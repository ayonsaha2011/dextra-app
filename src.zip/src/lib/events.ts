export const EVENTS = {
  ACTION_CREATED: 'action-created',
  ACTION_REFRESH: 'action-refresh',
} as const;

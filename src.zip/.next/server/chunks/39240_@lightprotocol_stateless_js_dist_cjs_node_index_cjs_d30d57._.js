module.exports = {

"[project]/node_modules/.pnpm/@lightprotocol+stateless.js@0.17.1_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@lightprotocol/stateless.js/dist/cjs/node/index.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
'use strict';
var web3_js = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.95.3_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
var anchor = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
var require$$0 = __turbopack_require__("[externals]/buffer [external] (buffer, cjs)");
var nacl = __turbopack_require__("[project]/node_modules/.pnpm/tweetnacl@1.0.3/node_modules/tweetnacl/nacl-fast.js [app-route] (ecmascript)");
var superstruct = __turbopack_require__("[project]/node_modules/.pnpm/superstruct@2.0.2/node_modules/superstruct/dist/index.mjs [app-route] (ecmascript)");
var require$$1 = __turbopack_require__("[externals]/util [external] (util, cjs)");
const IDL$3 = {
    version: '1.2.0',
    name: 'light_system_program',
    constants: [
        {
            name: 'SOL_POOL_PDA_SEED',
            type: 'bytes',
            value: '[115, 111, 108, 95, 112, 111, 111, 108, 95, 112, 100, 97]'
        }
    ],
    instructions: [
        {
            name: 'initCpiContextAccount',
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true
                },
                {
                    name: 'cpiContextAccount',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'associatedMerkleTree',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: []
        },
        {
            name: 'invoke',
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'Fee payer needs to be mutable to pay rollover and protocol fees.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'noopProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionAuthority',
                    isMut: false,
                    isSigner: false,
                    docs: [
                        'This pda is used to invoke the account compression program.'
                    ]
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false,
                    docs: [
                        'Merkle trees.'
                    ]
                },
                {
                    name: 'solPoolPda',
                    isMut: true,
                    isSigner: false,
                    isOptional: true,
                    docs: [
                        'Sol pool pda is used to store the native sol that has been compressed.',
                        "It's only required when compressing or decompressing sol."
                    ]
                },
                {
                    name: 'decompressionRecipient',
                    isMut: true,
                    isSigner: false,
                    isOptional: true,
                    docs: [
                        'Only needs to be provided for decompression as a recipient for the',
                        'decompressed sol.',
                        'Compressed sol originate from authority.'
                    ]
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'inputs',
                    type: 'bytes'
                }
            ]
        },
        {
            name: 'invokeCpi',
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'Fee payer needs to be mutable to pay rollover and protocol fees.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'noopProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'invokingProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'solPoolPda',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'decompressionRecipient',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'cpiContextAccount',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                }
            ],
            args: [
                {
                    name: 'inputs',
                    type: 'bytes'
                }
            ]
        },
        {
            name: 'stubIdlBuild',
            docs: [
                'This function is a stub to allow Anchor to include the input types in',
                'the IDL. It should not be included in production builds nor be called in',
                'practice.'
            ],
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'Fee payer needs to be mutable to pay rollover and protocol fees.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'noopProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionAuthority',
                    isMut: false,
                    isSigner: false,
                    docs: [
                        'This pda is used to invoke the account compression program.'
                    ]
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false,
                    docs: [
                        'Merkle trees.'
                    ]
                },
                {
                    name: 'solPoolPda',
                    isMut: true,
                    isSigner: false,
                    isOptional: true,
                    docs: [
                        'Sol pool pda is used to store the native sol that has been compressed.',
                        "It's only required when compressing or decompressing sol."
                    ]
                },
                {
                    name: 'decompressionRecipient',
                    isMut: true,
                    isSigner: false,
                    isOptional: true,
                    docs: [
                        'Only needs to be provided for decompression as a recipient for the',
                        'decompressed sol.',
                        'Compressed sol originate from authority.'
                    ]
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'inputs1',
                    type: {
                        defined: 'InstructionDataInvoke'
                    }
                },
                {
                    name: 'inputs2',
                    type: {
                        defined: 'InstructionDataInvokeCpi'
                    }
                },
                {
                    name: 'inputs3',
                    type: {
                        defined: 'PublicTransactionEvent'
                    }
                }
            ]
        }
    ],
    accounts: [
        {
            name: 'stateMerkleTreeAccount',
            docs: [
                'Concurrent state Merkle tree used for public compressed transactions.'
            ],
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'metadata',
                        type: {
                            defined: 'MerkleTreeMetadata'
                        }
                    }
                ]
            }
        },
        {
            name: 'cpiContextAccount',
            docs: [
                'Collects instruction data without executing a compressed transaction.',
                'Signer checks are performed on instruction data.',
                'Collected instruction data is combined with the instruction data of the executing cpi,',
                'and executed as a single transaction.',
                'This enables to use input compressed accounts that are owned by multiple programs,',
                'with one zero-knowledge proof.'
            ],
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'feePayer',
                        type: 'publicKey'
                    },
                    {
                        name: 'associatedMerkleTree',
                        type: 'publicKey'
                    },
                    {
                        name: 'context',
                        type: {
                            vec: {
                                defined: 'InstructionDataInvokeCpi'
                            }
                        }
                    }
                ]
            }
        }
    ],
    types: [
        {
            name: 'AccessMetadata',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'owner',
                        docs: [
                            'Owner of the Merkle tree.'
                        ],
                        type: 'publicKey'
                    },
                    {
                        name: 'programOwner',
                        docs: [
                            'Program owner of the Merkle tree. This will be used for program owned Merkle trees.'
                        ],
                        type: 'publicKey'
                    },
                    {
                        name: 'forester',
                        docs: [
                            'Optional privileged forester pubkey, can be set for custom Merkle trees',
                            'without a network fee. Merkle trees without network fees are not',
                            'forested by light foresters. The variable is not used in the account',
                            'compression program but the registry program. The registry program',
                            'implements access control to prevent contention during forester. The',
                            'forester pubkey specified in this struct can bypass contention checks.'
                        ],
                        type: 'publicKey'
                    }
                ]
            }
        },
        {
            name: 'MerkleTreeMetadata',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'accessMetadata',
                        type: {
                            defined: 'AccessMetadata'
                        }
                    },
                    {
                        name: 'rolloverMetadata',
                        type: {
                            defined: 'RolloverMetadata'
                        }
                    },
                    {
                        name: 'associatedQueue',
                        type: 'publicKey'
                    },
                    {
                        name: 'nextMerkleTree',
                        type: 'publicKey'
                    }
                ]
            }
        },
        {
            name: 'RolloverMetadata',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'index',
                        docs: [
                            'Unique index.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'rolloverFee',
                        docs: [
                            'This fee is used for rent for the next account.',
                            'It accumulates in the account so that once the corresponding Merkle tree account is full it can be rolled over'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'rolloverThreshold',
                        docs: [
                            'The threshold in percentage points when the account should be rolled over (95 corresponds to 95% filled).'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'networkFee',
                        docs: [
                            'Tip for maintaining the account.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'rolledoverSlot',
                        docs: [
                            'The slot when the account was rolled over, a rolled over account should not be written to.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'closeThreshold',
                        docs: [
                            'If current slot is greater than rolledover_slot + close_threshold and',
                            "the account is empty it can be closed. No 'close' functionality has been",
                            'implemented yet.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'additionalBytes',
                        docs: [
                            'Placeholder for bytes of additional accounts which are tied to the',
                            'Merkle trees operation and need to be rolled over as well.'
                        ],
                        type: 'u64'
                    }
                ]
            }
        },
        {
            name: 'InstructionDataInvoke',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'proof',
                        type: {
                            option: {
                                defined: 'CompressedProof'
                            }
                        }
                    },
                    {
                        name: 'inputCompressedAccountsWithMerkleContext',
                        type: {
                            vec: {
                                defined: 'PackedCompressedAccountWithMerkleContext'
                            }
                        }
                    },
                    {
                        name: 'outputCompressedAccounts',
                        type: {
                            vec: {
                                defined: 'OutputCompressedAccountWithPackedContext'
                            }
                        }
                    },
                    {
                        name: 'relayFee',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'newAddressParams',
                        type: {
                            vec: {
                                defined: 'NewAddressParamsPacked'
                            }
                        }
                    },
                    {
                        name: 'compressOrDecompressLamports',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'isCompress',
                        type: 'bool'
                    }
                ]
            }
        },
        {
            name: 'NewAddressParamsPacked',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'seed',
                        type: {
                            array: [
                                'u8',
                                32
                            ]
                        }
                    },
                    {
                        name: 'addressQueueAccountIndex',
                        type: 'u8'
                    },
                    {
                        name: 'addressMerkleTreeAccountIndex',
                        type: 'u8'
                    },
                    {
                        name: 'addressMerkleTreeRootIndex',
                        type: 'u16'
                    }
                ]
            }
        },
        {
            name: 'OutputCompressedAccountWithPackedContext',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'compressedAccount',
                        type: {
                            defined: 'CompressedAccount'
                        }
                    },
                    {
                        name: 'merkleTreeIndex',
                        type: 'u8'
                    }
                ]
            }
        },
        {
            name: 'CompressedProof',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'a',
                        type: {
                            array: [
                                'u8',
                                32
                            ]
                        }
                    },
                    {
                        name: 'b',
                        type: {
                            array: [
                                'u8',
                                64
                            ]
                        }
                    },
                    {
                        name: 'c',
                        type: {
                            array: [
                                'u8',
                                32
                            ]
                        }
                    }
                ]
            }
        },
        {
            name: 'InstructionDataInvokeCpi',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'proof',
                        type: {
                            option: {
                                defined: 'CompressedProof'
                            }
                        }
                    },
                    {
                        name: 'newAddressParams',
                        type: {
                            vec: {
                                defined: 'NewAddressParamsPacked'
                            }
                        }
                    },
                    {
                        name: 'inputCompressedAccountsWithMerkleContext',
                        type: {
                            vec: {
                                defined: 'PackedCompressedAccountWithMerkleContext'
                            }
                        }
                    },
                    {
                        name: 'outputCompressedAccounts',
                        type: {
                            vec: {
                                defined: 'OutputCompressedAccountWithPackedContext'
                            }
                        }
                    },
                    {
                        name: 'relayFee',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'compressOrDecompressLamports',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'isCompress',
                        type: 'bool'
                    },
                    {
                        name: 'cpiContext',
                        type: {
                            option: {
                                defined: 'CompressedCpiContext'
                            }
                        }
                    }
                ]
            }
        },
        {
            name: 'CompressedCpiContext',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'setContext',
                        docs: [
                            'Is set by the program that is invoking the CPI to signal that is should',
                            'set the cpi context.'
                        ],
                        type: 'bool'
                    },
                    {
                        name: 'firstSetContext',
                        docs: [
                            'Is set to wipe the cpi context since someone could have set it before',
                            'with unrelated data.'
                        ],
                        type: 'bool'
                    },
                    {
                        name: 'cpiContextAccountIndex',
                        docs: [
                            'Index of cpi context account in remaining accounts.'
                        ],
                        type: 'u8'
                    }
                ]
            }
        },
        {
            name: 'CompressedAccount',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'owner',
                        type: 'publicKey'
                    },
                    {
                        name: 'lamports',
                        type: 'u64'
                    },
                    {
                        name: 'address',
                        type: {
                            option: {
                                array: [
                                    'u8',
                                    32
                                ]
                            }
                        }
                    },
                    {
                        name: 'data',
                        type: {
                            option: {
                                defined: 'CompressedAccountData'
                            }
                        }
                    }
                ]
            }
        },
        {
            name: 'CompressedAccountData',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'discriminator',
                        type: {
                            array: [
                                'u8',
                                8
                            ]
                        }
                    },
                    {
                        name: 'data',
                        type: 'bytes'
                    },
                    {
                        name: 'dataHash',
                        type: {
                            array: [
                                'u8',
                                32
                            ]
                        }
                    }
                ]
            }
        },
        {
            name: 'PackedCompressedAccountWithMerkleContext',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'compressedAccount',
                        type: {
                            defined: 'CompressedAccount'
                        }
                    },
                    {
                        name: 'merkleContext',
                        type: {
                            defined: 'PackedMerkleContext'
                        }
                    },
                    {
                        name: 'rootIndex',
                        docs: [
                            'Index of root used in inclusion validity proof.'
                        ],
                        type: 'u16'
                    },
                    {
                        name: 'readOnly',
                        docs: [
                            'Placeholder to mark accounts read-only unimplemented set to false.'
                        ],
                        type: 'bool'
                    }
                ]
            }
        },
        {
            name: 'PackedMerkleContext',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'merkleTreePubkeyIndex',
                        type: 'u8'
                    },
                    {
                        name: 'nullifierQueuePubkeyIndex',
                        type: 'u8'
                    },
                    {
                        name: 'leafIndex',
                        type: 'u32'
                    },
                    {
                        name: 'queueIndex',
                        docs: [
                            'Index of leaf in queue. Placeholder of batched Merkle tree updates',
                            'currently unimplemented.'
                        ],
                        type: {
                            option: {
                                defined: 'QueueIndex'
                            }
                        }
                    }
                ]
            }
        },
        {
            name: 'QueueIndex',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'queueId',
                        docs: [
                            'Id of queue in queue account.'
                        ],
                        type: 'u8'
                    },
                    {
                        name: 'index',
                        docs: [
                            'Index of compressed account hash in queue.'
                        ],
                        type: 'u16'
                    }
                ]
            }
        },
        {
            name: 'MerkleTreeSequenceNumber',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'pubkey',
                        type: 'publicKey'
                    },
                    {
                        name: 'seq',
                        type: 'u64'
                    }
                ]
            }
        },
        {
            name: 'PublicTransactionEvent',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'inputCompressedAccountHashes',
                        type: {
                            vec: {
                                array: [
                                    'u8',
                                    32
                                ]
                            }
                        }
                    },
                    {
                        name: 'outputCompressedAccountHashes',
                        type: {
                            vec: {
                                array: [
                                    'u8',
                                    32
                                ]
                            }
                        }
                    },
                    {
                        name: 'outputCompressedAccounts',
                        type: {
                            vec: {
                                defined: 'OutputCompressedAccountWithPackedContext'
                            }
                        }
                    },
                    {
                        name: 'outputLeafIndices',
                        type: {
                            vec: 'u32'
                        }
                    },
                    {
                        name: 'sequenceNumbers',
                        type: {
                            vec: {
                                defined: 'MerkleTreeSequenceNumber'
                            }
                        }
                    },
                    {
                        name: 'relayFee',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'isCompress',
                        type: 'bool'
                    },
                    {
                        name: 'compressOrDecompressLamports',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'pubkeyArray',
                        type: {
                            vec: 'publicKey'
                        }
                    },
                    {
                        name: 'message',
                        type: {
                            option: 'bytes'
                        }
                    }
                ]
            }
        }
    ],
    errors: [
        {
            code: 6000,
            name: 'SumCheckFailed',
            msg: 'Sum check failed'
        },
        {
            code: 6001,
            name: 'SignerCheckFailed',
            msg: 'Signer check failed'
        },
        {
            code: 6002,
            name: 'CpiSignerCheckFailed',
            msg: 'Cpi signer check failed'
        },
        {
            code: 6003,
            name: 'ComputeInputSumFailed',
            msg: 'Computing input sum failed.'
        },
        {
            code: 6004,
            name: 'ComputeOutputSumFailed',
            msg: 'Computing output sum failed.'
        },
        {
            code: 6005,
            name: 'ComputeRpcSumFailed',
            msg: 'Computing rpc sum failed.'
        },
        {
            code: 6006,
            name: 'InvalidAddress',
            msg: 'InvalidAddress'
        },
        {
            code: 6007,
            name: 'DeriveAddressError',
            msg: 'DeriveAddressError'
        },
        {
            code: 6008,
            name: 'CompressedSolPdaUndefinedForCompressSol',
            msg: 'CompressedSolPdaUndefinedForCompressSol'
        },
        {
            code: 6009,
            name: 'DeCompressLamportsUndefinedForCompressSol',
            msg: 'DeCompressLamportsUndefinedForCompressSol'
        },
        {
            code: 6010,
            name: 'CompressedSolPdaUndefinedForDecompressSol',
            msg: 'CompressedSolPdaUndefinedForDecompressSol'
        },
        {
            code: 6011,
            name: 'DeCompressLamportsUndefinedForDecompressSol',
            msg: 'DeCompressLamportsUndefinedForDecompressSol'
        },
        {
            code: 6012,
            name: 'DecompressRecipientUndefinedForDecompressSol',
            msg: 'DecompressRecipientUndefinedForDecompressSol'
        },
        {
            code: 6013,
            name: 'WriteAccessCheckFailed',
            msg: 'WriteAccessCheckFailed'
        },
        {
            code: 6014,
            name: 'InvokingProgramNotProvided',
            msg: 'InvokingProgramNotProvided'
        },
        {
            code: 6015,
            name: 'InvalidCapacity',
            msg: 'InvalidCapacity'
        },
        {
            code: 6016,
            name: 'InvalidMerkleTreeOwner',
            msg: 'InvalidMerkleTreeOwner'
        },
        {
            code: 6017,
            name: 'ProofIsNone',
            msg: 'ProofIsNone'
        },
        {
            code: 6018,
            name: 'ProofIsSome',
            msg: 'Proof is some but no input compressed accounts or new addresses provided.'
        },
        {
            code: 6019,
            name: 'EmptyInputs',
            msg: 'EmptyInputs'
        },
        {
            code: 6020,
            name: 'CpiContextAccountUndefined',
            msg: 'CpiContextAccountUndefined'
        },
        {
            code: 6021,
            name: 'CpiContextEmpty',
            msg: 'CpiContextEmpty'
        },
        {
            code: 6022,
            name: 'CpiContextMissing',
            msg: 'CpiContextMissing'
        },
        {
            code: 6023,
            name: 'DecompressionRecipientDefined',
            msg: 'DecompressionRecipientDefined'
        },
        {
            code: 6024,
            name: 'SolPoolPdaDefined',
            msg: 'SolPoolPdaDefined'
        },
        {
            code: 6025,
            name: 'AppendStateFailed',
            msg: 'AppendStateFailed'
        },
        {
            code: 6026,
            name: 'InstructionNotCallable',
            msg: 'The instruction is not callable'
        },
        {
            code: 6027,
            name: 'CpiContextFeePayerMismatch',
            msg: 'CpiContextFeePayerMismatch'
        },
        {
            code: 6028,
            name: 'CpiContextAssociatedMerkleTreeMismatch',
            msg: 'CpiContextAssociatedMerkleTreeMismatch'
        },
        {
            code: 6029,
            name: 'NoInputs',
            msg: 'NoInputs'
        },
        {
            code: 6030,
            name: 'InputMerkleTreeIndicesNotInOrder',
            msg: 'Input merkle tree indices are not in ascending order.'
        },
        {
            code: 6031,
            name: 'OutputMerkleTreeIndicesNotInOrder',
            msg: 'Output merkle tree indices are not in ascending order.'
        },
        {
            code: 6032,
            name: 'OutputMerkleTreeNotUnique'
        },
        {
            code: 6033,
            name: 'DataFieldUndefined'
        }
    ]
};
/// TODO: extract wallet into its own npm package
const { sign } = nacl;
/// Mock Solana web3 library
class Wallet {
    constructor(keypair, url, commitment){
        this.signTransaction = async (tx)=>{
            await tx.sign([
                this._keypair
            ]);
            return tx;
        };
        this.sendTransaction = async (transaction)=>{
            const signature = await this._connection.sendTransaction(transaction);
            return signature;
        };
        this.signAllTransactions = async (transactions)=>{
            const signedTxs = await Promise.all(transactions.map(async (tx)=>{
                return await this.signTransaction(tx);
            }));
            return signedTxs;
        };
        this.signMessage = async (message)=>{
            return sign.detached(message, this._keypair.secretKey);
        };
        this.sendAndConfirmTransaction = async (transaction, signers = [])=>{
            const response = await web3_js.sendAndConfirmTransaction(this._connection, transaction, [
                this._keypair,
                ...signers
            ], {
                commitment: this._commitment
            });
            return response;
        };
        this._publicKey = keypair.publicKey;
        this._keypair = keypair;
        this._connection = new web3_js.Connection(url);
        this._url = url;
        this._commitment = commitment;
    }
}
// TODO consider adding isNodeWallet
const useWallet = (keypair, url = 'http://127.0.0.1:8899', commitment = 'confirmed')=>{
    url = url !== 'mock' ? url : 'http://127.0.0.1:8899';
    const wallet = new Wallet(keypair, url, commitment);
    return {
        publicKey: wallet._publicKey,
        sendAndConfirmTransaction: wallet.sendAndConfirmTransaction,
        signMessage: wallet.signMessage,
        signTransaction: wallet.signTransaction,
        signAllTransactions: wallet.signAllTransactions,
        sendTransaction: wallet.sendTransaction
    };
};
const FIELD_SIZE = new anchor.BN('21888242871839275222246405745257275088548364400416034343698204186575808495617');
const HIGHEST_ADDRESS_PLUS_ONE = new anchor.BN('452312848583266388373324160190187140051835877600158453279131187530910662655');
// TODO: implement properly
const noopProgram = 'noopb9bkMVfRPU8AsbpTUg8AQkHtKwMYZiFUjNRtMmV';
const lightProgram = 'SySTEM1eSU2p4BGQfQpimFEWWSC1XDFeun3Nqzz3rT7';
const accountCompressionProgram = 'compr6CUsB5m2jS4Y3831ztGSTnDpnKJTKS95d64XVq';
const getRegisteredProgramPda = ()=>new web3_js.PublicKey('35hkDgaAKwMCaxRz2ocSZ6NaUrtKkyNqU6c4RV3tYJRh'); // TODO: better labelling. gov authority pda
const getAccountCompressionAuthority = ()=>web3_js.PublicKey.findProgramAddressSync([
        require$$0.Buffer.from('cpi_authority')
    ], new web3_js.PublicKey(// TODO: can add check to ensure its consistent with the idl
    lightProgram))[0];
const defaultStaticAccounts = ()=>[
        new web3_js.PublicKey(getRegisteredProgramPda()),
        new web3_js.PublicKey(noopProgram),
        new web3_js.PublicKey(accountCompressionProgram),
        new web3_js.PublicKey(getAccountCompressionAuthority())
    ];
const defaultStaticAccountsStruct = ()=>{
    return {
        registeredProgramPda: new web3_js.PublicKey(getRegisteredProgramPda()),
        noopProgram: new web3_js.PublicKey(noopProgram),
        accountCompressionProgram: new web3_js.PublicKey(accountCompressionProgram),
        accountCompressionAuthority: new web3_js.PublicKey(getAccountCompressionAuthority()),
        cpiSignatureAccount: null
    };
};
const defaultTestStateTreeAccounts = ()=>{
    return {
        nullifierQueue: new web3_js.PublicKey(nullifierQueuePubkey),
        merkleTree: new web3_js.PublicKey(merkletreePubkey),
        merkleTreeHeight: DEFAULT_MERKLE_TREE_HEIGHT,
        addressTree: new web3_js.PublicKey(addressTree),
        addressQueue: new web3_js.PublicKey(addressQueue)
    };
};
const nullifierQueuePubkey = 'nfq1NvQDJ2GEgnS8zt9prAe8rjjpAW1zFkrvZoBR148';
const merkletreePubkey = 'smt1NamzXdq4AMqS2fS2F1i5KTYPZRhoHgWx38d8WsT';
const addressTree = 'amt1Ayt45jfbdw5YSo7iz6WZxUmnZsQTYXy82hVwyC2';
const addressQueue = 'aq1S9z4reTSQAdgWHGD2zDaS39sjGrAxbR31vxJ2F4F';
const confirmConfig = {
    commitment: 'confirmed',
    preflightCommitment: 'confirmed'
};
const DEFAULT_MERKLE_TREE_HEIGHT = 26;
const DEFAULT_MERKLE_TREE_ROOTS = 2800;
/** Threshold (per asset) at which new in-UTXOs get merged, in order to reduce UTXO pool size */ const UTXO_MERGE_THRESHOLD = 20;
const UTXO_MERGE_MAXIMUM = 10;
/**
 * Treshold after which the currently used transaction Merkle tree is switched
 * to the next one
 */ const TRANSACTION_MERKLE_TREE_ROLLOVER_THRESHOLD = new anchor.BN(Math.floor(2 ** DEFAULT_MERKLE_TREE_HEIGHT * 0.95));
/**
 * Fee to provide continous funding for the state Merkle tree.
 * Once the state Merkle tree is at 95% capacity the accumulated fees
 * will be used to fund the next state Merkle tree with the same parameters.
 *
 * Is charged per output compressed account.
 */ const STATE_MERKLE_TREE_ROLLOVER_FEE = new anchor.BN(300);
/**
 * Fee to provide continous funding for the address queue and address Merkle tree.
 * Once the address Merkle tree is at 95% capacity the accumulated fees
 * will be used to fund the next address queue and address tree with the same parameters.
 *
 * Is charged per newly created address.
 */ const ADDRESS_QUEUE_ROLLOVER_FEE = new anchor.BN(392);
/**
 * Is charged if the transaction nullifies at least one compressed account.
 */ const STATE_MERKLE_TREE_NETWORK_FEE = new anchor.BN(5000);
/**
 * Is charged if the transaction creates at least one address.
 */ const ADDRESS_TREE_NETWORK_FEE = new anchor.BN(5000);
var _a$1;
/**
 * Returns true if being run inside a web browser,
 * false if in a Node process or electron app.
 */ process.env.ANCHOR_BROWSER || "undefined" !== "undefined" && !((_a$1 = window.process) === null || _a$1 === void 0 ? void 0 : _a$1.hasOwnProperty("type"));
var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : ("TURBOPACK compile-time falsy", 0) ? ("TURBOPACK unreachable", undefined) : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};
function getDefaultExportFromCjs(x) {
    return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
}
var safeBuffer = {
    exports: {}
};
/*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */ (function(module, exports1) {
    /* eslint-disable node/no-deprecated-api */ var buffer = require$$0;
    var Buffer1 = buffer.Buffer;
    // alternative to using Object.keys for old browsers
    function copyProps(src, dst) {
        for(var key in src){
            dst[key] = src[key];
        }
    }
    if (Buffer1.from && Buffer1.alloc && Buffer1.allocUnsafe && Buffer1.allocUnsafeSlow) {
        module.exports = buffer;
    } else {
        // Copy properties from require('buffer')
        copyProps(buffer, exports1);
        exports1.Buffer = SafeBuffer;
    }
    function SafeBuffer(arg, encodingOrOffset, length) {
        return Buffer1(arg, encodingOrOffset, length);
    }
    SafeBuffer.prototype = Object.create(Buffer1.prototype);
    // Copy static methods from Buffer
    copyProps(Buffer1, SafeBuffer);
    SafeBuffer.from = function(arg, encodingOrOffset, length) {
        if (typeof arg === 'number') {
            throw new TypeError('Argument must not be a number');
        }
        return Buffer1(arg, encodingOrOffset, length);
    };
    SafeBuffer.alloc = function(size, fill, encoding) {
        if (typeof size !== 'number') {
            throw new TypeError('Argument must be a number');
        }
        var buf = Buffer1(size);
        if (fill !== undefined) {
            if (typeof encoding === 'string') {
                buf.fill(fill, encoding);
            } else {
                buf.fill(fill);
            }
        } else {
            buf.fill(0);
        }
        return buf;
    };
    SafeBuffer.allocUnsafe = function(size) {
        if (typeof size !== 'number') {
            throw new TypeError('Argument must be a number');
        }
        return Buffer1(size);
    };
    SafeBuffer.allocUnsafeSlow = function(size) {
        if (typeof size !== 'number') {
            throw new TypeError('Argument must be a number');
        }
        return buffer.SlowBuffer(size);
    };
})(safeBuffer, safeBuffer.exports);
var safeBufferExports = safeBuffer.exports;
// base-x encoding / decoding
// Copyright (c) 2018 base-x contributors
// Copyright (c) 2014-2018 The Bitcoin Core developers (base58.cpp)
// Distributed under the MIT software license, see the accompanying
// file LICENSE or http://www.opensource.org/licenses/mit-license.php.
// @ts-ignore
var _Buffer = safeBufferExports.Buffer;
function base(ALPHABET) {
    if (ALPHABET.length >= 255) {
        throw new TypeError('Alphabet too long');
    }
    var BASE_MAP = new Uint8Array(256);
    for(var j = 0; j < BASE_MAP.length; j++){
        BASE_MAP[j] = 255;
    }
    for(var i = 0; i < ALPHABET.length; i++){
        var x = ALPHABET.charAt(i);
        var xc = x.charCodeAt(0);
        if (BASE_MAP[xc] !== 255) {
            throw new TypeError(x + ' is ambiguous');
        }
        BASE_MAP[xc] = i;
    }
    var BASE = ALPHABET.length;
    var LEADER = ALPHABET.charAt(0);
    var FACTOR = Math.log(BASE) / Math.log(256); // log(BASE) / log(256), rounded up
    var iFACTOR = Math.log(256) / Math.log(BASE); // log(256) / log(BASE), rounded up
    function encode(source) {
        if (Array.isArray(source) || source instanceof Uint8Array) {
            source = _Buffer.from(source);
        }
        if (!_Buffer.isBuffer(source)) {
            throw new TypeError('Expected Buffer');
        }
        if (source.length === 0) {
            return '';
        }
        // Skip & count leading zeroes.
        var zeroes = 0;
        var length = 0;
        var pbegin = 0;
        var pend = source.length;
        while(pbegin !== pend && source[pbegin] === 0){
            pbegin++;
            zeroes++;
        }
        // Allocate enough space in big-endian base58 representation.
        var size = (pend - pbegin) * iFACTOR + 1 >>> 0;
        var b58 = new Uint8Array(size);
        // Process the bytes.
        while(pbegin !== pend){
            var carry = source[pbegin];
            // Apply "b58 = b58 * 256 + ch".
            var i = 0;
            for(var it1 = size - 1; (carry !== 0 || i < length) && it1 !== -1; it1--, i++){
                carry += 256 * b58[it1] >>> 0;
                b58[it1] = carry % BASE >>> 0;
                carry = carry / BASE >>> 0;
            }
            if (carry !== 0) {
                throw new Error('Non-zero carry');
            }
            length = i;
            pbegin++;
        }
        // Skip leading zeroes in base58 result.
        var it2 = size - length;
        while(it2 !== size && b58[it2] === 0){
            it2++;
        }
        // Translate the result into a string.
        var str = LEADER.repeat(zeroes);
        for(; it2 < size; ++it2){
            str += ALPHABET.charAt(b58[it2]);
        }
        return str;
    }
    function decodeUnsafe(source) {
        if (typeof source !== 'string') {
            throw new TypeError('Expected String');
        }
        if (source.length === 0) {
            return _Buffer.alloc(0);
        }
        var psz = 0;
        // Skip and count leading '1's.
        var zeroes = 0;
        var length = 0;
        while(source[psz] === LEADER){
            zeroes++;
            psz++;
        }
        // Allocate enough space in big-endian base256 representation.
        var size = (source.length - psz) * FACTOR + 1 >>> 0; // log(58) / log(256), rounded up.
        var b256 = new Uint8Array(size);
        // Process the characters.
        while(source[psz]){
            // Decode character
            var carry = BASE_MAP[source.charCodeAt(psz)];
            // Invalid character
            if (carry === 255) {
                return;
            }
            var i = 0;
            for(var it3 = size - 1; (carry !== 0 || i < length) && it3 !== -1; it3--, i++){
                carry += BASE * b256[it3] >>> 0;
                b256[it3] = carry % 256 >>> 0;
                carry = carry / 256 >>> 0;
            }
            if (carry !== 0) {
                throw new Error('Non-zero carry');
            }
            length = i;
            psz++;
        }
        // Skip leading zeroes in b256.
        var it4 = size - length;
        while(it4 !== size && b256[it4] === 0){
            it4++;
        }
        var vch = _Buffer.allocUnsafe(zeroes + (size - it4));
        vch.fill(0x00, 0, zeroes);
        var j = zeroes;
        while(it4 !== size){
            vch[j++] = b256[it4++];
        }
        return vch;
    }
    function decode(string) {
        var buffer = decodeUnsafe(string);
        if (buffer) {
            return buffer;
        }
        throw new Error('Non-base' + BASE + ' character');
    }
    return {
        encode: encode,
        decodeUnsafe: decodeUnsafe,
        decode: decode
    };
}
var src = base;
var basex = src;
var ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
var bs58$2 = basex(ALPHABET);
var bs58$3 = /*@__PURE__*/ getDefaultExportFromCjs(bs58$2);
function encode$4(data) {
    return bs58$3.encode(data);
}
function decode$4(data) {
    return bs58$3.decode(data);
}
// TODO: consider implementing BN254 as wrapper class around _BN mirroring
// PublicKey this would encapsulate our runtime checks and also enforce
// typesafety at compile time
const bn = (number, base, endian)=>new anchor.BN(number, base, endian);
/** Create a bigint instance with <254-bit max size and base58 capabilities */ const createBN254 = (number, base)=>{
    if (base === 'base58') {
        if (typeof number !== 'string') throw new Error('Must be a base58 string');
        return createBN254(decode$4(number));
    }
    const bigintNumber = new anchor.BN(number, base);
    return enforceSize(bigintNumber);
};
/**
 * Enforces a maximum size of <254 bits for bigint instances. This is necessary
 * for compatibility with zk-SNARKs, where hashes must be less than the field
 * modulus (~2^254).
 */ function enforceSize(bigintNumber) {
    if (bigintNumber.gte(FIELD_SIZE)) {
        throw new Error('Value is too large. Max <254 bits');
    }
    return bigintNumber;
}
/** Convert <254-bit bigint to Base58 string.  */ function encodeBN254toBase58(bigintNumber) {
    /// enforce size
    const bn254 = createBN254(bigintNumber);
    const bn254Buffer = bn254.toArrayLike(require$$0.Buffer, undefined, 32);
    return encode$4(bn254Buffer);
}
const createCompressedAccount = (owner, lamports, data, address)=>({
        owner,
        lamports: lamports !== null && lamports !== void 0 ? lamports : bn(0),
        address: address !== null && address !== void 0 ? address : null,
        data: data !== null && data !== void 0 ? data : null
    });
const createCompressedAccountWithMerkleContext = (merkleContext, owner, lamports, data, address)=>Object.assign(Object.assign(Object.assign({}, createCompressedAccount(owner, lamports, data, address)), merkleContext), {
        readOnly: false
    });
const createMerkleContext = (merkleTree, nullifierQueue, hash, leafIndex)=>({
        merkleTree,
        nullifierQueue,
        hash,
        leafIndex
    });
function number(n) {
    if (!Number.isSafeInteger(n) || n < 0) throw new Error(`positive integer expected, not ${n}`);
}
// copied from utils
function isBytes(a) {
    return a instanceof Uint8Array || a != null && typeof a === 'object' && a.constructor.name === 'Uint8Array';
}
function bytes$1(b, ...lengths) {
    if (!isBytes(b)) throw new Error('Uint8Array expected');
    if (lengths.length > 0 && !lengths.includes(b.length)) throw new Error(`Uint8Array expected of length ${lengths}, not of length=${b.length}`);
}
function exists(instance, checkFinished = true) {
    if (instance.destroyed) throw new Error('Hash instance has been destroyed');
    if (checkFinished && instance.finished) throw new Error('Hash#digest() has already been called');
}
function output(out, instance) {
    bytes$1(out);
    const min = instance.outputLen;
    if (out.length < min) {
        throw new Error(`digestInto() expects output buffer of length at least ${min}`);
    }
}
const U32_MASK64 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
const _32n = /* @__PURE__ */ BigInt(32);
// We are not using BigUint64Array, because they are extremely slow as per 2022
function fromBig(n, le = false) {
    if (le) return {
        h: Number(n & U32_MASK64),
        l: Number(n >> _32n & U32_MASK64)
    };
    return {
        h: Number(n >> _32n & U32_MASK64) | 0,
        l: Number(n & U32_MASK64) | 0
    };
}
function split(lst, le = false) {
    let Ah = new Uint32Array(lst.length);
    let Al = new Uint32Array(lst.length);
    for(let i = 0; i < lst.length; i++){
        const { h, l } = fromBig(lst[i], le);
        [Ah[i], Al[i]] = [
            h,
            l
        ];
    }
    return [
        Ah,
        Al
    ];
}
// Left rotate for Shift in [1, 32)
const rotlSH = (h, l, s)=>h << s | l >>> 32 - s;
const rotlSL = (h, l, s)=>l << s | h >>> 32 - s;
// Left rotate for Shift in (32, 64), NOTE: 32 is special case.
const rotlBH = (h, l, s)=>l << s - 32 | h >>> 64 - s;
const rotlBL = (h, l, s)=>h << s - 32 | l >>> 64 - s;
/*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */ // We use WebCrypto aka globalThis.crypto, which exists in browsers and node.js 16+.
// node.js versions earlier than v19 don't declare it in global scope.
// For node.js, package.json#exports field mapping rewrites import
// from `crypto` to `cryptoNode`, which imports native module.
// Makes the utils un-importable in browsers without a bundler.
// Once node.js 18 is deprecated (2025-04-30), we can just drop the import.
const u32 = (arr)=>new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
const isLE = new Uint8Array(new Uint32Array([
    0x11223344
]).buffer)[0] === 0x44;
// The byte swap operation for uint32
const byteSwap = (word)=>word << 24 & 0xff000000 | word << 8 & 0xff0000 | word >>> 8 & 0xff00 | word >>> 24 & 0xff;
// In place byte swap for Uint32Array
function byteSwap32(arr) {
    for(let i = 0; i < arr.length; i++){
        arr[i] = byteSwap(arr[i]);
    }
}
/**
 * @example utf8ToBytes('abc') // new Uint8Array([97, 98, 99])
 */ function utf8ToBytes(str) {
    if (typeof str !== 'string') throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
    return new Uint8Array(new TextEncoder().encode(str)); // https://bugzil.la/1681809
}
/**
 * Normalizes (non-hex) string or Uint8Array to Uint8Array.
 * Warning: when Uint8Array is passed, it would NOT get copied.
 * Keep in mind for future mutable operations.
 */ function toBytes(data) {
    if (typeof data === 'string') data = utf8ToBytes(data);
    bytes$1(data);
    return data;
}
// For runtime check if class implements interface
class Hash {
    // Safe version that clones internal state
    clone() {
        return this._cloneInto();
    }
}
function wrapConstructor(hashCons) {
    const hashC = (msg)=>hashCons().update(toBytes(msg)).digest();
    const tmp = hashCons();
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = ()=>hashCons();
    return hashC;
}
// SHA3 (keccak) is based on a new design: basically, the internal state is bigger than output size.
// It's called a sponge function.
// Various per round constants calculations
const SHA3_PI = [];
const SHA3_ROTL = [];
const _SHA3_IOTA = [];
const _0n = /* @__PURE__ */ BigInt(0);
const _1n = /* @__PURE__ */ BigInt(1);
const _2n = /* @__PURE__ */ BigInt(2);
const _7n = /* @__PURE__ */ BigInt(7);
const _256n = /* @__PURE__ */ BigInt(256);
const _0x71n = /* @__PURE__ */ BigInt(0x71);
for(let round = 0, R = _1n, x = 1, y = 0; round < 24; round++){
    // Pi
    [x, y] = [
        y,
        (2 * x + 3 * y) % 5
    ];
    SHA3_PI.push(2 * (5 * y + x));
    // Rotational
    SHA3_ROTL.push((round + 1) * (round + 2) / 2 % 64);
    // Iota
    let t = _0n;
    for(let j = 0; j < 7; j++){
        R = (R << _1n ^ (R >> _7n) * _0x71n) % _256n;
        if (R & _2n) t ^= _1n << (_1n << /* @__PURE__ */ BigInt(j)) - _1n;
    }
    _SHA3_IOTA.push(t);
}
const [SHA3_IOTA_H, SHA3_IOTA_L] = /* @__PURE__ */ split(_SHA3_IOTA, true);
// Left rotation (without 0, 32, 64)
const rotlH = (h, l, s)=>s > 32 ? rotlBH(h, l, s) : rotlSH(h, l, s);
const rotlL = (h, l, s)=>s > 32 ? rotlBL(h, l, s) : rotlSL(h, l, s);
// Same as keccakf1600, but allows to skip some rounds
function keccakP(s, rounds = 24) {
    const B = new Uint32Array(5 * 2);
    // NOTE: all indices are x2 since we store state as u32 instead of u64 (bigints to slow in js)
    for(let round = 24 - rounds; round < 24; round++){
        // Theta θ
        for(let x = 0; x < 10; x++)B[x] = s[x] ^ s[x + 10] ^ s[x + 20] ^ s[x + 30] ^ s[x + 40];
        for(let x = 0; x < 10; x += 2){
            const idx1 = (x + 8) % 10;
            const idx0 = (x + 2) % 10;
            const B0 = B[idx0];
            const B1 = B[idx0 + 1];
            const Th = rotlH(B0, B1, 1) ^ B[idx1];
            const Tl = rotlL(B0, B1, 1) ^ B[idx1 + 1];
            for(let y = 0; y < 50; y += 10){
                s[x + y] ^= Th;
                s[x + y + 1] ^= Tl;
            }
        }
        // Rho (ρ) and Pi (π)
        let curH = s[2];
        let curL = s[3];
        for(let t = 0; t < 24; t++){
            const shift = SHA3_ROTL[t];
            const Th = rotlH(curH, curL, shift);
            const Tl = rotlL(curH, curL, shift);
            const PI = SHA3_PI[t];
            curH = s[PI];
            curL = s[PI + 1];
            s[PI] = Th;
            s[PI + 1] = Tl;
        }
        // Chi (χ)
        for(let y = 0; y < 50; y += 10){
            for(let x = 0; x < 10; x++)B[x] = s[y + x];
            for(let x = 0; x < 10; x++)s[y + x] ^= ~B[(x + 2) % 10] & B[(x + 4) % 10];
        }
        // Iota (ι)
        s[0] ^= SHA3_IOTA_H[round];
        s[1] ^= SHA3_IOTA_L[round];
    }
    B.fill(0);
}
class Keccak extends Hash {
    // NOTE: we accept arguments in bytes instead of bits here.
    constructor(blockLen, suffix, outputLen, enableXOF = false, rounds = 24){
        super();
        this.blockLen = blockLen;
        this.suffix = suffix;
        this.outputLen = outputLen;
        this.enableXOF = enableXOF;
        this.rounds = rounds;
        this.pos = 0;
        this.posOut = 0;
        this.finished = false;
        this.destroyed = false;
        // Can be passed from user as dkLen
        number(outputLen);
        // 1600 = 5x5 matrix of 64bit.  1600 bits === 200 bytes
        if (0 >= this.blockLen || this.blockLen >= 200) throw new Error('Sha3 supports only keccak-f1600 function');
        this.state = new Uint8Array(200);
        this.state32 = u32(this.state);
    }
    keccak() {
        if (!isLE) byteSwap32(this.state32);
        keccakP(this.state32, this.rounds);
        if (!isLE) byteSwap32(this.state32);
        this.posOut = 0;
        this.pos = 0;
    }
    update(data) {
        exists(this);
        const { blockLen, state } = this;
        data = toBytes(data);
        const len = data.length;
        for(let pos = 0; pos < len;){
            const take = Math.min(blockLen - this.pos, len - pos);
            for(let i = 0; i < take; i++)state[this.pos++] ^= data[pos++];
            if (this.pos === blockLen) this.keccak();
        }
        return this;
    }
    finish() {
        if (this.finished) return;
        this.finished = true;
        const { state, suffix, pos, blockLen } = this;
        // Do the padding
        state[pos] ^= suffix;
        if ((suffix & 0x80) !== 0 && pos === blockLen - 1) this.keccak();
        state[blockLen - 1] ^= 0x80;
        this.keccak();
    }
    writeInto(out) {
        exists(this, false);
        bytes$1(out);
        this.finish();
        const bufferOut = this.state;
        const { blockLen } = this;
        for(let pos = 0, len = out.length; pos < len;){
            if (this.posOut >= blockLen) this.keccak();
            const take = Math.min(blockLen - this.posOut, len - pos);
            out.set(bufferOut.subarray(this.posOut, this.posOut + take), pos);
            this.posOut += take;
            pos += take;
        }
        return out;
    }
    xofInto(out) {
        // Sha3/Keccak usage with XOF is probably mistake, only SHAKE instances can do XOF
        if (!this.enableXOF) throw new Error('XOF is not possible for this instance');
        return this.writeInto(out);
    }
    xof(bytes) {
        number(bytes);
        return this.xofInto(new Uint8Array(bytes));
    }
    digestInto(out) {
        output(out, this);
        if (this.finished) throw new Error('digest() was already called');
        this.writeInto(out);
        this.destroy();
        return out;
    }
    digest() {
        return this.digestInto(new Uint8Array(this.outputLen));
    }
    destroy() {
        this.destroyed = true;
        this.state.fill(0);
    }
    _cloneInto(to) {
        const { blockLen, suffix, outputLen, rounds, enableXOF } = this;
        to || (to = new Keccak(blockLen, suffix, outputLen, enableXOF, rounds));
        to.state32.set(this.state32);
        to.pos = this.pos;
        to.posOut = this.posOut;
        to.finished = this.finished;
        to.rounds = rounds;
        // Suffix can change in cSHAKE
        to.suffix = suffix;
        to.outputLen = outputLen;
        to.enableXOF = enableXOF;
        to.destroyed = this.destroyed;
        return to;
    }
}
const gen = (suffix, blockLen, outputLen)=>wrapConstructor(()=>new Keccak(blockLen, suffix, outputLen));
/**
 * keccak-256 hash function. Different from SHA3-256.
 * @param message - that would be hashed
 */ const keccak_256 = /* @__PURE__ */ gen(0x01, 136, 256 / 8);
function byteArrayToKeypair(byteArray) {
    return web3_js.Keypair.fromSecretKey(Uint8Array.from(byteArray));
}
/**
 * @internal
 * convert BN to hex with '0x' prefix
 */ function toHex(bn) {
    return '0x' + bn.toString('hex');
}
const toArray = (value)=>Array.isArray(value) ? value : [
        value
    ];
const bufToDecStr = (buf)=>{
    return createBN254(buf).toString();
};
function isSmallerThanBn254FieldSizeBe(bytes) {
    const bigint = bn(bytes, undefined, 'be');
    return bigint.lt(FIELD_SIZE);
}
/**
 * Hash the provided `bytes` with Keccak256 and ensure the result fits in the
 * BN254 prime field by repeatedly hashing the inputs with various "bump seeds"
 * and truncating the resulting hash to 31 bytes.
 *
 * @deprecated Use `hashvToBn254FieldSizeBe` instead.
 */ function hashToBn254FieldSizeBe(bytes) {
    // TODO(vadorovsky, affects-onchain): Get rid of the bump mechanism, it
    // makes no sense. Doing the same as in the `hashvToBn254FieldSizeBe` below
    // - overwriting the most significant byte with zero - is sufficient for
    // truncation, it's also faster, doesn't force us to return `Option` and
    // care about handling an error which is practically never returned.
    //
    // The reason we can't do it now is that it would affect on-chain programs.
    // Once we can update programs, we can get rid of the seed bump (or even of
    // this function all together in favor of the `hashv` variant).
    let bumpSeed = 255;
    while(bumpSeed >= 0){
        const inputWithBumpSeed = require$$0.Buffer.concat([
            bytes,
            require$$0.Buffer.from([
                bumpSeed
            ])
        ]);
        const hash = keccak_256(inputWithBumpSeed);
        if (hash.length !== 32) {
            throw new Error('Invalid hash length');
        }
        hash[0] = 0;
        if (isSmallerThanBn254FieldSizeBe(require$$0.Buffer.from(hash))) {
            return [
                require$$0.Buffer.from(hash),
                bumpSeed
            ];
        }
        bumpSeed -= 1;
    }
    return null;
}
/**
 * Hash the provided `bytes` with Keccak256 and ensure that the result fits in
 * the BN254 prime field by truncating the resulting hash to 31 bytes.
 *
 * @param bytes Input bytes
 *
 * @returns     Hash digest
 */ function hashvToBn254FieldSizeBe(bytes) {
    const hasher = keccak_256.create();
    for (const input of bytes){
        hasher.update(input);
    }
    const hash = hasher.digest();
    hash[0] = 0;
    return hash;
}
/** Mutates array in place */ function pushUniqueItems(items, map) {
    items.forEach((item)=>{
        if (!map.includes(item)) {
            map.push(item);
        }
    });
}
function toCamelCase(obj) {
    if (Array.isArray(obj)) {
        return obj.map((v)=>toCamelCase(v));
    } else if (obj !== null && obj.constructor === Object) {
        return Object.keys(obj).reduce((result, key)=>{
            const camelCaseKey = key.replace(/([-_][a-z])/gi, ($1)=>{
                return $1.toUpperCase().replace('-', '').replace('_', '');
            });
            result[camelCaseKey] = toCamelCase(obj[key]);
            return result;
        }, {});
    }
    return obj;
}
// FIXME: check bundling and how to resolve the type error
//@ts-ignore
if (undefined) {
    //@ts-ignore
    const { it, expect, describe } = undefined;
    describe('toArray function', ()=>{
        it('should convert a single item to an array', ()=>{
            expect(toArray(1)).toEqual([
                1
            ]);
        });
        it('should leave an array unchanged', ()=>{
            expect(toArray([
                1,
                2,
                3
            ])).toEqual([
                1,
                2,
                3
            ]);
        });
    });
    describe('isSmallerThanBn254FieldSizeBe function', ()=>{
        it('should return true for a small number', ()=>{
            const buf = require$$0.Buffer.from('0000000000000000000000000000000000000000000000000000000000000000', 'hex');
            expect(isSmallerThanBn254FieldSizeBe(buf)).toBe(true);
        });
        it('should return false for a large number', ()=>{
            const buf = require$$0.Buffer.from('0000000000000000000000000000000000000000000000000000000000000065', 'hex').reverse();
            expect(isSmallerThanBn254FieldSizeBe(buf)).toBe(false);
        });
    });
    describe('hashToBn254FieldSizeBe function', ()=>{
        const bytes = [
            131,
            219,
            249,
            246,
            221,
            196,
            33,
            3,
            114,
            23,
            121,
            235,
            18,
            229,
            71,
            152,
            39,
            87,
            169,
            208,
            143,
            101,
            43,
            128,
            245,
            59,
            22,
            134,
            182,
            231,
            116,
            33
        ];
        const refResult = [
            0,
            146,
            15,
            187,
            171,
            163,
            183,
            93,
            237,
            121,
            37,
            231,
            55,
            162,
            208,
            188,
            244,
            77,
            185,
            157,
            93,
            9,
            101,
            193,
            220,
            247,
            109,
            94,
            48,
            212,
            98,
            149
        ];
        it('should return a valid value for initial buffer', async ()=>{
            const result = await hashToBn254FieldSizeBe(require$$0.Buffer.from(bytes));
            expect(Array.from(result[0])).toEqual(refResult);
        });
        it('should return a valid value for initial buffer', async ()=>{
            const buf = require$$0.Buffer.from('0000000000000000000000000000000000000000000000000000000000000000', 'hex');
            const result = await hashToBn254FieldSizeBe(buf);
            expect(result).not.toBeNull();
            if (result) {
                expect(result[0]).toBeInstanceOf(require$$0.Buffer);
                expect(result[1]).toBe(255);
            }
        });
        it('should return a valid value for a buffer that can be hashed to a smaller value', async ()=>{
            const buf = require$$0.Buffer.from('fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe', 'hex');
            const result = await hashToBn254FieldSizeBe(buf);
            expect(result).not.toBeNull();
            if (result) {
                expect(result[1]).toBeLessThanOrEqual(255);
                expect(result[0]).toBeInstanceOf(require$$0.Buffer);
                // Check if the hashed value is indeed smaller than the bn254 field size
                expect(isSmallerThanBn254FieldSizeBe(result[0])).toBe(true);
            }
        });
        it('should correctly hash the input buffer', async ()=>{
            const buf = require$$0.Buffer.from('deadbeef', 'hex');
            const result = await hashToBn254FieldSizeBe(buf);
            expect(result).not.toBeNull();
            if (result) {
                // Since the actual hash value depends on the crypto implementation and input,
                // we cannot predict the exact output. However, we can check if the output is valid.
                expect(result[0].length).toBe(32); // SHA-256 hash length
                expect(result[1]).toBeLessThanOrEqual(255);
                expect(isSmallerThanBn254FieldSizeBe(result[0])).toBe(true);
            }
        });
    });
    describe('pushUniqueItems function', ()=>{
        it('should add unique items', ()=>{
            const map = [
                1,
                2,
                3
            ];
            const itemsToAdd = [
                3,
                4,
                5
            ];
            pushUniqueItems(itemsToAdd, map);
            expect(map).toEqual([
                1,
                2,
                3,
                4,
                5
            ]);
        });
        it('should ignore duplicates', ()=>{
            const map = [
                1,
                2,
                3
            ];
            const itemsToAdd = [
                1,
                2,
                3
            ];
            pushUniqueItems(itemsToAdd, map);
            expect(map).toEqual([
                1,
                2,
                3
            ]);
        });
        it('should handle empty arrays', ()=>{
            const map = [];
            const itemsToAdd = [];
            pushUniqueItems(itemsToAdd, map);
            expect(map).toEqual([]);
        });
    });
    describe('bufToDecStr', ()=>{
        it("should convert buffer [0] to '0'", ()=>{
            expect(bufToDecStr(require$$0.Buffer.from([
                0
            ]))).toEqual('0');
        });
        it("should convert buffer [1] to '1'", ()=>{
            expect(bufToDecStr(require$$0.Buffer.from([
                1
            ]))).toEqual('1');
        });
        it("should convert buffer [1, 0] to '256'", ()=>{
            expect(bufToDecStr(require$$0.Buffer.from([
                1,
                0
            ]))).toEqual('256');
        });
        it("should convert buffer [1, 1] to '257'", ()=>{
            expect(bufToDecStr(require$$0.Buffer.from([
                1,
                1
            ]))).toEqual('257');
        });
        it("should convert buffer [7, 91, 205, 21] to '123456789'", ()=>{
            expect(bufToDecStr(require$$0.Buffer.from([
                7,
                91,
                205,
                21
            ]))).toEqual('123456789');
        });
    });
    describe('toCamelCase', ()=>{
        it('should convert object keys to camelCase', ()=>{
            const input = {
                test_key: 1,
                'another-testKey': 2
            };
            const expected = {
                testKey: 1,
                anotherTestKey: 2
            };
            expect(toCamelCase(input)).toEqual(expected);
        });
        it('should handle arrays of objects', ()=>{
            const input = [
                {
                    array_key: 3
                },
                {
                    'another_array-key': 4
                }
            ];
            const expected = [
                {
                    arrayKey: 3
                },
                {
                    anotherArrayKey: 4
                }
            ];
            expect(toCamelCase(input)).toEqual(expected);
        });
        it('should return the input if it is neither an object nor an array', ()=>{
            const input = 'testString';
            expect(toCamelCase(input)).toBe(input);
        });
    });
}
/**
 * @internal Finds the index of a PublicKey in an array, or adds it if not
 * present
 * */ function getIndexOrAdd(accountsArray, key) {
    const index = accountsArray.findIndex((existingKey)=>existingKey.equals(key));
    if (index === -1) {
        accountsArray.push(key);
        return accountsArray.length - 1;
    }
    return index;
}
/** @internal */ function padOutputStateMerkleTrees(outputStateMerkleTrees, numberOfOutputCompressedAccounts, inputCompressedAccountsWithMerkleContext) {
    if (numberOfOutputCompressedAccounts <= 0) {
        return [];
    }
    /// Default: use the 0th state tree of input state for all output accounts
    if (outputStateMerkleTrees === undefined) {
        if (inputCompressedAccountsWithMerkleContext.length === 0) {
            return new Array(numberOfOutputCompressedAccounts).fill(defaultTestStateTreeAccounts().merkleTree);
        }
        return new Array(numberOfOutputCompressedAccounts).fill(inputCompressedAccountsWithMerkleContext[0].merkleTree);
    /// Align the number of output state trees with the number of output
    /// accounts, and fill up with 0th output state tree
    } else {
        /// Into array
        const treesArray = toArray(outputStateMerkleTrees);
        if (treesArray.length >= numberOfOutputCompressedAccounts) {
            return treesArray.slice(0, numberOfOutputCompressedAccounts);
        } else {
            return treesArray.concat(new Array(numberOfOutputCompressedAccounts - treesArray.length).fill(treesArray[0]));
        }
    }
}
function toAccountMetas(remainingAccounts) {
    return remainingAccounts.map((account)=>({
            pubkey: account,
            isWritable: true,
            isSigner: false
        }));
}
// TODO: include owner and lamports in packing.
/**
 * Packs Compressed Accounts.
 *
 * Replaces PublicKey with index pointer to remaining accounts.
 *
 * @param inputCompressedAccounts           Ix input state to be consumed
 * @param inputStateRootIndices             The recent state root indices of the
 *                                          input state. The expiry is tied to
 *                                          the proof.
 * @param outputCompressedAccounts          Ix output state to be created
 * @param outputStateMerkleTrees            Optional output state trees to be
 *                                          inserted into the output state.
 *                                          Defaults to the 0th state tree of
 *                                          the input state. Gets padded to the
 *                                          length of outputCompressedAccounts.
 *
 * @param remainingAccounts                 Optional existing array of accounts
 *                                          to append to.
 **/ function packCompressedAccounts(inputCompressedAccounts, inputStateRootIndices, outputCompressedAccounts, outputStateMerkleTrees, remainingAccounts = []) {
    const _remainingAccounts = remainingAccounts.slice();
    const packedInputCompressedAccounts = [];
    const packedOutputCompressedAccounts = [];
    /// input
    inputCompressedAccounts.forEach((account, index)=>{
        const merkleTreePubkeyIndex = getIndexOrAdd(_remainingAccounts, account.merkleTree);
        const nullifierQueuePubkeyIndex = getIndexOrAdd(_remainingAccounts, account.nullifierQueue);
        packedInputCompressedAccounts.push({
            compressedAccount: {
                owner: account.owner,
                lamports: account.lamports,
                address: account.address,
                data: account.data
            },
            merkleContext: {
                merkleTreePubkeyIndex,
                nullifierQueuePubkeyIndex,
                leafIndex: account.leafIndex,
                queueIndex: null
            },
            rootIndex: inputStateRootIndices[index],
            readOnly: false
        });
    });
    /// output
    const paddedOutputStateMerkleTrees = padOutputStateMerkleTrees(outputStateMerkleTrees, outputCompressedAccounts.length, inputCompressedAccounts);
    outputCompressedAccounts.forEach((account, index)=>{
        const merkleTreePubkeyIndex = getIndexOrAdd(_remainingAccounts, paddedOutputStateMerkleTrees[index]);
        packedOutputCompressedAccounts.push({
            compressedAccount: {
                owner: account.owner,
                lamports: account.lamports,
                address: account.address,
                data: account.data
            },
            merkleTreeIndex: merkleTreePubkeyIndex
        });
    });
    return {
        packedInputCompressedAccounts,
        packedOutputCompressedAccounts,
        remainingAccounts: _remainingAccounts
    };
}
const validateSufficientBalance = (balance)=>{
    if (balance.lt(bn(0))) {
        throw new Error('Not enough balance for transfer');
    }
};
const validateSameOwner = (compressedAccounts)=>{
    if (compressedAccounts.length === 0) {
        throw new Error('No accounts provided for validation');
    }
    const zerothOwner = compressedAccounts[0].owner;
    if (!compressedAccounts.every((account)=>account.owner.equals(zerothOwner))) {
        throw new Error('All input accounts must have the same owner');
    }
};
function deriveAddressSeed(seeds, programId) {
    const combinedSeeds = [
        programId.toBytes(),
        ...seeds
    ];
    const hash = hashvToBn254FieldSizeBe(combinedSeeds);
    return hash;
}
/**
 * Derive an address for a compressed account from a seed and an address Merkle
 * tree public key.
 *
 * @param seed                     Seed to derive the address from
 * @param addressMerkleTreePubkey  Merkle tree public key. Defaults to
 *                                 defaultTestStateTreeAccounts().addressTree
 * @returns                        Derived address
 */ function deriveAddress(seed, addressMerkleTreePubkey = defaultTestStateTreeAccounts().addressTree) {
    if (seed.length != 32) {
        throw new Error('Seed length is not 32 bytes.');
    }
    const bytes = addressMerkleTreePubkey.toBytes();
    const combined = Buffer.from([
        ...bytes,
        ...seed
    ]);
    const hash = hashToBn254FieldSizeBe(combined);
    if (hash === null) {
        throw new Error('DeriveAddressError');
    }
    const buf = hash[0];
    return new web3_js.PublicKey(buf);
}
/**
 * Packs new address params for instruction data in TypeScript clients
 *
 * @param newAddressParams      New address params
 * @param remainingAccounts     Remaining accounts
 * @returns                     Packed new address params
 */ function packNewAddressParams(newAddressParams, remainingAccounts) {
    const _remainingAccounts = remainingAccounts.slice();
    const newAddressParamsPacked = newAddressParams.map((x)=>({
            seed: Array.from(x.seed),
            addressMerkleTreeRootIndex: x.addressMerkleTreeRootIndex,
            addressMerkleTreeAccountIndex: 0,
            addressQueueAccountIndex: 0
        }));
    newAddressParams.forEach((params, i)=>{
        newAddressParamsPacked[i].addressMerkleTreeAccountIndex = getIndexOrAdd(_remainingAccounts, params.addressMerkleTreePubkey);
    });
    newAddressParams.forEach((params, i)=>{
        newAddressParamsPacked[i].addressQueueAccountIndex = getIndexOrAdd(_remainingAccounts, params.addressQueuePubkey);
    });
    return {
        newAddressParamsPacked,
        remainingAccounts: _remainingAccounts
    };
}
//@ts-ignore
if (undefined) {
    //@ts-ignore
    const { it, expect, describe } = undefined;
    const programId = new web3_js.PublicKey('7yucc7fL3JGbyMwg4neUaenNSdySS39hbAk89Ao3t1Hz');
    describe('derive address seed', ()=>{
        it('should derive a valid address seed', ()=>{
            const seeds = [
                new TextEncoder().encode('foo'),
                new TextEncoder().encode('bar')
            ];
            expect(deriveAddressSeed(seeds, programId)).toStrictEqual(new Uint8Array([
                0,
                246,
                150,
                3,
                192,
                95,
                53,
                123,
                56,
                139,
                206,
                179,
                253,
                133,
                115,
                103,
                120,
                155,
                251,
                72,
                250,
                47,
                117,
                217,
                118,
                59,
                174,
                207,
                49,
                101,
                201,
                110
            ]));
        });
        it('should derive a valid address seed', ()=>{
            const seeds = [
                new TextEncoder().encode('ayy'),
                new TextEncoder().encode('lmao')
            ];
            expect(deriveAddressSeed(seeds, programId)).toStrictEqual(new Uint8Array([
                0,
                202,
                44,
                25,
                221,
                74,
                144,
                92,
                69,
                168,
                38,
                19,
                206,
                208,
                29,
                162,
                53,
                27,
                120,
                214,
                152,
                116,
                15,
                107,
                212,
                168,
                33,
                121,
                187,
                10,
                76,
                233
            ]));
        });
    });
    describe('deriveAddress function', ()=>{
        it('should derive a valid address from a seed and a merkle tree public key', async ()=>{
            const seeds = [
                new TextEncoder().encode('foo'),
                new TextEncoder().encode('bar')
            ];
            const seed = deriveAddressSeed(seeds, programId);
            const merkleTreePubkey = new web3_js.PublicKey('11111111111111111111111111111111');
            const derivedAddress = deriveAddress(seed, merkleTreePubkey);
            expect(derivedAddress).toBeInstanceOf(web3_js.PublicKey);
            expect(derivedAddress).toStrictEqual(new web3_js.PublicKey('139uhyyBtEh4e1CBDJ68ooK5nCeWoncZf9HPyAfRrukA'));
        });
        it('should derive a valid address from a seed and a merkle tree public key', async ()=>{
            const seeds = [
                new TextEncoder().encode('ayy'),
                new TextEncoder().encode('lmao')
            ];
            const seed = deriveAddressSeed(seeds, programId);
            const merkleTreePubkey = new web3_js.PublicKey('11111111111111111111111111111111');
            const derivedAddress = deriveAddress(seed, merkleTreePubkey);
            expect(derivedAddress).toBeInstanceOf(web3_js.PublicKey);
            expect(derivedAddress).toStrictEqual(new web3_js.PublicKey('12bhHm6PQjbNmEn3Yu1Gq9k7XwVn2rZpzYokmLwbFazN'));
        });
    });
    describe('packNewAddressParams function', ()=>{
        it('should pack new address params correctly', ()=>{
            const newAddressParams = [
                {
                    seed: new Uint8Array([
                        1,
                        2,
                        3,
                        4
                    ]),
                    addressMerkleTreeRootIndex: 0,
                    addressMerkleTreePubkey: new web3_js.PublicKey('11111111111111111111111111111111'),
                    addressQueuePubkey: new web3_js.PublicKey('11111111111111111111111111111112')
                }
            ];
            const remainingAccounts = [
                new web3_js.PublicKey('11111111111111111111111111111112'),
                new web3_js.PublicKey('11111111111111111111111111111111')
            ];
            const packedParams = packNewAddressParams(newAddressParams, remainingAccounts);
            expect(packedParams.newAddressParamsPacked[0].addressMerkleTreeAccountIndex).toBe(1);
            expect(packedParams.newAddressParamsPacked[0].addressQueueAccountIndex).toBe(0);
        });
    });
}
async function airdropSol({ connection, lamports, recipientPublicKey }) {
    const txHash = await connection.requestAirdrop(recipientPublicKey, lamports);
    await confirmTransaction(connection, txHash);
    return txHash;
}
async function confirmTransaction(connection, signature, confirmation = 'confirmed') {
    const latestBlockHash = await connection.getLatestBlockhash(confirmation);
    const strategy = {
        signature: signature.toString(),
        lastValidBlockHeight: latestBlockHash.lastValidBlockHeight,
        blockhash: latestBlockHash.blockhash
    };
    return await connection.confirmTransaction(strategy, confirmation);
}
const placeholderValidityProof = ()=>({
        a: Array.from({
            length: 32
        }, (_, i)=>i + 1),
        b: Array.from({
            length: 64
        }, (_, i)=>i + 1),
        c: Array.from({
            length: 32
        }, (_, i)=>i + 1)
    });
const checkValidityProofShape = (proof)=>{
    if (proof.a.length !== 32 || proof.b.length !== 64 || proof.c.length !== 32) {
        throw new Error('ValidityProof has invalid shape');
    }
};
function proofFromJsonStruct(json) {
    const proofAX = deserializeHexStringToBeBytes(json.ar[0]);
    const proofAY = deserializeHexStringToBeBytes(json.ar[1]);
    const proofA = new Uint8Array([
        ...proofAX,
        ...proofAY
    ]);
    const proofBX0 = deserializeHexStringToBeBytes(json.bs[0][0]);
    const proofBX1 = deserializeHexStringToBeBytes(json.bs[0][1]);
    const proofBY0 = deserializeHexStringToBeBytes(json.bs[1][0]);
    const proofBY1 = deserializeHexStringToBeBytes(json.bs[1][1]);
    const proofB = new Uint8Array([
        ...proofBX0,
        ...proofBX1,
        ...proofBY0,
        ...proofBY1
    ]);
    const proofCX = deserializeHexStringToBeBytes(json.krs[0]);
    const proofCY = deserializeHexStringToBeBytes(json.krs[1]);
    const proofC = new Uint8Array([
        ...proofCX,
        ...proofCY
    ]);
    const proofABC = {
        a: proofA,
        b: proofB,
        c: proofC
    };
    return proofABC;
}
// TODO: add unit test for negation
// TODO: test if LE BE issue. unit test
function negateAndCompressProof(proof) {
    const proofA = proof.a;
    const proofB = proof.b;
    const proofC = proof.c;
    const aXElement = proofA.slice(0, 32);
    const aYElement = new anchor.BN(proofA.slice(32, 64), 32, 'be');
    /// Negate
    const proofAIsPositive = yElementIsPositiveG1(aYElement) ? false : true;
    /// First byte of proofA is the bitmask
    aXElement[0] = addBitmaskToByte(aXElement[0], proofAIsPositive);
    const bXElement = proofB.slice(0, 64);
    const bYElement = proofB.slice(64, 128);
    const proofBIsPositive = yElementIsPositiveG2(new anchor.BN(bYElement.slice(0, 32), 32, 'be'), new anchor.BN(bYElement.slice(32, 64), 32, 'be'));
    bXElement[0] = addBitmaskToByte(bXElement[0], proofBIsPositive);
    const cXElement = proofC.slice(0, 32);
    const cYElement = proofC.slice(32, 64);
    const proofCIsPositive = yElementIsPositiveG1(new anchor.BN(cYElement, 32, 'be'));
    cXElement[0] = addBitmaskToByte(cXElement[0], proofCIsPositive);
    const compressedProof = {
        a: Array.from(aXElement),
        b: Array.from(bXElement),
        c: Array.from(cXElement)
    };
    return compressedProof;
}
function deserializeHexStringToBeBytes(hexStr) {
    // Using BN for simpler conversion from hex string to byte array
    const bn = new anchor.BN(hexStr.startsWith('0x') ? hexStr.substring(2) : hexStr, 'hex');
    return new Uint8Array(bn.toArray('be', 32));
}
function yElementIsPositiveG1(yElement) {
    return yElement.lte(FIELD_SIZE.sub(yElement));
}
function yElementIsPositiveG2(yElement1, yElement2) {
    const fieldMidpoint = FIELD_SIZE.div(new anchor.BN(2));
    // Compare the first component of the y coordinate
    if (yElement1.lt(fieldMidpoint)) {
        return true;
    } else if (yElement1.gt(fieldMidpoint)) {
        return false;
    }
    // If the first component is equal to the midpoint, compare the second component
    return yElement2.lt(fieldMidpoint);
}
// bitmask compatible with solana altbn128 compression syscall and arkworks' implementation
// https://github.com/arkworks-rs/algebra/blob/master/ff/src/fields/models/fp/mod.rs#L580
// https://github.com/arkworks-rs/algebra/blob/master/serialize/src/flags.rs#L18
// fn u8_bitmask(value: u8, inf: bool, neg: bool) -> u8 {
//     let mut mask = 0;
//     match self {
//         inf => mask |= 1 << 6,
//         neg => mask |= 1 << 7,
//         _ => (),
//     }
//     mask
// }
function addBitmaskToByte(byte, yIsPositive) {
    if (!yIsPositive) {
        return byte |= 1 << 7;
    } else {
        return byte;
    }
}
//@ts-ignore
if (undefined) {
    //@ts-ignore
    const { it, expect, describe } = undefined;
    // Unit test for addBitmaskToByte function
    describe('addBitmaskToByte', ()=>{
        it('should add a bitmask to the byte if yIsPositive is false', ()=>{
            const byte = 0b00000000;
            const yIsPositive = false;
            const result = addBitmaskToByte(byte, yIsPositive);
            expect(result).toBe(0b10000000); // 128 in binary, which is 1 << 7
        });
        it('should not modify the byte if yIsPositive is true', ()=>{
            const byte = 0b00000000;
            const yIsPositive = true;
            const result = addBitmaskToByte(byte, yIsPositive);
            expect(result).toBe(0b00000000);
        });
    });
    describe('test prover server', ()=>{
        const TEST_JSON = {
            ar: [
                '0x22bdaa3187d8fe294925a66fa0165a11bc9e07678fa2fc72402ebfd33d521c69',
                '0x2d18ff780b69898b4cdd8d7b6ac72d077799399f0f45e52665426456f3903584'
            ],
            bs: [
                [
                    '0x138cc0962e49f76a701d2871d2799892c9782940095eb0429e979f336d2e162d',
                    '0x2fe1bfbb15cbfb83d7e00ace23e45f890604003783eaf34affa35e0d6f4822bc'
                ],
                [
                    '0x1a89264f82cc6e8ef1c696bea0b5803c28c0ba6ab61366bcb71e73a4135cae8d',
                    '0xf778d857b3df01a4100265c9d014ce02d47425f0114685356165fa5ee3f3a26'
                ]
            ],
            krs: [
                '0x176b6ae9001f66832951e2d43a98a972667447bb1781f534b70cb010270dcdd3',
                '0xb748d5fac1686db28d94c02250af7eb4f28dfdabc8983305c45bcbc6e163eeb'
            ]
        };
        const COMPRESSED_PROOF_A = [
            34,
            189,
            170,
            49,
            135,
            216,
            254,
            41,
            73,
            37,
            166,
            111,
            160,
            22,
            90,
            17,
            188,
            158,
            7,
            103,
            143,
            162,
            252,
            114,
            64,
            46,
            191,
            211,
            61,
            82,
            28,
            105
        ];
        const COMPRESSED_PROOF_B = [
            147,
            140,
            192,
            150,
            46,
            73,
            247,
            106,
            112,
            29,
            40,
            113,
            210,
            121,
            152,
            146,
            201,
            120,
            41,
            64,
            9,
            94,
            176,
            66,
            158,
            151,
            159,
            51,
            109,
            46,
            22,
            45,
            47,
            225,
            191,
            187,
            21,
            203,
            251,
            131,
            215,
            224,
            10,
            206,
            35,
            228,
            95,
            137,
            6,
            4,
            0,
            55,
            131,
            234,
            243,
            74,
            255,
            163,
            94,
            13,
            111,
            72,
            34,
            188
        ];
        const COMPRESSED_PROOF_C = [
            23,
            107,
            106,
            233,
            0,
            31,
            102,
            131,
            41,
            81,
            226,
            212,
            58,
            152,
            169,
            114,
            102,
            116,
            71,
            187,
            23,
            129,
            245,
            52,
            183,
            12,
            176,
            16,
            39,
            13,
            205,
            211
        ];
        it('should execute a compressed token mint', async ()=>{
            const proof = proofFromJsonStruct(TEST_JSON);
            const compressedProof = negateAndCompressProof(proof);
            expect(compressedProof.a).toEqual(COMPRESSED_PROOF_A);
            expect(compressedProof.b).toEqual(COMPRESSED_PROOF_B);
            expect(compressedProof.c).toEqual(COMPRESSED_PROOF_C);
        });
    });
    describe('Validity Proof Functions', ()=>{
        describe('placeholderValidityProof', ()=>{
            it('should create a validity proof with correct shape', ()=>{
                const validityProof = placeholderValidityProof();
                expect(validityProof.a.length).toBe(32);
                expect(validityProof.b.length).toBe(64);
                expect(validityProof.c.length).toBe(32);
            });
        });
        describe('checkValidityProofShape', ()=>{
            it('should not throw an error for valid proof shape', ()=>{
                const validProof = {
                    a: Array.from(new Uint8Array(32)),
                    b: Array.from(new Uint8Array(64)),
                    c: Array.from(new Uint8Array(32))
                };
                expect(()=>checkValidityProofShape(validProof)).not.toThrow();
            });
            it('should throw an error for an invalid proof', ()=>{
                const invalidProof = {
                    a: Array.from(new Uint8Array(31)),
                    b: Array.from(new Uint8Array(64)),
                    c: Array.from(new Uint8Array(32))
                };
                expect(()=>checkValidityProofShape(invalidProof)).toThrow('ValidityProof has invalid shape');
            });
        });
    });
}
/** pipe function */ function pipe(initialFunction, ...functions) {
    return (initialValue)=>functions.reduce((currentValue, currentFunction)=>currentFunction(currentValue), initialFunction(initialValue));
}
//@ts-ignore
if (undefined) {
    //@ts-ignore
    const { it, expect, describe } = undefined;
    describe('pipe', ()=>{
        it('should return the result of applying all fns to the initial value', ()=>{
            const addOne = (x)=>x + 1;
            const multiplyByTwo = (x)=>x * 2;
            const subtractThree = (x)=>x - 3;
            const addOneMultiplyByTwoSubtractThree = pipe(addOne, multiplyByTwo, subtractThree);
            expect(addOneMultiplyByTwoSubtractThree(5)).toBe(9);
        });
    });
}
/**
 * Builds a versioned Transaction from instructions.
 *
 * @param instructions          instructions to include
 * @param payerPublicKey        fee payer public key
 * @param blockhash             blockhash to use
 * @param lookupTableAccounts   lookup table accounts to include
 *
 * @return VersionedTransaction
 */ function buildTx(instructions, payerPublicKey, blockhash, lookupTableAccounts) {
    const messageV0 = new web3_js.TransactionMessage({
        payerKey: payerPublicKey,
        recentBlockhash: blockhash,
        instructions
    }).compileToV0Message(lookupTableAccounts);
    return new web3_js.VersionedTransaction(messageV0);
}
/**
 * Sends a versioned transaction and confirms it.
 *
 * @param rpc               connection to use
 * @param tx                versioned transaction to send
 * @param confirmOptions    confirmation options
 * @param blockHashCtx      blockhash context for confirmation
 *
 * @return TransactionSignature
 */ async function sendAndConfirmTx(rpc, tx, confirmOptions, blockHashCtx) {
    const txId = await rpc.sendTransaction(tx, confirmOptions);
    if (!blockHashCtx) blockHashCtx = await rpc.getLatestBlockhash();
    const transactionConfirmationStrategy0 = {
        signature: txId,
        blockhash: blockHashCtx.blockhash,
        lastValidBlockHeight: blockHashCtx.lastValidBlockHeight
    };
    const ctxAndRes = await rpc.confirmTransaction(transactionConfirmationStrategy0, (confirmOptions === null || confirmOptions === void 0 ? void 0 : confirmOptions.commitment) || rpc.commitment || 'confirmed');
    const slot = ctxAndRes.context.slot;
    await rpc.confirmTransactionIndexed(slot);
    return txId;
}
/**
 * Confirms a transaction with a given txId.
 *
 * @param rpc               connection to use
 * @param txId              transaction signature to confirm
 * @param confirmOptions    confirmation options
 * @param blockHashCtx      blockhash context for confirmation
 * @return SignatureResult
 */ async function confirmTx(rpc, txId, confirmOptions, blockHashCtx) {
    if (!blockHashCtx) blockHashCtx = await rpc.getLatestBlockhash();
    const transactionConfirmationStrategy = {
        signature: txId,
        blockhash: blockHashCtx.blockhash,
        lastValidBlockHeight: blockHashCtx.lastValidBlockHeight
    };
    const res = await rpc.confirmTransaction(transactionConfirmationStrategy, (confirmOptions === null || confirmOptions === void 0 ? void 0 : confirmOptions.commitment) || rpc.commitment || 'confirmed');
    const slot = res.context.slot;
    await rpc.confirmTransactionIndexed(slot);
    return res;
}
/**
 * Builds a versioned Transaction from instructions and signs it.
 *
 * @param instructions          instructions to include in the transaction
 * @param payer                 payer of the transaction
 * @param blockhash             recent blockhash to use in the transaction
 * @param additionalSigners     non-feepayer signers to include in the
 *                              transaction
 * @param lookupTableAccounts   lookup table accounts to include in the
 *                              transaction
 */ function buildAndSignTx(instructions, payer, blockhash, additionalSigners = [], lookupTableAccounts) {
    if (additionalSigners.includes(payer)) throw new Error('payer must not be in additionalSigners');
    const allSigners = [
        payer,
        ...additionalSigners
    ];
    const tx = buildTx(instructions, payer.publicKey, blockhash, lookupTableAccounts);
    tx.sign(allSigners);
    return tx;
}
// zzz
function sleep(ms) {
    return new Promise((resolve)=>setTimeout(resolve, ms));
}
let c = 1;
const ALICE = getTestKeypair(255);
const BOB = getTestKeypair(254);
const CHARLIE = getTestKeypair(253);
const DAVE = getTestKeypair(252);
/**
 * Create a new account and airdrop lamports to it
 *
 * @param rpc       connection to use
 * @param lamports  amount of lamports to airdrop
 * @param counter   counter to use for generating the keypair.
 *                  If undefined or >255, generates random keypair.
 */ async function newAccountWithLamports(rpc, lamports = 1000000000, counter = undefined) {
    /// get random keypair
    if (counter === undefined || counter > 255) {
        counter = 256;
    }
    const account = getTestKeypair(counter);
    const sig = await rpc.requestAirdrop(account.publicKey, lamports);
    await confirmTx(rpc, sig);
    return account;
}
function getConnection() {
    const url = 'http://127.0.0.1:8899';
    const connection = new web3_js.Connection(url, 'confirmed');
    return connection;
}
/**
 * For use in tests.
 * Generate a unique keypair by passing in a counter <255. If no counter
 * is supplied, it uses and increments a global counter.
 * if counter > 255, generates random keypair
 */ function getTestKeypair(counter = undefined) {
    if (!counter) {
        counter = c;
        c++;
    }
    if (counter > 255) {
        return web3_js.Keypair.generate();
    }
    const seed = new Uint8Array(32);
    seed[31] = counter; // le
    return web3_js.Keypair.fromSeed(seed);
}
//@ts-ignore
if (undefined) {
    //@ts-ignore
    const { describe, it, expect } = undefined;
    describe('getTestKeypair', ()=>{
        it('should generate a keypair with a specific counter', ()=>{
            const keypair = getTestKeypair(10);
            const keypair2 = getTestKeypair(10);
            expect(keypair).toEqual(keypair2);
            expect(keypair).toBeInstanceOf(web3_js.Keypair);
            expect(keypair.publicKey).toBeDefined();
            expect(keypair.secretKey).toBeDefined();
        });
        it('should generate random keypair if counter is greater than 255', ()=>{
            const testFn = ()=>getTestKeypair(256);
            const kp1 = testFn();
            const kp2 = testFn();
            expect(kp1).not.toEqual(kp2);
        });
        it('should increment the global counter if no counter is provided', ()=>{
            const initialKeypair = getTestKeypair();
            const nextKeypair = getTestKeypair();
            const nextNextKeypair = getTestKeypair();
            const nextNextNextKeypair = getTestKeypair(3);
            expect(initialKeypair).not.toEqual(nextKeypair);
            expect(nextKeypair).not.toEqual(nextNextKeypair);
            expect(nextNextKeypair).toEqual(nextNextNextKeypair);
        });
    });
}
/**
 * @param targetLamports - Target priority fee in lamports
 * @param computeUnits - Expected compute units used by the transaction
 * @returns microLamports per compute unit (use in
 * `ComputeBudgetProgram.setComputeUnitPrice`)
 */ function calculateComputeUnitPrice(targetLamports, computeUnits) {
    return Math.ceil(targetLamports * 1000000 / computeUnits);
}
const sumUpLamports = (accounts)=>{
    return accounts.reduce((acc, account)=>acc.add(bn(account.lamports)), bn(0));
};
const SOL_POOL_PDA_SEED = require$$0.Buffer.from('sol_pool_pda');
class LightSystemProgram {
    /**
     * @internal
     */ constructor(){}
    static get program() {
        if (!this._program) {
            this.initializeProgram();
        }
        return this._program;
    }
    /**
     * @internal
     * Cwct1kQLwJm8Z3HetLu8m4SXkhD6FZ5fXbJQCxTxPnGY
     *
     */ static deriveCompressedSolPda() {
        const seeds = [
            SOL_POOL_PDA_SEED
        ];
        const [address, _] = web3_js.PublicKey.findProgramAddressSync(seeds, this.programId);
        return address;
    }
    /**
     * Initializes the program statically if not already initialized.
     */ static initializeProgram() {
        if (!this._program) {
            const mockKeypair = web3_js.Keypair.generate();
            const mockConnection = new web3_js.Connection('http://127.0.0.1:8899', 'confirmed');
            const mockProvider = new anchor.AnchorProvider(mockConnection, useWallet(mockKeypair), {
                commitment: 'confirmed',
                preflightCommitment: 'confirmed'
            });
            anchor.setProvider(mockProvider);
            this._program = new anchor.Program(IDL$3, this.programId, mockProvider);
        }
    }
    static createTransferOutputState(inputCompressedAccounts, toAddress, lamports) {
        lamports = bn(lamports);
        const inputLamports = sumUpLamports(inputCompressedAccounts);
        const changeLamports = inputLamports.sub(lamports);
        validateSufficientBalance(changeLamports);
        if (changeLamports.eq(bn(0))) {
            return [
                createCompressedAccount(toAddress, lamports)
            ];
        }
        validateSameOwner(inputCompressedAccounts);
        const outputCompressedAccounts = [
            createCompressedAccount(inputCompressedAccounts[0].owner, changeLamports),
            createCompressedAccount(toAddress, lamports)
        ];
        return outputCompressedAccounts;
    }
    static createDecompressOutputState(inputCompressedAccounts, lamports) {
        lamports = bn(lamports);
        const inputLamports = sumUpLamports(inputCompressedAccounts);
        const changeLamports = inputLamports.sub(lamports);
        validateSufficientBalance(changeLamports);
        /// lamports gets decompressed
        if (changeLamports.eq(bn(0))) {
            return [];
        }
        validateSameOwner(inputCompressedAccounts);
        const outputCompressedAccounts = [
            createCompressedAccount(inputCompressedAccounts[0].owner, changeLamports)
        ];
        return outputCompressedAccounts;
    }
    /**
     * No data by default
     */ static createNewAddressOutputState(address, owner, lamports, inputCompressedAccounts) {
        lamports = bn(lamports !== null && lamports !== void 0 ? lamports : 0);
        const inputLamports = sumUpLamports(inputCompressedAccounts !== null && inputCompressedAccounts !== void 0 ? inputCompressedAccounts : []);
        const changeLamports = inputLamports.sub(lamports);
        validateSufficientBalance(changeLamports);
        if (changeLamports.eq(bn(0)) || !inputCompressedAccounts) {
            return [
                createCompressedAccount(owner, lamports, undefined, address)
            ];
        }
        validateSameOwner(inputCompressedAccounts);
        const outputCompressedAccounts = [
            createCompressedAccount(inputCompressedAccounts[0].owner, changeLamports),
            createCompressedAccount(owner, lamports, undefined, address)
        ];
        return outputCompressedAccounts;
    }
    /**
     * Creates instruction to create compressed account with PDA.
     * Cannot write data.
     *
     * TODO: support transfer of lamports to the new account.
     */ static async createAccount({ payer, newAddressParams, newAddress, recentValidityProof, outputStateTree, inputCompressedAccounts, inputStateRootIndices, lamports }) {
        const outputCompressedAccounts = this.createNewAddressOutputState(newAddress, payer, lamports, inputCompressedAccounts);
        /// Pack accounts
        const { packedInputCompressedAccounts, packedOutputCompressedAccounts, remainingAccounts: _remainingAccounts } = packCompressedAccounts(inputCompressedAccounts !== null && inputCompressedAccounts !== void 0 ? inputCompressedAccounts : [], inputStateRootIndices !== null && inputStateRootIndices !== void 0 ? inputStateRootIndices : [], outputCompressedAccounts, outputStateTree);
        const { newAddressParamsPacked, remainingAccounts } = packNewAddressParams([
            newAddressParams
        ], _remainingAccounts);
        const rawData = {
            proof: recentValidityProof,
            inputCompressedAccountsWithMerkleContext: packedInputCompressedAccounts,
            outputCompressedAccounts: packedOutputCompressedAccounts,
            relayFee: null,
            newAddressParams: newAddressParamsPacked,
            compressOrDecompressLamports: null,
            isCompress: false
        };
        /// Encode instruction data
        const ixData = this.program.coder.types.encode('InstructionDataInvoke', rawData);
        /// Build anchor instruction
        const instruction = await this.program.methods.invoke(ixData).accounts(Object.assign(Object.assign({}, defaultStaticAccountsStruct()), {
            feePayer: payer,
            authority: payer,
            solPoolPda: null,
            decompressionRecipient: null,
            systemProgram: web3_js.SystemProgram.programId
        })).remainingAccounts(toAccountMetas(remainingAccounts)).instruction();
        return instruction;
    }
    /**
     * Creates a transaction instruction that transfers compressed lamports from
     * one owner to another.
     */ static async transfer({ payer, inputCompressedAccounts, toAddress, lamports, recentInputStateRootIndices, recentValidityProof, outputStateTrees }) {
        /// Create output state
        const outputCompressedAccounts = this.createTransferOutputState(inputCompressedAccounts, toAddress, lamports);
        /// Pack accounts
        const { packedInputCompressedAccounts, packedOutputCompressedAccounts, remainingAccounts } = packCompressedAccounts(inputCompressedAccounts, recentInputStateRootIndices, outputCompressedAccounts, outputStateTrees);
        /// Encode instruction data
        const data = this.program.coder.types.encode('InstructionDataInvoke', {
            proof: recentValidityProof,
            inputCompressedAccountsWithMerkleContext: packedInputCompressedAccounts,
            outputCompressedAccounts: packedOutputCompressedAccounts,
            relayFee: null,
            /// TODO: here and on-chain: option<newAddressInputs> or similar.
            newAddressParams: [],
            compressOrDecompressLamports: null,
            isCompress: false
        });
        /// Build anchor instruction
        const instruction = await this.program.methods.invoke(data).accounts(Object.assign(Object.assign({}, defaultStaticAccountsStruct()), {
            feePayer: payer,
            authority: payer,
            solPoolPda: null,
            decompressionRecipient: null,
            systemProgram: web3_js.SystemProgram.programId
        })).remainingAccounts(toAccountMetas(remainingAccounts)).instruction();
        return instruction;
    }
    /**
     * Creates a transaction instruction that transfers compressed lamports from
     * one owner to another.
     */ // TODO: add support for non-fee-payer owner
    static async compress({ payer, toAddress, lamports, outputStateTree }) {
        /// Create output state
        lamports = bn(lamports);
        const outputCompressedAccount = createCompressedAccount(toAddress, lamports);
        /// Pack accounts
        const { packedInputCompressedAccounts, packedOutputCompressedAccounts, remainingAccounts } = packCompressedAccounts([], [], [
            outputCompressedAccount
        ], outputStateTree);
        /// Encode instruction data
        const rawInputs = {
            proof: null,
            inputCompressedAccountsWithMerkleContext: packedInputCompressedAccounts,
            outputCompressedAccounts: packedOutputCompressedAccounts,
            relayFee: null,
            /// TODO: here and on-chain: option<newAddressInputs> or similar.
            newAddressParams: [],
            compressOrDecompressLamports: lamports,
            isCompress: true
        };
        const data = this.program.coder.types.encode('InstructionDataInvoke', rawInputs);
        /// Build anchor instruction
        const instruction = await this.program.methods.invoke(data).accounts(Object.assign(Object.assign({}, defaultStaticAccountsStruct()), {
            feePayer: payer,
            authority: payer,
            solPoolPda: this.deriveCompressedSolPda(),
            decompressionRecipient: null,
            systemProgram: web3_js.SystemProgram.programId
        })).remainingAccounts(toAccountMetas(remainingAccounts)).instruction();
        return instruction;
    }
    /**
     * Creates a transaction instruction that transfers compressed lamports from
     * one owner to another.
     */ static async decompress({ payer, inputCompressedAccounts, toAddress, lamports, recentInputStateRootIndices, recentValidityProof, outputStateTree }) {
        /// Create output state
        lamports = bn(lamports);
        const outputCompressedAccounts = this.createDecompressOutputState(inputCompressedAccounts, lamports);
        /// Pack accounts
        const { packedInputCompressedAccounts, packedOutputCompressedAccounts, remainingAccounts } = packCompressedAccounts(inputCompressedAccounts, recentInputStateRootIndices, outputCompressedAccounts, outputStateTree);
        /// Encode instruction data
        const data = this.program.coder.types.encode('InstructionDataInvoke', {
            proof: recentValidityProof,
            inputCompressedAccountsWithMerkleContext: packedInputCompressedAccounts,
            outputCompressedAccounts: packedOutputCompressedAccounts,
            relayFee: null,
            /// TODO: here and on-chain: option<newAddressInputs> or similar.
            newAddressParams: [],
            compressOrDecompressLamports: lamports,
            isCompress: false
        });
        /// Build anchor instruction
        const instruction = await this.program.methods.invoke(data).accounts(Object.assign(Object.assign({}, defaultStaticAccountsStruct()), {
            feePayer: payer,
            authority: payer,
            solPoolPda: this.deriveCompressedSolPda(),
            decompressionRecipient: toAddress,
            systemProgram: web3_js.SystemProgram.programId
        })).remainingAccounts(toAccountMetas(remainingAccounts)).instruction();
        return instruction;
    }
}
/**
 * Public key that identifies the CompressedPda program
 */ LightSystemProgram.programId = new web3_js.PublicKey(// TODO: can add check to ensure its consistent with the idl
'SySTEM1eSU2p4BGQfQpimFEWWSC1XDFeun3Nqzz3rT7');
LightSystemProgram._program = null;
/**
 * Selects the minimal number of compressed SOL accounts for a transfer.
 *
 * 1. Sorts the accounts by amount in descending order
 * 2. Accumulates the amount until it is greater than or equal to the transfer
 *    amount
 */ function selectMinCompressedSolAccountsForTransfer(accounts, transferLamports) {
    let accumulatedLamports = bn(0);
    transferLamports = bn(transferLamports);
    const selectedAccounts = [];
    accounts.sort((a, b)=>b.lamports.cmp(a.lamports));
    for (const account of accounts){
        if (accumulatedLamports.gte(bn(transferLamports))) break;
        accumulatedLamports = accumulatedLamports.add(account.lamports);
        selectedAccounts.push(account);
    }
    if (accumulatedLamports.lt(bn(transferLamports))) {
        throw new Error(`Not enough balance for transfer. Required: ${transferLamports.toString()}, available: ${accumulatedLamports.toString()}`);
    }
    return [
        selectedAccounts,
        accumulatedLamports
    ];
}
/**
 * Compress lamports to a solana address
 *
 * @param rpc             RPC to use
 * @param payer           Payer of the transaction and initialization fees
 * @param lamports        Amount of lamports to compress
 * @param toAddress       Address of the recipient compressed account
 * @param outputStateTree Optional output state tree. Defaults to a current shared state tree.
 * @param confirmOptions  Options for confirming the transaction
 *
 * @return Transaction signature
 */ /// TODO: add multisig support
/// TODO: add support for payer != owner
async function compress(rpc, payer, lamports, toAddress, outputStateTree, confirmOptions) {
    const { blockhash } = await rpc.getLatestBlockhash();
    const ix = await LightSystemProgram.compress({
        payer: payer.publicKey,
        toAddress,
        lamports,
        outputStateTree
    });
    const tx = buildAndSignTx([
        web3_js.ComputeBudgetProgram.setComputeUnitLimit({
            units: 1000000
        }),
        ix
    ], payer, blockhash, []);
    const txId = await sendAndConfirmTx(rpc, tx, confirmOptions);
    return txId;
}
/**
 * Create compressed account with address
 *
 * @param rpc               RPC to use
 * @param payer             Payer of the transaction and initialization fees
 * @param seeds             Seeds to derive the new account address
 * @param programId         Owner of the new account
 * @param addressTree       Optional address tree. Defaults to a current shared
 *                          address tree.
 * @param addressQueue      Optional address queue. Defaults to a current shared
 *                          address queue.
 * @param outputStateTree   Optional output state tree. Defaults to a current
 *                          shared state tree.
 * @param confirmOptions    Options for confirming the transaction
 *
 * @return                  Transaction signature
 */ async function createAccount(rpc, payer, seeds, programId, addressTree, addressQueue, outputStateTree, confirmOptions) {
    const { blockhash } = await rpc.getLatestBlockhash();
    addressTree = addressTree !== null && addressTree !== void 0 ? addressTree : defaultTestStateTreeAccounts().addressTree;
    addressQueue = addressQueue !== null && addressQueue !== void 0 ? addressQueue : defaultTestStateTreeAccounts().addressQueue;
    const seed = deriveAddressSeed(seeds, programId);
    const address = deriveAddress(seed, addressTree);
    const proof = await rpc.getValidityProofV0(undefined, [
        {
            address: bn(address.toBytes()),
            tree: addressTree,
            queue: addressQueue
        }
    ]);
    const params = {
        seed: seed,
        addressMerkleTreeRootIndex: proof.rootIndices[0],
        addressMerkleTreePubkey: proof.merkleTrees[0],
        addressQueuePubkey: proof.nullifierQueues[0]
    };
    const ix = await LightSystemProgram.createAccount({
        payer: payer.publicKey,
        newAddressParams: params,
        newAddress: Array.from(address.toBytes()),
        recentValidityProof: proof.compressedProof,
        programId,
        outputStateTree
    });
    const tx = buildAndSignTx([
        web3_js.ComputeBudgetProgram.setComputeUnitLimit({
            units: 1000000
        }),
        ix
    ], payer, blockhash, []);
    const txId = await sendAndConfirmTx(rpc, tx, confirmOptions);
    return txId;
}
/**
 * Create compressed account with address and lamports
 *
 * @param rpc               RPC to use
 * @param payer             Payer of the transaction and initialization fees
 * @param seeds             Seeds to derive the new account address
 * @param lamports          Number of compressed lamports to initialize the
 *                          account with
 * @param programId         Owner of the new account
 * @param addressTree       Optional address tree. Defaults to a current shared
 *                          address tree.
 * @param addressQueue      Optional address queue. Defaults to a current shared
 *                          address queue.
 * @param outputStateTree   Optional output state tree. Defaults to a current
 *                          shared state tree.
 * @param confirmOptions    Options for confirming the transaction
 *
 * @return                  Transaction signature
 */ // TODO: add support for payer != user owner
async function createAccountWithLamports(rpc, payer, seeds, lamports, programId, addressTree, addressQueue, outputStateTree, confirmOptions) {
    lamports = bn(lamports);
    const compressedAccounts = await rpc.getCompressedAccountsByOwner(payer.publicKey);
    const [inputAccounts] = selectMinCompressedSolAccountsForTransfer(compressedAccounts.items, lamports);
    const { blockhash } = await rpc.getLatestBlockhash();
    addressTree = addressTree !== null && addressTree !== void 0 ? addressTree : defaultTestStateTreeAccounts().addressTree;
    addressQueue = addressQueue !== null && addressQueue !== void 0 ? addressQueue : defaultTestStateTreeAccounts().addressQueue;
    const seed = deriveAddressSeed(seeds, programId);
    const address = deriveAddress(seed, addressTree);
    const proof = await rpc.getValidityProof(inputAccounts.map((account)=>bn(account.hash)), [
        bn(address.toBytes())
    ]);
    /// TODO(crank): Adapt before supporting addresses in rpc / cranked address trees.
    /// Currently expects address roots to be consistent with one another and
    /// static. See test-rpc.ts for more details.
    const params = {
        seed: seed,
        addressMerkleTreeRootIndex: proof.rootIndices[proof.rootIndices.length - 1],
        addressMerkleTreePubkey: proof.merkleTrees[proof.merkleTrees.length - 1],
        addressQueuePubkey: proof.nullifierQueues[proof.nullifierQueues.length - 1]
    };
    const ix = await LightSystemProgram.createAccount({
        payer: payer.publicKey,
        newAddressParams: params,
        newAddress: Array.from(address.toBytes()),
        recentValidityProof: proof.compressedProof,
        inputCompressedAccounts: inputAccounts,
        inputStateRootIndices: proof.rootIndices,
        programId,
        outputStateTree
    });
    const tx = buildAndSignTx([
        web3_js.ComputeBudgetProgram.setComputeUnitLimit({
            units: 1000000
        }),
        ix
    ], payer, blockhash, []);
    const txId = await sendAndConfirmTx(rpc, tx, confirmOptions);
    return txId;
}
/**
 * Decompress lamports into a solana account
 *
 * @param rpc             RPC to use
 * @param payer           Payer of the transaction and initialization fees
 * @param lamports        Amount of lamports to compress
 * @param toAddress       Address of the recipient compressed account
 * @param outputStateTree Optional output state tree. Defaults to a current shared state tree.
 * @param confirmOptions  Options for confirming the transaction
 *
 * @return Transaction signature
 */ /// TODO: add multisig support
/// TODO: add support for payer != owner
async function decompress(rpc, payer, lamports, recipient, outputStateTree, confirmOptions) {
    /// TODO: use dynamic state tree and nullifier queue
    const userCompressedAccountsWithMerkleContext = (await rpc.getCompressedAccountsByOwner(payer.publicKey)).items;
    lamports = bn(lamports);
    const inputLamports = sumUpLamports(userCompressedAccountsWithMerkleContext);
    if (lamports.gt(inputLamports)) {
        throw new Error(`Not enough compressed lamports. Expected ${lamports}, got ${inputLamports}`);
    }
    const proof = await rpc.getValidityProof(userCompressedAccountsWithMerkleContext.map((x)=>bn(x.hash)));
    const { blockhash } = await rpc.getLatestBlockhash();
    const ix = await LightSystemProgram.decompress({
        payer: payer.publicKey,
        toAddress: recipient,
        outputStateTree: outputStateTree,
        inputCompressedAccounts: userCompressedAccountsWithMerkleContext,
        recentValidityProof: proof.compressedProof,
        recentInputStateRootIndices: proof.rootIndices,
        lamports
    });
    const tx = buildAndSignTx([
        web3_js.ComputeBudgetProgram.setComputeUnitLimit({
            units: 1000000
        }),
        ix
    ], payer, blockhash, []);
    const txId = await sendAndConfirmTx(rpc, tx, confirmOptions);
    return txId;
}
/** @internal remove signer from signers if part of signers */ function dedupeSigner(signer, signers) {
    if (signers.includes(signer)) {
        return signers.filter((s)=>s.publicKey.toString() !== signer.publicKey.toString());
    }
    return signers;
}
/**
 * Transfer compressed lamports from one owner to another
 *
 * @param rpc            Rpc to use
 * @param payer          Payer of transaction fees
 * @param lamports       Number of lamports to transfer
 * @param owner          Owner of the compressed lamports
 * @param toAddress      Destination address of the recipient
 * @param merkleTree     State tree account that the compressed lamports should be
 *                       inserted into. Defaults to the default state tree account.
 * @param confirmOptions Options for confirming the transaction
 * @param config         Configuration for fetching compressed accounts
 *
 *
 * @return Signature of the confirmed transaction
 */ async function transfer(rpc, payer, lamports, owner, toAddress, /// TODO: allow multiple
merkleTree, confirmOptions) {
    var _a;
    let accumulatedLamports = bn(0);
    const compressedAccounts = [];
    let cursor;
    const batchSize = 1000; // Maximum allowed by the API
    lamports = bn(lamports);
    while(accumulatedLamports.lt(lamports)){
        const batchConfig = {
            filters: undefined,
            dataSlice: undefined,
            cursor,
            limit: new anchor.BN(batchSize)
        };
        const batch = await rpc.getCompressedAccountsByOwner(owner.publicKey, batchConfig);
        for (const account of batch.items){
            if (account.lamports.gt(new anchor.BN(0))) {
                compressedAccounts.push(account);
                accumulatedLamports = accumulatedLamports.add(account.lamports);
            }
        }
        cursor = (_a = batch.cursor) !== null && _a !== void 0 ? _a : undefined;
        if (batch.items.length < batchSize || accumulatedLamports.gte(lamports)) break;
    }
    if (accumulatedLamports.lt(lamports)) {
        throw new Error(`Not enough balance for transfer. Required: ${lamports.toString()}, available: ${accumulatedLamports.toString()}`);
    }
    const [inputAccounts] = selectMinCompressedSolAccountsForTransfer(compressedAccounts, lamports);
    const proof = await rpc.getValidityProof(inputAccounts.map((account)=>bn(account.hash)));
    const ix = await LightSystemProgram.transfer({
        payer: payer.publicKey,
        inputCompressedAccounts: inputAccounts,
        toAddress,
        lamports,
        recentInputStateRootIndices: proof.rootIndices,
        recentValidityProof: proof.compressedProof,
        outputStateTrees: merkleTree
    });
    const { blockhash } = await rpc.getLatestBlockhash();
    const signedTx = buildAndSignTx([
        web3_js.ComputeBudgetProgram.setComputeUnitLimit({
            units: 1000000
        }),
        ix
    ], payer, blockhash);
    const txId = await sendAndConfirmTx(rpc, signedTx, confirmOptions);
    return txId;
}
const IDL$2 = {
    version: '1.2.0',
    name: 'account_compression',
    constants: [
        {
            name: 'CPI_AUTHORITY_PDA_SEED',
            type: 'bytes',
            value: '[99, 112, 105, 95, 97, 117, 116, 104, 111, 114, 105, 116, 121]'
        },
        {
            name: 'GROUP_AUTHORITY_SEED',
            type: 'bytes',
            value: '[103, 114, 111, 117, 112, 95, 97, 117, 116, 104, 111, 114, 105, 116, 121]'
        },
        {
            name: 'STATE_MERKLE_TREE_HEIGHT',
            type: 'u64',
            value: '26'
        },
        {
            name: 'STATE_MERKLE_TREE_CHANGELOG',
            type: 'u64',
            value: '1400'
        },
        {
            name: 'STATE_MERKLE_TREE_ROOTS',
            type: 'u64',
            value: '2400'
        },
        {
            name: 'STATE_MERKLE_TREE_CANOPY_DEPTH',
            type: 'u64',
            value: '10'
        },
        {
            name: 'STATE_NULLIFIER_QUEUE_VALUES',
            type: 'u16',
            value: '28_807'
        },
        {
            name: 'STATE_NULLIFIER_QUEUE_SEQUENCE_THRESHOLD',
            type: 'u64',
            value: '2400'
        },
        {
            name: 'ADDRESS_MERKLE_TREE_HEIGHT',
            type: 'u64',
            value: '26'
        },
        {
            name: 'ADDRESS_MERKLE_TREE_CHANGELOG',
            type: 'u64',
            value: '1400'
        },
        {
            name: 'ADDRESS_MERKLE_TREE_ROOTS',
            type: 'u64',
            value: '2400'
        },
        {
            name: 'ADDRESS_MERKLE_TREE_CANOPY_DEPTH',
            type: 'u64',
            value: '10'
        },
        {
            name: 'ADDRESS_MERKLE_TREE_INDEXED_CHANGELOG',
            type: 'u64',
            value: '1400'
        },
        {
            name: 'ADDRESS_QUEUE_VALUES',
            type: 'u16',
            value: '28_807'
        },
        {
            name: 'ADDRESS_QUEUE_SEQUENCE_THRESHOLD',
            type: 'u64',
            value: '2400'
        },
        {
            name: 'NOOP_PUBKEY',
            type: {
                array: [
                    'u8',
                    32
                ]
            },
            value: '[11 , 188 , 15 , 192 , 187 , 71 , 202 , 47 , 116 , 196 , 17 , 46 , 148 , 171 , 19 , 207 , 163 , 198 , 52 , 229 , 220 , 23 , 234 , 203 , 3 , 205 , 26 , 35 , 205 , 126 , 120 , 124 ,]'
        }
    ],
    instructions: [
        {
            name: 'initializeAddressMerkleTreeAndQueue',
            accounts: [
                {
                    name: 'authority',
                    isMut: true,
                    isSigner: true
                },
                {
                    name: 'merkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'queue',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                }
            ],
            args: [
                {
                    name: 'index',
                    type: 'u64'
                },
                {
                    name: 'programOwner',
                    type: {
                        option: 'publicKey'
                    }
                },
                {
                    name: 'forester',
                    type: {
                        option: 'publicKey'
                    }
                },
                {
                    name: 'addressMerkleTreeConfig',
                    type: {
                        defined: 'AddressMerkleTreeConfig'
                    }
                },
                {
                    name: 'addressQueueConfig',
                    type: {
                        defined: 'AddressQueueConfig'
                    }
                }
            ]
        },
        {
            name: 'insertAddresses',
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'Fee payer pays rollover fee.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'addresses',
                    type: {
                        vec: {
                            array: [
                                'u8',
                                32
                            ]
                        }
                    }
                }
            ]
        },
        {
            name: 'updateAddressMerkleTree',
            docs: [
                'Updates the address Merkle tree with a new address.'
            ],
            accounts: [
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'queue',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'merkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'logWrapper',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'changelogIndex',
                    type: 'u16'
                },
                {
                    name: 'indexedChangelogIndex',
                    type: 'u16'
                },
                {
                    name: 'value',
                    type: 'u16'
                },
                {
                    name: 'lowAddressIndex',
                    type: 'u64'
                },
                {
                    name: 'lowAddressValue',
                    type: {
                        array: [
                            'u8',
                            32
                        ]
                    }
                },
                {
                    name: 'lowAddressNextIndex',
                    type: 'u64'
                },
                {
                    name: 'lowAddressNextValue',
                    type: {
                        array: [
                            'u8',
                            32
                        ]
                    }
                },
                {
                    name: 'lowAddressProof',
                    type: {
                        array: [
                            {
                                array: [
                                    'u8',
                                    32
                                ]
                            },
                            16
                        ]
                    }
                }
            ]
        },
        {
            name: 'rolloverAddressMerkleTreeAndQueue',
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'Signer used to receive rollover accounts rentexemption reimbursement.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'newAddressMerkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'newQueue',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'oldAddressMerkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'oldQueue',
                    isMut: true,
                    isSigner: false
                }
            ],
            args: []
        },
        {
            name: 'initializeGroupAuthority',
            docs: [
                'initialize group (a group can be used to give multiple programs access',
                'to the same Merkle trees by registering the programs to the group)'
            ],
            accounts: [
                {
                    name: 'authority',
                    isMut: true,
                    isSigner: true
                },
                {
                    name: 'seed',
                    isMut: false,
                    isSigner: true,
                    docs: [
                        'Seed public key used to derive the group authority.'
                    ]
                },
                {
                    name: 'groupAuthority',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'authority',
                    type: 'publicKey'
                }
            ]
        },
        {
            name: 'updateGroupAuthority',
            accounts: [
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'groupAuthority',
                    isMut: true,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'authority',
                    type: 'publicKey'
                }
            ]
        },
        {
            name: 'registerProgramToGroup',
            accounts: [
                {
                    name: 'authority',
                    isMut: true,
                    isSigner: true
                },
                {
                    name: 'programToBeRegistered',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'registeredProgramPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'groupAuthorityPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: []
        },
        {
            name: 'deregisterProgram',
            accounts: [
                {
                    name: 'authority',
                    isMut: true,
                    isSigner: true
                },
                {
                    name: 'registeredProgramPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'groupAuthorityPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'closeRecipient',
                    isMut: true,
                    isSigner: false
                }
            ],
            args: []
        },
        {
            name: 'initializeStateMerkleTreeAndNullifierQueue',
            docs: [
                'Initializes a new Merkle tree from config bytes.',
                'Index is an optional identifier and not checked by the program.'
            ],
            accounts: [
                {
                    name: 'authority',
                    isMut: true,
                    isSigner: true
                },
                {
                    name: 'merkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'nullifierQueue',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                }
            ],
            args: [
                {
                    name: 'index',
                    type: 'u64'
                },
                {
                    name: 'programOwner',
                    type: {
                        option: 'publicKey'
                    }
                },
                {
                    name: 'forester',
                    type: {
                        option: 'publicKey'
                    }
                },
                {
                    name: 'stateMerkleTreeConfig',
                    type: {
                        defined: 'StateMerkleTreeConfig'
                    }
                },
                {
                    name: 'nullifierQueueConfig',
                    type: {
                        defined: 'NullifierQueueConfig'
                    }
                },
                {
                    name: 'additionalBytes',
                    type: 'u64'
                }
            ]
        },
        {
            name: 'appendLeavesToMerkleTrees',
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'Fee payer pays rollover fee.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true,
                    docs: [
                        'Checked whether instruction is accessed by a registered program or owner = authority.'
                    ]
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false,
                    isOptional: true,
                    docs: [
                        'Some assumes that the Merkle trees are accessed by a registered program.',
                        'None assumes that the Merkle trees are accessed by its owner.'
                    ]
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'leaves',
                    type: {
                        vec: {
                            defined: '(u8,[u8;32])'
                        }
                    }
                }
            ]
        },
        {
            name: 'nullifyLeaves',
            accounts: [
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'logWrapper',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'merkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'nullifierQueue',
                    isMut: true,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'changeLogIndices',
                    type: {
                        vec: 'u64'
                    }
                },
                {
                    name: 'leavesQueueIndices',
                    type: {
                        vec: 'u16'
                    }
                },
                {
                    name: 'leafIndices',
                    type: {
                        vec: 'u64'
                    }
                },
                {
                    name: 'proofs',
                    type: {
                        vec: {
                            vec: {
                                array: [
                                    'u8',
                                    32
                                ]
                            }
                        }
                    }
                }
            ]
        },
        {
            name: 'insertIntoNullifierQueues',
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'Fee payer pays rollover fee.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'nullifiers',
                    type: {
                        vec: {
                            array: [
                                'u8',
                                32
                            ]
                        }
                    }
                }
            ]
        },
        {
            name: 'rolloverStateMerkleTreeAndNullifierQueue',
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'Signer used to receive rollover accounts rentexemption reimbursement.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'newStateMerkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'newNullifierQueue',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'oldStateMerkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'oldNullifierQueue',
                    isMut: true,
                    isSigner: false
                }
            ],
            args: []
        }
    ],
    accounts: [
        {
            name: 'registeredProgram',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'registeredProgramId',
                        type: 'publicKey'
                    },
                    {
                        name: 'groupAuthorityPda',
                        type: 'publicKey'
                    }
                ]
            }
        },
        {
            name: 'accessMetadata',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'owner',
                        docs: [
                            'Owner of the Merkle tree.'
                        ],
                        type: 'publicKey'
                    },
                    {
                        name: 'programOwner',
                        docs: [
                            'Program owner of the Merkle tree. This will be used for program owned Merkle trees.'
                        ],
                        type: 'publicKey'
                    },
                    {
                        name: 'forester',
                        docs: [
                            'Optional privileged forester pubkey, can be set for custom Merkle trees',
                            'without a network fee. Merkle trees without network fees are not',
                            'forested by light foresters. The variable is not used in the account',
                            'compression program but the registry program. The registry program',
                            'implements access control to prevent contention during forester. The',
                            'forester pubkey specified in this struct can bypass contention checks.'
                        ],
                        type: 'publicKey'
                    }
                ]
            }
        },
        {
            name: 'addressMerkleTreeAccount',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'metadata',
                        type: {
                            defined: 'MerkleTreeMetadata'
                        }
                    }
                ]
            }
        },
        {
            name: 'groupAuthority',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'authority',
                        type: 'publicKey'
                    },
                    {
                        name: 'seed',
                        type: 'publicKey'
                    }
                ]
            }
        },
        {
            name: 'merkleTreeMetadata',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'accessMetadata',
                        type: {
                            defined: 'AccessMetadata'
                        }
                    },
                    {
                        name: 'rolloverMetadata',
                        type: {
                            defined: 'RolloverMetadata'
                        }
                    },
                    {
                        name: 'associatedQueue',
                        type: 'publicKey'
                    },
                    {
                        name: 'nextMerkleTree',
                        type: 'publicKey'
                    }
                ]
            }
        },
        {
            name: 'stateMerkleTreeAccount',
            docs: [
                'Concurrent state Merkle tree used for public compressed transactions.'
            ],
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'metadata',
                        type: {
                            defined: 'MerkleTreeMetadata'
                        }
                    }
                ]
            }
        },
        {
            name: 'queueMetadata',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'accessMetadata',
                        type: {
                            defined: 'AccessMetadata'
                        }
                    },
                    {
                        name: 'rolloverMetadata',
                        type: {
                            defined: 'RolloverMetadata'
                        }
                    },
                    {
                        name: 'associatedMerkleTree',
                        type: 'publicKey'
                    },
                    {
                        name: 'nextQueue',
                        type: 'publicKey'
                    },
                    {
                        name: 'queueType',
                        type: 'u64'
                    }
                ]
            }
        },
        {
            name: 'queueAccount',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'metadata',
                        type: {
                            defined: 'QueueMetadata'
                        }
                    }
                ]
            }
        },
        {
            name: 'rolloverMetadata',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'index',
                        docs: [
                            'Unique index.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'rolloverFee',
                        docs: [
                            'This fee is used for rent for the next account.',
                            'It accumulates in the account so that once the corresponding Merkle tree account is full it can be rolled over'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'rolloverThreshold',
                        docs: [
                            'The threshold in percentage points when the account should be rolled over (95 corresponds to 95% filled).'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'networkFee',
                        docs: [
                            'Tip for maintaining the account.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'rolledoverSlot',
                        docs: [
                            'The slot when the account was rolled over, a rolled over account should not be written to.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'closeThreshold',
                        docs: [
                            'If current slot is greater than rolledover_slot + close_threshold and',
                            "the account is empty it can be closed. No 'close' functionality has been",
                            'implemented yet.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'additionalBytes',
                        docs: [
                            'Placeholder for bytes of additional accounts which are tied to the',
                            'Merkle trees operation and need to be rolled over as well.'
                        ],
                        type: 'u64'
                    }
                ]
            }
        }
    ],
    types: [
        {
            name: 'AddressMerkleTreeConfig',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'height',
                        type: 'u32'
                    },
                    {
                        name: 'changelogSize',
                        type: 'u64'
                    },
                    {
                        name: 'rootsSize',
                        type: 'u64'
                    },
                    {
                        name: 'canopyDepth',
                        type: 'u64'
                    },
                    {
                        name: 'addressChangelogSize',
                        type: 'u64'
                    },
                    {
                        name: 'networkFee',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'rolloverThreshold',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'closeThreshold',
                        type: {
                            option: 'u64'
                        }
                    }
                ]
            }
        },
        {
            name: 'StateMerkleTreeConfig',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'height',
                        type: 'u32'
                    },
                    {
                        name: 'changelogSize',
                        type: 'u64'
                    },
                    {
                        name: 'rootsSize',
                        type: 'u64'
                    },
                    {
                        name: 'canopyDepth',
                        type: 'u64'
                    },
                    {
                        name: 'networkFee',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'rolloverThreshold',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'closeThreshold',
                        type: {
                            option: 'u64'
                        }
                    }
                ]
            }
        },
        {
            name: 'NullifierQueueConfig',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'capacity',
                        type: 'u16'
                    },
                    {
                        name: 'sequenceThreshold',
                        type: 'u64'
                    },
                    {
                        name: 'networkFee',
                        type: {
                            option: 'u64'
                        }
                    }
                ]
            }
        },
        {
            name: 'QueueType',
            type: {
                kind: 'enum',
                variants: [
                    {
                        name: 'NullifierQueue'
                    },
                    {
                        name: 'AddressQueue'
                    }
                ]
            }
        },
        {
            name: 'AddressQueueConfig',
            type: {
                kind: 'alias',
                value: {
                    defined: 'NullifierQueueConfig'
                }
            }
        }
    ],
    errors: [
        {
            code: 6000,
            name: 'IntegerOverflow',
            msg: 'Integer overflow'
        },
        {
            code: 6001,
            name: 'InvalidAuthority',
            msg: 'InvalidAuthority'
        },
        {
            code: 6002,
            name: 'NumberOfLeavesMismatch',
            msg: 'Leaves <> remaining accounts mismatch. The number of remaining accounts must match the number of leaves.'
        },
        {
            code: 6003,
            name: 'InvalidNoopPubkey',
            msg: 'Provided noop program public key is invalid'
        },
        {
            code: 6004,
            name: 'NumberOfChangeLogIndicesMismatch',
            msg: 'Number of change log indices mismatch'
        },
        {
            code: 6005,
            name: 'NumberOfIndicesMismatch',
            msg: 'Number of indices mismatch'
        },
        {
            code: 6006,
            name: 'NumberOfProofsMismatch',
            msg: 'NumberOfProofsMismatch'
        },
        {
            code: 6007,
            name: 'InvalidMerkleProof',
            msg: 'InvalidMerkleProof'
        },
        {
            code: 6008,
            name: 'LeafNotFound',
            msg: 'Could not find the leaf in the queue'
        },
        {
            code: 6009,
            name: 'MerkleTreeAndQueueNotAssociated',
            msg: 'MerkleTreeAndQueueNotAssociated'
        },
        {
            code: 6010,
            name: 'MerkleTreeAlreadyRolledOver',
            msg: 'MerkleTreeAlreadyRolledOver'
        },
        {
            code: 6011,
            name: 'NotReadyForRollover',
            msg: 'NotReadyForRollover'
        },
        {
            code: 6012,
            name: 'RolloverNotConfigured',
            msg: 'RolloverNotConfigured'
        },
        {
            code: 6013,
            name: 'NotAllLeavesProcessed',
            msg: 'NotAllLeavesProcessed'
        },
        {
            code: 6014,
            name: 'InvalidQueueType',
            msg: 'InvalidQueueType'
        },
        {
            code: 6015,
            name: 'InputElementsEmpty',
            msg: 'InputElementsEmpty'
        },
        {
            code: 6016,
            name: 'NoLeavesForMerkleTree',
            msg: 'NoLeavesForMerkleTree'
        },
        {
            code: 6017,
            name: 'InvalidAccountSize',
            msg: 'InvalidAccountSize'
        },
        {
            code: 6018,
            name: 'InsufficientRolloverFee',
            msg: 'InsufficientRolloverFee'
        },
        {
            code: 6019,
            name: 'UnsupportedHeight',
            msg: 'Unsupported Merkle tree height'
        },
        {
            code: 6020,
            name: 'UnsupportedCanopyDepth',
            msg: 'Unsupported canopy depth'
        },
        {
            code: 6021,
            name: 'InvalidSequenceThreshold',
            msg: 'Invalid sequence threshold'
        },
        {
            code: 6022,
            name: 'UnsupportedCloseThreshold',
            msg: 'Unsupported close threshold'
        },
        {
            code: 6023,
            name: 'InvalidAccountBalance',
            msg: 'InvalidAccountBalance'
        },
        {
            code: 6024,
            name: 'UnsupportedAdditionalBytes'
        },
        {
            code: 6025,
            name: 'InvalidGroup'
        },
        {
            code: 6026,
            name: 'ProofLengthMismatch'
        }
    ]
};
const IDL$1 = {
    version: '1.2.0',
    name: 'light_registry',
    constants: [
        {
            name: 'FORESTER_SEED',
            type: 'bytes',
            value: '[102, 111, 114, 101, 115, 116, 101, 114]'
        },
        {
            name: 'FORESTER_EPOCH_SEED',
            type: 'bytes',
            value: '[102, 111, 114, 101, 115, 116, 101, 114, 95, 101, 112, 111, 99, 104]'
        },
        {
            name: 'PROTOCOL_CONFIG_PDA_SEED',
            type: 'bytes',
            value: '[97, 117, 116, 104, 111, 114, 105, 116, 121]'
        }
    ],
    instructions: [
        {
            name: 'initializeProtocolConfig',
            docs: [
                'Initializes the protocol config pda. Can only be called once by the',
                'program account keypair.'
            ],
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'protocolConfigPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'selfProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'bump',
                    type: 'u8'
                },
                {
                    name: 'protocolConfig',
                    type: {
                        defined: 'ProtocolConfig'
                    }
                }
            ]
        },
        {
            name: 'updateProtocolConfig',
            accounts: [
                {
                    name: 'feePayer',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'protocolConfigPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'newAuthority',
                    isMut: false,
                    isSigner: true,
                    isOptional: true
                }
            ],
            args: [
                {
                    name: 'protocolConfig',
                    type: {
                        option: {
                            defined: 'ProtocolConfig'
                        }
                    }
                }
            ]
        },
        {
            name: 'registerSystemProgram',
            accounts: [
                {
                    name: 'authority',
                    isMut: true,
                    isSigner: true
                },
                {
                    name: 'protocolConfigPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'cpiAuthority',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'groupPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'programToBeRegistered',
                    isMut: false,
                    isSigner: true,
                    docs: [
                        '- is signer so that only the program deployer can register a program.'
                    ]
                }
            ],
            args: [
                {
                    name: 'bump',
                    type: 'u8'
                }
            ]
        },
        {
            name: 'deregisterSystemProgram',
            accounts: [
                {
                    name: 'authority',
                    isMut: true,
                    isSigner: true
                },
                {
                    name: 'protocolConfigPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'cpiAuthority',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'groupPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: true,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'bump',
                    type: 'u8'
                }
            ]
        },
        {
            name: 'registerForester',
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'protocolConfigPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'foresterPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'bump',
                    type: 'u8'
                },
                {
                    name: 'authority',
                    type: 'publicKey'
                },
                {
                    name: 'config',
                    type: {
                        defined: 'ForesterConfig'
                    }
                },
                {
                    name: 'weight',
                    type: {
                        option: 'u64'
                    }
                }
            ]
        },
        {
            name: 'updateForesterPda',
            accounts: [
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'foresterPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'newAuthority',
                    isMut: false,
                    isSigner: true,
                    isOptional: true
                }
            ],
            args: [
                {
                    name: 'config',
                    type: {
                        option: {
                            defined: 'ForesterConfig'
                        }
                    }
                }
            ]
        },
        {
            name: 'updateForesterPdaWeight',
            accounts: [
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'protocolConfigPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'foresterPda',
                    isMut: true,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'newWeight',
                    type: 'u64'
                }
            ]
        },
        {
            name: 'registerForesterEpoch',
            docs: [
                'Registers the forester for the epoch.',
                '1. Only the forester can register herself for the epoch.',
                '2. Protocol config is copied.',
                '3. Epoch account is created if needed.'
            ],
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'foresterPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'foresterEpochPda',
                    isMut: true,
                    isSigner: false,
                    docs: [
                        'Instruction checks that current_epoch is the the current epoch and that',
                        'the epoch is in registration phase.'
                    ]
                },
                {
                    name: 'protocolConfig',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'epochPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'epoch',
                    type: 'u64'
                }
            ]
        },
        {
            name: 'finalizeRegistration',
            docs: [
                'This transaction can be included as additional instruction in the first',
                'work instructions during the active phase.',
                'Registration Period must be over.'
            ],
            accounts: [
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'foresterEpochPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'epochPda',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: []
        },
        {
            name: 'reportWork',
            accounts: [
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'foresterEpochPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'epochPda',
                    isMut: true,
                    isSigner: false
                }
            ],
            args: []
        },
        {
            name: 'initializeAddressMerkleTree',
            accounts: [
                {
                    name: 'authority',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'Anyone can create new trees just the fees cannot be set arbitrarily.'
                    ]
                },
                {
                    name: 'merkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'queue',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'cpiAuthority',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'protocolConfigPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'cpiContextAccount',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'lightSystemProgram',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                }
            ],
            args: [
                {
                    name: 'bump',
                    type: 'u8'
                },
                {
                    name: 'programOwner',
                    type: {
                        option: 'publicKey'
                    }
                },
                {
                    name: 'forester',
                    type: {
                        option: 'publicKey'
                    }
                },
                {
                    name: 'merkleTreeConfig',
                    type: {
                        defined: 'AddressMerkleTreeConfig'
                    }
                },
                {
                    name: 'queueConfig',
                    type: {
                        defined: 'AddressQueueConfig'
                    }
                }
            ]
        },
        {
            name: 'initializeStateMerkleTree',
            accounts: [
                {
                    name: 'authority',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'Anyone can create new trees just the fees cannot be set arbitrarily.'
                    ]
                },
                {
                    name: 'merkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'queue',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'cpiAuthority',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'protocolConfigPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'cpiContextAccount',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'lightSystemProgram',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                }
            ],
            args: [
                {
                    name: 'bump',
                    type: 'u8'
                },
                {
                    name: 'programOwner',
                    type: {
                        option: 'publicKey'
                    }
                },
                {
                    name: 'forester',
                    type: {
                        option: 'publicKey'
                    }
                },
                {
                    name: 'merkleTreeConfig',
                    type: {
                        defined: 'StateMerkleTreeConfig'
                    }
                },
                {
                    name: 'queueConfig',
                    type: {
                        defined: 'NullifierQueueConfig'
                    }
                }
            ]
        },
        {
            name: 'nullify',
            accounts: [
                {
                    name: 'registeredForesterPda',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'cpiAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'logWrapper',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'merkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'nullifierQueue',
                    isMut: true,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'bump',
                    type: 'u8'
                },
                {
                    name: 'changeLogIndices',
                    type: {
                        vec: 'u64'
                    }
                },
                {
                    name: 'leavesQueueIndices',
                    type: {
                        vec: 'u16'
                    }
                },
                {
                    name: 'indices',
                    type: {
                        vec: 'u64'
                    }
                },
                {
                    name: 'proofs',
                    type: {
                        vec: {
                            vec: {
                                array: [
                                    'u8',
                                    32
                                ]
                            }
                        }
                    }
                }
            ]
        },
        {
            name: 'updateAddressMerkleTree',
            accounts: [
                {
                    name: 'registeredForesterPda',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'cpiAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'queue',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'merkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'logWrapper',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'bump',
                    type: 'u8'
                },
                {
                    name: 'changelogIndex',
                    type: 'u16'
                },
                {
                    name: 'indexedChangelogIndex',
                    type: 'u16'
                },
                {
                    name: 'value',
                    type: 'u16'
                },
                {
                    name: 'lowAddressIndex',
                    type: 'u64'
                },
                {
                    name: 'lowAddressValue',
                    type: {
                        array: [
                            'u8',
                            32
                        ]
                    }
                },
                {
                    name: 'lowAddressNextIndex',
                    type: 'u64'
                },
                {
                    name: 'lowAddressNextValue',
                    type: {
                        array: [
                            'u8',
                            32
                        ]
                    }
                },
                {
                    name: 'lowAddressProof',
                    type: {
                        array: [
                            {
                                array: [
                                    'u8',
                                    32
                                ]
                            },
                            16
                        ]
                    }
                }
            ]
        },
        {
            name: 'rolloverAddressMerkleTreeAndQueue',
            accounts: [
                {
                    name: 'registeredForesterPda',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'authority',
                    isMut: true,
                    isSigner: true
                },
                {
                    name: 'cpiAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'newMerkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'newQueue',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'oldMerkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'oldQueue',
                    isMut: true,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'bump',
                    type: 'u8'
                }
            ]
        },
        {
            name: 'rolloverStateMerkleTreeAndQueue',
            accounts: [
                {
                    name: 'registeredForesterPda',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'authority',
                    isMut: true,
                    isSigner: true
                },
                {
                    name: 'cpiAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'newMerkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'newQueue',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'oldMerkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'oldQueue',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'cpiContextAccount',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'lightSystemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'protocolConfigPda',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'bump',
                    type: 'u8'
                }
            ]
        }
    ],
    accounts: [
        {
            name: 'epochPda',
            docs: [
                'Is used for tallying and rewards calculation'
            ],
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'epoch',
                        type: 'u64'
                    },
                    {
                        name: 'protocolConfig',
                        type: {
                            defined: 'ProtocolConfig'
                        }
                    },
                    {
                        name: 'totalWork',
                        type: 'u64'
                    },
                    {
                        name: 'registeredWeight',
                        type: 'u64'
                    }
                ]
            }
        },
        {
            name: 'foresterEpochPda',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'authority',
                        type: 'publicKey'
                    },
                    {
                        name: 'config',
                        type: {
                            defined: 'ForesterConfig'
                        }
                    },
                    {
                        name: 'epoch',
                        type: 'u64'
                    },
                    {
                        name: 'weight',
                        type: 'u64'
                    },
                    {
                        name: 'workCounter',
                        type: 'u64'
                    },
                    {
                        name: 'hasReportedWork',
                        docs: [
                            'Work can be reported in an extra round to earn extra performance based',
                            'rewards.'
                        ],
                        type: 'bool'
                    },
                    {
                        name: 'foresterIndex',
                        docs: [
                            'Start index of the range that determines when the forester is eligible to perform work.',
                            'End index is forester_start_index + weight'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'epochActivePhaseStartSlot',
                        type: 'u64'
                    },
                    {
                        name: 'totalEpochWeight',
                        docs: [
                            'Total epoch weight is registered weight of the epoch account after',
                            'registration is concluded and active epoch period starts.'
                        ],
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'protocolConfig',
                        type: {
                            defined: 'ProtocolConfig'
                        }
                    },
                    {
                        name: 'finalizeCounter',
                        docs: [
                            'Incremented every time finalize registration is called.'
                        ],
                        type: 'u64'
                    }
                ]
            }
        },
        {
            name: 'protocolConfigPda',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'authority',
                        type: 'publicKey'
                    },
                    {
                        name: 'bump',
                        type: 'u8'
                    },
                    {
                        name: 'config',
                        type: {
                            defined: 'ProtocolConfig'
                        }
                    }
                ]
            }
        },
        {
            name: 'foresterPda',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'authority',
                        type: 'publicKey'
                    },
                    {
                        name: 'config',
                        type: {
                            defined: 'ForesterConfig'
                        }
                    },
                    {
                        name: 'activeWeight',
                        type: 'u64'
                    },
                    {
                        name: 'pendingWeight',
                        docs: [
                            'Pending weight which will get active once the next epoch starts.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'currentEpoch',
                        type: 'u64'
                    },
                    {
                        name: 'lastCompressedForesterEpochPdaHash',
                        docs: [
                            'Link to previous compressed forester epoch account hash.'
                        ],
                        type: {
                            array: [
                                'u8',
                                32
                            ]
                        }
                    },
                    {
                        name: 'lastRegisteredEpoch',
                        type: 'u64'
                    }
                ]
            }
        }
    ],
    types: [
        {
            name: 'ProtocolConfig',
            docs: [
                'Epoch Phases:',
                '1. Registration',
                '2. Active',
                '3. Report Work',
                '4. Post (Epoch has ended, and rewards can be claimed.)',
                '- There is always an active phase in progress, registration and report work',
                'phases run in parallel to a currently active phase.'
            ],
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'genesisSlot',
                        docs: [
                            'Solana slot when the protocol starts operating.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'minWeight',
                        docs: [
                            'Minimum weight required for a forester to register to an epoch.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'slotLength',
                        docs: [
                            'Light protocol slot length.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'registrationPhaseLength',
                        docs: [
                            'Foresters can register for this phase.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'activePhaseLength',
                        docs: [
                            'Foresters can perform work in this phase.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'reportWorkPhaseLength',
                        docs: [
                            'Foresters can report work to receive performance based rewards in this',
                            'phase.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'networkFee',
                        type: 'u64'
                    },
                    {
                        name: 'cpiContextSize',
                        type: 'u64'
                    },
                    {
                        name: 'finalizeCounterLimit',
                        type: 'u64'
                    },
                    {
                        name: 'placeHolder',
                        docs: [
                            'Placeholder for future protocol updates.'
                        ],
                        type: 'publicKey'
                    },
                    {
                        name: 'placeHolderA',
                        type: 'u64'
                    },
                    {
                        name: 'placeHolderB',
                        type: 'u64'
                    },
                    {
                        name: 'placeHolderC',
                        type: 'u64'
                    },
                    {
                        name: 'placeHolderD',
                        type: 'u64'
                    },
                    {
                        name: 'placeHolderE',
                        type: 'u64'
                    },
                    {
                        name: 'placeHolderF',
                        type: 'u64'
                    }
                ]
            }
        },
        {
            name: 'ForesterConfig',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'fee',
                        docs: [
                            'Fee in percentage points.'
                        ],
                        type: 'u64'
                    }
                ]
            }
        },
        {
            name: 'EpochState',
            type: {
                kind: 'enum',
                variants: [
                    {
                        name: 'Registration'
                    },
                    {
                        name: 'Active'
                    },
                    {
                        name: 'ReportWork'
                    },
                    {
                        name: 'Post'
                    },
                    {
                        name: 'Pre'
                    }
                ]
            }
        }
    ],
    errors: [
        {
            code: 6000,
            name: 'InvalidForester',
            msg: 'InvalidForester'
        },
        {
            code: 6001,
            name: 'NotInReportWorkPhase'
        },
        {
            code: 6002,
            name: 'StakeAccountAlreadySynced'
        },
        {
            code: 6003,
            name: 'EpochEnded'
        },
        {
            code: 6004,
            name: 'ForesterNotEligible'
        },
        {
            code: 6005,
            name: 'NotInRegistrationPeriod'
        },
        {
            code: 6006,
            name: 'WeightInsuffient'
        },
        {
            code: 6007,
            name: 'ForesterAlreadyRegistered'
        },
        {
            code: 6008,
            name: 'InvalidEpochAccount'
        },
        {
            code: 6009,
            name: 'InvalidEpoch'
        },
        {
            code: 6010,
            name: 'EpochStillInProgress'
        },
        {
            code: 6011,
            name: 'NotInActivePhase'
        },
        {
            code: 6012,
            name: 'ForesterAlreadyReportedWork'
        },
        {
            code: 6013,
            name: 'InvalidNetworkFee'
        },
        {
            code: 6014,
            name: 'FinalizeCounterExceeded'
        },
        {
            code: 6015,
            name: 'CpiContextAccountMissing'
        },
        {
            code: 6016,
            name: 'ArithmeticUnderflow'
        },
        {
            code: 6017,
            name: 'RegistrationNotFinalized'
        },
        {
            code: 6018,
            name: 'CpiContextAccountInvalidDataLen'
        },
        {
            code: 6019,
            name: 'InvalidConfigUpdate'
        },
        {
            code: 6020,
            name: 'InvalidSigner'
        },
        {
            code: 6021,
            name: 'GetLatestRegisterEpochFailed'
        },
        {
            code: 6022,
            name: 'GetCurrentActiveEpochFailed'
        },
        {
            code: 6023,
            name: 'ForesterUndefined'
        },
        {
            code: 6024,
            name: 'ForesterDefined'
        }
    ]
};
const IDL = {
    version: '1.2.0',
    name: 'light_compressed_token',
    instructions: [
        {
            name: 'createTokenPool',
            docs: [
                'This instruction creates a token pool for a given mint. Every spl mint',
                'can have one token pool. When a token is compressed the tokens are',
                'transferrred to the token pool, and their compressed equivalent is',
                'minted into a Merkle tree.'
            ],
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'UNCHECKED: only pays fees.'
                    ]
                },
                {
                    name: 'tokenPoolPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'mint',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'tokenProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'cpiAuthorityPda',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: []
        },
        {
            name: 'mintTo',
            docs: [
                'Mints tokens from an spl token mint to a list of compressed accounts.',
                'Minted tokens are transferred to a pool account owned by the compressed',
                'token program. The instruction creates one compressed output account for',
                'every amount and pubkey input pair. A constant amount of lamports can be',
                'transferred to each output account to enable. A use case to add lamports',
                'to a compressed token account is to prevent spam. This is the only way',
                'to add lamports to a compressed token account.'
            ],
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'UNCHECKED: only pays fees.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'cpiAuthorityPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'mint',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'tokenPoolPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'tokenProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'lightSystemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'noopProgram',
                    isMut: false,
                    isSigner: false,
                    docs: [
                        'programs'
                    ]
                },
                {
                    name: 'accountCompressionAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'merkleTree',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'selfProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'solPoolPda',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                }
            ],
            args: [
                {
                    name: 'publicKeys',
                    type: {
                        vec: 'publicKey'
                    }
                },
                {
                    name: 'amounts',
                    type: {
                        vec: 'u64'
                    }
                },
                {
                    name: 'lamports',
                    type: {
                        option: 'u64'
                    }
                }
            ]
        },
        {
            name: 'compressSplTokenAccount',
            docs: [
                'Compresses the balance of an spl token account sub an optional remaining',
                'amount. This instruction does not close the spl token account. To close',
                'the account bundle a close spl account instruction in your transaction.'
            ],
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'UNCHECKED: only pays fees.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true,
                    docs: [
                        'Authority is verified through proof since both owner and delegate',
                        'are included in the token data hash, which is a public input to the',
                        'validity proof.'
                    ]
                },
                {
                    name: 'cpiAuthorityPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'lightSystemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'noopProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'selfProgram',
                    isMut: false,
                    isSigner: false,
                    docs: [
                        'this program is the signer of the cpi.'
                    ]
                },
                {
                    name: 'tokenPoolPda',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'compressOrDecompressTokenAccount',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'tokenProgram',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'owner',
                    type: 'publicKey'
                },
                {
                    name: 'remainingAmount',
                    type: {
                        option: 'u64'
                    }
                },
                {
                    name: 'cpiContext',
                    type: {
                        option: {
                            defined: 'CompressedCpiContext'
                        }
                    }
                }
            ]
        },
        {
            name: 'transfer',
            docs: [
                'Transfers compressed tokens from one account to another. All accounts',
                'must be of the same mint. Additional spl tokens can be compressed or',
                'decompressed. In one transaction only compression or decompression is',
                'possible. Lamports can be transferred alongside tokens. If output token',
                'accounts specify less lamports than inputs the remaining lamports are',
                'transferred to an output compressed account. Signer must be owner or',
                'delegate. If a delegated token account is transferred the delegate is',
                'not preserved.'
            ],
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'UNCHECKED: only pays fees.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true,
                    docs: [
                        'Authority is verified through proof since both owner and delegate',
                        'are included in the token data hash, which is a public input to the',
                        'validity proof.'
                    ]
                },
                {
                    name: 'cpiAuthorityPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'lightSystemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'noopProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'selfProgram',
                    isMut: false,
                    isSigner: false,
                    docs: [
                        'this program is the signer of the cpi.'
                    ]
                },
                {
                    name: 'tokenPoolPda',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'compressOrDecompressTokenAccount',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'tokenProgram',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'inputs',
                    type: 'bytes'
                }
            ]
        },
        {
            name: 'approve',
            docs: [
                'Delegates an amount to a delegate. A compressed token account is either',
                'completely delegated or not. Prior delegates are not preserved. Cannot',
                'be called by a delegate.',
                'The instruction creates two output accounts:',
                '1. one account with delegated amount',
                '2. one account with remaining(change) amount'
            ],
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'UNCHECKED: only pays fees.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true,
                    docs: [
                        'Authority is verified through proof since both owner and delegate',
                        'are included in the token data hash, which is a public input to the',
                        'validity proof.'
                    ]
                },
                {
                    name: 'cpiAuthorityPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'lightSystemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'noopProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'selfProgram',
                    isMut: false,
                    isSigner: false,
                    docs: [
                        'this program is the signer of the cpi.'
                    ]
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'inputs',
                    type: 'bytes'
                }
            ]
        },
        {
            name: 'revoke',
            docs: [
                'Revokes a delegation. The instruction merges all inputs into one output',
                'account. Cannot be called by a delegate. Delegates are not preserved.'
            ],
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'UNCHECKED: only pays fees.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true,
                    docs: [
                        'Authority is verified through proof since both owner and delegate',
                        'are included in the token data hash, which is a public input to the',
                        'validity proof.'
                    ]
                },
                {
                    name: 'cpiAuthorityPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'lightSystemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'noopProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'selfProgram',
                    isMut: false,
                    isSigner: false,
                    docs: [
                        'this program is the signer of the cpi.'
                    ]
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'inputs',
                    type: 'bytes'
                }
            ]
        },
        {
            name: 'freeze',
            docs: [
                'Freezes compressed token accounts. Inputs must not be frozen. Creates as',
                'many outputs as inputs. Balances and delegates are preserved.'
            ],
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'UNCHECKED: only pays fees.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'cpiAuthorityPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'lightSystemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'noopProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'selfProgram',
                    isMut: false,
                    isSigner: false,
                    docs: [
                        'that this program is the signer of the cpi.'
                    ]
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'mint',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'inputs',
                    type: 'bytes'
                }
            ]
        },
        {
            name: 'thaw',
            docs: [
                'Thaws frozen compressed token accounts. Inputs must be frozen. Creates',
                'as many outputs as inputs. Balances and delegates are preserved.'
            ],
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'UNCHECKED: only pays fees.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true
                },
                {
                    name: 'cpiAuthorityPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'lightSystemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'noopProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'selfProgram',
                    isMut: false,
                    isSigner: false,
                    docs: [
                        'that this program is the signer of the cpi.'
                    ]
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'mint',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'inputs',
                    type: 'bytes'
                }
            ]
        },
        {
            name: 'burn',
            docs: [
                'Burns compressed tokens and spl tokens from the pool account. Delegates',
                'can burn tokens. The output compressed token account remains delegated.',
                'Creates one output compressed token account.'
            ],
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'UNCHECKED: only pays fees.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true,
                    docs: [
                        'Authority is verified through proof since both owner and delegate',
                        'are included in the token data hash, which is a public input to the',
                        'validity proof.'
                    ]
                },
                {
                    name: 'cpiAuthorityPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'mint',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'tokenPoolPda',
                    isMut: true,
                    isSigner: false
                },
                {
                    name: 'tokenProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'lightSystemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'noopProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'selfProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'inputs',
                    type: 'bytes'
                }
            ]
        },
        {
            name: 'stubIdlBuild',
            docs: [
                'This function is a stub to allow Anchor to include the input types in',
                'the IDL. It should not be included in production builds nor be called in',
                'practice.'
            ],
            accounts: [
                {
                    name: 'feePayer',
                    isMut: true,
                    isSigner: true,
                    docs: [
                        'UNCHECKED: only pays fees.'
                    ]
                },
                {
                    name: 'authority',
                    isMut: false,
                    isSigner: true,
                    docs: [
                        'Authority is verified through proof since both owner and delegate',
                        'are included in the token data hash, which is a public input to the',
                        'validity proof.'
                    ]
                },
                {
                    name: 'cpiAuthorityPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'lightSystemProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'registeredProgramPda',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'noopProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionAuthority',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'accountCompressionProgram',
                    isMut: false,
                    isSigner: false
                },
                {
                    name: 'selfProgram',
                    isMut: false,
                    isSigner: false,
                    docs: [
                        'this program is the signer of the cpi.'
                    ]
                },
                {
                    name: 'tokenPoolPda',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'compressOrDecompressTokenAccount',
                    isMut: true,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'tokenProgram',
                    isMut: false,
                    isSigner: false,
                    isOptional: true
                },
                {
                    name: 'systemProgram',
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: 'inputs1',
                    type: {
                        defined: 'CompressedTokenInstructionDataTransfer'
                    }
                },
                {
                    name: 'inputs2',
                    type: {
                        defined: 'TokenData'
                    }
                }
            ]
        }
    ],
    types: [
        {
            name: 'AccessMetadata',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'owner',
                        docs: [
                            'Owner of the Merkle tree.'
                        ],
                        type: 'publicKey'
                    },
                    {
                        name: 'programOwner',
                        docs: [
                            'Program owner of the Merkle tree. This will be used for program owned Merkle trees.'
                        ],
                        type: 'publicKey'
                    },
                    {
                        name: 'forester',
                        docs: [
                            'Optional privileged forester pubkey, can be set for custom Merkle trees',
                            'without a network fee. Merkle trees without network fees are not',
                            'forested by light foresters. The variable is not used in the account',
                            'compression program but the registry program. The registry program',
                            'implements access control to prevent contention during forester. The',
                            'forester pubkey specified in this struct can bypass contention checks.'
                        ],
                        type: 'publicKey'
                    }
                ]
            }
        },
        {
            name: 'AccountState',
            type: {
                kind: 'enum',
                variants: [
                    {
                        name: 'Initialized'
                    },
                    {
                        name: 'Frozen'
                    }
                ]
            }
        },
        {
            name: 'CompressedAccount',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'owner',
                        type: 'publicKey'
                    },
                    {
                        name: 'lamports',
                        type: 'u64'
                    },
                    {
                        name: 'address',
                        type: {
                            option: {
                                array: [
                                    'u8',
                                    32
                                ]
                            }
                        }
                    },
                    {
                        name: 'data',
                        type: {
                            option: {
                                defined: 'CompressedAccountData'
                            }
                        }
                    }
                ]
            }
        },
        {
            name: 'CompressedAccountData',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'discriminator',
                        type: {
                            array: [
                                'u8',
                                8
                            ]
                        }
                    },
                    {
                        name: 'data',
                        type: 'bytes'
                    },
                    {
                        name: 'dataHash',
                        type: {
                            array: [
                                'u8',
                                32
                            ]
                        }
                    }
                ]
            }
        },
        {
            name: 'CompressedCpiContext',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'setContext',
                        docs: [
                            'Is set by the program that is invoking the CPI to signal that is should',
                            'set the cpi context.'
                        ],
                        type: 'bool'
                    },
                    {
                        name: 'firstSetContext',
                        docs: [
                            'Is set to wipe the cpi context since someone could have set it before',
                            'with unrelated data.'
                        ],
                        type: 'bool'
                    },
                    {
                        name: 'cpiContextAccountIndex',
                        docs: [
                            'Index of cpi context account in remaining accounts.'
                        ],
                        type: 'u8'
                    }
                ]
            }
        },
        {
            name: 'CompressedProof',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'a',
                        type: {
                            array: [
                                'u8',
                                32
                            ]
                        }
                    },
                    {
                        name: 'b',
                        type: {
                            array: [
                                'u8',
                                64
                            ]
                        }
                    },
                    {
                        name: 'c',
                        type: {
                            array: [
                                'u8',
                                32
                            ]
                        }
                    }
                ]
            }
        },
        {
            name: 'CompressedTokenInstructionDataTransfer',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'proof',
                        type: {
                            option: {
                                defined: 'CompressedProof'
                            }
                        }
                    },
                    {
                        name: 'mint',
                        type: 'publicKey'
                    },
                    {
                        name: 'delegatedTransfer',
                        docs: [
                            'Is required if the signer is delegate,',
                            '-> delegate is authority account,',
                            'owner = Some(owner) is the owner of the token account.'
                        ],
                        type: {
                            option: {
                                defined: 'DelegatedTransfer'
                            }
                        }
                    },
                    {
                        name: 'inputTokenDataWithContext',
                        type: {
                            vec: {
                                defined: 'InputTokenDataWithContext'
                            }
                        }
                    },
                    {
                        name: 'outputCompressedAccounts',
                        type: {
                            vec: {
                                defined: 'PackedTokenTransferOutputData'
                            }
                        }
                    },
                    {
                        name: 'isCompress',
                        type: 'bool'
                    },
                    {
                        name: 'compressOrDecompressAmount',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'cpiContext',
                        type: {
                            option: {
                                defined: 'CompressedCpiContext'
                            }
                        }
                    },
                    {
                        name: 'lamportsChangeAccountMerkleTreeIndex',
                        type: {
                            option: 'u8'
                        }
                    }
                ]
            }
        },
        {
            name: 'DelegatedTransfer',
            docs: [
                'Struct to provide the owner when the delegate is signer of the transaction.'
            ],
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'owner',
                        type: 'publicKey'
                    },
                    {
                        name: 'delegateChangeAccountIndex',
                        docs: [
                            'Index of change compressed account in output compressed accounts. In',
                            "case that the delegate didn't spend the complete delegated compressed",
                            'account balance the change compressed account will be delegated to her',
                            'as well.'
                        ],
                        type: {
                            option: 'u8'
                        }
                    }
                ]
            }
        },
        {
            name: 'InputTokenDataWithContext',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'amount',
                        type: 'u64'
                    },
                    {
                        name: 'delegateIndex',
                        type: {
                            option: 'u8'
                        }
                    },
                    {
                        name: 'merkleContext',
                        type: {
                            defined: 'PackedMerkleContext'
                        }
                    },
                    {
                        name: 'rootIndex',
                        type: 'u16'
                    },
                    {
                        name: 'lamports',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'tlv',
                        docs: [
                            'Placeholder for TokenExtension tlv data (unimplemented)'
                        ],
                        type: {
                            option: 'bytes'
                        }
                    }
                ]
            }
        },
        {
            name: 'InstructionDataInvoke',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'proof',
                        type: {
                            option: {
                                defined: 'CompressedProof'
                            }
                        }
                    },
                    {
                        name: 'inputCompressedAccountsWithMerkleContext',
                        type: {
                            vec: {
                                defined: 'PackedCompressedAccountWithMerkleContext'
                            }
                        }
                    },
                    {
                        name: 'outputCompressedAccounts',
                        type: {
                            vec: {
                                defined: 'OutputCompressedAccountWithPackedContext'
                            }
                        }
                    },
                    {
                        name: 'relayFee',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'newAddressParams',
                        type: {
                            vec: {
                                defined: 'NewAddressParamsPacked'
                            }
                        }
                    },
                    {
                        name: 'compressOrDecompressLamports',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'isCompress',
                        type: 'bool'
                    }
                ]
            }
        },
        {
            name: 'InstructionDataInvokeCpi',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'proof',
                        type: {
                            option: {
                                defined: 'CompressedProof'
                            }
                        }
                    },
                    {
                        name: 'newAddressParams',
                        type: {
                            vec: {
                                defined: 'NewAddressParamsPacked'
                            }
                        }
                    },
                    {
                        name: 'inputCompressedAccountsWithMerkleContext',
                        type: {
                            vec: {
                                defined: 'PackedCompressedAccountWithMerkleContext'
                            }
                        }
                    },
                    {
                        name: 'outputCompressedAccounts',
                        type: {
                            vec: {
                                defined: 'OutputCompressedAccountWithPackedContext'
                            }
                        }
                    },
                    {
                        name: 'relayFee',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'compressOrDecompressLamports',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'isCompress',
                        type: 'bool'
                    },
                    {
                        name: 'cpiContext',
                        type: {
                            option: {
                                defined: 'CompressedCpiContext'
                            }
                        }
                    }
                ]
            }
        },
        {
            name: 'MerkleTreeMetadata',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'accessMetadata',
                        type: {
                            defined: 'AccessMetadata'
                        }
                    },
                    {
                        name: 'rolloverMetadata',
                        type: {
                            defined: 'RolloverMetadata'
                        }
                    },
                    {
                        name: 'associatedQueue',
                        type: 'publicKey'
                    },
                    {
                        name: 'nextMerkleTree',
                        type: 'publicKey'
                    }
                ]
            }
        },
        {
            name: 'MerkleTreeSequenceNumber',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'pubkey',
                        type: 'publicKey'
                    },
                    {
                        name: 'seq',
                        type: 'u64'
                    }
                ]
            }
        },
        {
            name: 'NewAddressParamsPacked',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'seed',
                        type: {
                            array: [
                                'u8',
                                32
                            ]
                        }
                    },
                    {
                        name: 'addressQueueAccountIndex',
                        type: 'u8'
                    },
                    {
                        name: 'addressMerkleTreeAccountIndex',
                        type: 'u8'
                    },
                    {
                        name: 'addressMerkleTreeRootIndex',
                        type: 'u16'
                    }
                ]
            }
        },
        {
            name: 'OutputCompressedAccountWithPackedContext',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'compressedAccount',
                        type: {
                            defined: 'CompressedAccount'
                        }
                    },
                    {
                        name: 'merkleTreeIndex',
                        type: 'u8'
                    }
                ]
            }
        },
        {
            name: 'PackedCompressedAccountWithMerkleContext',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'compressedAccount',
                        type: {
                            defined: 'CompressedAccount'
                        }
                    },
                    {
                        name: 'merkleContext',
                        type: {
                            defined: 'PackedMerkleContext'
                        }
                    },
                    {
                        name: 'rootIndex',
                        docs: [
                            'Index of root used in inclusion validity proof.'
                        ],
                        type: 'u16'
                    },
                    {
                        name: 'readOnly',
                        docs: [
                            'Placeholder to mark accounts read-only unimplemented set to false.'
                        ],
                        type: 'bool'
                    }
                ]
            }
        },
        {
            name: 'PackedMerkleContext',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'merkleTreePubkeyIndex',
                        type: 'u8'
                    },
                    {
                        name: 'nullifierQueuePubkeyIndex',
                        type: 'u8'
                    },
                    {
                        name: 'leafIndex',
                        type: 'u32'
                    },
                    {
                        name: 'queueIndex',
                        docs: [
                            'Index of leaf in queue. Placeholder of batched Merkle tree updates',
                            'currently unimplemented.'
                        ],
                        type: {
                            option: {
                                defined: 'QueueIndex'
                            }
                        }
                    }
                ]
            }
        },
        {
            name: 'PackedTokenTransferOutputData',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'owner',
                        type: 'publicKey'
                    },
                    {
                        name: 'amount',
                        type: 'u64'
                    },
                    {
                        name: 'lamports',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'merkleTreeIndex',
                        type: 'u8'
                    },
                    {
                        name: 'tlv',
                        docs: [
                            'Placeholder for TokenExtension tlv data (unimplemented)'
                        ],
                        type: {
                            option: 'bytes'
                        }
                    }
                ]
            }
        },
        {
            name: 'PublicTransactionEvent',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'inputCompressedAccountHashes',
                        type: {
                            vec: {
                                array: [
                                    'u8',
                                    32
                                ]
                            }
                        }
                    },
                    {
                        name: 'outputCompressedAccountHashes',
                        type: {
                            vec: {
                                array: [
                                    'u8',
                                    32
                                ]
                            }
                        }
                    },
                    {
                        name: 'outputCompressedAccounts',
                        type: {
                            vec: {
                                defined: 'OutputCompressedAccountWithPackedContext'
                            }
                        }
                    },
                    {
                        name: 'outputLeafIndices',
                        type: {
                            vec: 'u32'
                        }
                    },
                    {
                        name: 'sequenceNumbers',
                        type: {
                            vec: {
                                defined: 'MerkleTreeSequenceNumber'
                            }
                        }
                    },
                    {
                        name: 'relayFee',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'isCompress',
                        type: 'bool'
                    },
                    {
                        name: 'compressOrDecompressLamports',
                        type: {
                            option: 'u64'
                        }
                    },
                    {
                        name: 'pubkeyArray',
                        type: {
                            vec: 'publicKey'
                        }
                    },
                    {
                        name: 'message',
                        type: {
                            option: 'bytes'
                        }
                    }
                ]
            }
        },
        {
            name: 'QueueIndex',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'queueId',
                        docs: [
                            'Id of queue in queue account.'
                        ],
                        type: 'u8'
                    },
                    {
                        name: 'index',
                        docs: [
                            'Index of compressed account hash in queue.'
                        ],
                        type: 'u16'
                    }
                ]
            }
        },
        {
            name: 'RolloverMetadata',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'index',
                        docs: [
                            'Unique index.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'rolloverFee',
                        docs: [
                            'This fee is used for rent for the next account.',
                            'It accumulates in the account so that once the corresponding Merkle tree account is full it can be rolled over'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'rolloverThreshold',
                        docs: [
                            'The threshold in percentage points when the account should be rolled over (95 corresponds to 95% filled).'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'networkFee',
                        docs: [
                            'Tip for maintaining the account.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'rolledoverSlot',
                        docs: [
                            'The slot when the account was rolled over, a rolled over account should not be written to.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'closeThreshold',
                        docs: [
                            'If current slot is greater than rolledover_slot + close_threshold and',
                            "the account is empty it can be closed. No 'close' functionality has been",
                            'implemented yet.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'additionalBytes',
                        docs: [
                            'Placeholder for bytes of additional accounts which are tied to the',
                            'Merkle trees operation and need to be rolled over as well.'
                        ],
                        type: 'u64'
                    }
                ]
            }
        },
        {
            name: 'TokenData',
            type: {
                kind: 'struct',
                fields: [
                    {
                        name: 'mint',
                        docs: [
                            'The mint associated with this account'
                        ],
                        type: 'publicKey'
                    },
                    {
                        name: 'owner',
                        docs: [
                            'The owner of this account.'
                        ],
                        type: 'publicKey'
                    },
                    {
                        name: 'amount',
                        docs: [
                            'The amount of tokens this account holds.'
                        ],
                        type: 'u64'
                    },
                    {
                        name: 'delegate',
                        docs: [
                            'If `delegate` is `Some` then `delegated_amount` represents',
                            'the amount authorized by the delegate'
                        ],
                        type: {
                            option: 'publicKey'
                        }
                    },
                    {
                        name: 'state',
                        docs: [
                            "The account's state"
                        ],
                        type: {
                            defined: 'AccountState'
                        }
                    },
                    {
                        name: 'tlv',
                        docs: [
                            'Placeholder for TokenExtension tlv data (unimplemented)'
                        ],
                        type: {
                            option: 'bytes'
                        }
                    }
                ]
            }
        }
    ],
    errors: [
        {
            code: 6000,
            name: 'PublicKeyAmountMissmatch',
            msg: 'public keys and amounts must be of same length'
        },
        {
            code: 6001,
            name: 'ComputeInputSumFailed',
            msg: 'ComputeInputSumFailed'
        },
        {
            code: 6002,
            name: 'ComputeOutputSumFailed',
            msg: 'ComputeOutputSumFailed'
        },
        {
            code: 6003,
            name: 'ComputeCompressSumFailed',
            msg: 'ComputeCompressSumFailed'
        },
        {
            code: 6004,
            name: 'ComputeDecompressSumFailed',
            msg: 'ComputeDecompressSumFailed'
        },
        {
            code: 6005,
            name: 'SumCheckFailed',
            msg: 'SumCheckFailed'
        },
        {
            code: 6006,
            name: 'DecompressRecipientUndefinedForDecompress',
            msg: 'DecompressRecipientUndefinedForDecompress'
        },
        {
            code: 6007,
            name: 'CompressedPdaUndefinedForDecompress',
            msg: 'CompressedPdaUndefinedForDecompress'
        },
        {
            code: 6008,
            name: 'DeCompressAmountUndefinedForDecompress',
            msg: 'DeCompressAmountUndefinedForDecompress'
        },
        {
            code: 6009,
            name: 'CompressedPdaUndefinedForCompress',
            msg: 'CompressedPdaUndefinedForCompress'
        },
        {
            code: 6010,
            name: 'DeCompressAmountUndefinedForCompress',
            msg: 'DeCompressAmountUndefinedForCompress'
        },
        {
            code: 6011,
            name: 'DelegateSignerCheckFailed',
            msg: 'DelegateSignerCheckFailed'
        },
        {
            code: 6012,
            name: 'MintTooLarge',
            msg: 'Minted amount greater than u64::MAX'
        },
        {
            code: 6013,
            name: 'SplTokenSupplyMismatch',
            msg: 'SplTokenSupplyMismatch'
        },
        {
            code: 6014,
            name: 'HeapMemoryCheckFailed',
            msg: 'HeapMemoryCheckFailed'
        },
        {
            code: 6015,
            name: 'InstructionNotCallable',
            msg: 'The instruction is not callable'
        },
        {
            code: 6016,
            name: 'ArithmeticUnderflow',
            msg: 'ArithmeticUnderflow'
        },
        {
            code: 6017,
            name: 'HashToFieldError',
            msg: 'HashToFieldError'
        },
        {
            code: 6018,
            name: 'InvalidAuthorityMint',
            msg: 'Expected the authority to be also a mint authority'
        },
        {
            code: 6019,
            name: 'InvalidFreezeAuthority',
            msg: 'Provided authority is not the freeze authority'
        },
        {
            code: 6020,
            name: 'InvalidDelegateIndex'
        },
        {
            code: 6021,
            name: 'TokenPoolPdaUndefined'
        },
        {
            code: 6022,
            name: 'IsTokenPoolPda',
            msg: 'Compress or decompress recipient is the same account as the token pool pda.'
        },
        {
            code: 6023,
            name: 'InvalidTokenPoolPda'
        },
        {
            code: 6024,
            name: 'NoInputTokenAccountsProvided'
        },
        {
            code: 6025,
            name: 'NoInputsProvided'
        },
        {
            code: 6026,
            name: 'MintHasNoFreezeAuthority'
        },
        {
            code: 6027,
            name: 'MintWithInvalidExtension'
        },
        {
            code: 6028,
            name: 'InsufficientTokenAccountBalance',
            msg: 'The token account balance is less than the remaining amount.'
        }
    ]
};
// TODO: Clean up
exports.UtxoErrorCode = void 0;
(function(UtxoErrorCode) {
    UtxoErrorCode["NEGATIVE_LAMPORTS"] = "NEGATIVE_LAMPORTS";
    UtxoErrorCode["NOT_U64"] = "NOT_U64";
    UtxoErrorCode["BLINDING_EXCEEDS_FIELD_SIZE"] = "BLINDING_EXCEEDS_FIELD_SIZE";
})(exports.UtxoErrorCode || (exports.UtxoErrorCode = {}));
exports.SelectInUtxosErrorCode = void 0;
(function(SelectInUtxosErrorCode) {
    SelectInUtxosErrorCode["FAILED_TO_FIND_UTXO_COMBINATION"] = "FAILED_TO_FIND_UTXO_COMBINATION";
    SelectInUtxosErrorCode["INVALID_NUMBER_OF_IN_UTXOS"] = "INVALID_NUMBER_OF_IN_UTXOS";
})(exports.SelectInUtxosErrorCode || (exports.SelectInUtxosErrorCode = {}));
exports.CreateUtxoErrorCode = void 0;
(function(CreateUtxoErrorCode) {
    CreateUtxoErrorCode["OWNER_UNDEFINED"] = "OWNER_UNDEFINED";
    CreateUtxoErrorCode["INVALID_OUTPUT_UTXO_LENGTH"] = "INVALID_OUTPUT_UTXO_LENGTH";
    CreateUtxoErrorCode["UTXO_DATA_UNDEFINED"] = "UTXO_DATA_UNDEFINED";
})(exports.CreateUtxoErrorCode || (exports.CreateUtxoErrorCode = {}));
exports.RpcErrorCode = void 0;
(function(RpcErrorCode) {
    RpcErrorCode["CONNECTION_UNDEFINED"] = "CONNECTION_UNDEFINED";
    RpcErrorCode["RPC_PUBKEY_UNDEFINED"] = "RPC_PUBKEY_UNDEFINED";
    RpcErrorCode["RPC_METHOD_NOT_IMPLEMENTED"] = "RPC_METHOD_NOT_IMPLEMENTED";
    RpcErrorCode["RPC_INVALID"] = "RPC_INVALID";
})(exports.RpcErrorCode || (exports.RpcErrorCode = {}));
exports.LookupTableErrorCode = void 0;
(function(LookupTableErrorCode) {
    LookupTableErrorCode["LOOK_UP_TABLE_UNDEFINED"] = "LOOK_UP_TABLE_UNDEFINED";
    LookupTableErrorCode["LOOK_UP_TABLE_NOT_INITIALIZED"] = "LOOK_UP_TABLE_NOT_INITIALIZED";
})(exports.LookupTableErrorCode || (exports.LookupTableErrorCode = {}));
exports.HashErrorCode = void 0;
(function(HashErrorCode) {
    HashErrorCode["NO_POSEIDON_HASHER_PROVIDED"] = "NO_POSEIDON_HASHER_PROVIDED";
})(exports.HashErrorCode || (exports.HashErrorCode = {}));
exports.ProofErrorCode = void 0;
(function(ProofErrorCode) {
    ProofErrorCode["INVALID_PROOF"] = "INVALID_PROOF";
    ProofErrorCode["PROOF_INPUT_UNDEFINED"] = "PROOF_INPUT_UNDEFINED";
    ProofErrorCode["PROOF_GENERATION_FAILED"] = "PROOF_GENERATION_FAILED";
})(exports.ProofErrorCode || (exports.ProofErrorCode = {}));
exports.MerkleTreeErrorCode = void 0;
(function(MerkleTreeErrorCode) {
    MerkleTreeErrorCode["MERKLE_TREE_NOT_INITIALIZED"] = "MERKLE_TREE_NOT_INITIALIZED";
    MerkleTreeErrorCode["SOL_MERKLE_TREE_UNDEFINED"] = "SOL_MERKLE_TREE_UNDEFINED";
    MerkleTreeErrorCode["MERKLE_TREE_UNDEFINED"] = "MERKLE_TREE_UNDEFINED";
    MerkleTreeErrorCode["INPUT_UTXO_NOT_INSERTED_IN_MERKLE_TREE"] = "INPUT_UTXO_NOT_INSERTED_IN_MERKLE_TREE";
    MerkleTreeErrorCode["MERKLE_TREE_INDEX_UNDEFINED"] = "MERKLE_TREE_INDEX_UNDEFINED";
    MerkleTreeErrorCode["MERKLE_TREE_SET_SPACE_UNDEFINED"] = "MERKLE_TREE_SET_SPACE_UNDEFINED";
})(exports.MerkleTreeErrorCode || (exports.MerkleTreeErrorCode = {}));
exports.UtilsErrorCode = void 0;
(function(UtilsErrorCode) {
    UtilsErrorCode["ACCOUNT_NAME_UNDEFINED_IN_IDL"] = "ACCOUNT_NAME_UNDEFINED_IN_IDL";
    UtilsErrorCode["PROPERTY_UNDEFINED"] = "PROPERTY_UNDEFINED";
    UtilsErrorCode["LOOK_UP_TABLE_CREATION_FAILED"] = "LOOK_UP_TABLE_CREATION_FAILED";
    UtilsErrorCode["UNSUPPORTED_ARCHITECTURE"] = "UNSUPPORTED_ARCHITECTURE";
    UtilsErrorCode["UNSUPPORTED_PLATFORM"] = "UNSUPPORTED_PLATFORM";
    UtilsErrorCode["ACCOUNTS_UNDEFINED"] = "ACCOUNTS_UNDEFINED";
    UtilsErrorCode["INVALID_NUMBER"] = "INVALID_NUMBER";
})(exports.UtilsErrorCode || (exports.UtilsErrorCode = {}));
class MetaError extends Error {
    constructor(code, functionName, codeMessage){
        super(`${code}: ${codeMessage}`);
        this.code = code;
        this.functionName = functionName;
        this.codeMessage = codeMessage;
    }
}
class UtxoError extends MetaError {
}
class SelectInUtxosError extends MetaError {
}
class CreateUtxoError extends MetaError {
}
class RpcError extends MetaError {
}
class LookupTableError extends MetaError {
}
class HashError extends MetaError {
}
class ProofError extends MetaError {
}
class MerkleTreeError extends MetaError {
}
class UtilsError extends MetaError {
}
/**
 * @internal
 */ const PublicKeyFromString = superstruct.coerce(superstruct.instance(web3_js.PublicKey), superstruct.string(), (value)=>new web3_js.PublicKey(value));
/**
 * @internal
 */ const ArrayFromString = superstruct.coerce(superstruct.instance(Array), superstruct.string(), (value)=>Array.from(new web3_js.PublicKey(value).toBytes()));
/**
 * @internal
 */ const BN254FromString = superstruct.coerce(superstruct.instance(anchor.BN), superstruct.string(), (value)=>{
    return createBN254(value, 'base58');
});
const BNFromInt = superstruct.coerce(superstruct.instance(anchor.BN), superstruct.number(), (value)=>{
    // Check if the number is safe
    if (Number.isSafeInteger(value)) {
        return bn(value);
    } else {
        // Convert to string if the number is unsafe
        return bn(value.toString(), 10);
    }
});
/**
 * @internal
 */ const Base64EncodedCompressedAccountDataResult = superstruct.coerce(superstruct.string(), superstruct.string(), (value)=>value === '' ? null : value);
/**
 * @internal
 */ function createRpcResult(result) {
    return superstruct.union([
        superstruct.type({
            jsonrpc: superstruct.literal('2.0'),
            id: superstruct.string(),
            result
        }),
        superstruct.type({
            jsonrpc: superstruct.literal('2.0'),
            id: superstruct.string(),
            error: superstruct.type({
                code: superstruct.unknown(),
                message: superstruct.string(),
                data: superstruct.nullable(superstruct.any())
            })
        })
    ]);
}
/**
 * @internal
 */ const UnknownRpcResult = createRpcResult(superstruct.unknown());
/**
 * @internal
 */ function jsonRpcResult(schema) {
    return superstruct.coerce(createRpcResult(schema), UnknownRpcResult, (value)=>{
        if ('error' in value) {
            return value;
        } else {
            return Object.assign(Object.assign({}, value), {
                result: superstruct.create(value.result, schema)
            });
        }
    });
}
/**
 * @internal
 */ function jsonRpcResultAndContext(value) {
    return jsonRpcResult(superstruct.type({
        context: superstruct.type({
            slot: superstruct.number()
        }),
        value
    }));
}
/**
 * @internal
 */ const CompressedAccountResult = superstruct.type({
    address: superstruct.nullable(ArrayFromString),
    hash: BN254FromString,
    data: superstruct.nullable(superstruct.type({
        data: Base64EncodedCompressedAccountDataResult,
        dataHash: BN254FromString,
        discriminator: BNFromInt
    })),
    lamports: BNFromInt,
    owner: PublicKeyFromString,
    leafIndex: superstruct.number(),
    tree: PublicKeyFromString,
    seq: superstruct.nullable(BNFromInt),
    slotCreated: BNFromInt
});
const TokenDataResult = superstruct.type({
    mint: PublicKeyFromString,
    owner: PublicKeyFromString,
    amount: BNFromInt,
    delegate: superstruct.nullable(PublicKeyFromString),
    state: superstruct.string()
});
/**
 * @internal
 */ const CompressedTokenAccountResult = superstruct.type({
    tokenData: TokenDataResult,
    account: CompressedAccountResult
});
/**
 * @internal
 */ const MultipleCompressedAccountsResult = superstruct.type({
    items: superstruct.array(CompressedAccountResult)
});
/**
 * @internal
 */ const CompressedAccountsByOwnerResult = superstruct.type({
    items: superstruct.array(CompressedAccountResult),
    cursor: superstruct.nullable(superstruct.string())
});
/**
 * @internal
 */ const CompressedTokenAccountsByOwnerOrDelegateResult = superstruct.type({
    items: superstruct.array(CompressedTokenAccountResult),
    cursor: superstruct.nullable(superstruct.string())
});
/**
 * @internal
 */ const SlotResult = superstruct.number();
/**
 * @internal
 */ const HealthResult = superstruct.string();
/**
 * @internal
 */ const LatestNonVotingSignaturesResult = superstruct.type({
    items: superstruct.array(superstruct.type({
        signature: superstruct.string(),
        slot: superstruct.number(),
        blockTime: superstruct.number(),
        error: superstruct.nullable(superstruct.string())
    }))
});
/**
 * @internal
 */ const LatestNonVotingSignaturesResultPaginated = superstruct.type({
    items: superstruct.array(superstruct.type({
        signature: superstruct.string(),
        slot: superstruct.number(),
        blockTime: superstruct.number()
    })),
    cursor: superstruct.nullable(superstruct.string())
});
/**
 * @internal
 */ const MerkeProofResult = superstruct.type({
    hash: BN254FromString,
    leafIndex: superstruct.number(),
    merkleTree: PublicKeyFromString,
    proof: superstruct.array(BN254FromString),
    rootSeq: superstruct.number(),
    root: BN254FromString
});
/**
 * @internal
 */ const NewAddressProofResult = superstruct.type({
    address: BN254FromString,
    nextIndex: superstruct.number(),
    merkleTree: PublicKeyFromString,
    proof: superstruct.array(BN254FromString),
    rootSeq: superstruct.number(),
    root: BN254FromString,
    lowerRangeAddress: BN254FromString,
    higherRangeAddress: BN254FromString,
    lowElementLeafIndex: superstruct.number()
});
/**
 * @internal
 */ const CompressedProofResult = superstruct.type({
    a: superstruct.array(superstruct.number()),
    b: superstruct.array(superstruct.number()),
    c: superstruct.array(superstruct.number())
});
/**
 * @internal
 */ const ValidityProofResult = superstruct.type({
    compressedProof: CompressedProofResult,
    leafIndices: superstruct.array(superstruct.number()),
    leaves: superstruct.array(BN254FromString),
    rootIndices: superstruct.array(superstruct.number()),
    roots: superstruct.array(BN254FromString),
    merkleTrees: superstruct.array(PublicKeyFromString)
});
/**
 * @internal
 */ const MultipleMerkleProofsResult = superstruct.array(MerkeProofResult);
/**
 * @internal
 */ const BalanceResult = superstruct.type({
    amount: BNFromInt
});
const NativeBalanceResult = BNFromInt;
const TokenBalanceResult = superstruct.type({
    balance: BNFromInt,
    mint: PublicKeyFromString
});
const TokenBalanceListResult = superstruct.type({
    tokenBalances: superstruct.array(TokenBalanceResult),
    cursor: superstruct.nullable(superstruct.string())
});
const TokenBalanceListResultV2 = superstruct.type({
    items: superstruct.array(TokenBalanceResult),
    cursor: superstruct.nullable(superstruct.string())
});
const CompressedMintTokenHoldersResult = superstruct.type({
    cursor: superstruct.nullable(superstruct.string()),
    items: superstruct.array(superstruct.type({
        balance: BNFromInt,
        owner: PublicKeyFromString
    }))
});
const AccountProofResult = superstruct.type({
    hash: superstruct.array(superstruct.number()),
    root: superstruct.array(superstruct.number()),
    proof: superstruct.array(superstruct.array(superstruct.number()))
});
const toUnixTimestamp = (blockTime)=>{
    return new Date(blockTime).getTime();
};
const SignatureListResult = superstruct.type({
    items: superstruct.array(superstruct.type({
        blockTime: superstruct.number(),
        signature: superstruct.string(),
        slot: superstruct.number()
    }))
});
const SignatureListWithCursorResult = superstruct.type({
    items: superstruct.array(superstruct.type({
        blockTime: superstruct.number(),
        signature: superstruct.string(),
        slot: superstruct.number()
    })),
    cursor: superstruct.nullable(superstruct.string())
});
const CompressedTransactionResult = superstruct.type({
    compressionInfo: superstruct.type({
        closedAccounts: superstruct.array(superstruct.type({
            account: CompressedAccountResult,
            optionalTokenData: superstruct.nullable(TokenDataResult)
        })),
        openedAccounts: superstruct.array(superstruct.type({
            account: CompressedAccountResult,
            optionalTokenData: superstruct.nullable(TokenDataResult)
        }))
    }),
    /// TODO: add transaction struct
    /// https://github.com/solana-labs/solana/blob/27eff8408b7223bb3c4ab70523f8a8dca3ca6645/transaction-status/src/lib.rs#L1061
    transaction: superstruct.any()
});
/** @internal */ function parseAccountData({ discriminator, data, dataHash }) {
    return {
        discriminator: discriminator.toArray('le', 8),
        data: require$$0.Buffer.from(data, 'base64'),
        dataHash: dataHash.toArray('le', 32)
    };
}
/** @internal */ async function getCompressedTokenAccountsByOwnerOrDelegate(rpc, ownerOrDelegate, options, filterByDelegate = false) {
    var _a, _b;
    const endpoint = filterByDelegate ? 'getCompressedTokenAccountsByDelegate' : 'getCompressedTokenAccountsByOwner';
    const propertyToCheck = filterByDelegate ? 'delegate' : 'owner';
    const unsafeRes = await rpcRequest(rpc.compressionApiEndpoint, endpoint, {
        [propertyToCheck]: ownerOrDelegate.toBase58(),
        mint: (_a = options.mint) === null || _a === void 0 ? void 0 : _a.toBase58(),
        limit: (_b = options.limit) === null || _b === void 0 ? void 0 : _b.toNumber(),
        cursor: options.cursor
    });
    const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(CompressedTokenAccountsByOwnerOrDelegateResult));
    if ('error' in res) {
        throw new web3_js.SolanaJSONRPCError(res.error, `failed to get info for compressed accounts by ${propertyToCheck} ${ownerOrDelegate.toBase58()}`);
    }
    if (res.result.value === null) {
        throw new Error('not implemented: NULL result');
    }
    const accounts = [];
    res.result.value.items.map((item)=>{
        var _a;
        const _account = item.account;
        const _tokenData = item.tokenData;
        const compressedAccount = createCompressedAccountWithMerkleContext(createMerkleContext(_account.tree, mockNullifierQueue, _account.hash.toArray('be', 32), _account.leafIndex), _account.owner, bn(_account.lamports), _account.data ? parseAccountData(_account.data) : undefined, _account.address || undefined);
        const parsed = {
            mint: _tokenData.mint,
            owner: _tokenData.owner,
            amount: _tokenData.amount,
            delegate: _tokenData.delegate,
            state: [
                'uninitialized',
                'initialized',
                'frozen'
            ].indexOf(_tokenData.state),
            tlv: null
        };
        if (((_a = parsed[propertyToCheck]) === null || _a === void 0 ? void 0 : _a.toBase58()) !== ownerOrDelegate.toBase58()) {
            throw new Error(`RPC returned token account with ${propertyToCheck} different from requested ${propertyToCheck}`);
        }
        accounts.push({
            compressedAccount,
            parsed
        });
    });
    /// TODO: consider custom or different sort. Most recent here.
    return {
        items: accounts.sort((a, b)=>b.compressedAccount.leafIndex - a.compressedAccount.leafIndex),
        cursor: res.result.value.cursor
    };
}
/** @internal */ function buildCompressedAccountWithMaybeTokenData(accountStructWithOptionalTokenData) {
    const compressedAccountResult = accountStructWithOptionalTokenData.account;
    const tokenDataResult = accountStructWithOptionalTokenData.optionalTokenData;
    const compressedAccount = createCompressedAccountWithMerkleContext(createMerkleContext(compressedAccountResult.merkleTree, mockNullifierQueue, compressedAccountResult.hash.toArray('be', 32), compressedAccountResult.leafIndex), compressedAccountResult.owner, bn(compressedAccountResult.lamports), compressedAccountResult.data ? parseAccountData(compressedAccountResult.data) : undefined, compressedAccountResult.address || undefined);
    if (tokenDataResult === null) {
        return {
            account: compressedAccount,
            maybeTokenData: null
        };
    }
    const parsed = {
        mint: tokenDataResult.mint,
        owner: tokenDataResult.owner,
        amount: tokenDataResult.amount,
        delegate: tokenDataResult.delegate,
        state: [
            'uninitialized',
            'initialized',
            'frozen'
        ].indexOf(tokenDataResult.state),
        tlv: null
    };
    return {
        account: compressedAccount,
        maybeTokenData: parsed
    };
}
/**
 * Establish a Compression-compatible JSON RPC connection
 *
 * @param endpointOrWeb3JsConnection    endpoint to the solana cluster or
 *                                      Connection object
 * @param compressionApiEndpoint        Endpoint to the compression server
 * @param proverEndpoint                Endpoint to the prover server. defaults
 *                                      to endpoint
 * @param connectionConfig              Optional connection config
 */ function createRpc(endpointOrWeb3JsConnection = 'http://127.0.0.1:8899', compressionApiEndpoint = 'http://127.0.0.1:8784', proverEndpoint = 'http://127.0.0.1:3001', config) {
    const endpoint = typeof endpointOrWeb3JsConnection === 'string' ? endpointOrWeb3JsConnection : endpointOrWeb3JsConnection.rpcEndpoint;
    return new Rpc(endpoint, compressionApiEndpoint, proverEndpoint, config);
}
/** @internal */ const rpcRequest = async (rpcEndpoint, method, params = [], convertToCamelCase = true, debug = false)=>{
    const body = JSON.stringify({
        jsonrpc: '2.0',
        id: 'test-account',
        method: method,
        params: params
    });
    if (debug) {
        const generateCurlSnippet = ()=>{
            const escapedBody = body.replace(/"/g, '\\"');
            return `curl -X POST ${rpcEndpoint} \\
     -H "Content-Type: application/json" \\
     -d "${escapedBody}"`;
        };
        console.log('Debug: Stack trace:');
        console.log(new Error().stack);
        console.log('\nDebug: curl:');
        console.log(generateCurlSnippet());
        console.log('\n');
    }
    const response = await fetch(rpcEndpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: body
    });
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }
    if (convertToCamelCase) {
        const res = await response.json();
        return toCamelCase(res);
    }
    return await response.json();
};
/** @internal */ const proverRequest = async (proverEndpoint, method, params = [], log = false)=>{
    let logMsg = '';
    if (log) {
        logMsg = `Proof generation for method:${method}`;
        console.time(logMsg);
    }
    let body;
    if (method === 'inclusion') {
        body = JSON.stringify({
            'input-compressed-accounts': params
        });
    } else if (method === 'new-address') {
        body = JSON.stringify({
            'new-addresses': params
        });
    } else if (method === 'combined') {
        body = JSON.stringify({
            'input-compressed-accounts': params[0],
            'new-addresses': params[1]
        });
    }
    const response = await fetch(`${proverEndpoint}/prove`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: body
    });
    if (!response.ok) {
        throw new Error(`Error fetching proof: ${response.statusText}`);
    }
    const data = await response.json();
    const parsed = proofFromJsonStruct(data);
    const compressedProof = negateAndCompressProof(parsed);
    if (log) console.timeEnd(logMsg);
    return compressedProof;
};
function convertMerkleProofsWithContextToHex(merkleProofsWithContext) {
    const inputs = [];
    for(let i = 0; i < merkleProofsWithContext.length; i++){
        const input = {
            root: toHex(merkleProofsWithContext[i].root),
            pathIndex: merkleProofsWithContext[i].leafIndex,
            pathElements: merkleProofsWithContext[i].merkleProof.map((hex)=>toHex(hex)),
            leaf: toHex(bn(merkleProofsWithContext[i].hash))
        };
        inputs.push(input);
    }
    return inputs;
}
function convertNonInclusionMerkleProofInputsToHex(nonInclusionMerkleProofInputs) {
    const inputs = [];
    for(let i = 0; i < nonInclusionMerkleProofInputs.length; i++){
        const input = {
            root: toHex(nonInclusionMerkleProofInputs[i].root),
            value: toHex(nonInclusionMerkleProofInputs[i].value),
            pathIndex: nonInclusionMerkleProofInputs[i].indexHashedIndexedElementLeaf.toNumber(),
            pathElements: nonInclusionMerkleProofInputs[i].merkleProofHashedIndexedElementLeaf.map((hex)=>toHex(hex)),
            nextIndex: nonInclusionMerkleProofInputs[i].nextIndex.toNumber(),
            leafLowerRangeValue: toHex(nonInclusionMerkleProofInputs[i].leafLowerRangeValue),
            leafHigherRangeValue: toHex(nonInclusionMerkleProofInputs[i].leafHigherRangeValue)
        };
        inputs.push(input);
    }
    return inputs;
}
/// TODO: replace with dynamic nullifierQueue
const mockNullifierQueue = defaultTestStateTreeAccounts().nullifierQueue;
const mockAddressQueue = defaultTestStateTreeAccounts().addressQueue;
/**
 *
 */ class Rpc extends web3_js.Connection {
    /**
     * Establish a Compression-compatible JSON RPC connection
     *
     * @param endpoint                      Endpoint to the solana cluster
     * @param compressionApiEndpoint        Endpoint to the compression server
     * @param proverEndpoint                Endpoint to the prover server.
     * @param connectionConfig              Optional connection config
     */ constructor(endpoint, compressionApiEndpoint, proverEndpoint, config){
        super(endpoint, config || 'confirmed');
        this.compressionApiEndpoint = compressionApiEndpoint;
        this.proverEndpoint = proverEndpoint;
    }
    /**
     * Fetch the compressed account for the specified account address or hash
     */ async getCompressedAccount(address, hash) {
        if (!hash && !address) {
            throw new Error('Either hash or address must be provided');
        }
        if (hash && address) {
            throw new Error('Only one of hash or address must be provided');
        }
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getCompressedAccount', {
            hash: hash ? encodeBN254toBase58(hash) : undefined,
            address: address ? encodeBN254toBase58(address) : undefined
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(superstruct.nullable(CompressedAccountResult)));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get info for compressed account ${hash ? hash.toString() : address ? address.toString() : ''}`);
        }
        if (res.result.value === null) {
            return null;
        }
        const item = res.result.value;
        const account = createCompressedAccountWithMerkleContext(createMerkleContext(item.tree, mockNullifierQueue, item.hash.toArray('be', 32), item.leafIndex), item.owner, bn(item.lamports), item.data ? parseAccountData(item.data) : undefined, item.address || undefined);
        return account;
    }
    /**
     * Fetch the compressed balance for the specified account address or hash
     */ async getCompressedBalance(address, hash) {
        if (!hash && !address) {
            throw new Error('Either hash or address must be provided');
        }
        if (hash && address) {
            throw new Error('Only one of hash or address must be provided');
        }
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getCompressedBalance', {
            hash: hash ? encodeBN254toBase58(hash) : undefined,
            address: address ? encodeBN254toBase58(address) : undefined
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(NativeBalanceResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get balance for compressed account ${hash ? hash.toString() : address ? address.toString() : ''}`);
        }
        if (res.result.value === null) {
            return bn(0);
        }
        return bn(res.result.value);
    }
    /// TODO: validate that this is just for sol accounts
    /**
     * Fetch the total compressed balance for the specified owner public key
     */ async getCompressedBalanceByOwner(owner) {
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getCompressedBalanceByOwner', {
            owner: owner.toBase58()
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(NativeBalanceResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get balance for compressed account ${owner.toBase58()}`);
        }
        if (res.result.value === null) {
            return bn(0);
        }
        return bn(res.result.value);
    }
    /**
     * Fetch the latest merkle proof for the specified account hash from the
     * cluster
     */ async getCompressedAccountProof(hash) {
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getCompressedAccountProof', {
            hash: encodeBN254toBase58(hash)
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(MerkeProofResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get proof for compressed account ${hash.toString()}`);
        }
        if (res.result.value === null) {
            throw new Error(`failed to get proof for compressed account ${hash.toString()}`);
        }
        const value = {
            hash: res.result.value.hash.toArray('be', 32),
            merkleTree: res.result.value.merkleTree,
            leafIndex: res.result.value.leafIndex,
            merkleProof: res.result.value.proof,
            nullifierQueue: mockNullifierQueue,
            rootIndex: res.result.value.rootSeq % 2400,
            root: res.result.value.root
        };
        return value;
    }
    /**
     * Fetch all the account info for multiple compressed accounts specified by
     * an array of account hashes
     */ async getMultipleCompressedAccounts(hashes) {
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getMultipleCompressedAccounts', {
            hashes: hashes.map((hash)=>encodeBN254toBase58(hash))
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(MultipleCompressedAccountsResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get info for compressed accounts ${hashes.map((hash)=>encodeBN254toBase58(hash)).join(', ')}`);
        }
        if (res.result.value === null) {
            throw new Error(`failed to get info for compressed accounts ${hashes.map((hash)=>encodeBN254toBase58(hash)).join(', ')}`);
        }
        const accounts = [];
        res.result.value.items.map((item)=>{
            const account = createCompressedAccountWithMerkleContext(createMerkleContext(item.tree, mockNullifierQueue, item.hash.toArray('be', 32), item.leafIndex), item.owner, bn(item.lamports), item.data ? parseAccountData(item.data) : undefined, item.address || undefined);
            accounts.push(account);
        });
        return accounts.sort((a, b)=>b.leafIndex - a.leafIndex);
    }
    /**
     * Fetch the latest merkle proofs for multiple compressed accounts specified
     * by an array account hashes
     */ async getMultipleCompressedAccountProofs(hashes) {
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getMultipleCompressedAccountProofs', hashes.map((hash)=>encodeBN254toBase58(hash)));
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(superstruct.array(MerkeProofResult)));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get proofs for compressed accounts ${hashes.map((hash)=>encodeBN254toBase58(hash)).join(', ')}`);
        }
        if (res.result.value === null) {
            throw new Error(`failed to get proofs for compressed accounts ${hashes.map((hash)=>encodeBN254toBase58(hash)).join(', ')}`);
        }
        const merkleProofs = [];
        for (const proof of res.result.value){
            const value = {
                hash: proof.hash.toArray('be', 32),
                merkleTree: proof.merkleTree,
                leafIndex: proof.leafIndex,
                merkleProof: proof.proof,
                nullifierQueue: mockAddressQueue,
                rootIndex: proof.rootSeq % 2400,
                root: proof.root
            };
            merkleProofs.push(value);
        }
        return merkleProofs;
    }
    /**
     * Fetch all the compressed accounts owned by the specified public key.
     * Owner can be a program or user account
     */ async getCompressedAccountsByOwner(owner, config) {
        var _a;
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getCompressedAccountsByOwner', {
            owner: owner.toBase58(),
            filters: (config === null || config === void 0 ? void 0 : config.filters) || [],
            dataSlice: config === null || config === void 0 ? void 0 : config.dataSlice,
            cursor: config === null || config === void 0 ? void 0 : config.cursor,
            limit: (_a = config === null || config === void 0 ? void 0 : config.limit) === null || _a === void 0 ? void 0 : _a.toNumber()
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(CompressedAccountsByOwnerResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get info for compressed accounts owned by ${owner.toBase58()}`);
        }
        if (res.result.value === null) {
            return {
                items: [],
                cursor: null
            };
        }
        const accounts = [];
        res.result.value.items.map((item)=>{
            const account = createCompressedAccountWithMerkleContext(createMerkleContext(item.tree, mockNullifierQueue, item.hash.toArray('be', 32), item.leafIndex), item.owner, bn(item.lamports), item.data ? parseAccountData(item.data) : undefined, item.address || undefined);
            accounts.push(account);
        });
        return {
            items: accounts.sort((a, b)=>b.leafIndex - a.leafIndex),
            cursor: res.result.value.cursor
        };
    }
    /**
     * Fetch all the compressed token accounts owned by the specified public
     * key. Owner can be a program or user account
     */ async getCompressedTokenAccountsByOwner(owner, options) {
        if (!options) options = {};
        return await getCompressedTokenAccountsByOwnerOrDelegate(this, owner, options, false);
    }
    /**
     * Fetch all the compressed accounts delegated to the specified public key.
     */ async getCompressedTokenAccountsByDelegate(delegate, options) {
        if (!options) options = {};
        return getCompressedTokenAccountsByOwnerOrDelegate(this, delegate, options, true);
    }
    /**
     * Fetch the compressed token balance for the specified account hash
     */ async getCompressedTokenAccountBalance(hash) {
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getCompressedTokenAccountBalance', {
            hash: encodeBN254toBase58(hash)
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(BalanceResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get balance for compressed token account ${hash.toString()}`);
        }
        if (res.result.value === null) {
            throw new Error(`failed to get balance for compressed token account ${hash.toString()}`);
        }
        return {
            amount: bn(res.result.value.amount)
        };
    }
    /**
     * @deprecated use {@link getCompressedTokenBalancesByOwnerV2} instead.
     *
     * Fetch all the compressed token balances owned by the specified public
     * key. Can filter by mint. Returns without context.
     */ async getCompressedTokenBalancesByOwner(owner, options) {
        var _a, _b;
        if (!options) options = {};
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getCompressedTokenBalancesByOwner', {
            owner: owner.toBase58(),
            mint: (_a = options.mint) === null || _a === void 0 ? void 0 : _a.toBase58(),
            limit: (_b = options.limit) === null || _b === void 0 ? void 0 : _b.toNumber(),
            cursor: options.cursor
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(TokenBalanceListResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get compressed token balances for owner ${owner.toBase58()}`);
        }
        if (res.result.value === null) {
            throw new Error(`failed to get compressed token balances for owner ${owner.toBase58()}`);
        }
        const maybeFiltered = options.mint ? res.result.value.tokenBalances.filter((tokenBalance)=>tokenBalance.mint.toBase58() === options.mint.toBase58()) : res.result.value.tokenBalances;
        return {
            items: maybeFiltered,
            cursor: res.result.value.cursor
        };
    }
    /**
     * Fetch the compressed token balances owned by the specified public
     * key. Paginated. Can filter by mint. Returns with context.
     */ async getCompressedTokenBalancesByOwnerV2(owner, options) {
        var _a, _b;
        if (!options) options = {};
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getCompressedTokenBalancesByOwnerV2', {
            owner: owner.toBase58(),
            mint: (_a = options.mint) === null || _a === void 0 ? void 0 : _a.toBase58(),
            limit: (_b = options.limit) === null || _b === void 0 ? void 0 : _b.toNumber(),
            cursor: options.cursor
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(TokenBalanceListResultV2));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get compressed token balances for owner ${owner.toBase58()}`);
        }
        if (res.result.value === null) {
            throw new Error(`failed to get compressed token balances for owner ${owner.toBase58()}`);
        }
        const maybeFiltered = options.mint ? res.result.value.items.filter((tokenBalance)=>tokenBalance.mint.toBase58() === options.mint.toBase58()) : res.result.value.items;
        return {
            context: res.result.context,
            value: {
                items: maybeFiltered,
                cursor: res.result.value.cursor
            }
        };
    }
    /**
     * Returns confirmed compression signatures for transactions involving the specified
     * account hash forward in time from genesis to the most recent confirmed
     * block
     *
     * @param hash queried account hash
     */ async getCompressionSignaturesForAccount(hash) {
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getCompressionSignaturesForAccount', {
            hash: encodeBN254toBase58(hash)
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(SignatureListResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get signatures for compressed account ${hash.toString()}`);
        }
        return res.result.value.items;
    }
    /**
     * Fetch a confirmed or finalized transaction from the cluster. Return with
     * CompressionInfo
     */ async getTransactionWithCompressionInfo(signature) {
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getTransactionWithCompressionInfo', {
            signature
        });
        const res = superstruct.create(unsafeRes, jsonRpcResult(CompressedTransactionResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, 'failed to get slot');
        }
        if (res.result.transaction === null) return null;
        const closedAccounts = [];
        const openedAccounts = [];
        res.result.compressionInfo.closedAccounts.map((item)=>{
            closedAccounts.push(buildCompressedAccountWithMaybeTokenData(item));
        });
        res.result.compressionInfo.openedAccounts.map((item)=>{
            openedAccounts.push(buildCompressedAccountWithMaybeTokenData(item));
        });
        const calculateTokenBalances = (accounts)=>{
            const balances = Object.values(accounts.reduce((acc, { maybeTokenData })=>{
                if (maybeTokenData) {
                    const { owner, mint, amount } = maybeTokenData;
                    const key = `${owner.toBase58()}_${mint.toBase58()}`;
                    if (key in acc) {
                        acc[key].amount = acc[key].amount.add(amount);
                    } else {
                        acc[key] = {
                            owner,
                            mint,
                            amount
                        };
                    }
                }
                return acc;
            }, {}));
            return balances.length > 0 ? balances : undefined;
        };
        const preTokenBalances = calculateTokenBalances(closedAccounts);
        const postTokenBalances = calculateTokenBalances(openedAccounts);
        return {
            compressionInfo: {
                closedAccounts,
                openedAccounts,
                preTokenBalances,
                postTokenBalances
            },
            transaction: res.result.transaction
        };
    }
    /**
     * Returns confirmed signatures for transactions involving the specified
     * address forward in time from genesis to the most recent confirmed block
     *
     * @param address queried compressed account address
     */ async getCompressionSignaturesForAddress(address, options) {
        var _a;
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getCompressionSignaturesForAddress', {
            address: address.toBase58(),
            cursor: options === null || options === void 0 ? void 0 : options.cursor,
            limit: (_a = options === null || options === void 0 ? void 0 : options.limit) === null || _a === void 0 ? void 0 : _a.toNumber()
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(SignatureListWithCursorResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get signatures for address ${address.toBase58()}`);
        }
        if (res.result.value === null) {
            throw new Error(`failed to get signatures for address ${address.toBase58()}`);
        }
        return res.result.value;
    }
    /**
     * Returns confirmed signatures for compression transactions involving the
     * specified account owner forward in time from genesis to the
     * most recent confirmed block
     *
     * @param owner queried owner public key
     */ async getCompressionSignaturesForOwner(owner, options) {
        var _a;
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getCompressionSignaturesForOwner', {
            owner: owner.toBase58(),
            cursor: options === null || options === void 0 ? void 0 : options.cursor,
            limit: (_a = options === null || options === void 0 ? void 0 : options.limit) === null || _a === void 0 ? void 0 : _a.toNumber()
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(SignatureListWithCursorResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get signatures for owner ${owner.toBase58()}`);
        }
        if (res.result.value === null) {
            throw new Error(`failed to get signatures for owner ${owner.toBase58()}`);
        }
        return res.result.value;
    }
    /**
     * Returns confirmed signatures for compression transactions involving the
     * specified token account owner forward in time from genesis to the most
     * recent confirmed block
     */ async getCompressionSignaturesForTokenOwner(owner, options) {
        var _a;
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getCompressionSignaturesForTokenOwner', {
            owner: owner.toBase58(),
            cursor: options === null || options === void 0 ? void 0 : options.cursor,
            limit: (_a = options === null || options === void 0 ? void 0 : options.limit) === null || _a === void 0 ? void 0 : _a.toNumber()
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(SignatureListWithCursorResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get signatures for owner ${owner.toBase58()}`);
        }
        if (res.result.value === null) {
            throw new Error(`failed to get signatures for owner ${owner.toBase58()}`);
        }
        return res.result.value;
    }
    /**
     * Fetch the current indexer health status
     */ async getIndexerHealth() {
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getIndexerHealth');
        const res = superstruct.create(unsafeRes, jsonRpcResult(HealthResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, 'failed to get health');
        }
        return res.result;
    }
    /**
     * Ensure that the Compression Indexer has already indexed the transaction
     */ async confirmTransactionIndexed(slot) {
        const startTime = Date.now();
        // eslint-disable-next-line no-constant-condition
        while(true){
            const indexerSlot = await this.getIndexerSlot();
            if (indexerSlot >= slot) {
                return true;
            }
            if (Date.now() - startTime > 20000) {
                // 20 seconds
                throw new Error('Timeout: Indexer slot did not reach the required slot within 20 seconds');
            }
            await new Promise((resolve)=>setTimeout(resolve, 200));
        }
    }
    /**
     * Fetch the current slot that the node is processing
     */ async getIndexerSlot() {
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getIndexerSlot');
        const res = superstruct.create(unsafeRes, jsonRpcResult(SlotResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, 'failed to get slot');
        }
        return res.result;
    }
    /**
     * Fetch all the compressed token holders for a given mint. Paginated.
     */ async getCompressedMintTokenHolders(mint, options) {
        var _a;
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getCompressedMintTokenHolders', {
            mint: mint.toBase58(),
            cursor: options === null || options === void 0 ? void 0 : options.cursor,
            limit: (_a = options === null || options === void 0 ? void 0 : options.limit) === null || _a === void 0 ? void 0 : _a.toNumber()
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(CompressedMintTokenHoldersResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, 'failed to get mint token holders');
        }
        return res.result;
    }
    /**
     * Fetch the latest compression signatures on the cluster. Results are
     * paginated.
     */ async getLatestCompressionSignatures(cursor, limit) {
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getLatestCompressionSignatures', {
            limit,
            cursor
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(LatestNonVotingSignaturesResultPaginated));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, 'failed to get latest non-voting signatures');
        }
        return res.result;
    }
    /**
     * Fetch all non-voting signatures
     */ async getLatestNonVotingSignatures(limit, cursor) {
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getLatestNonVotingSignatures', {
            limit,
            cursor
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(LatestNonVotingSignaturesResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, 'failed to get latest non-voting signatures');
        }
        return res.result;
    }
    /**
     * Fetch the latest address proofs for new unique addresses specified by an
     * array of addresses.
     *
     * the proof states that said address have not yet been created in
     * respective address tree.
     * @param addresses Array of BN254 new addresses
     * @returns Array of validity proofs for new addresses
     */ async getMultipleNewAddressProofs(addresses) {
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getMultipleNewAddressProofs', addresses.map((address)=>encodeBN254toBase58(address)));
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(superstruct.array(NewAddressProofResult)));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get proofs for new addresses ${addresses.map((address)=>encodeBN254toBase58(address)).join(', ')}`);
        }
        if (res.result.value === null) {
            throw new Error(`failed to get proofs for new addresses ${addresses.map((address)=>encodeBN254toBase58(address)).join(', ')}`);
        }
        /// Creates proof for each address
        const newAddressProofs = [];
        for (const proof of res.result.value){
            const _proof = {
                root: proof.root,
                rootIndex: proof.rootSeq % 2400,
                value: proof.address,
                leafLowerRangeValue: proof.lowerRangeAddress,
                leafHigherRangeValue: proof.higherRangeAddress,
                nextIndex: bn(proof.nextIndex),
                merkleProofHashedIndexedElementLeaf: proof.proof,
                indexHashedIndexedElementLeaf: bn(proof.lowElementLeafIndex),
                merkleTree: proof.merkleTree,
                nullifierQueue: mockAddressQueue
            };
            newAddressProofs.push(_proof);
        }
        return newAddressProofs;
    }
    /**
     * Advanced usage of getValidityProof: fetches ZKP directly from a custom
     * non-rpcprover. Note: This uses the proverEndpoint specified in the
     * constructor. For normal usage, please use {@link getValidityProof}
     * instead.
     *
     * Fetch the latest validity proof for (1) compressed accounts specified by
     * an array of account hashes. (2) new unique addresses specified by an
     * array of addresses.
     *
     * Validity proofs prove the presence of compressed accounts in state trees
     * and the non-existence of addresses in address trees, respectively. They
     * enable verification without recomputing the merkle proof path, thus
     * lowering verification and data costs.
     *
     * @param hashes        Array of BN254 hashes.
     * @param newAddresses  Array of BN254 new addresses.
     * @returns             validity proof with context
     */ async getValidityProofDirect(hashes = [], newAddresses = []) {
        let validityProof;
        if (hashes.length === 0 && newAddresses.length === 0) {
            throw new Error('Empty input. Provide hashes and/or new addresses.');
        } else if (hashes.length > 0 && newAddresses.length === 0) {
            /// inclusion
            const merkleProofsWithContext = await this.getMultipleCompressedAccountProofs(hashes);
            const inputs = convertMerkleProofsWithContextToHex(merkleProofsWithContext);
            const compressedProof = await proverRequest(this.proverEndpoint, 'inclusion', inputs, false);
            validityProof = {
                compressedProof,
                roots: merkleProofsWithContext.map((proof)=>proof.root),
                rootIndices: merkleProofsWithContext.map((proof)=>proof.rootIndex),
                leafIndices: merkleProofsWithContext.map((proof)=>proof.leafIndex),
                leaves: merkleProofsWithContext.map((proof)=>bn(proof.hash)),
                merkleTrees: merkleProofsWithContext.map((proof)=>proof.merkleTree),
                nullifierQueues: merkleProofsWithContext.map((proof)=>proof.nullifierQueue)
            };
        } else if (hashes.length === 0 && newAddresses.length > 0) {
            /// new-address
            const newAddressProofs = await this.getMultipleNewAddressProofs(newAddresses);
            const inputs = convertNonInclusionMerkleProofInputsToHex(newAddressProofs);
            const compressedProof = await proverRequest(this.proverEndpoint, 'new-address', inputs, false);
            validityProof = {
                compressedProof,
                roots: newAddressProofs.map((proof)=>proof.root),
                rootIndices: newAddressProofs.map((proof)=>proof.rootIndex),
                leafIndices: newAddressProofs.map((proof)=>proof.nextIndex.toNumber()),
                leaves: newAddressProofs.map((proof)=>bn(proof.value)),
                merkleTrees: newAddressProofs.map((proof)=>proof.merkleTree),
                nullifierQueues: newAddressProofs.map((proof)=>proof.nullifierQueue)
            };
        } else if (hashes.length > 0 && newAddresses.length > 0) {
            /// combined
            const merkleProofsWithContext = await this.getMultipleCompressedAccountProofs(hashes);
            const inputs = convertMerkleProofsWithContextToHex(merkleProofsWithContext);
            const newAddressProofs = await this.getMultipleNewAddressProofs(newAddresses);
            const newAddressInputs = convertNonInclusionMerkleProofInputsToHex(newAddressProofs);
            const compressedProof = await proverRequest(this.proverEndpoint, 'combined', [
                inputs,
                newAddressInputs
            ], false);
            validityProof = {
                compressedProof,
                roots: merkleProofsWithContext.map((proof)=>proof.root).concat(newAddressProofs.map((proof)=>proof.root)),
                rootIndices: merkleProofsWithContext.map((proof)=>proof.rootIndex).concat(newAddressProofs.map((proof)=>proof.rootIndex)),
                leafIndices: merkleProofsWithContext.map((proof)=>proof.leafIndex).concat(newAddressProofs.map((proof)=>proof.nextIndex.toNumber())),
                leaves: merkleProofsWithContext.map((proof)=>bn(proof.hash)).concat(newAddressProofs.map((proof)=>bn(proof.value))),
                merkleTrees: merkleProofsWithContext.map((proof)=>proof.merkleTree).concat(newAddressProofs.map((proof)=>proof.merkleTree)),
                nullifierQueues: merkleProofsWithContext.map((proof)=>proof.nullifierQueue).concat(newAddressProofs.map((proof)=>proof.nullifierQueue))
            };
        } else throw new Error('Invalid input');
        return validityProof;
    }
    /**
     * Fetch the latest validity proof for (1) compressed accounts specified by
     * an array of account hashes. (2) new unique addresses specified by an
     * array of addresses.
     *
     * Validity proofs prove the presence of compressed accounts in state trees
     * and the non-existence of addresses in address trees, respectively. They
     * enable verification without recomputing the merkle proof path, thus
     * lowering verification and data costs.
     *
     * @param hashes        Array of BN254 hashes.
     * @param newAddresses  Array of BN254 new addresses.
     * @returns             validity proof with context
     */ async getValidityProof(hashes = [], newAddresses = []) {
        const defaultAddressTreePublicKey = defaultTestStateTreeAccounts().addressTree;
        const defaultAddressQueuePublicKey = defaultTestStateTreeAccounts().addressQueue;
        const defaultStateTreePublicKey = defaultTestStateTreeAccounts().merkleTree;
        const defaultStateQueuePublicKey = defaultTestStateTreeAccounts().nullifierQueue;
        const formattedHashes = hashes.map((item)=>{
            return {
                hash: item,
                tree: defaultStateTreePublicKey,
                queue: defaultStateQueuePublicKey
            };
        });
        const formattedNewAddresses = newAddresses.map((item)=>{
            return {
                address: item,
                tree: defaultAddressTreePublicKey,
                queue: defaultAddressQueuePublicKey
            };
        });
        return this.getValidityProofV0(formattedHashes, formattedNewAddresses);
    }
    /**
     * Fetch the latest validity proof for (1) compressed accounts specified by
     * an array of account hashes. (2) new unique addresses specified by an
     * array of addresses.
     *
     * Validity proofs prove the presence of compressed accounts in state trees
     * and the non-existence of addresses in address trees, respectively. They
     * enable verification without recomputing the merkle proof path, thus
     * lowering verification and data costs.
     *
     * @param hashes        Array of { hash: BN254, tree: PublicKey, queue: PublicKey }.
     * @param newAddresses  Array of { address: BN254, tree: PublicKey, queue: PublicKey }.
     * @returns             validity proof with context
     */ async getValidityProofV0(hashes = [], newAddresses = []) {
        const { value } = await this.getValidityProofAndRpcContext(hashes, newAddresses);
        return value;
    }
    /**
     * Fetch the latest validity proof for (1) compressed accounts specified by
     * an array of account hashes. (2) new unique addresses specified by an
     * array of addresses. Returns with context slot.
     *
     * Validity proofs prove the presence of compressed accounts in state trees
     * and the non-existence of addresses in address trees, respectively. They
     * enable verification without recomputing the merkle proof path, thus
     * lowering verification and data costs.
     *
     * @param hashes        Array of BN254 hashes.
     * @param newAddresses  Array of BN254 new addresses. Optionally specify the
     *                      tree and queue for each address. Default to public
     *                      state tree/queue.
     * @returns             validity proof with context
     */ async getValidityProofAndRpcContext(hashes = [], newAddresses = []) {
        const unsafeRes = await rpcRequest(this.compressionApiEndpoint, 'getValidityProof', {
            hashes: hashes.map(({ hash })=>encodeBN254toBase58(hash)),
            newAddressesWithTrees: newAddresses.map(({ address, tree })=>({
                    address: encodeBN254toBase58(address),
                    tree: tree.toBase58()
                }))
        });
        const res = superstruct.create(unsafeRes, jsonRpcResultAndContext(ValidityProofResult));
        if ('error' in res) {
            throw new web3_js.SolanaJSONRPCError(res.error, `failed to get ValidityProof for compressed accounts ${hashes.map((hash)=>hash.toString())}`);
        }
        const result = res.result.value;
        if (result === null) {
            throw new Error(`failed to get ValidityProof for compressed accounts ${hashes.map((hash)=>hash.toString())}`);
        }
        const value = {
            compressedProof: result.compressedProof,
            merkleTrees: result.merkleTrees,
            leafIndices: result.leafIndices,
            nullifierQueues: [
                ...hashes.map(({ queue })=>queue),
                ...newAddresses.map(({ queue })=>queue)
            ],
            rootIndices: result.rootIndices,
            roots: result.roots,
            leaves: result.leaves
        };
        return {
            value,
            context: res.result.context
        };
    }
}
class IndexedElement {
    constructor(index, value, nextIndex){
        this.index = index;
        this.value = value;
        this.nextIndex = nextIndex;
    }
    equals(other) {
        return this.value.eq(other.value);
    }
    compareTo(other) {
        return this.value.cmp(other.value);
    }
    hash(lightWasm, nextValue) {
        try {
            const hash = lightWasm.poseidonHash([
                bn(this.value.toArray('be', 32)).toString(),
                bn(this.nextIndex).toString(),
                bn(nextValue.toArray('be', 32)).toString()
            ]);
            return hash;
        } catch (error) {
            throw new Error('Hashing failed');
        }
    }
}
class IndexedElementBundle {
    constructor(newLowElement, newElement, newElementNextValue){
        this.newLowElement = newLowElement;
        this.newElement = newElement;
        this.newElementNextValue = newElementNextValue;
    }
}
/**
 * This indexed array implementation mirrors the rust implementation of the
 * indexed merkle tree. It stores the elements of the indexed merkle tree.
 */ class IndexedArray {
    constructor(elements, currentNodeIndex, highestElementIndex){
        this.elements = elements;
        this.currentNodeIndex = currentNodeIndex;
        this.highestElementIndex = highestElementIndex;
    }
    static default() {
        return new IndexedArray([
            new IndexedElement(0, bn(0), 0)
        ], 0, 0);
    }
    get(index) {
        return this.elements[index];
    }
    length() {
        return Number(this.currentNodeIndex);
    }
    isEmpty() {
        return this.currentNodeIndex === 0;
    }
    findElement(value) {
        return this.elements.slice(0, this.length() + 1).find((node)=>node.value === value);
    }
    init() {
        try {
            const init_value = HIGHEST_ADDRESS_PLUS_ONE;
            return this.append(init_value);
        } catch (error) {
            throw new Error(`Failed to initialize IndexedArray: ${error}`);
        }
    }
    /**
     * Finds the index of the low element for the given `value` which should not be part of the array.
     * Low element is the greatest element which still has a lower value than the provided one.
     * Low elements are used in non-membership proofs.
     */ findLowElementIndex(value) {
        // Try to find element whose next element is higher than the provided value.
        for(let i = 0; i <= this.length(); i++){
            const node = this.elements[i];
            if (this.elements[node.nextIndex].value.gt(value) && node.value.lt(value)) {
                return i;
            } else if (node.value.eq(value)) {
                throw new Error('Element already exists in the array');
            }
        }
        // If no such element was found, it means that our value is going to be the greatest in the array.
        // This means that the currently greatest element is going to be the low element of our value.
        return this.highestElementIndex;
    }
    /**
     * Returns the low element for the given value and the next value for that low element.
     * Low element is the greatest element which still has lower value than the provided one.
     * Low elements are used in non-membership proofs.
     */ findLowElement(value) {
        const lowElementIndex = this.findLowElementIndex(value);
        if (lowElementIndex === undefined) return [
            undefined,
            undefined
        ];
        const lowElement = this.elements[lowElementIndex];
        return [
            lowElement,
            this.elements[lowElement.nextIndex].value
        ];
    }
    // /**
    //  * Returns the index of the low element for the given `value`, which should be the part of the array.
    //  * Low element is the greatest element which still has lower value than the provided one.
    //  * Low elements are used in non-membership proofs.
    //  */
    // public findLowElementIndexForExistingElement(
    //     value: BN,
    // ): number | undefined {
    //     for (let i = 0; i <= this.length(); i++) {
    //         const node = this.elements[i];
    //         if (this.elements[node.nextIndex].value === value) {
    //             return i;
    //         }
    //     }
    //     return undefined;
    // }
    /**
     * Returns the hash of the given element. That hash consists of:
     * - The value of the given element.
     * - The `nextIndex` of the given element.
     * - The value of the element pointed by `nextIndex`.
     */ hashElement(lightWasm, index) {
        const element = this.elements[index];
        if (!element) return undefined;
        const nextElement = this.elements[element.nextIndex];
        if (!nextElement) return undefined;
        const hash = lightWasm.poseidonHash([
            bn(element.value.toArray('be', 32)).toString(),
            bn(element.nextIndex).toString(),
            bn(nextElement.value.toArray('be', 32)).toString()
        ]);
        return hash;
    }
    /**
     * Appends a new element with the given value to the indexed array.
     * It finds the low element index and uses it to append the new element correctly.
     * @param value The value of the new element to append.
     * @returns The new element and its low element after insertion.
     */ append(value) {
        const lowElementIndex = this.findLowElementIndex(value);
        if (lowElementIndex === undefined) {
            throw new Error('Low element index not found.');
        }
        return this.appendWithLowElementIndex(lowElementIndex, value);
    }
    /**
     * Appends a new element with the given value to the indexed array using a specific low element index.
     * This method ensures the new element is placed correctly relative to the low element.
     * @param lowElementIndex The index of the low element.
     * @param value The value of the new element to append.
     * @returns The new element and its updated low element.
     */ appendWithLowElementIndex(lowElementIndex, value) {
        const lowElement = this.elements[lowElementIndex];
        if (lowElement.nextIndex === 0) {
            if (value.lte(lowElement.value)) {
                throw new Error('New element value must be greater than the low element value.');
            }
        } else {
            const nextElement = this.elements[lowElement.nextIndex];
            if (value.lte(lowElement.value)) {
                throw new Error('New element value must be greater than the low element value.');
            }
            if (value.gte(nextElement.value)) {
                throw new Error('New element value must be less than the next element value.');
            }
        }
        const newElementBundle = this.newElementWithLowElementIndex(lowElementIndex, value);
        // If the old low element wasn't pointing to any element, it means that:
        //
        // * It used to be the highest element.
        // * Our new element, which we are appending, is going the be the
        //   highest element.
        //
        // Therefore, we need to save the new element index as the highest
        // index.
        if (lowElement.nextIndex === 0) {
            this.highestElementIndex = newElementBundle.newElement.index;
        }
        // Insert new node.
        this.currentNodeIndex = newElementBundle.newElement.index;
        this.elements[this.length()] = newElementBundle.newElement;
        // Update low element.
        this.elements[lowElementIndex] = newElementBundle.newLowElement;
        return newElementBundle;
    }
    /**
     * Finds the lowest element in the array.
     * @returns The lowest element or undefined if the array is empty.
     */ lowest() {
        return this.elements.length > 0 ? this.elements[0] : undefined;
    }
    /**
     * Creates a new element with the specified value and updates the low element index accordingly.
     * @param lowElementIndex The index of the low element.
     * @param value The value for the new element.
     * @returns A bundle containing the new element, the updated low element, and the value of the next element.
     */ newElementWithLowElementIndex(lowElementIndex, value) {
        const newLowElement = this.elements[lowElementIndex];
        const newElementIndex = this.currentNodeIndex + 1;
        const newElement = new IndexedElement(newElementIndex, value, newLowElement.nextIndex);
        newLowElement.nextIndex = newElementIndex;
        const newElementNextValue = this.elements[newElement.nextIndex].value;
        return new IndexedElementBundle(newLowElement, newElement, newElementNextValue);
    }
    /**
     * Creates a new element with the specified value by first finding the appropriate low element index.
     * @param value The value for the new element.
     * @returns A bundle containing the new element, the updated low element, and the value of the next element.
     */ newElement(value) {
        const lowElementIndex = this.findLowElementIndex(value);
        if (lowElementIndex === undefined) {
            throw new Error('Low element index not found.');
        }
        return this.newElementWithLowElementIndex(lowElementIndex, value);
    }
}
const DEFAULT_ZERO = '0';
/**
 * @callback hashFunction
 * @param left Left leaf
 * @param right Right leaf
 */ /**
 * Merkle tree
 */ class MerkleTree {
    constructor(levels, lightWasm, elements = [], { zeroElement = DEFAULT_ZERO } = {}){
        this.levels = levels;
        this.capacity = 2 ** levels;
        this.zeroElement = zeroElement;
        this._lightWasm = lightWasm;
        if (elements.length > this.capacity) {
            throw new Error('Tree is full');
        }
        this._zeros = [];
        this._layers = [];
        this._layers[0] = elements;
        this._zeros[0] = this.zeroElement;
        for(let i = 1; i <= levels; i++){
            this._zeros[i] = this._lightWasm.poseidonHashString([
                this._zeros[i - 1],
                this._zeros[i - 1]
            ]);
        }
        this._rebuild();
    }
    _rebuild() {
        for(let level = 1; level <= this.levels; level++){
            this._layers[level] = [];
            for(let i = 0; i < Math.ceil(this._layers[level - 1].length / 2); i++){
                this._layers[level][i] = this._lightWasm.poseidonHashString([
                    this._layers[level - 1][i * 2],
                    i * 2 + 1 < this._layers[level - 1].length ? this._layers[level - 1][i * 2 + 1] : this._zeros[level - 1]
                ]);
            }
        }
    }
    /**
     * Get tree root
     * @returns {*}
     */ root() {
        return this._layers[this.levels].length > 0 ? this._layers[this.levels][0] : this._zeros[this.levels];
    }
    /**
     * Insert new element into the tree
     * @param element Element to insert
     */ insert(element) {
        if (this._layers[0].length >= this.capacity) {
            throw new Error('Tree is full');
        }
        this.update(this._layers[0].length, element);
    }
    /**
     * Insert multiple elements into the tree. Tree will be fully rebuilt during this operation.
     * @param {Array} elements Elements to insert
     */ bulkInsert(elements) {
        if (this._layers[0].length + elements.length > this.capacity) {
            throw new Error('Tree is full');
        }
        this._layers[0].push(...elements);
        this._rebuild();
    }
    // TODO: update does not work debug
    /**
     * Change an element in the tree
     * @param {number} index Index of element to change
     * @param element Updated element value
     */ update(index, element) {
        // index 0 and 1 and element is the commitment hash
        if (isNaN(Number(index)) || index < 0 || index > this._layers[0].length || index >= this.capacity) {
            throw new Error('Insert index out of bounds: ' + index);
        }
        this._layers[0][index] = element;
        for(let level = 1; level <= this.levels; level++){
            index >>= 1;
            this._layers[level][index] = this._lightWasm.poseidonHashString([
                this._layers[level - 1][index * 2],
                index * 2 + 1 < this._layers[level - 1].length ? this._layers[level - 1][index * 2 + 1] : this._zeros[level - 1]
            ]);
        }
    }
    /**
     * Get merkle path to a leaf
     * @param {number} index Leaf index to generate path for
     * @returns {{pathElements: number[], pathIndex: number[]}} An object containing adjacent elements and left-right index
     */ path(index) {
        if (isNaN(Number(index)) || index < 0 || index >= this._layers[0].length) {
            throw new Error('Index out of bounds: ' + index);
        }
        const pathElements = [];
        const pathIndices = [];
        for(let level = 0; level < this.levels; level++){
            pathIndices[level] = index % 2;
            pathElements[level] = (index ^ 1) < this._layers[level].length ? this._layers[level][index ^ 1] : this._zeros[level];
            index >>= 1;
        }
        return {
            pathElements,
            pathIndices
        };
    }
    /**
     * Find an element in the tree
     * @param element An element to find
     * @param comparator A function that checks leaf value equality
     * @returns {number} Index if element is found, otherwise -1
     */ indexOf(element, comparator = null) {
        if (comparator) {
            return this._layers[0].findIndex((el)=>comparator(element, el));
        } else {
            return this._layers[0].indexOf(element);
        }
    }
    /**
     * Returns a copy of non-zero tree elements
     * @returns {Object[]}
     */ elements() {
        return this._layers[0].slice();
    }
    /**
     * Serialize entire tree state including intermediate layers into a plain object
     * Deserializing it back will not require to recompute any hashes
     * Elements are not converted to a plain type, this is responsibility of the caller
     */ serialize() {
        return {
            levels: this.levels,
            _zeros: this._zeros,
            _layers: this._layers
        };
    }
    /**
     * Deserialize data into a MerkleTree instance
     * Make sure to provide the same hashFunction as was used in the source tree,
     * otherwise the tree state will be invalid
     *
     * @param data
     * @param hashFunction
     * @returns {MerkleTree}
     */ static deserialize(data, hashFunction) {
        const instance = Object.assign(Object.create(this.prototype), data);
        instance._hash = hashFunction;
        instance.capacity = 2 ** instance.levels;
        instance.zeroElement = instance._zeros[0];
        return instance;
    }
}
var bytes = {};
var hex = {};
Object.defineProperty(hex, "__esModule", {
    value: true
});
hex.decode = hex.encode = void 0;
const buffer_1$1 = require$$0;
function encode$3(data) {
    return data.reduce((str, byte)=>str + byte.toString(16).padStart(2, "0"), "0x");
}
hex.encode = encode$3;
function decode$3(data) {
    if (data.indexOf("0x") === 0) {
        data = data.substr(2);
    }
    if (data.length % 2 === 1) {
        data = "0" + data;
    }
    let key = data.match(/.{2}/g);
    if (key === null) {
        return buffer_1$1.Buffer.from([]);
    }
    return buffer_1$1.Buffer.from(key.map((byte)=>parseInt(byte, 16)));
}
hex.decode = decode$3;
var utf8 = {};
var common = {};
var _a;
Object.defineProperty(common, "__esModule", {
    value: true
});
common.isVersionedTransaction = common.chunks = common.isBrowser = void 0;
/**
 * Returns true if being run inside a web browser,
 * false if in a Node process or electron app.
 */ common.isBrowser = process.env.ANCHOR_BROWSER || "undefined" !== "undefined" && !((_a = window.process) === null || _a === void 0 ? void 0 : _a.hasOwnProperty("type"));
/**
 * Splits an array into chunks
 *
 * @param array Array of objects to chunk.
 * @param size The max size of a chunk.
 * @returns A two dimensional array where each T[] length is < the provided size.
 */ function chunks(array, size) {
    return Array.apply(0, new Array(Math.ceil(array.length / size))).map((_, index)=>array.slice(index * size, (index + 1) * size));
}
common.chunks = chunks;
/**
 * Check if a transaction object is a VersionedTransaction or not
 *
 * @param tx
 * @returns bool
 */ const isVersionedTransaction = (tx)=>{
    return "version" in tx;
};
common.isVersionedTransaction = isVersionedTransaction;
Object.defineProperty(utf8, "__esModule", {
    value: true
});
utf8.encode = utf8.decode = void 0;
const common_1 = common;
function decode$2(array) {
    const decoder = common_1.isBrowser ? new TextDecoder("utf-8") // Browser https://caniuse.com/textencoder.
     : new require$$1.TextDecoder("utf-8"); // Node.
    return decoder.decode(array);
}
utf8.decode = decode$2;
function encode$2(input) {
    const encoder = common_1.isBrowser ? new TextEncoder() // Browser.
     : new require$$1.TextEncoder("utf-8"); // Node.
    return encoder.encode(input);
}
utf8.encode = encode$2;
var bs58$1 = {};
var __importDefault = commonjsGlobal && commonjsGlobal.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(bs58$1, "__esModule", {
    value: true
});
bs58$1.decode = bs58$1.encode = void 0;
const bs58_1 = __importDefault(bs58$2);
function encode$1(data) {
    return bs58_1.default.encode(data);
}
bs58$1.encode = encode$1;
function decode$1(data) {
    return bs58_1.default.decode(data);
}
bs58$1.decode = decode$1;
var base64 = {};
Object.defineProperty(base64, "__esModule", {
    value: true
});
base64.decode = base64.encode = void 0;
const buffer_1 = require$$0;
function encode(data) {
    return data.toString("base64");
}
base64.encode = encode;
function decode(data) {
    return buffer_1.Buffer.from(data, "base64");
}
base64.decode = decode;
var __createBinding = commonjsGlobal && commonjsGlobal.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = commonjsGlobal && commonjsGlobal.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = commonjsGlobal && commonjsGlobal.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(bytes, "__esModule", {
    value: true
});
bytes.base64 = bs58 = bytes.bs58 = bytes.utf8 = bytes.hex = void 0;
bytes.hex = __importStar(hex);
bytes.utf8 = __importStar(utf8);
var bs58 = bytes.bs58 = __importStar(bs58$1);
bytes.base64 = __importStar(base64);
/**
 * @internal
 * Returns newest first.
 *
 * */ async function getParsedEvents(rpc) {
    const { noopProgram, accountCompressionProgram } = defaultStaticAccountsStruct();
    /// Get raw transactions
    const signatures = (await rpc.getConfirmedSignaturesForAddress2(accountCompressionProgram, undefined, 'confirmed')).map((s)=>s.signature);
    const txs = await rpc.getParsedTransactions(signatures, {
        maxSupportedTransactionVersion: 0,
        commitment: 'confirmed'
    });
    /// Filter by NOOP program
    const transactionEvents = txs.filter((tx)=>{
        if (!tx) {
            return false;
        }
        const accountKeys = tx.transaction.message.accountKeys;
        const hasSplNoopAddress = accountKeys.some((item)=>{
            const itemStr = typeof item === 'string' ? item : item.pubkey.toBase58();
            return itemStr === noopProgram.toBase58();
        });
        return hasSplNoopAddress;
    });
    /// Parse events
    const parsedEvents = parseEvents(transactionEvents, parsePublicTransactionEventWithIdl);
    return parsedEvents;
}
const parseEvents = (indexerEventsTransactions, deserializeFn)=>{
    const { noopProgram } = defaultStaticAccountsStruct();
    const transactions = [];
    indexerEventsTransactions.forEach((tx)=>{
        if (!tx || !tx.meta || tx.meta.err || !tx.meta.innerInstructions || tx.meta.innerInstructions.length <= 0) {
            return;
        }
        /// We only care about the very last inner instruction as it contains the
        /// PublicTransactionEvent
        tx.meta.innerInstructions.forEach((ix)=>{
            if (ix.instructions.length > 0) {
                const ixInner = ix.instructions[ix.instructions.length - 1];
                // Type guard for partially parsed web3js types.
                if ('data' in ixInner && ixInner.data && ixInner.programId.toBase58() === noopProgram.toBase58()) {
                    const data = bs58.decode(ixInner.data);
                    const decodedEvent = deserializeFn(Buffer.from(data), tx);
                    if (decodedEvent !== null && decodedEvent !== undefined) {
                        transactions.push(decodedEvent);
                    }
                }
            }
        });
    });
    return transactions;
};
// TODO: make it type safe. have to reimplement the types from the IDL.
const parsePublicTransactionEventWithIdl = (data)=>{
    const numericData = Buffer.from(data.map((byte)=>byte));
    try {
        return LightSystemProgram.program.coder.types.decode('PublicTransactionEvent', numericData);
    } catch (error) {
        console.error('Error deserializing event:', error);
        return null;
    }
};
async function getCompressedAccountsByOwnerTest(rpc, owner) {
    const unspentAccounts = await getCompressedAccountsForTest(rpc);
    const byOwner = unspentAccounts.filter((acc)=>acc.owner.equals(owner));
    return byOwner;
}
async function getCompressedAccountByHashTest(rpc, hash) {
    const unspentAccounts = await getCompressedAccountsForTest(rpc);
    return unspentAccounts.find((acc)=>bn(acc.hash).eq(hash));
}
async function getMultipleCompressedAccountsByHashTest(rpc, hashes) {
    const unspentAccounts = await getCompressedAccountsForTest(rpc);
    return unspentAccounts.filter((acc)=>hashes.some((hash)=>bn(acc.hash).eq(hash))).sort((a, b)=>b.leafIndex - a.leafIndex);
}
/// Returns all unspent compressed accounts
async function getCompressedAccountsForTest(rpc) {
    var _a, _b;
    const events = (await getParsedEvents(rpc)).reverse();
    const allOutputAccounts = [];
    const allInputAccountHashes = [];
    for (const event of events){
        for(let index = 0; index < event.outputCompressedAccounts.length; index++){
            const account = event.outputCompressedAccounts[index];
            const merkleContext = {
                merkleTree: defaultTestStateTreeAccounts().merkleTree,
                nullifierQueue: defaultTestStateTreeAccounts().nullifierQueue,
                hash: event.outputCompressedAccountHashes[index],
                leafIndex: event.outputLeafIndices[index]
            };
            const withCtx = createCompressedAccountWithMerkleContext(merkleContext, account.compressedAccount.owner, account.compressedAccount.lamports, (_a = account.compressedAccount.data) !== null && _a !== void 0 ? _a : undefined, (_b = account.compressedAccount.address) !== null && _b !== void 0 ? _b : undefined);
            allOutputAccounts.push(withCtx);
        }
        for(let index = 0; index < event.inputCompressedAccountHashes.length; index++){
            const hash = event.inputCompressedAccountHashes[index];
            allInputAccountHashes.push(bn(hash));
        }
    }
    const unspentAccounts = allOutputAccounts.filter((account)=>!allInputAccountHashes.some((hash)=>hash.eq(bn(account.hash))));
    unspentAccounts.sort((a, b)=>b.leafIndex - a.leafIndex);
    return unspentAccounts;
}
const tokenProgramId = new web3_js.PublicKey(// TODO: can add check to ensure its consistent with the idl
'cTokenmWW8bLPjZEBAUgYy3zKxQZW6VKi7bqNFEVv3m');
/**
 * Manually parse the compressed token layout for a given compressed account.
 * @param compressedAccount - The compressed account
 * @returns The parsed token data
 */ function parseTokenLayoutWithIdl(compressedAccount, programId = tokenProgramId) {
    if (compressedAccount.data === null) return null;
    const { data } = compressedAccount.data;
    if (data.length === 0) return null;
    if (compressedAccount.owner.toBase58() !== programId.toBase58()) {
        throw new Error(`Invalid owner ${compressedAccount.owner.toBase58()} for token layout`);
    }
    const decodedLayout = new anchor.BorshCoder(IDL).types.decode('TokenData', Buffer.from(data));
    return decodedLayout;
}
/**
 * parse compressed accounts of an event with token layout
 * @internal
 * TODO: refactor
 */ async function parseEventWithTokenTlvData(event) {
    const pubkeyArray = event.pubkeyArray;
    const outputHashes = event.outputCompressedAccountHashes;
    const outputCompressedAccountsWithParsedTokenData = event.outputCompressedAccounts.map((compressedAccount, i)=>{
        var _a;
        const merkleContext = {
            merkleTree: pubkeyArray[event.outputCompressedAccounts[i].merkleTreeIndex],
            nullifierQueue: // FIXME: fix make dynamic
            defaultTestStateTreeAccounts().nullifierQueue,
            hash: outputHashes[i],
            leafIndex: event.outputLeafIndices[i]
        };
        if (!compressedAccount.compressedAccount.data) throw new Error('No data');
        const parsedData = parseTokenLayoutWithIdl(compressedAccount.compressedAccount);
        if (!parsedData) throw new Error('Invalid token data');
        const withMerkleContext = createCompressedAccountWithMerkleContext(merkleContext, compressedAccount.compressedAccount.owner, compressedAccount.compressedAccount.lamports, compressedAccount.compressedAccount.data, (_a = compressedAccount.compressedAccount.address) !== null && _a !== void 0 ? _a : undefined);
        return {
            compressedAccount: withMerkleContext,
            parsed: parsedData
        };
    });
    return {
        inputCompressedAccountHashes: event.inputCompressedAccountHashes,
        outputCompressedAccounts: outputCompressedAccountsWithParsedTokenData
    };
}
/**
 * Retrieves all compressed token accounts for a given mint and owner.
 *
 * Note: This function is intended for testing purposes only. For production, use rpc.getCompressedTokenAccounts.
 *
 * @param events    Public transaction events
 * @param owner     PublicKey of the token owner
 * @param mint      PublicKey of the token mint
 */ async function getCompressedTokenAccounts(events) {
    const eventsWithParsedTokenTlvData = await Promise.all(events.map((event)=>parseEventWithTokenTlvData(event)));
    /// strip spent compressed accounts if an output compressed account of tx n is
    /// an input compressed account of tx n+m, it is spent
    const allOutCompressedAccounts = eventsWithParsedTokenTlvData.flatMap((event)=>event.outputCompressedAccounts);
    const allInCompressedAccountHashes = eventsWithParsedTokenTlvData.flatMap((event)=>event.inputCompressedAccountHashes);
    const unspentCompressedAccounts = allOutCompressedAccounts.filter((outputCompressedAccount)=>!allInCompressedAccountHashes.some((hash)=>{
            return JSON.stringify(hash) === JSON.stringify(outputCompressedAccount.compressedAccount.hash);
        }));
    return unspentCompressedAccounts;
}
/** @internal */ async function getCompressedTokenAccountsByOwnerTest(rpc, owner, mint) {
    const events = await getParsedEvents(rpc);
    const compressedTokenAccounts = await getCompressedTokenAccounts(events);
    const accounts = compressedTokenAccounts.filter((acc)=>acc.parsed.owner.equals(owner) && acc.parsed.mint.equals(mint));
    return {
        items: accounts.sort((a, b)=>b.compressedAccount.leafIndex - a.compressedAccount.leafIndex),
        cursor: null
    };
}
async function getCompressedTokenAccountsByDelegateTest(rpc, delegate, mint) {
    const events = await getParsedEvents(rpc);
    const compressedTokenAccounts = await getCompressedTokenAccounts(events);
    return {
        items: compressedTokenAccounts.filter((acc)=>{
            var _a;
            return ((_a = acc.parsed.delegate) === null || _a === void 0 ? void 0 : _a.equals(delegate)) && acc.parsed.mint.equals(mint);
        }),
        cursor: null
    };
}
async function getCompressedTokenAccountByHashTest(rpc, hash) {
    const events = await getParsedEvents(rpc);
    const compressedTokenAccounts = await getCompressedTokenAccounts(events);
    const filtered = compressedTokenAccounts.filter((acc)=>bn(acc.compressedAccount.hash).eq(hash));
    if (filtered.length === 0) {
        throw new Error('No compressed account found');
    }
    return filtered[0];
}
/**
 * Returns a mock RPC instance for use in unit tests.
 *
 * @param lightWasm               Wasm hasher instance.
 * @param endpoint                RPC endpoint URL. Defaults to
 *                                'http://127.0.0.1:8899'.
 * @param proverEndpoint          Prover server endpoint URL. Defaults to
 *                                'http://localhost:3001'.
 * @param merkleTreeAddress       Address of the merkle tree to index. Defaults
 *                                to the public default test state tree.
 * @param nullifierQueueAddress   Optional address of the associated nullifier
 *                                queue.
 * @param depth                   Depth of the merkle tree.
 * @param log                     Log proof generation time.
 */ async function getTestRpc(lightWasm, endpoint = 'http://127.0.0.1:8899', compressionApiEndpoint = 'http://127.0.0.1:8784', proverEndpoint = 'http://127.0.0.1:3001', merkleTreeAddress, nullifierQueueAddress, depth, log = false) {
    const defaultAccounts = defaultTestStateTreeAccounts();
    return new TestRpc(endpoint, lightWasm, compressionApiEndpoint, proverEndpoint, undefined, {
        merkleTreeAddress: merkleTreeAddress || defaultAccounts.merkleTree,
        nullifierQueueAddress: nullifierQueueAddress || defaultAccounts.nullifierQueue,
        depth: depth || defaultAccounts.merkleTreeHeight,
        log
    });
}
/**
 * Simple mock rpc for unit tests that simulates the compression rpc interface.
 * Fetches, parses events and builds merkletree on-demand, i.e. it does not persist state.
 * Constraints:
 * - Can only index 1 merkletree
 * - Can only index up to 1000 transactions
 *
 * For advanced testing use photon: https://github.com/helius-labs/photon
 */ class TestRpc extends web3_js.Connection {
    /**
     * Establish a Compression-compatible JSON RPC mock-connection
     *
     * @param endpoint                  endpoint to the solana cluster (use for
     *                                  localnet only)
     * @param hasher                    light wasm hasher instance
     * @param compressionApiEndpoint    Endpoint to the compression server.
     * @param proverEndpoint            Endpoint to the prover server. defaults
     *                                  to endpoint
     * @param connectionConfig          Optional connection config
     * @param testRpcConfig             Config for the mock rpc
     */ constructor(endpoint, hasher, compressionApiEndpoint, proverEndpoint, connectionConfig, testRpcConfig){
        super(endpoint, connectionConfig || 'confirmed');
        this.log = false;
        this.compressionApiEndpoint = compressionApiEndpoint;
        this.proverEndpoint = proverEndpoint;
        const { merkleTreeAddress, nullifierQueueAddress, depth, log, addressTreeAddress, addressQueueAddress } = testRpcConfig !== null && testRpcConfig !== void 0 ? testRpcConfig : {};
        const { merkleTree, nullifierQueue, merkleTreeHeight, addressQueue, addressTree } = defaultTestStateTreeAccounts();
        this.lightWasm = hasher;
        this.merkleTreeAddress = merkleTreeAddress !== null && merkleTreeAddress !== void 0 ? merkleTreeAddress : merkleTree;
        this.nullifierQueueAddress = nullifierQueueAddress !== null && nullifierQueueAddress !== void 0 ? nullifierQueueAddress : nullifierQueue;
        this.addressTreeAddress = addressTreeAddress !== null && addressTreeAddress !== void 0 ? addressTreeAddress : addressTree;
        this.addressQueueAddress = addressQueueAddress !== null && addressQueueAddress !== void 0 ? addressQueueAddress : addressQueue;
        this.depth = depth !== null && depth !== void 0 ? depth : merkleTreeHeight;
        this.log = log !== null && log !== void 0 ? log : false;
    }
    /**
     * Fetch the compressed account for the specified account hash
     */ async getCompressedAccount(address, hash) {
        if (address) {
            throw new Error('address is not supported in test-rpc');
        }
        if (!hash) {
            throw new Error('hash is required');
        }
        const account = await getCompressedAccountByHashTest(this, hash);
        return account !== null && account !== void 0 ? account : null;
    }
    /**
     * Fetch the compressed balance for the specified account hash
     */ async getCompressedBalance(address, hash) {
        if (address) {
            throw new Error('address is not supported in test-rpc');
        }
        if (!hash) {
            throw new Error('hash is required');
        }
        const account = await getCompressedAccountByHashTest(this, hash);
        if (!account) {
            throw new Error('Account not found');
        }
        return bn(account.lamports);
    }
    /**
     * Fetch the total compressed balance for the specified owner public key
     */ async getCompressedBalanceByOwner(owner) {
        const accounts = await this.getCompressedAccountsByOwner(owner);
        return accounts.items.reduce((acc, account)=>acc.add(account.lamports), bn(0));
    }
    /**
     * Fetch the latest merkle proof for the specified account hash from the
     * cluster
     */ async getCompressedAccountProof(hash) {
        const proofs = await this.getMultipleCompressedAccountProofs([
            hash
        ]);
        return proofs[0];
    }
    /**
     * Fetch all the account info for multiple compressed accounts specified by
     * an array of account hashes
     */ async getMultipleCompressedAccounts(hashes) {
        return await getMultipleCompressedAccountsByHashTest(this, hashes);
    }
    /**
     * Ensure that the Compression Indexer has already indexed the transaction
     */ async confirmTransactionIndexed(_slot) {
        return true;
    }
    /**
     * Fetch the latest merkle proofs for multiple compressed accounts specified
     * by an array account hashes
     */ async getMultipleCompressedAccountProofs(hashes) {
        /// Build tree
        const events = await getParsedEvents(this).then((events)=>events.reverse());
        const allLeaves = [];
        const allLeafIndices = [];
        for (const event of events){
            for(let index = 0; index < event.outputCompressedAccounts.length; index++){
                const hash = event.outputCompressedAccountHashes[index];
                allLeaves.push(hash);
                allLeafIndices.push(event.outputLeafIndices[index]);
            }
        }
        const tree = new MerkleTree(this.depth, this.lightWasm, allLeaves.map((leaf)=>bn(leaf).toString()));
        /// create merkle proofs and assemble return type
        const merkleProofs = [];
        for(let i = 0; i < hashes.length; i++){
            const leafIndex = tree.indexOf(hashes[i].toString());
            const pathElements = tree.path(leafIndex).pathElements;
            const bnPathElements = pathElements.map((value)=>bn(value));
            const root = bn(tree.root());
            const merkleProof = {
                hash: hashes[i].toArray('be', 32),
                merkleTree: this.merkleTreeAddress,
                leafIndex: leafIndex,
                merkleProof: bnPathElements,
                nullifierQueue: this.nullifierQueueAddress,
                rootIndex: allLeaves.length,
                root: root
            };
            merkleProofs.push(merkleProof);
        }
        /// Validate
        merkleProofs.forEach((proof, index)=>{
            const leafIndex = proof.leafIndex;
            const computedHash = tree.elements()[leafIndex];
            const hashArr = bn(computedHash).toArray('be', 32);
            if (!hashArr.every((val, index)=>val === proof.hash[index])) {
                throw new Error(`Mismatch at index ${index}: expected ${proof.hash.toString()}, got ${hashArr.toString()}`);
            }
        });
        return merkleProofs;
    }
    /**
     * Fetch all the compressed accounts owned by the specified public key.
     * Owner can be a program or user account
     */ async getCompressedAccountsByOwner(owner, _config) {
        // TODO(swen): revisit
        // if (_config) {
        //     throw new Error(
        //         'dataSlice or filters are not supported in test-rpc. Please use rpc.ts instead.',
        //     );
        // }
        const accounts = await getCompressedAccountsByOwnerTest(this, owner);
        return {
            items: accounts,
            cursor: null
        };
    }
    /**
     * Fetch the latest compression signatures on the cluster. Results are
     * paginated.
     */ async getLatestCompressionSignatures(_cursor, _limit) {
        throw new Error('getLatestNonVotingSignaturesWithContext not supported in test-rpc');
    }
    /**
     * Fetch the latest non-voting signatures on the cluster. Results are
     * not paginated.
     */ async getLatestNonVotingSignatures(_limit) {
        throw new Error('getLatestNonVotingSignaturesWithContext not supported in test-rpc');
    }
    /**
     * Fetch all the compressed token accounts owned by the specified public
     * key. Owner can be a program or user account
     */ async getCompressedTokenAccountsByOwner(owner, options) {
        return await getCompressedTokenAccountsByOwnerTest(this, owner, options.mint);
    }
    /**
     * Fetch all the compressed accounts delegated to the specified public key.
     */ async getCompressedTokenAccountsByDelegate(delegate, options) {
        return await getCompressedTokenAccountsByDelegateTest(this, delegate, options.mint);
    }
    /**
     * Fetch the compressed token balance for the specified account hash
     */ async getCompressedTokenAccountBalance(hash) {
        const account = await getCompressedTokenAccountByHashTest(this, hash);
        return {
            amount: bn(account.parsed.amount)
        };
    }
    /**
     * @deprecated use {@link getCompressedTokenBalancesByOwnerV2}.
     * Fetch all the compressed token balances owned by the specified public
     * key. Can filter by mint.
     */ async getCompressedTokenBalancesByOwner(publicKey, options) {
        const accounts = await getCompressedTokenAccountsByOwnerTest(this, publicKey, options.mint);
        return {
            items: accounts.items.map((account)=>({
                    balance: bn(account.parsed.amount),
                    mint: account.parsed.mint
                })),
            cursor: null
        };
    }
    /**
     * Fetch all the compressed token balances owned by the specified public
     * key. Can filter by mint. Uses context.
     */ async getCompressedTokenBalancesByOwnerV2(publicKey, options) {
        const accounts = await getCompressedTokenAccountsByOwnerTest(this, publicKey, options.mint);
        return {
            context: {
                slot: 1
            },
            value: {
                items: accounts.items.map((account)=>({
                        balance: bn(account.parsed.amount),
                        mint: account.parsed.mint
                    })),
                cursor: null
            }
        };
    }
    /**
     * Returns confirmed signatures for transactions involving the specified
     * account hash forward in time from genesis to the most recent confirmed
     * block
     *
     * @param hash queried account hash
     */ async getCompressionSignaturesForAccount(_hash) {
        throw new Error('getCompressionSignaturesForAccount not implemented in test-rpc');
    }
    /**
     * Fetch a confirmed or finalized transaction from the cluster. Return with
     * CompressionInfo
     */ async getTransactionWithCompressionInfo(_signature) {
        throw new Error('getCompressedTransaction not implemented in test-rpc');
    }
    /**
     * Returns confirmed signatures for transactions involving the specified
     * address forward in time from genesis to the most recent confirmed
     * block
     *
     * @param address queried compressed account address
     */ async getCompressionSignaturesForAddress(_address, _options) {
        throw new Error('getSignaturesForAddress3 not implemented');
    }
    /**
     * Returns confirmed signatures for compression transactions involving the
     * specified account owner forward in time from genesis to the
     * most recent confirmed block
     *
     * @param owner queried owner public key
     */ async getCompressionSignaturesForOwner(_owner, _options) {
        throw new Error('getSignaturesForOwner not implemented');
    }
    /**
     * Returns confirmed signatures for compression transactions involving the
     * specified token account owner forward in time from genesis to the most
     * recent confirmed block
     */ async getCompressionSignaturesForTokenOwner(_owner, _options) {
        throw new Error('getSignaturesForTokenOwner not implemented');
    }
    /**
     * Fetch the current indexer health status
     */ async getIndexerHealth() {
        return 'ok';
    }
    /**
     * Fetch the current slot that the node is processing
     */ async getIndexerSlot() {
        return 1;
    }
    /**
     * Fetch the latest address proofs for new unique addresses specified by an
     * array of addresses.
     *
     * the proof states that said address have not yet been created in respective address tree.
     * @param addresses Array of BN254 new addresses
     * @returns Array of validity proofs for new addresses
     */ async getMultipleNewAddressProofs(addresses) {
        /// Build tree
        const indexedArray = IndexedArray.default();
        const allAddresses = [];
        indexedArray.init();
        const hashes = [];
        // TODO(crank): add support for cranked address tree in 'allAddresses'.
        // The Merkle tree root doesnt actually advance beyond init() unless we
        // start emptying the address queue.
        for(let i = 0; i < allAddresses.length; i++){
            indexedArray.append(bn(allAddresses[i]));
        }
        for(let i = 0; i < indexedArray.elements.length; i++){
            const hash = indexedArray.hashElement(this.lightWasm, i);
            hashes.push(bn(hash));
        }
        const tree = new MerkleTree(this.depth, this.lightWasm, hashes.map((hash)=>bn(hash).toString()));
        /// Creates proof for each address
        const newAddressProofs = [];
        for(let i = 0; i < addresses.length; i++){
            const [lowElement] = indexedArray.findLowElement(addresses[i]);
            if (!lowElement) throw new Error('Address not found');
            const leafIndex = lowElement.index;
            const pathElements = tree.path(leafIndex).pathElements;
            const bnPathElements = pathElements.map((value)=>bn(value));
            const higherRangeValue = indexedArray.get(lowElement.nextIndex).value;
            const root = bn(tree.root());
            const proof = {
                root,
                rootIndex: 3,
                value: addresses[i],
                leafLowerRangeValue: lowElement.value,
                leafHigherRangeValue: higherRangeValue,
                nextIndex: bn(lowElement.nextIndex),
                merkleProofHashedIndexedElementLeaf: bnPathElements,
                indexHashedIndexedElementLeaf: bn(lowElement.index),
                merkleTree: this.addressTreeAddress,
                nullifierQueue: this.addressQueueAddress
            };
            newAddressProofs.push(proof);
        }
        return newAddressProofs;
    }
    async getCompressedMintTokenHolders(_mint, _options) {
        throw new Error('getCompressedMintTokenHolders not implemented in test-rpc');
    }
    /**
     * Advanced usage of getValidityProof: fetches ZKP directly from a custom
     * non-rpcprover. Note: This uses the proverEndpoint specified in the
     * constructor. For normal usage, please use {@link getValidityProof}
     * instead.
     *
     * Note: Use RPC class for forested trees. TestRpc is only for custom
     * testing purposes.
     */ async getValidityProofDirect(hashes = [], newAddresses = []) {
        return this.getValidityProof(hashes, newAddresses);
    }
    /**
     * @deprecated This method is not available for TestRpc. Please use
     * {@link getValidityProof} instead.
     */ async getValidityProofAndRpcContext(hashes = [], newAddresses = []) {
        if (newAddresses.some((address)=>!(address instanceof anchor.BN))) {
            throw new Error('AddressWithTree is not supported in test-rpc');
        }
        return {
            value: await this.getValidityProofV0(hashes, newAddresses),
            context: {
                slot: 1
            }
        };
    }
    /**
     * Fetch the latest validity proof for (1) compressed accounts specified by
     * an array of account hashes. (2) new unique addresses specified by an
     * array of addresses.
     *
     * Validity proofs prove the presence of compressed accounts in state trees
     * and the non-existence of addresses in address trees, respectively. They
     * enable verification without recomputing the merkle proof path, thus
     * lowering verification and data costs.
     *
     * @param hashes        Array of BN254 hashes.
     * @param newAddresses  Array of BN254 new addresses.
     * @returns             validity proof with context
     */ async getValidityProof(hashes = [], newAddresses = []) {
        if (newAddresses.some((address)=>!(address instanceof anchor.BN))) {
            throw new Error('AddressWithTree is not supported in test-rpc');
        }
        let validityProof;
        if (hashes.length === 0 && newAddresses.length === 0) {
            throw new Error('Empty input. Provide hashes and/or new addresses.');
        } else if (hashes.length > 0 && newAddresses.length === 0) {
            /// inclusion
            const merkleProofsWithContext = await this.getMultipleCompressedAccountProofs(hashes);
            const inputs = convertMerkleProofsWithContextToHex(merkleProofsWithContext);
            const compressedProof = await proverRequest(this.proverEndpoint, 'inclusion', inputs, this.log);
            validityProof = {
                compressedProof,
                roots: merkleProofsWithContext.map((proof)=>proof.root),
                rootIndices: merkleProofsWithContext.map((proof)=>proof.rootIndex),
                leafIndices: merkleProofsWithContext.map((proof)=>proof.leafIndex),
                leaves: merkleProofsWithContext.map((proof)=>bn(proof.hash)),
                merkleTrees: merkleProofsWithContext.map((proof)=>proof.merkleTree),
                nullifierQueues: merkleProofsWithContext.map((proof)=>proof.nullifierQueue)
            };
        } else if (hashes.length === 0 && newAddresses.length > 0) {
            /// new-address
            const newAddressProofs = await this.getMultipleNewAddressProofs(newAddresses);
            const inputs = convertNonInclusionMerkleProofInputsToHex(newAddressProofs);
            const compressedProof = await proverRequest(this.proverEndpoint, 'new-address', inputs, this.log);
            validityProof = {
                compressedProof,
                roots: newAddressProofs.map((proof)=>proof.root),
                // TODO(crank): make dynamic to enable forester support in
                // test-rpc.ts. Currently this is a static root because the
                // address tree doesn't advance.
                rootIndices: newAddressProofs.map((_)=>3),
                leafIndices: newAddressProofs.map((proof)=>proof.indexHashedIndexedElementLeaf.toNumber()),
                leaves: newAddressProofs.map((proof)=>bn(proof.value)),
                merkleTrees: newAddressProofs.map((proof)=>proof.merkleTree),
                nullifierQueues: newAddressProofs.map((proof)=>proof.nullifierQueue)
            };
        } else if (hashes.length > 0 && newAddresses.length > 0) {
            /// combined
            const merkleProofsWithContext = await this.getMultipleCompressedAccountProofs(hashes);
            const inputs = convertMerkleProofsWithContextToHex(merkleProofsWithContext);
            const newAddressProofs = await this.getMultipleNewAddressProofs(newAddresses);
            const newAddressInputs = convertNonInclusionMerkleProofInputsToHex(newAddressProofs);
            const compressedProof = await proverRequest(this.proverEndpoint, 'combined', [
                inputs,
                newAddressInputs
            ], this.log);
            validityProof = {
                compressedProof,
                roots: merkleProofsWithContext.map((proof)=>proof.root).concat(newAddressProofs.map((proof)=>proof.root)),
                rootIndices: merkleProofsWithContext.map((proof)=>proof.rootIndex)// TODO(crank): make dynamic to enable forester support in
                // test-rpc.ts. Currently this is a static root because the
                // address tree doesn't advance.
                .concat(newAddressProofs.map((_)=>3)),
                leafIndices: merkleProofsWithContext.map((proof)=>proof.leafIndex).concat(newAddressProofs.map((proof)=>proof.indexHashedIndexedElementLeaf.toNumber())),
                leaves: merkleProofsWithContext.map((proof)=>bn(proof.hash)).concat(newAddressProofs.map((proof)=>bn(proof.value))),
                merkleTrees: merkleProofsWithContext.map((proof)=>proof.merkleTree).concat(newAddressProofs.map((proof)=>proof.merkleTree)),
                nullifierQueues: merkleProofsWithContext.map((proof)=>proof.nullifierQueue).concat(newAddressProofs.map((proof)=>proof.nullifierQueue))
            };
        } else throw new Error('Invalid input');
        return validityProof;
    }
    async getValidityProofV0(hashes = [], newAddresses = []) {
        /// TODO(swen): add support for custom trees
        return this.getValidityProof(hashes.map((hash)=>hash.hash), newAddresses.map((address)=>address.address));
    }
}
exports.ADDRESS_QUEUE_ROLLOVER_FEE = ADDRESS_QUEUE_ROLLOVER_FEE;
exports.ADDRESS_TREE_NETWORK_FEE = ADDRESS_TREE_NETWORK_FEE;
exports.ALICE = ALICE;
exports.AccountCompressionIDL = IDL$2;
exports.AccountProofResult = AccountProofResult;
exports.BOB = BOB;
exports.BalanceResult = BalanceResult;
exports.CHARLIE = CHARLIE;
exports.CompressedAccountResult = CompressedAccountResult;
exports.CompressedAccountsByOwnerResult = CompressedAccountsByOwnerResult;
exports.CompressedMintTokenHoldersResult = CompressedMintTokenHoldersResult;
exports.CompressedTokenAccountResult = CompressedTokenAccountResult;
exports.CompressedTokenAccountsByOwnerOrDelegateResult = CompressedTokenAccountsByOwnerOrDelegateResult;
exports.CompressedTransactionResult = CompressedTransactionResult;
exports.CreateUtxoError = CreateUtxoError;
exports.DAVE = DAVE;
exports.DEFAULT_MERKLE_TREE_HEIGHT = DEFAULT_MERKLE_TREE_HEIGHT;
exports.DEFAULT_MERKLE_TREE_ROOTS = DEFAULT_MERKLE_TREE_ROOTS;
exports.DEFAULT_ZERO = DEFAULT_ZERO;
exports.FIELD_SIZE = FIELD_SIZE;
exports.HIGHEST_ADDRESS_PLUS_ONE = HIGHEST_ADDRESS_PLUS_ONE;
exports.HashError = HashError;
exports.HealthResult = HealthResult;
exports.IndexedArray = IndexedArray;
exports.IndexedElement = IndexedElement;
exports.IndexedElementBundle = IndexedElementBundle;
exports.LatestNonVotingSignaturesResult = LatestNonVotingSignaturesResult;
exports.LatestNonVotingSignaturesResultPaginated = LatestNonVotingSignaturesResultPaginated;
exports.LightCompressedTokenIDL = IDL;
exports.LightRegistryIDL = IDL$1;
exports.LightSystemIDL = IDL$3;
exports.LightSystemProgram = LightSystemProgram;
exports.LookupTableError = LookupTableError;
exports.MerkeProofResult = MerkeProofResult;
exports.MerkleTree = MerkleTree;
exports.MerkleTreeError = MerkleTreeError;
exports.MultipleCompressedAccountsResult = MultipleCompressedAccountsResult;
exports.MultipleMerkleProofsResult = MultipleMerkleProofsResult;
exports.NativeBalanceResult = NativeBalanceResult;
exports.NewAddressProofResult = NewAddressProofResult;
exports.ProofError = ProofError;
exports.Rpc = Rpc;
exports.RpcError = RpcError;
exports.STATE_MERKLE_TREE_NETWORK_FEE = STATE_MERKLE_TREE_NETWORK_FEE;
exports.STATE_MERKLE_TREE_ROLLOVER_FEE = STATE_MERKLE_TREE_ROLLOVER_FEE;
exports.SelectInUtxosError = SelectInUtxosError;
exports.SignatureListResult = SignatureListResult;
exports.SignatureListWithCursorResult = SignatureListWithCursorResult;
exports.SlotResult = SlotResult;
exports.TRANSACTION_MERKLE_TREE_ROLLOVER_THRESHOLD = TRANSACTION_MERKLE_TREE_ROLLOVER_THRESHOLD;
exports.TestRpc = TestRpc;
exports.TokenBalanceListResult = TokenBalanceListResult;
exports.TokenBalanceListResultV2 = TokenBalanceListResultV2;
exports.TokenBalanceResult = TokenBalanceResult;
exports.TokenDataResult = TokenDataResult;
exports.UTXO_MERGE_MAXIMUM = UTXO_MERGE_MAXIMUM;
exports.UTXO_MERGE_THRESHOLD = UTXO_MERGE_THRESHOLD;
exports.UtilsError = UtilsError;
exports.UtxoError = UtxoError;
exports.ValidityProofResult = ValidityProofResult;
exports.accountCompressionProgram = accountCompressionProgram;
exports.addressQueue = addressQueue;
exports.addressTree = addressTree;
exports.airdropSol = airdropSol;
exports.bn = bn;
exports.bufToDecStr = bufToDecStr;
exports.buildAndSignTx = buildAndSignTx;
exports.buildTx = buildTx;
exports.byteArrayToKeypair = byteArrayToKeypair;
exports.calculateComputeUnitPrice = calculateComputeUnitPrice;
exports.checkValidityProofShape = checkValidityProofShape;
exports.compress = compress;
exports.confirmConfig = confirmConfig;
exports.confirmTransaction = confirmTransaction;
exports.confirmTx = confirmTx;
exports.convertMerkleProofsWithContextToHex = convertMerkleProofsWithContextToHex;
exports.convertNonInclusionMerkleProofInputsToHex = convertNonInclusionMerkleProofInputsToHex;
exports.createAccount = createAccount;
exports.createAccountWithLamports = createAccountWithLamports;
exports.createBN254 = createBN254;
exports.createCompressedAccount = createCompressedAccount;
exports.createCompressedAccountWithMerkleContext = createCompressedAccountWithMerkleContext;
exports.createMerkleContext = createMerkleContext;
exports.createRpc = createRpc;
exports.createRpcResult = createRpcResult;
exports.decompress = decompress;
exports.dedupeSigner = dedupeSigner;
exports.defaultStaticAccounts = defaultStaticAccounts;
exports.defaultStaticAccountsStruct = defaultStaticAccountsStruct;
exports.defaultTestStateTreeAccounts = defaultTestStateTreeAccounts;
exports.deriveAddress = deriveAddress;
exports.deriveAddressSeed = deriveAddressSeed;
exports.encodeBN254toBase58 = encodeBN254toBase58;
exports.getAccountCompressionAuthority = getAccountCompressionAuthority;
exports.getCompressedTokenAccountByHashTest = getCompressedTokenAccountByHashTest;
exports.getCompressedTokenAccounts = getCompressedTokenAccounts;
exports.getCompressedTokenAccountsByDelegateTest = getCompressedTokenAccountsByDelegateTest;
exports.getCompressedTokenAccountsByOwnerTest = getCompressedTokenAccountsByOwnerTest;
exports.getConnection = getConnection;
exports.getIndexOrAdd = getIndexOrAdd;
exports.getParsedEvents = getParsedEvents;
exports.getRegisteredProgramPda = getRegisteredProgramPda;
exports.getTestKeypair = getTestKeypair;
exports.getTestRpc = getTestRpc;
exports.hashToBn254FieldSizeBe = hashToBn254FieldSizeBe;
exports.hashvToBn254FieldSizeBe = hashvToBn254FieldSizeBe;
exports.jsonRpcResult = jsonRpcResult;
exports.jsonRpcResultAndContext = jsonRpcResultAndContext;
exports.lightProgram = lightProgram;
exports.merkletreePubkey = merkletreePubkey;
exports.negateAndCompressProof = negateAndCompressProof;
exports.newAccountWithLamports = newAccountWithLamports;
exports.noopProgram = noopProgram;
exports.nullifierQueuePubkey = nullifierQueuePubkey;
exports.packCompressedAccounts = packCompressedAccounts;
exports.packNewAddressParams = packNewAddressParams;
exports.padOutputStateMerkleTrees = padOutputStateMerkleTrees;
exports.parseAccountData = parseAccountData;
exports.parseEvents = parseEvents;
exports.parsePublicTransactionEventWithIdl = parsePublicTransactionEventWithIdl;
exports.parseTokenLayoutWithIdl = parseTokenLayoutWithIdl;
exports.pipe = pipe;
exports.placeholderValidityProof = placeholderValidityProof;
exports.proofFromJsonStruct = proofFromJsonStruct;
exports.proverRequest = proverRequest;
exports.pushUniqueItems = pushUniqueItems;
exports.rpcRequest = rpcRequest;
exports.selectMinCompressedSolAccountsForTransfer = selectMinCompressedSolAccountsForTransfer;
exports.sendAndConfirmTx = sendAndConfirmTx;
exports.sleep = sleep;
exports.sumUpLamports = sumUpLamports;
exports.toAccountMetas = toAccountMetas;
exports.toArray = toArray;
exports.toCamelCase = toCamelCase;
exports.toHex = toHex;
exports.toUnixTimestamp = toUnixTimestamp;
exports.transfer = transfer;
exports.useWallet = useWallet;
exports.validateSameOwner = validateSameOwner;
exports.validateSufficientBalance = validateSufficientBalance; //# sourceMappingURL=index.cjs.map
}}),

};

//# sourceMappingURL=39240_%40lightprotocol_stateless_js_dist_cjs_node_index_cjs_d30d57._.js.map
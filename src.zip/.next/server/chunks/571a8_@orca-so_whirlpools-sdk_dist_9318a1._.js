module.exports = {

"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/artifacts/whirlpool.json (json)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__(JSON.parse("{\"version\":\"0.3.2\",\"name\":\"whirlpool\",\"instructions\":[{\"name\":\"initializeConfig\",\"docs\":[\"Initializes a WhirlpoolsConfig account that hosts info & authorities\",\"required to govern a set of Whirlpools.\",\"\",\"### Parameters\",\"- `fee_authority` - Authority authorized to initialize fee-tiers and set customs fees.\",\"- `collect_protocol_fees_authority` - Authority authorized to collect protocol fees.\",\"- `reward_emissions_super_authority` - Authority authorized to set reward authorities in pools.\"],\"accounts\":[{\"name\":\"config\",\"isMut\":true,\"isSigner\":true},{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"feeAuthority\",\"type\":\"publicKey\"},{\"name\":\"collectProtocolFeesAuthority\",\"type\":\"publicKey\"},{\"name\":\"rewardEmissionsSuperAuthority\",\"type\":\"publicKey\"},{\"name\":\"defaultProtocolFeeRate\",\"type\":\"u16\"}]},{\"name\":\"initializePool\",\"docs\":[\"Initializes a Whirlpool account.\",\"Fee rate is set to the default values on the config and supplied fee_tier.\",\"\",\"### Parameters\",\"- `bumps` - The bump value when deriving the PDA of the Whirlpool address.\",\"- `tick_spacing` - The desired tick spacing for this pool.\",\"- `initial_sqrt_price` - The desired initial sqrt-price for this pool\",\"\",\"#### Special Errors\",\"`InvalidTokenMintOrder` - The order of mints have to be ordered by\",\"`SqrtPriceOutOfBounds` - provided initial_sqrt_price is not between 2^-64 to 2^64\",\"\"],\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultA\",\"isMut\":true,\"isSigner\":true},{\"name\":\"tokenVaultB\",\"isMut\":true,\"isSigner\":true},{\"name\":\"feeTier\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rent\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"bumps\",\"type\":{\"defined\":\"WhirlpoolBumps\"}},{\"name\":\"tickSpacing\",\"type\":\"u16\"},{\"name\":\"initialSqrtPrice\",\"type\":\"u128\"}]},{\"name\":\"initializeTickArray\",\"docs\":[\"Initializes a tick_array account to represent a tick-range in a Whirlpool.\",\"\",\"### Parameters\",\"- `start_tick_index` - The starting tick index for this tick-array.\",\"Has to be a multiple of TickArray size & the tick spacing of this pool.\",\"\",\"#### Special Errors\",\"- `InvalidStartTick` - if the provided start tick is out of bounds or is not a multiple of\",\"TICK_ARRAY_SIZE * tick spacing.\"],\"accounts\":[{\"name\":\"whirlpool\",\"isMut\":false,\"isSigner\":false},{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"tickArray\",\"isMut\":true,\"isSigner\":false},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"startTickIndex\",\"type\":\"i32\"}]},{\"name\":\"initializeFeeTier\",\"docs\":[\"Initializes a fee_tier account usable by Whirlpools in a WhirlpoolConfig space.\",\"\",\"### Authority\",\"- \\\"fee_authority\\\" - Set authority in the WhirlpoolConfig\",\"\",\"### Parameters\",\"- `tick_spacing` - The tick-spacing that this fee-tier suggests the default_fee_rate for.\",\"- `default_fee_rate` - The default fee rate that a pool will use if the pool uses this\",\"fee tier during initialization.\",\"\",\"#### Special Errors\",\"- `FeeRateMaxExceeded` - If the provided default_fee_rate exceeds MAX_FEE_RATE.\"],\"accounts\":[{\"name\":\"config\",\"isMut\":false,\"isSigner\":false},{\"name\":\"feeTier\",\"isMut\":true,\"isSigner\":false},{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"feeAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"tickSpacing\",\"type\":\"u16\"},{\"name\":\"defaultFeeRate\",\"type\":\"u16\"}]},{\"name\":\"initializeReward\",\"docs\":[\"Initialize reward for a Whirlpool. A pool can only support up to a set number of rewards.\",\"\",\"### Authority\",\"- \\\"reward_authority\\\" - assigned authority by the reward_super_authority for the specified\",\"reward-index in this Whirlpool\",\"\",\"### Parameters\",\"- `reward_index` - The reward index that we'd like to initialize. (0 <= index <= NUM_REWARDS)\",\"\",\"#### Special Errors\",\"- `InvalidRewardIndex` - If the provided reward index doesn't match the lowest uninitialized\",\"index in this pool, or exceeds NUM_REWARDS, or\",\"all reward slots for this pool has been initialized.\"],\"accounts\":[{\"name\":\"rewardAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"rewardMint\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rewardVault\",\"isMut\":true,\"isSigner\":true},{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rent\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"rewardIndex\",\"type\":\"u8\"}]},{\"name\":\"setRewardEmissions\",\"docs\":[\"Set the reward emissions for a reward in a Whirlpool.\",\"\",\"### Authority\",\"- \\\"reward_authority\\\" - assigned authority by the reward_super_authority for the specified\",\"reward-index in this Whirlpool\",\"\",\"### Parameters\",\"- `reward_index` - The reward index (0 <= index <= NUM_REWARDS) that we'd like to modify.\",\"- `emissions_per_second_x64` - The amount of rewards emitted in this pool.\",\"\",\"#### Special Errors\",\"- `RewardVaultAmountInsufficient` - The amount of rewards in the reward vault cannot emit\",\"more than a day of desired emissions.\",\"- `InvalidTimestamp` - Provided timestamp is not in order with the previous timestamp.\",\"- `InvalidRewardIndex` - If the provided reward index doesn't match the lowest uninitialized\",\"index in this pool, or exceeds NUM_REWARDS, or\",\"all reward slots for this pool has been initialized.\"],\"accounts\":[{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"rewardAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"rewardVault\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"rewardIndex\",\"type\":\"u8\"},{\"name\":\"emissionsPerSecondX64\",\"type\":\"u128\"}]},{\"name\":\"openPosition\",\"docs\":[\"Open a position in a Whirlpool. A unique token will be minted to represent the position\",\"in the users wallet. The position will start off with 0 liquidity.\",\"\",\"### Parameters\",\"- `tick_lower_index` - The tick specifying the lower end of the position range.\",\"- `tick_upper_index` - The tick specifying the upper end of the position range.\",\"\",\"#### Special Errors\",\"- `InvalidTickIndex` - If a provided tick is out of bounds, out of order or not a multiple of\",\"the tick-spacing in this pool.\"],\"accounts\":[{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"owner\",\"isMut\":false,\"isSigner\":false},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionMint\",\"isMut\":true,\"isSigner\":true},{\"name\":\"positionTokenAccount\",\"isMut\":true,\"isSigner\":false},{\"name\":\"whirlpool\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rent\",\"isMut\":false,\"isSigner\":false},{\"name\":\"associatedTokenProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"bumps\",\"type\":{\"defined\":\"OpenPositionBumps\"}},{\"name\":\"tickLowerIndex\",\"type\":\"i32\"},{\"name\":\"tickUpperIndex\",\"type\":\"i32\"}]},{\"name\":\"openPositionWithMetadata\",\"docs\":[\"Open a position in a Whirlpool. A unique token will be minted to represent the position\",\"in the users wallet. Additional Metaplex metadata is appended to identify the token.\",\"The position will start off with 0 liquidity.\",\"\",\"### Parameters\",\"- `tick_lower_index` - The tick specifying the lower end of the position range.\",\"- `tick_upper_index` - The tick specifying the upper end of the position range.\",\"\",\"#### Special Errors\",\"- `InvalidTickIndex` - If a provided tick is out of bounds, out of order or not a multiple of\",\"the tick-spacing in this pool.\"],\"accounts\":[{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"owner\",\"isMut\":false,\"isSigner\":false},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionMint\",\"isMut\":true,\"isSigner\":true},{\"name\":\"positionMetadataAccount\",\"isMut\":true,\"isSigner\":false,\"docs\":[\"https://github.com/metaplex-foundation/mpl-token-metadata/blob/master/programs/token-metadata/program/src/utils/metadata.rs#L78\"]},{\"name\":\"positionTokenAccount\",\"isMut\":true,\"isSigner\":false},{\"name\":\"whirlpool\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rent\",\"isMut\":false,\"isSigner\":false},{\"name\":\"associatedTokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"metadataProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"metadataUpdateAuth\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"bumps\",\"type\":{\"defined\":\"OpenPositionWithMetadataBumps\"}},{\"name\":\"tickLowerIndex\",\"type\":\"i32\"},{\"name\":\"tickUpperIndex\",\"type\":\"i32\"}]},{\"name\":\"increaseLiquidity\",\"docs\":[\"Add liquidity to a position in the Whirlpool. This call also updates the position's accrued fees and rewards.\",\"\",\"### Authority\",\"- `position_authority` - authority that owns the token corresponding to this desired position.\",\"\",\"### Parameters\",\"- `liquidity_amount` - The total amount of Liquidity the user is willing to deposit.\",\"- `token_max_a` - The maximum amount of tokenA the user is willing to deposit.\",\"- `token_max_b` - The maximum amount of tokenB the user is willing to deposit.\",\"\",\"#### Special Errors\",\"- `LiquidityZero` - Provided liquidity amount is zero.\",\"- `LiquidityTooHigh` - Provided liquidity exceeds u128::max.\",\"- `TokenMaxExceeded` - The required token to perform this operation exceeds the user defined amount.\"],\"accounts\":[{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"positionAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionTokenAccount\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenOwnerAccountA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayLower\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayUpper\",\"isMut\":true,\"isSigner\":false}],\"args\":[{\"name\":\"liquidityAmount\",\"type\":\"u128\"},{\"name\":\"tokenMaxA\",\"type\":\"u64\"},{\"name\":\"tokenMaxB\",\"type\":\"u64\"}]},{\"name\":\"decreaseLiquidity\",\"docs\":[\"Withdraw liquidity from a position in the Whirlpool. This call also updates the position's accrued fees and rewards.\",\"\",\"### Authority\",\"- `position_authority` - authority that owns the token corresponding to this desired position.\",\"\",\"### Parameters\",\"- `liquidity_amount` - The total amount of Liquidity the user desires to withdraw.\",\"- `token_min_a` - The minimum amount of tokenA the user is willing to withdraw.\",\"- `token_min_b` - The minimum amount of tokenB the user is willing to withdraw.\",\"\",\"#### Special Errors\",\"- `LiquidityZero` - Provided liquidity amount is zero.\",\"- `LiquidityTooHigh` - Provided liquidity exceeds u128::max.\",\"- `TokenMinSubceeded` - The required token to perform this operation subceeds the user defined amount.\"],\"accounts\":[{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"positionAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionTokenAccount\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenOwnerAccountA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayLower\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayUpper\",\"isMut\":true,\"isSigner\":false}],\"args\":[{\"name\":\"liquidityAmount\",\"type\":\"u128\"},{\"name\":\"tokenMinA\",\"type\":\"u64\"},{\"name\":\"tokenMinB\",\"type\":\"u64\"}]},{\"name\":\"updateFeesAndRewards\",\"docs\":[\"Update the accrued fees and rewards for a position.\",\"\",\"#### Special Errors\",\"- `TickNotFound` - Provided tick array account does not contain the tick for this position.\",\"- `LiquidityZero` - Position has zero liquidity and therefore already has the most updated fees and reward values.\"],\"accounts\":[{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayLower\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tickArrayUpper\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"collectFees\",\"docs\":[\"Collect fees accrued for this position.\",\"\",\"### Authority\",\"- `position_authority` - authority that owns the token corresponding to this desired position.\"],\"accounts\":[{\"name\":\"whirlpool\",\"isMut\":false,\"isSigner\":false},{\"name\":\"positionAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionTokenAccount\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenOwnerAccountA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"collectReward\",\"docs\":[\"Collect rewards accrued for this position.\",\"\",\"### Authority\",\"- `position_authority` - authority that owns the token corresponding to this desired position.\"],\"accounts\":[{\"name\":\"whirlpool\",\"isMut\":false,\"isSigner\":false},{\"name\":\"positionAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionTokenAccount\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rewardOwnerAccount\",\"isMut\":true,\"isSigner\":false},{\"name\":\"rewardVault\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"rewardIndex\",\"type\":\"u8\"}]},{\"name\":\"collectProtocolFees\",\"docs\":[\"Collect the protocol fees accrued in this Whirlpool\",\"\",\"### Authority\",\"- `collect_protocol_fees_authority` - assigned authority in the WhirlpoolConfig that can collect protocol fees\"],\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":false,\"isSigner\":false},{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"collectProtocolFeesAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"tokenVaultA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenDestinationA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenDestinationB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"swap\",\"docs\":[\"Perform a swap in this Whirlpool\",\"\",\"### Authority\",\"- \\\"token_authority\\\" - The authority to withdraw tokens from the input token account.\",\"\",\"### Parameters\",\"- `amount` - The amount of input or output token to swap from (depending on amount_specified_is_input).\",\"- `other_amount_threshold` - The maximum/minimum of input/output token to swap into (depending on amount_specified_is_input).\",\"- `sqrt_price_limit` - The maximum/minimum price the swap will swap to.\",\"- `amount_specified_is_input` - Specifies the token the parameter `amount`represents. If true, the amount represents the input token of the swap.\",\"- `a_to_b` - The direction of the swap. True if swapping from A to B. False if swapping from B to A.\",\"\",\"#### Special Errors\",\"- `ZeroTradableAmount` - User provided parameter `amount` is 0.\",\"- `InvalidSqrtPriceLimitDirection` - User provided parameter `sqrt_price_limit` does not match the direction of the trade.\",\"- `SqrtPriceOutOfBounds` - User provided parameter `sqrt_price_limit` is over Whirlppool's max/min bounds for sqrt-price.\",\"- `InvalidTickArraySequence` - User provided tick-arrays are not in sequential order required to proceed in this trade direction.\",\"- `TickArraySequenceInvalidIndex` - The swap loop attempted to access an invalid array index during the query of the next initialized tick.\",\"- `TickArrayIndexOutofBounds` - The swap loop attempted to access an invalid array index during tick crossing.\",\"- `LiquidityOverflow` - Liquidity value overflowed 128bits during tick crossing.\",\"- `InvalidTickSpacing` - The swap pool was initialized with tick-spacing of 0.\"],\"accounts\":[{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArray0\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArray1\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArray2\",\"isMut\":true,\"isSigner\":false},{\"name\":\"oracle\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"amount\",\"type\":\"u64\"},{\"name\":\"otherAmountThreshold\",\"type\":\"u64\"},{\"name\":\"sqrtPriceLimit\",\"type\":\"u128\"},{\"name\":\"amountSpecifiedIsInput\",\"type\":\"bool\"},{\"name\":\"aToB\",\"type\":\"bool\"}]},{\"name\":\"closePosition\",\"docs\":[\"Close a position in a Whirlpool. Burns the position token in the owner's wallet.\",\"\",\"### Authority\",\"- \\\"position_authority\\\" - The authority that owns the position token.\",\"\",\"#### Special Errors\",\"- `ClosePositionNotEmpty` - The provided position account is not empty.\"],\"accounts\":[{\"name\":\"positionAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"receiver\",\"isMut\":true,\"isSigner\":false},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionMint\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionTokenAccount\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"setDefaultFeeRate\",\"docs\":[\"Set the default_fee_rate for a FeeTier\",\"Only the current fee authority has permission to invoke this instruction.\",\"\",\"### Authority\",\"- \\\"fee_authority\\\" - Set authority in the WhirlpoolConfig\",\"\",\"### Parameters\",\"- `default_fee_rate` - The default fee rate that a pool will use if the pool uses this\",\"fee tier during initialization.\",\"\",\"#### Special Errors\",\"- `FeeRateMaxExceeded` - If the provided default_fee_rate exceeds MAX_FEE_RATE.\"],\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":false,\"isSigner\":false},{\"name\":\"feeTier\",\"isMut\":true,\"isSigner\":false},{\"name\":\"feeAuthority\",\"isMut\":false,\"isSigner\":true}],\"args\":[{\"name\":\"defaultFeeRate\",\"type\":\"u16\"}]},{\"name\":\"setDefaultProtocolFeeRate\",\"docs\":[\"Sets the default protocol fee rate for a WhirlpoolConfig\",\"Protocol fee rate is represented as a basis point.\",\"Only the current fee authority has permission to invoke this instruction.\",\"\",\"### Authority\",\"- \\\"fee_authority\\\" - Set authority that can modify pool fees in the WhirlpoolConfig\",\"\",\"### Parameters\",\"- `default_protocol_fee_rate` - Rate that is referenced during the initialization of a Whirlpool using this config.\",\"\",\"#### Special Errors\",\"- `ProtocolFeeRateMaxExceeded` - If the provided default_protocol_fee_rate exceeds MAX_PROTOCOL_FEE_RATE.\"],\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":true,\"isSigner\":false},{\"name\":\"feeAuthority\",\"isMut\":false,\"isSigner\":true}],\"args\":[{\"name\":\"defaultProtocolFeeRate\",\"type\":\"u16\"}]},{\"name\":\"setFeeRate\",\"docs\":[\"Sets the fee rate for a Whirlpool.\",\"Fee rate is represented as hundredths of a basis point.\",\"Only the current fee authority has permission to invoke this instruction.\",\"\",\"### Authority\",\"- \\\"fee_authority\\\" - Set authority that can modify pool fees in the WhirlpoolConfig\",\"\",\"### Parameters\",\"- `fee_rate` - The rate that the pool will use to calculate fees going onwards.\",\"\",\"#### Special Errors\",\"- `FeeRateMaxExceeded` - If the provided fee_rate exceeds MAX_FEE_RATE.\"],\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":false,\"isSigner\":false},{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"feeAuthority\",\"isMut\":false,\"isSigner\":true}],\"args\":[{\"name\":\"feeRate\",\"type\":\"u16\"}]},{\"name\":\"setProtocolFeeRate\",\"docs\":[\"Sets the protocol fee rate for a Whirlpool.\",\"Protocol fee rate is represented as a basis point.\",\"Only the current fee authority has permission to invoke this instruction.\",\"\",\"### Authority\",\"- \\\"fee_authority\\\" - Set authority that can modify pool fees in the WhirlpoolConfig\",\"\",\"### Parameters\",\"- `protocol_fee_rate` - The rate that the pool will use to calculate protocol fees going onwards.\",\"\",\"#### Special Errors\",\"- `ProtocolFeeRateMaxExceeded` - If the provided default_protocol_fee_rate exceeds MAX_PROTOCOL_FEE_RATE.\"],\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":false,\"isSigner\":false},{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"feeAuthority\",\"isMut\":false,\"isSigner\":true}],\"args\":[{\"name\":\"protocolFeeRate\",\"type\":\"u16\"}]},{\"name\":\"setFeeAuthority\",\"docs\":[\"Sets the fee authority for a WhirlpoolConfig.\",\"The fee authority can set the fee & protocol fee rate for individual pools or\",\"set the default fee rate for newly minted pools.\",\"Only the current fee authority has permission to invoke this instruction.\",\"\",\"### Authority\",\"- \\\"fee_authority\\\" - Set authority that can modify pool fees in the WhirlpoolConfig\"],\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":true,\"isSigner\":false},{\"name\":\"feeAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"newFeeAuthority\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"setCollectProtocolFeesAuthority\",\"docs\":[\"Sets the fee authority to collect protocol fees for a WhirlpoolConfig.\",\"Only the current collect protocol fee authority has permission to invoke this instruction.\",\"\",\"### Authority\",\"- \\\"fee_authority\\\" - Set authority that can collect protocol fees in the WhirlpoolConfig\"],\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":true,\"isSigner\":false},{\"name\":\"collectProtocolFeesAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"newCollectProtocolFeesAuthority\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"setRewardAuthority\",\"docs\":[\"Set the whirlpool reward authority at the provided `reward_index`.\",\"Only the current reward authority for this reward index has permission to invoke this instruction.\",\"\",\"### Authority\",\"- \\\"reward_authority\\\" - Set authority that can control reward emission for this particular reward.\",\"\",\"#### Special Errors\",\"- `InvalidRewardIndex` - If the provided reward index doesn't match the lowest uninitialized\",\"index in this pool, or exceeds NUM_REWARDS, or\",\"all reward slots for this pool has been initialized.\"],\"accounts\":[{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"rewardAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"newRewardAuthority\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"rewardIndex\",\"type\":\"u8\"}]},{\"name\":\"setRewardAuthorityBySuperAuthority\",\"docs\":[\"Set the whirlpool reward authority at the provided `reward_index`.\",\"Only the current reward super authority has permission to invoke this instruction.\",\"\",\"### Authority\",\"- \\\"reward_authority\\\" - Set authority that can control reward emission for this particular reward.\",\"\",\"#### Special Errors\",\"- `InvalidRewardIndex` - If the provided reward index doesn't match the lowest uninitialized\",\"index in this pool, or exceeds NUM_REWARDS, or\",\"all reward slots for this pool has been initialized.\"],\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":false,\"isSigner\":false},{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"rewardEmissionsSuperAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"newRewardAuthority\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"rewardIndex\",\"type\":\"u8\"}]},{\"name\":\"setRewardEmissionsSuperAuthority\",\"docs\":[\"Set the whirlpool reward super authority for a WhirlpoolConfig\",\"Only the current reward super authority has permission to invoke this instruction.\",\"This instruction will not change the authority on any `WhirlpoolRewardInfo` whirlpool rewards.\",\"\",\"### Authority\",\"- \\\"reward_emissions_super_authority\\\" - Set authority that can control reward authorities for all pools in this config space.\"],\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":true,\"isSigner\":false},{\"name\":\"rewardEmissionsSuperAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"newRewardEmissionsSuperAuthority\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"twoHopSwap\",\"docs\":[\"Perform a two-hop swap in this Whirlpool\",\"\",\"### Authority\",\"- \\\"token_authority\\\" - The authority to withdraw tokens from the input token account.\",\"\",\"### Parameters\",\"- `amount` - The amount of input or output token to swap from (depending on amount_specified_is_input).\",\"- `other_amount_threshold` - The maximum/minimum of input/output token to swap into (depending on amount_specified_is_input).\",\"- `amount_specified_is_input` - Specifies the token the parameter `amount`represents. If true, the amount represents the input token of the swap.\",\"- `a_to_b_one` - The direction of the swap of hop one. True if swapping from A to B. False if swapping from B to A.\",\"- `a_to_b_two` - The direction of the swap of hop two. True if swapping from A to B. False if swapping from B to A.\",\"- `sqrt_price_limit_one` - The maximum/minimum price the swap will swap to in the first hop.\",\"- `sqrt_price_limit_two` - The maximum/minimum price the swap will swap to in the second hop.\",\"\",\"#### Special Errors\",\"- `ZeroTradableAmount` - User provided parameter `amount` is 0.\",\"- `InvalidSqrtPriceLimitDirection` - User provided parameter `sqrt_price_limit` does not match the direction of the trade.\",\"- `SqrtPriceOutOfBounds` - User provided parameter `sqrt_price_limit` is over Whirlppool's max/min bounds for sqrt-price.\",\"- `InvalidTickArraySequence` - User provided tick-arrays are not in sequential order required to proceed in this trade direction.\",\"- `TickArraySequenceInvalidIndex` - The swap loop attempted to access an invalid array index during the query of the next initialized tick.\",\"- `TickArrayIndexOutofBounds` - The swap loop attempted to access an invalid array index during tick crossing.\",\"- `LiquidityOverflow` - Liquidity value overflowed 128bits during tick crossing.\",\"- `InvalidTickSpacing` - The swap pool was initialized with tick-spacing of 0.\",\"- `InvalidIntermediaryMint` - Error if the intermediary mint between hop one and two do not equal.\",\"- `DuplicateTwoHopPool` - Error if whirlpool one & two are the same pool.\"],\"accounts\":[{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"whirlpoolOne\",\"isMut\":true,\"isSigner\":false},{\"name\":\"whirlpoolTwo\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountOneA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultOneA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountOneB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultOneB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountTwoA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultTwoA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountTwoB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultTwoB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayOne0\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayOne1\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayOne2\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayTwo0\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayTwo1\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayTwo2\",\"isMut\":true,\"isSigner\":false},{\"name\":\"oracleOne\",\"isMut\":false,\"isSigner\":false},{\"name\":\"oracleTwo\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"amount\",\"type\":\"u64\"},{\"name\":\"otherAmountThreshold\",\"type\":\"u64\"},{\"name\":\"amountSpecifiedIsInput\",\"type\":\"bool\"},{\"name\":\"aToBOne\",\"type\":\"bool\"},{\"name\":\"aToBTwo\",\"type\":\"bool\"},{\"name\":\"sqrtPriceLimitOne\",\"type\":\"u128\"},{\"name\":\"sqrtPriceLimitTwo\",\"type\":\"u128\"}]},{\"name\":\"initializePositionBundle\",\"docs\":[\"Initializes a PositionBundle account that bundles several positions.\",\"A unique token will be minted to represent the position bundle in the users wallet.\"],\"accounts\":[{\"name\":\"positionBundle\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionBundleMint\",\"isMut\":true,\"isSigner\":true},{\"name\":\"positionBundleTokenAccount\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionBundleOwner\",\"isMut\":false,\"isSigner\":false},{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rent\",\"isMut\":false,\"isSigner\":false},{\"name\":\"associatedTokenProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"initializePositionBundleWithMetadata\",\"docs\":[\"Initializes a PositionBundle account that bundles several positions.\",\"A unique token will be minted to represent the position bundle in the users wallet.\",\"Additional Metaplex metadata is appended to identify the token.\"],\"accounts\":[{\"name\":\"positionBundle\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionBundleMint\",\"isMut\":true,\"isSigner\":true},{\"name\":\"positionBundleMetadata\",\"isMut\":true,\"isSigner\":false,\"docs\":[\"https://github.com/metaplex-foundation/metaplex-program-library/blob/773a574c4b34e5b9f248a81306ec24db064e255f/token-metadata/program/src/utils/metadata.rs#L100\"]},{\"name\":\"positionBundleTokenAccount\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionBundleOwner\",\"isMut\":false,\"isSigner\":false},{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"metadataUpdateAuth\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rent\",\"isMut\":false,\"isSigner\":false},{\"name\":\"associatedTokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"metadataProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"deletePositionBundle\",\"docs\":[\"Delete a PositionBundle account. Burns the position bundle token in the owner's wallet.\",\"\",\"### Authority\",\"- `position_bundle_owner` - The owner that owns the position bundle token.\",\"\",\"### Special Errors\",\"- `PositionBundleNotDeletable` - The provided position bundle has open positions.\"],\"accounts\":[{\"name\":\"positionBundle\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionBundleMint\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionBundleTokenAccount\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionBundleOwner\",\"isMut\":false,\"isSigner\":true},{\"name\":\"receiver\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"openBundledPosition\",\"docs\":[\"Open a bundled position in a Whirlpool. No new tokens are issued\",\"because the owner of the position bundle becomes the owner of the position.\",\"The position will start off with 0 liquidity.\",\"\",\"### Authority\",\"- `position_bundle_authority` - authority that owns the token corresponding to this desired position bundle.\",\"\",\"### Parameters\",\"- `bundle_index` - The bundle index that we'd like to open.\",\"- `tick_lower_index` - The tick specifying the lower end of the position range.\",\"- `tick_upper_index` - The tick specifying the upper end of the position range.\",\"\",\"#### Special Errors\",\"- `InvalidBundleIndex` - If the provided bundle index is out of bounds.\",\"- `InvalidTickIndex` - If a provided tick is out of bounds, out of order or not a multiple of\",\"the tick-spacing in this pool.\"],\"accounts\":[{\"name\":\"bundledPosition\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionBundle\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionBundleTokenAccount\",\"isMut\":false,\"isSigner\":false},{\"name\":\"positionBundleAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"whirlpool\",\"isMut\":false,\"isSigner\":false},{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rent\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"bundleIndex\",\"type\":\"u16\"},{\"name\":\"tickLowerIndex\",\"type\":\"i32\"},{\"name\":\"tickUpperIndex\",\"type\":\"i32\"}]},{\"name\":\"closeBundledPosition\",\"docs\":[\"Close a bundled position in a Whirlpool.\",\"\",\"### Authority\",\"- `position_bundle_authority` - authority that owns the token corresponding to this desired position bundle.\",\"\",\"### Parameters\",\"- `bundle_index` - The bundle index that we'd like to close.\",\"\",\"#### Special Errors\",\"- `InvalidBundleIndex` - If the provided bundle index is out of bounds.\",\"- `ClosePositionNotEmpty` - The provided position account is not empty.\"],\"accounts\":[{\"name\":\"bundledPosition\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionBundle\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionBundleTokenAccount\",\"isMut\":false,\"isSigner\":false},{\"name\":\"positionBundleAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"receiver\",\"isMut\":true,\"isSigner\":false}],\"args\":[{\"name\":\"bundleIndex\",\"type\":\"u16\"}]},{\"name\":\"openPositionWithTokenExtensions\",\"docs\":[\"Open a position in a Whirlpool. A unique token will be minted to represent the position\",\"in the users wallet. Additional TokenMetadata extension is initialized to identify the token.\",\"Mint and TokenAccount are based on Token-2022.\",\"The position will start off with 0 liquidity.\",\"\",\"### Parameters\",\"- `tick_lower_index` - The tick specifying the lower end of the position range.\",\"- `tick_upper_index` - The tick specifying the upper end of the position range.\",\"- `with_token_metadata_extension` - If true, the token metadata extension will be initialized.\",\"\",\"#### Special Errors\",\"- `InvalidTickIndex` - If a provided tick is out of bounds, out of order or not a multiple of\",\"the tick-spacing in this pool.\"],\"accounts\":[{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"owner\",\"isMut\":false,\"isSigner\":false},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionMint\",\"isMut\":true,\"isSigner\":true},{\"name\":\"positionTokenAccount\",\"isMut\":true,\"isSigner\":false},{\"name\":\"whirlpool\",\"isMut\":false,\"isSigner\":false},{\"name\":\"token2022Program\",\"isMut\":false,\"isSigner\":false},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"associatedTokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"metadataUpdateAuth\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"tickLowerIndex\",\"type\":\"i32\"},{\"name\":\"tickUpperIndex\",\"type\":\"i32\"},{\"name\":\"withTokenMetadataExtension\",\"type\":\"bool\"}]},{\"name\":\"closePositionWithTokenExtensions\",\"docs\":[\"Close a position in a Whirlpool. Burns the position token in the owner's wallet.\",\"Mint and TokenAccount are based on Token-2022. And Mint accout will be also closed.\",\"\",\"### Authority\",\"- \\\"position_authority\\\" - The authority that owns the position token.\",\"\",\"#### Special Errors\",\"- `ClosePositionNotEmpty` - The provided position account is not empty.\"],\"accounts\":[{\"name\":\"positionAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"receiver\",\"isMut\":true,\"isSigner\":false},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionMint\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionTokenAccount\",\"isMut\":true,\"isSigner\":false},{\"name\":\"token2022Program\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"collectFeesV2\",\"docs\":[\"Collect fees accrued for this position.\",\"\",\"### Authority\",\"- `position_authority` - authority that owns the token corresponding to this desired position.\"],\"accounts\":[{\"name\":\"whirlpool\",\"isMut\":false,\"isSigner\":false},{\"name\":\"positionAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionTokenAccount\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenOwnerAccountA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenProgramA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgramB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"memoProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"remainingAccountsInfo\",\"type\":{\"option\":{\"defined\":\"RemainingAccountsInfo\"}}}]},{\"name\":\"collectProtocolFeesV2\",\"docs\":[\"Collect the protocol fees accrued in this Whirlpool\",\"\",\"### Authority\",\"- `collect_protocol_fees_authority` - assigned authority in the WhirlpoolConfig that can collect protocol fees\"],\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":false,\"isSigner\":false},{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"collectProtocolFeesAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"tokenMintA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenVaultA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenDestinationA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenDestinationB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenProgramA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgramB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"memoProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"remainingAccountsInfo\",\"type\":{\"option\":{\"defined\":\"RemainingAccountsInfo\"}}}]},{\"name\":\"collectRewardV2\",\"docs\":[\"Collect rewards accrued for this position.\",\"\",\"### Authority\",\"- `position_authority` - authority that owns the token corresponding to this desired position.\"],\"accounts\":[{\"name\":\"whirlpool\",\"isMut\":false,\"isSigner\":false},{\"name\":\"positionAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionTokenAccount\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rewardOwnerAccount\",\"isMut\":true,\"isSigner\":false},{\"name\":\"rewardMint\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rewardVault\",\"isMut\":true,\"isSigner\":false},{\"name\":\"rewardTokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"memoProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"rewardIndex\",\"type\":\"u8\"},{\"name\":\"remainingAccountsInfo\",\"type\":{\"option\":{\"defined\":\"RemainingAccountsInfo\"}}}]},{\"name\":\"decreaseLiquidityV2\",\"docs\":[\"Withdraw liquidity from a position in the Whirlpool. This call also updates the position's accrued fees and rewards.\",\"\",\"### Authority\",\"- `position_authority` - authority that owns the token corresponding to this desired position.\",\"\",\"### Parameters\",\"- `liquidity_amount` - The total amount of Liquidity the user desires to withdraw.\",\"- `token_min_a` - The minimum amount of tokenA the user is willing to withdraw.\",\"- `token_min_b` - The minimum amount of tokenB the user is willing to withdraw.\",\"\",\"#### Special Errors\",\"- `LiquidityZero` - Provided liquidity amount is zero.\",\"- `LiquidityTooHigh` - Provided liquidity exceeds u128::max.\",\"- `TokenMinSubceeded` - The required token to perform this operation subceeds the user defined amount.\"],\"accounts\":[{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenProgramA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgramB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"memoProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"positionAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionTokenAccount\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenOwnerAccountA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayLower\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayUpper\",\"isMut\":true,\"isSigner\":false}],\"args\":[{\"name\":\"liquidityAmount\",\"type\":\"u128\"},{\"name\":\"tokenMinA\",\"type\":\"u64\"},{\"name\":\"tokenMinB\",\"type\":\"u64\"},{\"name\":\"remainingAccountsInfo\",\"type\":{\"option\":{\"defined\":\"RemainingAccountsInfo\"}}}]},{\"name\":\"increaseLiquidityV2\",\"docs\":[\"Add liquidity to a position in the Whirlpool. This call also updates the position's accrued fees and rewards.\",\"\",\"### Authority\",\"- `position_authority` - authority that owns the token corresponding to this desired position.\",\"\",\"### Parameters\",\"- `liquidity_amount` - The total amount of Liquidity the user is willing to deposit.\",\"- `token_max_a` - The maximum amount of tokenA the user is willing to deposit.\",\"- `token_max_b` - The maximum amount of tokenB the user is willing to deposit.\",\"\",\"#### Special Errors\",\"- `LiquidityZero` - Provided liquidity amount is zero.\",\"- `LiquidityTooHigh` - Provided liquidity exceeds u128::max.\",\"- `TokenMaxExceeded` - The required token to perform this operation exceeds the user defined amount.\"],\"accounts\":[{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenProgramA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgramB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"memoProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"positionAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"position\",\"isMut\":true,\"isSigner\":false},{\"name\":\"positionTokenAccount\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenOwnerAccountA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayLower\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayUpper\",\"isMut\":true,\"isSigner\":false}],\"args\":[{\"name\":\"liquidityAmount\",\"type\":\"u128\"},{\"name\":\"tokenMaxA\",\"type\":\"u64\"},{\"name\":\"tokenMaxB\",\"type\":\"u64\"},{\"name\":\"remainingAccountsInfo\",\"type\":{\"option\":{\"defined\":\"RemainingAccountsInfo\"}}}]},{\"name\":\"initializePoolV2\",\"docs\":[\"Initializes a Whirlpool account.\",\"Fee rate is set to the default values on the config and supplied fee_tier.\",\"\",\"### Parameters\",\"- `bumps` - The bump value when deriving the PDA of the Whirlpool address.\",\"- `tick_spacing` - The desired tick spacing for this pool.\",\"- `initial_sqrt_price` - The desired initial sqrt-price for this pool\",\"\",\"#### Special Errors\",\"`InvalidTokenMintOrder` - The order of mints have to be ordered by\",\"`SqrtPriceOutOfBounds` - provided initial_sqrt_price is not between 2^-64 to 2^64\",\"\"],\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenBadgeA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenBadgeB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultA\",\"isMut\":true,\"isSigner\":true},{\"name\":\"tokenVaultB\",\"isMut\":true,\"isSigner\":true},{\"name\":\"feeTier\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgramA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgramB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rent\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"tickSpacing\",\"type\":\"u16\"},{\"name\":\"initialSqrtPrice\",\"type\":\"u128\"}]},{\"name\":\"initializeRewardV2\",\"docs\":[\"Initialize reward for a Whirlpool. A pool can only support up to a set number of rewards.\",\"\",\"### Authority\",\"- \\\"reward_authority\\\" - assigned authority by the reward_super_authority for the specified\",\"reward-index in this Whirlpool\",\"\",\"### Parameters\",\"- `reward_index` - The reward index that we'd like to initialize. (0 <= index <= NUM_REWARDS)\",\"\",\"#### Special Errors\",\"- `InvalidRewardIndex` - If the provided reward index doesn't match the lowest uninitialized\",\"index in this pool, or exceeds NUM_REWARDS, or\",\"all reward slots for this pool has been initialized.\"],\"accounts\":[{\"name\":\"rewardAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"rewardMint\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rewardTokenBadge\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rewardVault\",\"isMut\":true,\"isSigner\":true},{\"name\":\"rewardTokenProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"rent\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"rewardIndex\",\"type\":\"u8\"}]},{\"name\":\"setRewardEmissionsV2\",\"docs\":[\"Set the reward emissions for a reward in a Whirlpool.\",\"\",\"### Authority\",\"- \\\"reward_authority\\\" - assigned authority by the reward_super_authority for the specified\",\"reward-index in this Whirlpool\",\"\",\"### Parameters\",\"- `reward_index` - The reward index (0 <= index <= NUM_REWARDS) that we'd like to modify.\",\"- `emissions_per_second_x64` - The amount of rewards emitted in this pool.\",\"\",\"#### Special Errors\",\"- `RewardVaultAmountInsufficient` - The amount of rewards in the reward vault cannot emit\",\"more than a day of desired emissions.\",\"- `InvalidTimestamp` - Provided timestamp is not in order with the previous timestamp.\",\"- `InvalidRewardIndex` - If the provided reward index doesn't match the lowest uninitialized\",\"index in this pool, or exceeds NUM_REWARDS, or\",\"all reward slots for this pool has been initialized.\"],\"accounts\":[{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"rewardAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"rewardVault\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"rewardIndex\",\"type\":\"u8\"},{\"name\":\"emissionsPerSecondX64\",\"type\":\"u128\"}]},{\"name\":\"swapV2\",\"docs\":[\"Perform a swap in this Whirlpool\",\"\",\"### Authority\",\"- \\\"token_authority\\\" - The authority to withdraw tokens from the input token account.\",\"\",\"### Parameters\",\"- `amount` - The amount of input or output token to swap from (depending on amount_specified_is_input).\",\"- `other_amount_threshold` - The maximum/minimum of input/output token to swap into (depending on amount_specified_is_input).\",\"- `sqrt_price_limit` - The maximum/minimum price the swap will swap to.\",\"- `amount_specified_is_input` - Specifies the token the parameter `amount`represents. If true, the amount represents the input token of the swap.\",\"- `a_to_b` - The direction of the swap. True if swapping from A to B. False if swapping from B to A.\",\"\",\"#### Special Errors\",\"- `ZeroTradableAmount` - User provided parameter `amount` is 0.\",\"- `InvalidSqrtPriceLimitDirection` - User provided parameter `sqrt_price_limit` does not match the direction of the trade.\",\"- `SqrtPriceOutOfBounds` - User provided parameter `sqrt_price_limit` is over Whirlppool's max/min bounds for sqrt-price.\",\"- `InvalidTickArraySequence` - User provided tick-arrays are not in sequential order required to proceed in this trade direction.\",\"- `TickArraySequenceInvalidIndex` - The swap loop attempted to access an invalid array index during the query of the next initialized tick.\",\"- `TickArrayIndexOutofBounds` - The swap loop attempted to access an invalid array index during tick crossing.\",\"- `LiquidityOverflow` - Liquidity value overflowed 128bits during tick crossing.\",\"- `InvalidTickSpacing` - The swap pool was initialized with tick-spacing of 0.\"],\"accounts\":[{\"name\":\"tokenProgramA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgramB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"memoProgram\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"whirlpool\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenMintA\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintB\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenOwnerAccountA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultA\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultB\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArray0\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArray1\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArray2\",\"isMut\":true,\"isSigner\":false},{\"name\":\"oracle\",\"isMut\":true,\"isSigner\":false}],\"args\":[{\"name\":\"amount\",\"type\":\"u64\"},{\"name\":\"otherAmountThreshold\",\"type\":\"u64\"},{\"name\":\"sqrtPriceLimit\",\"type\":\"u128\"},{\"name\":\"amountSpecifiedIsInput\",\"type\":\"bool\"},{\"name\":\"aToB\",\"type\":\"bool\"},{\"name\":\"remainingAccountsInfo\",\"type\":{\"option\":{\"defined\":\"RemainingAccountsInfo\"}}}]},{\"name\":\"twoHopSwapV2\",\"docs\":[\"Perform a two-hop swap in this Whirlpool\",\"\",\"### Authority\",\"- \\\"token_authority\\\" - The authority to withdraw tokens from the input token account.\",\"\",\"### Parameters\",\"- `amount` - The amount of input or output token to swap from (depending on amount_specified_is_input).\",\"- `other_amount_threshold` - The maximum/minimum of input/output token to swap into (depending on amount_specified_is_input).\",\"- `amount_specified_is_input` - Specifies the token the parameter `amount`represents. If true, the amount represents the input token of the swap.\",\"- `a_to_b_one` - The direction of the swap of hop one. True if swapping from A to B. False if swapping from B to A.\",\"- `a_to_b_two` - The direction of the swap of hop two. True if swapping from A to B. False if swapping from B to A.\",\"- `sqrt_price_limit_one` - The maximum/minimum price the swap will swap to in the first hop.\",\"- `sqrt_price_limit_two` - The maximum/minimum price the swap will swap to in the second hop.\",\"\",\"#### Special Errors\",\"- `ZeroTradableAmount` - User provided parameter `amount` is 0.\",\"- `InvalidSqrtPriceLimitDirection` - User provided parameter `sqrt_price_limit` does not match the direction of the trade.\",\"- `SqrtPriceOutOfBounds` - User provided parameter `sqrt_price_limit` is over Whirlppool's max/min bounds for sqrt-price.\",\"- `InvalidTickArraySequence` - User provided tick-arrays are not in sequential order required to proceed in this trade direction.\",\"- `TickArraySequenceInvalidIndex` - The swap loop attempted to access an invalid array index during the query of the next initialized tick.\",\"- `TickArrayIndexOutofBounds` - The swap loop attempted to access an invalid array index during tick crossing.\",\"- `LiquidityOverflow` - Liquidity value overflowed 128bits during tick crossing.\",\"- `InvalidTickSpacing` - The swap pool was initialized with tick-spacing of 0.\",\"- `InvalidIntermediaryMint` - Error if the intermediary mint between hop one and two do not equal.\",\"- `DuplicateTwoHopPool` - Error if whirlpool one & two are the same pool.\"],\"accounts\":[{\"name\":\"whirlpoolOne\",\"isMut\":true,\"isSigner\":false},{\"name\":\"whirlpoolTwo\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenMintInput\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintIntermediate\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenMintOutput\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgramInput\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgramIntermediate\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenProgramOutput\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenOwnerAccountInput\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultOneInput\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultOneIntermediate\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultTwoIntermediate\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenVaultTwoOutput\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenOwnerAccountOutput\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tokenAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"tickArrayOne0\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayOne1\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayOne2\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayTwo0\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayTwo1\",\"isMut\":true,\"isSigner\":false},{\"name\":\"tickArrayTwo2\",\"isMut\":true,\"isSigner\":false},{\"name\":\"oracleOne\",\"isMut\":true,\"isSigner\":false},{\"name\":\"oracleTwo\",\"isMut\":true,\"isSigner\":false},{\"name\":\"memoProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[{\"name\":\"amount\",\"type\":\"u64\"},{\"name\":\"otherAmountThreshold\",\"type\":\"u64\"},{\"name\":\"amountSpecifiedIsInput\",\"type\":\"bool\"},{\"name\":\"aToBOne\",\"type\":\"bool\"},{\"name\":\"aToBTwo\",\"type\":\"bool\"},{\"name\":\"sqrtPriceLimitOne\",\"type\":\"u128\"},{\"name\":\"sqrtPriceLimitTwo\",\"type\":\"u128\"},{\"name\":\"remainingAccountsInfo\",\"type\":{\"option\":{\"defined\":\"RemainingAccountsInfo\"}}}]},{\"name\":\"initializeConfigExtension\",\"accounts\":[{\"name\":\"config\",\"isMut\":false,\"isSigner\":false},{\"name\":\"configExtension\",\"isMut\":true,\"isSigner\":false},{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"feeAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"setConfigExtensionAuthority\",\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":false,\"isSigner\":false},{\"name\":\"whirlpoolsConfigExtension\",\"isMut\":true,\"isSigner\":false},{\"name\":\"configExtensionAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"newConfigExtensionAuthority\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"setTokenBadgeAuthority\",\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":false,\"isSigner\":false},{\"name\":\"whirlpoolsConfigExtension\",\"isMut\":true,\"isSigner\":false},{\"name\":\"configExtensionAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"newTokenBadgeAuthority\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"initializeTokenBadge\",\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":false,\"isSigner\":false},{\"name\":\"whirlpoolsConfigExtension\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenBadgeAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"tokenMint\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenBadge\",\"isMut\":true,\"isSigner\":false},{\"name\":\"funder\",\"isMut\":true,\"isSigner\":true},{\"name\":\"systemProgram\",\"isMut\":false,\"isSigner\":false}],\"args\":[]},{\"name\":\"deleteTokenBadge\",\"accounts\":[{\"name\":\"whirlpoolsConfig\",\"isMut\":false,\"isSigner\":false},{\"name\":\"whirlpoolsConfigExtension\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenBadgeAuthority\",\"isMut\":false,\"isSigner\":true},{\"name\":\"tokenMint\",\"isMut\":false,\"isSigner\":false},{\"name\":\"tokenBadge\",\"isMut\":true,\"isSigner\":false},{\"name\":\"receiver\",\"isMut\":true,\"isSigner\":false}],\"args\":[]}],\"accounts\":[{\"name\":\"WhirlpoolsConfig\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"feeAuthority\",\"type\":\"publicKey\"},{\"name\":\"collectProtocolFeesAuthority\",\"type\":\"publicKey\"},{\"name\":\"rewardEmissionsSuperAuthority\",\"type\":\"publicKey\"},{\"name\":\"defaultProtocolFeeRate\",\"type\":\"u16\"}]}},{\"name\":\"WhirlpoolsConfigExtension\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"whirlpoolsConfig\",\"type\":\"publicKey\"},{\"name\":\"configExtensionAuthority\",\"type\":\"publicKey\"},{\"name\":\"tokenBadgeAuthority\",\"type\":\"publicKey\"}]}},{\"name\":\"FeeTier\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"whirlpoolsConfig\",\"type\":\"publicKey\"},{\"name\":\"tickSpacing\",\"type\":\"u16\"},{\"name\":\"defaultFeeRate\",\"type\":\"u16\"}]}},{\"name\":\"Position\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"whirlpool\",\"type\":\"publicKey\"},{\"name\":\"positionMint\",\"type\":\"publicKey\"},{\"name\":\"liquidity\",\"type\":\"u128\"},{\"name\":\"tickLowerIndex\",\"type\":\"i32\"},{\"name\":\"tickUpperIndex\",\"type\":\"i32\"},{\"name\":\"feeGrowthCheckpointA\",\"type\":\"u128\"},{\"name\":\"feeOwedA\",\"type\":\"u64\"},{\"name\":\"feeGrowthCheckpointB\",\"type\":\"u128\"},{\"name\":\"feeOwedB\",\"type\":\"u64\"},{\"name\":\"rewardInfos\",\"type\":{\"array\":[{\"defined\":\"PositionRewardInfo\"},3]}}]}},{\"name\":\"PositionBundle\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"positionBundleMint\",\"type\":\"publicKey\"},{\"name\":\"positionBitmap\",\"type\":{\"array\":[\"u8\",32]}}]}},{\"name\":\"TickArray\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"startTickIndex\",\"type\":\"i32\"},{\"name\":\"ticks\",\"type\":{\"array\":[{\"defined\":\"Tick\"},88]}},{\"name\":\"whirlpool\",\"type\":\"publicKey\"}]}},{\"name\":\"TokenBadge\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"whirlpoolsConfig\",\"type\":\"publicKey\"},{\"name\":\"tokenMint\",\"type\":\"publicKey\"}]}},{\"name\":\"Whirlpool\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"whirlpoolsConfig\",\"type\":\"publicKey\"},{\"name\":\"whirlpoolBump\",\"type\":{\"array\":[\"u8\",1]}},{\"name\":\"tickSpacing\",\"type\":\"u16\"},{\"name\":\"tickSpacingSeed\",\"type\":{\"array\":[\"u8\",2]}},{\"name\":\"feeRate\",\"type\":\"u16\"},{\"name\":\"protocolFeeRate\",\"type\":\"u16\"},{\"name\":\"liquidity\",\"type\":\"u128\"},{\"name\":\"sqrtPrice\",\"type\":\"u128\"},{\"name\":\"tickCurrentIndex\",\"type\":\"i32\"},{\"name\":\"protocolFeeOwedA\",\"type\":\"u64\"},{\"name\":\"protocolFeeOwedB\",\"type\":\"u64\"},{\"name\":\"tokenMintA\",\"type\":\"publicKey\"},{\"name\":\"tokenVaultA\",\"type\":\"publicKey\"},{\"name\":\"feeGrowthGlobalA\",\"type\":\"u128\"},{\"name\":\"tokenMintB\",\"type\":\"publicKey\"},{\"name\":\"tokenVaultB\",\"type\":\"publicKey\"},{\"name\":\"feeGrowthGlobalB\",\"type\":\"u128\"},{\"name\":\"rewardLastUpdatedTimestamp\",\"type\":\"u64\"},{\"name\":\"rewardInfos\",\"type\":{\"array\":[{\"defined\":\"WhirlpoolRewardInfo\"},3]}}]}}],\"types\":[{\"name\":\"OpenPositionBumps\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"positionBump\",\"type\":\"u8\"}]}},{\"name\":\"OpenPositionWithMetadataBumps\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"positionBump\",\"type\":\"u8\"},{\"name\":\"metadataBump\",\"type\":\"u8\"}]}},{\"name\":\"PositionRewardInfo\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"growthInsideCheckpoint\",\"type\":\"u128\"},{\"name\":\"amountOwed\",\"type\":\"u64\"}]}},{\"name\":\"Tick\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"initialized\",\"type\":\"bool\"},{\"name\":\"liquidityNet\",\"type\":\"i128\"},{\"name\":\"liquidityGross\",\"type\":\"u128\"},{\"name\":\"feeGrowthOutsideA\",\"type\":\"u128\"},{\"name\":\"feeGrowthOutsideB\",\"type\":\"u128\"},{\"name\":\"rewardGrowthsOutside\",\"type\":{\"array\":[\"u128\",3]}}]}},{\"name\":\"WhirlpoolBumps\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"whirlpoolBump\",\"type\":\"u8\"}]}},{\"name\":\"WhirlpoolRewardInfo\",\"docs\":[\"Stores the state relevant for tracking liquidity mining rewards at the `Whirlpool` level.\",\"These values are used in conjunction with `PositionRewardInfo`, `Tick.reward_growths_outside`,\",\"and `Whirlpool.reward_last_updated_timestamp` to determine how many rewards are earned by open\",\"positions.\"],\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"mint\",\"docs\":[\"Reward token mint.\"],\"type\":\"publicKey\"},{\"name\":\"vault\",\"docs\":[\"Reward vault token account.\"],\"type\":\"publicKey\"},{\"name\":\"authority\",\"docs\":[\"Authority account that has permission to initialize the reward and set emissions.\"],\"type\":\"publicKey\"},{\"name\":\"emissionsPerSecondX64\",\"docs\":[\"Q64.64 number that indicates how many tokens per second are earned per unit of liquidity.\"],\"type\":\"u128\"},{\"name\":\"growthGlobalX64\",\"docs\":[\"Q64.64 number that tracks the total tokens earned per unit of liquidity since the reward\",\"emissions were turned on.\"],\"type\":\"u128\"}]}},{\"name\":\"AccountsType\",\"type\":{\"kind\":\"enum\",\"variants\":[{\"name\":\"TransferHookA\"},{\"name\":\"TransferHookB\"},{\"name\":\"TransferHookReward\"},{\"name\":\"TransferHookInput\"},{\"name\":\"TransferHookIntermediate\"},{\"name\":\"TransferHookOutput\"},{\"name\":\"SupplementalTickArrays\"},{\"name\":\"SupplementalTickArraysOne\"},{\"name\":\"SupplementalTickArraysTwo\"}]}},{\"name\":\"RemainingAccountsInfo\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"slices\",\"type\":{\"vec\":{\"defined\":\"RemainingAccountsSlice\"}}}]}},{\"name\":\"RemainingAccountsSlice\",\"type\":{\"kind\":\"struct\",\"fields\":[{\"name\":\"accountsType\",\"type\":{\"defined\":\"AccountsType\"}},{\"name\":\"length\",\"type\":\"u8\"}]}}],\"errors\":[{\"code\":6000,\"name\":\"InvalidEnum\",\"msg\":\"Enum value could not be converted\"},{\"code\":6001,\"name\":\"InvalidStartTick\",\"msg\":\"Invalid start tick index provided.\"},{\"code\":6002,\"name\":\"TickArrayExistInPool\",\"msg\":\"Tick-array already exists in this whirlpool\"},{\"code\":6003,\"name\":\"TickArrayIndexOutofBounds\",\"msg\":\"Attempt to search for a tick-array failed\"},{\"code\":6004,\"name\":\"InvalidTickSpacing\",\"msg\":\"Tick-spacing is not supported\"},{\"code\":6005,\"name\":\"ClosePositionNotEmpty\",\"msg\":\"Position is not empty It cannot be closed\"},{\"code\":6006,\"name\":\"DivideByZero\",\"msg\":\"Unable to divide by zero\"},{\"code\":6007,\"name\":\"NumberCastError\",\"msg\":\"Unable to cast number into BigInt\"},{\"code\":6008,\"name\":\"NumberDownCastError\",\"msg\":\"Unable to down cast number\"},{\"code\":6009,\"name\":\"TickNotFound\",\"msg\":\"Tick not found within tick array\"},{\"code\":6010,\"name\":\"InvalidTickIndex\",\"msg\":\"Provided tick index is either out of bounds or uninitializable\"},{\"code\":6011,\"name\":\"SqrtPriceOutOfBounds\",\"msg\":\"Provided sqrt price out of bounds\"},{\"code\":6012,\"name\":\"LiquidityZero\",\"msg\":\"Liquidity amount must be greater than zero\"},{\"code\":6013,\"name\":\"LiquidityTooHigh\",\"msg\":\"Liquidity amount must be less than i64::MAX\"},{\"code\":6014,\"name\":\"LiquidityOverflow\",\"msg\":\"Liquidity overflow\"},{\"code\":6015,\"name\":\"LiquidityUnderflow\",\"msg\":\"Liquidity underflow\"},{\"code\":6016,\"name\":\"LiquidityNetError\",\"msg\":\"Tick liquidity net underflowed or overflowed\"},{\"code\":6017,\"name\":\"TokenMaxExceeded\",\"msg\":\"Exceeded token max\"},{\"code\":6018,\"name\":\"TokenMinSubceeded\",\"msg\":\"Did not meet token min\"},{\"code\":6019,\"name\":\"MissingOrInvalidDelegate\",\"msg\":\"Position token account has a missing or invalid delegate\"},{\"code\":6020,\"name\":\"InvalidPositionTokenAmount\",\"msg\":\"Position token amount must be 1\"},{\"code\":6021,\"name\":\"InvalidTimestampConversion\",\"msg\":\"Timestamp should be convertible from i64 to u64\"},{\"code\":6022,\"name\":\"InvalidTimestamp\",\"msg\":\"Timestamp should be greater than the last updated timestamp\"},{\"code\":6023,\"name\":\"InvalidTickArraySequence\",\"msg\":\"Invalid tick array sequence provided for instruction.\"},{\"code\":6024,\"name\":\"InvalidTokenMintOrder\",\"msg\":\"Token Mint in wrong order\"},{\"code\":6025,\"name\":\"RewardNotInitialized\",\"msg\":\"Reward not initialized\"},{\"code\":6026,\"name\":\"InvalidRewardIndex\",\"msg\":\"Invalid reward index\"},{\"code\":6027,\"name\":\"RewardVaultAmountInsufficient\",\"msg\":\"Reward vault requires amount to support emissions for at least one day\"},{\"code\":6028,\"name\":\"FeeRateMaxExceeded\",\"msg\":\"Exceeded max fee rate\"},{\"code\":6029,\"name\":\"ProtocolFeeRateMaxExceeded\",\"msg\":\"Exceeded max protocol fee rate\"},{\"code\":6030,\"name\":\"MultiplicationShiftRightOverflow\",\"msg\":\"Multiplication with shift right overflow\"},{\"code\":6031,\"name\":\"MulDivOverflow\",\"msg\":\"Muldiv overflow\"},{\"code\":6032,\"name\":\"MulDivInvalidInput\",\"msg\":\"Invalid div_u256 input\"},{\"code\":6033,\"name\":\"MultiplicationOverflow\",\"msg\":\"Multiplication overflow\"},{\"code\":6034,\"name\":\"InvalidSqrtPriceLimitDirection\",\"msg\":\"Provided SqrtPriceLimit not in the same direction as the swap.\"},{\"code\":6035,\"name\":\"ZeroTradableAmount\",\"msg\":\"There are no tradable amount to swap.\"},{\"code\":6036,\"name\":\"AmountOutBelowMinimum\",\"msg\":\"Amount out below minimum threshold\"},{\"code\":6037,\"name\":\"AmountInAboveMaximum\",\"msg\":\"Amount in above maximum threshold\"},{\"code\":6038,\"name\":\"TickArraySequenceInvalidIndex\",\"msg\":\"Invalid index for tick array sequence\"},{\"code\":6039,\"name\":\"AmountCalcOverflow\",\"msg\":\"Amount calculated overflows\"},{\"code\":6040,\"name\":\"AmountRemainingOverflow\",\"msg\":\"Amount remaining overflows\"},{\"code\":6041,\"name\":\"InvalidIntermediaryMint\",\"msg\":\"Invalid intermediary mint\"},{\"code\":6042,\"name\":\"DuplicateTwoHopPool\",\"msg\":\"Duplicate two hop pool\"},{\"code\":6043,\"name\":\"InvalidBundleIndex\",\"msg\":\"Bundle index is out of bounds\"},{\"code\":6044,\"name\":\"BundledPositionAlreadyOpened\",\"msg\":\"Position has already been opened\"},{\"code\":6045,\"name\":\"BundledPositionAlreadyClosed\",\"msg\":\"Position has already been closed\"},{\"code\":6046,\"name\":\"PositionBundleNotDeletable\",\"msg\":\"Unable to delete PositionBundle with open positions\"},{\"code\":6047,\"name\":\"UnsupportedTokenMint\",\"msg\":\"Token mint has unsupported attributes\"},{\"code\":6048,\"name\":\"RemainingAccountsInvalidSlice\",\"msg\":\"Invalid remaining accounts\"},{\"code\":6049,\"name\":\"RemainingAccountsInsufficient\",\"msg\":\"Insufficient remaining accounts\"},{\"code\":6050,\"name\":\"NoExtraAccountsForTransferHook\",\"msg\":\"Unable to call transfer hook without extra accounts\"},{\"code\":6051,\"name\":\"IntermediateTokenAmountMismatch\",\"msg\":\"Output and input amount mismatch\"},{\"code\":6052,\"name\":\"TransferFeeCalculationError\",\"msg\":\"Transfer fee calculation failed\"},{\"code\":6053,\"name\":\"RemainingAccountsDuplicatedAccountsType\",\"msg\":\"Same accounts type is provided more than once\"},{\"code\":6054,\"name\":\"FullRangeOnlyPool\",\"msg\":\"This whirlpool only supports full-range positions\"},{\"code\":6055,\"name\":\"TooManySupplementalTickArrays\",\"msg\":\"Too many supplemental tick arrays provided\"},{\"code\":6056,\"name\":\"DifferentWhirlpoolTickArrayAccount\",\"msg\":\"TickArray account for different whirlpool provided\"},{\"code\":6057,\"name\":\"PartialFillError\",\"msg\":\"Trade resulted in partial fill\"}]}"));}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/anchor-types.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WHIRLPOOL_ACCOUNT_SIZE = exports.WHIRLPOOL_CODER = exports.WHIRLPOOL_IDL = exports.AccountName = void 0;
exports.getAccountSize = getAccountSize;
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const whirlpool_json_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/artifacts/whirlpool.json (json)"));
var AccountName;
(function(AccountName) {
    AccountName["WhirlpoolsConfig"] = "WhirlpoolsConfig";
    AccountName["Position"] = "Position";
    AccountName["TickArray"] = "TickArray";
    AccountName["Whirlpool"] = "Whirlpool";
    AccountName["FeeTier"] = "FeeTier";
    AccountName["PositionBundle"] = "PositionBundle";
    AccountName["WhirlpoolsConfigExtension"] = "WhirlpoolsConfigExtension";
    AccountName["TokenBadge"] = "TokenBadge";
})(AccountName || (exports.AccountName = AccountName = {}));
exports.WHIRLPOOL_IDL = whirlpool_json_1.default;
exports.WHIRLPOOL_CODER = new anchor_1.BorshAccountsCoder(exports.WHIRLPOOL_IDL);
function getAccountSize(accountName) {
    const size = exports.WHIRLPOOL_CODER.size(exports.WHIRLPOOL_IDL.accounts.find((account)=>account.name === accountName));
    return size + RESERVED_BYTES[accountName];
}
const RESERVED_BYTES = {
    [AccountName.WhirlpoolsConfig]: 2,
    [AccountName.Position]: 0,
    [AccountName.TickArray]: 0,
    [AccountName.Whirlpool]: 0,
    [AccountName.FeeTier]: 0,
    [AccountName.PositionBundle]: 64,
    [AccountName.WhirlpoolsConfigExtension]: 512,
    [AccountName.TokenBadge]: 128
};
exports.WHIRLPOOL_ACCOUNT_SIZE = getAccountSize(AccountName.Whirlpool); //# sourceMappingURL=anchor-types.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/constants.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SPLASH_POOL_TICK_SPACING = exports.FULL_RANGE_ONLY_TICK_SPACING_THRESHOLD = exports.WHIRLPOOL_NFT_UPDATE_AUTH = exports.FEE_RATE_MUL_VALUE = exports.PROTOCOL_FEE_RATE_MUL_VALUE = exports.MAX_SUPPLEMENTAL_TICK_ARRAYS = exports.MAX_SWAP_TICK_ARRAYS = exports.MEMO_PROGRAM_ADDRESS = exports.METADATA_PROGRAM_ADDRESS = exports.POSITION_BUNDLE_SIZE = exports.TICK_ARRAY_SIZE = exports.MAX_SQRT_PRICE_BN = exports.MIN_SQRT_PRICE_BN = exports.MIN_SQRT_PRICE = exports.MAX_SQRT_PRICE = exports.MIN_TICK_INDEX = exports.MAX_TICK_INDEX = exports.NUM_REWARDS = exports.ORCA_SUPPORTED_TICK_SPACINGS = exports.ORCA_WHIRLPOOLS_CONFIG_EXTENSION = exports.ORCA_WHIRLPOOLS_CONFIG_ECLIPSE = exports.ORCA_WHIRLPOOLS_CONFIG = exports.ORCA_WHIRLPOOL_PROGRAM_ID = void 0;
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
exports.ORCA_WHIRLPOOL_PROGRAM_ID = new web3_js_1.PublicKey("whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc");
exports.ORCA_WHIRLPOOLS_CONFIG = new web3_js_1.PublicKey("2LecshUwdy9xi7meFgHtFJQNSKk4KdTrcpvaB56dP2NQ");
exports.ORCA_WHIRLPOOLS_CONFIG_ECLIPSE = new web3_js_1.PublicKey("FVG4oDbGv16hqTUbovjyGmtYikn6UBEnazz6RVDMEFwv");
exports.ORCA_WHIRLPOOLS_CONFIG_EXTENSION = new web3_js_1.PublicKey("777H5H3Tp9U11uRVRzFwM8BinfiakbaLT8vQpeuhvEiH");
exports.ORCA_SUPPORTED_TICK_SPACINGS = [
    1,
    2,
    4,
    8,
    16,
    64,
    96,
    128,
    256,
    32896
];
exports.NUM_REWARDS = 3;
exports.MAX_TICK_INDEX = 443636;
exports.MIN_TICK_INDEX = -443636;
exports.MAX_SQRT_PRICE = "79226673515401279992447579055";
exports.MIN_SQRT_PRICE = "4295048016";
exports.MIN_SQRT_PRICE_BN = new anchor_1.BN(exports.MIN_SQRT_PRICE);
exports.MAX_SQRT_PRICE_BN = new anchor_1.BN(exports.MAX_SQRT_PRICE);
exports.TICK_ARRAY_SIZE = 88;
exports.POSITION_BUNDLE_SIZE = 256;
exports.METADATA_PROGRAM_ADDRESS = new web3_js_1.PublicKey("metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s");
exports.MEMO_PROGRAM_ADDRESS = new web3_js_1.PublicKey("MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr");
exports.MAX_SWAP_TICK_ARRAYS = 3;
exports.MAX_SUPPLEMENTAL_TICK_ARRAYS = 3;
exports.PROTOCOL_FEE_RATE_MUL_VALUE = new anchor_1.BN(10_000);
exports.FEE_RATE_MUL_VALUE = new anchor_1.BN(1_000_000);
exports.WHIRLPOOL_NFT_UPDATE_AUTH = new web3_js_1.PublicKey("3axbTs2z5GBy6usVbNVoqEgZMng3vZvMnAoX29BFfwhr");
exports.FULL_RANGE_ONLY_TICK_SPACING_THRESHOLD = 32768;
exports.SPLASH_POOL_TICK_SPACING = 32896; //# sourceMappingURL=constants.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/anchor-types.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/constants.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/parsing.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ParsableTokenBadge = exports.ParsableWhirlpoolsConfigExtension = exports.ParsablePositionBundle = exports.ParsableFeeTier = exports.ParsableTickArray = exports.ParsablePosition = exports.ParsableWhirlpool = exports.ParsableWhirlpoolsConfig = void 0;
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const WhirlpoolIDL = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/artifacts/whirlpool.json (json)"));
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
let ParsableWhirlpoolsConfig = class ParsableWhirlpoolsConfig {
    static parse(address, accountData) {
        if (!accountData?.data) {
            return null;
        }
        try {
            return parseAnchorAccount(public_1.AccountName.WhirlpoolsConfig, accountData);
        } catch (e) {
            console.error(`error while parsing WhirlpoolsConfig: ${e}`);
            return null;
        }
    }
};
exports.ParsableWhirlpoolsConfig = ParsableWhirlpoolsConfig;
exports.ParsableWhirlpoolsConfig = ParsableWhirlpoolsConfig = __decorate([
    (0, common_sdk_1.staticImplements)()
], ParsableWhirlpoolsConfig);
let ParsableWhirlpool = class ParsableWhirlpool {
    static parse(address, accountData) {
        if (!accountData?.data) {
            return null;
        }
        try {
            return parseAnchorAccount(public_1.AccountName.Whirlpool, accountData);
        } catch (e) {
            console.error(`error while parsing Whirlpool: ${e}`);
            return null;
        }
    }
};
exports.ParsableWhirlpool = ParsableWhirlpool;
exports.ParsableWhirlpool = ParsableWhirlpool = __decorate([
    (0, common_sdk_1.staticImplements)()
], ParsableWhirlpool);
let ParsablePosition = class ParsablePosition {
    static parse(address, accountData) {
        if (!accountData?.data) {
            return null;
        }
        try {
            return parseAnchorAccount(public_1.AccountName.Position, accountData);
        } catch (e) {
            console.error(`error while parsing Position: ${e}`);
            return null;
        }
    }
};
exports.ParsablePosition = ParsablePosition;
exports.ParsablePosition = ParsablePosition = __decorate([
    (0, common_sdk_1.staticImplements)()
], ParsablePosition);
let ParsableTickArray = class ParsableTickArray {
    static parse(address, accountData) {
        if (!accountData?.data) {
            return null;
        }
        try {
            return parseAnchorAccount(public_1.AccountName.TickArray, accountData);
        } catch (e) {
            console.error(`error while parsing TickArray: ${e}`);
            return null;
        }
    }
};
exports.ParsableTickArray = ParsableTickArray;
exports.ParsableTickArray = ParsableTickArray = __decorate([
    (0, common_sdk_1.staticImplements)()
], ParsableTickArray);
let ParsableFeeTier = class ParsableFeeTier {
    static parse(address, accountData) {
        if (!accountData?.data) {
            return null;
        }
        try {
            return parseAnchorAccount(public_1.AccountName.FeeTier, accountData);
        } catch (e) {
            console.error(`error while parsing FeeTier: ${e}`);
            return null;
        }
    }
};
exports.ParsableFeeTier = ParsableFeeTier;
exports.ParsableFeeTier = ParsableFeeTier = __decorate([
    (0, common_sdk_1.staticImplements)()
], ParsableFeeTier);
let ParsablePositionBundle = class ParsablePositionBundle {
    static parse(address, accountData) {
        if (!accountData?.data) {
            return null;
        }
        try {
            return parseAnchorAccount(public_1.AccountName.PositionBundle, accountData);
        } catch (e) {
            console.error(`error while parsing PositionBundle: ${e}`);
            return null;
        }
    }
};
exports.ParsablePositionBundle = ParsablePositionBundle;
exports.ParsablePositionBundle = ParsablePositionBundle = __decorate([
    (0, common_sdk_1.staticImplements)()
], ParsablePositionBundle);
let ParsableWhirlpoolsConfigExtension = class ParsableWhirlpoolsConfigExtension {
    static parse(address, accountData) {
        if (!accountData?.data) {
            return null;
        }
        try {
            return parseAnchorAccount(public_1.AccountName.WhirlpoolsConfigExtension, accountData);
        } catch (e) {
            console.error(`error while parsing WhirlpoolsConfigExtension: ${e}`);
            return null;
        }
    }
};
exports.ParsableWhirlpoolsConfigExtension = ParsableWhirlpoolsConfigExtension;
exports.ParsableWhirlpoolsConfigExtension = ParsableWhirlpoolsConfigExtension = __decorate([
    (0, common_sdk_1.staticImplements)()
], ParsableWhirlpoolsConfigExtension);
let ParsableTokenBadge = class ParsableTokenBadge {
    static parse(address, accountData) {
        if (!accountData?.data) {
            return null;
        }
        try {
            return parseAnchorAccount(public_1.AccountName.TokenBadge, accountData);
        } catch (e) {
            console.error(`error while parsing TokenBadge: ${e}`);
            return null;
        }
    }
};
exports.ParsableTokenBadge = ParsableTokenBadge;
exports.ParsableTokenBadge = ParsableTokenBadge = __decorate([
    (0, common_sdk_1.staticImplements)()
], ParsableTokenBadge);
const WhirlpoolCoder = new anchor_1.BorshAccountsCoder(WhirlpoolIDL);
function parseAnchorAccount(accountName, accountData) {
    const data = accountData.data;
    const discriminator = anchor_1.BorshAccountsCoder.accountDiscriminator(accountName);
    if (discriminator.compare(data.slice(0, 8))) {
        console.error("incorrect account name during parsing");
        return null;
    }
    try {
        return WhirlpoolCoder.decode(accountName, data);
    } catch (_e) {
        console.error("unknown account name during parsing");
        return null;
    }
} //# sourceMappingURL=parsing.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/fetcher-impl.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WhirlpoolAccountFetcher = exports.buildDefaultAccountFetcher = void 0;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/index.js [app-route] (ecmascript)");
const parsing_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/parsing.js [app-route] (ecmascript)");
const buildDefaultAccountFetcher = (connection)=>{
    return new WhirlpoolAccountFetcher(connection, new common_sdk_1.SimpleAccountFetcher(connection, __1.DEFAULT_WHIRLPOOL_RETENTION_POLICY));
};
exports.buildDefaultAccountFetcher = buildDefaultAccountFetcher;
class WhirlpoolAccountFetcher {
    connection;
    fetcher;
    _accountRentExempt;
    _epochInfo;
    _epochInfoNextFetchTime = 0;
    constructor(connection, fetcher){
        this.connection = connection;
        this.fetcher = fetcher;
    }
    async getAccountRentExempt(refresh = false) {
        if (!this._accountRentExempt || refresh) {
            this._accountRentExempt = await this.connection.getMinimumBalanceForRentExemption(spl_token_1.AccountLayout.span);
        }
        return this._accountRentExempt;
    }
    async getEpoch(refresh = false) {
        if (!this._epochInfo || Date.now() >= this._epochInfoNextFetchTime || refresh) {
            const epochInfo = await this.connection.getEpochInfo();
            const remainingSlotsInEpoch = Math.max(epochInfo.slotsInEpoch - epochInfo.slotIndex, 0);
            const nextFetchTime = Date.now() + remainingSlotsInEpoch * 320;
            this._epochInfo = epochInfo;
            this._epochInfoNextFetchTime = nextFetchTime;
        }
        return this._epochInfo.epoch;
    }
    getPool(address, opts) {
        return this.fetcher.getAccount(address, parsing_1.ParsableWhirlpool, opts);
    }
    getPools(addresses, opts) {
        return this.fetcher.getAccounts(addresses, parsing_1.ParsableWhirlpool, opts);
    }
    getPosition(address, opts) {
        return this.fetcher.getAccount(address, parsing_1.ParsablePosition, opts);
    }
    getPositions(addresses, opts) {
        return this.fetcher.getAccounts(addresses, parsing_1.ParsablePosition, opts);
    }
    getTickArray(address, opts) {
        return this.fetcher.getAccount(address, parsing_1.ParsableTickArray, opts);
    }
    getTickArrays(addresses, opts) {
        return this.fetcher.getAccountsAsArray(addresses, parsing_1.ParsableTickArray, opts);
    }
    getFeeTier(address, opts) {
        return this.fetcher.getAccount(address, parsing_1.ParsableFeeTier, opts);
    }
    getFeeTiers(addresses, opts) {
        return this.fetcher.getAccounts(addresses, parsing_1.ParsableFeeTier, opts);
    }
    getTokenInfo(address, opts) {
        return this.fetcher.getAccount(address, common_sdk_1.ParsableTokenAccountInfo, opts);
    }
    getTokenInfos(addresses, opts) {
        return this.fetcher.getAccounts(addresses, common_sdk_1.ParsableTokenAccountInfo, opts);
    }
    getMintInfo(address, opts) {
        return this.fetcher.getAccount(address, common_sdk_1.ParsableMintInfo, opts);
    }
    getMintInfos(addresses, opts) {
        return this.fetcher.getAccounts(addresses, common_sdk_1.ParsableMintInfo, opts);
    }
    getConfig(address, opts) {
        return this.fetcher.getAccount(address, parsing_1.ParsableWhirlpoolsConfig, opts);
    }
    getConfigs(addresses, opts) {
        return this.fetcher.getAccounts(addresses, parsing_1.ParsableWhirlpoolsConfig, opts);
    }
    getPositionBundle(address, opts) {
        return this.fetcher.getAccount(address, parsing_1.ParsablePositionBundle, opts);
    }
    getPositionBundles(addresses, opts) {
        return this.fetcher.getAccounts(addresses, parsing_1.ParsablePositionBundle, opts);
    }
    getConfigExtension(address, opts) {
        return this.fetcher.getAccount(address, parsing_1.ParsableWhirlpoolsConfigExtension, opts);
    }
    getConfigExtensions(addresses, opts) {
        return this.fetcher.getAccounts(addresses, parsing_1.ParsableWhirlpoolsConfigExtension, opts);
    }
    getTokenBadge(address, opts) {
        return this.fetcher.getAccount(address, parsing_1.ParsableTokenBadge, opts);
    }
    getTokenBadges(addresses, opts) {
        return this.fetcher.getAccounts(addresses, parsing_1.ParsableTokenBadge, opts);
    }
    populateCache(accounts, parser, now = Date.now()) {
        this.fetcher.populateAccounts(accounts, parser, now);
    }
}
exports.WhirlpoolAccountFetcher = WhirlpoolAccountFetcher; //# sourceMappingURL=fetcher-impl.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/fetcher-types.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PREFER_CACHE = exports.IGNORE_CACHE = exports.DEFAULT_WHIRLPOOL_RETENTION_POLICY = void 0;
exports.DEFAULT_WHIRLPOOL_RETENTION_POLICY = new Map([]);
exports.IGNORE_CACHE = {
    maxAge: 0
};
exports.PREFER_CACHE = {
    maxAge: Number.POSITIVE_INFINITY
}; //# sourceMappingURL=fetcher-types.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/graphs/public/pool-graph-utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PoolGraphUtils = void 0;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
class PoolGraphUtils {
    static PATH_ID_DELIMITER = "-";
    static getSearchPathId(tokenA, tokenB) {
        return `${common_sdk_1.AddressUtil.toString(tokenA)}${PoolGraphUtils.PATH_ID_DELIMITER}${common_sdk_1.AddressUtil.toString(tokenB)}`;
    }
    static deconstructPathId(pathId) {
        const split = pathId.split(PoolGraphUtils.PATH_ID_DELIMITER);
        if (split.length !== 2) {
            throw new Error(`Invalid path id: ${pathId}`);
        }
        const [tokenA, tokenB] = split;
        return [
            tokenA,
            tokenB
        ];
    }
}
exports.PoolGraphUtils = PoolGraphUtils; //# sourceMappingURL=pool-graph-utils.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/graphs/adjacency-list-pool-graph.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.AdjacencyListPoolGraph = void 0;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const pool_graph_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/graphs/public/pool-graph-utils.js [app-route] (ecmascript)");
class AdjacencyListPoolGraph {
    graph;
    tokens;
    constructor(pools){
        const [adjacencyListGraphMap, insertedTokens] = buildPoolGraph(pools);
        this.graph = adjacencyListGraphMap;
        this.tokens = Array.from(insertedTokens);
    }
    getPath(startMint, endMint, options) {
        const results = this.getPathsForPairs([
            [
                startMint,
                endMint
            ]
        ], options);
        return results[0][1];
    }
    getPathsForPairs(searchTokenPairs, options) {
        const searchTokenPairsInString = searchTokenPairs.map(([startMint, endMint])=>{
            return [
                common_sdk_1.AddressUtil.toString(startMint),
                common_sdk_1.AddressUtil.toString(endMint)
            ];
        });
        const searchTokenPairsToFind = searchTokenPairsInString.filter(([startMint, endMint])=>{
            return startMint !== endMint;
        });
        const walkMap = findWalks(searchTokenPairsToFind, this.graph, options?.intermediateTokens.map((token)=>common_sdk_1.AddressUtil.toString(token)));
        const results = searchTokenPairsInString.map(([startMint, endMint])=>{
            const searchRouteId = pool_graph_utils_1.PoolGraphUtils.getSearchPathId(startMint, endMint);
            const [internalStartMint, internalEndMint] = [
                startMint,
                endMint
            ].sort();
            const internalRouteId = getInternalRouteId(internalStartMint, internalEndMint, false);
            const reversed = internalStartMint !== startMint;
            const pathsForSearchPair = walkMap[internalRouteId];
            const paths = pathsForSearchPair ? pathsForSearchPair.map((path)=>{
                return {
                    startTokenMint: startMint,
                    endTokenMint: endMint,
                    edges: getHopsFromRoute(path, reversed)
                };
            }) : [];
            return [
                searchRouteId,
                paths
            ];
        });
        return results;
    }
    getAllPaths(options) {
        const tokenPairCombinations = combinations2(this.tokens);
        const searchTokenPairsInString = tokenPairCombinations.map(([startMint, endMint])=>{
            return [
                startMint,
                endMint
            ];
        });
        const searchTokenPairsToFind = searchTokenPairsInString.filter(([startMint, endMint])=>{
            return startMint !== endMint;
        });
        const walkMap = findWalks(searchTokenPairsToFind, this.graph, options?.intermediateTokens.map((token)=>common_sdk_1.AddressUtil.toString(token)));
        const results = searchTokenPairsInString.reduce((acc, [startMint, endMint])=>{
            const searchRouteId = pool_graph_utils_1.PoolGraphUtils.getSearchPathId(startMint, endMint);
            if (startMint === endMint) {
                acc.push([
                    searchRouteId,
                    []
                ]);
                return acc;
            }
            const [internalStartMint, internalEndMint] = [
                startMint,
                endMint
            ].sort();
            const internalRouteId = getInternalRouteId(internalStartMint, internalEndMint, false);
            const reversed = internalStartMint !== startMint;
            const pathsForSearchPair = walkMap[internalRouteId];
            const paths = pathsForSearchPair ? pathsForSearchPair.map((path)=>{
                return {
                    startTokenMint: startMint,
                    endTokenMint: endMint,
                    edges: getHopsFromRoute(path, reversed)
                };
            }) : [];
            acc.push([
                searchRouteId,
                paths
            ]);
            const reversedSearchRouteId = pool_graph_utils_1.PoolGraphUtils.getSearchPathId(endMint, startMint);
            const reversedPaths = pathsForSearchPair ? pathsForSearchPair.map((path)=>{
                return {
                    startTokenMint: endMint,
                    endTokenMint: startMint,
                    edges: getHopsFromRoute(path, !reversed)
                };
            }) : [];
            acc.push([
                reversedSearchRouteId,
                reversedPaths
            ]);
            return acc;
        }, []);
        return results;
    }
}
exports.AdjacencyListPoolGraph = AdjacencyListPoolGraph;
function getHopsFromRoute(path, reversed) {
    const finalRoutes = reversed ? path.slice().reverse() : path;
    return finalRoutes.map((hopStr)=>{
        return {
            poolAddress: hopStr
        };
    });
}
function buildPoolGraph(pools) {
    const insertedPoolCache = {};
    const insertedTokens = new Set();
    const poolGraphSet = pools.reduce((poolGraph, pool)=>{
        const { address, tokenMintA, tokenMintB } = pool;
        const [addr, mintA, mintB] = common_sdk_1.AddressUtil.toStrings([
            address,
            tokenMintA,
            tokenMintB
        ]);
        insertedTokens.add(mintA);
        insertedTokens.add(mintB);
        if (poolGraph[mintA] === undefined) {
            poolGraph[mintA] = [];
            insertedPoolCache[mintA] = new Set();
        }
        if (poolGraph[mintB] === undefined) {
            poolGraph[mintB] = [];
            insertedPoolCache[mintB] = new Set();
        }
        const [insertedPoolsForA, insertedPoolsForB] = [
            insertedPoolCache[mintA],
            insertedPoolCache[mintB]
        ];
        if (!insertedPoolsForA.has(addr)) {
            poolGraph[mintA].push({
                address: addr,
                otherToken: mintB
            });
            insertedPoolsForA.add(addr);
        }
        if (!insertedPoolsForB.has(addr)) {
            poolGraph[mintB].push({
                address: addr,
                otherToken: mintA
            });
            insertedPoolsForB.add(addr);
        }
        return poolGraph;
    }, {});
    return [
        poolGraphSet,
        insertedTokens
    ];
}
function findWalks(tokenPairs, poolGraph, intermediateTokens) {
    const walks = {};
    tokenPairs.forEach(([tokenMintFrom, tokenMintTo])=>{
        let paths = [];
        const [internalTokenMintFrom, internalTokenMintTo] = [
            tokenMintFrom,
            tokenMintTo
        ].sort();
        const internalPathId = getInternalRouteId(internalTokenMintFrom, internalTokenMintTo, false);
        const poolsForTokenFrom = poolGraph[internalTokenMintFrom] || [];
        const poolsForTokenTo = poolGraph[internalTokenMintTo] || [];
        if (!!walks[internalPathId]) {
            return;
        }
        const singleHop = poolsForTokenFrom.filter(({ address })=>poolsForTokenTo.some((p)=>p.address === address)).map((op)=>[
                op.address
            ]);
        paths.push(...singleHop);
        const firstHop = poolsForTokenFrom.filter(({ address })=>!poolsForTokenTo.some((p)=>p.address === address));
        firstHop.forEach((firstPool)=>{
            const intermediateToken = firstPool.otherToken;
            if (!intermediateTokens || intermediateTokens.indexOf(intermediateToken) > -1) {
                const secondHops = poolsForTokenTo.filter((secondPool)=>secondPool.otherToken === intermediateToken).map((secondPool)=>[
                        firstPool.address,
                        secondPool.address
                    ]);
                paths.push(...secondHops);
            }
        });
        if (paths.length > 0) {
            walks[internalPathId] = paths;
        }
    });
    return walks;
}
function getInternalRouteId(tokenA, tokenB, sort = true) {
    const mints = [
        common_sdk_1.AddressUtil.toString(tokenA),
        common_sdk_1.AddressUtil.toString(tokenB)
    ];
    const sortedMints = sort ? mints.sort() : mints;
    return `${sortedMints[0]}${pool_graph_utils_1.PoolGraphUtils.PATH_ID_DELIMITER}${sortedMints[1]}`;
}
function combinations2(array) {
    const result = [];
    for(let i = 0; i < array.length - 1; i++){
        for(let j = i + 1; j < array.length; j++){
            result.push([
                array[i],
                array[j]
            ]);
        }
    }
    return result;
} //# sourceMappingURL=adjacency-list-pool-graph.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/graphs/public/pool-graph-builder.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PoolGraphBuilder = void 0;
const fetcher_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)");
const adjacency_list_pool_graph_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/graphs/adjacency-list-pool-graph.js [app-route] (ecmascript)");
class PoolGraphBuilder {
    static async buildPoolGraphWithFetch(pools, fetcher) {
        const poolAccounts = await fetcher.getPools(pools, fetcher_1.PREFER_CACHE);
        const poolTokenPairs = Array.from(poolAccounts.entries()).map(([addr, pool])=>{
            if (pool) {
                return {
                    address: addr,
                    tokenMintA: pool.tokenMintA,
                    tokenMintB: pool.tokenMintB
                };
            }
            return null;
        }).flatMap((pool)=>pool ? pool : []);
        return new adjacency_list_pool_graph_1.AdjacencyListPoolGraph(poolTokenPairs);
    }
    static buildPoolGraph(poolTokenPairs) {
        return new adjacency_list_pool_graph_1.AdjacencyListPoolGraph(poolTokenPairs);
    }
}
exports.PoolGraphBuilder = PoolGraphBuilder; //# sourceMappingURL=pool-graph-builder.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/graphs/public/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/graphs/public/pool-graph-builder.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/graphs/public/pool-graph-utils.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/ix-utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.toTx = toTx;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
function toTx(ctx, ix) {
    return new common_sdk_1.TransactionBuilder(ctx.provider.connection, ctx.provider.wallet, ctx.txBuilderOpts).addInstruction(ix);
} //# sourceMappingURL=ix-utils.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/tick-utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TickArrayUtil = exports.TickUtil = void 0;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const pda_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/pda-utils.js [app-route] (ecmascript)");
var TickSearchDirection;
(function(TickSearchDirection) {
    TickSearchDirection[TickSearchDirection["Left"] = 0] = "Left";
    TickSearchDirection[TickSearchDirection["Right"] = 1] = "Right";
})(TickSearchDirection || (TickSearchDirection = {}));
class TickUtil {
    static getOffsetIndex(tickIndex, arrayStartIndex, tickSpacing) {
        return Math.floor((tickIndex - arrayStartIndex) / tickSpacing);
    }
    static getStartTickIndex(tickIndex, tickSpacing, offset = 0) {
        const realIndex = Math.floor(tickIndex / tickSpacing / public_1.TICK_ARRAY_SIZE);
        const startTickIndex = (realIndex + offset) * tickSpacing * public_1.TICK_ARRAY_SIZE;
        const ticksInArray = public_1.TICK_ARRAY_SIZE * tickSpacing;
        const minTickIndex = public_1.MIN_TICK_INDEX - (public_1.MIN_TICK_INDEX % ticksInArray + ticksInArray);
        (0, tiny_invariant_1.default)(startTickIndex >= minTickIndex, `startTickIndex is too small - - ${startTickIndex}`);
        (0, tiny_invariant_1.default)(startTickIndex <= public_1.MAX_TICK_INDEX, `startTickIndex is too large - ${startTickIndex}`);
        return startTickIndex;
    }
    static getInitializableTickIndex(tickIndex, tickSpacing) {
        return tickIndex - tickIndex % tickSpacing;
    }
    static getNextInitializableTickIndex(tickIndex, tickSpacing) {
        return TickUtil.getInitializableTickIndex(tickIndex, tickSpacing) + tickSpacing;
    }
    static getPrevInitializableTickIndex(tickIndex, tickSpacing) {
        return TickUtil.getInitializableTickIndex(tickIndex, tickSpacing) - tickSpacing;
    }
    static findPreviousInitializedTickIndex(account, currentTickIndex, tickSpacing) {
        return TickUtil.findInitializedTick(account, currentTickIndex, tickSpacing, TickSearchDirection.Left);
    }
    static findNextInitializedTickIndex(account, currentTickIndex, tickSpacing) {
        return TickUtil.findInitializedTick(account, currentTickIndex, tickSpacing, TickSearchDirection.Right);
    }
    static findInitializedTick(account, currentTickIndex, tickSpacing, searchDirection) {
        const currentTickArrayIndex = tickIndexToInnerIndex(account.startTickIndex, currentTickIndex, tickSpacing);
        const increment = searchDirection === TickSearchDirection.Right ? 1 : -1;
        let stepInitializedTickArrayIndex = searchDirection === TickSearchDirection.Right ? currentTickArrayIndex + increment : currentTickArrayIndex;
        while(stepInitializedTickArrayIndex >= 0 && stepInitializedTickArrayIndex < account.ticks.length){
            if (account.ticks[stepInitializedTickArrayIndex]?.initialized) {
                return innerIndexToTickIndex(account.startTickIndex, stepInitializedTickArrayIndex, tickSpacing);
            }
            stepInitializedTickArrayIndex += increment;
        }
        return null;
    }
    static checkTickInBounds(tick) {
        return tick <= public_1.MAX_TICK_INDEX && tick >= public_1.MIN_TICK_INDEX;
    }
    static isTickInitializable(tick, tickSpacing) {
        return tick % tickSpacing === 0;
    }
    static invertTick(tick) {
        return -tick;
    }
    static getFullRangeTickIndex(tickSpacing) {
        return [
            Math.ceil(public_1.MIN_TICK_INDEX / tickSpacing) * tickSpacing,
            Math.floor(public_1.MAX_TICK_INDEX / tickSpacing) * tickSpacing
        ];
    }
    static isFullRange(tickSpacing, tickLowerIndex, tickUpperIndex) {
        const [min, max] = TickUtil.getFullRangeTickIndex(tickSpacing);
        return tickLowerIndex === min && tickUpperIndex === max;
    }
    static isFullRangeOnly(tickSpacing) {
        return tickSpacing >= public_1.FULL_RANGE_ONLY_TICK_SPACING_THRESHOLD;
    }
}
exports.TickUtil = TickUtil;
class TickArrayUtil {
    static getTickFromArray(tickArray, tickIndex, tickSpacing) {
        const realIndex = tickIndexToInnerIndex(tickArray.startTickIndex, tickIndex, tickSpacing);
        const tick = tickArray.ticks[realIndex];
        (0, tiny_invariant_1.default)(!!tick, `tick realIndex out of range - start - ${tickArray.startTickIndex} index - ${tickIndex}, realIndex - ${realIndex}`);
        return tick;
    }
    static getTickArrayPDAs(tick, tickSpacing, numOfTickArrays, programId, whirlpoolAddress, aToB) {
        let arrayIndexList = [
            ...Array(numOfTickArrays).keys()
        ];
        if (aToB) {
            arrayIndexList = arrayIndexList.map((value)=>-value);
        }
        return arrayIndexList.map((value)=>{
            const startTick = TickUtil.getStartTickIndex(tick, tickSpacing, value);
            return pda_utils_1.PDAUtil.getTickArray(programId, whirlpoolAddress, startTick);
        });
    }
    static async getUninitializedArraysString(tickArrayAddrs, fetcher, opts) {
        const taAddrs = common_sdk_1.AddressUtil.toPubKeys(tickArrayAddrs);
        const tickArrayData = await fetcher.getTickArrays(taAddrs, opts);
        if (tickArrayData) {
            const uninitializedIndices = TickArrayUtil.getUninitializedArrays(tickArrayData);
            if (uninitializedIndices.length > 0) {
                const uninitializedArrays = uninitializedIndices.map((index)=>taAddrs[index].toBase58()).join(", ");
                return uninitializedArrays;
            }
        }
        return null;
    }
    static async getUninitializedArraysPDAs(ticks, programId, whirlpoolAddress, tickSpacing, fetcher, opts) {
        const startTicks = ticks.map((tick)=>TickUtil.getStartTickIndex(tick, tickSpacing));
        const removeDupeTicks = [
            ...new Set(startTicks)
        ];
        const tickArrayPDAs = removeDupeTicks.map((tick)=>pda_utils_1.PDAUtil.getTickArray(programId, whirlpoolAddress, tick));
        const fetchedArrays = await fetcher.getTickArrays(tickArrayPDAs.map((pda)=>pda.publicKey), opts);
        const uninitializedIndices = TickArrayUtil.getUninitializedArrays(fetchedArrays);
        return uninitializedIndices.map((index)=>{
            return {
                startIndex: removeDupeTicks[index],
                pda: tickArrayPDAs[index]
            };
        });
    }
    static getUninitializedArrays(tickArrays) {
        return tickArrays.map((value, index)=>{
            if (!value) {
                return index;
            }
            return -1;
        }).filter((index)=>index >= 0);
    }
}
exports.TickArrayUtil = TickArrayUtil;
function tickIndexToInnerIndex(startTickIndex, tickIndex, tickSpacing) {
    return Math.floor((tickIndex - startTickIndex) / tickSpacing);
}
function innerIndexToTickIndex(startTickIndex, tickArrayIndex, tickSpacing) {
    return startTickIndex + tickArrayIndex * tickSpacing;
} //# sourceMappingURL=tick-utils.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/price-math.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PriceMath = void 0;
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const decimal_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)"));
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const tick_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/tick-utils.js [app-route] (ecmascript)");
const BIT_PRECISION = 14;
const LOG_B_2_X32 = "59543866431248";
const LOG_B_P_ERR_MARGIN_LOWER_X64 = "184467440737095516";
const LOG_B_P_ERR_MARGIN_UPPER_X64 = "15793534762490258745";
class PriceMath {
    static priceToSqrtPriceX64(price, decimalsA, decimalsB) {
        return common_sdk_1.MathUtil.toX64(price.mul(decimal_js_1.default.pow(10, decimalsB - decimalsA)).sqrt());
    }
    static sqrtPriceX64ToPrice(sqrtPriceX64, decimalsA, decimalsB) {
        return common_sdk_1.MathUtil.fromX64(sqrtPriceX64).pow(2).mul(decimal_js_1.default.pow(10, decimalsA - decimalsB));
    }
    static tickIndexToSqrtPriceX64(tickIndex) {
        if (tickIndex > 0) {
            return new anchor_1.BN(tickIndexToSqrtPricePositive(tickIndex));
        } else {
            return new anchor_1.BN(tickIndexToSqrtPriceNegative(tickIndex));
        }
    }
    static sqrtPriceX64ToTickIndex(sqrtPriceX64) {
        if (sqrtPriceX64.gt(new anchor_1.BN(public_1.MAX_SQRT_PRICE)) || sqrtPriceX64.lt(new anchor_1.BN(public_1.MIN_SQRT_PRICE))) {
            throw new Error("Provided sqrtPrice is not within the supported sqrtPrice range.");
        }
        const msb = sqrtPriceX64.bitLength() - 1;
        const adjustedMsb = new anchor_1.BN(msb - 64);
        const log2pIntegerX32 = signedShiftLeft(adjustedMsb, 32, 128);
        let bit = new anchor_1.BN("8000000000000000", "hex");
        let precision = 0;
        let log2pFractionX64 = new anchor_1.BN(0);
        let r = msb >= 64 ? sqrtPriceX64.shrn(msb - 63) : sqrtPriceX64.shln(63 - msb);
        while(bit.gt(new anchor_1.BN(0)) && precision < BIT_PRECISION){
            r = r.mul(r);
            let rMoreThanTwo = r.shrn(127);
            r = r.shrn(63 + rMoreThanTwo.toNumber());
            log2pFractionX64 = log2pFractionX64.add(bit.mul(rMoreThanTwo));
            bit = bit.shrn(1);
            precision += 1;
        }
        const log2pFractionX32 = log2pFractionX64.shrn(32);
        const log2pX32 = log2pIntegerX32.add(log2pFractionX32);
        const logbpX64 = log2pX32.mul(new anchor_1.BN(LOG_B_2_X32));
        const tickLow = signedShiftRight(logbpX64.sub(new anchor_1.BN(LOG_B_P_ERR_MARGIN_LOWER_X64)), 64, 128).toNumber();
        const tickHigh = signedShiftRight(logbpX64.add(new anchor_1.BN(LOG_B_P_ERR_MARGIN_UPPER_X64)), 64, 128).toNumber();
        if (tickLow == tickHigh) {
            return tickLow;
        } else {
            const derivedTickHighSqrtPriceX64 = PriceMath.tickIndexToSqrtPriceX64(tickHigh);
            if (derivedTickHighSqrtPriceX64.lte(sqrtPriceX64)) {
                return tickHigh;
            } else {
                return tickLow;
            }
        }
    }
    static tickIndexToPrice(tickIndex, decimalsA, decimalsB) {
        return PriceMath.sqrtPriceX64ToPrice(PriceMath.tickIndexToSqrtPriceX64(tickIndex), decimalsA, decimalsB);
    }
    static priceToTickIndex(price, decimalsA, decimalsB) {
        return PriceMath.sqrtPriceX64ToTickIndex(PriceMath.priceToSqrtPriceX64(price, decimalsA, decimalsB));
    }
    static priceToInitializableTickIndex(price, decimalsA, decimalsB, tickSpacing) {
        return tick_utils_1.TickUtil.getInitializableTickIndex(PriceMath.priceToTickIndex(price, decimalsA, decimalsB), tickSpacing);
    }
    static invertPrice(price, decimalsA, decimalsB) {
        const tick = PriceMath.priceToTickIndex(price, decimalsA, decimalsB);
        const invTick = tick_utils_1.TickUtil.invertTick(tick);
        return PriceMath.tickIndexToPrice(invTick, decimalsB, decimalsA);
    }
    static invertSqrtPriceX64(sqrtPriceX64) {
        const tick = PriceMath.sqrtPriceX64ToTickIndex(sqrtPriceX64);
        const invTick = tick_utils_1.TickUtil.invertTick(tick);
        return PriceMath.tickIndexToSqrtPriceX64(invTick);
    }
    static getSlippageBoundForSqrtPrice(sqrtPriceX64, slippage) {
        const sqrtPriceX64Decimal = common_sdk_1.DecimalUtil.fromBN(sqrtPriceX64);
        const slippageNumerator = new decimal_js_1.default(slippage.numerator.toString());
        const slippageDenominator = new decimal_js_1.default(slippage.denominator.toString());
        const lowerBoundSqrtPriceDecimal = sqrtPriceX64Decimal.mul(slippageDenominator.sub(slippageNumerator).sqrt()).div(slippageDenominator.sqrt()).toDecimalPlaces(0);
        const upperBoundSqrtPriceDecimal = sqrtPriceX64Decimal.mul(slippageDenominator.add(slippageNumerator).sqrt()).div(slippageDenominator.sqrt()).toDecimalPlaces(0);
        const lowerBoundSqrtPrice = anchor_1.BN.min(anchor_1.BN.max(new anchor_1.BN(lowerBoundSqrtPriceDecimal.toFixed(0)), public_1.MIN_SQRT_PRICE_BN), public_1.MAX_SQRT_PRICE_BN);
        const upperBoundSqrtPrice = anchor_1.BN.min(anchor_1.BN.max(new anchor_1.BN(upperBoundSqrtPriceDecimal.toFixed(0)), public_1.MIN_SQRT_PRICE_BN), public_1.MAX_SQRT_PRICE_BN);
        const lowerTickCurrentIndex = PriceMath.sqrtPriceX64ToTickIndex(lowerBoundSqrtPrice);
        const upperTickCurrentIndex = PriceMath.sqrtPriceX64ToTickIndex(upperBoundSqrtPrice);
        return {
            lowerBound: [
                lowerBoundSqrtPrice,
                lowerTickCurrentIndex
            ],
            upperBound: [
                upperBoundSqrtPrice,
                upperTickCurrentIndex
            ]
        };
    }
}
exports.PriceMath = PriceMath;
function tickIndexToSqrtPricePositive(tick) {
    let ratio;
    if ((tick & 1) != 0) {
        ratio = new anchor_1.BN("79232123823359799118286999567");
    } else {
        ratio = new anchor_1.BN("79228162514264337593543950336");
    }
    if ((tick & 2) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("79236085330515764027303304731")), 96, 256);
    }
    if ((tick & 4) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("79244008939048815603706035061")), 96, 256);
    }
    if ((tick & 8) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("79259858533276714757314932305")), 96, 256);
    }
    if ((tick & 16) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("79291567232598584799939703904")), 96, 256);
    }
    if ((tick & 32) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("79355022692464371645785046466")), 96, 256);
    }
    if ((tick & 64) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("79482085999252804386437311141")), 96, 256);
    }
    if ((tick & 128) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("79736823300114093921829183326")), 96, 256);
    }
    if ((tick & 256) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("80248749790819932309965073892")), 96, 256);
    }
    if ((tick & 512) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("81282483887344747381513967011")), 96, 256);
    }
    if ((tick & 1024) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("83390072131320151908154831281")), 96, 256);
    }
    if ((tick & 2048) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("87770609709833776024991924138")), 96, 256);
    }
    if ((tick & 4096) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("97234110755111693312479820773")), 96, 256);
    }
    if ((tick & 8192) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("119332217159966728226237229890")), 96, 256);
    }
    if ((tick & 16384) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("179736315981702064433883588727")), 96, 256);
    }
    if ((tick & 32768) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("407748233172238350107850275304")), 96, 256);
    }
    if ((tick & 65536) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("2098478828474011932436660412517")), 96, 256);
    }
    if ((tick & 131072) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("55581415166113811149459800483533")), 96, 256);
    }
    if ((tick & 262144) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("38992368544603139932233054999993551")), 96, 256);
    }
    return signedShiftRight(ratio, 32, 256);
}
function tickIndexToSqrtPriceNegative(tickIndex) {
    let tick = Math.abs(tickIndex);
    let ratio;
    if ((tick & 1) != 0) {
        ratio = new anchor_1.BN("18445821805675392311");
    } else {
        ratio = new anchor_1.BN("18446744073709551616");
    }
    if ((tick & 2) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("18444899583751176498")), 64, 256);
    }
    if ((tick & 4) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("18443055278223354162")), 64, 256);
    }
    if ((tick & 8) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("18439367220385604838")), 64, 256);
    }
    if ((tick & 16) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("18431993317065449817")), 64, 256);
    }
    if ((tick & 32) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("18417254355718160513")), 64, 256);
    }
    if ((tick & 64) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("18387811781193591352")), 64, 256);
    }
    if ((tick & 128) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("18329067761203520168")), 64, 256);
    }
    if ((tick & 256) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("18212142134806087854")), 64, 256);
    }
    if ((tick & 512) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("17980523815641551639")), 64, 256);
    }
    if ((tick & 1024) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("17526086738831147013")), 64, 256);
    }
    if ((tick & 2048) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("16651378430235024244")), 64, 256);
    }
    if ((tick & 4096) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("15030750278693429944")), 64, 256);
    }
    if ((tick & 8192) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("12247334978882834399")), 64, 256);
    }
    if ((tick & 16384) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("8131365268884726200")), 64, 256);
    }
    if ((tick & 32768) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("3584323654723342297")), 64, 256);
    }
    if ((tick & 65536) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("696457651847595233")), 64, 256);
    }
    if ((tick & 131072) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("26294789957452057")), 64, 256);
    }
    if ((tick & 262144) != 0) {
        ratio = signedShiftRight(ratio.mul(new anchor_1.BN("37481735321082")), 64, 256);
    }
    return ratio;
}
function signedShiftLeft(n0, shiftBy, bitWidth) {
    let twosN0 = n0.toTwos(bitWidth).shln(shiftBy);
    twosN0.imaskn(bitWidth + 1);
    return twosN0.fromTwos(bitWidth);
}
function signedShiftRight(n0, shiftBy, bitWidth) {
    let twoN0 = n0.toTwos(bitWidth).shrn(shiftBy);
    twoN0.imaskn(bitWidth - shiftBy + 1);
    return twoN0.fromTwos(bitWidth - shiftBy);
} //# sourceMappingURL=price-math.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/pda-utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PDAUtil = void 0;
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const price_math_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/price-math.js [app-route] (ecmascript)");
const tick_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/tick-utils.js [app-route] (ecmascript)");
const PDA_WHIRLPOOL_SEED = "whirlpool";
const PDA_POSITION_SEED = "position";
const PDA_METADATA_SEED = "metadata";
const PDA_TICK_ARRAY_SEED = "tick_array";
const PDA_FEE_TIER_SEED = "fee_tier";
const PDA_ORACLE_SEED = "oracle";
const PDA_POSITION_BUNDLE_SEED = "position_bundle";
const PDA_BUNDLED_POSITION_SEED = "bundled_position";
const PDA_CONFIG_EXTENSION_SEED = "config_extension";
const PDA_TOKEN_BADGE_SEED = "token_badge";
class PDAUtil {
    static getWhirlpool(programId, whirlpoolsConfigKey, tokenMintAKey, tokenMintBKey, tickSpacing) {
        return common_sdk_1.AddressUtil.findProgramAddress([
            Buffer.from(PDA_WHIRLPOOL_SEED),
            whirlpoolsConfigKey.toBuffer(),
            tokenMintAKey.toBuffer(),
            tokenMintBKey.toBuffer(),
            new anchor_1.BN(tickSpacing).toArrayLike(Buffer, "le", 2)
        ], programId);
    }
    static getPosition(programId, positionMintKey) {
        return common_sdk_1.AddressUtil.findProgramAddress([
            Buffer.from(PDA_POSITION_SEED),
            positionMintKey.toBuffer()
        ], programId);
    }
    static getPositionMetadata(positionMintKey) {
        return common_sdk_1.AddressUtil.findProgramAddress([
            Buffer.from(PDA_METADATA_SEED),
            public_1.METADATA_PROGRAM_ADDRESS.toBuffer(),
            positionMintKey.toBuffer()
        ], public_1.METADATA_PROGRAM_ADDRESS);
    }
    static getTickArray(programId, whirlpoolAddress, startTick) {
        return common_sdk_1.AddressUtil.findProgramAddress([
            Buffer.from(PDA_TICK_ARRAY_SEED),
            whirlpoolAddress.toBuffer(),
            Buffer.from(startTick.toString())
        ], programId);
    }
    static getTickArrayFromTickIndex(tickIndex, tickSpacing, whirlpool, programId, tickArrayOffset = 0) {
        const startIndex = tick_utils_1.TickUtil.getStartTickIndex(tickIndex, tickSpacing, tickArrayOffset);
        return PDAUtil.getTickArray(common_sdk_1.AddressUtil.toPubKey(programId), common_sdk_1.AddressUtil.toPubKey(whirlpool), startIndex);
    }
    static getTickArrayFromSqrtPrice(sqrtPriceX64, tickSpacing, whirlpool, programId, tickArrayOffset = 0) {
        const tickIndex = price_math_1.PriceMath.sqrtPriceX64ToTickIndex(sqrtPriceX64);
        return PDAUtil.getTickArrayFromTickIndex(tickIndex, tickSpacing, whirlpool, programId, tickArrayOffset);
    }
    static getFeeTier(programId, whirlpoolsConfigAddress, tickSpacing) {
        return common_sdk_1.AddressUtil.findProgramAddress([
            Buffer.from(PDA_FEE_TIER_SEED),
            whirlpoolsConfigAddress.toBuffer(),
            new anchor_1.BN(tickSpacing).toArrayLike(Buffer, "le", 2)
        ], programId);
    }
    static getOracle(programId, whirlpoolAddress) {
        return common_sdk_1.AddressUtil.findProgramAddress([
            Buffer.from(PDA_ORACLE_SEED),
            whirlpoolAddress.toBuffer()
        ], programId);
    }
    static getBundledPosition(programId, positionBundleMintKey, bundleIndex) {
        return common_sdk_1.AddressUtil.findProgramAddress([
            Buffer.from(PDA_BUNDLED_POSITION_SEED),
            positionBundleMintKey.toBuffer(),
            Buffer.from(bundleIndex.toString())
        ], programId);
    }
    static getPositionBundle(programId, positionBundleMintKey) {
        return common_sdk_1.AddressUtil.findProgramAddress([
            Buffer.from(PDA_POSITION_BUNDLE_SEED),
            positionBundleMintKey.toBuffer()
        ], programId);
    }
    static getPositionBundleMetadata(positionBundleMintKey) {
        return common_sdk_1.AddressUtil.findProgramAddress([
            Buffer.from(PDA_METADATA_SEED),
            public_1.METADATA_PROGRAM_ADDRESS.toBuffer(),
            positionBundleMintKey.toBuffer()
        ], public_1.METADATA_PROGRAM_ADDRESS);
    }
    static getConfigExtension(programId, whirlpoolsConfigAddress) {
        return common_sdk_1.AddressUtil.findProgramAddress([
            Buffer.from(PDA_CONFIG_EXTENSION_SEED),
            whirlpoolsConfigAddress.toBuffer()
        ], programId);
    }
    static getTokenBadge(programId, whirlpoolsConfigAddress, tokenMintKey) {
        return common_sdk_1.AddressUtil.findProgramAddress([
            Buffer.from(PDA_TOKEN_BADGE_SEED),
            whirlpoolsConfigAddress.toBuffer(),
            tokenMintKey.toBuffer()
        ], programId);
    }
}
exports.PDAUtil = PDAUtil; //# sourceMappingURL=pda-utils.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/constants.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TOKEN_MINTS = void 0;
exports.TOKEN_MINTS = {
    USDC: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
    SOL: "So11111111111111111111111111111111111111112",
    USDT: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
    USDH: "USDH1SM1ojwWUga67PGrgFWUHibbjqMvuMaDkRJTgkX",
    mSOL: "mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So",
    stSOL: "7dHbWXmci3dT8UFYWYZweBLXgycu7Y3iL6trKn1Y7ARj"
}; //# sourceMappingURL=constants.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/types.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TokenType = exports.SwapDirection = void 0;
var SwapDirection;
(function(SwapDirection) {
    SwapDirection["AtoB"] = "aToB";
    SwapDirection["BtoA"] = "bToA";
})(SwapDirection || (exports.SwapDirection = SwapDirection = {}));
var TokenType;
(function(TokenType) {
    TokenType[TokenType["TokenA"] = 1] = "TokenA";
    TokenType[TokenType["TokenB"] = 2] = "TokenB";
})(TokenType || (exports.TokenType = TokenType = {})); //# sourceMappingURL=types.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/pool-utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PoolUtil = void 0;
exports.toTokenAmount = toTokenAmount;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const decimal_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/constants.js [app-route] (ecmascript)");
const price_math_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/price-math.js [app-route] (ecmascript)");
const types_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/types.js [app-route] (ecmascript)");
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
class PoolUtil {
    static isRewardInitialized(rewardInfo) {
        return !web3_js_1.PublicKey.default.equals(rewardInfo.mint) && !web3_js_1.PublicKey.default.equals(rewardInfo.vault);
    }
    static getTokenType(pool, mint) {
        if (pool.tokenMintA.equals(mint)) {
            return types_1.TokenType.TokenA;
        } else if (pool.tokenMintB.equals(mint)) {
            return types_1.TokenType.TokenB;
        }
        return undefined;
    }
    static getFeeRate(feeRate) {
        return common_sdk_1.Percentage.fromFraction(feeRate, 1e6);
    }
    static getProtocolFeeRate(protocolFeeRate) {
        return common_sdk_1.Percentage.fromFraction(protocolFeeRate, 1e4);
    }
    static orderMints(mintX, mintY) {
        return this.compareMints(mintX, mintY) < 0 ? [
            mintX,
            mintY
        ] : [
            mintY,
            mintX
        ];
    }
    static compareMints(mintX, mintY) {
        return Buffer.compare(common_sdk_1.AddressUtil.toPubKey(mintX).toBuffer(), common_sdk_1.AddressUtil.toPubKey(mintY).toBuffer());
    }
    static getTokenAmountsFromLiquidity(liquidity, currentSqrtPrice, lowerSqrtPrice, upperSqrtPrice, round_up) {
        const _liquidity = new decimal_js_1.default(liquidity.toString());
        const _currentPrice = new decimal_js_1.default(currentSqrtPrice.toString());
        const _lowerPrice = new decimal_js_1.default(lowerSqrtPrice.toString());
        const _upperPrice = new decimal_js_1.default(upperSqrtPrice.toString());
        let tokenA, tokenB;
        if (currentSqrtPrice.lt(lowerSqrtPrice)) {
            tokenA = common_sdk_1.MathUtil.toX64_Decimal(_liquidity).mul(_upperPrice.sub(_lowerPrice)).div(_lowerPrice.mul(_upperPrice));
            tokenB = new decimal_js_1.default(0);
        } else if (currentSqrtPrice.lt(upperSqrtPrice)) {
            tokenA = common_sdk_1.MathUtil.toX64_Decimal(_liquidity).mul(_upperPrice.sub(_currentPrice)).div(_currentPrice.mul(_upperPrice));
            tokenB = common_sdk_1.MathUtil.fromX64_Decimal(_liquidity.mul(_currentPrice.sub(_lowerPrice)));
        } else {
            tokenA = new decimal_js_1.default(0);
            tokenB = common_sdk_1.MathUtil.fromX64_Decimal(_liquidity.mul(_upperPrice.sub(_lowerPrice)));
        }
        if (round_up) {
            return {
                tokenA: new bn_js_1.default(tokenA.ceil().toString()),
                tokenB: new bn_js_1.default(tokenB.ceil().toString())
            };
        } else {
            return {
                tokenA: new bn_js_1.default(tokenA.floor().toString()),
                tokenB: new bn_js_1.default(tokenB.floor().toString())
            };
        }
    }
    static estimateLiquidityFromTokenAmounts(currTick, lowerTick, upperTick, tokenAmount) {
        return this.estimateMaxLiquidityFromTokenAmounts(price_math_1.PriceMath.tickIndexToSqrtPriceX64(currTick), lowerTick, upperTick, tokenAmount);
    }
    static estimateMaxLiquidityFromTokenAmounts(sqrtPriceX64, tickLowerIndex, tickUpperIndex, tokenAmount) {
        if (tickUpperIndex < tickLowerIndex) {
            throw new Error("upper tick cannot be lower than the lower tick");
        }
        const currSqrtPrice = sqrtPriceX64;
        const lowerSqrtPrice = price_math_1.PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex);
        const upperSqrtPrice = price_math_1.PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex);
        if (currSqrtPrice.gte(upperSqrtPrice)) {
            return estLiquidityForTokenB(upperSqrtPrice, lowerSqrtPrice, tokenAmount.tokenB);
        } else if (currSqrtPrice.lt(lowerSqrtPrice)) {
            return estLiquidityForTokenA(lowerSqrtPrice, upperSqrtPrice, tokenAmount.tokenA);
        } else {
            const estLiquidityAmountA = estLiquidityForTokenA(currSqrtPrice, upperSqrtPrice, tokenAmount.tokenA);
            const estLiquidityAmountB = estLiquidityForTokenB(currSqrtPrice, lowerSqrtPrice, tokenAmount.tokenB);
            return bn_js_1.default.min(estLiquidityAmountA, estLiquidityAmountB);
        }
    }
    static toBaseQuoteOrder(tokenMintAKey, tokenMintBKey) {
        const pair = [
            tokenMintAKey,
            tokenMintBKey
        ];
        return pair.sort(sortByQuotePriority);
    }
    static async isSupportedToken(ctx, whirlpoolsConfig, tokenMintKey) {
        const mintWithTokenProgram = await ctx.fetcher.getMintInfo(tokenMintKey);
        (0, tiny_invariant_1.default)(mintWithTokenProgram, "Mint not found");
        if (mintWithTokenProgram.tokenProgram.equals(spl_token_1.TOKEN_PROGRAM_ID)) {
            return true;
        }
        if (mintWithTokenProgram.address.equals(spl_token_1.NATIVE_MINT_2022)) {
            return false;
        }
        const tokenBadgePda = __1.PDAUtil.getTokenBadge(ctx.program.programId, whirlpoolsConfig, tokenMintKey);
        const tokenBadge = await ctx.fetcher.getTokenBadge(tokenBadgePda.publicKey);
        const isTokenBadgeInitialized = tokenBadge !== null;
        if (mintWithTokenProgram.freezeAuthority !== null && !isTokenBadgeInitialized) {
            return false;
        }
        const EXTENSION_TYPE_CONFIDENTIAL_TRANSFER_FEE_CONFIG = 16;
        const extensions = (0, spl_token_1.getExtensionTypes)(mintWithTokenProgram.tlvData);
        for (const extension of extensions){
            switch(extension){
                case spl_token_1.ExtensionType.TransferFeeConfig:
                case spl_token_1.ExtensionType.InterestBearingConfig:
                case spl_token_1.ExtensionType.TokenMetadata:
                case spl_token_1.ExtensionType.MetadataPointer:
                case spl_token_1.ExtensionType.ConfidentialTransferMint:
                case EXTENSION_TYPE_CONFIDENTIAL_TRANSFER_FEE_CONFIG:
                    continue;
                case spl_token_1.ExtensionType.PermanentDelegate:
                case spl_token_1.ExtensionType.TransferHook:
                case spl_token_1.ExtensionType.MintCloseAuthority:
                    if (!isTokenBadgeInitialized) {
                        return false;
                    }
                    continue;
                case spl_token_1.ExtensionType.DefaultAccountState:
                    if (!isTokenBadgeInitialized) {
                        return false;
                    }
                    const defaultAccountState = (0, spl_token_1.getDefaultAccountState)(mintWithTokenProgram);
                    if (defaultAccountState.state !== spl_token_1.AccountState.Initialized) {
                        return false;
                    }
                    continue;
                case spl_token_1.ExtensionType.NonTransferable:
                    return false;
                default:
                    return false;
            }
        }
        return true;
    }
}
exports.PoolUtil = PoolUtil;
function toTokenAmount(a, b) {
    return {
        tokenA: new bn_js_1.default(a.toString()),
        tokenB: new bn_js_1.default(b.toString())
    };
}
const QUOTE_TOKENS = {
    [constants_1.TOKEN_MINTS["USDT"]]: 100,
    [constants_1.TOKEN_MINTS["USDC"]]: 90,
    [constants_1.TOKEN_MINTS["USDH"]]: 80,
    [constants_1.TOKEN_MINTS["SOL"]]: 70,
    [constants_1.TOKEN_MINTS["mSOL"]]: 60,
    [constants_1.TOKEN_MINTS["stSOL"]]: 50
};
const DEFAULT_QUOTE_PRIORITY = 0;
function getQuoteTokenPriority(mint) {
    const value = QUOTE_TOKENS[mint];
    if (value) {
        return value;
    }
    return DEFAULT_QUOTE_PRIORITY;
}
function sortByQuotePriority(mintLeft, mintRight) {
    return getQuoteTokenPriority(mintLeft.toString()) - getQuoteTokenPriority(mintRight.toString());
}
function estLiquidityForTokenA(sqrtPrice1, sqrtPrice2, tokenAmount) {
    const lowerSqrtPriceX64 = bn_js_1.default.min(sqrtPrice1, sqrtPrice2);
    const upperSqrtPriceX64 = bn_js_1.default.max(sqrtPrice1, sqrtPrice2);
    const num = common_sdk_1.MathUtil.fromX64_BN(tokenAmount.mul(upperSqrtPriceX64).mul(lowerSqrtPriceX64));
    const dem = upperSqrtPriceX64.sub(lowerSqrtPriceX64);
    return num.div(dem);
}
function estLiquidityForTokenB(sqrtPrice1, sqrtPrice2, tokenAmount) {
    const lowerSqrtPriceX64 = bn_js_1.default.min(sqrtPrice1, sqrtPrice2);
    const upperSqrtPriceX64 = bn_js_1.default.max(sqrtPrice1, sqrtPrice2);
    const delta = upperSqrtPriceX64.sub(lowerSqrtPriceX64);
    return tokenAmount.shln(64).div(delta);
} //# sourceMappingURL=pool-utils.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/position-bundle-util.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PositionBundleUtil = void 0;
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
class PositionBundleUtil {
    static checkBundleIndexInBounds(bundleIndex) {
        return bundleIndex >= 0 && bundleIndex < public_1.POSITION_BUNDLE_SIZE;
    }
    static isOccupied(positionBundle, bundleIndex) {
        (0, tiny_invariant_1.default)(PositionBundleUtil.checkBundleIndexInBounds(bundleIndex), "bundleIndex out of range");
        const array = PositionBundleUtil.convertBitmapToArray(positionBundle);
        return array[bundleIndex];
    }
    static isUnoccupied(positionBundle, bundleIndex) {
        return !PositionBundleUtil.isOccupied(positionBundle, bundleIndex);
    }
    static isFull(positionBundle) {
        const unoccupied = PositionBundleUtil.getUnoccupiedBundleIndexes(positionBundle);
        return unoccupied.length === 0;
    }
    static isEmpty(positionBundle) {
        const occupied = PositionBundleUtil.getOccupiedBundleIndexes(positionBundle);
        return occupied.length === 0;
    }
    static getOccupiedBundleIndexes(positionBundle) {
        const result = [];
        PositionBundleUtil.convertBitmapToArray(positionBundle).forEach((occupied, index)=>{
            if (occupied) {
                result.push(index);
            }
        });
        return result;
    }
    static getUnoccupiedBundleIndexes(positionBundle) {
        const result = [];
        PositionBundleUtil.convertBitmapToArray(positionBundle).forEach((occupied, index)=>{
            if (!occupied) {
                result.push(index);
            }
        });
        return result;
    }
    static findUnoccupiedBundleIndex(positionBundle) {
        const unoccupied = PositionBundleUtil.getUnoccupiedBundleIndexes(positionBundle);
        return unoccupied.length === 0 ? null : unoccupied[0];
    }
    static convertBitmapToArray(positionBundle) {
        const result = [];
        positionBundle.positionBitmap.map((bitmap)=>{
            for(let offset = 0; offset < 8; offset++){
                result.push((bitmap & 1 << offset) !== 0);
            }
        });
        return result;
    }
}
exports.PositionBundleUtil = PositionBundleUtil; //# sourceMappingURL=position-bundle-util.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/errors/errors.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WhirlpoolsError = exports.RouteQueryErrorCode = exports.SwapErrorCode = exports.TokenErrorCode = exports.MathErrorCode = void 0;
var MathErrorCode;
(function(MathErrorCode) {
    MathErrorCode["MultiplicationOverflow"] = "MultiplicationOverflow";
    MathErrorCode["MulDivOverflow"] = "MulDivOverflow";
    MathErrorCode["MultiplicationShiftRightOverflow"] = "MultiplicationShiftRightOverflow";
    MathErrorCode["DivideByZero"] = "DivideByZero";
})(MathErrorCode || (exports.MathErrorCode = MathErrorCode = {}));
var TokenErrorCode;
(function(TokenErrorCode) {
    TokenErrorCode["TokenMaxExceeded"] = "TokenMaxExceeded";
    TokenErrorCode["TokenMinSubceeded"] = "TokenMinSubceeded";
})(TokenErrorCode || (exports.TokenErrorCode = TokenErrorCode = {}));
var SwapErrorCode;
(function(SwapErrorCode) {
    SwapErrorCode["InvalidDevFeePercentage"] = "InvalidDevFeePercentage";
    SwapErrorCode["InvalidSqrtPriceLimitDirection"] = "InvalidSqrtPriceLimitDirection";
    SwapErrorCode["SqrtPriceOutOfBounds"] = "SqrtPriceOutOfBounds";
    SwapErrorCode["ZeroTradableAmount"] = "ZeroTradableAmount";
    SwapErrorCode["AmountOutBelowMinimum"] = "AmountOutBelowMinimum";
    SwapErrorCode["AmountInAboveMaximum"] = "AmountInAboveMaximum";
    SwapErrorCode["TickArrayCrossingAboveMax"] = "TickArrayCrossingAboveMax";
    SwapErrorCode["TickArrayIndexNotInitialized"] = "TickArrayIndexNotInitialized";
    SwapErrorCode["TickArraySequenceInvalid"] = "TickArraySequenceInvalid";
    SwapErrorCode["AmountRemainingOverflow"] = "AmountRemainingOverflow";
    SwapErrorCode["AmountCalcOverflow"] = "AmountCalcOverflow";
})(SwapErrorCode || (exports.SwapErrorCode = SwapErrorCode = {}));
var RouteQueryErrorCode;
(function(RouteQueryErrorCode) {
    RouteQueryErrorCode["RouteDoesNotExist"] = "RouteDoesNotExist";
    RouteQueryErrorCode["TradeAmountTooHigh"] = "TradeAmountTooHigh";
    RouteQueryErrorCode["ZeroInputAmount"] = "ZeroInputAmount";
    RouteQueryErrorCode["General"] = "General";
})(RouteQueryErrorCode || (exports.RouteQueryErrorCode = RouteQueryErrorCode = {}));
class WhirlpoolsError extends Error {
    message;
    errorCode;
    constructor(message, errorCode, stack){
        super(message);
        this.message = message;
        this.errorCode = errorCode;
        this.stack = stack;
    }
    static isWhirlpoolsErrorCode(e, code) {
        return e instanceof WhirlpoolsError && e.errorCode === code;
    }
}
exports.WhirlpoolsError = WhirlpoolsError; //# sourceMappingURL=errors.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/math/bit-math.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BitMath = void 0;
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const errors_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/errors/errors.js [app-route] (ecmascript)");
class BitMath {
    static mul(n0, n1, limit) {
        const result = n0.mul(n1);
        if (this.isOverLimit(result, limit)) {
            throw new errors_1.WhirlpoolsError(`Mul result higher than u${limit}`, errors_1.MathErrorCode.MultiplicationOverflow);
        }
        return result;
    }
    static mulDiv(n0, n1, d, limit) {
        return this.mulDivRoundUpIf(n0, n1, d, false, limit);
    }
    static mulDivRoundUp(n0, n1, d, limit) {
        return this.mulDivRoundUpIf(n0, n1, d, true, limit);
    }
    static mulDivRoundUpIf(n0, n1, d, roundUp, limit) {
        if (d.eq(common_sdk_1.ZERO)) {
            throw new errors_1.WhirlpoolsError("mulDiv denominator is zero", errors_1.MathErrorCode.DivideByZero);
        }
        const p = this.mul(n0, n1, limit);
        const n = p.div(d);
        return roundUp && p.mod(d).gt(common_sdk_1.ZERO) ? n.add(common_sdk_1.ONE) : n;
    }
    static checked_mul_shift_right(n0, n1, limit) {
        return this.checked_mul_shift_right_round_up_if(n0, n1, false, limit);
    }
    static checked_mul_shift_right_round_up_if(n0, n1, roundUp, limit) {
        if (n0.eq(common_sdk_1.ZERO) || n1.eq(common_sdk_1.ZERO)) {
            return common_sdk_1.ZERO;
        }
        const p = this.mul(n0, n1, limit);
        if (this.isOverLimit(p, limit)) {
            throw new errors_1.WhirlpoolsError(`MulShiftRight overflowed u${limit}.`, errors_1.MathErrorCode.MultiplicationShiftRightOverflow);
        }
        const result = common_sdk_1.MathUtil.fromX64_BN(p);
        const shouldRound = roundUp && p.and(common_sdk_1.U64_MAX).gt(common_sdk_1.ZERO);
        if (shouldRound && result.eq(common_sdk_1.U64_MAX)) {
            throw new errors_1.WhirlpoolsError(`MulShiftRight overflowed u${limit}.`, errors_1.MathErrorCode.MultiplicationOverflow);
        }
        return shouldRound ? result.add(common_sdk_1.ONE) : result;
    }
    static isOverLimit(n0, limit) {
        const limitBN = common_sdk_1.TWO.pow(new anchor_1.BN(limit)).sub(common_sdk_1.ONE);
        return n0.gt(limitBN);
    }
    static divRoundUp(n, d) {
        return this.divRoundUpIf(n, d, true);
    }
    static divRoundUpIf(n, d, roundUp) {
        if (d.eq(common_sdk_1.ZERO)) {
            throw new errors_1.WhirlpoolsError("divRoundUpIf - divide by zero", errors_1.MathErrorCode.DivideByZero);
        }
        let q = n.div(d);
        return roundUp && n.mod(d).gt(common_sdk_1.ZERO) ? q.add(common_sdk_1.ONE) : q;
    }
}
exports.BitMath = BitMath; //# sourceMappingURL=bit-math.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/math/token-math.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.AmountDeltaU64 = void 0;
exports.getAmountDeltaA = getAmountDeltaA;
exports.tryGetAmountDeltaA = tryGetAmountDeltaA;
exports.getAmountDeltaB = getAmountDeltaB;
exports.tryGetAmountDeltaB = tryGetAmountDeltaB;
exports.getNextSqrtPrice = getNextSqrtPrice;
exports.adjustForSlippage = adjustForSlippage;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const errors_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/errors/errors.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const bit_math_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/math/bit-math.js [app-route] (ecmascript)");
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
class AmountDeltaU64 {
    inner;
    constructor(inner){
        this.inner = inner;
    }
    static fromValid(value) {
        return new AmountDeltaU64({
            type: "Valid",
            value
        });
    }
    static fromExceedsMax(error) {
        return new AmountDeltaU64({
            type: "ExceedsMax",
            error
        });
    }
    lte(other) {
        if (this.inner.type === "ExceedsMax") {
            return false;
        }
        return this.inner.value.lte(other);
    }
    exceedsMax() {
        return this.inner.type === "ExceedsMax";
    }
    value() {
        (0, tiny_invariant_1.default)(this.inner.type === "Valid", "Expected valid AmountDeltaU64");
        return this.inner.value;
    }
    unwrap() {
        if (this.inner.type === "Valid") {
            return this.inner.value;
        } else {
            throw this.inner.error;
        }
    }
}
exports.AmountDeltaU64 = AmountDeltaU64;
function getAmountDeltaA(currSqrtPrice, targetSqrtPrice, currLiquidity, roundUp) {
    return tryGetAmountDeltaA(currSqrtPrice, targetSqrtPrice, currLiquidity, roundUp).unwrap();
}
function tryGetAmountDeltaA(currSqrtPrice, targetSqrtPrice, currLiquidity, roundUp) {
    let [sqrtPriceLower, sqrtPriceUpper] = toIncreasingPriceOrder(currSqrtPrice, targetSqrtPrice);
    let sqrtPriceDiff = sqrtPriceUpper.sub(sqrtPriceLower);
    let numerator = currLiquidity.mul(sqrtPriceDiff).shln(64);
    let denominator = sqrtPriceLower.mul(sqrtPriceUpper);
    let quotient = numerator.div(denominator);
    let remainder = numerator.mod(denominator);
    let result = roundUp && !remainder.eq(common_sdk_1.ZERO) ? quotient.add(new bn_js_1.default(1)) : quotient;
    if (result.gt(common_sdk_1.U64_MAX)) {
        return AmountDeltaU64.fromExceedsMax(new errors_1.WhirlpoolsError("Results larger than U64", errors_1.TokenErrorCode.TokenMaxExceeded));
    }
    return AmountDeltaU64.fromValid(result);
}
function getAmountDeltaB(currSqrtPrice, targetSqrtPrice, currLiquidity, roundUp) {
    return tryGetAmountDeltaB(currSqrtPrice, targetSqrtPrice, currLiquidity, roundUp).unwrap();
}
function tryGetAmountDeltaB(currSqrtPrice, targetSqrtPrice, currLiquidity, roundUp) {
    let [sqrtPriceLower, sqrtPriceUpper] = toIncreasingPriceOrder(currSqrtPrice, targetSqrtPrice);
    const n0 = currLiquidity;
    const n1 = sqrtPriceUpper.sub(sqrtPriceLower);
    const limit = 128;
    if (n0.eq(common_sdk_1.ZERO) || n1.eq(common_sdk_1.ZERO)) {
        return AmountDeltaU64.fromValid(common_sdk_1.ZERO);
    }
    const p = bit_math_1.BitMath.mul(n0, n1, limit * 2);
    if (bit_math_1.BitMath.isOverLimit(p, limit)) {
        return AmountDeltaU64.fromExceedsMax(new errors_1.WhirlpoolsError(`MulShiftRight overflowed u${limit}.`, errors_1.MathErrorCode.MultiplicationShiftRightOverflow));
    }
    const result = common_sdk_1.MathUtil.fromX64_BN(p);
    const shouldRound = roundUp && p.and(common_sdk_1.U64_MAX).gt(common_sdk_1.ZERO);
    if (shouldRound && result.eq(common_sdk_1.U64_MAX)) {
        return AmountDeltaU64.fromExceedsMax(new errors_1.WhirlpoolsError(`MulShiftRight overflowed u${limit}.`, errors_1.MathErrorCode.MultiplicationOverflow));
    }
    return AmountDeltaU64.fromValid(shouldRound ? result.add(common_sdk_1.ONE) : result);
}
function getNextSqrtPrice(sqrtPrice, currLiquidity, amount, amountSpecifiedIsInput, aToB) {
    if (amountSpecifiedIsInput === aToB) {
        return getNextSqrtPriceFromARoundUp(sqrtPrice, currLiquidity, amount, amountSpecifiedIsInput);
    } else {
        return getNextSqrtPriceFromBRoundDown(sqrtPrice, currLiquidity, amount, amountSpecifiedIsInput);
    }
}
function adjustForSlippage(n, { numerator, denominator }, adjustUp) {
    if (adjustUp) {
        return n.mul(denominator.add(numerator)).div(denominator);
    } else {
        return n.mul(denominator).div(denominator.add(numerator));
    }
}
function toIncreasingPriceOrder(sqrtPrice0, sqrtPrice1) {
    if (sqrtPrice0.gt(sqrtPrice1)) {
        return [
            sqrtPrice1,
            sqrtPrice0
        ];
    } else {
        return [
            sqrtPrice0,
            sqrtPrice1
        ];
    }
}
function getNextSqrtPriceFromARoundUp(sqrtPrice, currLiquidity, amount, amountSpecifiedIsInput) {
    if (amount.eq(common_sdk_1.ZERO)) {
        return sqrtPrice;
    }
    let p = bit_math_1.BitMath.mul(sqrtPrice, amount, 256);
    let numerator = bit_math_1.BitMath.mul(currLiquidity, sqrtPrice, 256).shln(64);
    if (bit_math_1.BitMath.isOverLimit(numerator, 256)) {
        throw new errors_1.WhirlpoolsError("getNextSqrtPriceFromARoundUp - numerator overflow u256", errors_1.MathErrorCode.MultiplicationOverflow);
    }
    let currLiquidityShiftLeft = currLiquidity.shln(64);
    if (!amountSpecifiedIsInput && currLiquidityShiftLeft.lte(p)) {
        throw new errors_1.WhirlpoolsError("getNextSqrtPriceFromARoundUp - Unable to divide currLiquidityX64 by product", errors_1.MathErrorCode.DivideByZero);
    }
    let denominator = amountSpecifiedIsInput ? currLiquidityShiftLeft.add(p) : currLiquidityShiftLeft.sub(p);
    let price = bit_math_1.BitMath.divRoundUp(numerator, denominator);
    if (price.lt(new bn_js_1.default(public_1.MIN_SQRT_PRICE))) {
        throw new errors_1.WhirlpoolsError("getNextSqrtPriceFromARoundUp - price less than min sqrt price", errors_1.TokenErrorCode.TokenMinSubceeded);
    } else if (price.gt(new bn_js_1.default(public_1.MAX_SQRT_PRICE))) {
        throw new errors_1.WhirlpoolsError("getNextSqrtPriceFromARoundUp - price less than max sqrt price", errors_1.TokenErrorCode.TokenMaxExceeded);
    }
    return price;
}
function getNextSqrtPriceFromBRoundDown(sqrtPrice, currLiquidity, amount, amountSpecifiedIsInput) {
    let amountX64 = amount.shln(64);
    let delta = bit_math_1.BitMath.divRoundUpIf(amountX64, currLiquidity, !amountSpecifiedIsInput);
    if (amountSpecifiedIsInput) {
        sqrtPrice = sqrtPrice.add(delta);
    } else {
        sqrtPrice = sqrtPrice.sub(delta);
    }
    return sqrtPrice;
} //# sourceMappingURL=token-math.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/swap-utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ZEROED_TICKS = exports.ZEROED_TICK_DATA = void 0;
exports.getLowerSqrtPriceFromTokenA = getLowerSqrtPriceFromTokenA;
exports.getUpperSqrtPriceFromTokenA = getUpperSqrtPriceFromTokenA;
exports.getLowerSqrtPriceFromTokenB = getLowerSqrtPriceFromTokenB;
exports.getUpperSqrtPriceFromTokenB = getUpperSqrtPriceFromTokenB;
exports.getTickArrayPublicKeysWithStartTickIndex = getTickArrayPublicKeysWithStartTickIndex;
exports.buildZeroedTickArray = buildZeroedTickArray;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const public_2 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
function getLowerSqrtPriceFromTokenA(amount, liquidity, sqrtPriceX64) {
    const numerator = liquidity.mul(sqrtPriceX64).shln(64);
    const denominator = liquidity.shln(64).add(amount.mul(sqrtPriceX64));
    return common_sdk_1.MathUtil.divRoundUp(numerator, denominator);
}
function getUpperSqrtPriceFromTokenA(amount, liquidity, sqrtPriceX64) {
    const numerator = liquidity.mul(sqrtPriceX64).shln(64);
    const denominator = liquidity.shln(64).sub(amount.mul(sqrtPriceX64));
    return common_sdk_1.MathUtil.divRoundUp(numerator, denominator);
}
function getLowerSqrtPriceFromTokenB(amount, liquidity, sqrtPriceX64) {
    return sqrtPriceX64.sub(common_sdk_1.MathUtil.divRoundUp(amount.shln(64), liquidity));
}
function getUpperSqrtPriceFromTokenB(amount, liquidity, sqrtPriceX64) {
    return sqrtPriceX64.add(amount.shln(64).div(liquidity));
}
function getTickArrayPublicKeysWithStartTickIndex(tickCurrentIndex, tickSpacing, aToB, programId, whirlpoolAddress) {
    const shift = aToB ? 0 : tickSpacing;
    let offset = 0;
    let tickArrayAddresses = [];
    for(let i = 0; i < public_1.MAX_SWAP_TICK_ARRAYS; i++){
        let startIndex;
        try {
            startIndex = public_2.TickUtil.getStartTickIndex(tickCurrentIndex + shift, tickSpacing, offset);
        } catch  {
            return tickArrayAddresses;
        }
        const pda = public_2.PDAUtil.getTickArray(programId, whirlpoolAddress, startIndex);
        tickArrayAddresses.push({
            pubkey: pda.publicKey,
            startTickIndex: startIndex
        });
        offset = aToB ? offset - 1 : offset + 1;
    }
    return tickArrayAddresses;
}
exports.ZEROED_TICK_DATA = Object.freeze({
    initialized: false,
    liquidityNet: common_sdk_1.ZERO,
    liquidityGross: common_sdk_1.ZERO,
    feeGrowthOutsideA: common_sdk_1.ZERO,
    feeGrowthOutsideB: common_sdk_1.ZERO,
    rewardGrowthsOutside: [
        common_sdk_1.ZERO,
        common_sdk_1.ZERO,
        common_sdk_1.ZERO
    ]
});
exports.ZEROED_TICKS = Array.from({
    length: public_1.TICK_ARRAY_SIZE
}, ()=>exports.ZEROED_TICK_DATA);
function buildZeroedTickArray(whirlpool, startTickIndex) {
    return {
        startTickIndex,
        ticks: exports.ZEROED_TICKS,
        whirlpool
    };
} //# sourceMappingURL=swap-utils.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/swap-utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SwapUtils = void 0;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const token_math_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/math/token-math.js [app-route] (ecmascript)");
const pda_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/pda-utils.js [app-route] (ecmascript)");
const pool_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/pool-utils.js [app-route] (ecmascript)");
const types_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/types.js [app-route] (ecmascript)");
const swap_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/swap-utils.js [app-route] (ecmascript)");
class SwapUtils {
    static getDefaultSqrtPriceLimit(aToB) {
        return new bn_js_1.default(aToB ? public_1.MIN_SQRT_PRICE : public_1.MAX_SQRT_PRICE);
    }
    static getDefaultOtherAmountThreshold(amountSpecifiedIsInput) {
        return amountSpecifiedIsInput ? common_sdk_1.ZERO : common_sdk_1.U64_MAX;
    }
    static getSwapDirection(pool, swapTokenMint, swapTokenIsInput) {
        const tokenType = pool_utils_1.PoolUtil.getTokenType(pool, swapTokenMint);
        if (!tokenType) {
            return undefined;
        }
        return tokenType === types_1.TokenType.TokenA === swapTokenIsInput ? types_1.SwapDirection.AtoB : types_1.SwapDirection.BtoA;
    }
    static getTickArrayPublicKeys(tickCurrentIndex, tickSpacing, aToB, programId, whirlpoolAddress) {
        return (0, swap_utils_1.getTickArrayPublicKeysWithStartTickIndex)(tickCurrentIndex, tickSpacing, aToB, programId, whirlpoolAddress).map((p)=>p.pubkey);
    }
    static getFallbackTickArrayPublicKey(tickArrays, tickSpacing, aToB, programId, whirlpoolAddress) {
        try {
            const fallbackStartTickIndex = __1.TickUtil.getStartTickIndex(tickArrays[0].startTickIndex, tickSpacing, aToB ? 1 : -1);
            const pda = pda_utils_1.PDAUtil.getTickArray(programId, whirlpoolAddress, fallbackStartTickIndex);
            return pda.publicKey;
        } catch  {
            return undefined;
        }
    }
    static async getTickArrays(tickCurrentIndex, tickSpacing, aToB, programId, whirlpoolAddress, fetcher, opts) {
        const data = await this.getBatchTickArrays(programId, fetcher, [
            {
                tickCurrentIndex,
                tickSpacing,
                aToB,
                whirlpoolAddress
            }
        ], opts);
        return data[0];
    }
    static async getBatchTickArrays(programId, fetcher, tickArrayRequests, opts) {
        let addresses = [];
        let requestToIndices = [];
        for(let i = 0; i < tickArrayRequests.length; i++){
            const { tickCurrentIndex, tickSpacing, aToB, whirlpoolAddress } = tickArrayRequests[i];
            const requestAddresses = (0, swap_utils_1.getTickArrayPublicKeysWithStartTickIndex)(tickCurrentIndex, tickSpacing, aToB, programId, whirlpoolAddress);
            requestToIndices.push([
                addresses.length,
                addresses.length + requestAddresses.length
            ]);
            addresses.push(...requestAddresses);
        }
        const data = await fetcher.getTickArrays(addresses.map((a)=>a.pubkey), opts);
        return requestToIndices.map((indices)=>{
            const [start, end] = indices;
            const addressSlice = addresses.slice(start, end);
            const dataSlice = data.slice(start, end);
            return addressSlice.map((addr, index)=>({
                    address: addr.pubkey,
                    startTickIndex: addr.startTickIndex,
                    data: dataSlice[index]
                }));
        });
    }
    static interpolateUninitializedTickArrays(whirlpoolAddress, tickArrays) {
        return tickArrays.map((tickArray)=>({
                address: tickArray.address,
                startTickIndex: tickArray.startTickIndex,
                data: tickArray.data ?? (0, swap_utils_1.buildZeroedTickArray)(whirlpoolAddress, tickArray.startTickIndex)
            }));
    }
    static calculateSwapAmountsFromQuote(amount, estAmountIn, estAmountOut, slippageTolerance, amountSpecifiedIsInput) {
        if (amountSpecifiedIsInput) {
            return {
                amount,
                otherAmountThreshold: (0, token_math_1.adjustForSlippage)(estAmountOut, slippageTolerance, false)
            };
        } else {
            return {
                amount,
                otherAmountThreshold: (0, token_math_1.adjustForSlippage)(estAmountIn, slippageTolerance, true)
            };
        }
    }
    static getSwapParamsFromQuote(quote, ctx, whirlpool, inputTokenAssociatedAddress, outputTokenAssociatedAddress, wallet) {
        const data = whirlpool.getData();
        return this.getSwapParamsFromQuoteKeys(quote, ctx, whirlpool.getAddress(), data.tokenVaultA, data.tokenVaultB, inputTokenAssociatedAddress, outputTokenAssociatedAddress, wallet);
    }
    static getSwapParamsFromQuoteKeys(quote, ctx, whirlpool, tokenVaultA, tokenVaultB, inputTokenAssociatedAddress, outputTokenAssociatedAddress, wallet) {
        const aToB = quote.aToB;
        const [inputTokenATA, outputTokenATA] = common_sdk_1.AddressUtil.toPubKeys([
            inputTokenAssociatedAddress,
            outputTokenAssociatedAddress
        ]);
        const oraclePda = pda_utils_1.PDAUtil.getOracle(ctx.program.programId, whirlpool);
        const params = {
            whirlpool,
            tokenOwnerAccountA: aToB ? inputTokenATA : outputTokenATA,
            tokenOwnerAccountB: aToB ? outputTokenATA : inputTokenATA,
            tokenVaultA,
            tokenVaultB,
            oracle: oraclePda.publicKey,
            tokenAuthority: wallet,
            ...quote
        };
        return params;
    }
}
exports.SwapUtils = SwapUtils; //# sourceMappingURL=swap-utils.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TokenExtensionUtil = exports.NO_TOKEN_EXTENSION_CONTEXT = void 0;
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const defaultTokenMintWithProgram = {
    address: web3_js_1.PublicKey.default,
    decimals: 0,
    freezeAuthority: null,
    mintAuthority: null,
    isInitialized: true,
    supply: 0n,
    tlvData: Buffer.from([]),
    tokenProgram: spl_token_1.TOKEN_PROGRAM_ID
};
exports.NO_TOKEN_EXTENSION_CONTEXT = {
    currentEpoch: 0,
    tokenMintWithProgramA: defaultTokenMintWithProgram,
    tokenMintWithProgramB: defaultTokenMintWithProgram,
    rewardTokenMintsWithProgram: [
        defaultTokenMintWithProgram,
        defaultTokenMintWithProgram,
        defaultTokenMintWithProgram
    ]
};
class TokenExtensionUtil {
    static calculateTransferFeeIncludedAmount(transferFeeExcludedAmount, tokenInfo, currentEpoch) {
        const config = (0, spl_token_1.getTransferFeeConfig)(tokenInfo);
        if (config === null) {
            return {
                amount: transferFeeExcludedAmount,
                fee: common_sdk_1.ZERO
            };
        }
        const transferFee = (0, spl_token_1.getEpochFee)(config, BigInt(currentEpoch));
        return calculateTransferFeeIncludedAmount(transferFee, transferFeeExcludedAmount);
    }
    static calculateTransferFeeExcludedAmount(transferFeeIncludedAmount, tokenInfo, currentEpoch) {
        const config = (0, spl_token_1.getTransferFeeConfig)(tokenInfo);
        if (config === null) {
            return {
                amount: transferFeeIncludedAmount,
                fee: common_sdk_1.ZERO
            };
        }
        const transferFee = (0, spl_token_1.getEpochFee)(config, BigInt(currentEpoch));
        return calculateTransferFeeExcludedAmount(transferFee, transferFeeIncludedAmount);
    }
    static async buildTokenExtensionContext(fetcher, whirlpoolData, opts) {
        const mintA = whirlpoolData.tokenMintA;
        const mintB = whirlpoolData.tokenMintB;
        const rewards = whirlpoolData.rewardInfos;
        const [tokenMintWithProgram, currentEpoch] = await Promise.all([
            fetcher.getMintInfos([
                mintA,
                mintB,
                ...rewards.filter((r)=>__1.PoolUtil.isRewardInitialized(r)).map((r)=>r.mint)
            ], opts),
            fetcher.getEpoch()
        ]);
        const get = (mint)=>tokenMintWithProgram.get(mint.toBase58());
        return {
            tokenMintWithProgramA: get(whirlpoolData.tokenMintA),
            tokenMintWithProgramB: get(whirlpoolData.tokenMintB),
            rewardTokenMintsWithProgram: [
                __1.PoolUtil.isRewardInitialized(rewards[0]) ? get(rewards[0].mint) : null,
                __1.PoolUtil.isRewardInitialized(rewards[1]) ? get(rewards[1].mint) : null,
                __1.PoolUtil.isRewardInitialized(rewards[2]) ? get(rewards[2].mint) : null
            ],
            currentEpoch
        };
    }
    static async buildTokenExtensionContextForPool(fetcher, tokenMintA, tokenMintB, opts) {
        const [tokenMintWithProgram, currentEpoch] = await Promise.all([
            fetcher.getMintInfos([
                tokenMintA,
                tokenMintB
            ], opts),
            fetcher.getEpoch()
        ]);
        const get = (mint)=>tokenMintWithProgram.get(mint.toBase58());
        return {
            tokenMintWithProgramA: get(tokenMintA),
            tokenMintWithProgramB: get(tokenMintB),
            currentEpoch
        };
    }
    static async getExtraAccountMetasForTransferHook(connection, tokenMintWithProgram, source, destination, owner) {
        const transferHook = (0, spl_token_1.getTransferHook)(tokenMintWithProgram);
        if (!transferHook) return undefined;
        const instruction = new web3_js_1.TransactionInstruction({
            programId: spl_token_1.TOKEN_2022_PROGRAM_ID,
            keys: [
                {
                    pubkey: source,
                    isSigner: false,
                    isWritable: false
                },
                {
                    pubkey: tokenMintWithProgram.address,
                    isSigner: false,
                    isWritable: false
                },
                {
                    pubkey: destination,
                    isSigner: false,
                    isWritable: false
                },
                {
                    pubkey: owner,
                    isSigner: false,
                    isWritable: false
                },
                {
                    pubkey: owner,
                    isSigner: false,
                    isWritable: false
                }
            ]
        });
        await (0, spl_token_1.addExtraAccountMetasForExecute)(connection, instruction, transferHook.programId, source, tokenMintWithProgram.address, destination, owner, 0n, "confirmed");
        const extraAccountMetas = instruction.keys.slice(5);
        return extraAccountMetas.length > 0 ? extraAccountMetas : undefined;
    }
    static async getExtraAccountMetasForTransferHookForPool(connection, tokenExtensionCtx, sourceA, destinationA, ownerA, sourceB, destinationB, ownerB) {
        const [tokenTransferHookAccountsA, tokenTransferHookAccountsB] = await Promise.all([
            TokenExtensionUtil.getExtraAccountMetasForTransferHook(connection, tokenExtensionCtx.tokenMintWithProgramA, sourceA, destinationA, ownerA),
            TokenExtensionUtil.getExtraAccountMetasForTransferHook(connection, tokenExtensionCtx.tokenMintWithProgramB, sourceB, destinationB, ownerB)
        ]);
        return {
            tokenTransferHookAccountsA,
            tokenTransferHookAccountsB
        };
    }
    static isV2IxRequiredPool(tokenExtensionCtx) {
        return tokenExtensionCtx.tokenMintWithProgramA.tokenProgram.equals(spl_token_1.TOKEN_2022_PROGRAM_ID) || tokenExtensionCtx.tokenMintWithProgramB.tokenProgram.equals(spl_token_1.TOKEN_2022_PROGRAM_ID);
    }
    static isV2IxRequiredReward(tokenExtensionCtx, rewardIndex) {
        return tokenExtensionCtx.rewardTokenMintsWithProgram[rewardIndex]?.tokenProgram.equals(spl_token_1.TOKEN_2022_PROGRAM_ID) ?? false;
    }
}
exports.TokenExtensionUtil = TokenExtensionUtil;
function ceilDivBN(num, denom) {
    return num.add(denom.subn(1)).div(denom);
}
function calculateTransferFeeIncludedAmount(transferFee, amount) {
    const ONE_IN_BASIS_POINTS = 10_000;
    const maxFeeBN = new bn_js_1.default(transferFee.maximumFee.toString());
    if (transferFee.transferFeeBasisPoints === 0) {
        return {
            amount,
            fee: common_sdk_1.ZERO
        };
    }
    if (amount.isZero()) {
        return {
            amount,
            fee: common_sdk_1.ZERO
        };
    }
    if (transferFee.transferFeeBasisPoints === ONE_IN_BASIS_POINTS) {
        if (amount.add(maxFeeBN).gt(common_sdk_1.U64_MAX)) {
            throw new Error("The total amount and fees overflow");
        }
        return {
            amount: amount.add(maxFeeBN),
            fee: maxFeeBN
        };
    }
    const num = amount.muln(ONE_IN_BASIS_POINTS);
    const denom = new bn_js_1.default(ONE_IN_BASIS_POINTS - transferFee.transferFeeBasisPoints);
    const rawFeeIncludedAmount = ceilDivBN(num, denom);
    const result = rawFeeIncludedAmount.sub(amount).gte(maxFeeBN) ? {
        amount: amount.add(maxFeeBN),
        fee: maxFeeBN
    } : {
        amount: rawFeeIncludedAmount,
        fee: rawFeeIncludedAmount.sub(amount)
    };
    if (result.amount.gt(common_sdk_1.U64_MAX)) {
        throw new Error("The total amount and fees overflow");
    }
    return {
        ...result
    };
}
function calculateTransferFeeExcludedAmount(transferFee, amount) {
    const fee = (0, spl_token_1.calculateFee)(transferFee, BigInt(amount.toString()));
    const feeBN = new bn_js_1.default(fee.toString());
    return {
        amount: amount.sub(feeBN),
        fee: feeBN
    };
} //# sourceMappingURL=token-extension-util.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/graphs/public/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/ix-utils.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/pda-utils.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/pool-utils.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/position-bundle-util.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/price-math.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/swap-utils.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/tick-utils.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/types.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/fetcher-utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getAllWhirlpoolAccountsForConfig = getAllWhirlpoolAccountsForConfig;
exports.getAllPositionAccountsByOwner = getAllPositionAccountsByOwner;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const parsing_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/parsing.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const public_2 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
async function getAllWhirlpoolAccountsForConfig({ connection, programId, configId }) {
    const filters = [
        {
            dataSize: (0, public_1.getAccountSize)(public_1.AccountName.Whirlpool)
        },
        {
            memcmp: public_1.WHIRLPOOL_CODER.memcmp(public_1.AccountName.Whirlpool, common_sdk_1.AddressUtil.toPubKey(configId).toBuffer())
        }
    ];
    const accounts = await connection.getProgramAccounts(common_sdk_1.AddressUtil.toPubKey(programId), {
        filters
    });
    const parsedAccounts = [];
    accounts.forEach(({ pubkey, account })=>{
        const parsedAccount = parsing_1.ParsableWhirlpool.parse(pubkey, account);
        (0, tiny_invariant_1.default)(!!parsedAccount, `could not parse whirlpool: ${pubkey.toBase58()}`);
        parsedAccounts.push([
            common_sdk_1.AddressUtil.toString(pubkey),
            parsedAccount
        ]);
    });
    return new Map(parsedAccounts.map(([address, pool])=>[
            common_sdk_1.AddressUtil.toString(address),
            pool
        ]));
}
async function getAllPositionAccountsByOwner({ ctx, owner, includesPositions = true, includesPositionsWithTokenExtensions = true, includesBundledPositions = false }) {
    const positions = !includesPositions ? new Map() : await findPositions(ctx, owner, spl_token_1.TOKEN_PROGRAM_ID);
    const positionsWithTokenExtensions = !includesPositionsWithTokenExtensions ? new Map() : await findPositions(ctx, owner, spl_token_1.TOKEN_2022_PROGRAM_ID);
    const positionBundles = !includesBundledPositions ? [] : await findBundledPositions(ctx, owner);
    return {
        positions,
        positionsWithTokenExtensions,
        positionBundles
    };
}
async function findPositions(ctx, owner, tokenProgramId) {
    const programId = common_sdk_1.AddressUtil.toPubKey(tokenProgramId);
    const tokenAccounts = await ctx.connection.getTokenAccountsByOwner(common_sdk_1.AddressUtil.toPubKey(owner), {
        programId
    });
    const candidatePubkeys = [];
    tokenAccounts.value.forEach((ta)=>{
        const parsed = (0, spl_token_1.unpackAccount)(ta.pubkey, ta.account, programId);
        if (parsed.amount === 1n) {
            const pda = public_2.PDAUtil.getPosition(ctx.program.programId, parsed.mint);
            candidatePubkeys.push(pda.publicKey);
        }
    });
    const positionData = await ctx.fetcher.getPositions(candidatePubkeys, __1.IGNORE_CACHE);
    return new Map(Array.from(positionData.entries()).filter(([_, v])=>v !== null));
}
async function findBundledPositions(ctx, owner) {
    const tokenAccounts = await ctx.connection.getTokenAccountsByOwner(common_sdk_1.AddressUtil.toPubKey(owner), {
        programId: spl_token_1.TOKEN_PROGRAM_ID
    });
    const candidatePubkeys = [];
    tokenAccounts.value.forEach((ta)=>{
        const parsed = (0, spl_token_1.unpackAccount)(ta.pubkey, ta.account, spl_token_1.TOKEN_PROGRAM_ID);
        if (parsed.amount === 1n) {
            const pda = public_2.PDAUtil.getPositionBundle(ctx.program.programId, parsed.mint);
            candidatePubkeys.push(pda.publicKey);
        }
    });
    const positionBundleData = await ctx.fetcher.getPositionBundles(candidatePubkeys, __1.IGNORE_CACHE);
    const positionBundles = Array.from(positionBundleData.entries()).filter(([_, v])=>v !== null);
    const bundledPositionPubkeys = [];
    positionBundles.forEach(([_, positionBundle])=>{
        const bundleIndexes = public_2.PositionBundleUtil.getOccupiedBundleIndexes(positionBundle);
        bundleIndexes.forEach((bundleIndex)=>{
            const pda = public_2.PDAUtil.getBundledPosition(ctx.program.programId, positionBundle.positionBundleMint, bundleIndex);
            bundledPositionPubkeys.push(pda.publicKey);
        });
    });
    const bundledPositionData = await ctx.fetcher.getPositions(bundledPositionPubkeys, __1.IGNORE_CACHE);
    return positionBundles.map(([positionBundleAddress, positionBundleData])=>{
        const bundleIndexes = public_2.PositionBundleUtil.getOccupiedBundleIndexes(positionBundleData);
        const bundledPositions = new Map(bundleIndexes.map((bundleIndex)=>{
            const pda = public_2.PDAUtil.getBundledPosition(ctx.program.programId, positionBundleData.positionBundleMint, bundleIndex);
            return [
                bundleIndex,
                bundledPositionData.get(common_sdk_1.AddressUtil.toString(pda.publicKey))
            ];
        }).filter(([_, v])=>v !== null));
        return {
            positionBundleAddress,
            positionBundleData,
            bundledPositions
        };
    });
} //# sourceMappingURL=fetcher-utils.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/fetcher-impl.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/fetcher-types.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/fetcher-utils.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/parsing.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/txn-utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.MultipleTransactionBuilderFactoryWithAccountResolver = void 0;
exports.convertListToMap = convertListToMap;
exports.filterNullObjects = filterNullObjects;
exports.checkMergedTransactionSizeIsValid = checkMergedTransactionSizeIsValid;
exports.contextOptionsToBuilderOptions = contextOptionsToBuilderOptions;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
function convertListToMap(fetchedData, addresses) {
    const result = {};
    fetchedData.forEach((data, index)=>{
        if (data) {
            const addr = addresses[index];
            result[addr] = data;
        }
    });
    return result;
}
function filterNullObjects(firstArray, secondArray) {
    const filteredFirstArray = [];
    const filteredSecondArray = [];
    firstArray.forEach((item, idx)=>{
        if (item !== null) {
            filteredFirstArray.push(item);
            filteredSecondArray.push(secondArray[idx]);
        }
    });
    return [
        filteredFirstArray,
        filteredSecondArray
    ];
}
async function checkMergedTransactionSizeIsValid(ctx, builders, latestBlockhash) {
    const merged = new common_sdk_1.TransactionBuilder(ctx.connection, ctx.wallet, ctx.txBuilderOpts);
    builders.forEach((builder)=>merged.addInstruction(builder.compressIx(true)));
    try {
        await merged.txnSize({
            latestBlockhash
        });
        return true;
    } catch  {
        return false;
    }
}
function contextOptionsToBuilderOptions(opts) {
    return {
        defaultBuildOption: {
            ...common_sdk_1.defaultTransactionBuilderOptions.defaultBuildOption,
            ...opts.userDefaultBuildOptions
        },
        defaultSendOption: {
            ...common_sdk_1.defaultTransactionBuilderOptions.defaultSendOption,
            ...opts.userDefaultSendOptions
        },
        defaultConfirmationCommitment: opts.userDefaultConfirmCommitment ?? common_sdk_1.defaultTransactionBuilderOptions.defaultConfirmationCommitment
    };
}
class MultipleTransactionBuilderFactoryWithAccountResolver {
    ctx;
    resolvedAtas;
    tokenOwner;
    payer;
    txBuilders = [];
    pendingTxBuilder = null;
    touchedMints = null;
    accountExemption = null;
    constructor(ctx, resolvedAtas, tokenOwner = ctx.wallet.publicKey, payer = tokenOwner){
        this.ctx = ctx;
        this.resolvedAtas = resolvedAtas;
        this.tokenOwner = tokenOwner;
        this.payer = payer;
    }
    async addInstructions(generator) {
        if (this.accountExemption === null) {
            this.accountExemption = await this.ctx.fetcher.getAccountRentExempt();
        }
        for(let iter = 0; iter < 2; iter++){
            if (!this.pendingTxBuilder || !this.touchedMints) {
                this.pendingTxBuilder = new common_sdk_1.TransactionBuilder(this.ctx.connection, this.ctx.wallet, this.ctx.txBuilderOpts);
                this.touchedMints = new Set();
                this.resolvedAtas[spl_token_1.NATIVE_MINT.toBase58()] = common_sdk_1.TokenUtil.createWrappedNativeAccountInstruction(this.tokenOwner, common_sdk_1.ZERO, this.accountExemption, this.payer, this.tokenOwner, this.ctx.accountResolverOpts.createWrappedSolAccountMethod);
            }
            const newTxBuilder = new common_sdk_1.TransactionBuilder(this.ctx.connection, this.ctx.wallet, this.ctx.txBuilderOpts);
            const resolve = (mint)=>{
                if (!this.touchedMints.has(mint)) {
                    newTxBuilder.addInstruction(this.resolvedAtas[mint]);
                    this.touchedMints.add(mint);
                }
                return this.resolvedAtas[mint].address;
            };
            const ixs = await generator(resolve.bind(this));
            newTxBuilder.addInstructions(ixs);
            const mergeable = await checkMergedTransactionSizeIsValid(this.ctx, [
                this.pendingTxBuilder,
                newTxBuilder
            ], common_sdk_1.MEASUREMENT_BLOCKHASH);
            if (mergeable) {
                this.pendingTxBuilder.addInstruction(newTxBuilder.compressIx(false));
                break;
            } else {
                if (iter !== 0) {
                    throw new Error(`instruction is too large.`);
                }
                this.txBuilders.push(this.pendingTxBuilder);
                this.pendingTxBuilder = null;
                this.touchedMints = null;
            }
        }
    }
    build() {
        return this.pendingTxBuilder ? [
            ...this.txBuilders,
            this.pendingTxBuilder
        ] : [
            ...this.txBuilders
        ];
    }
}
exports.MultipleTransactionBuilderFactoryWithAccountResolver = MultipleTransactionBuilderFactoryWithAccountResolver; //# sourceMappingURL=txn-utils.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/context.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WhirlpoolContext = void 0;
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const whirlpool_json_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/artifacts/whirlpool.json (json)"));
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/index.js [app-route] (ecmascript)");
const txn_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/txn-utils.js [app-route] (ecmascript)");
const DEFAULT_ACCOUNT_RESOLVER_OPTS = {
    createWrappedSolAccountMethod: "keypair",
    allowPDAOwnerAddress: false
};
class WhirlpoolContext {
    connection;
    wallet;
    program;
    provider;
    fetcher;
    lookupTableFetcher;
    opts;
    txBuilderOpts;
    accountResolverOpts;
    static from(connection, wallet, programId, fetcher = (0, public_1.buildDefaultAccountFetcher)(connection), lookupTableFetcher, opts = {}) {
        const anchorProvider = new anchor_1.AnchorProvider(connection, wallet, {
            commitment: opts.userDefaultConfirmCommitment || "confirmed",
            preflightCommitment: opts.userDefaultConfirmCommitment || "confirmed"
        });
        const program = new anchor_1.Program(whirlpool_json_1.default, programId, anchorProvider);
        return new WhirlpoolContext(anchorProvider, anchorProvider.wallet, program, fetcher, lookupTableFetcher, opts);
    }
    static fromWorkspace(provider, program, fetcher = (0, public_1.buildDefaultAccountFetcher)(provider.connection), lookupTableFetcher, opts = {}) {
        return new WhirlpoolContext(provider, provider.wallet, program, fetcher, lookupTableFetcher, opts);
    }
    static withProvider(provider, programId, fetcher = (0, public_1.buildDefaultAccountFetcher)(provider.connection), lookupTableFetcher, opts = {}) {
        const program = new anchor_1.Program(whirlpool_json_1.default, programId, provider);
        return new WhirlpoolContext(provider, provider.wallet, program, fetcher, lookupTableFetcher, opts);
    }
    constructor(provider, wallet, program, fetcher, lookupTableFetcher, opts = {}){
        this.connection = provider.connection;
        this.wallet = wallet;
        this.program = program;
        this.provider = provider;
        this.fetcher = fetcher;
        this.lookupTableFetcher = lookupTableFetcher;
        this.opts = opts;
        this.txBuilderOpts = (0, txn_utils_1.contextOptionsToBuilderOptions)(this.opts);
        this.accountResolverOpts = opts.accountResolverOptions ?? DEFAULT_ACCOUNT_RESOLVER_OPTS;
    }
}
exports.WhirlpoolContext = WhirlpoolContext; //# sourceMappingURL=context.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/close-bundled-position-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.closeBundledPositionIx = closeBundledPositionIx;
function closeBundledPositionIx(program, params) {
    const { bundledPosition, positionBundle, positionBundleTokenAccount, positionBundleAuthority, bundleIndex, receiver } = params;
    const ix = program.instruction.closeBundledPosition(bundleIndex, {
        accounts: {
            bundledPosition,
            positionBundle,
            positionBundleTokenAccount,
            positionBundleAuthority,
            receiver
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=close-bundled-position-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/close-position-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.closePositionIx = closePositionIx;
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
function closePositionIx(program, params) {
    const { positionAuthority, receiver: receiver, position: position, positionMint: positionMint, positionTokenAccount } = params;
    const ix = program.instruction.closePosition({
        accounts: {
            positionAuthority,
            receiver,
            position,
            positionMint,
            positionTokenAccount,
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=close-position-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/close-position-with-token-extensions-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.closePositionWithTokenExtensionsIx = closePositionWithTokenExtensionsIx;
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
function closePositionWithTokenExtensionsIx(program, params) {
    const ix = program.instruction.closePositionWithTokenExtensions({
        accounts: {
            ...params,
            token2022Program: spl_token_1.TOKEN_2022_PROGRAM_ID
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=close-position-with-token-extensions-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/collect-fees-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.collectFeesIx = collectFeesIx;
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
function collectFeesIx(program, params) {
    const { whirlpool, positionAuthority, position, positionTokenAccount, tokenOwnerAccountA, tokenOwnerAccountB, tokenVaultA, tokenVaultB } = params;
    const ix = program.instruction.collectFees({
        accounts: {
            whirlpool,
            positionAuthority,
            position,
            positionTokenAccount,
            tokenOwnerAccountA,
            tokenOwnerAccountB,
            tokenVaultA,
            tokenVaultB,
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=collect-fees-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/collect-protocol-fees-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.collectProtocolFeesIx = collectProtocolFeesIx;
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
function collectProtocolFeesIx(program, params) {
    const { whirlpoolsConfig, whirlpool, collectProtocolFeesAuthority, tokenVaultA, tokenVaultB, tokenOwnerAccountA: tokenDestinationA, tokenOwnerAccountB: tokenDestinationB } = params;
    const ix = program.instruction.collectProtocolFees({
        accounts: {
            whirlpoolsConfig,
            whirlpool,
            collectProtocolFeesAuthority,
            tokenVaultA,
            tokenVaultB,
            tokenDestinationA,
            tokenDestinationB,
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=collect-protocol-fees-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/collect-reward-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.collectRewardIx = collectRewardIx;
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
function collectRewardIx(program, params) {
    const { whirlpool, positionAuthority, position, positionTokenAccount, rewardOwnerAccount, rewardVault, rewardIndex } = params;
    const ix = program.instruction.collectReward(rewardIndex, {
        accounts: {
            whirlpool,
            positionAuthority,
            position,
            positionTokenAccount,
            rewardOwnerAccount,
            rewardVault,
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=collect-reward-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WhirlpoolIx = void 0;
const ix = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/index.js [app-route] (ecmascript)"));
class WhirlpoolIx {
    static initializeConfigIx(program, params) {
        return ix.initializeConfigIx(program, params);
    }
    static initializeFeeTierIx(program, params) {
        return ix.initializeFeeTierIx(program, params);
    }
    static initializePoolIx(program, params) {
        return ix.initializePoolIx(program, params);
    }
    static initializeRewardIx(program, params) {
        return ix.initializeRewardIx(program, params);
    }
    static initTickArrayIx(program, params) {
        return ix.initTickArrayIx(program, params);
    }
    static openPositionIx(program, params) {
        return ix.openPositionIx(program, params);
    }
    static openPositionWithMetadataIx(program, params) {
        return ix.openPositionWithMetadataIx(program, params);
    }
    static increaseLiquidityIx(program, params) {
        return ix.increaseLiquidityIx(program, params);
    }
    static decreaseLiquidityIx(program, params) {
        return ix.decreaseLiquidityIx(program, params);
    }
    static closePositionIx(program, params) {
        return ix.closePositionIx(program, params);
    }
    static swapIx(program, params) {
        return ix.swapIx(program, params);
    }
    static twoHopSwapIx(program, params) {
        return ix.twoHopSwapIx(program, params);
    }
    static updateFeesAndRewardsIx(program, params) {
        return ix.updateFeesAndRewardsIx(program, params);
    }
    static collectFeesIx(program, params) {
        return ix.collectFeesIx(program, params);
    }
    static collectProtocolFeesIx(program, params) {
        return ix.collectProtocolFeesIx(program, params);
    }
    static collectRewardIx(program, params) {
        return ix.collectRewardIx(program, params);
    }
    static setCollectProtocolFeesAuthorityIx(program, params) {
        return ix.setCollectProtocolFeesAuthorityIx(program, params);
    }
    static setDefaultFeeRateIx(program, params) {
        return ix.setDefaultFeeRateIx(program, params);
    }
    static setDefaultProtocolFeeRateIx(program, params) {
        return ix.setDefaultProtocolFeeRateIx(program, params);
    }
    static setFeeAuthorityIx(program, params) {
        return ix.setFeeAuthorityIx(program, params);
    }
    static setFeeRateIx(program, params) {
        return ix.setFeeRateIx(program, params);
    }
    static setProtocolFeeRateIx(program, params) {
        return ix.setProtocolFeeRateIx(program, params);
    }
    static setRewardAuthorityBySuperAuthorityIx(program, params) {
        return ix.setRewardAuthorityBySuperAuthorityIx(program, params);
    }
    static setRewardAuthorityIx(program, params) {
        return ix.setRewardAuthorityIx(program, params);
    }
    static setRewardEmissionsIx(program, params) {
        return ix.setRewardEmissionsIx(program, params);
    }
    static setRewardEmissionsSuperAuthorityIx(program, params) {
        return ix.setRewardEmissionsSuperAuthorityIx(program, params);
    }
    static initializePositionBundleIx(program, params) {
        return ix.initializePositionBundleIx(program, params);
    }
    static initializePositionBundleWithMetadataIx(program, params) {
        return ix.initializePositionBundleWithMetadataIx(program, params);
    }
    static deletePositionBundleIx(program, params) {
        return ix.deletePositionBundleIx(program, params);
    }
    static openBundledPositionIx(program, params) {
        return ix.openBundledPositionIx(program, params);
    }
    static closeBundledPositionIx(program, params) {
        return ix.closeBundledPositionIx(program, params);
    }
    static openPositionWithTokenExtensionsIx(program, params) {
        return ix.openPositionWithTokenExtensionsIx(program, params);
    }
    static closePositionWithTokenExtensionsIx(program, params) {
        return ix.closePositionWithTokenExtensionsIx(program, params);
    }
    static collectFeesV2Ix(program, params) {
        return ix.collectFeesV2Ix(program, params);
    }
    static collectProtocolFeesV2Ix(program, params) {
        return ix.collectProtocolFeesV2Ix(program, params);
    }
    static collectRewardV2Ix(program, params) {
        return ix.collectRewardV2Ix(program, params);
    }
    static decreaseLiquidityV2Ix(program, params) {
        return ix.decreaseLiquidityV2Ix(program, params);
    }
    static increaseLiquidityV2Ix(program, params) {
        return ix.increaseLiquidityV2Ix(program, params);
    }
    static initializePoolV2Ix(program, params) {
        return ix.initializePoolV2Ix(program, params);
    }
    static initializeRewardV2Ix(program, params) {
        return ix.initializeRewardV2Ix(program, params);
    }
    static setRewardEmissionsV2Ix(program, params) {
        return ix.setRewardEmissionsV2Ix(program, params);
    }
    static swapV2Ix(program, params) {
        return ix.swapV2Ix(program, params);
    }
    static twoHopSwapV2Ix(program, params) {
        return ix.twoHopSwapV2Ix(program, params);
    }
    static initializeConfigExtensionIx(program, params) {
        return ix.initializeConfigExtensionIx(program, params);
    }
    static setConfigExtensionAuthorityIx(program, params) {
        return ix.setConfigExtensionAuthorityIx(program, params);
    }
    static setTokenBadgeAuthorityIx(program, params) {
        return ix.setTokenBadgeAuthorityIx(program, params);
    }
    static initializeTokenBadgeIx(program, params) {
        return ix.initializeTokenBadgeIx(program, params);
    }
    static deleteTokenBadgeIx(program, params) {
        return ix.deleteTokenBadgeIx(program, params);
    }
}
exports.WhirlpoolIx = WhirlpoolIx; //# sourceMappingURL=ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/whirlpool-ata-utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TokenMintTypes = void 0;
exports.getTokenMintsFromWhirlpools = getTokenMintsFromWhirlpools;
exports.resolveAtaForMints = resolveAtaForMints;
exports.addNativeMintHandlingIx = addNativeMintHandlingIx;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const txn_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/txn-utils.js [app-route] (ecmascript)");
var TokenMintTypes;
(function(TokenMintTypes) {
    TokenMintTypes["ALL"] = "ALL";
    TokenMintTypes["POOL_ONLY"] = "POOL_ONLY";
    TokenMintTypes["REWARD_ONLY"] = "REWARDS_ONLY";
})(TokenMintTypes || (exports.TokenMintTypes = TokenMintTypes = {}));
function getTokenMintsFromWhirlpools(whirlpoolDatas, mintTypes = TokenMintTypes.ALL) {
    let hasNativeMint = false;
    const mints = Array.from(whirlpoolDatas.reduce((accu, whirlpoolData)=>{
        if (whirlpoolData) {
            if (mintTypes === TokenMintTypes.ALL || mintTypes === TokenMintTypes.POOL_ONLY) {
                const { tokenMintA, tokenMintB } = whirlpoolData;
                if (!common_sdk_1.TokenUtil.isNativeMint(tokenMintA)) {
                    accu.add(tokenMintA.toBase58());
                } else {
                    hasNativeMint = true;
                }
                if (!common_sdk_1.TokenUtil.isNativeMint(tokenMintB)) {
                    accu.add(tokenMintB.toBase58());
                } else {
                    hasNativeMint = true;
                }
            }
            if (mintTypes === TokenMintTypes.ALL || mintTypes === TokenMintTypes.REWARD_ONLY) {
                const rewardInfos = whirlpoolData.rewardInfos;
                rewardInfos.forEach((reward)=>{
                    if (common_sdk_1.TokenUtil.isNativeMint(reward.mint)) {
                        hasNativeMint = true;
                    }
                    if (__1.PoolUtil.isRewardInitialized(reward)) {
                        accu.add(reward.mint.toBase58());
                    }
                });
            }
        }
        return accu;
    }, new Set())).map((mint)=>new web3_js_1.PublicKey(mint));
    return {
        mintMap: mints,
        hasNativeMint
    };
}
async function resolveAtaForMints(ctx, params) {
    const { mints, receiver, payer, accountExemption } = params;
    const receiverKey = receiver ?? ctx.wallet.publicKey;
    const payerKey = payer ?? ctx.wallet.publicKey;
    const resolvedAtaResults = await (0, common_sdk_1.resolveOrCreateATAs)(ctx.connection, receiverKey, mints.map((tokenMint)=>{
        return {
            tokenMint
        };
    }), async ()=>accountExemption, payerKey, undefined, ctx.accountResolverOpts.allowPDAOwnerAddress, ctx.accountResolverOpts.createWrappedSolAccountMethod);
    const { resolveAtaIxs, resolvedAtas } = resolvedAtaResults.reduce((accu, curr)=>{
        const { address, ...ix } = curr;
        accu.resolvedAtas.push(address);
        if (ix.instructions.length) {
            accu.resolveAtaIxs.push(ix);
        }
        return accu;
    }, {
        resolvedAtas: [],
        resolveAtaIxs: []
    });
    const affliatedTokenAtaMap = (0, txn_utils_1.convertListToMap)(resolvedAtas, mints.map((mint)=>mint.toBase58()));
    return {
        ataTokenAddresses: affliatedTokenAtaMap,
        resolveAtaIxs
    };
}
function addNativeMintHandlingIx(txBuilder, affliatedTokenAtaMap, destinationWallet, accountExemption, createAccountMethod) {
    let { address: wSOLAta, ...resolveWSolIx } = common_sdk_1.TokenUtil.createWrappedNativeAccountInstruction(destinationWallet, common_sdk_1.ZERO, accountExemption, undefined, undefined, createAccountMethod);
    affliatedTokenAtaMap[spl_token_1.NATIVE_MINT.toBase58()] = wSOLAta;
    txBuilder.prependInstruction(resolveWSolIx);
} //# sourceMappingURL=whirlpool-ata-utils.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/update-fees-and-rewards-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.updateFeesAndRewardsIx = updateFeesAndRewardsIx;
function updateFeesAndRewardsIx(program, params) {
    const { whirlpool, position, tickArrayLower, tickArrayUpper } = params;
    const ix = program.instruction.updateFeesAndRewards({
        accounts: {
            whirlpool,
            position,
            tickArrayLower,
            tickArrayUpper
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=update-fees-and-rewards-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/composites/collect-all-txn.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.collectAllForPositionAddressesTxns = collectAllForPositionAddressesTxns;
exports.collectAllForPositionsTxns = collectAllForPositionsTxns;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const ix_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/ix.js [app-route] (ecmascript)");
const fetcher_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const txn_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/txn-utils.js [app-route] (ecmascript)");
const whirlpool_ata_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/whirlpool-ata-utils.js [app-route] (ecmascript)");
const update_fees_and_rewards_ix_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/update-fees-and-rewards-ix.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
async function collectAllForPositionAddressesTxns(ctx, params, opts = fetcher_1.PREFER_CACHE) {
    const { positions, ...rest } = params;
    const fetchedPositions = await ctx.fetcher.getPositions(positions, opts);
    const positionMap = {};
    fetchedPositions.forEach((pos, addr)=>{
        if (pos) {
            positionMap[addr] = pos;
        }
    });
    return collectAllForPositionsTxns(ctx, {
        positions: positionMap,
        ...rest
    });
}
async function collectAllForPositionsTxns(ctx, params) {
    const { positions, receiver, positionAuthority, positionOwner, payer } = params;
    const receiverKey = receiver ?? ctx.wallet.publicKey;
    const positionAuthorityKey = positionAuthority ?? ctx.wallet.publicKey;
    const positionOwnerKey = positionOwner ?? ctx.wallet.publicKey;
    const payerKey = payer ?? ctx.wallet.publicKey;
    const positionList = Object.entries(positions);
    if (positionList.length === 0) {
        return [];
    }
    const whirlpoolAddrs = positionList.map(([, pos])=>pos.whirlpool.toBase58());
    const whirlpools = await ctx.fetcher.getPools(whirlpoolAddrs, fetcher_1.PREFER_CACHE);
    const allMints = (0, whirlpool_ata_utils_1.getTokenMintsFromWhirlpools)(Array.from(whirlpools.values()));
    const accountExemption = await ctx.fetcher.getAccountRentExempt();
    const positionMintAddrs = positionList.map(([, pos])=>pos.positionMint);
    const positionMintInfos = await ctx.fetcher.getMintInfos(positionMintAddrs);
    await ctx.fetcher.getMintInfos(allMints.mintMap);
    const resolvedAtas = (0, txn_utils_1.convertListToMap)(await (0, common_sdk_1.resolveOrCreateATAs)(ctx.connection, receiverKey, allMints.mintMap.map((tokenMint)=>({
            tokenMint
        })), async ()=>accountExemption, payerKey, true, ctx.accountResolverOpts.allowPDAOwnerAddress, ctx.accountResolverOpts.createWrappedSolAccountMethod), allMints.mintMap.map((mint)=>mint.toBase58()));
    const latestBlockhash = await ctx.connection.getLatestBlockhash();
    const txBuilders = [];
    const collectionTasks = [];
    positionList.forEach(([positionAddr, position])=>{
        const whirlpool = whirlpools.get(position.whirlpool.toBase58());
        if (!whirlpool) {
            throw new Error(`Unable to process positionMint ${position.positionMint.toBase58()} - unable to derive whirlpool ${position.whirlpool.toBase58()}`);
        }
        const positionMintInfo = positionMintInfos.get(position.positionMint.toBase58());
        if (!positionMintInfo) {
            throw new Error(`Unable to process positionMint ${position.positionMint.toBase58()} - missing mint info`);
        }
        collectionTasks.push({
            collectionType: "fee",
            positionAddr,
            position,
            whirlpool,
            positionMintTokenProgramId: positionMintInfo.tokenProgram
        });
        whirlpool.rewardInfos.forEach((rewardInfo, index)=>{
            if (public_1.PoolUtil.isRewardInitialized(rewardInfo)) {
                collectionTasks.push({
                    collectionType: "reward",
                    rewardIndex: index,
                    positionAddr,
                    position,
                    whirlpool,
                    positionMintTokenProgramId: positionMintInfo.tokenProgram
                });
            }
        });
    });
    let cursor = 0;
    let pendingTxBuilder = null;
    let touchedMints = null;
    let lastUpdatedPosition = null;
    let reattempt = false;
    while(cursor < collectionTasks.length){
        if (!pendingTxBuilder || !touchedMints) {
            pendingTxBuilder = new common_sdk_1.TransactionBuilder(ctx.connection, ctx.wallet, ctx.txBuilderOpts);
            touchedMints = new Set();
            resolvedAtas[spl_token_1.NATIVE_MINT.toBase58()] = common_sdk_1.TokenUtil.createWrappedNativeAccountInstruction(receiverKey, common_sdk_1.ZERO, accountExemption, undefined, undefined, ctx.accountResolverOpts.createWrappedSolAccountMethod);
        }
        const task = collectionTasks[cursor];
        const alreadyUpdated = lastUpdatedPosition === task.positionAddr;
        const collectIxForPosition = await constructCollectIxForPosition(ctx, task, alreadyUpdated, positionOwnerKey, positionAuthorityKey, resolvedAtas, touchedMints);
        const positionTxBuilder = new common_sdk_1.TransactionBuilder(ctx.connection, ctx.wallet, ctx.txBuilderOpts);
        positionTxBuilder.addInstructions(collectIxForPosition);
        const mergeable = await (0, txn_utils_1.checkMergedTransactionSizeIsValid)(ctx, [
            pendingTxBuilder,
            positionTxBuilder
        ], latestBlockhash);
        if (mergeable) {
            pendingTxBuilder.addInstruction(positionTxBuilder.compressIx(false));
            cursor += 1;
            lastUpdatedPosition = task.positionAddr;
            reattempt = false;
        } else {
            if (reattempt) {
                throw new Error(`Unable to fit collection ix for ${task.position.positionMint.toBase58()} in a Transaction.`);
            }
            txBuilders.push(pendingTxBuilder);
            pendingTxBuilder = null;
            touchedMints = null;
            lastUpdatedPosition = null;
            reattempt = true;
        }
    }
    if (pendingTxBuilder) {
        txBuilders.push(pendingTxBuilder);
    }
    return txBuilders;
}
const constructCollectIxForPosition = async (ctx, task, alreadyUpdated, positionOwner, positionAuthority, resolvedAtas, touchedMints)=>{
    const ixForPosition = [];
    const { whirlpool: whirlpoolKey, liquidity, tickLowerIndex, tickUpperIndex, positionMint } = task.position;
    const positionMintTokenProgramId = task.positionMintTokenProgramId;
    const whirlpool = task.whirlpool;
    const { tickSpacing } = whirlpool;
    const mintA = whirlpool.tokenMintA.toBase58();
    const mintB = whirlpool.tokenMintB.toBase58();
    const tokenExtensionCtx = await token_extension_util_1.TokenExtensionUtil.buildTokenExtensionContext(ctx.fetcher, whirlpool, fetcher_1.PREFER_CACHE);
    const positionTokenAccount = (0, spl_token_1.getAssociatedTokenAddressSync)(positionMint, positionOwner, ctx.accountResolverOpts.allowPDAOwnerAddress, positionMintTokenProgramId);
    if (!liquidity.eq(common_sdk_1.ZERO) && !alreadyUpdated) {
        ixForPosition.push((0, update_fees_and_rewards_ix_1.updateFeesAndRewardsIx)(ctx.program, {
            position: new web3_js_1.PublicKey(task.positionAddr),
            whirlpool: whirlpoolKey,
            tickArrayLower: public_1.PDAUtil.getTickArray(ctx.program.programId, whirlpoolKey, public_1.TickUtil.getStartTickIndex(tickLowerIndex, tickSpacing)).publicKey,
            tickArrayUpper: public_1.PDAUtil.getTickArray(ctx.program.programId, whirlpoolKey, public_1.TickUtil.getStartTickIndex(tickUpperIndex, tickSpacing)).publicKey
        }));
    }
    if (task.collectionType === "fee") {
        if (!touchedMints.has(mintA)) {
            ixForPosition.push(resolvedAtas[mintA]);
            touchedMints.add(mintA);
        }
        if (!touchedMints.has(mintB)) {
            ixForPosition.push(resolvedAtas[mintB]);
            touchedMints.add(mintB);
        }
        const collectFeesBaseParams = {
            whirlpool: whirlpoolKey,
            position: new web3_js_1.PublicKey(task.positionAddr),
            positionAuthority,
            positionTokenAccount,
            tokenOwnerAccountA: resolvedAtas[mintA].address,
            tokenOwnerAccountB: resolvedAtas[mintB].address,
            tokenVaultA: whirlpool.tokenVaultA,
            tokenVaultB: whirlpool.tokenVaultB
        };
        ixForPosition.push(!token_extension_util_1.TokenExtensionUtil.isV2IxRequiredPool(tokenExtensionCtx) ? ix_1.WhirlpoolIx.collectFeesIx(ctx.program, collectFeesBaseParams) : ix_1.WhirlpoolIx.collectFeesV2Ix(ctx.program, {
            ...collectFeesBaseParams,
            tokenMintA: tokenExtensionCtx.tokenMintWithProgramA.address,
            tokenMintB: tokenExtensionCtx.tokenMintWithProgramB.address,
            tokenProgramA: tokenExtensionCtx.tokenMintWithProgramA.tokenProgram,
            tokenProgramB: tokenExtensionCtx.tokenMintWithProgramB.tokenProgram,
            ...await token_extension_util_1.TokenExtensionUtil.getExtraAccountMetasForTransferHookForPool(ctx.connection, tokenExtensionCtx, collectFeesBaseParams.tokenVaultA, collectFeesBaseParams.tokenOwnerAccountA, collectFeesBaseParams.whirlpool, collectFeesBaseParams.tokenVaultB, collectFeesBaseParams.tokenOwnerAccountB, collectFeesBaseParams.whirlpool)
        }));
    } else {
        const index = task.rewardIndex;
        const rewardInfo = whirlpool.rewardInfos[index];
        const mintReward = rewardInfo.mint.toBase58();
        if (!touchedMints.has(mintReward)) {
            ixForPosition.push(resolvedAtas[mintReward]);
            touchedMints.add(mintReward);
        }
        const collectRewardBaseParams = {
            whirlpool: whirlpoolKey,
            position: new web3_js_1.PublicKey(task.positionAddr),
            positionAuthority,
            positionTokenAccount,
            rewardIndex: index,
            rewardOwnerAccount: resolvedAtas[mintReward].address,
            rewardVault: rewardInfo.vault
        };
        ixForPosition.push(!token_extension_util_1.TokenExtensionUtil.isV2IxRequiredReward(tokenExtensionCtx, index) ? ix_1.WhirlpoolIx.collectRewardIx(ctx.program, collectRewardBaseParams) : ix_1.WhirlpoolIx.collectRewardV2Ix(ctx.program, {
            ...collectRewardBaseParams,
            rewardMint: tokenExtensionCtx.rewardTokenMintsWithProgram[index].address,
            rewardTokenProgram: tokenExtensionCtx.rewardTokenMintsWithProgram[index].tokenProgram,
            rewardTransferHookAccounts: await token_extension_util_1.TokenExtensionUtil.getExtraAccountMetasForTransferHook(ctx.connection, tokenExtensionCtx.rewardTokenMintsWithProgram[index], collectRewardBaseParams.rewardVault, collectRewardBaseParams.rewardOwnerAccount, collectRewardBaseParams.whirlpool)
        }));
    }
    return ixForPosition;
}; //# sourceMappingURL=collect-all-txn.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/remaining-accounts-util.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.RemainingAccountsBuilder = exports.RemainingAccountsType = void 0;
exports.toSupplementalTickArrayAccountMetas = toSupplementalTickArrayAccountMetas;
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
var RemainingAccountsType;
(function(RemainingAccountsType) {
    RemainingAccountsType["TransferHookA"] = "transferHookA";
    RemainingAccountsType["TransferHookB"] = "transferHookB";
    RemainingAccountsType["TransferHookReward"] = "transferHookReward";
    RemainingAccountsType["TransferHookInput"] = "transferHookInput";
    RemainingAccountsType["TransferHookIntermediate"] = "transferHookIntermediate";
    RemainingAccountsType["TransferHookOutput"] = "transferHookOutput";
    RemainingAccountsType["SupplementalTickArrays"] = "supplementalTickArrays";
    RemainingAccountsType["SupplementalTickArraysOne"] = "supplementalTickArraysOne";
    RemainingAccountsType["SupplementalTickArraysTwo"] = "supplementalTickArraysTwo";
})(RemainingAccountsType || (exports.RemainingAccountsType = RemainingAccountsType = {}));
class RemainingAccountsBuilder {
    remainingAccounts = [];
    slices = [];
    addSlice(accountsType, accounts) {
        if (!accounts || accounts.length === 0) return this;
        this.slices.push({
            accountsType: {
                [accountsType]: {}
            },
            length: accounts.length
        });
        this.remainingAccounts.push(...accounts);
        return this;
    }
    build() {
        return this.slices.length === 0 ? [
            null,
            undefined
        ] : [
            {
                slices: this.slices
            },
            this.remainingAccounts
        ];
    }
}
exports.RemainingAccountsBuilder = RemainingAccountsBuilder;
function toSupplementalTickArrayAccountMetas(tickArrayPubkeys) {
    if (!tickArrayPubkeys) return undefined;
    (0, tiny_invariant_1.default)(tickArrayPubkeys.length <= public_1.MAX_SUPPLEMENTAL_TICK_ARRAYS, "Too many supplemental tick arrays provided");
    return tickArrayPubkeys.map((pubkey)=>({
            pubkey,
            isWritable: true,
            isSigner: false
        }));
} //# sourceMappingURL=remaining-accounts-util.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/collect-fees-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.collectFeesV2Ix = collectFeesV2Ix;
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const remaining_accounts_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/remaining-accounts-util.js [app-route] (ecmascript)");
function collectFeesV2Ix(program, params) {
    const { whirlpool, positionAuthority, position, positionTokenAccount, tokenMintA, tokenMintB, tokenOwnerAccountA, tokenOwnerAccountB, tokenVaultA, tokenVaultB, tokenTransferHookAccountsA, tokenTransferHookAccountsB, tokenProgramA, tokenProgramB } = params;
    const [remainingAccountsInfo, remainingAccounts] = new remaining_accounts_util_1.RemainingAccountsBuilder().addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookA, tokenTransferHookAccountsA).addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookB, tokenTransferHookAccountsB).build();
    const ix = program.instruction.collectFeesV2(remainingAccountsInfo, {
        accounts: {
            whirlpool,
            positionAuthority,
            position,
            positionTokenAccount,
            tokenMintA,
            tokenMintB,
            tokenOwnerAccountA,
            tokenOwnerAccountB,
            tokenVaultA,
            tokenVaultB,
            tokenProgramA,
            tokenProgramB,
            memoProgram: __1.MEMO_PROGRAM_ADDRESS
        },
        remainingAccounts
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=collect-fees-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/collect-protocol-fees-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.collectProtocolFeesV2Ix = collectProtocolFeesV2Ix;
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const remaining_accounts_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/remaining-accounts-util.js [app-route] (ecmascript)");
function collectProtocolFeesV2Ix(program, params) {
    const { whirlpoolsConfig, whirlpool, collectProtocolFeesAuthority, tokenMintA, tokenMintB, tokenVaultA, tokenVaultB, tokenTransferHookAccountsA, tokenTransferHookAccountsB, tokenOwnerAccountA: tokenDestinationA, tokenOwnerAccountB: tokenDestinationB, tokenProgramA, tokenProgramB } = params;
    const [remainingAccountsInfo, remainingAccounts] = new remaining_accounts_util_1.RemainingAccountsBuilder().addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookA, tokenTransferHookAccountsA).addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookB, tokenTransferHookAccountsB).build();
    const ix = program.instruction.collectProtocolFeesV2(remainingAccountsInfo, {
        accounts: {
            whirlpoolsConfig,
            whirlpool,
            collectProtocolFeesAuthority,
            tokenMintA,
            tokenMintB,
            tokenVaultA,
            tokenVaultB,
            tokenDestinationA,
            tokenDestinationB,
            tokenProgramA,
            tokenProgramB,
            memoProgram: __1.MEMO_PROGRAM_ADDRESS
        },
        remainingAccounts
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=collect-protocol-fees-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/collect-reward-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.collectRewardV2Ix = collectRewardV2Ix;
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const remaining_accounts_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/remaining-accounts-util.js [app-route] (ecmascript)");
function collectRewardV2Ix(program, params) {
    const { whirlpool, positionAuthority, position, positionTokenAccount, rewardMint, rewardOwnerAccount, rewardVault, rewardTransferHookAccounts, rewardIndex, rewardTokenProgram } = params;
    const [remainingAccountsInfo, remainingAccounts] = new remaining_accounts_util_1.RemainingAccountsBuilder().addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookReward, rewardTransferHookAccounts).build();
    const ix = program.instruction.collectRewardV2(rewardIndex, remainingAccountsInfo, {
        accounts: {
            whirlpool,
            positionAuthority,
            position,
            positionTokenAccount,
            rewardMint,
            rewardOwnerAccount,
            rewardVault,
            rewardTokenProgram,
            memoProgram: __1.MEMO_PROGRAM_ADDRESS
        },
        remainingAccounts
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=collect-reward-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/decrease-liquidity-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.decreaseLiquidityV2Ix = decreaseLiquidityV2Ix;
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const remaining_accounts_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/remaining-accounts-util.js [app-route] (ecmascript)");
function decreaseLiquidityV2Ix(program, params) {
    const { liquidityAmount, tokenMinA, tokenMinB, whirlpool, positionAuthority, position, positionTokenAccount, tokenMintA, tokenMintB, tokenOwnerAccountA, tokenOwnerAccountB, tokenVaultA, tokenVaultB, tokenTransferHookAccountsA, tokenTransferHookAccountsB, tokenProgramA, tokenProgramB, tickArrayLower, tickArrayUpper } = params;
    const [remainingAccountsInfo, remainingAccounts] = new remaining_accounts_util_1.RemainingAccountsBuilder().addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookA, tokenTransferHookAccountsA).addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookB, tokenTransferHookAccountsB).build();
    const ix = program.instruction.decreaseLiquidityV2(liquidityAmount, tokenMinA, tokenMinB, remainingAccountsInfo, {
        accounts: {
            whirlpool,
            positionAuthority,
            position,
            positionTokenAccount,
            tokenMintA,
            tokenMintB,
            tokenOwnerAccountA,
            tokenOwnerAccountB,
            tokenVaultA,
            tokenVaultB,
            tokenProgramA,
            tokenProgramB,
            tickArrayLower,
            tickArrayUpper,
            memoProgram: __1.MEMO_PROGRAM_ADDRESS
        },
        remainingAccounts
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=decrease-liquidity-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/increase-liquidity-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.increaseLiquidityV2Ix = increaseLiquidityV2Ix;
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const remaining_accounts_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/remaining-accounts-util.js [app-route] (ecmascript)");
function increaseLiquidityV2Ix(program, params) {
    const { liquidityAmount, tokenMaxA, tokenMaxB, whirlpool, positionAuthority, position, positionTokenAccount, tokenMintA, tokenMintB, tokenOwnerAccountA, tokenOwnerAccountB, tokenVaultA, tokenVaultB, tokenTransferHookAccountsA, tokenTransferHookAccountsB, tokenProgramA, tokenProgramB, tickArrayLower, tickArrayUpper } = params;
    const [remainingAccountsInfo, remainingAccounts] = new remaining_accounts_util_1.RemainingAccountsBuilder().addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookA, tokenTransferHookAccountsA).addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookB, tokenTransferHookAccountsB).build();
    const ix = program.instruction.increaseLiquidityV2(liquidityAmount, tokenMaxA, tokenMaxB, remainingAccountsInfo, {
        accounts: {
            whirlpool,
            positionAuthority,
            position,
            positionTokenAccount,
            tokenMintA,
            tokenMintB,
            tokenOwnerAccountA,
            tokenOwnerAccountB,
            tokenVaultA,
            tokenVaultB,
            tokenProgramA,
            tokenProgramB,
            tickArrayLower,
            tickArrayUpper,
            memoProgram: __1.MEMO_PROGRAM_ADDRESS
        },
        remainingAccounts
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=increase-liquidity-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/initialize-pool-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.initializePoolV2Ix = initializePoolV2Ix;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function initializePoolV2Ix(program, params) {
    const { initSqrtPrice, tokenMintA, tokenMintB, tokenBadgeA, tokenBadgeB, tokenProgramA, tokenProgramB, whirlpoolsConfig, whirlpoolPda, feeTierKey, tokenVaultAKeypair, tokenVaultBKeypair, tickSpacing, funder } = params;
    const ix = program.instruction.initializePoolV2(tickSpacing, initSqrtPrice, {
        accounts: {
            whirlpoolsConfig,
            tokenMintA,
            tokenMintB,
            tokenBadgeA,
            tokenBadgeB,
            funder,
            whirlpool: whirlpoolPda.publicKey,
            tokenVaultA: tokenVaultAKeypair.publicKey,
            tokenVaultB: tokenVaultBKeypair.publicKey,
            feeTier: feeTierKey,
            systemProgram: web3_js_1.SystemProgram.programId,
            tokenProgramA,
            tokenProgramB,
            rent: web3_js_1.SYSVAR_RENT_PUBKEY
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: [
            tokenVaultAKeypair,
            tokenVaultBKeypair
        ]
    };
} //# sourceMappingURL=initialize-pool-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/initialize-reward-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.initializeRewardV2Ix = initializeRewardV2Ix;
const anchor = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)"));
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function initializeRewardV2Ix(program, params) {
    const { rewardAuthority, funder, whirlpool, rewardMint, rewardTokenBadge, rewardVaultKeypair, rewardIndex, rewardTokenProgram } = params;
    const ix = program.instruction.initializeRewardV2(rewardIndex, {
        accounts: {
            rewardAuthority,
            funder,
            whirlpool,
            rewardMint,
            rewardTokenBadge,
            rewardVault: rewardVaultKeypair.publicKey,
            rewardTokenProgram,
            systemProgram: web3_js_1.SystemProgram.programId,
            rent: anchor.web3.SYSVAR_RENT_PUBKEY
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: [
            rewardVaultKeypair
        ]
    };
} //# sourceMappingURL=initialize-reward-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/set-reward-emissions-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setRewardEmissionsV2Ix = setRewardEmissionsV2Ix;
function setRewardEmissionsV2Ix(program, params) {
    const { rewardAuthority, whirlpool, rewardIndex, rewardVaultKey: rewardVault, emissionsPerSecondX64 } = params;
    const ix = program.instruction.setRewardEmissionsV2(rewardIndex, emissionsPerSecondX64, {
        accounts: {
            rewardAuthority,
            whirlpool,
            rewardVault
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=set-reward-emissions-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/swap-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.swapV2Ix = swapV2Ix;
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const remaining_accounts_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/remaining-accounts-util.js [app-route] (ecmascript)");
function swapV2Ix(program, params) {
    const { amount, otherAmountThreshold, sqrtPriceLimit, amountSpecifiedIsInput, aToB, whirlpool, tokenAuthority, tokenMintA, tokenMintB, tokenOwnerAccountA, tokenVaultA, tokenOwnerAccountB, tokenVaultB, tokenTransferHookAccountsA, tokenTransferHookAccountsB, tokenProgramA, tokenProgramB, tickArray0, tickArray1, tickArray2, oracle, supplementalTickArrays } = params;
    const [remainingAccountsInfo, remainingAccounts] = new remaining_accounts_util_1.RemainingAccountsBuilder().addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookA, tokenTransferHookAccountsA).addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookB, tokenTransferHookAccountsB).addSlice(remaining_accounts_util_1.RemainingAccountsType.SupplementalTickArrays, (0, remaining_accounts_util_1.toSupplementalTickArrayAccountMetas)(supplementalTickArrays)).build();
    const ix = program.instruction.swapV2(amount, otherAmountThreshold, sqrtPriceLimit, amountSpecifiedIsInput, aToB, remainingAccountsInfo, {
        accounts: {
            tokenProgramA,
            tokenProgramB,
            memoProgram: public_1.MEMO_PROGRAM_ADDRESS,
            tokenAuthority: tokenAuthority,
            whirlpool,
            tokenMintA,
            tokenMintB,
            tokenOwnerAccountA,
            tokenVaultA,
            tokenOwnerAccountB,
            tokenVaultB,
            tickArray0,
            tickArray1,
            tickArray2,
            oracle
        },
        remainingAccounts
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=swap-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/two-hop-swap-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.twoHopSwapV2Ix = twoHopSwapV2Ix;
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const remaining_accounts_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/remaining-accounts-util.js [app-route] (ecmascript)");
function twoHopSwapV2Ix(program, params) {
    const { amount, otherAmountThreshold, amountSpecifiedIsInput, aToBOne, aToBTwo, sqrtPriceLimitOne, sqrtPriceLimitTwo, whirlpoolOne, whirlpoolTwo, tokenMintInput, tokenMintIntermediate, tokenMintOutput, tokenProgramInput, tokenProgramIntermediate, tokenProgramOutput, tokenVaultOneInput, tokenVaultOneIntermediate, tokenVaultTwoIntermediate, tokenVaultTwoOutput, tokenAuthority, tokenTransferHookAccountsInput, tokenTransferHookAccountsIntermediate, tokenTransferHookAccountsOutput, tokenOwnerAccountInput, tokenOwnerAccountOutput, tickArrayOne0, tickArrayOne1, tickArrayOne2, tickArrayTwo0, tickArrayTwo1, tickArrayTwo2, oracleOne, oracleTwo, supplementalTickArraysOne, supplementalTickArraysTwo } = params;
    const [remainingAccountsInfo, remainingAccounts] = new remaining_accounts_util_1.RemainingAccountsBuilder().addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookInput, tokenTransferHookAccountsInput).addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookIntermediate, tokenTransferHookAccountsIntermediate).addSlice(remaining_accounts_util_1.RemainingAccountsType.TransferHookOutput, tokenTransferHookAccountsOutput).addSlice(remaining_accounts_util_1.RemainingAccountsType.SupplementalTickArraysOne, (0, remaining_accounts_util_1.toSupplementalTickArrayAccountMetas)(supplementalTickArraysOne)).addSlice(remaining_accounts_util_1.RemainingAccountsType.SupplementalTickArraysTwo, (0, remaining_accounts_util_1.toSupplementalTickArrayAccountMetas)(supplementalTickArraysTwo)).build();
    const ix = program.instruction.twoHopSwapV2(amount, otherAmountThreshold, amountSpecifiedIsInput, aToBOne, aToBTwo, sqrtPriceLimitOne, sqrtPriceLimitTwo, remainingAccountsInfo, {
        accounts: {
            whirlpoolOne,
            whirlpoolTwo,
            tokenMintInput,
            tokenMintIntermediate,
            tokenMintOutput,
            tokenProgramInput,
            tokenProgramIntermediate,
            tokenProgramOutput,
            tokenOwnerAccountInput,
            tokenVaultOneInput,
            tokenVaultOneIntermediate,
            tokenVaultTwoIntermediate,
            tokenVaultTwoOutput,
            tokenOwnerAccountOutput,
            tokenAuthority,
            tickArrayOne0,
            tickArrayOne1,
            tickArrayOne2,
            tickArrayTwo0,
            tickArrayTwo1,
            tickArrayTwo2,
            oracleOne,
            oracleTwo,
            memoProgram: public_1.MEMO_PROGRAM_ADDRESS
        },
        remainingAccounts
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=two-hop-swap-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/initialize-config-extension-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.initializeConfigExtensionIx = initializeConfigExtensionIx;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function initializeConfigExtensionIx(program, params) {
    const { whirlpoolsConfig, whirlpoolsConfigExtensionPda, funder, feeAuthority } = params;
    const ix = program.instruction.initializeConfigExtension({
        accounts: {
            config: whirlpoolsConfig,
            configExtension: whirlpoolsConfigExtensionPda.publicKey,
            funder,
            feeAuthority,
            systemProgram: web3_js_1.SystemProgram.programId
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=initialize-config-extension-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/set-config-extension-authority-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setConfigExtensionAuthorityIx = setConfigExtensionAuthorityIx;
function setConfigExtensionAuthorityIx(program, params) {
    const { whirlpoolsConfig, whirlpoolsConfigExtension, configExtensionAuthority, newConfigExtensionAuthority } = params;
    const ix = program.instruction.setConfigExtensionAuthority({
        accounts: {
            whirlpoolsConfig,
            whirlpoolsConfigExtension,
            configExtensionAuthority,
            newConfigExtensionAuthority
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=set-config-extension-authority-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/set-token-badge-authority-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setTokenBadgeAuthorityIx = setTokenBadgeAuthorityIx;
function setTokenBadgeAuthorityIx(program, params) {
    const { whirlpoolsConfig, whirlpoolsConfigExtension, configExtensionAuthority, newTokenBadgeAuthority } = params;
    const ix = program.instruction.setTokenBadgeAuthority({
        accounts: {
            whirlpoolsConfig,
            whirlpoolsConfigExtension,
            configExtensionAuthority,
            newTokenBadgeAuthority
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=set-token-badge-authority-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/initialize-token-badge-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.initializeTokenBadgeIx = initializeTokenBadgeIx;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function initializeTokenBadgeIx(program, params) {
    const { whirlpoolsConfig, whirlpoolsConfigExtension, tokenBadgeAuthority, tokenMint, tokenBadgePda, funder } = params;
    const ix = program.instruction.initializeTokenBadge({
        accounts: {
            whirlpoolsConfig,
            whirlpoolsConfigExtension,
            tokenBadgeAuthority,
            tokenMint,
            tokenBadge: tokenBadgePda.publicKey,
            funder,
            systemProgram: web3_js_1.SystemProgram.programId
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=initialize-token-badge-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/delete-token-badge-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.deleteTokenBadgeIx = deleteTokenBadgeIx;
function deleteTokenBadgeIx(program, params) {
    const { whirlpoolsConfig, whirlpoolsConfigExtension, tokenBadgeAuthority, tokenMint, tokenBadge, receiver } = params;
    const ix = program.instruction.deleteTokenBadge({
        accounts: {
            whirlpoolsConfig,
            whirlpoolsConfigExtension,
            tokenBadgeAuthority,
            tokenMint,
            tokenBadge,
            receiver
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=delete-token-badge-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/collect-fees-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/collect-protocol-fees-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/collect-reward-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/decrease-liquidity-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/increase-liquidity-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/initialize-pool-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/initialize-reward-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/set-reward-emissions-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/swap-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/two-hop-swap-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/initialize-config-extension-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/set-config-extension-authority-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/set-token-badge-authority-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/initialize-token-badge-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/delete-token-badge-ix.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/composites/collect-protocol-fees.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.collectProtocolFees = collectProtocolFees;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const fetcher_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)");
const whirlpool_ata_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/whirlpool-ata-utils.js [app-route] (ecmascript)");
const collect_protocol_fees_ix_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/collect-protocol-fees-ix.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
const v2_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/index.js [app-route] (ecmascript)");
async function collectProtocolFees(ctx, poolAddresses) {
    const receiverKey = ctx.wallet.publicKey;
    const payerKey = ctx.wallet.publicKey;
    const whirlpoolDatas = Array.from((await ctx.fetcher.getPools(poolAddresses, fetcher_1.PREFER_CACHE)).values());
    const mints = (0, whirlpool_ata_utils_1.getTokenMintsFromWhirlpools)(whirlpoolDatas, whirlpool_ata_utils_1.TokenMintTypes.POOL_ONLY).mintMap;
    await ctx.fetcher.getMintInfos(mints);
    const accountExemption = await ctx.fetcher.getAccountRentExempt();
    const { ataTokenAddresses, resolveAtaIxs } = await (0, whirlpool_ata_utils_1.resolveAtaForMints)(ctx, {
        mints: mints,
        accountExemption,
        receiver: receiverKey,
        payer: payerKey
    });
    const latestBlockhash = await ctx.connection.getLatestBlockhash();
    let txBuilder = new common_sdk_1.TransactionBuilder(ctx.connection, ctx.wallet, ctx.txBuilderOpts).addInstructions(resolveAtaIxs);
    const instructions = [];
    for (const poolAddress of poolAddresses){
        const pool = await ctx.fetcher.getPool(poolAddress);
        if (!pool) {
            throw new Error(`Pool not found: ${poolAddress}`);
        }
        const poolConfig = await ctx.fetcher.getConfig(pool.whirlpoolsConfig);
        if (!poolConfig) {
            throw new Error(`Config not found: ${pool.whirlpoolsConfig}`);
        }
        if (poolConfig.collectProtocolFeesAuthority.toBase58() !== ctx.wallet.publicKey.toBase58()) {
            throw new Error(`Wallet is not the collectProtocolFeesAuthority`);
        }
        const poolHandlesNativeMint = common_sdk_1.TokenUtil.isNativeMint(pool.tokenMintA) || common_sdk_1.TokenUtil.isNativeMint(pool.tokenMintB);
        const txBuilderHasNativeMint = !!ataTokenAddresses[spl_token_1.NATIVE_MINT.toBase58()];
        if (poolHandlesNativeMint && !txBuilderHasNativeMint) {
            (0, whirlpool_ata_utils_1.addNativeMintHandlingIx)(txBuilder, ataTokenAddresses, receiverKey, accountExemption, ctx.accountResolverOpts.createWrappedSolAccountMethod);
        }
        const tokenExtensionCtx = await token_extension_util_1.TokenExtensionUtil.buildTokenExtensionContext(ctx.fetcher, pool, fetcher_1.PREFER_CACHE);
        const baseParams = {
            whirlpoolsConfig: pool.whirlpoolsConfig,
            whirlpool: common_sdk_1.AddressUtil.toPubKey(poolAddress),
            tokenVaultA: pool.tokenVaultA,
            tokenVaultB: pool.tokenVaultB,
            tokenOwnerAccountA: ataTokenAddresses[pool.tokenMintA.toBase58()],
            tokenOwnerAccountB: ataTokenAddresses[pool.tokenMintB.toBase58()],
            collectProtocolFeesAuthority: poolConfig.collectProtocolFeesAuthority
        };
        instructions.push(!token_extension_util_1.TokenExtensionUtil.isV2IxRequiredPool(tokenExtensionCtx) ? (0, collect_protocol_fees_ix_1.collectProtocolFeesIx)(ctx.program, baseParams) : (0, v2_1.collectProtocolFeesV2Ix)(ctx.program, {
            ...baseParams,
            tokenMintA: tokenExtensionCtx.tokenMintWithProgramA.address,
            tokenMintB: tokenExtensionCtx.tokenMintWithProgramB.address,
            tokenProgramA: tokenExtensionCtx.tokenMintWithProgramA.tokenProgram,
            tokenProgramB: tokenExtensionCtx.tokenMintWithProgramB.tokenProgram,
            ...await token_extension_util_1.TokenExtensionUtil.getExtraAccountMetasForTransferHookForPool(ctx.connection, tokenExtensionCtx, baseParams.tokenVaultA, baseParams.tokenOwnerAccountA, baseParams.whirlpool, baseParams.tokenVaultB, baseParams.tokenOwnerAccountB, baseParams.whirlpool)
        }));
    }
    txBuilder.addInstructions(instructions);
    const txSize = await txBuilder.txnSize({
        latestBlockhash
    });
    if (txSize > web3_js_1.PACKET_DATA_SIZE) {
        throw new Error(`Transaction size is too large: ${txSize}`);
    }
    return txBuilder;
} //# sourceMappingURL=collect-protocol-fees.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/swap-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.swapIx = swapIx;
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
function swapIx(program, params) {
    const { amount, otherAmountThreshold, sqrtPriceLimit, amountSpecifiedIsInput, aToB, whirlpool, tokenAuthority, tokenOwnerAccountA, tokenVaultA, tokenOwnerAccountB, tokenVaultB, tickArray0, tickArray1, tickArray2, oracle } = params;
    const ix = program.instruction.swap(amount, otherAmountThreshold, sqrtPriceLimit, amountSpecifiedIsInput, aToB, {
        accounts: {
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
            tokenAuthority: tokenAuthority,
            whirlpool,
            tokenOwnerAccountA,
            tokenVaultA,
            tokenOwnerAccountB,
            tokenVaultB,
            tickArray0,
            tickArray1,
            tickArray2,
            oracle
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=swap-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/composites/swap-async.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.swapAsync = swapAsync;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const swap_ix_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/swap-ix.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
const v2_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
async function swapAsync(ctx, params, _opts) {
    const { wallet, whirlpool, swapInput } = params;
    const { aToB, amount, otherAmountThreshold, amountSpecifiedIsInput } = swapInput;
    const txBuilder = new common_sdk_1.TransactionBuilder(ctx.connection, ctx.wallet, ctx.txBuilderOpts);
    const data = whirlpool.getData();
    const inputTokenMint = aToB ? data.tokenMintA : data.tokenMintB;
    const maxInputAmount = amountSpecifiedIsInput ? amount : otherAmountThreshold;
    if (inputTokenMint.equals(spl_token_1.NATIVE_MINT) && maxInputAmount.eq(common_sdk_1.U64_MAX)) {
        throw new Error("Wrapping U64_MAX amount of SOL is not possible");
    }
    const [resolvedAtaA, resolvedAtaB] = await (0, common_sdk_1.resolveOrCreateATAs)(ctx.connection, wallet, [
        {
            tokenMint: data.tokenMintA,
            wrappedSolAmountIn: aToB ? maxInputAmount : common_sdk_1.ZERO
        },
        {
            tokenMint: data.tokenMintB,
            wrappedSolAmountIn: !aToB ? maxInputAmount : common_sdk_1.ZERO
        }
    ], ()=>ctx.fetcher.getAccountRentExempt(), undefined, true, ctx.accountResolverOpts.allowPDAOwnerAddress, ctx.accountResolverOpts.createWrappedSolAccountMethod);
    const { address: ataAKey, ...tokenOwnerAccountAIx } = resolvedAtaA;
    const { address: ataBKey, ...tokenOwnerAccountBIx } = resolvedAtaB;
    txBuilder.addInstructions([
        tokenOwnerAccountAIx,
        tokenOwnerAccountBIx
    ]);
    const inputTokenAccount = aToB ? ataAKey : ataBKey;
    const outputTokenAccount = aToB ? ataBKey : ataAKey;
    const tokenExtensionCtx = await token_extension_util_1.TokenExtensionUtil.buildTokenExtensionContext(ctx.fetcher, data);
    const baseParams = __1.SwapUtils.getSwapParamsFromQuote(swapInput, ctx, whirlpool, inputTokenAccount, outputTokenAccount, wallet);
    return txBuilder.addInstruction(!token_extension_util_1.TokenExtensionUtil.isV2IxRequiredPool(tokenExtensionCtx) && !params.swapInput.supplementalTickArrays ? (0, swap_ix_1.swapIx)(ctx.program, baseParams) : (0, v2_1.swapV2Ix)(ctx.program, {
        ...baseParams,
        tokenMintA: tokenExtensionCtx.tokenMintWithProgramA.address,
        tokenMintB: tokenExtensionCtx.tokenMintWithProgramB.address,
        tokenProgramA: tokenExtensionCtx.tokenMintWithProgramA.tokenProgram,
        tokenProgramB: tokenExtensionCtx.tokenMintWithProgramB.tokenProgram,
        ...await token_extension_util_1.TokenExtensionUtil.getExtraAccountMetasForTransferHookForPool(ctx.connection, tokenExtensionCtx, baseParams.aToB ? baseParams.tokenOwnerAccountA : baseParams.tokenVaultA, baseParams.aToB ? baseParams.tokenVaultA : baseParams.tokenOwnerAccountA, baseParams.aToB ? baseParams.tokenAuthority : baseParams.whirlpool, baseParams.aToB ? baseParams.tokenVaultB : baseParams.tokenOwnerAccountB, baseParams.aToB ? baseParams.tokenOwnerAccountB : baseParams.tokenVaultB, baseParams.aToB ? baseParams.whirlpool : baseParams.tokenAuthority),
        supplementalTickArrays: params.swapInput.supplementalTickArrays
    }));
} //# sourceMappingURL=swap-async.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/composites/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/composites/collect-all-txn.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/composites/collect-protocol-fees.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/composites/swap-async.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/decrease-liquidity-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.decreaseLiquidityIx = decreaseLiquidityIx;
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
function decreaseLiquidityIx(program, params) {
    const { liquidityAmount, tokenMinA, tokenMinB, whirlpool, positionAuthority, position, positionTokenAccount, tokenOwnerAccountA, tokenOwnerAccountB, tokenVaultA, tokenVaultB, tickArrayLower, tickArrayUpper } = params;
    const ix = program.instruction.decreaseLiquidity(liquidityAmount, tokenMinA, tokenMinB, {
        accounts: {
            whirlpool,
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
            positionAuthority,
            position,
            positionTokenAccount,
            tokenOwnerAccountA,
            tokenOwnerAccountB,
            tokenVaultA,
            tokenVaultB,
            tickArrayLower,
            tickArrayUpper
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=decrease-liquidity-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/delete-position-bundle-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.deletePositionBundleIx = deletePositionBundleIx;
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
function deletePositionBundleIx(program, params) {
    const { owner, positionBundle, positionBundleMint, positionBundleTokenAccount, receiver } = params;
    const ix = program.instruction.deletePositionBundle({
        accounts: {
            positionBundle: positionBundle,
            positionBundleMint: positionBundleMint,
            positionBundleTokenAccount,
            positionBundleOwner: owner,
            receiver,
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=delete-position-bundle-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/increase-liquidity-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.increaseLiquidityIx = increaseLiquidityIx;
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
function increaseLiquidityIx(program, params) {
    const { liquidityAmount, tokenMaxA, tokenMaxB, whirlpool, positionAuthority, position, positionTokenAccount, tokenOwnerAccountA, tokenOwnerAccountB, tokenVaultA, tokenVaultB, tickArrayLower, tickArrayUpper } = params;
    const ix = program.instruction.increaseLiquidity(liquidityAmount, tokenMaxA, tokenMaxB, {
        accounts: {
            whirlpool,
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
            positionAuthority,
            position,
            positionTokenAccount,
            tokenOwnerAccountA,
            tokenOwnerAccountB,
            tokenVaultA,
            tokenVaultB,
            tickArrayLower,
            tickArrayUpper
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=increase-liquidity-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/initialize-config-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.initializeConfigIx = initializeConfigIx;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function initializeConfigIx(program, params) {
    const { feeAuthority, collectProtocolFeesAuthority, rewardEmissionsSuperAuthority, defaultProtocolFeeRate, funder } = params;
    const ix = program.instruction.initializeConfig(feeAuthority, collectProtocolFeesAuthority, rewardEmissionsSuperAuthority, defaultProtocolFeeRate, {
        accounts: {
            config: params.whirlpoolsConfigKeypair.publicKey,
            funder,
            systemProgram: web3_js_1.SystemProgram.programId
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: [
            params.whirlpoolsConfigKeypair
        ]
    };
} //# sourceMappingURL=initialize-config-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/initialize-fee-tier-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.initializeFeeTierIx = initializeFeeTierIx;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function initializeFeeTierIx(program, params) {
    const { feeTierPda, whirlpoolsConfig, tickSpacing, feeAuthority, defaultFeeRate, funder } = params;
    const ix = program.instruction.initializeFeeTier(tickSpacing, defaultFeeRate, {
        accounts: {
            config: whirlpoolsConfig,
            feeTier: feeTierPda.publicKey,
            feeAuthority,
            funder,
            systemProgram: web3_js_1.SystemProgram.programId
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=initialize-fee-tier-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/initialize-pool-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.initializePoolIx = initializePoolIx;
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function initializePoolIx(program, params) {
    const { initSqrtPrice, tokenMintA, tokenMintB, whirlpoolsConfig, whirlpoolPda, feeTierKey, tokenVaultAKeypair, tokenVaultBKeypair, tickSpacing, funder } = params;
    const whirlpoolBumps = {
        whirlpoolBump: whirlpoolPda.bump
    };
    const ix = program.instruction.initializePool(whirlpoolBumps, tickSpacing, initSqrtPrice, {
        accounts: {
            whirlpoolsConfig,
            tokenMintA,
            tokenMintB,
            funder,
            whirlpool: whirlpoolPda.publicKey,
            tokenVaultA: tokenVaultAKeypair.publicKey,
            tokenVaultB: tokenVaultBKeypair.publicKey,
            feeTier: feeTierKey,
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
            systemProgram: web3_js_1.SystemProgram.programId,
            rent: web3_js_1.SYSVAR_RENT_PUBKEY
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: [
            tokenVaultAKeypair,
            tokenVaultBKeypair
        ]
    };
} //# sourceMappingURL=initialize-pool-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/initialize-position-bundle-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.initializePositionBundleIx = initializePositionBundleIx;
exports.initializePositionBundleWithMetadataIx = initializePositionBundleWithMetadataIx;
const anchor = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)"));
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
function initializePositionBundleIx(program, params) {
    const { owner, positionBundlePda, positionBundleMintKeypair, positionBundleTokenAccount, funder } = params;
    const ix = program.instruction.initializePositionBundle({
        accounts: {
            positionBundle: positionBundlePda.publicKey,
            positionBundleMint: positionBundleMintKeypair.publicKey,
            positionBundleTokenAccount,
            positionBundleOwner: owner,
            funder,
            associatedTokenProgram: spl_token_1.ASSOCIATED_TOKEN_PROGRAM_ID,
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
            systemProgram: web3_js_1.SystemProgram.programId,
            rent: anchor.web3.SYSVAR_RENT_PUBKEY
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: [
            positionBundleMintKeypair
        ]
    };
}
function initializePositionBundleWithMetadataIx(program, params) {
    const { owner, positionBundlePda, positionBundleMintKeypair, positionBundleTokenAccount, positionBundleMetadataPda, funder } = params;
    const ix = program.instruction.initializePositionBundleWithMetadata({
        accounts: {
            positionBundle: positionBundlePda.publicKey,
            positionBundleMint: positionBundleMintKeypair.publicKey,
            positionBundleMetadata: positionBundleMetadataPda.publicKey,
            positionBundleTokenAccount,
            positionBundleOwner: owner,
            funder,
            associatedTokenProgram: spl_token_1.ASSOCIATED_TOKEN_PROGRAM_ID,
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
            systemProgram: web3_js_1.SystemProgram.programId,
            rent: anchor.web3.SYSVAR_RENT_PUBKEY,
            metadataProgram: __1.METADATA_PROGRAM_ADDRESS,
            metadataUpdateAuth: __1.WHIRLPOOL_NFT_UPDATE_AUTH
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: [
            positionBundleMintKeypair
        ]
    };
} //# sourceMappingURL=initialize-position-bundle-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/initialize-reward-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.initializeRewardIx = initializeRewardIx;
const anchor = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)"));
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function initializeRewardIx(program, params) {
    const { rewardAuthority, funder, whirlpool, rewardMint, rewardVaultKeypair, rewardIndex } = params;
    const ix = program.instruction.initializeReward(rewardIndex, {
        accounts: {
            rewardAuthority,
            funder,
            whirlpool,
            rewardMint,
            rewardVault: rewardVaultKeypair.publicKey,
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
            systemProgram: web3_js_1.SystemProgram.programId,
            rent: anchor.web3.SYSVAR_RENT_PUBKEY
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: [
            rewardVaultKeypair
        ]
    };
} //# sourceMappingURL=initialize-reward-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/initialize-tick-array-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.initTickArrayIx = initTickArrayIx;
const anchor = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)"));
function initTickArrayIx(program, params) {
    const { whirlpool, funder, tickArrayPda } = params;
    const ix = program.instruction.initializeTickArray(params.startTick, {
        accounts: {
            whirlpool,
            funder,
            tickArray: tickArrayPda.publicKey,
            systemProgram: anchor.web3.SystemProgram.programId
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=initialize-tick-array-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/open-bundled-position-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.openBundledPositionIx = openBundledPositionIx;
const anchor = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)"));
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function openBundledPositionIx(program, params) {
    const { whirlpool, bundledPositionPda, positionBundle, positionBundleTokenAccount, positionBundleAuthority, bundleIndex, tickLowerIndex, tickUpperIndex, funder } = params;
    const ix = program.instruction.openBundledPosition(bundleIndex, tickLowerIndex, tickUpperIndex, {
        accounts: {
            bundledPosition: bundledPositionPda.publicKey,
            positionBundle,
            positionBundleTokenAccount,
            positionBundleAuthority,
            whirlpool,
            funder,
            systemProgram: web3_js_1.SystemProgram.programId,
            rent: anchor.web3.SYSVAR_RENT_PUBKEY
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=open-bundled-position-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/instructions-util.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.openPositionAccounts = openPositionAccounts;
exports.openPositionWithTokenExtensionsAccounts = openPositionWithTokenExtensionsAccounts;
const anchor = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)"));
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function openPositionAccounts(params) {
    const { funder, owner, positionPda, positionMintAddress, positionTokenAccount: positionTokenAccountAddress, whirlpool: whirlpoolKey } = params;
    return {
        funder: funder,
        owner,
        position: positionPda.publicKey,
        positionMint: positionMintAddress,
        positionTokenAccount: positionTokenAccountAddress,
        whirlpool: whirlpoolKey,
        tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
        systemProgram: web3_js_1.SystemProgram.programId,
        rent: anchor.web3.SYSVAR_RENT_PUBKEY,
        associatedTokenProgram: spl_token_1.ASSOCIATED_TOKEN_PROGRAM_ID
    };
}
function openPositionWithTokenExtensionsAccounts(params) {
    const { funder, owner, positionPda, positionMint, positionTokenAccount, whirlpool: whirlpoolKey } = params;
    return {
        funder: funder,
        owner,
        position: positionPda.publicKey,
        positionMint,
        positionTokenAccount,
        whirlpool: whirlpoolKey,
        token2022Program: spl_token_1.TOKEN_2022_PROGRAM_ID,
        systemProgram: web3_js_1.SystemProgram.programId,
        associatedTokenProgram: spl_token_1.ASSOCIATED_TOKEN_PROGRAM_ID
    };
} //# sourceMappingURL=instructions-util.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/open-position-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.openPositionIx = openPositionIx;
exports.openPositionWithMetadataIx = openPositionWithMetadataIx;
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const instructions_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/instructions-util.js [app-route] (ecmascript)");
function openPositionIx(program, params) {
    const { positionPda, tickLowerIndex, tickUpperIndex } = params;
    const bumps = {
        positionBump: positionPda.bump
    };
    const ix = program.instruction.openPosition(bumps, tickLowerIndex, tickUpperIndex, {
        accounts: (0, instructions_util_1.openPositionAccounts)(params)
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
}
function openPositionWithMetadataIx(program, params) {
    const { positionPda, metadataPda, tickLowerIndex, tickUpperIndex } = params;
    const bumps = {
        positionBump: positionPda.bump,
        metadataBump: metadataPda.bump
    };
    const ix = program.instruction.openPositionWithMetadata(bumps, tickLowerIndex, tickUpperIndex, {
        accounts: {
            ...(0, instructions_util_1.openPositionAccounts)(params),
            positionMetadataAccount: metadataPda.publicKey,
            metadataProgram: __1.METADATA_PROGRAM_ADDRESS,
            metadataUpdateAuth: __1.WHIRLPOOL_NFT_UPDATE_AUTH
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=open-position-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/open-position-with-token-extensions-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.openPositionWithTokenExtensionsIx = openPositionWithTokenExtensionsIx;
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const instructions_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/instructions-util.js [app-route] (ecmascript)");
function openPositionWithTokenExtensionsIx(program, params) {
    const { tickLowerIndex, tickUpperIndex, withTokenMetadataExtension } = params;
    const ix = program.instruction.openPositionWithTokenExtensions(tickLowerIndex, tickUpperIndex, withTokenMetadataExtension, {
        accounts: {
            ...(0, instructions_util_1.openPositionWithTokenExtensionsAccounts)(params),
            metadataUpdateAuth: __1.WHIRLPOOL_NFT_UPDATE_AUTH
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=open-position-with-token-extensions-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-collect-protocol-fees-authority-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setCollectProtocolFeesAuthorityIx = setCollectProtocolFeesAuthorityIx;
function setCollectProtocolFeesAuthorityIx(program, params) {
    const { whirlpoolsConfig, collectProtocolFeesAuthority, newCollectProtocolFeesAuthority } = params;
    const ix = program.instruction.setCollectProtocolFeesAuthority({
        accounts: {
            whirlpoolsConfig,
            collectProtocolFeesAuthority,
            newCollectProtocolFeesAuthority
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=set-collect-protocol-fees-authority-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-default-fee-rate-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setDefaultFeeRateIx = setDefaultFeeRateIx;
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
function setDefaultFeeRateIx(program, params) {
    const { whirlpoolsConfig, feeAuthority, tickSpacing, defaultFeeRate } = params;
    const feeTierPda = public_1.PDAUtil.getFeeTier(program.programId, whirlpoolsConfig, tickSpacing);
    const ix = program.instruction.setDefaultFeeRate(defaultFeeRate, {
        accounts: {
            whirlpoolsConfig,
            feeTier: feeTierPda.publicKey,
            feeAuthority
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=set-default-fee-rate-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-default-protocol-fee-rate-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setDefaultProtocolFeeRateIx = setDefaultProtocolFeeRateIx;
function setDefaultProtocolFeeRateIx(program, params) {
    const { whirlpoolsConfig, feeAuthority, defaultProtocolFeeRate } = params;
    const ix = program.instruction.setDefaultProtocolFeeRate(defaultProtocolFeeRate, {
        accounts: {
            whirlpoolsConfig,
            feeAuthority
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=set-default-protocol-fee-rate-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-fee-authority-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setFeeAuthorityIx = setFeeAuthorityIx;
function setFeeAuthorityIx(program, params) {
    const { whirlpoolsConfig, feeAuthority, newFeeAuthority } = params;
    const ix = program.instruction.setFeeAuthority({
        accounts: {
            whirlpoolsConfig,
            feeAuthority,
            newFeeAuthority
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=set-fee-authority-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-fee-rate-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setFeeRateIx = setFeeRateIx;
function setFeeRateIx(program, params) {
    const { whirlpoolsConfig, whirlpool, feeAuthority, feeRate } = params;
    const ix = program.instruction.setFeeRate(feeRate, {
        accounts: {
            whirlpoolsConfig,
            whirlpool,
            feeAuthority
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=set-fee-rate-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-protocol-fee-rate-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setProtocolFeeRateIx = setProtocolFeeRateIx;
function setProtocolFeeRateIx(program, params) {
    const { whirlpoolsConfig, whirlpool, feeAuthority, protocolFeeRate } = params;
    const ix = program.instruction.setProtocolFeeRate(protocolFeeRate, {
        accounts: {
            whirlpoolsConfig,
            whirlpool,
            feeAuthority
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=set-protocol-fee-rate-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-reward-authority-by-super-authority-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setRewardAuthorityBySuperAuthorityIx = setRewardAuthorityBySuperAuthorityIx;
function setRewardAuthorityBySuperAuthorityIx(program, params) {
    const { whirlpoolsConfig, whirlpool, rewardEmissionsSuperAuthority, newRewardAuthority, rewardIndex } = params;
    const ix = program.instruction.setRewardAuthorityBySuperAuthority(rewardIndex, {
        accounts: {
            whirlpoolsConfig,
            whirlpool,
            rewardEmissionsSuperAuthority,
            newRewardAuthority
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=set-reward-authority-by-super-authority-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-reward-authority-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setRewardAuthorityIx = setRewardAuthorityIx;
function setRewardAuthorityIx(program, params) {
    const { whirlpool, rewardAuthority, newRewardAuthority, rewardIndex } = params;
    const ix = program.instruction.setRewardAuthority(rewardIndex, {
        accounts: {
            whirlpool,
            rewardAuthority,
            newRewardAuthority
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=set-reward-authority-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-reward-emissions-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setRewardEmissionsIx = setRewardEmissionsIx;
function setRewardEmissionsIx(program, params) {
    const { rewardAuthority, whirlpool, rewardIndex, rewardVaultKey: rewardVault, emissionsPerSecondX64 } = params;
    const ix = program.instruction.setRewardEmissions(rewardIndex, emissionsPerSecondX64, {
        accounts: {
            rewardAuthority,
            whirlpool,
            rewardVault
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=set-reward-emissions-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-reward-emissions-super-authority-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setRewardEmissionsSuperAuthorityIx = setRewardEmissionsSuperAuthorityIx;
function setRewardEmissionsSuperAuthorityIx(program, params) {
    const { whirlpoolsConfig, rewardEmissionsSuperAuthority, newRewardEmissionsSuperAuthority } = params;
    const ix = program.instruction.setRewardEmissionsSuperAuthority({
        accounts: {
            whirlpoolsConfig,
            rewardEmissionsSuperAuthority: rewardEmissionsSuperAuthority,
            newRewardEmissionsSuperAuthority
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=set-reward-emissions-super-authority-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/two-hop-swap-ix.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.twoHopSwapIx = twoHopSwapIx;
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
function twoHopSwapIx(program, params) {
    const { amount, otherAmountThreshold, amountSpecifiedIsInput, aToBOne, aToBTwo, sqrtPriceLimitOne, sqrtPriceLimitTwo, whirlpoolOne, whirlpoolTwo, tokenAuthority, tokenOwnerAccountOneA, tokenVaultOneA, tokenOwnerAccountOneB, tokenVaultOneB, tokenOwnerAccountTwoA, tokenVaultTwoA, tokenOwnerAccountTwoB, tokenVaultTwoB, tickArrayOne0, tickArrayOne1, tickArrayOne2, tickArrayTwo0, tickArrayTwo1, tickArrayTwo2, oracleOne, oracleTwo } = params;
    const ix = program.instruction.twoHopSwap(amount, otherAmountThreshold, amountSpecifiedIsInput, aToBOne, aToBTwo, sqrtPriceLimitOne, sqrtPriceLimitTwo, {
        accounts: {
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
            tokenAuthority,
            whirlpoolOne,
            whirlpoolTwo,
            tokenOwnerAccountOneA,
            tokenVaultOneA,
            tokenOwnerAccountOneB,
            tokenVaultOneB,
            tokenOwnerAccountTwoA,
            tokenVaultTwoA,
            tokenOwnerAccountTwoB,
            tokenVaultTwoB,
            tickArrayOne0,
            tickArrayOne1,
            tickArrayOne2,
            tickArrayTwo0,
            tickArrayTwo1,
            tickArrayTwo2,
            oracleOne,
            oracleTwo
        }
    });
    return {
        instructions: [
            ix
        ],
        cleanupInstructions: [],
        signers: []
    };
} //# sourceMappingURL=two-hop-swap-ix.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/close-bundled-position-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/close-position-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/close-position-with-token-extensions-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/collect-fees-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/collect-protocol-fees-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/collect-reward-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/composites/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/decrease-liquidity-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/delete-position-bundle-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/increase-liquidity-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/initialize-config-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/initialize-fee-tier-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/initialize-pool-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/initialize-position-bundle-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/initialize-reward-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/initialize-tick-array-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/open-bundled-position-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/open-position-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/open-position-with-token-extensions-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-collect-protocol-fees-authority-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-default-fee-rate-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-default-protocol-fee-rate-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-fee-authority-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-fee-rate-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-protocol-fee-rate-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-reward-authority-by-super-authority-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-reward-authority-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-reward-emissions-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/set-reward-emissions-super-authority-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/swap-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/two-hop-swap-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/update-fees-and-rewards-ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/v2/index.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/builder/position-builder-util.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getTickArrayDataForPosition = getTickArrayDataForPosition;
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
async function getTickArrayDataForPosition(ctx, position, whirlpool, opts) {
    const lowerTickArrayKey = public_1.PDAUtil.getTickArrayFromTickIndex(position.tickLowerIndex, whirlpool.tickSpacing, position.whirlpool, ctx.program.programId).publicKey;
    const upperTickArrayKey = public_1.PDAUtil.getTickArrayFromTickIndex(position.tickUpperIndex, whirlpool.tickSpacing, position.whirlpool, ctx.program.programId).publicKey;
    return await ctx.fetcher.getTickArrays([
        lowerTickArrayKey,
        upperTickArrayKey
    ], opts);
} //# sourceMappingURL=position-builder-util.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/impl/position-impl.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PositionImpl = void 0;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
const instructions_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/index.js [app-route] (ecmascript)");
const fetcher_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)");
const position_builder_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/builder/position-builder-util.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const whirlpool_ata_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/whirlpool-ata-utils.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
const txn_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/txn-utils.js [app-route] (ecmascript)");
class PositionImpl {
    ctx;
    address;
    positionMintTokenProgramId;
    data;
    whirlpoolData;
    lowerTickArrayData;
    upperTickArrayData;
    constructor(ctx, address, data, whirlpoolData, lowerTickArrayData, upperTickArrayData, positionMintTokenProgramId){
        this.ctx = ctx;
        this.address = address;
        this.positionMintTokenProgramId = positionMintTokenProgramId;
        this.data = data;
        this.whirlpoolData = whirlpoolData;
        this.lowerTickArrayData = lowerTickArrayData;
        this.upperTickArrayData = upperTickArrayData;
    }
    getAddress() {
        return this.address;
    }
    getPositionMintTokenProgramId() {
        return this.positionMintTokenProgramId;
    }
    getData() {
        return this.data;
    }
    getWhirlpoolData() {
        return this.whirlpoolData;
    }
    getLowerTickData() {
        return public_1.TickArrayUtil.getTickFromArray(this.lowerTickArrayData, this.data.tickLowerIndex, this.whirlpoolData.tickSpacing);
    }
    getUpperTickData() {
        return public_1.TickArrayUtil.getTickFromArray(this.upperTickArrayData, this.data.tickUpperIndex, this.whirlpoolData.tickSpacing);
    }
    async refreshData() {
        await this.refresh();
        return this.data;
    }
    async increaseLiquidity(liquidityInput, resolveATA = true, sourceWallet, positionWallet, ataPayer) {
        const sourceWalletKey = sourceWallet ? common_sdk_1.AddressUtil.toPubKey(sourceWallet) : this.ctx.wallet.publicKey;
        const positionWalletKey = positionWallet ? common_sdk_1.AddressUtil.toPubKey(positionWallet) : this.ctx.wallet.publicKey;
        const ataPayerKey = ataPayer ? common_sdk_1.AddressUtil.toPubKey(ataPayer) : this.ctx.wallet.publicKey;
        const whirlpool = await this.ctx.fetcher.getPool(this.data.whirlpool, fetcher_1.IGNORE_CACHE);
        if (!whirlpool) {
            throw new Error("Unable to fetch whirlpool for this position.");
        }
        const tokenExtensionCtx = await token_extension_util_1.TokenExtensionUtil.buildTokenExtensionContext(this.ctx.fetcher, whirlpool, fetcher_1.IGNORE_CACHE);
        const txBuilder = new common_sdk_1.TransactionBuilder(this.ctx.provider.connection, this.ctx.provider.wallet, this.ctx.txBuilderOpts);
        let tokenOwnerAccountA;
        let tokenOwnerAccountB;
        if (resolveATA) {
            const [ataA, ataB] = await (0, common_sdk_1.resolveOrCreateATAs)(this.ctx.connection, sourceWalletKey, [
                {
                    tokenMint: whirlpool.tokenMintA,
                    wrappedSolAmountIn: liquidityInput.tokenMaxA
                },
                {
                    tokenMint: whirlpool.tokenMintB,
                    wrappedSolAmountIn: liquidityInput.tokenMaxB
                }
            ], ()=>this.ctx.fetcher.getAccountRentExempt(), ataPayerKey, undefined, this.ctx.accountResolverOpts.allowPDAOwnerAddress, this.ctx.accountResolverOpts.createWrappedSolAccountMethod);
            const { address: ataAddrA, ...tokenOwnerAccountAIx } = ataA;
            const { address: ataAddrB, ...tokenOwnerAccountBIx } = ataB;
            tokenOwnerAccountA = ataAddrA;
            tokenOwnerAccountB = ataAddrB;
            txBuilder.addInstruction(tokenOwnerAccountAIx);
            txBuilder.addInstruction(tokenOwnerAccountBIx);
        } else {
            tokenOwnerAccountA = (0, spl_token_1.getAssociatedTokenAddressSync)(whirlpool.tokenMintA, sourceWalletKey, this.ctx.accountResolverOpts.allowPDAOwnerAddress, tokenExtensionCtx.tokenMintWithProgramA.tokenProgram);
            tokenOwnerAccountB = (0, spl_token_1.getAssociatedTokenAddressSync)(whirlpool.tokenMintB, sourceWalletKey, this.ctx.accountResolverOpts.allowPDAOwnerAddress, tokenExtensionCtx.tokenMintWithProgramB.tokenProgram);
        }
        const positionTokenAccount = (0, spl_token_1.getAssociatedTokenAddressSync)(this.data.positionMint, positionWalletKey, this.ctx.accountResolverOpts.allowPDAOwnerAddress, this.positionMintTokenProgramId);
        const baseParams = {
            ...liquidityInput,
            whirlpool: this.data.whirlpool,
            position: this.address,
            positionTokenAccount,
            tokenOwnerAccountA,
            tokenOwnerAccountB,
            tokenVaultA: whirlpool.tokenVaultA,
            tokenVaultB: whirlpool.tokenVaultB,
            tickArrayLower: public_1.PDAUtil.getTickArray(this.ctx.program.programId, this.data.whirlpool, public_1.TickUtil.getStartTickIndex(this.data.tickLowerIndex, whirlpool.tickSpacing)).publicKey,
            tickArrayUpper: public_1.PDAUtil.getTickArray(this.ctx.program.programId, this.data.whirlpool, public_1.TickUtil.getStartTickIndex(this.data.tickUpperIndex, whirlpool.tickSpacing)).publicKey,
            positionAuthority: positionWalletKey
        };
        const increaseIx = !token_extension_util_1.TokenExtensionUtil.isV2IxRequiredPool(tokenExtensionCtx) ? (0, instructions_1.increaseLiquidityIx)(this.ctx.program, baseParams) : (0, instructions_1.increaseLiquidityV2Ix)(this.ctx.program, {
            ...baseParams,
            tokenMintA: whirlpool.tokenMintA,
            tokenMintB: whirlpool.tokenMintB,
            tokenProgramA: tokenExtensionCtx.tokenMintWithProgramA.tokenProgram,
            tokenProgramB: tokenExtensionCtx.tokenMintWithProgramB.tokenProgram,
            ...await token_extension_util_1.TokenExtensionUtil.getExtraAccountMetasForTransferHookForPool(this.ctx.connection, tokenExtensionCtx, baseParams.tokenOwnerAccountA, baseParams.tokenVaultA, baseParams.positionAuthority, baseParams.tokenOwnerAccountB, baseParams.tokenVaultB, baseParams.positionAuthority)
        });
        txBuilder.addInstruction(increaseIx);
        return txBuilder;
    }
    async decreaseLiquidity(liquidityInput, resolveATA = true, sourceWallet, positionWallet, ataPayer) {
        const sourceWalletKey = sourceWallet ? common_sdk_1.AddressUtil.toPubKey(sourceWallet) : this.ctx.wallet.publicKey;
        const positionWalletKey = positionWallet ? common_sdk_1.AddressUtil.toPubKey(positionWallet) : this.ctx.wallet.publicKey;
        const ataPayerKey = ataPayer ? common_sdk_1.AddressUtil.toPubKey(ataPayer) : this.ctx.wallet.publicKey;
        const whirlpool = await this.ctx.fetcher.getPool(this.data.whirlpool, fetcher_1.IGNORE_CACHE);
        if (!whirlpool) {
            throw new Error("Unable to fetch whirlpool for this position.");
        }
        const tokenExtensionCtx = await token_extension_util_1.TokenExtensionUtil.buildTokenExtensionContext(this.ctx.fetcher, whirlpool, fetcher_1.IGNORE_CACHE);
        const txBuilder = new common_sdk_1.TransactionBuilder(this.ctx.provider.connection, this.ctx.provider.wallet, this.ctx.txBuilderOpts);
        let tokenOwnerAccountA;
        let tokenOwnerAccountB;
        if (resolveATA) {
            const [ataA, ataB] = await (0, common_sdk_1.resolveOrCreateATAs)(this.ctx.connection, sourceWalletKey, [
                {
                    tokenMint: whirlpool.tokenMintA
                },
                {
                    tokenMint: whirlpool.tokenMintB
                }
            ], ()=>this.ctx.fetcher.getAccountRentExempt(), ataPayerKey, undefined, this.ctx.accountResolverOpts.allowPDAOwnerAddress, this.ctx.accountResolverOpts.createWrappedSolAccountMethod);
            const { address: ataAddrA, ...tokenOwnerAccountAIx } = ataA;
            const { address: ataAddrB, ...tokenOwnerAccountBIx } = ataB;
            tokenOwnerAccountA = ataAddrA;
            tokenOwnerAccountB = ataAddrB;
            txBuilder.addInstruction(tokenOwnerAccountAIx);
            txBuilder.addInstruction(tokenOwnerAccountBIx);
        } else {
            tokenOwnerAccountA = (0, spl_token_1.getAssociatedTokenAddressSync)(whirlpool.tokenMintA, sourceWalletKey, this.ctx.accountResolverOpts.allowPDAOwnerAddress, tokenExtensionCtx.tokenMintWithProgramA.tokenProgram);
            tokenOwnerAccountB = (0, spl_token_1.getAssociatedTokenAddressSync)(whirlpool.tokenMintB, sourceWalletKey, this.ctx.accountResolverOpts.allowPDAOwnerAddress, tokenExtensionCtx.tokenMintWithProgramB.tokenProgram);
        }
        const baseParams = {
            ...liquidityInput,
            whirlpool: this.data.whirlpool,
            position: this.address,
            positionTokenAccount: (0, spl_token_1.getAssociatedTokenAddressSync)(this.data.positionMint, positionWalletKey, this.ctx.accountResolverOpts.allowPDAOwnerAddress, this.positionMintTokenProgramId),
            tokenOwnerAccountA,
            tokenOwnerAccountB,
            tokenVaultA: whirlpool.tokenVaultA,
            tokenVaultB: whirlpool.tokenVaultB,
            tickArrayLower: public_1.PDAUtil.getTickArray(this.ctx.program.programId, this.data.whirlpool, public_1.TickUtil.getStartTickIndex(this.data.tickLowerIndex, whirlpool.tickSpacing)).publicKey,
            tickArrayUpper: public_1.PDAUtil.getTickArray(this.ctx.program.programId, this.data.whirlpool, public_1.TickUtil.getStartTickIndex(this.data.tickUpperIndex, whirlpool.tickSpacing)).publicKey,
            positionAuthority: positionWalletKey
        };
        const decreaseIx = !token_extension_util_1.TokenExtensionUtil.isV2IxRequiredPool(tokenExtensionCtx) ? (0, instructions_1.decreaseLiquidityIx)(this.ctx.program, baseParams) : (0, instructions_1.decreaseLiquidityV2Ix)(this.ctx.program, {
            ...baseParams,
            tokenMintA: whirlpool.tokenMintA,
            tokenMintB: whirlpool.tokenMintB,
            tokenProgramA: tokenExtensionCtx.tokenMintWithProgramA.tokenProgram,
            tokenProgramB: tokenExtensionCtx.tokenMintWithProgramB.tokenProgram,
            ...await token_extension_util_1.TokenExtensionUtil.getExtraAccountMetasForTransferHookForPool(this.ctx.connection, tokenExtensionCtx, baseParams.tokenVaultA, baseParams.tokenOwnerAccountA, baseParams.whirlpool, baseParams.tokenVaultB, baseParams.tokenOwnerAccountB, baseParams.whirlpool)
        });
        txBuilder.addInstruction(decreaseIx);
        return txBuilder;
    }
    async collectFees(updateFeesAndRewards = true, ownerTokenAccountMap, destinationWallet, positionWallet, ataPayer, opts = fetcher_1.PREFER_CACHE) {
        const [destinationWalletKey, positionWalletKey, ataPayerKey] = common_sdk_1.AddressUtil.toPubKeys([
            destinationWallet ?? this.ctx.wallet.publicKey,
            positionWallet ?? this.ctx.wallet.publicKey,
            ataPayer ?? this.ctx.wallet.publicKey
        ]);
        const whirlpool = await this.ctx.fetcher.getPool(this.data.whirlpool, opts);
        if (!whirlpool) {
            throw new Error(`Unable to fetch whirlpool (${this.data.whirlpool}) for this position (${this.address}).`);
        }
        const tokenExtensionCtx = await token_extension_util_1.TokenExtensionUtil.buildTokenExtensionContext(this.ctx.fetcher, whirlpool, fetcher_1.IGNORE_CACHE);
        let txBuilder = new common_sdk_1.TransactionBuilder(this.ctx.provider.connection, this.ctx.provider.wallet, this.ctx.txBuilderOpts);
        const accountExemption = await this.ctx.fetcher.getAccountRentExempt();
        let ataMap = {
            ...ownerTokenAccountMap
        };
        if (!ownerTokenAccountMap) {
            const affliatedMints = (0, whirlpool_ata_utils_1.getTokenMintsFromWhirlpools)([
                whirlpool
            ], whirlpool_ata_utils_1.TokenMintTypes.POOL_ONLY);
            const { ataTokenAddresses: affliatedTokenAtaMap, resolveAtaIxs } = await (0, whirlpool_ata_utils_1.resolveAtaForMints)(this.ctx, {
                mints: affliatedMints.mintMap,
                accountExemption,
                receiver: destinationWalletKey,
                payer: ataPayerKey
            });
            txBuilder.addInstructions(resolveAtaIxs);
            if (affliatedMints.hasNativeMint) {
                let { address: wSOLAta, ...resolveWSolIx } = common_sdk_1.TokenUtil.createWrappedNativeAccountInstruction(destinationWalletKey, common_sdk_1.ZERO, accountExemption, ataPayerKey, destinationWalletKey, this.ctx.accountResolverOpts.createWrappedSolAccountMethod);
                affliatedTokenAtaMap[spl_token_1.NATIVE_MINT.toBase58()] = wSOLAta;
                txBuilder.addInstruction(resolveWSolIx);
            }
            ataMap = {
                ...affliatedTokenAtaMap
            };
        }
        const tokenOwnerAccountA = ataMap[whirlpool.tokenMintA.toBase58()];
        (0, tiny_invariant_1.default)(!!tokenOwnerAccountA, `No owner token account provided for wallet ${destinationWalletKey.toBase58()} for token A ${whirlpool.tokenMintA.toBase58()} `);
        const tokenOwnerAccountB = ataMap[whirlpool.tokenMintB.toBase58()];
        (0, tiny_invariant_1.default)(!!tokenOwnerAccountB, `No owner token account provided for wallet ${destinationWalletKey.toBase58()} for token B ${whirlpool.tokenMintB.toBase58()} `);
        const positionTokenAccount = (0, spl_token_1.getAssociatedTokenAddressSync)(this.data.positionMint, positionWalletKey, this.ctx.accountResolverOpts.allowPDAOwnerAddress, this.positionMintTokenProgramId);
        if (updateFeesAndRewards && !this.data.liquidity.isZero()) {
            const updateIx = await this.updateFeesAndRewards();
            txBuilder.addInstruction(updateIx);
        }
        const baseParams = {
            whirlpool: this.data.whirlpool,
            position: this.address,
            positionTokenAccount,
            tokenOwnerAccountA: common_sdk_1.AddressUtil.toPubKey(tokenOwnerAccountA),
            tokenOwnerAccountB: common_sdk_1.AddressUtil.toPubKey(tokenOwnerAccountB),
            tokenVaultA: whirlpool.tokenVaultA,
            tokenVaultB: whirlpool.tokenVaultB,
            positionAuthority: positionWalletKey
        };
        const ix = !token_extension_util_1.TokenExtensionUtil.isV2IxRequiredPool(tokenExtensionCtx) ? (0, instructions_1.collectFeesIx)(this.ctx.program, baseParams) : (0, instructions_1.collectFeesV2Ix)(this.ctx.program, {
            ...baseParams,
            tokenMintA: whirlpool.tokenMintA,
            tokenMintB: whirlpool.tokenMintB,
            tokenProgramA: tokenExtensionCtx.tokenMintWithProgramA.tokenProgram,
            tokenProgramB: tokenExtensionCtx.tokenMintWithProgramB.tokenProgram,
            ...await token_extension_util_1.TokenExtensionUtil.getExtraAccountMetasForTransferHookForPool(this.ctx.connection, tokenExtensionCtx, baseParams.tokenVaultA, baseParams.tokenOwnerAccountA, baseParams.whirlpool, baseParams.tokenVaultB, baseParams.tokenOwnerAccountB, baseParams.whirlpool)
        });
        txBuilder.addInstruction(ix);
        return txBuilder;
    }
    async collectRewards(rewardsToCollect, updateFeesAndRewards = true, ownerTokenAccountMap, destinationWallet, positionWallet, ataPayer, opts = fetcher_1.IGNORE_CACHE) {
        const [destinationWalletKey, positionWalletKey, ataPayerKey] = common_sdk_1.AddressUtil.toPubKeys([
            destinationWallet ?? this.ctx.wallet.publicKey,
            positionWallet ?? this.ctx.wallet.publicKey,
            ataPayer ?? this.ctx.wallet.publicKey
        ]);
        const whirlpool = await this.ctx.fetcher.getPool(this.data.whirlpool, opts);
        if (!whirlpool) {
            throw new Error(`Unable to fetch whirlpool(${this.data.whirlpool}) for this position(${this.address}).`);
        }
        const initializedRewards = whirlpool.rewardInfos.filter((info)=>public_1.PoolUtil.isRewardInitialized(info));
        const tokenExtensionCtx = await token_extension_util_1.TokenExtensionUtil.buildTokenExtensionContext(this.ctx.fetcher, whirlpool, fetcher_1.IGNORE_CACHE);
        let resolvedAtas;
        if (ownerTokenAccountMap) {
            resolvedAtas = {};
            Object.entries(ownerTokenAccountMap).forEach(([mint, address])=>{
                if (!address) return;
                resolvedAtas[mint] = {
                    address: common_sdk_1.AddressUtil.toPubKey(address),
                    instructions: [],
                    cleanupInstructions: [],
                    signers: [],
                    tokenProgram: web3_js_1.PublicKey.default
                };
            });
        } else {
            const accountExemption = await this.ctx.fetcher.getAccountRentExempt();
            const rewardMints = (0, whirlpool_ata_utils_1.getTokenMintsFromWhirlpools)([
                whirlpool
            ], whirlpool_ata_utils_1.TokenMintTypes.REWARD_ONLY);
            resolvedAtas = (0, txn_utils_1.convertListToMap)(await (0, common_sdk_1.resolveOrCreateATAs)(this.ctx.connection, destinationWalletKey, rewardMints.mintMap.map((tokenMint)=>({
                    tokenMint
                })), async ()=>accountExemption, ataPayerKey, true, this.ctx.accountResolverOpts.allowPDAOwnerAddress), rewardMints.mintMap.map((mint)=>mint.toBase58()));
        }
        const builder = new txn_utils_1.MultipleTransactionBuilderFactoryWithAccountResolver(this.ctx, resolvedAtas, destinationWalletKey, ataPayerKey);
        const positionTokenAccount = (0, spl_token_1.getAssociatedTokenAddressSync)(this.data.positionMint, positionWalletKey, this.ctx.accountResolverOpts.allowPDAOwnerAddress, this.positionMintTokenProgramId);
        if (updateFeesAndRewards && !this.data.liquidity.isZero()) {
            await builder.addInstructions(async ()=>{
                const updateIx = await this.updateFeesAndRewards();
                return [
                    updateIx
                ];
            });
        }
        for(let index = 0; index < initializedRewards.length; index++){
            const info = initializedRewards[index];
            if (rewardsToCollect && !rewardsToCollect.some((r)=>r.toString() === info.mint.toBase58())) {
                break;
            }
            await builder.addInstructions(async (resolve)=>{
                const rewardOwnerAccount = resolve(info.mint.toBase58());
                (0, tiny_invariant_1.default)(!!rewardOwnerAccount, `No owner token account provided for wallet ${destinationWalletKey.toBase58()} for reward ${index} token ${info.mint.toBase58()} `);
                const baseParams = {
                    whirlpool: this.data.whirlpool,
                    position: this.address,
                    positionTokenAccount,
                    rewardIndex: index,
                    rewardOwnerAccount: common_sdk_1.AddressUtil.toPubKey(rewardOwnerAccount),
                    rewardVault: info.vault,
                    positionAuthority: positionWalletKey
                };
                const ix = !token_extension_util_1.TokenExtensionUtil.isV2IxRequiredReward(tokenExtensionCtx, index) ? (0, instructions_1.collectRewardIx)(this.ctx.program, baseParams) : (0, instructions_1.collectRewardV2Ix)(this.ctx.program, {
                    ...baseParams,
                    rewardMint: info.mint,
                    rewardTokenProgram: tokenExtensionCtx.rewardTokenMintsWithProgram[index].tokenProgram,
                    rewardTransferHookAccounts: await token_extension_util_1.TokenExtensionUtil.getExtraAccountMetasForTransferHook(this.ctx.connection, tokenExtensionCtx.rewardTokenMintsWithProgram[index], baseParams.rewardVault, baseParams.rewardOwnerAccount, baseParams.whirlpool)
                });
                return [
                    ix
                ];
            });
        }
        return builder.build();
    }
    async refresh() {
        const positionAccount = await this.ctx.fetcher.getPosition(this.address, fetcher_1.IGNORE_CACHE);
        if (!!positionAccount) {
            this.data = positionAccount;
        }
        const whirlpoolAccount = await this.ctx.fetcher.getPool(this.data.whirlpool, fetcher_1.IGNORE_CACHE);
        if (!!whirlpoolAccount) {
            this.whirlpoolData = whirlpoolAccount;
        }
        const [lowerTickArray, upperTickArray] = await (0, position_builder_util_1.getTickArrayDataForPosition)(this.ctx, this.data, this.whirlpoolData, fetcher_1.IGNORE_CACHE);
        if (lowerTickArray) {
            this.lowerTickArrayData = lowerTickArray;
        }
        if (upperTickArray) {
            this.upperTickArrayData = upperTickArray;
        }
    }
    async updateFeesAndRewards() {
        const whirlpool = await this.ctx.fetcher.getPool(this.data.whirlpool);
        if (!whirlpool) {
            throw new Error(`Unable to fetch whirlpool(${this.data.whirlpool}) for this position(${this.address}).`);
        }
        const [tickArrayLowerPda, tickArrayUpperPda] = [
            this.data.tickLowerIndex,
            this.data.tickUpperIndex
        ].map((tickIndex)=>public_1.PDAUtil.getTickArrayFromTickIndex(tickIndex, whirlpool.tickSpacing, this.data.whirlpool, this.ctx.program.programId));
        const updateIx = (0, instructions_1.updateFeesAndRewardsIx)(this.ctx.program, {
            whirlpool: this.data.whirlpool,
            position: this.address,
            tickArrayLower: tickArrayLowerPda.publicKey,
            tickArrayUpper: tickArrayUpperPda.publicKey
        });
        return updateIx;
    }
}
exports.PositionImpl = PositionImpl; //# sourceMappingURL=position-impl.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/math/swap-math.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.computeSwapStep = computeSwapStep;
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const bit_math_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/math/bit-math.js [app-route] (ecmascript)");
const token_math_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/math/token-math.js [app-route] (ecmascript)");
function computeSwapStep(amountRemaining, feeRate, currLiquidity, currSqrtPrice, targetSqrtPrice, amountSpecifiedIsInput, aToB) {
    let initialAmountFixedDelta = tryGetAmountFixedDelta(currSqrtPrice, targetSqrtPrice, currLiquidity, amountSpecifiedIsInput, aToB);
    let amountCalc = amountRemaining;
    if (amountSpecifiedIsInput) {
        const result = bit_math_1.BitMath.mulDiv(amountRemaining, public_1.FEE_RATE_MUL_VALUE.sub(new bn_js_1.default(feeRate)), public_1.FEE_RATE_MUL_VALUE, 128);
        amountCalc = result;
    }
    let nextSqrtPrice = initialAmountFixedDelta.lte(amountCalc) ? targetSqrtPrice : (0, token_math_1.getNextSqrtPrice)(currSqrtPrice, currLiquidity, amountCalc, amountSpecifiedIsInput, aToB);
    let isMaxSwap = nextSqrtPrice.eq(targetSqrtPrice);
    let amountUnfixedDelta = getAmountUnfixedDelta(currSqrtPrice, nextSqrtPrice, currLiquidity, amountSpecifiedIsInput, aToB);
    let amountFixedDelta = !isMaxSwap || initialAmountFixedDelta.exceedsMax() ? getAmountFixedDelta(currSqrtPrice, nextSqrtPrice, currLiquidity, amountSpecifiedIsInput, aToB) : initialAmountFixedDelta.value();
    let amountIn = amountSpecifiedIsInput ? amountFixedDelta : amountUnfixedDelta;
    let amountOut = amountSpecifiedIsInput ? amountUnfixedDelta : amountFixedDelta;
    if (!amountSpecifiedIsInput && amountOut.gt(amountRemaining)) {
        amountOut = amountRemaining;
    }
    let feeAmount;
    if (amountSpecifiedIsInput && !isMaxSwap) {
        feeAmount = amountRemaining.sub(amountIn);
    } else {
        const feeRateBN = new bn_js_1.default(feeRate);
        feeAmount = bit_math_1.BitMath.mulDivRoundUp(amountIn, feeRateBN, public_1.FEE_RATE_MUL_VALUE.sub(feeRateBN), 128);
    }
    return {
        amountIn,
        amountOut,
        nextPrice: nextSqrtPrice,
        feeAmount
    };
}
function getAmountFixedDelta(currSqrtPrice, targetSqrtPrice, currLiquidity, amountSpecifiedIsInput, aToB) {
    if (aToB === amountSpecifiedIsInput) {
        return (0, token_math_1.getAmountDeltaA)(currSqrtPrice, targetSqrtPrice, currLiquidity, amountSpecifiedIsInput);
    } else {
        return (0, token_math_1.getAmountDeltaB)(currSqrtPrice, targetSqrtPrice, currLiquidity, amountSpecifiedIsInput);
    }
}
function tryGetAmountFixedDelta(currSqrtPrice, targetSqrtPrice, currLiquidity, amountSpecifiedIsInput, aToB) {
    if (aToB === amountSpecifiedIsInput) {
        return (0, token_math_1.tryGetAmountDeltaA)(currSqrtPrice, targetSqrtPrice, currLiquidity, amountSpecifiedIsInput);
    } else {
        return (0, token_math_1.tryGetAmountDeltaB)(currSqrtPrice, targetSqrtPrice, currLiquidity, amountSpecifiedIsInput);
    }
}
function getAmountUnfixedDelta(currSqrtPrice, targetSqrtPrice, currLiquidity, amountSpecifiedIsInput, aToB) {
    if (aToB === amountSpecifiedIsInput) {
        return (0, token_math_1.getAmountDeltaB)(currSqrtPrice, targetSqrtPrice, currLiquidity, !amountSpecifiedIsInput);
    } else {
        return (0, token_math_1.getAmountDeltaA)(currSqrtPrice, targetSqrtPrice, currLiquidity, !amountSpecifiedIsInput);
    }
} //# sourceMappingURL=swap-math.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/swap/swap-manager.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.computeSwap = computeSwap;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const swap_math_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/math/swap-math.js [app-route] (ecmascript)");
const public_2 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const errors_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/errors/errors.js [app-route] (ecmascript)");
function computeSwap(whirlpoolData, tickSequence, tokenAmount, sqrtPriceLimit, amountSpecifiedIsInput, aToB) {
    let amountRemaining = tokenAmount;
    let amountCalculated = common_sdk_1.ZERO;
    let currSqrtPrice = whirlpoolData.sqrtPrice;
    let currLiquidity = whirlpoolData.liquidity;
    let currTickIndex = whirlpoolData.tickCurrentIndex;
    let totalFeeAmount = common_sdk_1.ZERO;
    const feeRate = whirlpoolData.feeRate;
    const protocolFeeRate = whirlpoolData.protocolFeeRate;
    let currProtocolFee = new bn_js_1.default(0);
    let currFeeGrowthGlobalInput = aToB ? whirlpoolData.feeGrowthGlobalA : whirlpoolData.feeGrowthGlobalB;
    while(amountRemaining.gt(common_sdk_1.ZERO) && !sqrtPriceLimit.eq(currSqrtPrice)){
        let { nextIndex: nextTickIndex } = tickSequence.findNextInitializedTickIndex(currTickIndex);
        let { nextTickPrice, nextSqrtPriceLimit: targetSqrtPrice } = getNextSqrtPrices(nextTickIndex, sqrtPriceLimit, aToB);
        const swapComputation = (0, swap_math_1.computeSwapStep)(amountRemaining, feeRate, currLiquidity, currSqrtPrice, targetSqrtPrice, amountSpecifiedIsInput, aToB);
        totalFeeAmount = totalFeeAmount.add(swapComputation.feeAmount);
        if (amountSpecifiedIsInput) {
            amountRemaining = amountRemaining.sub(swapComputation.amountIn);
            amountRemaining = amountRemaining.sub(swapComputation.feeAmount);
            amountCalculated = amountCalculated.add(swapComputation.amountOut);
        } else {
            amountRemaining = amountRemaining.sub(swapComputation.amountOut);
            amountCalculated = amountCalculated.add(swapComputation.amountIn);
            amountCalculated = amountCalculated.add(swapComputation.feeAmount);
        }
        if (amountRemaining.isNeg()) {
            throw new errors_1.WhirlpoolsError("Amount remaining is negative.", errors_1.SwapErrorCode.AmountRemainingOverflow);
        }
        if (amountCalculated.gt(common_sdk_1.U64_MAX)) {
            throw new errors_1.WhirlpoolsError("Amount calculated is greater than U64_MAX.", errors_1.SwapErrorCode.AmountCalcOverflow);
        }
        let { nextProtocolFee, nextFeeGrowthGlobalInput } = calculateFees(swapComputation.feeAmount, protocolFeeRate, currLiquidity, currProtocolFee, currFeeGrowthGlobalInput);
        currProtocolFee = nextProtocolFee;
        currFeeGrowthGlobalInput = nextFeeGrowthGlobalInput;
        if (swapComputation.nextPrice.eq(nextTickPrice)) {
            const nextTick = tickSequence.getTick(nextTickIndex);
            if (nextTick.initialized) {
                currLiquidity = calculateNextLiquidity(nextTick.liquidityNet, currLiquidity, aToB);
            }
            currTickIndex = aToB ? nextTickIndex - 1 : nextTickIndex;
        } else {
            currTickIndex = public_2.PriceMath.sqrtPriceX64ToTickIndex(swapComputation.nextPrice);
        }
        currSqrtPrice = swapComputation.nextPrice;
    }
    let { amountA, amountB } = calculateEstTokens(tokenAmount, amountRemaining, amountCalculated, aToB, amountSpecifiedIsInput);
    return {
        amountA,
        amountB,
        nextTickIndex: currTickIndex,
        nextSqrtPrice: currSqrtPrice,
        totalFeeAmount
    };
}
function getNextSqrtPrices(nextTick, sqrtPriceLimit, aToB) {
    const nextTickPrice = public_2.PriceMath.tickIndexToSqrtPriceX64(nextTick);
    const nextSqrtPriceLimit = aToB ? bn_js_1.default.max(sqrtPriceLimit, nextTickPrice) : bn_js_1.default.min(sqrtPriceLimit, nextTickPrice);
    return {
        nextTickPrice,
        nextSqrtPriceLimit
    };
}
function calculateFees(feeAmount, protocolFeeRate, currLiquidity, currProtocolFee, currFeeGrowthGlobalInput) {
    let nextProtocolFee = currProtocolFee;
    let nextFeeGrowthGlobalInput = currFeeGrowthGlobalInput;
    let globalFee = feeAmount;
    if (protocolFeeRate > 0) {
        let delta = calculateProtocolFee(globalFee, protocolFeeRate);
        globalFee = globalFee.sub(delta);
        nextProtocolFee = nextProtocolFee.add(currProtocolFee);
    }
    if (currLiquidity.gt(common_sdk_1.ZERO)) {
        const globalFeeIncrement = globalFee.shln(64).div(currLiquidity);
        nextFeeGrowthGlobalInput = nextFeeGrowthGlobalInput.add(globalFeeIncrement);
    }
    return {
        nextProtocolFee,
        nextFeeGrowthGlobalInput
    };
}
function calculateProtocolFee(globalFee, protocolFeeRate) {
    return globalFee.mul(new bn_js_1.default(protocolFeeRate).div(public_1.PROTOCOL_FEE_RATE_MUL_VALUE));
}
function calculateEstTokens(amount, amountRemaining, amountCalculated, aToB, amountSpecifiedIsInput) {
    return aToB === amountSpecifiedIsInput ? {
        amountA: amount.sub(amountRemaining),
        amountB: amountCalculated
    } : {
        amountA: amountCalculated,
        amountB: amount.sub(amountRemaining)
    };
}
function calculateNextLiquidity(tickNetLiquidity, currLiquidity, aToB) {
    return aToB ? currLiquidity.sub(tickNetLiquidity) : currLiquidity.add(tickNetLiquidity);
} //# sourceMappingURL=swap-manager.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/swap/tick-array-index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TickArrayIndex = void 0;
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
class TickArrayIndex {
    arrayIndex;
    offsetIndex;
    tickSpacing;
    static fromTickIndex(index, tickSpacing) {
        const arrayIndex = Math.floor(Math.floor(index / tickSpacing) / public_1.TICK_ARRAY_SIZE);
        let offsetIndex = Math.floor(index % (tickSpacing * public_1.TICK_ARRAY_SIZE) / tickSpacing);
        if (offsetIndex < 0) {
            offsetIndex = public_1.TICK_ARRAY_SIZE + offsetIndex;
        }
        return new TickArrayIndex(arrayIndex, offsetIndex, tickSpacing);
    }
    constructor(arrayIndex, offsetIndex, tickSpacing){
        this.arrayIndex = arrayIndex;
        this.offsetIndex = offsetIndex;
        this.tickSpacing = tickSpacing;
        if (offsetIndex >= public_1.TICK_ARRAY_SIZE) {
            throw new Error("Invalid offsetIndex - value has to be smaller than TICK_ARRAY_SIZE");
        }
        if (offsetIndex < 0) {
            throw new Error("Invalid offsetIndex - value is smaller than 0");
        }
        if (tickSpacing < 0) {
            throw new Error("Invalid tickSpacing - value is less than 0");
        }
    }
    toTickIndex() {
        return this.arrayIndex * public_1.TICK_ARRAY_SIZE * this.tickSpacing + this.offsetIndex * this.tickSpacing;
    }
    toNextInitializableTickIndex() {
        return TickArrayIndex.fromTickIndex(this.toTickIndex() + this.tickSpacing, this.tickSpacing);
    }
    toPrevInitializableTickIndex() {
        return TickArrayIndex.fromTickIndex(this.toTickIndex() - this.tickSpacing, this.tickSpacing);
    }
}
exports.TickArrayIndex = TickArrayIndex; //# sourceMappingURL=tick-array-index.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/swap/tick-array-sequence.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TickArraySequence = void 0;
const errors_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/errors/errors.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const tick_array_index_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/swap/tick-array-index.js [app-route] (ecmascript)");
class TickArraySequence {
    tickSpacing;
    aToB;
    sequence;
    touchedArrays;
    startArrayIndex;
    constructor(tickArrays, tickSpacing, aToB){
        this.tickSpacing = tickSpacing;
        this.aToB = aToB;
        if (!tickArrays[0] || !tickArrays[0].data) {
            throw new Error("TickArray index 0 must be initialized");
        }
        this.sequence = [];
        for (const tickArray of tickArrays){
            if (!tickArray || !tickArray.data) {
                break;
            }
            this.sequence.push({
                address: tickArray.address,
                startTickIndex: tickArray.data.startTickIndex,
                data: tickArray.data
            });
        }
        this.touchedArrays = [
            ...Array(this.sequence.length).fill(false)
        ];
        this.startArrayIndex = tick_array_index_1.TickArrayIndex.fromTickIndex(this.sequence[0].data.startTickIndex, this.tickSpacing).arrayIndex;
    }
    isValidTickArray0(tickCurrentIndex) {
        const shift = this.aToB ? 0 : this.tickSpacing;
        const tickArray = this.sequence[0].data;
        return this.checkIfIndexIsInTickArrayRange(tickArray.startTickIndex, tickCurrentIndex + shift);
    }
    getNumOfTouchedArrays() {
        return this.touchedArrays.filter((val)=>!!val).length;
    }
    getTouchedArrays(minArraySize) {
        let result = this.touchedArrays.reduce((prev, curr, index)=>{
            if (curr) {
                prev.push(this.sequence[index].address);
            }
            return prev;
        }, []);
        if (result.length === 0) {
            return [];
        }
        const sizeDiff = minArraySize - result.length;
        if (sizeDiff > 0) {
            result = result.concat(Array(sizeDiff).fill(result[result.length - 1]));
        }
        return result;
    }
    getTick(index) {
        const targetTaIndex = tick_array_index_1.TickArrayIndex.fromTickIndex(index, this.tickSpacing);
        if (!this.isArrayIndexInBounds(targetTaIndex, this.aToB)) {
            throw new Error("Provided tick index is out of bounds for this sequence.");
        }
        const localArrayIndex = this.getLocalArrayIndex(targetTaIndex.arrayIndex, this.aToB);
        const tickArray = this.sequence[localArrayIndex].data;
        this.touchedArrays[localArrayIndex] = true;
        if (!tickArray) {
            throw new errors_1.WhirlpoolsError(`TickArray at index ${localArrayIndex} is not initialized.`, errors_1.SwapErrorCode.TickArrayIndexNotInitialized);
        }
        if (!this.checkIfIndexIsInTickArrayRange(tickArray.startTickIndex, index)) {
            throw new errors_1.WhirlpoolsError(`TickArray at index ${localArrayIndex} is unexpected for this sequence.`, errors_1.SwapErrorCode.TickArraySequenceInvalid);
        }
        return tickArray.ticks[targetTaIndex.offsetIndex];
    }
    findNextInitializedTickIndex(currIndex) {
        const searchIndex = this.aToB ? currIndex : currIndex + this.tickSpacing;
        let currTaIndex = tick_array_index_1.TickArrayIndex.fromTickIndex(searchIndex, this.tickSpacing);
        if (!this.isArrayIndexInBounds(currTaIndex, this.aToB)) {
            throw new errors_1.WhirlpoolsError(`Swap input value traversed too many arrays. Out of bounds at attempt to traverse tick index - ${currTaIndex.toTickIndex()}.`, errors_1.SwapErrorCode.TickArraySequenceInvalid);
        }
        while(this.isArrayIndexInBounds(currTaIndex, this.aToB)){
            const currTickData = this.getTick(currTaIndex.toTickIndex());
            if (currTickData.initialized) {
                return {
                    nextIndex: currTaIndex.toTickIndex(),
                    nextTickData: currTickData
                };
            }
            currTaIndex = this.aToB ? currTaIndex.toPrevInitializableTickIndex() : currTaIndex.toNextInitializableTickIndex();
        }
        const lastIndexInArray = Math.max(Math.min(this.aToB ? currTaIndex.toTickIndex() + this.tickSpacing : currTaIndex.toTickIndex() - 1, public_1.MAX_TICK_INDEX), public_1.MIN_TICK_INDEX);
        return {
            nextIndex: lastIndexInArray,
            nextTickData: null
        };
    }
    getLocalArrayIndex(arrayIndex, aToB) {
        return aToB ? this.startArrayIndex - arrayIndex : arrayIndex - this.startArrayIndex;
    }
    isArrayIndexInBounds(index, aToB) {
        const localArrayIndex = this.getLocalArrayIndex(index.arrayIndex, aToB);
        const seqLength = this.sequence.length;
        return localArrayIndex >= 0 && localArrayIndex < seqLength;
    }
    checkIfIndexIsInTickArrayRange(startTick, tickIndex) {
        const upperBound = startTick + this.tickSpacing * public_1.TICK_ARRAY_SIZE;
        return tickIndex >= startTick && tickIndex < upperBound;
    }
}
exports.TickArraySequence = TickArraySequence; //# sourceMappingURL=tick-array-sequence.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/swap/swap-quote-impl.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.simulateSwap = simulateSwap;
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const errors_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/errors/errors.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const swap_manager_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/swap/swap-manager.js [app-route] (ecmascript)");
const tick_array_sequence_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/swap/tick-array-sequence.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
function simulateSwap(params) {
    const { aToB, whirlpoolData, tickArrays, tokenAmount, sqrtPriceLimit, otherAmountThreshold, amountSpecifiedIsInput, tokenExtensionCtx } = params;
    if (sqrtPriceLimit.gt(new anchor_1.BN(public_1.MAX_SQRT_PRICE)) || sqrtPriceLimit.lt(new anchor_1.BN(public_1.MIN_SQRT_PRICE))) {
        throw new errors_1.WhirlpoolsError("Provided SqrtPriceLimit is out of bounds.", errors_1.SwapErrorCode.SqrtPriceOutOfBounds);
    }
    if (aToB && sqrtPriceLimit.gt(whirlpoolData.sqrtPrice) || !aToB && sqrtPriceLimit.lt(whirlpoolData.sqrtPrice)) {
        throw new errors_1.WhirlpoolsError("Provided SqrtPriceLimit is in the opposite direction of the trade.", errors_1.SwapErrorCode.InvalidSqrtPriceLimitDirection);
    }
    if (tokenAmount.eq(common_sdk_1.ZERO)) {
        throw new errors_1.WhirlpoolsError("Provided tokenAmount is zero.", errors_1.SwapErrorCode.ZeroTradableAmount);
    }
    const tickSequence = new tick_array_sequence_1.TickArraySequence(tickArrays, whirlpoolData.tickSpacing, aToB);
    if (!tickSequence.isValidTickArray0(whirlpoolData.tickCurrentIndex)) {
        throw new errors_1.WhirlpoolsError("TickArray at index 0 does not contain the Whirlpool current tick index.", errors_1.SwapErrorCode.TickArraySequenceInvalid);
    }
    if (amountSpecifiedIsInput) {
        const transferFeeExcludedIn = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(tokenAmount, aToB ? tokenExtensionCtx.tokenMintWithProgramA : tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
        if (transferFeeExcludedIn.amount.eq(common_sdk_1.ZERO)) {
            throw new errors_1.WhirlpoolsError("Provided tokenAmount is virtually zero due to transfer fee.", errors_1.SwapErrorCode.ZeroTradableAmount);
        }
        const swapResults = (0, swap_manager_1.computeSwap)(whirlpoolData, tickSequence, transferFeeExcludedIn.amount, sqrtPriceLimit, amountSpecifiedIsInput, aToB);
        const transferFeeExcludedOut = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(aToB ? swapResults.amountB : swapResults.amountA, aToB ? tokenExtensionCtx.tokenMintWithProgramB : tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
        if (transferFeeExcludedOut.amount.lt(otherAmountThreshold)) {
            throw new errors_1.WhirlpoolsError("Quoted amount for the other token is below the otherAmountThreshold.", errors_1.SwapErrorCode.AmountOutBelowMinimum);
        }
        const fullfilled = (aToB ? swapResults.amountA : swapResults.amountB).eq(transferFeeExcludedIn.amount);
        const transferFeeIncludedIn = fullfilled ? {
            amount: tokenAmount,
            fee: transferFeeExcludedIn.fee
        } : token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(aToB ? swapResults.amountA : swapResults.amountB, aToB ? tokenExtensionCtx.tokenMintWithProgramA : tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
        const numOfTickCrossings = tickSequence.getNumOfTouchedArrays();
        if (numOfTickCrossings > public_1.MAX_SWAP_TICK_ARRAYS) {
            throw new errors_1.WhirlpoolsError(`Input amount causes the quote to traverse more than the allowable amount of tick-arrays ${numOfTickCrossings}`, errors_1.SwapErrorCode.TickArrayCrossingAboveMax);
        }
        const touchedArrays = tickSequence.getTouchedArrays(public_1.MAX_SWAP_TICK_ARRAYS);
        return {
            estimatedAmountIn: transferFeeIncludedIn.amount,
            estimatedAmountOut: transferFeeExcludedOut.amount,
            estimatedEndTickIndex: swapResults.nextTickIndex,
            estimatedEndSqrtPrice: swapResults.nextSqrtPrice,
            estimatedFeeAmount: swapResults.totalFeeAmount,
            transferFee: {
                deductingFromEstimatedAmountIn: transferFeeIncludedIn.fee,
                deductedFromEstimatedAmountOut: transferFeeExcludedOut.fee
            },
            amount: tokenAmount,
            amountSpecifiedIsInput,
            aToB,
            otherAmountThreshold,
            sqrtPriceLimit,
            tickArray0: touchedArrays[0],
            tickArray1: touchedArrays[1],
            tickArray2: touchedArrays[2]
        };
    }
    const transferFeeIncludedOut = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(tokenAmount, aToB ? tokenExtensionCtx.tokenMintWithProgramB : tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    const swapResults = (0, swap_manager_1.computeSwap)(whirlpoolData, tickSequence, transferFeeIncludedOut.amount, sqrtPriceLimit, amountSpecifiedIsInput, aToB);
    const transferFeeIncludedIn = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(aToB ? swapResults.amountA : swapResults.amountB, aToB ? tokenExtensionCtx.tokenMintWithProgramA : tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
    if (transferFeeIncludedIn.amount.gt(otherAmountThreshold)) {
        throw new errors_1.WhirlpoolsError("Quoted amount for the other token is above the otherAmountThreshold.", errors_1.SwapErrorCode.AmountInAboveMaximum);
    }
    const transferFeeExcludedOut = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(aToB ? swapResults.amountB : swapResults.amountA, aToB ? tokenExtensionCtx.tokenMintWithProgramB : tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    const numOfTickCrossings = tickSequence.getNumOfTouchedArrays();
    if (numOfTickCrossings > public_1.MAX_SWAP_TICK_ARRAYS) {
        throw new errors_1.WhirlpoolsError(`Input amount causes the quote to traverse more than the allowable amount of tick-arrays ${numOfTickCrossings}`, errors_1.SwapErrorCode.TickArrayCrossingAboveMax);
    }
    const touchedArrays = tickSequence.getTouchedArrays(public_1.MAX_SWAP_TICK_ARRAYS);
    return {
        estimatedAmountIn: transferFeeIncludedIn.amount,
        estimatedAmountOut: transferFeeExcludedOut.amount,
        estimatedEndTickIndex: swapResults.nextTickIndex,
        estimatedEndSqrtPrice: swapResults.nextSqrtPrice,
        estimatedFeeAmount: swapResults.totalFeeAmount,
        transferFee: {
            deductingFromEstimatedAmountIn: transferFeeIncludedIn.fee,
            deductedFromEstimatedAmountOut: transferFeeExcludedOut.fee
        },
        amount: tokenAmount,
        amountSpecifiedIsInput,
        aToB,
        otherAmountThreshold,
        sqrtPriceLimit,
        tickArray0: touchedArrays[0],
        tickArray1: touchedArrays[1],
        tickArray2: touchedArrays[2]
    };
} //# sourceMappingURL=swap-quote-impl.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/swap-quote.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.UseFallbackTickArray = void 0;
exports.swapQuoteByInputToken = swapQuoteByInputToken;
exports.swapQuoteByOutputToken = swapQuoteByOutputToken;
exports.swapQuoteWithParams = swapQuoteWithParams;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
const fetcher_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const public_2 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const swap_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/swap-utils.js [app-route] (ecmascript)");
const swap_quote_impl_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/swap/swap-quote-impl.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
var UseFallbackTickArray;
(function(UseFallbackTickArray) {
    UseFallbackTickArray["Always"] = "Always";
    UseFallbackTickArray["Never"] = "Never";
    UseFallbackTickArray["Situational"] = "Situational";
})(UseFallbackTickArray || (exports.UseFallbackTickArray = UseFallbackTickArray = {}));
async function swapQuoteByInputToken(whirlpool, inputTokenMint, tokenAmount, slippageTolerance, programId, fetcher, opts, useFallbackTickArray = UseFallbackTickArray.Never) {
    const params = await swapQuoteByToken(whirlpool, inputTokenMint, tokenAmount, true, useFallbackTickArray, programId, fetcher, opts);
    return swapQuoteWithParams(params, slippageTolerance);
}
async function swapQuoteByOutputToken(whirlpool, outputTokenMint, tokenAmount, slippageTolerance, programId, fetcher, opts, useFallbackTickArray = UseFallbackTickArray.Never) {
    const params = await swapQuoteByToken(whirlpool, outputTokenMint, tokenAmount, false, useFallbackTickArray, programId, fetcher, opts);
    return swapQuoteWithParams(params, slippageTolerance);
}
function swapQuoteWithParams(params, slippageTolerance) {
    const quote = (0, swap_quote_impl_1.simulateSwap)({
        ...params,
        tickArrays: swap_utils_1.SwapUtils.interpolateUninitializedTickArrays(web3_js_1.PublicKey.default, params.tickArrays)
    });
    if (params.fallbackTickArray) {
        if (quote.tickArray2.equals(quote.tickArray1)) {
            quote.tickArray2 = params.fallbackTickArray;
        } else {
            quote.supplementalTickArrays = [
                params.fallbackTickArray
            ];
        }
    }
    const slippageAdjustedQuote = {
        ...quote,
        ...swap_utils_1.SwapUtils.calculateSwapAmountsFromQuote(quote.amount, quote.estimatedAmountIn, quote.estimatedAmountOut, slippageTolerance, quote.amountSpecifiedIsInput)
    };
    return slippageAdjustedQuote;
}
async function swapQuoteByToken(whirlpool, inputTokenMint, tokenAmount, amountSpecifiedIsInput, useFallbackTickArray, programId, fetcher, opts) {
    const whirlpoolData = await fetcher.getPool(whirlpool.getAddress(), opts);
    (0, tiny_invariant_1.default)(!!whirlpoolData, "Whirlpool data not found");
    const swapMintKey = common_sdk_1.AddressUtil.toPubKey(inputTokenMint);
    const swapTokenType = public_2.PoolUtil.getTokenType(whirlpoolData, swapMintKey);
    (0, tiny_invariant_1.default)(!!swapTokenType, "swapTokenMint does not match any tokens on this pool");
    const aToB = swap_utils_1.SwapUtils.getSwapDirection(whirlpoolData, swapMintKey, amountSpecifiedIsInput) === public_2.SwapDirection.AtoB;
    const tickArrays = await swap_utils_1.SwapUtils.getTickArrays(whirlpoolData.tickCurrentIndex, whirlpoolData.tickSpacing, aToB, common_sdk_1.AddressUtil.toPubKey(programId), whirlpool.getAddress(), fetcher, opts);
    const fallbackTickArray = getFallbackTickArray(useFallbackTickArray, tickArrays, aToB, whirlpool, programId);
    const tokenExtensionCtx = await token_extension_util_1.TokenExtensionUtil.buildTokenExtensionContext(fetcher, whirlpoolData, fetcher_1.IGNORE_CACHE);
    return {
        whirlpoolData,
        tokenAmount,
        aToB,
        amountSpecifiedIsInput,
        sqrtPriceLimit: swap_utils_1.SwapUtils.getDefaultSqrtPriceLimit(aToB),
        otherAmountThreshold: swap_utils_1.SwapUtils.getDefaultOtherAmountThreshold(amountSpecifiedIsInput),
        tickArrays,
        tokenExtensionCtx,
        fallbackTickArray
    };
}
function getFallbackTickArray(useFallbackTickArray, tickArrays, aToB, whirlpool, programId) {
    if (useFallbackTickArray === UseFallbackTickArray.Never) {
        return undefined;
    }
    const fallbackTickArray = swap_utils_1.SwapUtils.getFallbackTickArrayPublicKey(tickArrays, whirlpool.getData().tickSpacing, aToB, common_sdk_1.AddressUtil.toPubKey(programId), whirlpool.getAddress());
    if (useFallbackTickArray === UseFallbackTickArray.Always || !fallbackTickArray) {
        return fallbackTickArray;
    }
    (0, tiny_invariant_1.default)(useFallbackTickArray === UseFallbackTickArray.Situational, `Unexpected UseFallbackTickArray value: ${useFallbackTickArray}`);
    const ticksInArray = whirlpool.getData().tickSpacing * public_1.TICK_ARRAY_SIZE;
    const tickCurrentIndex = whirlpool.getData().tickCurrentIndex;
    if (aToB) {
        const threshold = tickArrays[0].startTickIndex + ticksInArray / 4 * 3;
        return tickCurrentIndex >= threshold ? fallbackTickArray : undefined;
    } else {
        const threshold = tickArrays[0].startTickIndex + ticksInArray / 4;
        return tickCurrentIndex <= threshold ? fallbackTickArray : undefined;
    }
} //# sourceMappingURL=swap-quote.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/prices/calculate-pool-prices.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.calculatePricesForQuoteToken = calculatePricesForQuoteToken;
exports.isSubset = isSubset;
exports.convertAmount = convertAmount;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const decimal_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)"));
const _1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/prices/index.js [app-route] (ecmascript)");
const swap_quote_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/swap-quote.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
const swap_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/swap-utils.js [app-route] (ecmascript)");
function checkLiquidity(pool, tickArrays, aToB, thresholdConfig, decimalsMap) {
    const { amountOut, priceImpactThreshold } = thresholdConfig;
    let estimatedAmountIn;
    try {
        ({ estimatedAmountIn } = (0, swap_quote_1.swapQuoteWithParams)({
            whirlpoolData: pool,
            aToB,
            amountSpecifiedIsInput: false,
            tokenAmount: amountOut,
            otherAmountThreshold: public_1.SwapUtils.getDefaultOtherAmountThreshold(false),
            sqrtPriceLimit: public_1.SwapUtils.getDefaultSqrtPriceLimit(aToB),
            tickArrays,
            tokenExtensionCtx: token_extension_util_1.NO_TOKEN_EXTENSION_CONTEXT
        }, common_sdk_1.Percentage.fromDecimal(new decimal_js_1.default(0))));
    } catch  {
        return false;
    }
    let price, inputDecimals, outputDecimals;
    if (aToB) {
        price = getPrice(pool, decimalsMap);
        inputDecimals = decimalsMap[pool.tokenMintA.toBase58()];
        outputDecimals = decimalsMap[pool.tokenMintB.toBase58()];
    } else {
        price = getPrice(pool, decimalsMap).pow(-1);
        inputDecimals = decimalsMap[pool.tokenMintB.toBase58()];
        outputDecimals = decimalsMap[pool.tokenMintA.toBase58()];
    }
    const amountOutDecimals = common_sdk_1.DecimalUtil.fromBN(amountOut, outputDecimals);
    const estimatedAmountInDecimals = common_sdk_1.DecimalUtil.fromBN(estimatedAmountIn, inputDecimals);
    const maxAmountInDecimals = amountOutDecimals.div(price).mul(priceImpactThreshold).toDecimalPlaces(inputDecimals);
    return estimatedAmountInDecimals.lte(maxAmountInDecimals);
}
function getMostLiquidPools(quoteTokenMint, poolMap) {
    const mostLiquidPools = new Map();
    Object.entries(poolMap).forEach(([address, pool])=>{
        const mintA = pool.tokenMintA.toBase58();
        const mintB = pool.tokenMintB.toBase58();
        if (pool.liquidity.isZero()) {
            return;
        }
        if (!pool.tokenMintA.equals(quoteTokenMint) && !pool.tokenMintB.equals(quoteTokenMint)) {
            return;
        }
        const baseTokenMint = pool.tokenMintA.equals(quoteTokenMint) ? mintB : mintA;
        const existingPool = mostLiquidPools.get(baseTokenMint);
        if (!existingPool || pool.liquidity.gt(existingPool.pool.liquidity)) {
            mostLiquidPools.set(baseTokenMint, {
                address: common_sdk_1.AddressUtil.toPubKey(address),
                pool
            });
        }
    });
    return Object.fromEntries(mostLiquidPools);
}
function calculatePricesForQuoteToken(mints, quoteTokenMint, poolMap, tickArrayMap, decimalsMap, config, thresholdConfig) {
    const mostLiquidPools = getMostLiquidPools(quoteTokenMint, poolMap);
    return Object.fromEntries(mints.map((mintAddr)=>{
        const mint = common_sdk_1.AddressUtil.toPubKey(mintAddr);
        if (mint.equals(quoteTokenMint)) {
            return [
                mint.toBase58(),
                new decimal_js_1.default(1)
            ];
        }
        const [mintA, mintB] = public_1.PoolUtil.orderMints(mint, quoteTokenMint);
        const aToB = common_sdk_1.AddressUtil.toPubKey(mintB).equals(quoteTokenMint);
        const baseTokenMint = aToB ? mintA : mintB;
        const poolCandidate = mostLiquidPools[common_sdk_1.AddressUtil.toString(baseTokenMint)];
        if (poolCandidate === undefined) {
            return [
                mint.toBase58(),
                null
            ];
        }
        const { pool, address } = poolCandidate;
        const tickArrays = getTickArrays(pool, address, aToB, tickArrayMap, config);
        const isPoolLiquid = checkLiquidity(pool, tickArrays, aToB, thresholdConfig, decimalsMap);
        if (!isPoolLiquid) {
            return [
                mint.toBase58(),
                null
            ];
        }
        const price = getPrice(pool, decimalsMap);
        const quotePrice = aToB ? price : price.pow(-1);
        return [
            mint.toBase58(),
            quotePrice
        ];
    }));
}
function getTickArrays(pool, address, aToB, tickArrayMap, config = _1.defaultGetPricesConfig) {
    const { programId } = config;
    const tickArrayAddresses = (0, swap_utils_1.getTickArrayPublicKeysWithStartTickIndex)(pool.tickCurrentIndex, pool.tickSpacing, aToB, programId, address);
    return tickArrayAddresses.map((a)=>{
        return {
            address: a.pubkey,
            startTickIndex: a.startTickIndex,
            data: tickArrayMap[a.pubkey.toBase58()]
        };
    });
}
function getPrice(pool, decimalsMap) {
    const tokenAAddress = pool.tokenMintA.toBase58();
    const tokenBAddress = pool.tokenMintB.toBase58();
    if (!(tokenAAddress in decimalsMap) || !(tokenBAddress in decimalsMap)) {
        throw new Error("Missing token decimals");
    }
    return public_1.PriceMath.sqrtPriceX64ToPrice(pool.sqrtPrice, decimalsMap[tokenAAddress], decimalsMap[tokenBAddress]);
}
function isSubset(listA, listB) {
    return listA.every((itemA)=>listB.includes(itemA));
}
function convertAmount(amount, price, amountDecimal, resultDecimal) {
    return common_sdk_1.DecimalUtil.toBN(common_sdk_1.DecimalUtil.fromBN(amount, amountDecimal).div(price), resultDecimal);
} //# sourceMappingURL=calculate-pool-prices.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/prices/price-module.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PriceModuleUtils = exports.PriceModule = void 0;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const _1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/prices/index.js [app-route] (ecmascript)");
const fetcher_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const txn_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/txn-utils.js [app-route] (ecmascript)");
const calculate_pool_prices_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/prices/calculate-pool-prices.js [app-route] (ecmascript)");
class PriceModule {
    static async fetchTokenPricesByMints(fetcher, mints, config = _1.defaultGetPricesConfig, thresholdConfig = _1.defaultGetPricesThresholdConfig, opts = fetcher_1.IGNORE_CACHE, availableData = {}) {
        const poolMap = availableData?.poolMap ? availableData?.poolMap : await PriceModuleUtils.fetchPoolDataFromMints(fetcher, mints, config, opts);
        const tickArrayMap = availableData?.tickArrayMap ? availableData.tickArrayMap : await PriceModuleUtils.fetchTickArraysForPools(fetcher, poolMap, config, opts);
        const decimalsMap = availableData?.decimalsMap ? availableData.decimalsMap : await PriceModuleUtils.fetchDecimalsForMints(fetcher, mints, fetcher_1.PREFER_CACHE);
        return PriceModule.calculateTokenPrices(mints, {
            poolMap,
            tickArrayMap,
            decimalsMap
        }, config, thresholdConfig);
    }
    static async fetchTokenPricesByPools(fetcher, pools, config = _1.defaultGetPricesConfig, thresholdConfig = _1.defaultGetPricesThresholdConfig, opts = fetcher_1.IGNORE_CACHE) {
        const poolDatas = Array.from((await fetcher.getPools(pools, opts)).values());
        const [filteredPoolDatas, filteredPoolAddresses] = (0, txn_utils_1.filterNullObjects)(poolDatas, pools);
        const poolMap = (0, txn_utils_1.convertListToMap)(filteredPoolDatas, common_sdk_1.AddressUtil.toStrings(filteredPoolAddresses));
        const tickArrayMap = await PriceModuleUtils.fetchTickArraysForPools(fetcher, poolMap, config, opts);
        const mints = Array.from(Object.values(poolMap).reduce((acc, pool)=>{
            acc.add(pool.tokenMintA.toBase58());
            acc.add(pool.tokenMintB.toBase58());
            return acc;
        }, new Set()));
        const decimalsMap = await PriceModuleUtils.fetchDecimalsForMints(fetcher, mints, fetcher_1.PREFER_CACHE);
        return PriceModule.calculateTokenPrices(mints, {
            poolMap,
            tickArrayMap,
            decimalsMap
        }, config, thresholdConfig);
    }
    static calculateTokenPrices(mints, priceCalcData, config = _1.defaultGetPricesConfig, thresholdConfig = _1.defaultGetPricesThresholdConfig) {
        const { poolMap, decimalsMap, tickArrayMap } = priceCalcData;
        const mintStrings = common_sdk_1.AddressUtil.toStrings(mints);
        if (!(0, calculate_pool_prices_1.isSubset)(config.quoteTokens.map((mint)=>common_sdk_1.AddressUtil.toString(mint)), mintStrings.map((mint)=>mint))) {
            throw new Error("Quote tokens must be in mints array");
        }
        const results = Object.fromEntries(mintStrings.map((mint)=>[
                mint,
                null
            ]));
        const remainingQuoteTokens = config.quoteTokens.slice();
        let remainingMints = mints.slice();
        while(remainingQuoteTokens.length > 0 && remainingMints.length > 0){
            const quoteToken = remainingQuoteTokens.shift();
            if (!quoteToken) {
                throw new Error("Unreachable: remainingQuoteTokens is an empty array");
            }
            let amountOutThresholdAgainstFirstQuoteToken;
            if (quoteToken.equals(config.quoteTokens[0])) {
                amountOutThresholdAgainstFirstQuoteToken = thresholdConfig.amountOut;
            } else {
                const quoteTokenStr = quoteToken.toBase58();
                const quoteTokenPrice = results[quoteTokenStr];
                if (!quoteTokenPrice) {
                    throw new Error(`Quote token - ${quoteTokenStr} must have a price against the first quote token`);
                }
                amountOutThresholdAgainstFirstQuoteToken = (0, calculate_pool_prices_1.convertAmount)(thresholdConfig.amountOut, quoteTokenPrice, decimalsMap[config.quoteTokens[0].toBase58()], decimalsMap[quoteTokenStr]);
            }
            const prices = (0, calculate_pool_prices_1.calculatePricesForQuoteToken)(remainingMints, quoteToken, poolMap, tickArrayMap, decimalsMap, config, {
                amountOut: amountOutThresholdAgainstFirstQuoteToken,
                priceImpactThreshold: thresholdConfig.priceImpactThreshold
            });
            const quoteTokenPrice = results[quoteToken.toBase58()] || prices[quoteToken.toBase58()];
            remainingMints.forEach((mintAddr)=>{
                const mint = common_sdk_1.AddressUtil.toString(mintAddr);
                const mintPrice = prices[mint];
                if (mintPrice != null && quoteTokenPrice != null) {
                    results[mint] = mintPrice.mul(quoteTokenPrice);
                }
            });
            remainingMints = remainingMints.filter((mint)=>results[common_sdk_1.AddressUtil.toString(mint)] == null);
        }
        return results;
    }
}
exports.PriceModule = PriceModule;
class PriceModuleUtils {
    static async fetchPoolDataFromMints(fetcher, mints, config = _1.defaultGetPricesConfig, opts = fetcher_1.IGNORE_CACHE) {
        const { quoteTokens, tickSpacings, programId, whirlpoolsConfig } = config;
        const poolAddresses = mints.map((mint)=>tickSpacings.map((tickSpacing)=>{
                return quoteTokens.map((quoteToken)=>{
                    const [mintA, mintB] = public_1.PoolUtil.orderMints(mint, quoteToken);
                    return public_1.PDAUtil.getWhirlpool(programId, whirlpoolsConfig, common_sdk_1.AddressUtil.toPubKey(mintA), common_sdk_1.AddressUtil.toPubKey(mintB), tickSpacing).publicKey.toBase58();
                });
            }).flat()).flat();
        const poolDatas = Array.from((await fetcher.getPools(poolAddresses, opts)).values());
        const [filteredPoolDatas, filteredPoolAddresses] = (0, txn_utils_1.filterNullObjects)(poolDatas, poolAddresses);
        return (0, txn_utils_1.convertListToMap)(filteredPoolDatas, filteredPoolAddresses);
    }
    static async fetchTickArraysForPools(fetcher, pools, config = _1.defaultGetPricesConfig, opts = fetcher_1.IGNORE_CACHE) {
        const { programId } = config;
        const getQuoteTokenOrder = (mint)=>{
            const index = config.quoteTokens.findIndex((quoteToken)=>quoteToken.equals(mint));
            return index === -1 ? config.quoteTokens.length : index;
        };
        const tickArrayAddressSet = new Set();
        Object.entries(pools).forEach(([address, pool])=>{
            const orderA = getQuoteTokenOrder(pool.tokenMintA);
            const orderB = getQuoteTokenOrder(pool.tokenMintB);
            if (orderA === orderB) {
                return;
            }
            const aToB = orderA > orderB;
            const tickArrayPubkeys = public_1.SwapUtils.getTickArrayPublicKeys(pool.tickCurrentIndex, pool.tickSpacing, aToB, programId, new web3_js_1.PublicKey(address));
            tickArrayPubkeys.forEach((p)=>tickArrayAddressSet.add(p.toBase58()));
        });
        const tickArrayAddresses = Array.from(tickArrayAddressSet);
        const tickArrays = await fetcher.getTickArrays(tickArrayAddresses, opts);
        const [filteredTickArrays, filteredTickArrayAddresses] = (0, txn_utils_1.filterNullObjects)(tickArrays, tickArrayAddresses);
        return (0, txn_utils_1.convertListToMap)(filteredTickArrays, filteredTickArrayAddresses);
    }
    static async fetchDecimalsForMints(fetcher, mints, opts = fetcher_1.IGNORE_CACHE) {
        const mintInfos = Array.from((await fetcher.getMintInfos(mints, opts)).values());
        return mintInfos.reduce((acc, mintInfo, index)=>{
            const mint = common_sdk_1.AddressUtil.toString(mints[index]);
            if (!mintInfo) {
                throw new Error(`Mint account does not exist: ${mint}`);
            }
            acc[mint] = mintInfo.decimals;
            return acc;
        }, {});
    }
}
exports.PriceModuleUtils = PriceModuleUtils; //# sourceMappingURL=price-module.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/prices/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.defaultGetPricesThresholdConfig = exports.defaultGetPricesConfig = exports.defaultQuoteTokens = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/constants.js [app-route] (ecmascript)");
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/prices/price-module.js [app-route] (ecmascript)"), exports);
exports.defaultQuoteTokens = [
    constants_1.TOKEN_MINTS["USDC"],
    constants_1.TOKEN_MINTS["SOL"],
    constants_1.TOKEN_MINTS["mSOL"],
    constants_1.TOKEN_MINTS["stSOL"]
].map((mint)=>new web3_js_1.PublicKey(mint));
exports.defaultGetPricesConfig = {
    quoteTokens: exports.defaultQuoteTokens,
    tickSpacings: public_1.ORCA_SUPPORTED_TICK_SPACINGS,
    programId: public_1.ORCA_WHIRLPOOL_PROGRAM_ID,
    whirlpoolsConfig: public_1.ORCA_WHIRLPOOLS_CONFIG
};
exports.defaultGetPricesThresholdConfig = {
    amountOut: new bn_js_1.default(1_000_000_000),
    priceImpactThreshold: 1.05
}; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/position-util.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PositionUtil = exports.PositionStatus = exports.AmountSpecified = exports.SwapDirection = void 0;
exports.adjustForSlippage = adjustForSlippage;
exports.adjustAmountForSlippage = adjustAmountForSlippage;
exports.getLiquidityFromTokenA = getLiquidityFromTokenA;
exports.getLiquidityFromTokenB = getLiquidityFromTokenB;
exports.getAmountFixedDelta = getAmountFixedDelta;
exports.getAmountUnfixedDelta = getAmountUnfixedDelta;
exports.getNextSqrtPrice = getNextSqrtPrice;
exports.getTokenAFromLiquidity = getTokenAFromLiquidity;
exports.getTokenBFromLiquidity = getTokenBFromLiquidity;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const swap_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/swap-utils.js [app-route] (ecmascript)");
var SwapDirection;
(function(SwapDirection) {
    SwapDirection["AtoB"] = "Swap A to B";
    SwapDirection["BtoA"] = "Swap B to A";
})(SwapDirection || (exports.SwapDirection = SwapDirection = {}));
var AmountSpecified;
(function(AmountSpecified) {
    AmountSpecified["Input"] = "Specified input amount";
    AmountSpecified["Output"] = "Specified output amount";
})(AmountSpecified || (exports.AmountSpecified = AmountSpecified = {}));
var PositionStatus;
(function(PositionStatus) {
    PositionStatus[PositionStatus["BelowRange"] = 0] = "BelowRange";
    PositionStatus[PositionStatus["InRange"] = 1] = "InRange";
    PositionStatus[PositionStatus["AboveRange"] = 2] = "AboveRange";
})(PositionStatus || (exports.PositionStatus = PositionStatus = {}));
class PositionUtil {
    static getPositionStatus(tickCurrentIndex, tickLowerIndex, tickUpperIndex) {
        if (tickCurrentIndex < tickLowerIndex) {
            return PositionStatus.BelowRange;
        } else if (tickCurrentIndex < tickUpperIndex) {
            return PositionStatus.InRange;
        } else {
            return PositionStatus.AboveRange;
        }
    }
    static getStrictPositionStatus(sqrtPriceX64, tickLowerIndex, tickUpperIndex) {
        const sqrtPriceLowerX64 = public_1.PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex);
        const sqrtPriceUpperX64 = public_1.PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex);
        if (sqrtPriceX64.lte(sqrtPriceLowerX64)) {
            return PositionStatus.BelowRange;
        } else if (sqrtPriceX64.gte(sqrtPriceUpperX64)) {
            return PositionStatus.AboveRange;
        } else {
            return PositionStatus.InRange;
        }
    }
}
exports.PositionUtil = PositionUtil;
function adjustForSlippage(n, { numerator, denominator }, adjustUp) {
    if (adjustUp) {
        return n.mul(denominator.add(numerator)).div(denominator);
    } else {
        return n.mul(denominator).div(denominator.add(numerator));
    }
}
function adjustAmountForSlippage(amountIn, amountOut, { numerator, denominator }, amountSpecified) {
    if (amountSpecified === AmountSpecified.Input) {
        return amountOut.mul(denominator).div(denominator.add(numerator));
    } else {
        return amountIn.mul(denominator.add(numerator)).div(denominator);
    }
}
function getLiquidityFromTokenA(amount, sqrtPriceLowerX64, sqrtPriceUpperX64, roundUp) {
    const result = amount.mul(sqrtPriceLowerX64).mul(sqrtPriceUpperX64).div(sqrtPriceUpperX64.sub(sqrtPriceLowerX64));
    if (roundUp) {
        return common_sdk_1.MathUtil.shiftRightRoundUp(result);
    } else {
        return result.shrn(64);
    }
}
function getLiquidityFromTokenB(amount, sqrtPriceLowerX64, sqrtPriceUpperX64, roundUp) {
    const numerator = amount.shln(64);
    const denominator = sqrtPriceUpperX64.sub(sqrtPriceLowerX64);
    if (roundUp) {
        return common_sdk_1.MathUtil.divRoundUp(numerator, denominator);
    } else {
        return numerator.div(denominator);
    }
}
function getAmountFixedDelta(currentSqrtPriceX64, targetSqrtPriceX64, liquidity, amountSpecified, swapDirection) {
    if (amountSpecified == AmountSpecified.Input == (swapDirection == SwapDirection.AtoB)) {
        return getTokenAFromLiquidity(liquidity, currentSqrtPriceX64, targetSqrtPriceX64, amountSpecified == AmountSpecified.Input);
    } else {
        return getTokenBFromLiquidity(liquidity, currentSqrtPriceX64, targetSqrtPriceX64, amountSpecified == AmountSpecified.Input);
    }
}
function getAmountUnfixedDelta(currentSqrtPriceX64, targetSqrtPriceX64, liquidity, amountSpecified, swapDirection) {
    if (amountSpecified == AmountSpecified.Input == (swapDirection == SwapDirection.AtoB)) {
        return getTokenBFromLiquidity(liquidity, currentSqrtPriceX64, targetSqrtPriceX64, amountSpecified == AmountSpecified.Output);
    } else {
        return getTokenAFromLiquidity(liquidity, currentSqrtPriceX64, targetSqrtPriceX64, amountSpecified == AmountSpecified.Output);
    }
}
function getNextSqrtPrice(sqrtPriceX64, liquidity, amount, amountSpecified, swapDirection) {
    if (amountSpecified === AmountSpecified.Input && swapDirection === SwapDirection.AtoB) {
        return (0, swap_utils_1.getLowerSqrtPriceFromTokenA)(amount, liquidity, sqrtPriceX64);
    } else if (amountSpecified === AmountSpecified.Output && swapDirection === SwapDirection.BtoA) {
        return (0, swap_utils_1.getUpperSqrtPriceFromTokenA)(amount, liquidity, sqrtPriceX64);
    } else if (amountSpecified === AmountSpecified.Input && swapDirection === SwapDirection.BtoA) {
        return (0, swap_utils_1.getUpperSqrtPriceFromTokenB)(amount, liquidity, sqrtPriceX64);
    } else {
        return (0, swap_utils_1.getLowerSqrtPriceFromTokenB)(amount, liquidity, sqrtPriceX64);
    }
}
function getTokenAFromLiquidity(liquidity, sqrtPrice0X64, sqrtPrice1X64, roundUp) {
    const [sqrtPriceLowerX64, sqrtPriceUpperX64] = orderSqrtPrice(sqrtPrice0X64, sqrtPrice1X64);
    const numerator = liquidity.mul(sqrtPriceUpperX64.sub(sqrtPriceLowerX64)).shln(64);
    const denominator = sqrtPriceUpperX64.mul(sqrtPriceLowerX64);
    if (roundUp) {
        return common_sdk_1.MathUtil.divRoundUp(numerator, denominator);
    } else {
        return numerator.div(denominator);
    }
}
function getTokenBFromLiquidity(liquidity, sqrtPrice0X64, sqrtPrice1X64, roundUp) {
    const [sqrtPriceLowerX64, sqrtPriceUpperX64] = orderSqrtPrice(sqrtPrice0X64, sqrtPrice1X64);
    const result = liquidity.mul(sqrtPriceUpperX64.sub(sqrtPriceLowerX64));
    if (roundUp) {
        return common_sdk_1.MathUtil.shiftRightRoundUp(result);
    } else {
        return result.shrn(64);
    }
}
function orderSqrtPrice(sqrtPrice0X64, sqrtPrice1X64) {
    if (sqrtPrice0X64.lt(sqrtPrice1X64)) {
        return [
            sqrtPrice0X64,
            sqrtPrice1X64
        ];
    } else {
        return [
            sqrtPrice1X64,
            sqrtPrice0X64
        ];
    }
} //# sourceMappingURL=position-util.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/increase-liquidity-quote.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.increaseLiquidityQuoteByInputTokenUsingPriceSlippage = increaseLiquidityQuoteByInputTokenUsingPriceSlippage;
exports.increaseLiquidityQuoteByInputTokenWithParamsUsingPriceSlippage = increaseLiquidityQuoteByInputTokenWithParamsUsingPriceSlippage;
exports.increaseLiquidityQuoteByLiquidityWithParams = increaseLiquidityQuoteByLiquidityWithParams;
exports.increaseLiquidityQuoteByInputToken = increaseLiquidityQuoteByInputToken;
exports.increaseLiquidityQuoteByInputTokenWithParams = increaseLiquidityQuoteByInputTokenWithParams;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
const position_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/position-util.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
function increaseLiquidityQuoteByInputTokenUsingPriceSlippage(inputTokenMint, inputTokenAmount, tickLower, tickUpper, slippageTolerance, whirlpool, tokenExtensionCtx) {
    const data = whirlpool.getData();
    const tokenAInfo = whirlpool.getTokenAInfo();
    const tokenBInfo = whirlpool.getTokenBInfo();
    const inputMint = common_sdk_1.AddressUtil.toPubKey(inputTokenMint);
    const inputTokenInfo = inputMint.equals(tokenAInfo.mint) ? tokenAInfo : tokenBInfo;
    return increaseLiquidityQuoteByInputTokenWithParamsUsingPriceSlippage({
        inputTokenMint: inputMint,
        inputTokenAmount: common_sdk_1.DecimalUtil.toBN(inputTokenAmount, inputTokenInfo.decimals),
        tickLowerIndex: public_1.TickUtil.getInitializableTickIndex(tickLower, data.tickSpacing),
        tickUpperIndex: public_1.TickUtil.getInitializableTickIndex(tickUpper, data.tickSpacing),
        slippageTolerance,
        tokenExtensionCtx,
        ...data
    });
}
function increaseLiquidityQuoteByInputTokenWithParamsUsingPriceSlippage(param) {
    (0, tiny_invariant_1.default)(public_1.TickUtil.checkTickInBounds(param.tickLowerIndex), "tickLowerIndex is out of bounds.");
    (0, tiny_invariant_1.default)(public_1.TickUtil.checkTickInBounds(param.tickUpperIndex), "tickUpperIndex is out of bounds.");
    (0, tiny_invariant_1.default)(param.inputTokenMint.equals(param.tokenMintA) || param.inputTokenMint.equals(param.tokenMintB), `input token mint ${param.inputTokenMint.toBase58()} does not match any tokens in the provided pool.`);
    const liquidity = getLiquidityFromInputToken(param);
    if (liquidity.eq(common_sdk_1.ZERO)) {
        return {
            liquidityAmount: common_sdk_1.ZERO,
            tokenMaxA: common_sdk_1.ZERO,
            tokenMaxB: common_sdk_1.ZERO,
            tokenEstA: common_sdk_1.ZERO,
            tokenEstB: common_sdk_1.ZERO,
            transferFee: {
                deductingFromTokenMaxA: common_sdk_1.ZERO,
                deductingFromTokenMaxB: common_sdk_1.ZERO,
                deductingFromTokenEstA: common_sdk_1.ZERO,
                deductingFromTokenEstB: common_sdk_1.ZERO
            }
        };
    }
    return increaseLiquidityQuoteByLiquidityWithParams({
        liquidity,
        tickCurrentIndex: param.tickCurrentIndex,
        sqrtPrice: param.sqrtPrice,
        tickLowerIndex: param.tickLowerIndex,
        tickUpperIndex: param.tickUpperIndex,
        slippageTolerance: param.slippageTolerance,
        tokenExtensionCtx: param.tokenExtensionCtx
    });
}
function getLiquidityFromInputToken(params) {
    const { inputTokenMint, inputTokenAmount, tickLowerIndex, tickUpperIndex, sqrtPrice, tokenExtensionCtx } = params;
    (0, tiny_invariant_1.default)(tickLowerIndex < tickUpperIndex, `tickLowerIndex(${tickLowerIndex}) must be less than tickUpperIndex(${tickUpperIndex})`);
    if (inputTokenAmount.eq(common_sdk_1.ZERO)) {
        return common_sdk_1.ZERO;
    }
    const isTokenA = params.tokenMintA.equals(inputTokenMint);
    const sqrtPriceLowerX64 = public_1.PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex);
    const sqrtPriceUpperX64 = public_1.PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex);
    const positionStatus = position_util_1.PositionUtil.getStrictPositionStatus(sqrtPrice, tickLowerIndex, tickUpperIndex);
    if (positionStatus === position_util_1.PositionStatus.BelowRange) {
        if (!isTokenA) {
            return common_sdk_1.ZERO;
        }
        const transferFeeExcludedInputTokenAmount = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(inputTokenAmount, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
        return (0, position_util_1.getLiquidityFromTokenA)(transferFeeExcludedInputTokenAmount.amount, sqrtPriceLowerX64, sqrtPriceUpperX64, false);
    }
    if (positionStatus === position_util_1.PositionStatus.AboveRange) {
        if (isTokenA) {
            return common_sdk_1.ZERO;
        }
        const transferFeeExcludedInputTokenAmount = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(inputTokenAmount, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
        return (0, position_util_1.getLiquidityFromTokenB)(transferFeeExcludedInputTokenAmount.amount, sqrtPriceLowerX64, sqrtPriceUpperX64, false);
    }
    if (isTokenA) {
        const transferFeeExcludedInputTokenAmount = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(inputTokenAmount, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
        return (0, position_util_1.getLiquidityFromTokenA)(transferFeeExcludedInputTokenAmount.amount, sqrtPrice, sqrtPriceUpperX64, false);
    } else {
        const transferFeeExcludedInputTokenAmount = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(inputTokenAmount, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
        return (0, position_util_1.getLiquidityFromTokenB)(transferFeeExcludedInputTokenAmount.amount, sqrtPriceLowerX64, sqrtPrice, false);
    }
}
function increaseLiquidityQuoteByLiquidityWithParams(params) {
    if (params.liquidity.eq(common_sdk_1.ZERO)) {
        return {
            liquidityAmount: common_sdk_1.ZERO,
            tokenMaxA: common_sdk_1.ZERO,
            tokenMaxB: common_sdk_1.ZERO,
            tokenEstA: common_sdk_1.ZERO,
            tokenEstB: common_sdk_1.ZERO,
            transferFee: {
                deductingFromTokenMaxA: common_sdk_1.ZERO,
                deductingFromTokenMaxB: common_sdk_1.ZERO,
                deductingFromTokenEstA: common_sdk_1.ZERO,
                deductingFromTokenEstB: common_sdk_1.ZERO
            }
        };
    }
    const { tokenEstA, tokenEstB } = getTokenEstimatesFromLiquidity(params);
    const { lowerBound: [sLowerSqrtPrice, sLowerIndex], upperBound: [sUpperSqrtPrice, sUpperIndex] } = public_1.PriceMath.getSlippageBoundForSqrtPrice(params.sqrtPrice, params.slippageTolerance);
    const { tokenEstA: tokenEstALower, tokenEstB: tokenEstBLower } = getTokenEstimatesFromLiquidity({
        ...params,
        sqrtPrice: sLowerSqrtPrice,
        tickCurrentIndex: sLowerIndex
    });
    const { tokenEstA: tokenEstAUpper, tokenEstB: tokenEstBUpper } = getTokenEstimatesFromLiquidity({
        ...params,
        sqrtPrice: sUpperSqrtPrice,
        tickCurrentIndex: sUpperIndex
    });
    const tokenMaxA = bn_js_1.default.max(bn_js_1.default.max(tokenEstA, tokenEstALower), tokenEstAUpper);
    const tokenMaxB = bn_js_1.default.max(bn_js_1.default.max(tokenEstB, tokenEstBLower), tokenEstBUpper);
    const tokenExtensionCtx = params.tokenExtensionCtx;
    const tokenMaxAIncluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(tokenMaxA, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    const tokenEstAIncluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(tokenEstA, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    const tokenMaxBIncluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(tokenMaxB, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
    const tokenEstBIncluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(tokenEstB, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
    return {
        liquidityAmount: params.liquidity,
        tokenMaxA: tokenMaxAIncluded.amount,
        tokenMaxB: tokenMaxBIncluded.amount,
        tokenEstA: tokenEstAIncluded.amount,
        tokenEstB: tokenEstBIncluded.amount,
        transferFee: {
            deductingFromTokenMaxA: tokenMaxAIncluded.fee,
            deductingFromTokenMaxB: tokenMaxBIncluded.fee,
            deductingFromTokenEstA: tokenEstAIncluded.fee,
            deductingFromTokenEstB: tokenEstBIncluded.fee
        }
    };
}
function getTokenEstimatesFromLiquidity(params) {
    const { liquidity, sqrtPrice, tickLowerIndex, tickUpperIndex } = params;
    if (liquidity.eq(common_sdk_1.ZERO)) {
        throw new Error("liquidity must be greater than 0");
    }
    let tokenEstA = common_sdk_1.ZERO;
    let tokenEstB = common_sdk_1.ZERO;
    const lowerSqrtPrice = public_1.PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex);
    const upperSqrtPrice = public_1.PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex);
    const positionStatus = position_util_1.PositionUtil.getStrictPositionStatus(sqrtPrice, tickLowerIndex, tickUpperIndex);
    if (positionStatus === position_util_1.PositionStatus.BelowRange) {
        tokenEstA = (0, position_util_1.getTokenAFromLiquidity)(liquidity, lowerSqrtPrice, upperSqrtPrice, true);
    } else if (positionStatus === position_util_1.PositionStatus.InRange) {
        tokenEstA = (0, position_util_1.getTokenAFromLiquidity)(liquidity, sqrtPrice, upperSqrtPrice, true);
        tokenEstB = (0, position_util_1.getTokenBFromLiquidity)(liquidity, lowerSqrtPrice, sqrtPrice, true);
    } else {
        tokenEstB = (0, position_util_1.getTokenBFromLiquidity)(liquidity, lowerSqrtPrice, upperSqrtPrice, true);
    }
    return {
        tokenEstA,
        tokenEstB
    };
}
function increaseLiquidityQuoteByInputToken(inputTokenMint, inputTokenAmount, tickLower, tickUpper, slippageTolerance, whirlpool, tokenExtensionCtx) {
    const data = whirlpool.getData();
    const tokenAInfo = whirlpool.getTokenAInfo();
    const tokenBInfo = whirlpool.getTokenBInfo();
    const inputMint = common_sdk_1.AddressUtil.toPubKey(inputTokenMint);
    const inputTokenInfo = inputMint.equals(tokenAInfo.mint) ? tokenAInfo : tokenBInfo;
    return increaseLiquidityQuoteByInputTokenWithParams({
        inputTokenMint: inputMint,
        inputTokenAmount: common_sdk_1.DecimalUtil.toBN(inputTokenAmount, inputTokenInfo.decimals),
        tickLowerIndex: public_1.TickUtil.getInitializableTickIndex(tickLower, data.tickSpacing),
        tickUpperIndex: public_1.TickUtil.getInitializableTickIndex(tickUpper, data.tickSpacing),
        slippageTolerance,
        tokenExtensionCtx,
        ...data
    });
}
function increaseLiquidityQuoteByInputTokenWithParams(param) {
    (0, tiny_invariant_1.default)(public_1.TickUtil.checkTickInBounds(param.tickLowerIndex), "tickLowerIndex is out of bounds.");
    (0, tiny_invariant_1.default)(public_1.TickUtil.checkTickInBounds(param.tickUpperIndex), "tickUpperIndex is out of bounds.");
    (0, tiny_invariant_1.default)(param.inputTokenMint.equals(param.tokenMintA) || param.inputTokenMint.equals(param.tokenMintB), `input token mint ${param.inputTokenMint.toBase58()} does not match any tokens in the provided pool.`);
    const positionStatus = position_util_1.PositionUtil.getStrictPositionStatus(param.sqrtPrice, param.tickLowerIndex, param.tickUpperIndex);
    switch(positionStatus){
        case position_util_1.PositionStatus.BelowRange:
            return quotePositionBelowRange(param);
        case position_util_1.PositionStatus.InRange:
            return quotePositionInRange(param);
        case position_util_1.PositionStatus.AboveRange:
            return quotePositionAboveRange(param);
        default:
            throw new Error(`type ${positionStatus} is an unknown PositionStatus`);
    }
}
function quotePositionBelowRange(param) {
    const { tokenMintA, inputTokenMint, inputTokenAmount, tickLowerIndex, tickUpperIndex, tokenExtensionCtx, slippageTolerance } = param;
    if (!tokenMintA.equals(inputTokenMint)) {
        return {
            liquidityAmount: common_sdk_1.ZERO,
            tokenMaxA: common_sdk_1.ZERO,
            tokenMaxB: common_sdk_1.ZERO,
            tokenEstA: common_sdk_1.ZERO,
            tokenEstB: common_sdk_1.ZERO,
            transferFee: {
                deductingFromTokenMaxA: common_sdk_1.ZERO,
                deductingFromTokenMaxB: common_sdk_1.ZERO,
                deductingFromTokenEstA: common_sdk_1.ZERO,
                deductingFromTokenEstB: common_sdk_1.ZERO
            }
        };
    }
    const sqrtPriceLowerX64 = public_1.PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex);
    const sqrtPriceUpperX64 = public_1.PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex);
    const transferFeeExcludedInputTokenAmount = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(inputTokenAmount, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    const liquidityAmount = (0, position_util_1.getLiquidityFromTokenA)(transferFeeExcludedInputTokenAmount.amount, sqrtPriceLowerX64, sqrtPriceUpperX64, false);
    const tokenEstA = (0, position_util_1.getTokenAFromLiquidity)(liquidityAmount, sqrtPriceLowerX64, sqrtPriceUpperX64, true);
    const tokenMaxA = (0, position_util_1.adjustForSlippage)(tokenEstA, slippageTolerance, true);
    const tokenMaxAIncluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(tokenMaxA, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    const tokenEstAIncluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(tokenEstA, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    return {
        liquidityAmount,
        tokenMaxA: tokenMaxAIncluded.amount,
        tokenMaxB: common_sdk_1.ZERO,
        tokenEstA: tokenEstAIncluded.amount,
        tokenEstB: common_sdk_1.ZERO,
        transferFee: {
            deductingFromTokenMaxA: tokenMaxAIncluded.fee,
            deductingFromTokenMaxB: common_sdk_1.ZERO,
            deductingFromTokenEstA: tokenEstAIncluded.fee,
            deductingFromTokenEstB: common_sdk_1.ZERO
        }
    };
}
function quotePositionInRange(param) {
    const { tokenMintA, tokenMintB, sqrtPrice, inputTokenMint, inputTokenAmount, tickLowerIndex, tickUpperIndex, tokenExtensionCtx, slippageTolerance } = param;
    const sqrtPriceX64 = sqrtPrice;
    const sqrtPriceLowerX64 = public_1.PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex);
    const sqrtPriceUpperX64 = public_1.PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex);
    let tokenEstA;
    let tokenEstB;
    let liquidityAmount;
    if (tokenMintA.equals(inputTokenMint)) {
        const transferFeeExcludedInputTokenAmount = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(inputTokenAmount, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
        liquidityAmount = (0, position_util_1.getLiquidityFromTokenA)(transferFeeExcludedInputTokenAmount.amount, sqrtPriceX64, sqrtPriceUpperX64, false);
        tokenEstA = (0, position_util_1.getTokenAFromLiquidity)(liquidityAmount, sqrtPriceX64, sqrtPriceUpperX64, true);
        tokenEstB = (0, position_util_1.getTokenBFromLiquidity)(liquidityAmount, sqrtPriceLowerX64, sqrtPriceX64, true);
    } else if (tokenMintB.equals(inputTokenMint)) {
        const transferFeeExcludedInputTokenAmount = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(inputTokenAmount, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
        liquidityAmount = (0, position_util_1.getLiquidityFromTokenB)(transferFeeExcludedInputTokenAmount.amount, sqrtPriceLowerX64, sqrtPriceX64, false);
        tokenEstA = (0, position_util_1.getTokenAFromLiquidity)(liquidityAmount, sqrtPriceX64, sqrtPriceUpperX64, true);
        tokenEstB = (0, position_util_1.getTokenBFromLiquidity)(liquidityAmount, sqrtPriceLowerX64, sqrtPriceX64, true);
    } else {
        throw new Error("invariant violation");
    }
    const tokenMaxA = (0, position_util_1.adjustForSlippage)(tokenEstA, slippageTolerance, true);
    const tokenMaxB = (0, position_util_1.adjustForSlippage)(tokenEstB, slippageTolerance, true);
    const tokenMaxAIncluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(tokenMaxA, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    const tokenEstAIncluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(tokenEstA, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    const tokenMaxBIncluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(tokenMaxB, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
    const tokenEstBIncluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(tokenEstB, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
    return {
        liquidityAmount,
        tokenMaxA: tokenMaxAIncluded.amount,
        tokenMaxB: tokenMaxBIncluded.amount,
        tokenEstA: tokenEstAIncluded.amount,
        tokenEstB: tokenEstBIncluded.amount,
        transferFee: {
            deductingFromTokenMaxA: tokenMaxAIncluded.fee,
            deductingFromTokenMaxB: tokenMaxBIncluded.fee,
            deductingFromTokenEstA: tokenEstAIncluded.fee,
            deductingFromTokenEstB: tokenEstBIncluded.fee
        }
    };
}
function quotePositionAboveRange(param) {
    const { tokenMintB, inputTokenMint, inputTokenAmount, tickLowerIndex, tickUpperIndex, tokenExtensionCtx, slippageTolerance } = param;
    if (!tokenMintB.equals(inputTokenMint)) {
        return {
            liquidityAmount: common_sdk_1.ZERO,
            tokenMaxA: common_sdk_1.ZERO,
            tokenMaxB: common_sdk_1.ZERO,
            tokenEstA: common_sdk_1.ZERO,
            tokenEstB: common_sdk_1.ZERO,
            transferFee: {
                deductingFromTokenMaxA: common_sdk_1.ZERO,
                deductingFromTokenMaxB: common_sdk_1.ZERO,
                deductingFromTokenEstA: common_sdk_1.ZERO,
                deductingFromTokenEstB: common_sdk_1.ZERO
            }
        };
    }
    const sqrtPriceLowerX64 = public_1.PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex);
    const sqrtPriceUpperX64 = public_1.PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex);
    const transferFeeExcludedInputTokenAmount = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(inputTokenAmount, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
    const liquidityAmount = (0, position_util_1.getLiquidityFromTokenB)(transferFeeExcludedInputTokenAmount.amount, sqrtPriceLowerX64, sqrtPriceUpperX64, false);
    const tokenEstB = (0, position_util_1.getTokenBFromLiquidity)(liquidityAmount, sqrtPriceLowerX64, sqrtPriceUpperX64, true);
    const tokenMaxB = (0, position_util_1.adjustForSlippage)(tokenEstB, slippageTolerance, true);
    const tokenMaxBIncluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(tokenMaxB, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
    const tokenEstBIncluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeIncludedAmount(tokenEstB, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
    return {
        liquidityAmount,
        tokenMaxA: common_sdk_1.ZERO,
        tokenMaxB: tokenMaxBIncluded.amount,
        tokenEstA: common_sdk_1.ZERO,
        tokenEstB: tokenEstBIncluded.amount,
        transferFee: {
            deductingFromTokenMaxA: common_sdk_1.ZERO,
            deductingFromTokenMaxB: tokenMaxBIncluded.fee,
            deductingFromTokenEstA: common_sdk_1.ZERO,
            deductingFromTokenEstB: tokenEstBIncluded.fee
        }
    };
} //# sourceMappingURL=increase-liquidity-quote.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/decrease-liquidity-quote.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.decreaseLiquidityQuoteByLiquidity = decreaseLiquidityQuoteByLiquidity;
exports.decreaseLiquidityQuoteByLiquidityWithParams = decreaseLiquidityQuoteByLiquidityWithParams;
exports.decreaseLiquidityQuoteByLiquidityWithParamsUsingPriceSlippage = decreaseLiquidityQuoteByLiquidityWithParamsUsingPriceSlippage;
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
const position_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/position-util.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
function decreaseLiquidityQuoteByLiquidity(liquidity, slippageTolerance, position, whirlpool, tokenExtensionCtx) {
    const positionData = position.getData();
    const whirlpoolData = whirlpool.getData();
    (0, tiny_invariant_1.default)(liquidity.lte(positionData.liquidity), "Quote liquidity is more than the position liquidity.");
    return decreaseLiquidityQuoteByLiquidityWithParams({
        liquidity,
        slippageTolerance,
        tickLowerIndex: positionData.tickLowerIndex,
        tickUpperIndex: positionData.tickUpperIndex,
        sqrtPrice: whirlpoolData.sqrtPrice,
        tickCurrentIndex: whirlpoolData.tickCurrentIndex,
        tokenExtensionCtx
    });
}
function decreaseLiquidityQuoteByLiquidityWithParams(params) {
    (0, tiny_invariant_1.default)(public_1.TickUtil.checkTickInBounds(params.tickLowerIndex), "tickLowerIndex is out of bounds.");
    (0, tiny_invariant_1.default)(public_1.TickUtil.checkTickInBounds(params.tickUpperIndex), "tickUpperIndex is out of bounds.");
    if (params.liquidity.eq(common_sdk_1.ZERO)) {
        return {
            tokenMinA: common_sdk_1.ZERO,
            tokenMinB: common_sdk_1.ZERO,
            liquidityAmount: common_sdk_1.ZERO,
            tokenEstA: common_sdk_1.ZERO,
            tokenEstB: common_sdk_1.ZERO,
            transferFee: {
                deductedFromTokenMinA: common_sdk_1.ZERO,
                deductedFromTokenMinB: common_sdk_1.ZERO,
                deductedFromTokenEstA: common_sdk_1.ZERO,
                deductedFromTokenEstB: common_sdk_1.ZERO
            }
        };
    }
    const { tokenExtensionCtx } = params;
    const { tokenEstA, tokenEstB } = getTokenEstimatesFromLiquidity(params);
    const [tokenMinA, tokenMinB] = [
        tokenEstA,
        tokenEstB
    ].map((tokenEst)=>(0, position_util_1.adjustForSlippage)(tokenEst, params.slippageTolerance, false));
    const tokenMinAExcluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(tokenMinA, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    const tokenEstAExcluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(tokenEstA, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    const tokenMinBExcluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(tokenMinB, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
    const tokenEstBExcluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(tokenEstB, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
    return {
        tokenMinA: tokenMinAExcluded.amount,
        tokenMinB: tokenMinBExcluded.amount,
        tokenEstA: tokenEstAExcluded.amount,
        tokenEstB: tokenEstBExcluded.amount,
        liquidityAmount: params.liquidity,
        transferFee: {
            deductedFromTokenMinA: tokenMinAExcluded.fee,
            deductedFromTokenMinB: tokenMinBExcluded.fee,
            deductedFromTokenEstA: tokenEstAExcluded.fee,
            deductedFromTokenEstB: tokenEstBExcluded.fee
        }
    };
}
function decreaseLiquidityQuoteByLiquidityWithParamsUsingPriceSlippage(params) {
    const { tokenExtensionCtx } = params;
    if (params.liquidity.eq(common_sdk_1.ZERO)) {
        return {
            tokenMinA: common_sdk_1.ZERO,
            tokenMinB: common_sdk_1.ZERO,
            liquidityAmount: common_sdk_1.ZERO,
            tokenEstA: common_sdk_1.ZERO,
            tokenEstB: common_sdk_1.ZERO,
            transferFee: {
                deductedFromTokenMinA: common_sdk_1.ZERO,
                deductedFromTokenMinB: common_sdk_1.ZERO,
                deductedFromTokenEstA: common_sdk_1.ZERO,
                deductedFromTokenEstB: common_sdk_1.ZERO
            }
        };
    }
    const { tokenEstA, tokenEstB } = getTokenEstimatesFromLiquidity(params);
    const { lowerBound: [sLowerSqrtPrice, sLowerIndex], upperBound: [sUpperSqrtPrice, sUpperIndex] } = public_1.PriceMath.getSlippageBoundForSqrtPrice(params.sqrtPrice, params.slippageTolerance);
    const { tokenEstA: tokenEstALower, tokenEstB: tokenEstBLower } = getTokenEstimatesFromLiquidity({
        ...params,
        sqrtPrice: sLowerSqrtPrice,
        tickCurrentIndex: sLowerIndex
    });
    const { tokenEstA: tokenEstAUpper, tokenEstB: tokenEstBUpper } = getTokenEstimatesFromLiquidity({
        ...params,
        sqrtPrice: sUpperSqrtPrice,
        tickCurrentIndex: sUpperIndex
    });
    const tokenMinA = anchor_1.BN.min(anchor_1.BN.min(tokenEstA, tokenEstALower), tokenEstAUpper);
    const tokenMinB = anchor_1.BN.min(anchor_1.BN.min(tokenEstB, tokenEstBLower), tokenEstBUpper);
    const tokenMinAExcluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(tokenMinA, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    const tokenEstAExcluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(tokenEstA, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    const tokenMinBExcluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(tokenMinB, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
    const tokenEstBExcluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(tokenEstB, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
    return {
        tokenMinA: tokenMinAExcluded.amount,
        tokenMinB: tokenMinBExcluded.amount,
        tokenEstA: tokenEstAExcluded.amount,
        tokenEstB: tokenEstBExcluded.amount,
        liquidityAmount: params.liquidity,
        transferFee: {
            deductedFromTokenMinA: tokenMinAExcluded.fee,
            deductedFromTokenMinB: tokenMinBExcluded.fee,
            deductedFromTokenEstA: tokenEstAExcluded.fee,
            deductedFromTokenEstB: tokenEstBExcluded.fee
        }
    };
}
function getTokenEstimatesFromLiquidity(params) {
    const { liquidity, tickLowerIndex, tickUpperIndex, sqrtPrice } = params;
    if (liquidity.eq(common_sdk_1.ZERO)) {
        throw new Error("liquidity must be greater than 0");
    }
    let tokenEstA = common_sdk_1.ZERO;
    let tokenEstB = common_sdk_1.ZERO;
    const lowerSqrtPrice = public_1.PriceMath.tickIndexToSqrtPriceX64(tickLowerIndex);
    const upperSqrtPrice = public_1.PriceMath.tickIndexToSqrtPriceX64(tickUpperIndex);
    const positionStatus = position_util_1.PositionUtil.getStrictPositionStatus(sqrtPrice, tickLowerIndex, tickUpperIndex);
    if (positionStatus === position_util_1.PositionStatus.BelowRange) {
        tokenEstA = (0, position_util_1.getTokenAFromLiquidity)(liquidity, lowerSqrtPrice, upperSqrtPrice, false);
    } else if (positionStatus === position_util_1.PositionStatus.InRange) {
        tokenEstA = (0, position_util_1.getTokenAFromLiquidity)(liquidity, sqrtPrice, upperSqrtPrice, false);
        tokenEstB = (0, position_util_1.getTokenBFromLiquidity)(liquidity, lowerSqrtPrice, sqrtPrice, false);
    } else {
        tokenEstB = (0, position_util_1.getTokenBFromLiquidity)(liquidity, lowerSqrtPrice, upperSqrtPrice, false);
    }
    return {
        tokenEstA,
        tokenEstB
    };
} //# sourceMappingURL=decrease-liquidity-quote.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/collect-fees-quote.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.collectFeesQuote = collectFeesQuote;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
function collectFeesQuote(param) {
    const { whirlpool, position, tickLower, tickUpper, tokenExtensionCtx } = param;
    const { tickCurrentIndex, feeGrowthGlobalA: feeGrowthGlobalAX64, feeGrowthGlobalB: feeGrowthGlobalBX64 } = whirlpool;
    const { tickLowerIndex, tickUpperIndex, liquidity, feeOwedA, feeOwedB, feeGrowthCheckpointA: feeGrowthCheckpointAX64, feeGrowthCheckpointB: feeGrowthCheckpointBX64 } = position;
    const { feeGrowthOutsideA: tickLowerFeeGrowthOutsideAX64, feeGrowthOutsideB: tickLowerFeeGrowthOutsideBX64 } = tickLower;
    const { feeGrowthOutsideA: tickUpperFeeGrowthOutsideAX64, feeGrowthOutsideB: tickUpperFeeGrowthOutsideBX64 } = tickUpper;
    let feeGrowthBelowAX64 = null;
    let feeGrowthBelowBX64 = null;
    if (tickCurrentIndex < tickLowerIndex) {
        feeGrowthBelowAX64 = common_sdk_1.MathUtil.subUnderflowU128(feeGrowthGlobalAX64, tickLowerFeeGrowthOutsideAX64);
        feeGrowthBelowBX64 = common_sdk_1.MathUtil.subUnderflowU128(feeGrowthGlobalBX64, tickLowerFeeGrowthOutsideBX64);
    } else {
        feeGrowthBelowAX64 = tickLowerFeeGrowthOutsideAX64;
        feeGrowthBelowBX64 = tickLowerFeeGrowthOutsideBX64;
    }
    let feeGrowthAboveAX64 = null;
    let feeGrowthAboveBX64 = null;
    if (tickCurrentIndex < tickUpperIndex) {
        feeGrowthAboveAX64 = tickUpperFeeGrowthOutsideAX64;
        feeGrowthAboveBX64 = tickUpperFeeGrowthOutsideBX64;
    } else {
        feeGrowthAboveAX64 = common_sdk_1.MathUtil.subUnderflowU128(feeGrowthGlobalAX64, tickUpperFeeGrowthOutsideAX64);
        feeGrowthAboveBX64 = common_sdk_1.MathUtil.subUnderflowU128(feeGrowthGlobalBX64, tickUpperFeeGrowthOutsideBX64);
    }
    const feeGrowthInsideAX64 = common_sdk_1.MathUtil.subUnderflowU128(common_sdk_1.MathUtil.subUnderflowU128(feeGrowthGlobalAX64, feeGrowthBelowAX64), feeGrowthAboveAX64);
    const feeGrowthInsideBX64 = common_sdk_1.MathUtil.subUnderflowU128(common_sdk_1.MathUtil.subUnderflowU128(feeGrowthGlobalBX64, feeGrowthBelowBX64), feeGrowthAboveBX64);
    const feeOwedADelta = common_sdk_1.MathUtil.subUnderflowU128(feeGrowthInsideAX64, feeGrowthCheckpointAX64).mul(liquidity).shrn(64);
    const feeOwedBDelta = common_sdk_1.MathUtil.subUnderflowU128(feeGrowthInsideBX64, feeGrowthCheckpointBX64).mul(liquidity).shrn(64);
    const updatedFeeOwedA = feeOwedA.add(feeOwedADelta);
    const transferFeeExcludedAmountA = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(updatedFeeOwedA, tokenExtensionCtx.tokenMintWithProgramA, tokenExtensionCtx.currentEpoch);
    const updatedFeeOwedB = feeOwedB.add(feeOwedBDelta);
    const transferFeeExcludedAmountB = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(updatedFeeOwedB, tokenExtensionCtx.tokenMintWithProgramB, tokenExtensionCtx.currentEpoch);
    return {
        feeOwedA: transferFeeExcludedAmountA.amount,
        feeOwedB: transferFeeExcludedAmountB.amount,
        transferFee: {
            deductedFromFeeOwedA: transferFeeExcludedAmountA.fee,
            deductedFromFeeOwedB: transferFeeExcludedAmountB.fee
        }
    };
} //# sourceMappingURL=collect-fees-quote.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/collect-rewards-quote.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.collectRewardsQuote = collectRewardsQuote;
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const bit_math_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/math/bit-math.js [app-route] (ecmascript)");
const pool_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/pool-utils.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
function collectRewardsQuote(param) {
    const { whirlpool, position, tickLower, tickUpper, timeStampInSeconds, tokenExtensionCtx } = param;
    const { tickCurrentIndex, rewardInfos: whirlpoolRewardsInfos, rewardLastUpdatedTimestamp } = whirlpool;
    const { tickLowerIndex, tickUpperIndex, liquidity, rewardInfos: positionRewardInfos } = position;
    const currTimestampInSeconds = timeStampInSeconds ?? new anchor_1.BN(Date.now()).div(new anchor_1.BN(1000));
    const timestampDelta = currTimestampInSeconds.sub(new anchor_1.BN(rewardLastUpdatedTimestamp));
    const rewardOwed = [
        undefined,
        undefined,
        undefined
    ];
    const transferFee = [
        undefined,
        undefined,
        undefined
    ];
    for(let i = 0; i < public_1.NUM_REWARDS; i++){
        const rewardInfo = whirlpoolRewardsInfos[i];
        const positionRewardInfo = positionRewardInfos[i];
        (0, tiny_invariant_1.default)(!!rewardInfo, "whirlpoolRewardsInfos cannot be undefined");
        const isRewardInitialized = pool_utils_1.PoolUtil.isRewardInitialized(rewardInfo);
        if (!isRewardInitialized) {
            continue;
        }
        let adjustedRewardGrowthGlobalX64 = rewardInfo.growthGlobalX64;
        if (!whirlpool.liquidity.isZero()) {
            const rewardGrowthDelta = bit_math_1.BitMath.mulDiv(timestampDelta, rewardInfo.emissionsPerSecondX64, whirlpool.liquidity, 128);
            adjustedRewardGrowthGlobalX64 = rewardInfo.growthGlobalX64.add(rewardGrowthDelta);
        }
        const tickLowerRewardGrowthsOutsideX64 = tickLower.rewardGrowthsOutside[i];
        const tickUpperRewardGrowthsOutsideX64 = tickUpper.rewardGrowthsOutside[i];
        let rewardGrowthsBelowX64 = adjustedRewardGrowthGlobalX64;
        if (tickLower.initialized) {
            rewardGrowthsBelowX64 = tickCurrentIndex < tickLowerIndex ? common_sdk_1.MathUtil.subUnderflowU128(adjustedRewardGrowthGlobalX64, tickLowerRewardGrowthsOutsideX64) : tickLowerRewardGrowthsOutsideX64;
        }
        let rewardGrowthsAboveX64 = new anchor_1.BN(0);
        if (tickUpper.initialized) {
            rewardGrowthsAboveX64 = tickCurrentIndex < tickUpperIndex ? tickUpperRewardGrowthsOutsideX64 : common_sdk_1.MathUtil.subUnderflowU128(adjustedRewardGrowthGlobalX64, tickUpperRewardGrowthsOutsideX64);
        }
        const rewardGrowthInsideX64 = common_sdk_1.MathUtil.subUnderflowU128(common_sdk_1.MathUtil.subUnderflowU128(adjustedRewardGrowthGlobalX64, rewardGrowthsBelowX64), rewardGrowthsAboveX64);
        const amountOwedX64 = positionRewardInfo.amountOwed.shln(64);
        const amountOwed = amountOwedX64.add(common_sdk_1.MathUtil.subUnderflowU128(rewardGrowthInsideX64, positionRewardInfo.growthInsideCheckpoint).mul(liquidity)).shrn(64);
        const transferFeeExcluded = token_extension_util_1.TokenExtensionUtil.calculateTransferFeeExcludedAmount(amountOwed, tokenExtensionCtx.rewardTokenMintsWithProgram[i], tokenExtensionCtx.currentEpoch);
        rewardOwed[i] = transferFeeExcluded.amount;
        transferFee[i] = transferFeeExcluded.fee;
    }
    return {
        rewardOwed,
        transferFee: {
            deductedFromRewardOwed: transferFee
        }
    };
} //# sourceMappingURL=collect-rewards-quote.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/dev-fee-swap-quote.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.swapQuoteByInputTokenWithDevFees = swapQuoteByInputTokenWithDevFees;
const errors_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/errors/errors.js [app-route] (ecmascript)");
const swap_quote_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/swap-quote.js [app-route] (ecmascript)");
async function swapQuoteByInputTokenWithDevFees(whirlpool, inputTokenMint, tokenAmount, slippageTolerance, programId, fetcher, devFeePercentage, opts) {
    if (devFeePercentage.toDecimal().greaterThanOrEqualTo(1)) {
        throw new errors_1.WhirlpoolsError("Provided devFeePercentage must be less than 100%", errors_1.SwapErrorCode.InvalidDevFeePercentage);
    }
    const devFeeAmount = tokenAmount.mul(devFeePercentage.numerator).div(devFeePercentage.denominator);
    const slippageAdjustedQuote = await (0, swap_quote_1.swapQuoteByInputToken)(whirlpool, inputTokenMint, tokenAmount.sub(devFeeAmount), slippageTolerance, programId, fetcher, opts);
    const devFeeAdjustedQuote = {
        ...slippageAdjustedQuote,
        amountSpecifiedIsInput: true,
        estimatedAmountIn: slippageAdjustedQuote.estimatedAmountIn.add(devFeeAmount),
        estimatedFeeAmount: slippageAdjustedQuote.estimatedFeeAmount.add(devFeeAmount),
        estimatedSwapFeeAmount: slippageAdjustedQuote.estimatedFeeAmount,
        devFeeAmount
    };
    return devFeeAdjustedQuote;
} //# sourceMappingURL=dev-fee-swap-quote.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/two-hop-swap-quote.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.twoHopSwapQuoteFromSwapQuotes = twoHopSwapQuoteFromSwapQuotes;
function twoHopSwapQuoteFromSwapQuotes(swapQuoteOne, swapQuoteTwo) {
    const amountSpecifiedIsInput = swapQuoteOne.amountSpecifiedIsInput;
    let [amount, otherAmountThreshold] = amountSpecifiedIsInput ? [
        swapQuoteOne.amount,
        swapQuoteTwo.otherAmountThreshold
    ] : [
        swapQuoteTwo.amount,
        swapQuoteOne.otherAmountThreshold
    ];
    return {
        amount,
        otherAmountThreshold,
        amountSpecifiedIsInput,
        aToBOne: swapQuoteOne.aToB,
        aToBTwo: swapQuoteTwo.aToB,
        sqrtPriceLimitOne: swapQuoteOne.sqrtPriceLimit,
        sqrtPriceLimitTwo: swapQuoteTwo.sqrtPriceLimit,
        tickArrayOne0: swapQuoteOne.tickArray0,
        tickArrayOne1: swapQuoteOne.tickArray1,
        tickArrayOne2: swapQuoteOne.tickArray2,
        tickArrayTwo0: swapQuoteTwo.tickArray0,
        tickArrayTwo1: swapQuoteTwo.tickArray1,
        tickArrayTwo2: swapQuoteTwo.tickArray2,
        supplementalTickArraysOne: swapQuoteOne.supplementalTickArrays,
        supplementalTickArraysTwo: swapQuoteTwo.supplementalTickArrays,
        swapOneEstimates: {
            ...swapQuoteOne
        },
        swapTwoEstimates: {
            ...swapQuoteTwo
        }
    };
} //# sourceMappingURL=two-hop-swap-quote.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/increase-liquidity-quote.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/decrease-liquidity-quote.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/collect-fees-quote.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/collect-rewards-quote.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/swap-quote.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/dev-fee-swap-quote.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/two-hop-swap-quote.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/composites/swap-with-route.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getSwapFromRoute = getSwapFromRoute;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const fetcher_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)");
const position_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/position-util.js [app-route] (ecmascript)");
const txn_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/txn-utils.js [app-route] (ecmascript)");
const swap_ix_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/swap-ix.js [app-route] (ecmascript)");
const two_hop_swap_ix_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/two-hop-swap-ix.js [app-route] (ecmascript)");
async function getSwapFromRoute(ctx, params, opts = fetcher_1.PREFER_CACHE, txBuilder = new common_sdk_1.TransactionBuilder(ctx.connection, ctx.wallet, (0, txn_utils_1.contextOptionsToBuilderOptions)(ctx.opts))) {
    const { route, wallet, resolvedAtaAccounts, slippage } = params;
    const requiredAtas = new Set();
    const requiredIntermediateAtas = new Set();
    const requiredTickArrays = [];
    let hasNativeMint = false;
    let nativeMintAmount = new bn_js_1.default(0);
    function addOrNative(mint, amount) {
        if (mint === spl_token_1.NATIVE_MINT.toBase58()) {
            hasNativeMint = true;
            nativeMintAmount = nativeMintAmount.add(amount);
        } else {
            requiredAtas.add(mint);
        }
    }
    for(let i = 0; i < route.subRoutes.length; i++){
        const routeFragment = route.subRoutes[i];
        const slippageAdjustedRoute = adjustQuoteForSlippage(routeFragment, slippage);
        if (slippageAdjustedRoute.hopQuotes.length == 1) {
            const { quote, mintA, mintB } = slippageAdjustedRoute.hopQuotes[0];
            requiredTickArrays.push(...[
                quote.tickArray0,
                quote.tickArray1,
                quote.tickArray2
            ]);
            const inputAmount = quote.amountSpecifiedIsInput ? quote.amount : quote.otherAmountThreshold;
            addOrNative(mintA.toString(), quote.aToB ? inputAmount : common_sdk_1.ZERO);
            addOrNative(mintB.toString(), !quote.aToB ? inputAmount : common_sdk_1.ZERO);
        } else if (slippageAdjustedRoute.hopQuotes.length == 2) {
            const { quote: quoteOne, mintA: mintOneA, mintB: mintOneB } = slippageAdjustedRoute.hopQuotes[0];
            const { quote: quoteTwo, mintA: mintTwoA, mintB: mintTwoB } = slippageAdjustedRoute.hopQuotes[1];
            const twoHopQuote = (0, __1.twoHopSwapQuoteFromSwapQuotes)(quoteOne, quoteTwo);
            requiredTickArrays.push(...[
                twoHopQuote.tickArrayOne0,
                twoHopQuote.tickArrayOne1,
                twoHopQuote.tickArrayOne2,
                twoHopQuote.tickArrayTwo0,
                twoHopQuote.tickArrayTwo1,
                twoHopQuote.tickArrayTwo2
            ]);
            const inputAmount = quoteOne.amountSpecifiedIsInput ? quoteOne.estimatedAmountIn : quoteOne.otherAmountThreshold;
            addOrNative(mintOneA.toString(), quoteOne.aToB ? inputAmount : common_sdk_1.ZERO);
            addOrNative(mintOneB.toString(), !quoteOne.aToB ? inputAmount : common_sdk_1.ZERO);
            addOrNative(mintTwoA.toString(), common_sdk_1.ZERO);
            addOrNative(mintTwoB.toString(), common_sdk_1.ZERO);
            requiredIntermediateAtas.add(quoteOne.aToB ? mintOneB.toString() : mintOneA.toString());
        }
    }
    requiredAtas.delete(spl_token_1.NATIVE_MINT.toBase58());
    const ataInstructionMap = await cachedResolveOrCreateNonNativeATAs(wallet, requiredAtas, requiredIntermediateAtas, (keys)=>{
        if (resolvedAtaAccounts != null) {
            return Promise.resolve(keys.map((key)=>resolvedAtaAccounts.find((ata)=>ata.address?.toBase58() === key.toBase58())));
        } else {
            return ctx.fetcher.getTokenInfos(keys, opts).then((result)=>Array.from(result.values()));
        }
    }, undefined, ctx.accountResolverOpts.allowPDAOwnerAddress);
    const ataIxes = Object.values(ataInstructionMap);
    if (hasNativeMint) {
        const solIx = common_sdk_1.TokenUtil.createWrappedNativeAccountInstruction(wallet, nativeMintAmount, await ctx.fetcher.getAccountRentExempt(), undefined, undefined, ctx.accountResolverOpts.createWrappedSolAccountMethod);
        txBuilder.addInstruction(solIx);
        ataInstructionMap[spl_token_1.NATIVE_MINT.toBase58()] = solIx;
    }
    txBuilder.addInstructions(ataIxes);
    const slippageAdjustedQuotes = route.subRoutes.map((quote)=>adjustQuoteForSlippage(quote, slippage));
    for(let i = 0; i < slippageAdjustedQuotes.length; i++){
        const routeFragment = slippageAdjustedQuotes[i];
        if (routeFragment.hopQuotes.length == 1) {
            const { quote, whirlpool, mintA, mintB, vaultA, vaultB } = routeFragment.hopQuotes[0];
            const [wp, tokenVaultA, tokenVaultB] = common_sdk_1.AddressUtil.toPubKeys([
                whirlpool,
                vaultA,
                vaultB
            ]);
            const accA = ataInstructionMap[mintA.toString()].address;
            const accB = ataInstructionMap[mintB.toString()].address;
            const oraclePda = __1.PDAUtil.getOracle(ctx.program.programId, wp);
            txBuilder.addInstruction((0, swap_ix_1.swapIx)(ctx.program, {
                whirlpool: wp,
                tokenOwnerAccountA: accA,
                tokenOwnerAccountB: accB,
                tokenVaultA,
                tokenVaultB,
                oracle: oraclePda.publicKey,
                tokenAuthority: wallet,
                ...quote
            }));
        } else if (routeFragment.hopQuotes.length == 2) {
            const { quote: quoteOne, whirlpool: whirlpoolOne, mintA: mintOneA, mintB: mintOneB, vaultA: vaultOneA, vaultB: vaultOneB } = routeFragment.hopQuotes[0];
            const { quote: quoteTwo, whirlpool: whirlpoolTwo, mintA: mintTwoA, mintB: mintTwoB, vaultA: vaultTwoA, vaultB: vaultTwoB } = routeFragment.hopQuotes[1];
            const [wpOne, wpTwo, tokenVaultOneA, tokenVaultOneB, tokenVaultTwoA, tokenVaultTwoB] = common_sdk_1.AddressUtil.toPubKeys([
                whirlpoolOne,
                whirlpoolTwo,
                vaultOneA,
                vaultOneB,
                vaultTwoA,
                vaultTwoB
            ]);
            const twoHopQuote = (0, __1.twoHopSwapQuoteFromSwapQuotes)(quoteOne, quoteTwo);
            const oracleOne = __1.PDAUtil.getOracle(ctx.program.programId, wpOne).publicKey;
            const oracleTwo = __1.PDAUtil.getOracle(ctx.program.programId, wpTwo).publicKey;
            const tokenOwnerAccountOneA = ataInstructionMap[mintOneA.toString()].address;
            const tokenOwnerAccountOneB = ataInstructionMap[mintOneB.toString()].address;
            const tokenOwnerAccountTwoA = ataInstructionMap[mintTwoA.toString()].address;
            const tokenOwnerAccountTwoB = ataInstructionMap[mintTwoB.toString()].address;
            txBuilder.addInstruction((0, two_hop_swap_ix_1.twoHopSwapIx)(ctx.program, {
                ...twoHopQuote,
                whirlpoolOne: wpOne,
                whirlpoolTwo: wpTwo,
                tokenOwnerAccountOneA,
                tokenOwnerAccountOneB,
                tokenOwnerAccountTwoA,
                tokenOwnerAccountTwoB,
                tokenVaultOneA,
                tokenVaultOneB,
                tokenVaultTwoA,
                tokenVaultTwoB,
                oracleOne,
                oracleTwo,
                tokenAuthority: wallet
            }));
        }
    }
    return txBuilder;
}
function adjustQuoteForSlippage(quote, slippage) {
    const { hopQuotes } = quote;
    if (hopQuotes.length === 1) {
        return {
            ...quote,
            hopQuotes: [
                {
                    ...hopQuotes[0],
                    quote: {
                        ...hopQuotes[0].quote,
                        ...__1.SwapUtils.calculateSwapAmountsFromQuote(hopQuotes[0].quote.amount, hopQuotes[0].quote.estimatedAmountIn, hopQuotes[0].quote.estimatedAmountOut, slippage, hopQuotes[0].quote.amountSpecifiedIsInput)
                    }
                }
            ]
        };
    } else if (quote.hopQuotes.length === 2) {
        const swapQuoteOne = quote.hopQuotes[0];
        const swapQuoteTwo = quote.hopQuotes[1];
        const amountSpecifiedIsInput = swapQuoteOne.quote.amountSpecifiedIsInput;
        let updatedQuote = {
            ...quote
        };
        if (amountSpecifiedIsInput) {
            updatedQuote.hopQuotes = [
                updatedQuote.hopQuotes[0],
                {
                    ...swapQuoteTwo,
                    quote: {
                        ...swapQuoteTwo.quote,
                        otherAmountThreshold: (0, position_util_1.adjustForSlippage)(swapQuoteTwo.quote.estimatedAmountOut, slippage, false)
                    }
                }
            ];
        } else {
            updatedQuote.hopQuotes = [
                {
                    ...swapQuoteOne,
                    quote: {
                        ...swapQuoteOne.quote,
                        otherAmountThreshold: (0, position_util_1.adjustForSlippage)(swapQuoteOne.quote.estimatedAmountIn, slippage, true)
                    }
                },
                updatedQuote.hopQuotes[1]
            ];
        }
        return updatedQuote;
    }
    return quote;
}
async function cachedResolveOrCreateNonNativeATAs(ownerAddress, tokenMints, intermediateTokenMints, getTokenAccounts, payer = ownerAddress, allowPDAOwnerAddress = false) {
    const instructionMap = {};
    const tokenMintArray = Array.from(tokenMints).map((tm)=>new web3_js_1.PublicKey(tm));
    const tokenAtas = tokenMintArray.map((tm)=>(0, spl_token_1.getAssociatedTokenAddressSync)(tm, ownerAddress, allowPDAOwnerAddress));
    const tokenAccounts = await getTokenAccounts(tokenAtas);
    tokenAccounts.forEach((tokenAccount, index)=>{
        const ataAddress = tokenAtas[index];
        let resolvedInstruction;
        if (tokenAccount) {
            if (!tokenAccount.owner.equals(ownerAddress)) {
                throw new Error(`ATA with change of ownership detected: ${ataAddress.toBase58()}`);
            }
            resolvedInstruction = {
                address: ataAddress,
                ...common_sdk_1.EMPTY_INSTRUCTION
            };
        } else {
            const tokenMint = tokenMintArray[index];
            const createAtaInstructions = [
                (0, spl_token_1.createAssociatedTokenAccountInstruction)(payer, ataAddress, ownerAddress, tokenMint)
            ];
            let cleanupInstructions = [];
            if (intermediateTokenMints.has(tokenMint.toBase58())) {
                cleanupInstructions = [
                    (0, spl_token_1.createCloseAccountInstruction)(ataAddress, ownerAddress, ownerAddress)
                ];
            }
            resolvedInstruction = {
                address: ataAddress,
                instructions: createAtaInstructions,
                cleanupInstructions: cleanupInstructions,
                signers: []
            };
        }
        instructionMap[tokenMintArray[index].toBase58()] = {
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
            ...resolvedInstruction
        };
    });
    return instructionMap;
} //# sourceMappingURL=swap-with-route.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/math/k-smallest-partition.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.kSmallestPartition = kSmallestPartition;
const RECURSION_BREAKPOINT = 600;
function kSmallestPartition(array, k, left = 0, right = array.length - 1, compare = defaultCompare) {
    while(right > left){
        if (right - left > RECURSION_BREAKPOINT) {
            const n = right - left + 1;
            const i = k - left + 1;
            const z = Math.log(n);
            const s = 0.5 * Math.exp(2 * z / 3);
            const sd = 0.5 * Math.sqrt(z * s * (n - s) / n) * (i - n / 2 < 0 ? -1 : 1);
            const newLeft = Math.max(left, Math.floor(k - i * s / n + sd));
            const newRight = Math.min(right, Math.floor(k + (n - i) * s / n + sd));
            kSmallestPartition(array, k, newLeft, newRight, compare);
        }
        const t = array[k];
        let i = left;
        let j = right;
        swap(array, left, k);
        if (compare(array[right], t) > 0) {
            swap(array, left, right);
        }
        while(i < j){
            swap(array, i, j);
            i++;
            j--;
            while(compare(array[i], t) < 0){
                i++;
            }
            while(compare(array[j], t) > 0){
                j--;
            }
        }
        if (compare(array[left], t) === 0) {
            swap(array, left, j);
        } else {
            j++;
            swap(array, j, right);
        }
        if (j <= k) {
            left = j + 1;
        }
        if (k <= j) {
            right = j - 1;
        }
    }
}
function swap(arr, i, j) {
    const tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
}
function defaultCompare(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
} //# sourceMappingURL=k-smallest-partition.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/convert-quote-map.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getBestRoutesFromQuoteMap = getBestRoutesFromQuoteMap;
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const k_smallest_partition_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/math/k-smallest-partition.js [app-route] (ecmascript)");
function getBestRoutesFromQuoteMap(quoteMap, amountSpecifiedIsInput, opts) {
    const { numTopRoutes, maxSplits } = opts;
    const sortedRoutes = [
        ...getRankedRoutes(quoteMap, amountSpecifiedIsInput, numTopRoutes, maxSplits),
        ...getSingleHopSplit(quoteMap)
    ].sort(getRouteCompareFn(amountSpecifiedIsInput));
    return convertInternalRoutesToTradeRoutes(sortedRoutes);
}
function convertInternalRoutesToTradeRoutes(internalRoutes) {
    const tradeRoutes = internalRoutes.map((internalRoute)=>{
        const { quotes, totalIn, totalOut } = internalRoute;
        return {
            subRoutes: quotes.map((quote)=>convertPathQuoteToSubTradeRoute(quote)),
            totalAmountIn: totalIn,
            totalAmountOut: totalOut
        };
    });
    return tradeRoutes;
}
function convertPathQuoteToSubTradeRoute(pathQuote) {
    const { calculatedEdgeQuotes, path, splitPercent, amountIn, amountOut } = pathQuote;
    return {
        path,
        splitPercent,
        amountIn,
        amountOut,
        hopQuotes: calculatedEdgeQuotes
    };
}
function getSingleHopSplit(quoteMap) {
    const fullFlow = quoteMap[100];
    if (fullFlow) {
        return fullFlow.filter((f)=>f.calculatedEdgeQuotes.length == 1).map((f)=>{
            const oneHop = f.calculatedEdgeQuotes[0];
            return {
                quotes: [
                    f
                ],
                splitPercent: 100,
                totalIn: oneHop.amountIn,
                totalOut: oneHop.amountOut
            };
        }).flatMap((g)=>!!g ? g : []);
    }
    return [];
}
function getRankedRoutes(percentMap, amountSpecifiedIsInput, topN, maxSplits) {
    let routes = generateRoutes(percentMap, maxSplits);
    const routeCompare = getRouteCompareFn(amountSpecifiedIsInput);
    if (routes.length <= topN) {
        return routes.sort(routeCompare);
    }
    (0, k_smallest_partition_1.kSmallestPartition)(routes, topN, 0, routes.length - 1, routeCompare);
    return routes.slice(0, topN).sort(routeCompare);
}
function generateRoutes(percentMap, maxSplits) {
    let routes = [];
    buildRoutes(percentMap, maxSplits, {
        quotes: [],
        splitPercent: 0,
        totalIn: new bn_js_1.default(0),
        totalOut: new bn_js_1.default(0)
    }, routes);
    return routes;
}
function buildRoutes(quotePercentMap, maxSplits, currentRoute, routes) {
    const { splitPercent: percent, quotes } = currentRoute;
    const percents = Object.keys(quotePercentMap).map((percent)=>Number(percent));
    for(let i = percents.length - 1; i >= 0; i--){
        const nextPercent = percents[i];
        const newPercentTotal = percent + nextPercent;
        const nextPercentIsSmaller = quotes.length > 0 && nextPercent > quotes[quotes.length - 1].splitPercent;
        if (newPercentTotal > 100 || nextPercentIsSmaller) {
            continue;
        }
        const nextPercentQuotes = quotePercentMap[nextPercent];
        for(let j = 0; j < nextPercentQuotes.length; j++){
            const nextQuote = nextPercentQuotes[j];
            const hasReusedPools = nextQuote.edgesPoolAddrs.some((r1)=>quotes.some((r2)=>r2.edgesPoolAddrs.some((r3)=>r3.indexOf(r1) !== -1)));
            if (hasReusedPools) {
                continue;
            }
            const nextRoute = {
                quotes: [
                    ...quotes,
                    nextQuote
                ],
                splitPercent: newPercentTotal,
                totalIn: currentRoute.totalIn.add(nextQuote.amountIn),
                totalOut: currentRoute.totalOut.add(nextQuote.amountOut)
            };
            const nextCandidateQuotes = nextPercentQuotes.slice(j + 1);
            if (newPercentTotal === 100) {
                routes.push(nextRoute);
            } else if (quotes.length + 1 != maxSplits) {
                buildRoutes({
                    ...quotePercentMap,
                    [nextPercent]: nextCandidateQuotes
                }, maxSplits, nextRoute, routes);
            }
        }
    }
}
function getRouteCompareFn(amountSpecifiedIsInput) {
    return amountSpecifiedIsInput ? routesCompareForInputAmount : routesCompareForOutputAmount;
}
function routesCompareForInputAmount(a, b) {
    return b.totalOut.cmp(a.totalOut);
}
function routesCompareForOutputAmount(a, b) {
    return a.totalIn.cmp(b.totalIn);
} //# sourceMappingURL=convert-quote-map.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/batch-swap-quote.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.batchBuildSwapQuoteParams = batchBuildSwapQuoteParams;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
async function batchBuildSwapQuoteParams(quoteRequests, programId, fetcher, opts) {
    const whirlpools = await fetcher.getPools(quoteRequests.map((req)=>req.whirlpool), opts);
    const program = common_sdk_1.AddressUtil.toPubKey(programId);
    const tickArrayRequests = quoteRequests.map((quoteReq)=>{
        const { whirlpool, tokenAmount, tradeTokenMint, amountSpecifiedIsInput } = quoteReq;
        const whirlpoolData = whirlpools.get(common_sdk_1.AddressUtil.toString(whirlpool));
        const swapMintKey = common_sdk_1.AddressUtil.toPubKey(tradeTokenMint);
        const swapTokenType = public_1.PoolUtil.getTokenType(whirlpoolData, swapMintKey);
        (0, tiny_invariant_1.default)(!!swapTokenType, "swapTokenMint does not match any tokens on this pool");
        const aToB = public_1.SwapUtils.getSwapDirection(whirlpoolData, swapMintKey, amountSpecifiedIsInput) === public_1.SwapDirection.AtoB;
        return {
            whirlpoolData,
            tokenAmount,
            aToB,
            tickCurrentIndex: whirlpoolData.tickCurrentIndex,
            tickSpacing: whirlpoolData.tickSpacing,
            whirlpoolAddress: common_sdk_1.AddressUtil.toPubKey(whirlpool),
            amountSpecifiedIsInput
        };
    });
    const tickArrays = await public_1.SwapUtils.getBatchTickArrays(program, fetcher, tickArrayRequests, opts);
    return tickArrayRequests.map((req, index)=>{
        const { whirlpoolData, tokenAmount, aToB, amountSpecifiedIsInput } = req;
        return {
            whirlpoolData,
            tokenAmount,
            aToB,
            amountSpecifiedIsInput,
            sqrtPriceLimit: public_1.SwapUtils.getDefaultSqrtPriceLimit(aToB),
            otherAmountThreshold: public_1.SwapUtils.getDefaultOtherAmountThreshold(amountSpecifiedIsInput),
            tickArrays: tickArrays[index],
            tokenExtensionCtx: token_extension_util_1.NO_TOKEN_EXTENSION_CONTEXT
        };
    });
} //# sourceMappingURL=batch-swap-quote.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/quote-map.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getQuoteMap = getQuoteMap;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const fetcher_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/index.js [app-route] (ecmascript)");
const public_2 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const batch_swap_quote_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/batch-swap-quote.js [app-route] (ecmascript)");
async function getQuoteMap(trade, paths, amountSpecifiedIsInput, programId, fetcher, opts) {
    const { percentIncrement, numTopPartialQuotes } = opts;
    const { tokenIn, tokenOut, tradeAmount } = trade;
    const { percents, amounts } = getSplitPercentageAmts(tradeAmount, percentIncrement);
    const maxRouteLength = Math.max(...paths.map((path)=>path.edges.length), 0);
    const quoteMap = {};
    let iteration = Array.from(Array(maxRouteLength).keys());
    if (!amountSpecifiedIsInput) {
        iteration = iteration.reverse();
    }
    try {
        for (const hop of iteration){
            const quoteUpdates = buildQuoteUpdateRequests(tokenIn, tokenOut, paths, percents, amounts, hop, amountSpecifiedIsInput, quoteMap);
            const quoteParams = await (0, batch_swap_quote_1.batchBuildSwapQuoteParams)(quoteUpdates.map((update)=>update.request), common_sdk_1.AddressUtil.toPubKey(programId), fetcher, fetcher_1.PREFER_CACHE);
            populateQuoteMap(quoteUpdates, quoteParams, quoteMap);
        }
    } catch (e) {
        throw e;
    }
    return sanitizeQuoteMap(quoteMap, numTopPartialQuotes, amountSpecifiedIsInput);
}
function populateQuoteMap(quoteUpdates, quoteParams, quoteMap) {
    for (const { splitPercent, pathIndex, quoteIndex, edgeIndex, request } of quoteUpdates){
        const swapParam = quoteParams[quoteIndex];
        const path = quoteMap[splitPercent][pathIndex];
        try {
            const quote = (0, public_1.swapQuoteWithParams)(swapParam, common_sdk_1.Percentage.fromFraction(0, 1000));
            const { whirlpoolData, tokenAmount, aToB, amountSpecifiedIsInput } = swapParam;
            const [mintA, mintB, vaultA, vaultB] = [
                whirlpoolData.tokenMintA.toBase58(),
                whirlpoolData.tokenMintB.toBase58(),
                whirlpoolData.tokenVaultA.toBase58(),
                whirlpoolData.tokenVaultB.toBase58()
            ];
            const [inputMint, outputMint] = aToB ? [
                mintA,
                mintB
            ] : [
                mintB,
                mintA
            ];
            path.calculatedEdgeQuotes[edgeIndex] = {
                success: true,
                amountIn: amountSpecifiedIsInput ? tokenAmount : quote.estimatedAmountIn,
                amountOut: amountSpecifiedIsInput ? quote.estimatedAmountOut : tokenAmount,
                whirlpool: request.whirlpool,
                inputMint,
                outputMint,
                mintA,
                mintB,
                vaultA,
                vaultB,
                quote,
                snapshot: {
                    aToB: swapParam.aToB,
                    sqrtPrice: whirlpoolData.sqrtPrice,
                    feeRate: public_2.PoolUtil.getFeeRate(whirlpoolData.feeRate)
                }
            };
        } catch (e) {
            const errorCode = e.errorCode;
            path.calculatedEdgeQuotes[edgeIndex] = {
                success: false,
                error: errorCode
            };
            continue;
        }
    }
}
function buildQuoteUpdateRequests(tokenIn, tokenOut, paths, percents, amounts, hop, amountSpecifiedIsInput, quoteMap) {
    const quoteUpdates = [];
    for(let amountIndex = 0; amountIndex < amounts.length; amountIndex++){
        const percent = percents[amountIndex];
        const tradeAmount = amounts[amountIndex];
        if (!quoteMap[percent]) {
            quoteMap[percent] = Array(paths.length);
        }
        for(let pathIndex = 0; pathIndex < paths.length; pathIndex++){
            const path = paths[pathIndex];
            const edges = path.edges;
            if (amountSpecifiedIsInput ? edges.length <= hop : hop > edges.length - 1) {
                continue;
            }
            const startingRouteEval = amountSpecifiedIsInput ? hop === 0 : hop === edges.length - 1;
            const poolsPath = common_sdk_1.AddressUtil.toStrings(edges.map((edge)=>edge.poolAddress));
            if (startingRouteEval) {
                quoteMap[percent][pathIndex] = {
                    path: path,
                    splitPercent: percent,
                    edgesPoolAddrs: poolsPath,
                    calculatedEdgeQuotes: Array(edges.length)
                };
            }
            const currentQuote = quoteMap[percent][pathIndex];
            const poolAddr = poolsPath[hop];
            const lastHop = amountSpecifiedIsInput ? currentQuote.calculatedEdgeQuotes[hop - 1] : currentQuote.calculatedEdgeQuotes[hop + 1];
            let tokenAmount;
            let tradeToken;
            if (startingRouteEval) {
                tokenAmount = tradeAmount;
                tradeToken = amountSpecifiedIsInput ? tokenIn : tokenOut;
            } else {
                if (!lastHop?.success) {
                    continue;
                }
                tokenAmount = amountSpecifiedIsInput ? lastHop.amountOut : lastHop.amountIn;
                tradeToken = amountSpecifiedIsInput ? lastHop.outputMint : lastHop.inputMint;
            }
            quoteUpdates.push({
                splitPercent: percent,
                pathIndex,
                edgeIndex: hop,
                quoteIndex: quoteUpdates.length,
                request: {
                    whirlpool: poolAddr,
                    tradeTokenMint: tradeToken,
                    tokenAmount,
                    amountSpecifiedIsInput
                }
            });
        }
    }
    return quoteUpdates;
}
function sanitizeQuoteMap(quoteMap, pruneN, amountSpecifiedIsInput) {
    const percents = Object.keys(quoteMap).map((percent)=>Number(percent));
    const cleanedQuoteMap = {};
    const failureErrors = new Set();
    for(let i = 0; i < percents.length; i++){
        const percent = percents[i];
        const uncleanedQuotes = quoteMap[percent];
        cleanedQuoteMap[percent] = [];
        for (const { edgesPoolAddrs: hopPoolAddrs, calculatedEdgeQuotes: calculatedHops, path } of uncleanedQuotes){
            const filteredCalculatedEdges = calculatedHops.flatMap((val)=>!!val && val.success ? val : []);
            if (filteredCalculatedEdges.length === hopPoolAddrs.length) {
                const [input, output] = [
                    filteredCalculatedEdges[0].amountIn,
                    filteredCalculatedEdges[filteredCalculatedEdges.length - 1].amountOut
                ];
                cleanedQuoteMap[percent].push({
                    path,
                    splitPercent: percent,
                    edgesPoolAddrs: hopPoolAddrs,
                    amountIn: input,
                    amountOut: output,
                    calculatedEdgeQuotes: filteredCalculatedEdges
                });
                continue;
            }
            const quoteFailures = calculatedHops.flatMap((f)=>f && !f?.success ? f : []);
            failureErrors.add(quoteFailures[0].error);
        }
    }
    const prunedQuoteMap = {};
    const sortFn = amountSpecifiedIsInput ? (a, b)=>b.amountOut.cmp(a.amountOut) : (a, b)=>a.amountIn.cmp(b.amountIn);
    for(let i = 0; i < percents.length; i++){
        const sortedQuotes = cleanedQuoteMap[percents[i]].sort(sortFn);
        const slicedSorted = sortedQuotes.slice(0, pruneN);
        prunedQuoteMap[percents[i]] = slicedSorted;
    }
    return [
        prunedQuoteMap,
        failureErrors
    ];
}
function getSplitPercentageAmts(inputAmount, minPercent = 5) {
    const percents = [];
    const amounts = [];
    for(let i = 1; i <= 100 / minPercent; i++){
        percents.push(i * minPercent);
        amounts.push(inputAmount.mul(new bn_js_1.default(i * minPercent)).div(new bn_js_1.default(100)));
    }
    return {
        percents,
        amounts
    };
} //# sourceMappingURL=quote-map.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/router-impl.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WhirlpoolRouterImpl = void 0;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const errors_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/errors/errors.js [app-route] (ecmascript)");
const swap_with_route_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/composites/swap-with-route.js [app-route] (ecmascript)");
const fetcher_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const convert_quote_map_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/convert-quote-map.js [app-route] (ecmascript)");
const public_2 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/public/index.js [app-route] (ecmascript)");
const quote_map_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/quote-map.js [app-route] (ecmascript)");
class WhirlpoolRouterImpl {
    ctx;
    poolGraph;
    constructor(ctx, poolGraph){
        this.ctx = ctx;
        this.poolGraph = poolGraph;
    }
    async findAllRoutes(trade, opts, fetchOpts) {
        const { tokenIn, tokenOut, tradeAmount, amountSpecifiedIsInput } = trade;
        const paths = this.poolGraph.getPath(tokenIn, tokenOut);
        if (paths.length === 0) {
            return Promise.reject(new errors_1.WhirlpoolsError(`Could not find route for ${tokenIn} -> ${tokenOut}`, errors_1.RouteQueryErrorCode.RouteDoesNotExist));
        }
        if (tradeAmount.isZero()) {
            return Promise.reject(new errors_1.WhirlpoolsError(`findBestRoutes error - input amount is zero.`, errors_1.RouteQueryErrorCode.ZeroInputAmount));
        }
        const routingOptions = {
            ...public_2.RouterUtils.getDefaultRouteOptions(),
            ...opts
        };
        const { program, fetcher } = this.ctx;
        const programId = program.programId;
        await prefetchRoutes(paths, programId, fetcher, fetchOpts);
        try {
            const [quoteMap, failures] = await (0, quote_map_1.getQuoteMap)(trade, paths, amountSpecifiedIsInput, programId, fetcher, routingOptions);
            const bestRoutes = (0, convert_quote_map_1.getBestRoutesFromQuoteMap)(quoteMap, amountSpecifiedIsInput, routingOptions);
            if (bestRoutes.length === 0) {
                if (failures.has(errors_1.SwapErrorCode.TickArraySequenceInvalid)) {
                    return Promise.reject(new errors_1.WhirlpoolsError(`All swap quote generation failed on amount too high.`, errors_1.RouteQueryErrorCode.TradeAmountTooHigh));
                }
            }
            return bestRoutes;
        } catch (e) {
            return Promise.reject(new errors_1.WhirlpoolsError(`Stack error received on quote generation.`, errors_1.RouteQueryErrorCode.General, e instanceof Error ? e.stack : ""));
        }
    }
    async findBestRoute(trade, routingOpts, selectionOpts, fetchOpts) {
        const allRoutes = await this.findAllRoutes(trade, routingOpts, fetchOpts);
        const selectOpts = {
            ...public_2.RouterUtils.getDefaultSelectOptions(),
            ...selectionOpts
        };
        return await public_2.RouterUtils.selectFirstExecutableRoute(this.ctx, allRoutes, selectOpts);
    }
    async swap(trade, slippage, resolvedAtas) {
        const txBuilder = await (0, swap_with_route_1.getSwapFromRoute)(this.ctx, {
            route: trade,
            slippage,
            resolvedAtaAccounts: resolvedAtas,
            wallet: this.ctx.wallet.publicKey
        }, fetcher_1.IGNORE_CACHE);
        return txBuilder;
    }
}
exports.WhirlpoolRouterImpl = WhirlpoolRouterImpl;
async function prefetchRoutes(paths, programId, fetcher, opts = fetcher_1.PREFER_CACHE) {
    const poolSet = new Set();
    for(let i = 0; i < paths.length; i++){
        const path = paths[i];
        for(let j = 0; j < path.edges.length; j++){
            poolSet.add(common_sdk_1.AddressUtil.toString(path.edges[j].poolAddress));
        }
    }
    const ps = Array.from(poolSet);
    const allWps = await fetcher.getPools(ps, opts);
    const tickArrayAddresses = [];
    for (const [key, wp] of allWps){
        if (wp == null) {
            continue;
        }
        const addr1 = public_1.SwapUtils.getTickArrayPublicKeys(wp.tickCurrentIndex, wp.tickSpacing, true, common_sdk_1.AddressUtil.toPubKey(programId), common_sdk_1.AddressUtil.toPubKey(key));
        const addr2 = public_1.SwapUtils.getTickArrayPublicKeys(wp.tickCurrentIndex, wp.tickSpacing, false, common_sdk_1.AddressUtil.toPubKey(programId), common_sdk_1.AddressUtil.toPubKey(key));
        const allAddrs = [
            ...addr1,
            ...addr2
        ].map((k)=>k.toBase58());
        const unique = Array.from(new Set(allAddrs));
        tickArrayAddresses.push(...unique);
    }
    await fetcher.getTickArrays(tickArrayAddresses, opts);
} //# sourceMappingURL=router-impl.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/public/router-builder.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WhirlpoolRouterBuilder = void 0;
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const router_impl_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/router-impl.js [app-route] (ecmascript)");
class WhirlpoolRouterBuilder {
    static buildWithPoolGraph(ctx, graph) {
        return new router_impl_1.WhirlpoolRouterImpl(ctx, graph);
    }
    static async buildWithPools(ctx, pools) {
        const poolGraph = await public_1.PoolGraphBuilder.buildPoolGraphWithFetch(pools, ctx.fetcher);
        return new router_impl_1.WhirlpoolRouterImpl(ctx, poolGraph);
    }
}
exports.WhirlpoolRouterBuilder = WhirlpoolRouterBuilder; //# sourceMappingURL=router-builder.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/math/constants.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.U64 = void 0;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
exports.U64 = common_sdk_1.U64_MAX.add(common_sdk_1.ONE); //# sourceMappingURL=constants.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/wallet-utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.isWalletConnected = isWalletConnected;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function isWalletConnected(wallet) {
    return wallet !== null && !wallet.publicKey.equals(web3_js_1.PublicKey.default);
} //# sourceMappingURL=wallet-utils.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/public/router-utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.RouterUtils = void 0;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const decimal_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)"));
const swap_with_route_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/composites/swap-with-route.js [app-route] (ecmascript)");
const fetcher_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/math/constants.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const wallet_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/wallet-utils.js [app-route] (ecmascript)");
class RouterUtils {
    static async selectFirstExecutableRoute(ctx, orderedRoutes, opts) {
        const { wallet } = ctx;
        if (orderedRoutes.length === 0) {
            return null;
        }
        if (!(0, wallet_utils_1.isWalletConnected)(wallet)) {
            return [
                orderedRoutes[0],
                undefined
            ];
        }
        if (opts.maxSupportedTransactionVersion !== "legacy" && ctx.lookupTableFetcher) {
            await loadLookupTablesForRoutes(ctx.lookupTableFetcher, orderedRoutes);
        }
        for(let i = 0; i < orderedRoutes.length && i < MEASURE_ROUTE_MAX; i++){
            const route = orderedRoutes[i];
            const tx = await (0, swap_with_route_1.getSwapFromRoute)(ctx, {
                route,
                slippage: common_sdk_1.Percentage.fromFraction(0, 100),
                resolvedAtaAccounts: opts.availableAtaAccounts ?? null,
                wallet: wallet.publicKey
            }, fetcher_1.PREFER_CACHE);
            if (!!opts.onRouteEvaluation) {
                opts.onRouteEvaluation(route, tx);
            }
            try {
                const legacyTxSize = tx.txnSize({
                    latestBlockhash: common_sdk_1.MEASUREMENT_BLOCKHASH,
                    maxSupportedTransactionVersion: "legacy"
                });
                if (legacyTxSize !== undefined && legacyTxSize <= opts.maxTransactionSize) {
                    return [
                        route,
                        undefined
                    ];
                }
            } catch  {}
            let v0TxSize;
            if (opts.maxSupportedTransactionVersion !== "legacy" && ctx.lookupTableFetcher) {
                const addressesToLookup = RouterUtils.getTouchedTickArraysFromRoute(route);
                if (addressesToLookup.length > MAX_LOOKUP_TABLE_FETCH_SIZE) {
                    continue;
                }
                const lookupTableAccounts = await ctx.lookupTableFetcher.getLookupTableAccountsForAddresses(addressesToLookup);
                try {
                    v0TxSize = tx.txnSize({
                        latestBlockhash: common_sdk_1.MEASUREMENT_BLOCKHASH,
                        maxSupportedTransactionVersion: opts.maxSupportedTransactionVersion,
                        lookupTableAccounts
                    });
                    if (v0TxSize !== undefined && v0TxSize <= opts.maxTransactionSize) {
                        return [
                            route,
                            lookupTableAccounts
                        ];
                    }
                } catch  {}
            }
        }
        return null;
    }
    static getPriceImpactForRoute(trade, route) {
        const { amountSpecifiedIsInput } = trade;
        const totalBaseValue = route.subRoutes.reduce((acc, route)=>{
            const directionalHops = amountSpecifiedIsInput ? route.hopQuotes : route.hopQuotes.slice().reverse();
            const baseOutputs = directionalHops.reduce((acc, quote, index)=>{
                const { snapshot } = quote;
                const { aToB, sqrtPrice, feeRate } = snapshot;
                const directionalSqrtPrice = aToB ? sqrtPrice : public_1.PriceMath.invertSqrtPriceX64(sqrtPrice);
                let nextBaseValue;
                const price = directionalSqrtPrice.mul(directionalSqrtPrice).div(constants_1.U64);
                if (amountSpecifiedIsInput) {
                    const amountIn = index === 0 ? quote.amountIn : acc[index - 1];
                    const feeAdjustedAmount = amountIn.mul(feeRate.denominator.sub(feeRate.numerator)).div(feeRate.denominator);
                    nextBaseValue = price.mul(feeAdjustedAmount).div(constants_1.U64);
                } else {
                    const amountOut = index === 0 ? quote.amountOut : acc[index - 1];
                    const feeAdjustedAmount = amountOut.mul(constants_1.U64).div(price);
                    nextBaseValue = feeAdjustedAmount.mul(feeRate.denominator).div(feeRate.denominator.sub(feeRate.numerator));
                }
                acc.push(nextBaseValue);
                return acc;
            }, new Array());
            return acc.add(baseOutputs[baseOutputs.length - 1]);
        }, new bn_js_1.default(0));
        const totalBaseValueDec = new decimal_js_1.default(totalBaseValue.toString());
        const totalAmountEstimatedDec = new decimal_js_1.default(amountSpecifiedIsInput ? route.totalAmountOut.toString() : route.totalAmountIn.toString());
        const priceImpact = amountSpecifiedIsInput ? totalBaseValueDec.sub(totalAmountEstimatedDec).div(totalBaseValueDec) : totalAmountEstimatedDec.sub(totalBaseValueDec).div(totalAmountEstimatedDec);
        return priceImpact.mul(100);
    }
    static getTouchedTickArraysFromRoute(route) {
        const taAddresses = new Set();
        for (const quote of route.subRoutes){
            for (const hop of quote.hopQuotes){
                taAddresses.add(hop.quote.tickArray0.toBase58());
                taAddresses.add(hop.quote.tickArray1.toBase58());
                taAddresses.add(hop.quote.tickArray2.toBase58());
            }
        }
        return common_sdk_1.AddressUtil.toPubKeys(Array.from(taAddresses));
    }
    static getDefaultRouteOptions() {
        return {
            percentIncrement: 20,
            numTopRoutes: 50,
            numTopPartialQuotes: 10,
            maxSplits: 3
        };
    }
    static getDefaultSelectOptions() {
        return {
            maxSupportedTransactionVersion: 0,
            maxTransactionSize: common_sdk_1.TX_SIZE_LIMIT
        };
    }
}
exports.RouterUtils = RouterUtils;
async function loadLookupTablesForRoutes(lookupTableFetcher, routes) {
    const altTicks = new Set();
    for(let i = 0; i < routes.length && i < MEASURE_ROUTE_MAX; i++){
        const route = routes[i];
        RouterUtils.getTouchedTickArraysFromRoute(route).map((ta)=>altTicks.add(ta.toBase58()));
    }
    const altTickArray = Array.from(altTicks);
    const altPageSize = 45;
    const altRequests = [];
    for(let i = 0; i < altTickArray.length; i += altPageSize){
        altRequests.push(altTickArray.slice(i, i + altPageSize));
    }
    await Promise.all(altRequests.map((altPage)=>{
        const altPageKeys = common_sdk_1.AddressUtil.toPubKeys(altPage);
        lookupTableFetcher.loadLookupTables(altPageKeys);
    }));
}
const MEASURE_ROUTE_MAX = 100;
const MAX_LOOKUP_TABLE_FETCH_SIZE = 50; //# sourceMappingURL=router-utils.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/public/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/public/router-builder.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/public/router-utils.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/impl/util.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getTokenMintInfos = getTokenMintInfos;
exports.getRewardInfos = getRewardInfos;
exports.getTokenVaultAccountInfos = getTokenVaultAccountInfos;
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const __1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
async function getTokenMintInfos(fetcher, data, opts) {
    const mintA = data.tokenMintA;
    const infoA = await fetcher.getMintInfo(mintA, opts);
    if (!infoA) {
        throw new Error(`Unable to fetch MintInfo for mint - ${mintA}`);
    }
    const mintB = data.tokenMintB;
    const infoB = await fetcher.getMintInfo(mintB, opts);
    if (!infoB) {
        throw new Error(`Unable to fetch MintInfo for mint - ${mintB}`);
    }
    return [
        {
            mint: mintA,
            ...infoA
        },
        {
            mint: mintB,
            ...infoB
        }
    ];
}
async function getRewardInfos(fetcher, data, opts) {
    const rewardInfos = [];
    for (const rewardInfo of data.rewardInfos){
        rewardInfos.push(await getRewardInfo(fetcher, rewardInfo, opts));
    }
    return rewardInfos;
}
async function getRewardInfo(fetcher, data, opts) {
    const rewardInfo = {
        ...data,
        initialized: false,
        vaultAmount: new bn_js_1.default(0)
    };
    if (__1.PoolUtil.isRewardInitialized(data)) {
        const vaultInfo = await fetcher.getTokenInfo(data.vault, opts);
        if (!vaultInfo) {
            throw new Error(`Unable to fetch TokenAccountInfo for vault - ${data.vault}`);
        }
        rewardInfo.initialized = true;
        rewardInfo.vaultAmount = new bn_js_1.default(vaultInfo.amount.toString());
    }
    return rewardInfo;
}
async function getTokenVaultAccountInfos(fetcher, data, opts) {
    const vaultA = data.tokenVaultA;
    const vaultInfoA = await fetcher.getTokenInfo(vaultA, opts);
    if (!vaultInfoA) {
        throw new Error(`Unable to fetch TokenAccountInfo for vault - ${vaultA}`);
    }
    const vaultB = data.tokenVaultB;
    const vaultInfoB = await fetcher.getTokenInfo(vaultB, opts);
    if (!vaultInfoB) {
        throw new Error(`Unable to fetch TokenAccountInfo for vault - ${vaultB}`);
    }
    return [
        vaultInfoA,
        vaultInfoB
    ];
} //# sourceMappingURL=util.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/impl/whirlpool-impl.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WhirlpoolImpl = void 0;
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
const instructions_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/index.js [app-route] (ecmascript)");
const ix_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/ix.js [app-route] (ecmascript)");
const fetcher_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/index.js [app-route] (ecmascript)");
const position_builder_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/builder/position-builder-util.js [app-route] (ecmascript)");
const public_2 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
const txn_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/txn-utils.js [app-route] (ecmascript)");
const whirlpool_ata_utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/whirlpool-ata-utils.js [app-route] (ecmascript)");
const position_impl_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/impl/position-impl.js [app-route] (ecmascript)");
const util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/impl/util.js [app-route] (ecmascript)");
class WhirlpoolImpl {
    ctx;
    address;
    tokenAInfo;
    tokenBInfo;
    tokenVaultAInfo;
    tokenVaultBInfo;
    rewardInfos;
    data;
    constructor(ctx, address, tokenAInfo, tokenBInfo, tokenVaultAInfo, tokenVaultBInfo, rewardInfos, data){
        this.ctx = ctx;
        this.address = address;
        this.tokenAInfo = tokenAInfo;
        this.tokenBInfo = tokenBInfo;
        this.tokenVaultAInfo = tokenVaultAInfo;
        this.tokenVaultBInfo = tokenVaultBInfo;
        this.rewardInfos = rewardInfos;
        this.data = data;
    }
    getAddress() {
        return this.address;
    }
    getData() {
        return this.data;
    }
    getTokenAInfo() {
        return this.tokenAInfo;
    }
    getTokenBInfo() {
        return this.tokenBInfo;
    }
    getTokenVaultAInfo() {
        return this.tokenVaultAInfo;
    }
    getTokenVaultBInfo() {
        return this.tokenVaultBInfo;
    }
    getRewardInfos() {
        return this.rewardInfos;
    }
    async refreshData() {
        await this.refresh();
        return this.data;
    }
    async openPosition(tickLower, tickUpper, liquidityInput, wallet, funder, positionMint, tokenProgramId) {
        await this.refresh();
        return this.getOpenPositionWithOptMetadataTx(tickLower, tickUpper, liquidityInput, !!wallet ? common_sdk_1.AddressUtil.toPubKey(wallet) : this.ctx.wallet.publicKey, !!funder ? common_sdk_1.AddressUtil.toPubKey(funder) : this.ctx.wallet.publicKey, tokenProgramId ?? spl_token_1.TOKEN_PROGRAM_ID, false, positionMint);
    }
    async openPositionWithMetadata(tickLower, tickUpper, liquidityInput, sourceWallet, funder, positionMint, tokenProgramId) {
        await this.refresh();
        return this.getOpenPositionWithOptMetadataTx(tickLower, tickUpper, liquidityInput, !!sourceWallet ? common_sdk_1.AddressUtil.toPubKey(sourceWallet) : this.ctx.wallet.publicKey, !!funder ? common_sdk_1.AddressUtil.toPubKey(funder) : this.ctx.wallet.publicKey, tokenProgramId ?? spl_token_1.TOKEN_PROGRAM_ID, true, positionMint);
    }
    async initTickArrayForTicks(ticks, funder, opts = fetcher_1.IGNORE_CACHE) {
        const initTickArrayStartPdas = await public_2.TickArrayUtil.getUninitializedArraysPDAs(ticks, this.ctx.program.programId, this.address, this.data.tickSpacing, this.ctx.fetcher, opts);
        if (!initTickArrayStartPdas.length) {
            return null;
        }
        const txBuilder = new common_sdk_1.TransactionBuilder(this.ctx.provider.connection, this.ctx.provider.wallet, this.ctx.txBuilderOpts);
        initTickArrayStartPdas.forEach((initTickArrayInfo)=>{
            txBuilder.addInstruction((0, instructions_1.initTickArrayIx)(this.ctx.program, {
                startTick: initTickArrayInfo.startIndex,
                tickArrayPda: initTickArrayInfo.pda,
                whirlpool: this.address,
                funder: !!funder ? common_sdk_1.AddressUtil.toPubKey(funder) : this.ctx.provider.wallet.publicKey
            }));
        });
        return txBuilder;
    }
    async closePosition(positionAddress, slippageTolerance, destinationWallet, positionWallet, payer, usePriceSlippage = false) {
        await this.refresh();
        const positionWalletKey = positionWallet ? common_sdk_1.AddressUtil.toPubKey(positionWallet) : this.ctx.wallet.publicKey;
        const destinationWalletKey = destinationWallet ? common_sdk_1.AddressUtil.toPubKey(destinationWallet) : this.ctx.wallet.publicKey;
        const payerKey = payer ? common_sdk_1.AddressUtil.toPubKey(payer) : this.ctx.wallet.publicKey;
        return this.getClosePositionIx(common_sdk_1.AddressUtil.toPubKey(positionAddress), slippageTolerance, destinationWalletKey, positionWalletKey, payerKey, usePriceSlippage);
    }
    async swap(quote, sourceWallet) {
        const sourceWalletKey = sourceWallet ? common_sdk_1.AddressUtil.toPubKey(sourceWallet) : this.ctx.wallet.publicKey;
        return (0, instructions_1.swapAsync)(this.ctx, {
            swapInput: quote,
            whirlpool: this,
            wallet: sourceWalletKey
        }, fetcher_1.IGNORE_CACHE);
    }
    async swapWithDevFees(quote, devFeeWallet, wallet, payer) {
        const sourceWalletKey = wallet ? common_sdk_1.AddressUtil.toPubKey(wallet) : this.ctx.wallet.publicKey;
        const payerKey = payer ? common_sdk_1.AddressUtil.toPubKey(payer) : this.ctx.wallet.publicKey;
        const txBuilder = new common_sdk_1.TransactionBuilder(this.ctx.provider.connection, this.ctx.provider.wallet, this.ctx.txBuilderOpts);
        if (!quote.devFeeAmount.eq(common_sdk_1.ZERO)) {
            const inputToken = quote.aToB === quote.amountSpecifiedIsInput ? this.getTokenAInfo() : this.getTokenBInfo();
            txBuilder.addInstruction(await common_sdk_1.TokenUtil.createSendTokensToWalletInstruction(this.ctx.connection, sourceWalletKey, devFeeWallet, inputToken.mint, inputToken.decimals, quote.devFeeAmount, ()=>this.ctx.fetcher.getAccountRentExempt(), payerKey, this.ctx.accountResolverOpts.allowPDAOwnerAddress));
        }
        const swapTxBuilder = await (0, instructions_1.swapAsync)(this.ctx, {
            swapInput: quote,
            whirlpool: this,
            wallet: sourceWalletKey
        }, fetcher_1.IGNORE_CACHE);
        txBuilder.addInstruction(swapTxBuilder.compressIx(true));
        return txBuilder;
    }
    async getOpenPositionWithOptMetadataTx(tickLower, tickUpper, liquidityInput, wallet, funder, tokenProgramId, withMetadata = false, positionMint) {
        (0, tiny_invariant_1.default)(public_2.TickUtil.checkTickInBounds(tickLower), "tickLower is out of bounds.");
        (0, tiny_invariant_1.default)(public_2.TickUtil.checkTickInBounds(tickUpper), "tickUpper is out of bounds.");
        (0, tiny_invariant_1.default)(tokenProgramId.equals(spl_token_1.TOKEN_PROGRAM_ID) || tokenProgramId.equals(spl_token_1.TOKEN_2022_PROGRAM_ID), "tokenProgramId must be either TOKEN_PROGRAM_ID or TOKEN_2022_PROGRAM_ID");
        const { liquidityAmount: liquidity, tokenMaxA, tokenMaxB } = liquidityInput;
        (0, tiny_invariant_1.default)(liquidity.gt(new anchor_1.BN(0)), "liquidity must be greater than zero");
        const whirlpool = await this.ctx.fetcher.getPool(this.address, fetcher_1.PREFER_CACHE);
        if (!whirlpool) {
            throw new Error(`Whirlpool not found: ${(0, anchor_1.translateAddress)(this.address).toBase58()}`);
        }
        const tokenExtensionCtx = await token_extension_util_1.TokenExtensionUtil.buildTokenExtensionContext(this.ctx.fetcher, whirlpool, fetcher_1.IGNORE_CACHE);
        (0, tiny_invariant_1.default)(public_2.TickUtil.isTickInitializable(tickLower, whirlpool.tickSpacing), `lower tick ${tickLower} is not an initializable tick for tick-spacing ${whirlpool.tickSpacing}`);
        (0, tiny_invariant_1.default)(public_2.TickUtil.isTickInitializable(tickUpper, whirlpool.tickSpacing), `upper tick ${tickUpper} is not an initializable tick for tick-spacing ${whirlpool.tickSpacing}`);
        const positionMintKeypair = web3_js_1.Keypair.generate();
        const positionMintPubkey = positionMint ?? positionMintKeypair.publicKey;
        const positionPda = public_2.PDAUtil.getPosition(this.ctx.program.programId, positionMintPubkey);
        const metadataPda = public_2.PDAUtil.getPositionMetadata(positionMintPubkey);
        const positionTokenAccountAddress = (0, spl_token_1.getAssociatedTokenAddressSync)(positionMintPubkey, wallet, this.ctx.accountResolverOpts.allowPDAOwnerAddress, tokenProgramId);
        const txBuilder = new common_sdk_1.TransactionBuilder(this.ctx.provider.connection, this.ctx.provider.wallet, this.ctx.txBuilderOpts);
        const params = {
            funder,
            owner: wallet,
            positionPda,
            positionTokenAccount: positionTokenAccountAddress,
            whirlpool: this.address,
            tickLowerIndex: tickLower,
            tickUpperIndex: tickUpper
        };
        const positionIx = tokenProgramId.equals(spl_token_1.TOKEN_2022_PROGRAM_ID) ? (0, instructions_1.openPositionWithTokenExtensionsIx)(this.ctx.program, {
            ...params,
            positionMint: positionMintPubkey,
            withTokenMetadataExtension: withMetadata
        }) : (withMetadata ? instructions_1.openPositionWithMetadataIx : instructions_1.openPositionIx)(this.ctx.program, {
            ...params,
            positionMintAddress: positionMintPubkey,
            metadataPda
        });
        txBuilder.addInstruction(positionIx);
        if (positionMint === undefined) {
            txBuilder.addSigner(positionMintKeypair);
        }
        const [ataA, ataB] = await (0, common_sdk_1.resolveOrCreateATAs)(this.ctx.connection, wallet, [
            {
                tokenMint: whirlpool.tokenMintA,
                wrappedSolAmountIn: tokenMaxA
            },
            {
                tokenMint: whirlpool.tokenMintB,
                wrappedSolAmountIn: tokenMaxB
            }
        ], ()=>this.ctx.fetcher.getAccountRentExempt(), funder, undefined, this.ctx.accountResolverOpts.allowPDAOwnerAddress, this.ctx.accountResolverOpts.createWrappedSolAccountMethod);
        const { address: tokenOwnerAccountA, ...tokenOwnerAccountAIx } = ataA;
        const { address: tokenOwnerAccountB, ...tokenOwnerAccountBIx } = ataB;
        txBuilder.addInstruction(tokenOwnerAccountAIx);
        txBuilder.addInstruction(tokenOwnerAccountBIx);
        const tickArrayLowerPda = public_2.PDAUtil.getTickArrayFromTickIndex(tickLower, this.data.tickSpacing, this.address, this.ctx.program.programId);
        const tickArrayUpperPda = public_2.PDAUtil.getTickArrayFromTickIndex(tickUpper, this.data.tickSpacing, this.address, this.ctx.program.programId);
        const baseParams = {
            liquidityAmount: liquidity,
            tokenMaxA,
            tokenMaxB,
            whirlpool: this.address,
            positionAuthority: wallet,
            position: positionPda.publicKey,
            positionTokenAccount: positionTokenAccountAddress,
            tokenOwnerAccountA,
            tokenOwnerAccountB,
            tokenVaultA: whirlpool.tokenVaultA,
            tokenVaultB: whirlpool.tokenVaultB,
            tickArrayLower: tickArrayLowerPda.publicKey,
            tickArrayUpper: tickArrayUpperPda.publicKey
        };
        const liquidityIx = !token_extension_util_1.TokenExtensionUtil.isV2IxRequiredPool(tokenExtensionCtx) ? (0, instructions_1.increaseLiquidityIx)(this.ctx.program, baseParams) : (0, instructions_1.increaseLiquidityV2Ix)(this.ctx.program, {
            ...baseParams,
            tokenMintA: whirlpool.tokenMintA,
            tokenMintB: whirlpool.tokenMintB,
            tokenProgramA: tokenExtensionCtx.tokenMintWithProgramA.tokenProgram,
            tokenProgramB: tokenExtensionCtx.tokenMintWithProgramB.tokenProgram,
            ...await token_extension_util_1.TokenExtensionUtil.getExtraAccountMetasForTransferHookForPool(this.ctx.connection, tokenExtensionCtx, baseParams.tokenOwnerAccountA, baseParams.tokenVaultA, baseParams.positionAuthority, baseParams.tokenOwnerAccountB, baseParams.tokenVaultB, baseParams.positionAuthority)
        });
        txBuilder.addInstruction(liquidityIx);
        return {
            positionMint: positionMintPubkey,
            tx: txBuilder
        };
    }
    async getClosePositionIx(positionAddress, slippageTolerance, destinationWallet, positionWallet, payerKey, usePriceSlippage = false) {
        const positionData = await this.ctx.fetcher.getPosition(positionAddress, fetcher_1.IGNORE_CACHE);
        if (!positionData) {
            throw new Error(`Position not found: ${positionAddress.toBase58()}`);
        }
        const positionMint = await this.ctx.fetcher.getMintInfo(positionData.positionMint);
        if (!positionMint) {
            throw new Error(`Position mint not found: ${positionData.positionMint.toBase58()}`);
        }
        const whirlpool = this.data;
        (0, tiny_invariant_1.default)(positionData.whirlpool.equals(this.address), `Position ${positionAddress.toBase58()} is not a position for Whirlpool ${this.address.toBase58()}`);
        const positionTokenAccount = (0, spl_token_1.getAssociatedTokenAddressSync)(positionData.positionMint, positionWallet, this.ctx.accountResolverOpts.allowPDAOwnerAddress, positionMint.tokenProgram);
        const accountExemption = await this.ctx.fetcher.getAccountRentExempt();
        const tickArrayLower = public_2.PDAUtil.getTickArrayFromTickIndex(positionData.tickLowerIndex, whirlpool.tickSpacing, positionData.whirlpool, this.ctx.program.programId).publicKey;
        const tickArrayUpper = public_2.PDAUtil.getTickArrayFromTickIndex(positionData.tickUpperIndex, whirlpool.tickSpacing, positionData.whirlpool, this.ctx.program.programId).publicKey;
        const [tickArrayLowerData, tickArrayUpperData] = await (0, position_builder_util_1.getTickArrayDataForPosition)(this.ctx, positionData, whirlpool, fetcher_1.IGNORE_CACHE);
        (0, tiny_invariant_1.default)(!!tickArrayLowerData, `Tick array ${tickArrayLower} expected to be initialized for whirlpool ${this.address}`);
        (0, tiny_invariant_1.default)(!!tickArrayUpperData, `Tick array ${tickArrayUpper} expected to be initialized for whirlpool ${this.address}`);
        const tokenExtensionCtx = await token_extension_util_1.TokenExtensionUtil.buildTokenExtensionContext(this.ctx.fetcher, whirlpool, fetcher_1.IGNORE_CACHE);
        const position = new position_impl_1.PositionImpl(this.ctx, positionAddress, positionData, whirlpool, tickArrayLowerData, tickArrayUpperData, positionMint.tokenProgram);
        const tickLower = position.getLowerTickData();
        const tickUpper = position.getUpperTickData();
        const feesQuote = (0, public_1.collectFeesQuote)({
            position: positionData,
            whirlpool,
            tickLower,
            tickUpper,
            tokenExtensionCtx
        });
        const rewardsQuote = (0, public_1.collectRewardsQuote)({
            position: positionData,
            whirlpool,
            tickLower,
            tickUpper,
            tokenExtensionCtx
        });
        const shouldCollectFees = feesQuote.feeOwedA.gtn(0) || feesQuote.feeOwedB.gtn(0);
        (0, tiny_invariant_1.default)(this.data.rewardInfos.length === rewardsQuote.rewardOwed.length, "Rewards quote does not match reward infos length");
        const shouldDecreaseLiquidity = positionData.liquidity.gtn(0);
        const rewardsToCollect = this.data.rewardInfos.map((info, index)=>({
                info,
                index
            })).filter(({ info, index })=>{
            if (!public_2.PoolUtil.isRewardInitialized(info)) {
                return false;
            }
            return (rewardsQuote.rewardOwed[index] ?? common_sdk_1.ZERO).gtn(0) || (rewardsQuote.transferFee.deductedFromRewardOwed[index] ?? common_sdk_1.ZERO).gtn(0);
        });
        const shouldCollectRewards = rewardsToCollect.length > 0;
        let mintType = whirlpool_ata_utils_1.TokenMintTypes.ALL;
        if ((shouldDecreaseLiquidity || shouldCollectFees) && !shouldCollectRewards) {
            mintType = whirlpool_ata_utils_1.TokenMintTypes.POOL_ONLY;
        } else if (!(shouldDecreaseLiquidity || shouldCollectFees) && shouldCollectRewards) {
            mintType = whirlpool_ata_utils_1.TokenMintTypes.REWARD_ONLY;
        }
        const allMints = (0, whirlpool_ata_utils_1.getTokenMintsFromWhirlpools)([
            whirlpool
        ], mintType);
        const resolvedAtas = (0, txn_utils_1.convertListToMap)(await (0, common_sdk_1.resolveOrCreateATAs)(this.ctx.connection, destinationWallet, allMints.mintMap.map((tokenMint)=>({
                tokenMint
            })), async ()=>accountExemption, payerKey, true, this.ctx.accountResolverOpts.allowPDAOwnerAddress, this.ctx.accountResolverOpts.createWrappedSolAccountMethod), allMints.mintMap.map((mint)=>mint.toBase58()));
        const builder = new txn_utils_1.MultipleTransactionBuilderFactoryWithAccountResolver(this.ctx, resolvedAtas, destinationWallet, payerKey);
        if (shouldDecreaseLiquidity) {
            await builder.addInstructions(async (resolveTokenAccount)=>{
                const tokenOwnerAccountA = resolveTokenAccount(whirlpool.tokenMintA.toBase58());
                const tokenOwnerAccountB = resolveTokenAccount(whirlpool.tokenMintB.toBase58());
                const params = {
                    liquidity: positionData.liquidity,
                    slippageTolerance,
                    sqrtPrice: whirlpool.sqrtPrice,
                    tickCurrentIndex: whirlpool.tickCurrentIndex,
                    tickLowerIndex: positionData.tickLowerIndex,
                    tickUpperIndex: positionData.tickUpperIndex,
                    tokenExtensionCtx
                };
                const decreaseLiqQuote = usePriceSlippage ? (0, public_1.decreaseLiquidityQuoteByLiquidityWithParamsUsingPriceSlippage)(params) : (0, public_1.decreaseLiquidityQuoteByLiquidityWithParams)(params);
                const baseParams = {
                    ...decreaseLiqQuote,
                    whirlpool: positionData.whirlpool,
                    positionAuthority: positionWallet,
                    position: positionAddress,
                    positionTokenAccount,
                    tokenOwnerAccountA,
                    tokenOwnerAccountB,
                    tokenVaultA: whirlpool.tokenVaultA,
                    tokenVaultB: whirlpool.tokenVaultB,
                    tickArrayLower,
                    tickArrayUpper
                };
                const ix = !token_extension_util_1.TokenExtensionUtil.isV2IxRequiredPool(tokenExtensionCtx) ? ix_1.WhirlpoolIx.decreaseLiquidityIx(this.ctx.program, baseParams) : ix_1.WhirlpoolIx.decreaseLiquidityV2Ix(this.ctx.program, {
                    ...baseParams,
                    tokenMintA: whirlpool.tokenMintA,
                    tokenMintB: whirlpool.tokenMintB,
                    tokenProgramA: tokenExtensionCtx.tokenMintWithProgramA.tokenProgram,
                    tokenProgramB: tokenExtensionCtx.tokenMintWithProgramB.tokenProgram,
                    ...await token_extension_util_1.TokenExtensionUtil.getExtraAccountMetasForTransferHookForPool(this.ctx.connection, tokenExtensionCtx, baseParams.tokenVaultA, baseParams.tokenOwnerAccountA, baseParams.whirlpool, baseParams.tokenVaultB, baseParams.tokenOwnerAccountB, baseParams.whirlpool)
                });
                return [
                    ix
                ];
            });
        }
        if (shouldCollectFees) {
            await builder.addInstructions(async (resolveTokenAccount)=>{
                const tokenOwnerAccountA = resolveTokenAccount(whirlpool.tokenMintA.toBase58());
                const tokenOwnerAccountB = resolveTokenAccount(whirlpool.tokenMintB.toBase58());
                const collectFeesBaseParams = {
                    whirlpool: positionData.whirlpool,
                    position: positionAddress,
                    positionAuthority: positionWallet,
                    positionTokenAccount,
                    tokenOwnerAccountA,
                    tokenOwnerAccountB,
                    tokenVaultA: whirlpool.tokenVaultA,
                    tokenVaultB: whirlpool.tokenVaultB
                };
                const ix = !token_extension_util_1.TokenExtensionUtil.isV2IxRequiredPool(tokenExtensionCtx) ? ix_1.WhirlpoolIx.collectFeesIx(this.ctx.program, collectFeesBaseParams) : ix_1.WhirlpoolIx.collectFeesV2Ix(this.ctx.program, {
                    ...collectFeesBaseParams,
                    tokenMintA: tokenExtensionCtx.tokenMintWithProgramA.address,
                    tokenMintB: tokenExtensionCtx.tokenMintWithProgramB.address,
                    tokenProgramA: tokenExtensionCtx.tokenMintWithProgramA.tokenProgram,
                    tokenProgramB: tokenExtensionCtx.tokenMintWithProgramB.tokenProgram,
                    ...await token_extension_util_1.TokenExtensionUtil.getExtraAccountMetasForTransferHookForPool(this.ctx.connection, tokenExtensionCtx, collectFeesBaseParams.tokenVaultA, collectFeesBaseParams.tokenOwnerAccountA, collectFeesBaseParams.whirlpool, collectFeesBaseParams.tokenVaultB, collectFeesBaseParams.tokenOwnerAccountB, collectFeesBaseParams.whirlpool)
                });
                return [
                    ix
                ];
            });
        }
        if (shouldCollectRewards) {
            for (const { info, index: rewardIndex } of rewardsToCollect){
                await builder.addInstructions(async (resolveTokenAccount)=>{
                    const rewardOwnerAccount = resolveTokenAccount(info.mint.toBase58());
                    const collectRewardBaseParams = {
                        whirlpool: positionData.whirlpool,
                        position: positionAddress,
                        positionAuthority: positionWallet,
                        positionTokenAccount,
                        rewardIndex,
                        rewardOwnerAccount,
                        rewardVault: info.vault
                    };
                    const ix = !token_extension_util_1.TokenExtensionUtil.isV2IxRequiredReward(tokenExtensionCtx, rewardIndex) ? ix_1.WhirlpoolIx.collectRewardIx(this.ctx.program, collectRewardBaseParams) : ix_1.WhirlpoolIx.collectRewardV2Ix(this.ctx.program, {
                        ...collectRewardBaseParams,
                        rewardMint: tokenExtensionCtx.rewardTokenMintsWithProgram[rewardIndex].address,
                        rewardTokenProgram: tokenExtensionCtx.rewardTokenMintsWithProgram[rewardIndex].tokenProgram,
                        rewardTransferHookAccounts: await token_extension_util_1.TokenExtensionUtil.getExtraAccountMetasForTransferHook(this.ctx.connection, tokenExtensionCtx.rewardTokenMintsWithProgram[rewardIndex], collectRewardBaseParams.rewardVault, collectRewardBaseParams.rewardOwnerAccount, collectRewardBaseParams.whirlpool)
                    });
                    return [
                        ix
                    ];
                });
            }
        }
        await builder.addInstructions(async ()=>{
            const closePositionParams = {
                positionAuthority: positionWallet,
                receiver: destinationWallet,
                positionTokenAccount,
                position: positionAddress,
                positionMint: positionData.positionMint
            };
            if (positionMint.tokenProgram.equals(spl_token_1.TOKEN_2022_PROGRAM_ID)) {
                return [
                    (0, instructions_1.closePositionWithTokenExtensionsIx)(this.ctx.program, closePositionParams)
                ];
            } else {
                return [
                    (0, instructions_1.closePositionIx)(this.ctx.program, closePositionParams)
                ];
            }
        });
        return builder.build();
    }
    async refresh() {
        const account = await this.ctx.fetcher.getPool(this.address, fetcher_1.IGNORE_CACHE);
        if (!!account) {
            const rewardInfos = await (0, util_1.getRewardInfos)(this.ctx.fetcher, account, fetcher_1.IGNORE_CACHE);
            const [tokenVaultAInfo, tokenVaultBInfo] = await (0, util_1.getTokenVaultAccountInfos)(this.ctx.fetcher, account, fetcher_1.IGNORE_CACHE);
            this.data = account;
            this.tokenVaultAInfo = tokenVaultAInfo;
            this.tokenVaultBInfo = tokenVaultBInfo;
            this.rewardInfos = rewardInfos;
        }
    }
}
exports.WhirlpoolImpl = WhirlpoolImpl; //# sourceMappingURL=whirlpool-impl.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/impl/whirlpool-client-impl.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WhirlpoolClientImpl = void 0;
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tiny_invariant_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/tiny-invariant.cjs.js [app-route] (ecmascript)"));
const instructions_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/index.js [app-route] (ecmascript)");
const composites_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/composites/index.js [app-route] (ecmascript)");
const ix_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/ix.js [app-route] (ecmascript)");
const fetcher_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/fetcher/index.js [app-route] (ecmascript)");
const public_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/public/index.js [app-route] (ecmascript)");
const public_2 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)");
const position_builder_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/builder/position-builder-util.js [app-route] (ecmascript)");
const public_3 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)");
const position_impl_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/impl/position-impl.js [app-route] (ecmascript)");
const util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/impl/util.js [app-route] (ecmascript)");
const whirlpool_impl_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/impl/whirlpool-impl.js [app-route] (ecmascript)");
const token_extension_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/token-extension-util.js [app-route] (ecmascript)");
const decimal_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)"));
class WhirlpoolClientImpl {
    ctx;
    constructor(ctx){
        this.ctx = ctx;
    }
    getContext() {
        return this.ctx;
    }
    getFetcher() {
        return this.ctx.fetcher;
    }
    getRouter(poolAddresses) {
        return public_1.WhirlpoolRouterBuilder.buildWithPools(this.ctx, poolAddresses);
    }
    async getPool(poolAddress, opts = fetcher_1.PREFER_CACHE) {
        const account = await this.ctx.fetcher.getPool(poolAddress, opts);
        if (!account) {
            throw new Error(`Unable to fetch Whirlpool at address at ${poolAddress}`);
        }
        const tokenInfos = await (0, util_1.getTokenMintInfos)(this.ctx.fetcher, account, opts);
        const vaultInfos = await (0, util_1.getTokenVaultAccountInfos)(this.ctx.fetcher, account, opts);
        const rewardInfos = await (0, util_1.getRewardInfos)(this.ctx.fetcher, account, opts);
        return new whirlpool_impl_1.WhirlpoolImpl(this.ctx, common_sdk_1.AddressUtil.toPubKey(poolAddress), tokenInfos[0], tokenInfos[1], vaultInfos[0], vaultInfos[1], rewardInfos, account);
    }
    async getPools(poolAddresses, opts = fetcher_1.PREFER_CACHE) {
        const accounts = Array.from((await this.ctx.fetcher.getPools(poolAddresses, opts)).values()).filter((account)=>!!account);
        if (accounts.length !== poolAddresses.length) {
            throw new Error(`Unable to fetch all Whirlpools at addresses ${poolAddresses}`);
        }
        const tokenMints = new Set();
        const tokenAccounts = new Set();
        accounts.forEach((account)=>{
            tokenMints.add(account.tokenMintA.toBase58());
            tokenMints.add(account.tokenMintB.toBase58());
            tokenAccounts.add(account.tokenVaultA.toBase58());
            tokenAccounts.add(account.tokenVaultB.toBase58());
            account.rewardInfos.forEach((rewardInfo)=>{
                if (public_3.PoolUtil.isRewardInitialized(rewardInfo)) {
                    tokenAccounts.add(rewardInfo.vault.toBase58());
                }
            });
        });
        await this.ctx.fetcher.getMintInfos(Array.from(tokenMints), opts);
        await this.ctx.fetcher.getTokenInfos(Array.from(tokenAccounts), opts);
        const whirlpools = [];
        for(let i = 0; i < accounts.length; i++){
            const account = accounts[i];
            const poolAddress = poolAddresses[i];
            const tokenInfos = await (0, util_1.getTokenMintInfos)(this.ctx.fetcher, account, fetcher_1.PREFER_CACHE);
            const vaultInfos = await (0, util_1.getTokenVaultAccountInfos)(this.ctx.fetcher, account, fetcher_1.PREFER_CACHE);
            const rewardInfos = await (0, util_1.getRewardInfos)(this.ctx.fetcher, account, fetcher_1.PREFER_CACHE);
            whirlpools.push(new whirlpool_impl_1.WhirlpoolImpl(this.ctx, common_sdk_1.AddressUtil.toPubKey(poolAddress), tokenInfos[0], tokenInfos[1], vaultInfos[0], vaultInfos[1], rewardInfos, account));
        }
        return whirlpools;
    }
    async getPosition(positionAddress, opts = fetcher_1.PREFER_CACHE) {
        const account = await this.ctx.fetcher.getPosition(positionAddress, opts);
        if (!account) {
            throw new Error(`Unable to fetch Position at address at ${positionAddress}`);
        }
        const whirlAccount = await this.ctx.fetcher.getPool(account.whirlpool, opts);
        if (!whirlAccount) {
            throw new Error(`Unable to fetch Whirlpool for Position at address at ${positionAddress}`);
        }
        const positionMint = await this.ctx.fetcher.getMintInfo(account.positionMint, opts);
        if (!positionMint) {
            throw new Error(`Unable to fetch Mint for Position at address at ${positionAddress}`);
        }
        const [lowerTickArray, upperTickArray] = await (0, position_builder_util_1.getTickArrayDataForPosition)(this.ctx, account, whirlAccount, opts);
        if (!lowerTickArray || !upperTickArray) {
            throw new Error(`Unable to fetch TickArrays for Position at address at ${positionAddress}`);
        }
        return new position_impl_1.PositionImpl(this.ctx, common_sdk_1.AddressUtil.toPubKey(positionAddress), account, whirlAccount, lowerTickArray, upperTickArray, positionMint.tokenProgram);
    }
    async getPositions(positionAddresses, opts = fetcher_1.PREFER_CACHE) {
        const positions = Array.from((await this.ctx.fetcher.getPositions(positionAddresses, opts)).values());
        const whirlpoolAddrs = positions.map((position)=>position?.whirlpool.toBase58()).flatMap((x)=>!!x ? x : []);
        await this.ctx.fetcher.getPools(whirlpoolAddrs, opts);
        const positionMintAddrs = positions.map((position)=>position?.positionMint.toBase58()).flatMap((x)=>!!x ? x : []);
        await this.ctx.fetcher.getMintInfos(positionMintAddrs, opts);
        const tickArrayAddresses = new Set();
        await Promise.all(positions.map(async (pos)=>{
            if (pos) {
                const pool = await this.ctx.fetcher.getPool(pos.whirlpool, fetcher_1.PREFER_CACHE);
                if (pool) {
                    const lowerTickArrayPda = public_3.PDAUtil.getTickArrayFromTickIndex(pos.tickLowerIndex, pool.tickSpacing, pos.whirlpool, this.ctx.program.programId).publicKey;
                    const upperTickArrayPda = public_3.PDAUtil.getTickArrayFromTickIndex(pos.tickUpperIndex, pool.tickSpacing, pos.whirlpool, this.ctx.program.programId).publicKey;
                    tickArrayAddresses.add(lowerTickArrayPda.toBase58());
                    tickArrayAddresses.add(upperTickArrayPda.toBase58());
                }
            }
        }));
        await this.ctx.fetcher.getTickArrays(Array.from(tickArrayAddresses), fetcher_1.IGNORE_CACHE);
        const results = await Promise.all(positionAddresses.map(async (pos)=>{
            try {
                const position = await this.getPosition(pos, fetcher_1.PREFER_CACHE);
                return [
                    pos,
                    position
                ];
            } catch  {
                return [
                    pos,
                    null
                ];
            }
        }));
        return Object.fromEntries(results);
    }
    async createSplashPool(whirlpoolsConfig, tokenMintA, tokenMintB, initialPrice = new decimal_js_1.default(1), funder, opts = fetcher_1.PREFER_CACHE) {
        const correctTokenOrder = public_3.PoolUtil.orderMints(tokenMintA, tokenMintB).map((addr)=>addr.toString());
        (0, tiny_invariant_1.default)(correctTokenOrder[0] === tokenMintA.toString(), "Token order needs to be flipped to match the canonical ordering (i.e. sorted on the byte repr. of the mint pubkeys)");
        const mintInfos = await this.getFetcher().getMintInfos([
            tokenMintA,
            tokenMintB
        ], opts);
        (0, tiny_invariant_1.default)(mintInfos.size === 2, "At least one of the token mints cannot be found.");
        const tokenExtensionCtx = {
            ...token_extension_util_1.NO_TOKEN_EXTENSION_CONTEXT,
            tokenMintWithProgramA: mintInfos.get(tokenMintA.toString()),
            tokenMintWithProgramB: mintInfos.get(tokenMintB.toString())
        };
        whirlpoolsConfig = common_sdk_1.AddressUtil.toPubKey(whirlpoolsConfig);
        const feeTierKey = public_3.PDAUtil.getFeeTier(this.ctx.program.programId, whirlpoolsConfig, public_2.SPLASH_POOL_TICK_SPACING).publicKey;
        const whirlpoolPda = public_3.PDAUtil.getWhirlpool(this.ctx.program.programId, whirlpoolsConfig, new web3_js_1.PublicKey(tokenMintA), new web3_js_1.PublicKey(tokenMintB), public_2.SPLASH_POOL_TICK_SPACING);
        const tokenDecimalsA = mintInfos.get(tokenMintA.toString())?.decimals ?? 0;
        const tokenDecimalsB = mintInfos.get(tokenMintB.toString())?.decimals ?? 0;
        const initSqrtPrice = public_3.PriceMath.priceToSqrtPriceX64(initialPrice, tokenDecimalsA, tokenDecimalsB);
        const tokenVaultAKeypair = web3_js_1.Keypair.generate();
        const tokenVaultBKeypair = web3_js_1.Keypair.generate();
        const txBuilder = new common_sdk_1.TransactionBuilder(this.ctx.provider.connection, this.ctx.provider.wallet, this.ctx.txBuilderOpts);
        const tokenBadgeA = public_3.PDAUtil.getTokenBadge(this.ctx.program.programId, whirlpoolsConfig, common_sdk_1.AddressUtil.toPubKey(tokenMintA)).publicKey;
        const tokenBadgeB = public_3.PDAUtil.getTokenBadge(this.ctx.program.programId, whirlpoolsConfig, common_sdk_1.AddressUtil.toPubKey(tokenMintB)).publicKey;
        const baseParams = {
            initSqrtPrice,
            whirlpoolsConfig,
            whirlpoolPda,
            tokenMintA: new web3_js_1.PublicKey(tokenMintA),
            tokenMintB: new web3_js_1.PublicKey(tokenMintB),
            tokenVaultAKeypair,
            tokenVaultBKeypair,
            feeTierKey,
            tickSpacing: public_2.SPLASH_POOL_TICK_SPACING,
            funder: new web3_js_1.PublicKey(funder)
        };
        const initPoolIx = !token_extension_util_1.TokenExtensionUtil.isV2IxRequiredPool(tokenExtensionCtx) ? ix_1.WhirlpoolIx.initializePoolIx(this.ctx.program, baseParams) : ix_1.WhirlpoolIx.initializePoolV2Ix(this.ctx.program, {
            ...baseParams,
            tokenProgramA: tokenExtensionCtx.tokenMintWithProgramA.tokenProgram,
            tokenProgramB: tokenExtensionCtx.tokenMintWithProgramB.tokenProgram,
            tokenBadgeA,
            tokenBadgeB
        });
        txBuilder.addInstruction(initPoolIx);
        const [startTickIndex, endTickIndex] = public_3.TickUtil.getFullRangeTickIndex(public_2.SPLASH_POOL_TICK_SPACING);
        const startInitializableTickIndex = public_3.TickUtil.getStartTickIndex(startTickIndex, public_2.SPLASH_POOL_TICK_SPACING);
        const endInitializableTickIndex = public_3.TickUtil.getStartTickIndex(endTickIndex, public_2.SPLASH_POOL_TICK_SPACING);
        const startTickArrayPda = public_3.PDAUtil.getTickArray(this.ctx.program.programId, whirlpoolPda.publicKey, startInitializableTickIndex);
        const endTickArrayPda = public_3.PDAUtil.getTickArray(this.ctx.program.programId, whirlpoolPda.publicKey, endInitializableTickIndex);
        txBuilder.addInstruction((0, instructions_1.initTickArrayIx)(this.ctx.program, {
            startTick: startInitializableTickIndex,
            tickArrayPda: startTickArrayPda,
            whirlpool: whirlpoolPda.publicKey,
            funder: common_sdk_1.AddressUtil.toPubKey(funder)
        }));
        txBuilder.addInstruction((0, instructions_1.initTickArrayIx)(this.ctx.program, {
            startTick: endInitializableTickIndex,
            tickArrayPda: endTickArrayPda,
            whirlpool: whirlpoolPda.publicKey,
            funder: common_sdk_1.AddressUtil.toPubKey(funder)
        }));
        return {
            poolKey: whirlpoolPda.publicKey,
            tx: txBuilder
        };
    }
    async createPool(whirlpoolsConfig, tokenMintA, tokenMintB, tickSpacing, initialTick, funder, opts = fetcher_1.PREFER_CACHE) {
        (0, tiny_invariant_1.default)(public_3.TickUtil.checkTickInBounds(initialTick), "initialTick is out of bounds.");
        (0, tiny_invariant_1.default)(public_3.TickUtil.isTickInitializable(initialTick, tickSpacing), `initial tick ${initialTick} is not an initializable tick for tick-spacing ${tickSpacing}`);
        const correctTokenOrder = public_3.PoolUtil.orderMints(tokenMintA, tokenMintB).map((addr)=>addr.toString());
        (0, tiny_invariant_1.default)(correctTokenOrder[0] === tokenMintA.toString(), "Token order needs to be flipped to match the canonical ordering (i.e. sorted on the byte repr. of the mint pubkeys)");
        const mintInfos = await this.ctx.fetcher.getMintInfos([
            tokenMintA,
            tokenMintB
        ], opts);
        const tokenExtensionCtx = {
            ...token_extension_util_1.NO_TOKEN_EXTENSION_CONTEXT,
            tokenMintWithProgramA: mintInfos.get(tokenMintA.toString()),
            tokenMintWithProgramB: mintInfos.get(tokenMintB.toString())
        };
        whirlpoolsConfig = common_sdk_1.AddressUtil.toPubKey(whirlpoolsConfig);
        const feeTierKey = public_3.PDAUtil.getFeeTier(this.ctx.program.programId, whirlpoolsConfig, tickSpacing).publicKey;
        const initSqrtPrice = public_3.PriceMath.tickIndexToSqrtPriceX64(initialTick);
        const tokenVaultAKeypair = web3_js_1.Keypair.generate();
        const tokenVaultBKeypair = web3_js_1.Keypair.generate();
        const whirlpoolPda = public_3.PDAUtil.getWhirlpool(this.ctx.program.programId, whirlpoolsConfig, new web3_js_1.PublicKey(tokenMintA), new web3_js_1.PublicKey(tokenMintB), tickSpacing);
        const feeTier = await this.ctx.fetcher.getFeeTier(feeTierKey, opts);
        (0, tiny_invariant_1.default)(!!feeTier, `Fee tier for ${tickSpacing} doesn't exist`);
        const txBuilder = new common_sdk_1.TransactionBuilder(this.ctx.provider.connection, this.ctx.provider.wallet, this.ctx.txBuilderOpts);
        const tokenBadgeA = public_3.PDAUtil.getTokenBadge(this.ctx.program.programId, whirlpoolsConfig, common_sdk_1.AddressUtil.toPubKey(tokenMintA)).publicKey;
        const tokenBadgeB = public_3.PDAUtil.getTokenBadge(this.ctx.program.programId, whirlpoolsConfig, common_sdk_1.AddressUtil.toPubKey(tokenMintB)).publicKey;
        const baseParams = {
            initSqrtPrice,
            whirlpoolsConfig,
            whirlpoolPda,
            tokenMintA: new web3_js_1.PublicKey(tokenMintA),
            tokenMintB: new web3_js_1.PublicKey(tokenMintB),
            tokenVaultAKeypair,
            tokenVaultBKeypair,
            feeTierKey,
            tickSpacing,
            funder: new web3_js_1.PublicKey(funder)
        };
        const initPoolIx = !token_extension_util_1.TokenExtensionUtil.isV2IxRequiredPool(tokenExtensionCtx) ? ix_1.WhirlpoolIx.initializePoolIx(this.ctx.program, baseParams) : ix_1.WhirlpoolIx.initializePoolV2Ix(this.ctx.program, {
            ...baseParams,
            tokenProgramA: tokenExtensionCtx.tokenMintWithProgramA.tokenProgram,
            tokenProgramB: tokenExtensionCtx.tokenMintWithProgramB.tokenProgram,
            tokenBadgeA,
            tokenBadgeB
        });
        const initialTickArrayStartTick = public_3.TickUtil.getStartTickIndex(initialTick, tickSpacing);
        const initialTickArrayPda = public_3.PDAUtil.getTickArray(this.ctx.program.programId, whirlpoolPda.publicKey, initialTickArrayStartTick);
        txBuilder.addInstruction(initPoolIx);
        txBuilder.addInstruction((0, instructions_1.initTickArrayIx)(this.ctx.program, {
            startTick: initialTickArrayStartTick,
            tickArrayPda: initialTickArrayPda,
            whirlpool: whirlpoolPda.publicKey,
            funder: common_sdk_1.AddressUtil.toPubKey(funder)
        }));
        return {
            poolKey: whirlpoolPda.publicKey,
            tx: txBuilder
        };
    }
    async collectFeesAndRewardsForPositions(positionAddresses, opts) {
        const walletKey = this.ctx.wallet.publicKey;
        return (0, composites_1.collectAllForPositionAddressesTxns)(this.ctx, {
            positions: positionAddresses,
            receiver: walletKey,
            positionAuthority: walletKey,
            positionOwner: walletKey,
            payer: walletKey
        }, opts);
    }
    async collectProtocolFeesForPools(poolAddresses) {
        return (0, composites_1.collectProtocolFees)(this.ctx, poolAddresses);
    }
}
exports.WhirlpoolClientImpl = WhirlpoolClientImpl; //# sourceMappingURL=whirlpool-client-impl.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/whirlpool-client.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.buildWhirlpoolClient = buildWhirlpoolClient;
const whirlpool_client_impl_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/impl/whirlpool-client-impl.js [app-route] (ecmascript)");
function buildWhirlpoolClient(ctx) {
    return new whirlpool_client_impl_1.WhirlpoolClientImpl(ctx);
} //# sourceMappingURL=whirlpool-client.js.map
}}),
"[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const decimal_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)"));
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/context.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/impl/position-impl.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/ix.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/network/public/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/prices/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/quotes/public/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/router/public/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/types/public/anchor-types.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/utils/public/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/whirlpool-client.js [app-route] (ecmascript)"), exports);
decimal_js_1.default.set({
    precision: 40,
    toExpPos: 40,
    toExpNeg: -20,
    rounding: 1
}); //# sourceMappingURL=index.js.map
}}),

};

//# sourceMappingURL=571a8_%40orca-so_whirlpools-sdk_dist_9318a1._.js.map
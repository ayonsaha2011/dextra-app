module.exports = {

"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/hack.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var _a, _b, _c, _d, _e, _f, _g;
var _h, _j, _k, _l, _m, _o;
Object.defineProperty(exports, "__esModule", {
    value: true
});
// crypto hack - this is to stop arweave-js's import time(!!!) check for `subtleCrypto` - which occurs if you try to use the root import of this SDK.
const hack = ()=>{
    throw new Error(`Unimplemented`);
};
// @ts-expect-error hack
(_a = globalThis.crypto) !== null && _a !== void 0 ? _a : globalThis.crypto = {};
// @ts-expect-error hack
(_b = (_h = globalThis.crypto).subtle) !== null && _b !== void 0 ? _b : _h.subtle = {};
// @ts-expect-error hack
(_c = (_j = globalThis.crypto.subtle).generateKey) !== null && _c !== void 0 ? _c : _j.generateKey = hack;
// @ts-expect-error hack
(_d = (_k = globalThis.crypto.subtle).importKey) !== null && _d !== void 0 ? _d : _k.importKey = hack;
// @ts-expect-error hack
(_e = (_l = globalThis.crypto.subtle).exportKey) !== null && _e !== void 0 ? _e : _l.exportKey = hack;
// @ts-expect-error hack
(_f = (_m = globalThis.crypto.subtle).digest) !== null && _f !== void 0 ? _f : _m.digest = hack;
// @ts-expect-error hack
(_g = (_o = globalThis.crypto.subtle).sign) !== null && _g !== void 0 ? _g : _o.sign = hack;
exports.default = hack; //# sourceMappingURL=hack.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/transactions.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Transaction = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
class Transaction {
    constructor(irys){
        this.irys = irys;
    }
    getById(id) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const res = (yield this.query({
                ids: [
                    id
                ],
                limit: 1
            })).at(0);
            if (!res) throw new Error(`Unable to locate tx with id ${id}`);
            return res;
        });
    }
    getByOwner(owner) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const res = (yield this.query({
                owners: [
                    owner
                ],
                limit: 1
            })).at(0);
            if (!res) throw new Error(`Unable to locate tx with owner ${owner}`);
            return res;
        });
    }
    getByTag(name, value) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const res = (yield this.query({
                tags: [
                    {
                        name,
                        values: [
                            value
                        ]
                    }
                ],
                limit: 1
            })).at(0);
            if (!res) throw new Error(`Unable to locate tx with tag ${name}:${value}`);
            return res;
        });
    }
    query(parameters) {
        var _a, _b;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            // full bundler node GQL query
            const query = `
    query ($ids: [String!], $after: String, $currency: String, $owners: [String!], $limit: Int, $order: SortOrder, $hasTags: Boolean, $tags: [TagFilter!]) {
      transactions(ids: $ids, after: $after, currency: $currency, owners: $owners, limit: $limit, order: $order, hasTags: $hasTags, tags: $tags) {
        edges {
          cursor
          node {
            address
            currency
            id
            receipt {
              deadlineHeight
              signature
              timestamp
              version
            }
            signature
            tags {
              name
              value
            }
            timestamp
          }
        }
        pageInfo {
          endCursor
          hasNextPage
        }
      }
    }
    `;
            const txs = [];
            let endCursor = null;
            do {
                const gqlRes = yield this.irys.api.post("/graphql", {
                    query,
                    variables: Object.assign(Object.assign({}, parameters), {
                        after: endCursor !== null && endCursor !== void 0 ? endCursor : parameters.after
                    })
                }, undefined);
                endCursor = ((_b = (_a = gqlRes.data.data.transactions) === null || _a === void 0 ? void 0 : _a.pageInfo) === null || _b === void 0 ? void 0 : _b.hasNextPage) ? gqlRes.data.data.transactions.pageInfo.endCursor : null;
                txs.push(...gqlRes.data.data.transactions.edges.map((t)=>t.node));
            }while (endCursor)
            return txs;
        });
    }
}
exports.Transaction = Transaction; //# sourceMappingURL=transactions.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/transaction.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const crypto_1 = tslib_1.__importDefault(__turbopack_require__("[externals]/crypto [external] (crypto, cjs)"));
/**
 * Extended DataItem that allows for seamless Irys operations, such as signing and uploading.
 * Takes the same parameters as a regular DataItem.
 */ function buildIrysTransaction(irys) {
    class IrysTransaction extends irys.arbundles.DataItem {
        constructor(data, irys, opts){
            var _a;
            super((opts === null || opts === void 0 ? void 0 : opts.dataIsRawTransaction) === true ? Buffer.from(data) : irys.arbundles.createData(data, irys.tokenConfig.getSigner(), Object.assign(Object.assign({}, opts), {
                anchor: (_a = opts === null || opts === void 0 ? void 0 : opts.anchor) !== null && _a !== void 0 ? _a : crypto_1.default.randomBytes(32).toString("base64").slice(0, 32)
            })).getRaw());
            this.Irys = irys;
            this.signer = irys.tokenConfig.getSigner();
        }
        sign() {
            return super.sign(this.signer);
        }
        get size() {
            return this.getRaw().length;
        }
        /**
         * @deprecated use upload
         */ uploadWithReceipt(opts) {
            return tslib_1.__awaiter(this, void 0, void 0, function*() {
                return (yield this.Irys.uploader.uploadTransaction(this, opts)).data;
            });
        }
        upload(opts) {
            return tslib_1.__awaiter(this, void 0, void 0, function*() {
                return (yield this.Irys.uploader.uploadTransaction(this, opts)).data;
            });
        }
        // static fromRaw(rawTransaction: Buffer, IrysInstance: Irys): IrysTransaction {
        //   return new IrysTransaction(rawTransaction, IrysInstance, { dataIsRawTransaction: true });
        // }
        getPrice() {
            return tslib_1.__awaiter(this, void 0, void 0, function*() {
                return this.Irys.utils.getPrice(this.Irys.tokenConfig.name, this.size);
            });
        }
        isValid() {
            return tslib_1.__awaiter(this, void 0, void 0, function*() {
                return irys.arbundles.DataItem.verify(this.getRaw());
            });
        }
    }
    return IrysTransaction;
}
exports.default = buildIrysTransaction; // export abstract class IrysTransaction extends DataItem {}
 // export interface IrysTransaction extends DataItem {
 //   size: number;
 //   uploadWithReceipt(opts?: UploadOptions): Promise<UploadReceipt>;
 //   upload(opts: UploadOptions & { getReceiptSignature: true }): Promise<UploadReceipt>;
 //   upload(opts?: UploadOptions): Promise<UploadResponse>;
 // }
 //# sourceMappingURL=transaction.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.erc20abi = exports.Utils = exports.httpErrData = exports.sleep = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const base64url_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const async_retry_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/async-retry@1.3.3/node_modules/async-retry/lib/index.js [app-route] (ecmascript)"));
bignumber_js_1.default.set({
    DECIMAL_PLACES: 50
});
const sleep = (ms)=>new Promise((resolve)=>setTimeout(resolve, ms));
exports.sleep = sleep;
const httpErrData = (res)=>typeof res.data !== "string" ? res.statusText : res.data;
exports.httpErrData = httpErrData;
class Utils {
    constructor(api, token, tokenConfig){
        this.api = api;
        this.token = token;
        this.tokenConfig = tokenConfig;
        this.arbundles = this.tokenConfig.irys.arbundles;
    }
    /**
     * Throws an error if the provided axios reponse has a status code != 200
     * @param res an axios response
     * @returns nothing if the status code is 200
     */ static checkAndThrow(res, context, exceptions) {
        if ((res === null || res === void 0 ? void 0 : res.status) && !(exceptions !== null && exceptions !== void 0 ? exceptions : []).includes(res.status) && res.status != 200) {
            throw new Error(`HTTP Error: ${context}: ${res.status} ${typeof res.data !== "string" ? res.statusText : res.data}`);
        }
        return;
    }
    /**
     * Gets the nonce used for withdrawal request validation from the bundler
     * @returns nonce for the current user
     */ getNonce() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const res = yield this.api.get(`/account/withdrawals/${this.tokenConfig.name}?address=${this.tokenConfig.address}`);
            Utils.checkAndThrow(res, "Getting withdrawal nonce");
            return res.data;
        });
    }
    /**
     * Gets the balance on the current bundler for the specified user
     * @param address the user's address to query
     * @returns the balance in winston
     */ getBalance(address) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const res = yield this.api.get(`/account/balance/${this.tokenConfig.name}?address=${address}`);
            Utils.checkAndThrow(res, "Getting balance");
            return new bignumber_js_1.default(res.data.balance);
        });
    }
    /**
     * Queries the bundler to get it's address for a specific token
     * @returns the bundler's address
     */ getBundlerAddress(token) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const res = yield this.api.get("/info");
            Utils.checkAndThrow(res, "Getting Bundler address");
            const address = res.data.addresses[token];
            if (!address) {
                throw new Error(`Specified bundler does not support token ${token}`);
            }
            return address;
        });
    }
    /**
     * Calculates the price for [bytes] bytes paid for with [token] for the loaded Irys node.
     * @param token
     * @param bytes
     * @returns
     */ getPrice(token, bytes) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const res = yield this.api.get(`/price/${token}/${bytes}`);
            Utils.checkAndThrow(res, "Getting storage cost");
            return new bignumber_js_1.default(res.data);
        });
    }
    /**
     * This function *estimates* the cost in atomic units for uploading a given set of files
     * note: this function becomes less accurate the smaller your transactions, unless you provide it with an accurate headerSizeAvg
     * @param folderInfo either an array of file sizes in bytes, or an object containing the total number of files and the sum total size of the files in bytes
     * note: for a more precise estimate, you can create an empty (dataless) transaction (make sure you still set tags and other metadata!) and then pass `tx.size` as `headerSizeAvg`
     */ estimateFolderPrice(folderInfo) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (Array.isArray(folderInfo)) {
                folderInfo = {
                    fileCount: folderInfo.length,
                    totalBytes: folderInfo.reduce((acc, v)=>acc + v, 0)
                };
            }
            // create a 0 data byte tx to estimate the per tx header overhead
            const headerSizeAvg = (_a = folderInfo.headerSizeAvg) !== null && _a !== void 0 ? _a : this.arbundles.createData("", this.tokenConfig.getSigner()).getRaw().length;
            const pricePerTxBase = yield this.getPrice(this.tokenConfig.name, headerSizeAvg);
            const basePriceForTxs = pricePerTxBase.multipliedBy(folderInfo.fileCount);
            const priceForData = (yield this.getPrice(this.tokenConfig.name, folderInfo.totalBytes)).plus(basePriceForTxs).decimalPlaces(0);
            return priceForData;
        });
    }
    /**
     * Returns the decimal values' equivalent in atomic units
     * @example
     * 0.1 ETH -> 100,000,000,000,000,000 wei
     * ```
     * toAtomic(100_000_000_000_000_000) -> 0.1
     * ```
     * @param decimalAmount - amount in decimal
     * @returns amount in atomic units
     */ toAtomic(decimalAmount) {
        return new bignumber_js_1.default(decimalAmount).multipliedBy(this.tokenConfig.base[1]);
    }
    /**
     * Returns the atomic amounts' equivalent in decimal units
     * @example
     * 100,000,000,000,000,000 wei -> 0.1 ETH
     * ```
     * fromAtomic(0.1) -> 100_000_000_000_000_000
     * ```
     * @param atomicAmount
     * @returns
     */ fromAtomic(atomicAmount) {
        return new bignumber_js_1.default(atomicAmount).dividedBy(this.tokenConfig.base[1]);
    }
    /**
     * Polls for transaction confirmation (or at least pending status) - used for fast currencies (i.e not arweave)
     * before posting the fund request to the server (so the server doesn't have to poll)
     * @param txid
     * @returns
     */ confirmationPoll(txid, seconds = 30) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (this.tokenConfig.isSlow) return;
            if (seconds < 0) seconds = 0;
            let lastError;
            let timedout;
            const internalPoll = ()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    while(!timedout){
                        const getRes = yield this.tokenConfig.getTx(txid).then((v)=>v === null || v === void 0 ? void 0 : v.confirmed).catch((err)=>{
                            lastError = err;
                            return false;
                        });
                        if (getRes) return true;
                        yield (0, exports.sleep)(1000);
                    }
                    return false;
                });
            const racer = ()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    yield (0, exports.sleep)(seconds * 1000);
                    timedout = true;
                    return "RACE";
                });
            const r = yield Promise.race([
                racer(),
                internalPoll()
            ]);
            if (r === "RACE") {
                console.warn(`Tx ${txid} didn't finalize after ${seconds} seconds ${lastError ? ` - ${lastError}` : ""}`);
                return lastError;
            }
            return r;
        });
    }
    /**
     * @deprecated this method is deprecated in favour of fromAtomic - removal slated for 0.12.0
     */ unitConverter(baseUnits) {
        return new bignumber_js_1.default(baseUnits).dividedBy(this.tokenConfig.base[1]);
    }
    verifyReceipt(receipt) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return Utils.verifyReceipt(this.arbundles, receipt);
        });
    }
    static verifyReceipt(dependencies, receipt) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const { id, deadlineHeight, timestamp, public: pubKey, signature, version } = receipt;
            const dh = yield dependencies.deepHash([
                dependencies.stringToBuffer("Bundlr"),
                dependencies.stringToBuffer(version),
                dependencies.stringToBuffer(id),
                dependencies.stringToBuffer(deadlineHeight.toString()),
                dependencies.stringToBuffer(timestamp.toString())
            ]);
            return yield dependencies.getCryptoDriver().verify(pubKey, dh, base64url_1.default.toBuffer(signature));
        });
    }
    getReceipt(txId) {
        var _a, _b, _c, _d, _e, _f;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            // get receipt information from GQL
            const query = `query {
      transactions(ids: ["${txId}"]) {
        edges {
          node {
            receipt {
              signature
              timestamp
              version
              deadlineHeight
            }
          }
        }
      }
    }`;
            const queryRes = yield (0, async_retry_1.default)(()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    return yield this.api.post("/graphql", {
                        query
                    }, {
                        headers: {
                            "content-type": "application/json"
                        },
                        validateStatus: (s)=>s === 200
                    });
                }));
            const receiptData = (_f = (_e = (_d = (_c = (_b = (_a = queryRes === null || queryRes === void 0 ? void 0 : queryRes.data) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.transactions) === null || _c === void 0 ? void 0 : _c.edges) === null || _d === void 0 ? void 0 : _d.at(0)) === null || _e === void 0 ? void 0 : _e.node) === null || _f === void 0 ? void 0 : _f.receipt;
            if (!receiptData) throw new Error(`Missing required receipt data from node for tx: ${txId}`);
            // get public key from node
            const pubKey = (yield this.api.get("/public")).data;
            const receipt = {
                public: pubKey,
                version: receiptData.version,
                id: txId,
                timestamp: receiptData.timestamp,
                validatorSignatures: [],
                signature: receiptData.signature,
                deadlineHeight: receiptData.deadlineHeight,
                // use stub to conform to type
                verify: ()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                        return false;
                    })
            };
            // inject method
            receipt.verify = ()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    return this.verifyReceipt(receipt);
                });
            return receipt;
        });
    }
}
exports.Utils = Utils;
exports.default = Utils;
exports.erc20abi = [
    {
        constant: true,
        inputs: [],
        name: "name",
        outputs: [
            {
                name: "",
                type: "string"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    },
    {
        constant: false,
        inputs: [
            {
                name: "_spender",
                type: "address"
            },
            {
                name: "_value",
                type: "uint256"
            }
        ],
        name: "approve",
        outputs: [
            {
                name: "",
                type: "bool"
            }
        ],
        payable: false,
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        constant: true,
        inputs: [],
        name: "totalSupply",
        outputs: [
            {
                name: "",
                type: "uint256"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    },
    {
        constant: false,
        inputs: [
            {
                name: "_from",
                type: "address"
            },
            {
                name: "_to",
                type: "address"
            },
            {
                name: "_value",
                type: "uint256"
            }
        ],
        name: "transferFrom",
        outputs: [
            {
                name: "",
                type: "bool"
            }
        ],
        payable: false,
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        constant: true,
        inputs: [],
        name: "decimals",
        outputs: [
            {
                name: "",
                type: "uint8"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    },
    {
        constant: true,
        inputs: [
            {
                name: "_owner",
                type: "address"
            }
        ],
        name: "balanceOf",
        outputs: [
            {
                name: "balance",
                type: "uint256"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    },
    {
        constant: true,
        inputs: [],
        name: "symbol",
        outputs: [
            {
                name: "",
                type: "string"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    },
    {
        constant: false,
        inputs: [
            {
                name: "_to",
                type: "address"
            },
            {
                name: "_value",
                type: "uint256"
            }
        ],
        name: "transfer",
        outputs: [
            {
                name: "",
                type: "bool"
            }
        ],
        payable: false,
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        constant: true,
        inputs: [
            {
                name: "_owner",
                type: "address"
            },
            {
                name: "_spender",
                type: "address"
            }
        ],
        name: "allowance",
        outputs: [
            {
                name: "",
                type: "uint256"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    },
    {
        payable: true,
        stateMutability: "payable",
        type: "fallback"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                name: "owner",
                type: "address"
            },
            {
                indexed: true,
                name: "spender",
                type: "address"
            },
            {
                indexed: false,
                name: "value",
                type: "uint256"
            }
        ],
        name: "Approval",
        type: "event"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                name: "from",
                type: "address"
            },
            {
                indexed: true,
                name: "to",
                type: "address"
            },
            {
                indexed: false,
                name: "value",
                type: "uint256"
            }
        ],
        name: "Transfer",
        type: "event"
    }
]; //# sourceMappingURL=utils.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/withdrawal.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.withdrawBalance = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const utils_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)"));
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const base64url_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
/**
 * Create and send a withdrawal request
 * @param utils Instance of Utils
 * @param api Instance of API
 * @param wallet Wallet to use
 * @param amount amount to withdraw in winston
 * @returns the response from the bundler
 */ function withdrawBalance(utils, api, amount) {
    return tslib_1.__awaiter(this, void 0, void 0, function*() {
        const c = utils.tokenConfig;
        const { deepHash, stringToBuffer } = c.irys.arbundles;
        const pkey = yield c.getPublicKey();
        const withdrawAll = amount === "all";
        const data = {
            publicKey: pkey,
            currency: utils.token,
            amount: withdrawAll ? "all" : new bignumber_js_1.default(amount).toString(),
            nonce: yield utils.getNonce(),
            signature: "",
            sigType: c.getSigner().signatureType
        };
        const deephash = yield deepHash([
            stringToBuffer(data.currency),
            stringToBuffer(data.amount.toString()),
            stringToBuffer(data.nonce.toString())
        ]);
        if (!Buffer.isBuffer(data.publicKey)) {
            data.publicKey = Buffer.from(data.publicKey);
        }
        const signature = yield c.sign(deephash);
        const isValid = yield c.verify(data.publicKey, deephash, signature);
        data.publicKey = base64url_1.default.encode(data.publicKey);
        data.signature = base64url_1.default.encode(Buffer.from(signature));
        const cpk = base64url_1.default.toBuffer(data.publicKey);
        const csig = base64url_1.default.toBuffer(data.signature);
        // should match opk and csig
        const dh2 = yield deepHash([
            stringToBuffer(data.currency),
            stringToBuffer(data.amount.toString()),
            stringToBuffer(data.nonce.toString())
        ]);
        const isValid2 = yield c.verify(cpk, dh2, csig);
        const isValid3 = c.ownerToAddress(c.name == "arweave" ? base64url_1.default.decode(data.publicKey) : base64url_1.default.toBuffer(data.publicKey)) === c.address;
        if (!(isValid || isValid2 || isValid3)) {
            throw new Error(`Internal withdrawal validation failed - please report this!\nDebug Info:${JSON.stringify(data)}`);
        }
        const res = yield api.post("/account/withdraw", data);
        if (res.status === 202) {
            // node has timed/erroed out confirming the withdrawal
            const txId = res.data.tx_id;
            const withdrawalConfirmed = yield utils.confirmationPoll(txId);
            if (!(withdrawalConfirmed === true)) throw new Error(`Unable to confirm withdrawal tx ${txId} ${withdrawalConfirmed ? withdrawalConfirmed === null || withdrawalConfirmed === void 0 ? void 0 : withdrawalConfirmed.toString() : ""}`);
        } else {
            utils_1.default.checkAndThrow(res, "Withdrawing balance");
        }
        return res.data;
    });
}
exports.withdrawBalance = withdrawBalance; //# sourceMappingURL=withdrawal.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/irys.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const transaction_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/transaction.js [app-route] (ecmascript)"));
const utils_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)"));
const withdrawal_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/withdrawal.js [app-route] (ecmascript)");
const query_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+query@0.0.8/node_modules/@irys/query/build/cjs/index.js [app-route] (ecmascript)"));
class Irys {
    constructor({ url, network, arbundles }){
        this.debug = false;
        switch(network){
            // case undefined:
            case "mainnet":
                url = "https://arweave.mainnet.irys.xyz";
                break;
            case "devnet":
                url = "https://arweave.devnet.irys.xyz";
                break;
        }
        if (!url) throw new Error(`Missing required Irys constructor parameter: URL or valid Network`);
        const parsed = new URL(url);
        this.url = parsed;
        this.arbundles = arbundles;
        this.IrysTransaction = (0, transaction_1.default)(this);
    }
    get address() {
        if (!this._address) throw new Error("Address is undefined, please provide a wallet or run `await irys.ready()`");
        return this._address;
    }
    set address(address) {
        this._address = address;
    }
    get signer() {
        return this.tokenConfig.getSigner();
    }
    get search() {
        const q = new query_1.default({
            url: new URL("/graphql", this.url)
        });
        return q.search.bind(q);
    }
    query(queryOpts) {
        return new query_1.default(queryOpts !== null && queryOpts !== void 0 ? queryOpts : {
            url: new URL("graphql", this.url)
        });
    }
    withdrawBalance(amount) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return (0, withdrawal_1.withdrawBalance)(this.utils, this.api, amount);
        });
    }
    withdrawAll() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return (0, withdrawal_1.withdrawBalance)(this.utils, this.api, "all");
        });
    }
    /**
     * Gets the balance for the loaded wallet
     * @returns balance (in winston)
     */ getLoadedBalance() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.address) throw new Error("address is undefined");
            return this.utils.getBalance(this.address);
        });
    }
    /**
     * Gets the balance for the specified address
     * @param address address to query for
     * @returns the balance (in winston)
     */ getBalance(address) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.utils.getBalance(address);
        });
    }
    /**
     * Sends amount atomic units to the specified bundler
     * @param amount amount to send in atomic units
     * @returns details about the fund transaction
     */ fund(amount, multiplier) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.funder.fund(amount, multiplier);
        });
    }
    /**
     * Calculates the price for [bytes] bytes for the loaded token and Irys node.
     * @param bytes
     * @returns
     */ getPrice(bytes) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.utils.getPrice(this.token, bytes);
        });
    }
    verifyReceipt(receipt) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return utils_1.default.verifyReceipt(this.arbundles, receipt);
        });
    }
    /**
     * Create a new IrysTransactions (flex token arbundles dataItem)
     * @param data
     * @param opts - dataItemCreateOptions
     * @returns - a new IrysTransaction instance
     */ createTransaction(data, opts) {
        return new this.IrysTransaction(data, this, opts);
    }
    /**
     * Returns the signer for the loaded token
     */ getSigner() {
        return this.tokenConfig.getSigner();
    }
    upload(data, opts) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.uploader.uploadData(data, opts);
        });
    }
    /**
     * @deprecated - use upload instead
     */ uploadWithReceipt(data, opts) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.uploader.uploadData(data, Object.assign({}, opts));
        });
    }
    ready() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            this.tokenConfig.ready ? yield this.tokenConfig.ready() : true;
            this.address = this.tokenConfig.address;
            return this;
        });
    }
    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
    get transaction() {
        // eslint-disable-next-line @typescript-eslint/no-this-alias
        const oThis = this;
        return {
            fromRaw (rawTransaction) {
                return new oThis.IrysTransaction(rawTransaction, oThis, {
                    dataIsRawTransaction: true
                });
            }
        };
    }
}
Irys.VERSION = "0.2.11";
exports.default = Irys; //# sourceMappingURL=irys.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/api.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Api = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const axios_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/axios@1.7.9/node_modules/axios/dist/node/axios.cjs [app-route] (ecmascript)"));
const irys_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/irys.js [app-route] (ecmascript)"));
class Api {
    constructor(config){
        this.cookieMap = new Map();
        if (config) this.applyConfig(config);
    }
    applyConfig(config) {
        this.config = this.mergeDefaults(config);
        this._instance = undefined;
    }
    getConfig() {
        return this.config;
    }
    requestInterceptor(request) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const cookies = this.cookieMap.get(new URL((_a = request.baseURL) !== null && _a !== void 0 ? _a : "").hostname);
            if (cookies) request.headers.cookie = cookies;
            return request;
        });
    }
    responseInterceptor(response) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const setCookie = (_a = response.headers) === null || _a === void 0 ? void 0 : _a["set-cookie"];
            if (setCookie) this.cookieMap.set(response.request.host, setCookie);
            return response;
        });
    }
    mergeDefaults(config) {
        var _a, _b, _c, _d;
        return {
            url: config.url,
            timeout: (_a = config.timeout) !== null && _a !== void 0 ? _a : 20000,
            logging: (_b = config.logging) !== null && _b !== void 0 ? _b : false,
            logger: (_c = config.logger) !== null && _c !== void 0 ? _c : console.log,
            headers: Object.assign(Object.assign({}, config.headers), {
                "x-irys-js-sdk-version": irys_1.default.VERSION
            }),
            withCredentials: (_d = config.withCredentials) !== null && _d !== void 0 ? _d : false,
            retry: {
                retries: 3,
                maxTimeout: 5000
            }
        };
    }
    get(path, config) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            try {
                return yield this.request(path, Object.assign(Object.assign({}, config), {
                    method: "GET"
                }));
            } catch (error) {
                if ((_a = error.response) === null || _a === void 0 ? void 0 : _a.status) return error.response;
                throw error;
            }
        });
    }
    post(path, body, config) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            try {
                return yield this.request(path, Object.assign(Object.assign({
                    data: body
                }, config), {
                    method: "POST"
                }));
            } catch (error) {
                if ((_a = error.response) === null || _a === void 0 ? void 0 : _a.status) return error.response;
                throw error;
            }
        });
    }
    get instance() {
        if (this._instance) return this._instance;
        const instance = axios_1.default.create({
            baseURL: this.config.url.toString(),
            timeout: this.config.timeout,
            maxContentLength: 1024 * 1024 * 512,
            headers: this.config.headers,
            withCredentials: this.config.withCredentials
        });
        if (this.config.withCredentials) {
            instance.interceptors.request.use(this.requestInterceptor.bind(this));
            instance.interceptors.response.use(this.responseInterceptor.bind(this));
        }
        if (this.config.logging) {
            instance.interceptors.request.use((request)=>{
                this.config.logger(`Requesting: ${request.baseURL}/${request.url}`);
                return request;
            });
            instance.interceptors.response.use((response)=>{
                this.config.logger(`Response: ${response.config.url} - ${response.status}`);
                return response;
            });
        }
        return this._instance = instance;
    }
    request(path, config) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const instance = this.instance;
            const url = (_a = config === null || config === void 0 ? void 0 : config.url) !== null && _a !== void 0 ? _a : new URL(path, this.config.url).toString();
            // return AsyncRetry((_) => instance({ ...config, url }), {
            //   ...this.config.retry,
            //   ...config?.retry,
            // });
            return instance(Object.assign(Object.assign({}, config), {
                url
            }));
        });
    }
}
exports.Api = Api;
exports.default = Api; // /**
 //  * *** To be removed when browsers catch up with the whatwg standard. ***
 //  * [Symbol.AsyncIterator] is needed to use `for-await` on the returned ReadableStream (web stream).
 //  * Feature is available in nodejs, and should be available in browsers eventually.
 //  */
 // export const addAsyncIterator = (body: ReadableStream): ReadableStream => {
 //   const bodyWithIter = body as ReadableStream<Uint8Array> & AsyncIterable<Uint8Array>;
 //   if (typeof bodyWithIter[Symbol.asyncIterator] === "undefined") {
 //     bodyWithIter[Symbol.asyncIterator] = webIiterator<Uint8Array>(body);
 //     return bodyWithIter;
 //   }
 //   return body;
 // };
 // const webIiterator = function <T>(stream: ReadableStream): () => AsyncGenerator<Awaited<T>, void> {
 //   return async function* iteratorGenerator<T>() {
 //     const reader = stream.getReader(); // lock
 //     try {
 //       while (true) {
 //         const { done, value } = await reader.read();
 //         if (done) return;
 //         yield value as T;
 //       }
 //     } finally {
 //       reader.releaseLock(); // unlock
 //     }
 //   };
 // };
 //# sourceMappingURL=api.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/fund.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Fund = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const async_retry_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/async-retry@1.3.3/node_modules/async-retry/lib/index.js [app-route] (ecmascript)"));
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const utils_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)"));
class Fund {
    constructor(utils){
        this.utils = utils;
    }
    /**
     * Function to Fund (send funds to) a Irys node - inherits instance token and node
     * @param amount - amount in base units to send
     * @param multiplier - network tx fee multiplier - only works for specific currencies
     * @returns  - funding receipt
     */ fund(amount, multiplier = 1.0) {
        var _a, _b;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            amount = new bignumber_js_1.default(amount);
            if (!amount.isInteger()) {
                throw new Error("must use an integer for funding amount");
            }
            const c = this.utils.tokenConfig;
            const to = yield this.utils.getBundlerAddress(this.utils.token);
            let fee = c.needsFee ? yield c.getFee(amount, to, multiplier) : undefined;
            // if fee is defined, is a bigNumber, and getFee doesn't accept the multiplier arg, apply multiplier here.
            // tokens should now handle multipliers within getFee, this is a temporary transitionary measure.
            if (fee && bignumber_js_1.default.isBigNumber(fee) && c.getFee.length < 3) fee = fee.multipliedBy(multiplier).integerValue();
            const tx = yield c.createTx(amount, to, fee);
            const sendTxRes = yield c.sendTx(tx.tx);
            (_a = tx.txId) !== null && _a !== void 0 ? _a : tx.txId = sendTxRes;
            if (!tx.txId) throw new Error(`Undefined transaction ID`);
            // Utils.checkAndThrow(sendTxRes, `Sending transaction to the ${this.utils.token} network`);
            let confirmError = yield this.utils.confirmationPoll(tx.txId);
            const bres = yield this.submitTransaction(tx.txId).catch((e)=>{
                confirmError = e;
                return undefined;
            });
            if (!bres) {
                throw new Error(`failed to post funding tx - ${tx.txId} - keep this id! \n ${confirmError ? ` - ${(_b = confirmError === null || confirmError === void 0 ? void 0 : confirmError.message) !== null && _b !== void 0 ? _b : confirmError}` : ""}`);
            }
            return {
                reward: bignumber_js_1.default.isBigNumber(fee) ? fee.toString() : JSON.stringify(fee),
                target: to,
                quantity: amount.toString(),
                id: tx.txId
            };
        });
    }
    submitTransaction(transactionId) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return yield (0, async_retry_1.default)(()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    const bres = yield this.utils.api.post(`/account/balance/${this.utils.token}`, {
                        tx_id: transactionId
                    });
                    utils_1.default.checkAndThrow(bres, `Posting transaction ${transactionId} information to the bundler`, [
                        202
                    ]);
                    return bres;
                }), {
                retries: 5,
                maxTimeout: 1000,
                minTimeout: 100,
                randomize: true
            });
        });
    }
    submitFundTransaction(transactionId) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.submitTransaction(transactionId);
        });
    }
}
exports.Fund = Fund;
exports.default = Fund; //# sourceMappingURL=fund.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/types.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.UploadHeaders = void 0;
var UploadHeaders;
(function(UploadHeaders) {
    UploadHeaders["PAID_BY"] = "x-irys-paid-by";
})(UploadHeaders || (exports.UploadHeaders = UploadHeaders = {})); //# sourceMappingURL=types.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/s2ai.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.STATES = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const NOT_READABLE = Symbol("not readable");
const READABLE = Symbol("readable");
const ENDED = Symbol("ended");
const ERRORED = Symbol("errored");
exports.STATES = {
    notReadable: NOT_READABLE,
    readable: READABLE,
    ended: ENDED,
    errored: ERRORED
};
/**
 * Wraps a stream into an object that can be used as an async iterator.
 *
 * This will keep a stream in a paused state, and will only read from the stream on each
 * iteration. A size can be supplied to set an explicit call to `stream.read([size])` in
 * the options for each iteration.
 */ class StreamToAsyncIterator {
    get closed() {
        return this._state === exports.STATES.ended;
    }
    constructor(stream, { size } = {}){
        /** The current state of the iterator (not readable, readable, ended, errored) */ this._state = exports.STATES.notReadable;
        /** The rejections of promises to call when stream errors out */ this._rejections = new Set();
        this._stream = stream;
        this._size = size;
        const bindMethods = [
            "_handleStreamEnd",
            "_handleStreamError"
        ];
        for (const method of bindMethods){
            Object.defineProperty(this, method, {
                configurable: true,
                writable: true,
                value: this[method].bind(this)
            });
        }
        // eslint-disable-next-line @typescript-eslint/unbound-method
        stream.once("error", this._handleStreamError);
        // eslint-disable-next-line @typescript-eslint/unbound-method
        stream.once("end", this._handleStreamEnd);
        stream.on("readable", ()=>{
            this._state = exports.STATES.readable;
        });
    }
    [Symbol.asyncIterator]() {
        return this;
    }
    /**
     * Returns the next iteration of data. Rejects if the stream errored out.
     */ next() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            switch(this._state){
                case exports.STATES.notReadable:
                    {
                        let untilReadable;
                        let untilEnd;
                        try {
                            untilReadable = this._untilReadable();
                            untilEnd = this._untilEnd();
                            yield Promise.race([
                                untilReadable.promise,
                                untilEnd.promise
                            ]);
                        } finally{
                            // need to clean up any hanging event listeners
                            if (untilReadable != null) {
                                untilReadable.close();
                            }
                            if (untilEnd != null) {
                                untilEnd.close();
                            }
                        }
                        return this.next();
                    }
                case exports.STATES.ended:
                    {
                        this.close();
                        return {
                            done: true,
                            value: undefined
                        };
                    }
                case exports.STATES.errored:
                    {
                        this.close();
                        throw this._error;
                    }
                case exports.STATES.readable:
                    {
                        // stream.read returns null if not readable or when stream has ended
                        // todo: Could add a way to ensure data-type/shape of reads to make this type safe
                        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
                        const data = this._size ? this._stream.read(this._size) : this._stream.read();
                        if (data !== null) {
                            return {
                                done: false,
                                value: data
                            };
                        } else {
                            // we're no longer readable, need to find out what state we're in
                            this._state = exports.STATES.notReadable;
                            // need to let event loop run to fill stream buffer
                            yield new Promise((r)=>setTimeout((r)=>r(true), 0, r));
                            return this.next();
                        }
                    }
            }
        });
    }
    /**
     * Waits until the stream is readable. Rejects if the stream errored out.
     * @returns Promise when stream is readable
     */ _untilReadable() {
        // let is used here instead of const because the exact reference is
        // required to remove it, this is why it is not a curried function that
        // accepts resolve & reject as parameters.
        let handleReadable = undefined;
        const promise = new Promise((resolve, reject)=>{
            handleReadable = ()=>{
                this._state = exports.STATES.readable;
                this._rejections.delete(reject);
                resolve();
            };
            if (this._state === exports.STATES.readable) handleReadable; // race condition guard
            this._stream.once("readable", handleReadable);
            this._rejections.add(reject);
        });
        const cleanup = ()=>{
            if (handleReadable != null) {
                this._stream.removeListener("readable", handleReadable);
            }
        };
        return {
            close: cleanup,
            promise
        };
    }
    /**
     * Waits until the stream is ended. Rejects if the stream errored out.
     * @returns Promise when stream is finished
     */ _untilEnd() {
        let handleEnd = undefined;
        const promise = new Promise((resolve, reject)=>{
            handleEnd = ()=>{
                this._state = exports.STATES.ended;
                this._rejections.delete(reject);
                resolve();
            };
            this._stream.once("end", handleEnd);
            this._rejections.add(reject);
        });
        const cleanup = ()=>{
            if (handleEnd != null) {
                this._stream.removeListener("end", handleEnd);
            }
        };
        return {
            close: cleanup,
            promise
        };
    }
    return() {
        this._state = exports.STATES.ended;
        return this.next();
    }
    throw(err) {
        this._error = err;
        this._state = exports.STATES.errored;
        return this.next();
    }
    /**
     * Destroy the stream
     * @param err An optional error to pass to the stream for an error event
     */ close(err) {
        // eslint-disable-next-line @typescript-eslint/unbound-method
        this._stream.removeListener("end", this._handleStreamEnd);
        // eslint-disable-next-line @typescript-eslint/unbound-method
        this._stream.removeListener("error", this._handleStreamError);
        this._state = exports.STATES.ended;
        this._stream.destroy(err);
    }
    _handleStreamError(err) {
        this._error = err;
        this._state = exports.STATES.errored;
        for (const reject of this._rejections){
            reject(err);
        }
    }
    _handleStreamEnd() {
        this._state = exports.STATES.ended;
    }
    get state() {
        return this._state;
    }
}
exports.default = StreamToAsyncIterator; // export const addAsyncIterator = (body: ReadableStream) => {
 //   const bodyWithIter = body as ReadableStream<Uint8Array> & AsyncIterable<Uint8Array>;
 //   if (typeof bodyWithIter[Symbol.asyncIterator] === "undefined") {
 //     bodyWithIter[Symbol.asyncIterator] = webIiterator<Uint8Array>(body);
 //     return bodyWithIter;
 //   }
 //   return body;
 // };
 // export const webIiterator = function <T>(stream: ReadableStream) {
 //   return async function* iteratorGenerator<T>() {
 //     const reader = stream.getReader(); //lock
 //     try {
 //       const { done, value } = await reader.read();
 //       if (done) return;
 //       yield value as T;
 //     } finally {
 //       reader.releaseLock(); //unlock
 //     }
 //   };
 // };
 //# sourceMappingURL=s2ai.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/chunkingUploader.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ChunkingUploader = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const stream_1 = __turbopack_require__("[externals]/stream [external] (stream, cjs)");
const events_1 = __turbopack_require__("[externals]/events [external] (events, cjs)");
const types_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/types.js [app-route] (ecmascript)");
const utils_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)"));
const crypto_1 = tslib_1.__importDefault(__turbopack_require__("[externals]/crypto [external] (crypto, cjs)"));
const async_retry_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/async-retry@1.3.3/node_modules/async-retry/lib/index.js [app-route] (ecmascript)"));
const s2ai_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/s2ai.js [app-route] (ecmascript)"));
class ChunkingUploader extends events_1.EventEmitter {
    constructor(tokenConfig, api){
        super({
            captureRejections: true
        });
        this.paused = false;
        this.isResume = false;
        this.tokenConfig = tokenConfig;
        this.arbundles = this.tokenConfig.irys.arbundles;
        this.api = api;
        this.token = this.tokenConfig.name;
        this.chunkSize = 25000000;
        this.batchSize = 5;
        this.uploadID = "";
    }
    setResumeData(uploadID) {
        if (uploadID) {
            this.uploadID = uploadID;
            this.isResume = true;
        }
        return this;
    }
    /**
     * Note: Will return undefined unless an upload has been started.
     * @returns
     */ getResumeData() {
        return this.uploadID;
    }
    setChunkSize(size) {
        if (size < 1) {
            throw new Error("Invalid chunk size (must be >=1)");
        }
        this.chunkSize = size;
        return this;
    }
    setBatchSize(size) {
        if (size < 1) {
            throw new Error("Invalid batch size (must be >=1)");
        }
        this.batchSize = size;
        return this;
    }
    pause() {
        this.emit("pause");
        this.paused = true;
    }
    resume() {
        this.paused = false;
        this.emit("resume");
    }
    uploadTransaction(data, opts) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            this.uploadOptions = opts;
            if (this.arbundles.DataItem.isDataItem(data)) {
                return this.runUpload(data.getRaw());
            } else {
                return this.runUpload(data);
            }
        });
    }
    uploadData(dataStream, options) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            this.uploadOptions = options === null || options === void 0 ? void 0 : options.upload;
            return this.runUpload(dataStream, Object.assign({}, options));
        });
    }
    runUpload(dataStream, transactionOpts) {
        var _a, _b, _c, _d, _e, _f;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            let id = this.uploadID;
            const isTransaction = transactionOpts === undefined;
            const headers = {
                "x-chunking-version": "2"
            };
            let getres;
            if (!id) {
                getres = yield this.api.get(`/chunks/${this.token}/-1/-1`, {
                    headers
                });
                utils_1.default.checkAndThrow(getres, "Getting upload token");
                this.uploadID = id = getres.data.id;
            } else {
                getres = yield this.api.get(`/chunks/${this.token}/${id}/-1`, {
                    headers
                });
                if (getres.status === 404) throw new Error(`Upload ID not found - your upload has probably expired.`);
                utils_1.default.checkAndThrow(getres, "Getting upload info");
                if (this.chunkSize != +getres.data.size) {
                    throw new Error(`Chunk size not equal to that of a previous upload (${+getres.data.size}).`);
                }
            }
            const { max, min } = getres.data;
            if (this.chunkSize < +min || this.chunkSize > +max) {
                throw new Error(`Chunk size out of allowed range: ${min} - ${max}`);
            }
            let totalUploaded = 0;
            const promiseFactory = (d, o, c)=>{
                return new Promise((r)=>{
                    (0, async_retry_1.default)((bail)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                            yield this.api.post(`/chunks/${this.token}/${id}/${o}`, d, {
                                headers: Object.assign({
                                    "Content-Type": "application/octet-stream"
                                }, headers),
                                maxBodyLength: Infinity,
                                maxContentLength: Infinity
                            }).then((re)=>{
                                var _a;
                                if ((re === null || re === void 0 ? void 0 : re.status) >= 300) {
                                    const e = {
                                        res: re,
                                        id: c,
                                        offset: o,
                                        size: d.length
                                    };
                                    this.emit("chunkError", e);
                                    if ((re === null || re === void 0 ? void 0 : re.status) === 402) {
                                        const retryAfterHeader = (_a = finishUpload === null || finishUpload === void 0 ? void 0 : finishUpload.headers) === null || _a === void 0 ? void 0 : _a["retry-after"];
                                        const errorMsg = "402 error: " + finishUpload.data + (retryAfterHeader ? ` - retry after ${retryAfterHeader}s` : "");
                                        bail(new Error(errorMsg));
                                    }
                                    throw e;
                                }
                                this.emit("chunkUpload", {
                                    id: c,
                                    offset: o,
                                    size: d.length,
                                    totalUploaded: totalUploaded += d.length
                                });
                                r({
                                    o,
                                    d: re
                                });
                            });
                        })), {
                        retries: 3,
                        minTimeout: 1000,
                        maxTimeout: 10000
                    };
                });
            };
            const present = (_a = getres.data.chunks) !== null && _a !== void 0 ? _a : [];
            const stream = new stream_1.PassThrough();
            let cache = Buffer.alloc(0);
            let ended = false;
            let hasData = true;
            stream.on("end", ()=>ended = true);
            stream.on("error", (e)=>{
                throw new Error(`Error processing readable: ${e}`);
            });
            // custom as we need to read any number of bytes.
            const readBytes = (size)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    while(!ended){
                        if (cache.length >= size) {
                            data = Buffer.from(cache.slice(0, size)); // force a copy
                            cache = cache.slice(size);
                            return data;
                        }
                        // eslint-disable-next-line no-var
                        var data = stream.read(size);
                        if (data === null) {
                            // wait for stream refill (perferred over setImmeadiate due to multi env support)
                            yield new Promise((r)=>setTimeout((r)=>r(true), 0, r));
                            continue;
                        }
                        if (data.length === size) return data;
                        cache = Buffer.concat([
                            cache,
                            data
                        ]);
                    }
                    // flush
                    while(cache.length >= size){
                        data = Buffer.from(cache.slice(0, size)); // force a copy
                        cache = cache.slice(size);
                        return data;
                    }
                    hasData = false;
                    return cache;
                });
            let tx;
            let txHeaderLength;
            // doesn't matter if we randomise ID (anchor) between resumes, as the tx header/signing info is always uploaded last.
            if (!isTransaction) {
                tx = this.arbundles.createData("", this.tokenConfig.getSigner(), Object.assign(Object.assign({}, transactionOpts), {
                    anchor: (_b = transactionOpts === null || transactionOpts === void 0 ? void 0 : transactionOpts.anchor) !== null && _b !== void 0 ? _b : crypto_1.default.randomBytes(32).toString("base64").slice(0, 32)
                }));
                const raw = tx.getRaw();
                txHeaderLength = raw.length;
                stream.write(raw);
                totalUploaded -= raw.length;
            }
            if (Buffer.isBuffer(dataStream)) {
                stream.write(dataStream);
                stream.end();
            } else if ("pipe" in dataStream) {
                dataStream.pipe(stream);
            } else {
                throw new Error("Input data is not a buffer or a compatible stream (no .pipe method)");
            }
            let offset = 0;
            const processing = new Set();
            let chunkID = 0;
            let heldChunk;
            let teeStream;
            let deephash;
            if (!isTransaction) {
                teeStream = new stream_1.PassThrough();
                const txLength = tx.getRaw().length;
                if (this.chunkSize < txHeaderLength) throw new Error(`Configured chunk size is too small for transaction header! (${this.chunkSize} < ${txHeaderLength})`);
                heldChunk = yield readBytes(this.chunkSize);
                chunkID++;
                offset += heldChunk.length;
                teeStream.write(heldChunk.slice(txLength));
                const sigComponents = [
                    this.arbundles.stringToBuffer("dataitem"),
                    this.arbundles.stringToBuffer("1"),
                    this.arbundles.stringToBuffer(tx.signatureType.toString()),
                    tx.rawOwner,
                    tx.rawTarget,
                    tx.rawAnchor,
                    tx.rawTags,
                    new s2ai_1.default(teeStream)
                ];
                // do *not* await, this needs to process in parallel to the upload process.
                deephash = this.arbundles.deepHash(sigComponents);
            }
            let nextPresent = present.pop();
            // Consume data while there's data to read.
            while(hasData){
                if (this.paused) {
                    yield new Promise((r)=>this.on("resume", ()=>r(undefined)));
                }
                // do not upload data that's already present
                if (nextPresent) {
                    const delta = +nextPresent[0] - offset;
                    if (delta <= this.chunkSize) {
                        const bytesToSkip = nextPresent[1];
                        const data = yield readBytes(bytesToSkip);
                        if (!isTransaction) teeStream.write(data);
                        offset += bytesToSkip;
                        nextPresent = present.pop();
                        chunkID++;
                        totalUploaded += bytesToSkip;
                        continue;
                    }
                }
                const chunk = yield readBytes(this.chunkSize);
                if (!isTransaction) teeStream.write(chunk);
                while(processing.size >= this.batchSize){
                    // get & then remove resolved promise from processing set
                    const [p] = yield Promise.race(processing);
                    processing.delete(p);
                }
                // self-referencing promise
                const promise = (()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                        return yield promiseFactory(chunk, offset, ++chunkID);
                    }))().then((value)=>[
                        promise,
                        value
                    ]);
                processing.add(promise);
                offset += chunk.length;
            }
            if (teeStream) teeStream.end();
            yield Promise.all(processing);
            if (!isTransaction) {
                const hash = yield deephash;
                const sigBytes = Buffer.from((yield this.tokenConfig.getSigner().sign(hash)));
                heldChunk.set(sigBytes, 2); // tx will be the first part of the held chunk.
                yield promiseFactory(heldChunk, 0, 0);
            }
            const finalHeaders = Object.assign({
                "Content-Type": "application/octet-stream"
            }, headers);
            if ((_c = transactionOpts === null || transactionOpts === void 0 ? void 0 : transactionOpts.upload) === null || _c === void 0 ? void 0 : _c.paidBy) finalHeaders[types_1.UploadHeaders.PAID_BY] = transactionOpts.upload.paidBy;
            // potential improvement: write chunks into a file at offsets, instead of individual chunks + doing a concatenating copy
            const finishUpload = yield this.api.post(`/chunks/${this.token}/${id}/-1`, null, {
                headers: finalHeaders,
                timeout: (_e = (_d = this.api.config) === null || _d === void 0 ? void 0 : _d.timeout) !== null && _e !== void 0 ? _e : 40000 * 10
            });
            if (finishUpload.status === 402) {
                const retryAfterHeader = (_f = finishUpload === null || finishUpload === void 0 ? void 0 : finishUpload.headers) === null || _f === void 0 ? void 0 : _f["retry-after"];
                const errorMsg = "402 error: " + finishUpload.data + (retryAfterHeader ? ` - retry after ${retryAfterHeader}s` : "");
                throw new Error(errorMsg);
            }
            // this will throw if the dataItem reconstruction fails
            utils_1.default.checkAndThrow(finishUpload, "Finalising upload", [
                201
            ]);
            // Recover ID
            if (finishUpload.status === 201) {
                throw new Error(finishUpload.data);
            }
            finishUpload.data.verify = utils_1.default.verifyReceipt.bind({}, this.arbundles, finishUpload.data.data);
            this.emit("done", finishUpload);
            return finishUpload;
        });
    }
    get completionPromise() {
        return new Promise((r)=>this.on("done", r));
    }
}
exports.ChunkingUploader = ChunkingUploader; //# sourceMappingURL=chunkingUploader.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/upload.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Uploader = exports.CHUNKING_THRESHOLD = exports.sleep = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
/* eslint-disable no-case-declarations */ const promise_pool_1 = __turbopack_require__("[project]/node_modules/.pnpm/@supercharge+promise-pool@3.2.0/node_modules/@supercharge/promise-pool/dist/index.js [app-route] (ecmascript)");
const arbundles_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/index.js [app-route] (ecmascript)");
const base64url_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const chunkingUploader_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/chunkingUploader.js [app-route] (ecmascript)");
const types_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/types.js [app-route] (ecmascript)");
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
const async_retry_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/async-retry@1.3.3/node_modules/async-retry/lib/index.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)");
const sleep = (ms)=>new Promise((resolve)=>setTimeout(resolve, ms));
exports.sleep = sleep;
exports.CHUNKING_THRESHOLD = 50000000;
// eslint-disable-next-line @typescript-eslint/naming-convention
class Uploader {
    constructor(api, utils, token, tokenConfig, irysTransaction){
        this.api = api;
        this.token = token;
        this.tokenConfig = tokenConfig;
        this.arbundles = this.tokenConfig.irys.arbundles;
        this.utils = utils;
        this.irysTransaction = irysTransaction;
    }
    uploadTransaction(transaction, opts) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            let res;
            const isDataItem = this.arbundles.DataItem.isDataItem(transaction);
            if (this.forceUseChunking || isDataItem && transaction.getRaw().length >= exports.CHUNKING_THRESHOLD || !isDataItem) {
                res = yield this.chunkedUploader.uploadTransaction(isDataItem ? transaction.getRaw() : transaction, opts);
            } else {
                const { url, timeout, headers: confHeaders } = this.api.getConfig();
                const headers = Object.assign({
                    "Content-Type": "application/octet-stream"
                }, confHeaders);
                if (opts === null || opts === void 0 ? void 0 : opts.paidBy) headers[types_1.UploadHeaders.PAID_BY] = opts.paidBy;
                res = yield this.api.post(new URL(`/tx/${this.token}`, url).toString(), transaction.getRaw(), {
                    headers: headers,
                    timeout,
                    maxBodyLength: Infinity
                });
                if (res.status === 201) {
                    throw new Error(res.data);
                }
            }
            switch(res.status){
                case 402:
                    const retryAfterHeader = (_a = res === null || res === void 0 ? void 0 : res.headers) === null || _a === void 0 ? void 0 : _a["retry-after"];
                    const errorMsg = "402 error: " + res.data + (retryAfterHeader ? ` - retry after ${retryAfterHeader}s` : "");
                    throw new Error(errorMsg);
                default:
                    if (res.status >= 400) {
                        throw new Error(`whilst uploading Irys transaction: ${res.status} ${(0, utils_1.httpErrData)(res)}`);
                    }
            }
            res.data.verify = ()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    return this.utils.verifyReceipt(res.data);
                });
            return res;
        });
    }
    uploadData(data, opts) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (typeof data === "string") {
                data = Buffer.from(data);
            }
            if (Buffer.isBuffer(data)) {
                if (data.length <= exports.CHUNKING_THRESHOLD) {
                    const dataItem = this.arbundles.createData(data, this.tokenConfig.getSigner(), Object.assign(Object.assign({}, opts), {
                        anchor: (_a = opts === null || opts === void 0 ? void 0 : opts.anchor) !== null && _a !== void 0 ? _a : (0, crypto_1.randomBytes)(32).toString("base64").slice(0, 32)
                    }));
                    yield dataItem.sign(this.tokenConfig.getSigner());
                    return (yield this.uploadTransaction(dataItem, Object.assign({}, opts === null || opts === void 0 ? void 0 : opts.upload))).data;
                }
            }
            return (yield this.chunkedUploader.uploadData(data, opts)).data;
        });
    }
    // concurrently uploads transactions
    concurrentUploader(data, opts) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const errors = [];
            const logFn = (opts === null || opts === void 0 ? void 0 : opts.logFunction) ? opts === null || opts === void 0 ? void 0 : opts.logFunction : (_)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    return;
                });
            const concurrency = (_a = opts === null || opts === void 0 ? void 0 : opts.concurrency) !== null && _a !== void 0 ? _a : 5;
            const results = yield promise_pool_1.PromisePool.for(data).withConcurrency(concurrency >= 1 ? concurrency : 5).handleError((error, _, pool)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    errors.push(error);
                    if (error.message.includes("402 error")) {
                        pool.stop();
                        throw error;
                    }
                })).process((item, i)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    yield (0, async_retry_1.default)((bail)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                            try {
                                const res = yield this.processItem(item, opts === null || opts === void 0 ? void 0 : opts.itemOptions);
                                if (i % concurrency == 0) {
                                    yield logFn(`Processed ${i} Items`);
                                }
                                if (opts === null || opts === void 0 ? void 0 : opts.resultProcessor) {
                                    return yield opts.resultProcessor({
                                        item,
                                        res,
                                        i
                                    });
                                } else {
                                    return {
                                        item,
                                        res,
                                        i
                                    };
                                }
                            } catch (e) {
                                if (e === null || e === void 0 ? void 0 : e.message.includes("402 error")) {
                                    bail(e);
                                }
                                throw e;
                            }
                        }), {
                        retries: 3,
                        minTimeout: 1000,
                        maxTimeout: 10000
                    });
                }));
            return {
                errors,
                results: results.results
            };
        });
    }
    processItem(data, opts) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (this.arbundles.DataItem.isDataItem(data)) {
                return this.uploadTransaction(data, Object.assign({}, opts === null || opts === void 0 ? void 0 : opts.upload));
            }
            return this.uploadData(data, opts);
        });
    }
    /**
     * geneates a manifest JSON object
     * @param config.items mapping of logical paths to item IDs
     * @param config.indexFile optional logical path of the index file for the manifest
     * @returns
     */ generateManifest(config) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const { items, indexFile } = config;
            const manifest = {
                manifest: "arweave/paths",
                version: "0.1.0",
                paths: {}
            };
            if (indexFile) {
                if (!items.has(indexFile)) {
                    throw new Error(`Unable to access item: ${indexFile}`);
                }
                manifest.index = {
                    path: indexFile
                };
            }
            for (const [k, v] of items.entries()){
                // @ts-expect-error constant index type
                manifest.paths[k] = {
                    id: v
                };
            }
            return manifest;
        });
    }
    get chunkedUploader() {
        return new chunkingUploader_1.ChunkingUploader(this.tokenConfig, this.api);
    }
    set useChunking(state) {
        if (typeof state === "boolean") {
            this.forceUseChunking = state;
        }
    }
    set contentType(type) {
        // const fullType = mime.contentType(type)
        // if(!fullType){
        //     throw new Error("Invali")
        // }
        this.contentTypeOverride = type;
    }
    uploadBundle(transactions, opts) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const throwawayKey = (_a = opts === null || opts === void 0 ? void 0 : opts.throwawayKey) !== null && _a !== void 0 ? _a : yield this.arbundles.getCryptoDriver().generateJWK();
            const ephemeralSigner = new arbundles_1.ArweaveSigner(throwawayKey);
            const txs = transactions.map((tx)=>this.arbundles.DataItem.isDataItem(tx) ? tx : this.arbundles.createData(tx, ephemeralSigner));
            const bundle = yield this.arbundles.bundleAndSignData(txs, ephemeralSigner);
            // upload bundle with bundle specific tags, use actual signer for this.
            const tx = this.arbundles.createData(bundle.getRaw(), this.tokenConfig.getSigner(), {
                tags: [
                    {
                        name: "Bundle-Format",
                        value: "binary"
                    },
                    {
                        name: "Bundle-Version",
                        value: "2.0.0"
                    }
                ]
            });
            yield tx.sign(this.tokenConfig.getSigner());
            const res = yield this.uploadTransaction(tx, opts);
            const throwawayKeyAddress = (0, base64url_1.default)(Buffer.from((yield this.arbundles.getCryptoDriver().hash(base64url_1.default.toBuffer((0, base64url_1.default)(ephemeralSigner.publicKey))))));
            return Object.assign(Object.assign({}, res), {
                txs,
                throwawayKey,
                throwawayKeyAddress
            });
        });
    }
}
exports.Uploader = Uploader;
exports.default = Uploader; //# sourceMappingURL=upload.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/upload.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.NodeUploader = exports.checkPath = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const fs_1 = __turbopack_require__("[externals]/fs [external] (fs, cjs)");
const upload_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/upload.js [app-route] (ecmascript)"));
const mime_types_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/mime-types@2.1.35/node_modules/mime-types/index.js [app-route] (ecmascript)"));
const inquirer_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/inquirer@8.2.6/node_modules/inquirer/lib/inquirer.js [app-route] (ecmascript)"));
const stream_1 = __turbopack_require__("[externals]/stream [external] (stream, cjs)");
const path_1 = __turbopack_require__("[externals]/path [external] (path, cjs)");
const csv_parse_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/csv-parse@4.16.3/node_modules/csv-parse/lib/index.js [app-route] (ecmascript)"));
const csv_stringify_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/csv-stringify@5.6.5/node_modules/csv-stringify/lib/index.js [app-route] (ecmascript)"));
const checkPath = (path)=>tslib_1.__awaiter(void 0, void 0, void 0, function*() {
        return fs_1.promises.stat(path).then((_)=>true).catch((_)=>false);
    });
exports.checkPath = checkPath;
class NodeUploader extends upload_1.default {
    constructor(api, utils, token, tokenConfig, irysTx){
        super(api, utils, token, tokenConfig, irysTx);
    }
    /**
     * Uploads a file to the bundler
     * @param path to the file to be uploaded
     * @returns the response from the bundler
     */ uploadFile(path, opts) {
        var _a, _b;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!(yield fs_1.promises.stat(path).then((_)=>true).catch((_)=>false))) {
                throw new Error(`Unable to access path: ${path}`);
            }
            // don't add Content-type tag if it already exists
            const hasContentTypeTag = (opts === null || opts === void 0 ? void 0 : opts.tags) && opts.tags.some((t)=>t.name.toLowerCase() === "content-type");
            const mimeType = mime_types_1.default.contentType(mime_types_1.default.lookup(path) || "application/octet-stream");
            (opts !== null && opts !== void 0 ? opts : opts = {}).tags = hasContentTypeTag ? opts.tags : [
                {
                    name: "Content-Type",
                    value: (_a = this.contentTypeOverride) !== null && _a !== void 0 ? _a : mimeType
                },
                ...(_b = opts === null || opts === void 0 ? void 0 : opts.tags) !== null && _b !== void 0 ? _b : []
            ];
            const data = (0, fs_1.createReadStream)(path);
            return yield this.uploadData(data, opts);
        });
    }
    walk(dir) {
        return tslib_1.__asyncGenerator(this, arguments, function* walk_1() {
            var _a, e_1, _b, _c;
            try {
                for(var _d = true, _e = tslib_1.__asyncValues((yield tslib_1.__await(fs_1.promises.opendir(dir)))), _f; _f = yield tslib_1.__await(_e.next()), _a = _f.done, !_a; _d = true){
                    _c = _f.value;
                    _d = false;
                    const d = _c;
                    const entry = (0, path_1.join)(dir, d.name);
                    if (d.isDirectory()) yield tslib_1.__await((yield* tslib_1.__asyncDelegator(tslib_1.__asyncValues((yield tslib_1.__await(this.walk(entry)))))));
                    else if (d.isFile()) yield yield tslib_1.__await(entry);
                }
            } catch (e_1_1) {
                e_1 = {
                    error: e_1_1
                };
            } finally{
                try {
                    if (!_d && !_a && (_b = _e.return)) yield tslib_1.__await(_b.call(_e));
                } finally{
                    if (e_1) throw e_1.error;
                }
            }
        });
    }
    /**
     * Preprocessor for folder uploads, ensures the rest of the system has a correct operating environment.
     * @param path - path to the folder to be uploaded
     * @param indexFile - path to the index file (i.e index.html)
     * @param batchSize - number of items to upload concurrently
     * @param interactivePreflight - whether to interactively prompt the user for confirmation of upload (CLI ONLY)
     * @param keepDeleted - Whether to keep previously uploaded (but now deleted) files in the manifest
     * @param logFunction - for handling logging from the uploader for UX
     * @returns
     */ // eslint-disable-next-line @typescript-eslint/ban-types
    uploadFolder(path, { batchSize = 10, keepDeleted = true, indexFile, interactivePreflight, logFunction, manifestTags, itemOptions } = {
        batchSize: 10,
        keepDeleted: true
    }) {
        var _a, e_2, _b, _c, _d, e_3, _e, _f;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            path = (0, path_1.resolve)(path);
            const alreadyProcessed = new Map();
            const receiptTxs = new Map();
            if (!(yield (0, exports.checkPath)(path))) {
                throw new Error(`Unable to access path: ${path}`);
            }
            // fallback to console.log if no logging function is given and interactive preflight is on.
            if (!logFunction && interactivePreflight) {
                logFunction = (log)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                        console.log(log);
                    });
            } else if (!logFunction) {
                // blackhole logs
                logFunction = (_)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                        return;
                    });
            }
            // manifest with folder name placed in parent directory of said folder - keeps contamination down.
            const manifestPath = (0, path_1.join)((0, path_1.join)(path, `${path_1.sep}..`), `${(0, path_1.basename)(path)}-manifest.csv`);
            const csvHeader = "path,id,receipt\n";
            if (yield (0, exports.checkPath)(manifestPath)) {
                const rstrm = (0, fs_1.createReadStream)(manifestPath);
                // check if empty
                if ((yield fs_1.promises.stat(manifestPath)).size === 0) {
                    yield fs_1.promises.writeFile(manifestPath, csvHeader);
                }
                // validate header
                yield new Promise((res)=>{
                    (0, fs_1.createReadStream)(manifestPath).once("data", (d)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                            const fl = d.toString().split("\n")[0];
                            if (`${fl}\n` !== csvHeader) {
                                yield fs_1.promises.writeFile(manifestPath, csvHeader);
                            }
                            res(d);
                        }));
                });
                const csvStream = stream_1.Readable.from(rstrm.pipe((0, csv_parse_1.default)({
                    delimiter: ",",
                    columns: true
                })));
                try {
                    for(var _g = true, csvStream_1 = tslib_1.__asyncValues(csvStream), csvStream_1_1; csvStream_1_1 = yield csvStream_1.next(), _a = csvStream_1_1.done, !_a; _g = true){
                        _c = csvStream_1_1.value;
                        _g = false;
                        const record = _c;
                        record;
                        if (record.path && record.id) {
                            alreadyProcessed.set(record.path, record.id);
                            receiptTxs.set(record.path, JSON.parse(record.receipt));
                        }
                    }
                } catch (e_2_1) {
                    e_2 = {
                        error: e_2_1
                    };
                } finally{
                    try {
                        if (!_g && !_a && (_b = csvStream_1.return)) yield _b.call(csvStream_1);
                    } finally{
                        if (e_2) throw e_2.error;
                    }
                }
            } else {
                yield fs_1.promises.writeFile(manifestPath, csvHeader);
            }
            const files = [];
            let total = 0;
            let i = 0;
            try {
                for(var _h = true, _j = tslib_1.__asyncValues(this.walk(path)), _k; _k = yield _j.next(), _d = _k.done, !_d; _h = true){
                    _f = _k.value;
                    _h = false;
                    const f = _f;
                    const relPath = (0, path_1.relative)(path, f);
                    if (!alreadyProcessed.has(relPath)) {
                        files.push(f);
                        total += (yield fs_1.promises.stat(f)).size;
                    } else {
                        alreadyProcessed.delete(relPath);
                    }
                    if (++i % batchSize == 0) {
                        logFunction(`Checked ${i} files...`);
                    }
                }
            } catch (e_3_1) {
                e_3 = {
                    error: e_3_1
                };
            } finally{
                try {
                    if (!_h && !_d && (_e = _j.return)) yield _e.call(_j);
                } finally{
                    if (e_3) throw e_3.error;
                }
            }
            if (!keepDeleted) {
                alreadyProcessed.clear();
            }
            // pass as param otherwise it thinks logFunction can be undef
            const uploadManifest = (logFunction)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    // generate JSON
                    yield logFunction("Generating JSON manifest...");
                    const jsonManifestPath = yield this.generateManifestFromCsv(path, alreadyProcessed, indexFile);
                    // upload the manifest
                    yield logFunction("Uploading JSON manifest...");
                    const tags = [
                        {
                            name: "Type",
                            value: "manifest"
                        },
                        {
                            name: "Content-Type",
                            value: "application/x.arweave-manifest+json"
                        },
                        ...manifestTags !== null && manifestTags !== void 0 ? manifestTags : []
                    ];
                    const mres = yield this.uploadData((0, fs_1.createReadStream)(jsonManifestPath), {
                        tags
                    }).catch((e)=>{
                        throw new Error(`Failed to upload manifest: ${e.message}`);
                    });
                    yield logFunction("Done!");
                    if (mres === null || mres === void 0 ? void 0 : mres.id) {
                        yield fs_1.promises.writeFile((0, path_1.join)((0, path_1.join)(path, `${path_1.sep}..`), `${(0, path_1.basename)(path)}-id.txt`), JSON.stringify(mres));
                    } else {
                        throw new Error(`Unable to get upload ID! ${JSON.stringify(mres)}`);
                    }
                    return mres;
                });
            // TODO: add logic to detect changes (MD5/other hash)
            if (files.length == 0 && alreadyProcessed.size === 0) {
                logFunction("No items to process");
                // return the txID of the upload
                const idpath = (0, path_1.join)((0, path_1.join)(path, `${path_1.sep}..`), `${(0, path_1.basename)(path)}-id.txt`);
                if (yield (0, exports.checkPath)(idpath)) {
                    return JSON.parse((yield fs_1.promises.readFile(idpath, "utf-8")));
                }
                // assume manifest wasn't uploaded
                return yield uploadManifest(logFunction);
            }
            // const zprice = (await this.utils.getPrice(this.currency, 0)).multipliedBy(files.length);
            // const price = (await this.utils.getPrice(this.currency, total)).plus(zprice).toFixed(0);
            const price = yield this.utils.estimateFolderPrice({
                fileCount: files.length,
                totalBytes: total
            });
            if (interactivePreflight) {
                if (!(yield confirmation(`Authorize upload?\nTotal amount of data: ${total} bytes over ${files.length} files - cost: ${price} ${this.tokenConfig.base[0]} (${this.utils.fromAtomic(price).toFixed()} ${this.token})\n Y / N`))) {
                    throw new Error("Confirmation failed");
                }
            }
            const stringifier = (0, csv_stringify_1.default)({
                header: false,
                columns: {
                    path: "path",
                    id: "id",
                    receipt: "receipt"
                }
            });
            const wstrm = (0, fs_1.createWriteStream)(manifestPath, {
                flags: "a+"
            });
            stringifier.pipe(wstrm);
            const processor = (data)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    var _l;
                    if ((_l = data === null || data === void 0 ? void 0 : data.res) === null || _l === void 0 ? void 0 : _l.id) {
                        const receipt = data.res.signature ? {
                            id: data.res.id,
                            block: data.res.block,
                            deadlineHeight: data.res.deadlineHeight,
                            public: data.res.public,
                            signature: data.res.signature,
                            timestamp: data.res.timestamp,
                            validatorSignatures: data.res.validatorSignatures,
                            version: data.res.version
                        } : {};
                        receiptTxs.set((0, path_1.relative)(path, data.item), receipt);
                        stringifier.write([
                            (0, path_1.relative)(path, data.item),
                            data.res.id,
                            JSON.stringify(receipt)
                        ]);
                    }
                });
            const processingResults = yield this.concurrentUploader(files, {
                concurrency: batchSize,
                resultProcessor: processor,
                logFunction,
                itemOptions
            });
            if (processingResults.errors.length > 0) {
                yield logFunction(`${processingResults.errors.length} Errors detected, skipping manifest upload...`);
                const ewstrm = (0, fs_1.createWriteStream)((0, path_1.join)((0, path_1.join)(path, `${path_1.sep}..`), `${(0, path_1.basename)(path)}-errors.txt`), {
                    flags: "a+"
                });
                ewstrm.write(`Errors from upload at ${new Date().toString()}:\n`);
                processingResults.errors.forEach((e)=>{
                    var _a;
                    return ewstrm.write(`${(_a = e === null || e === void 0 ? void 0 : e.stack) !== null && _a !== void 0 ? _a : JSON.stringify(e)}\n`);
                });
                yield new Promise((res)=>ewstrm.close(res));
                throw new Error(`${processingResults.errors.length} Errors detected - check ${(0, path_1.basename)(path)}-errors.txt for more information.`);
            }
            yield logFunction(`Finished processing ${files.length} Items`);
            yield new Promise((r)=>wstrm.close(r));
            return yield uploadManifest(logFunction);
        });
    }
    /**
     * processes an item to convert it into a DataItem, and then uploads it.
     * @param item can be a string value, a path to a file, a Buffer of data or a DataItem
     * @returns A dataItem
     */ processItem(item, opts) {
        var _a, _b;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (this.arbundles.DataItem.isDataItem(item)) {
                return this.uploadTransaction(item, Object.assign({}, opts === null || opts === void 0 ? void 0 : opts.upload));
            }
            let tags;
            if (typeof item === "string") {
                if (yield (0, exports.checkPath)(item)) {
                    const mimeType = mime_types_1.default.contentType(mime_types_1.default.lookup(item) || "application/octet-stream");
                    tags = [
                        {
                            name: "Content-Type",
                            value: (_a = this.contentTypeOverride) !== null && _a !== void 0 ? _a : mimeType
                        }
                    ];
                    // returnVal = item;
                    item = (0, fs_1.createReadStream)(item);
                } else {
                    item = Buffer.from(item);
                    if (this.contentTypeOverride) {
                        tags = [
                            {
                                name: "Content-Type",
                                value: this.contentTypeOverride
                            }
                        ];
                    }
                }
            }
            return this.uploadData(item, Object.assign(Object.assign({}, opts), {
                tags: [
                    ...tags,
                    ...(_b = opts === null || opts === void 0 ? void 0 : opts.tags) !== null && _b !== void 0 ? _b : []
                ]
            }));
        });
    }
    /**
     * Stream-based CSV parser and JSON assembler
     * @param path base path of the upload
     * @param indexFile optional path to an index file
     * @returns the path to the generated manifest
     */ generateManifestFromCsv(path, nowRemoved, indexFile) {
        var _a, e_4, _b, _c;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const csvstrm = (0, csv_parse_1.default)({
                delimiter: ",",
                columns: true
            });
            const csvPath = (0, path_1.join)((0, path_1.join)(path, `${path_1.sep}..`), `${(0, path_1.basename)(path)}-manifest.csv`);
            const manifestPath = (0, path_1.join)((0, path_1.join)(path, `${path_1.sep}..`), `${(0, path_1.basename)(path)}-manifest.json`);
            const wstrm = (0, fs_1.createWriteStream)(manifestPath, {
                flags: "w+"
            });
            (0, fs_1.createReadStream)(csvPath).pipe(csvstrm); // pipe csv
            /* eslint-disable quotes */ // "header"
            wstrm.write(`{\n"manifest": "arweave/paths",\n"version": "0.1.0",\n"paths": {\n`);
            const csvs = stream_1.Readable.from(csvstrm);
            let firstValue = true;
            try {
                for(var _d = true, csvs_1 = tslib_1.__asyncValues(csvs), csvs_1_1; csvs_1_1 = yield csvs_1.next(), _a = csvs_1_1.done, !_a; _d = true){
                    _c = csvs_1_1.value;
                    _d = false;
                    const d = _c;
                    if (nowRemoved === null || nowRemoved === void 0 ? void 0 : nowRemoved.has(d.path)) {
                        nowRemoved.delete(d.path);
                        continue;
                    }
                    const prefix = firstValue ? "" : ",\n";
                    wstrm.write(`${prefix}"${d.path.replaceAll("\\", "/")}":{"id":"${d.id}"}`);
                    firstValue = false;
                }
            } catch (e_4_1) {
                e_4 = {
                    error: e_4_1
                };
            } finally{
                try {
                    if (!_d && !_a && (_b = csvs_1.return)) yield _b.call(csvs_1);
                } finally{
                    if (e_4) throw e_4.error;
                }
            }
            // "trailer"
            wstrm.write(`\n}`);
            // add index
            if (indexFile) {
                wstrm.write(`,\n"index":{"path":"${indexFile.replaceAll("\\", "/")}"}`);
            }
            wstrm.write(`\n}`);
            yield new Promise((r)=>wstrm.close(r));
            return manifestPath;
        });
    }
}
exports.NodeUploader = NodeUploader;
function confirmation(message) {
    return tslib_1.__awaiter(this, void 0, void 0, function*() {
        const answers = yield inquirer_1.default.prompt([
            {
                type: "input",
                name: "confirmation",
                message
            }
        ]);
        return answers.confirmation.toLowerCase() == "y";
    });
}
exports.default = NodeUploader; //# sourceMappingURL=upload.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Arweave = exports.bundleAndSignData = exports.getCryptoDriver = exports.stringToBuffer = exports.deepHash = exports.DataItem = exports.createData = void 0;
const node_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/index.js [app-route] (ecmascript)");
Object.defineProperty(exports, "createData", {
    enumerable: true,
    get: function() {
        return node_1.createData;
    }
});
Object.defineProperty(exports, "DataItem", {
    enumerable: true,
    get: function() {
        return node_1.DataItem;
    }
});
Object.defineProperty(exports, "deepHash", {
    enumerable: true,
    get: function() {
        return node_1.deepHash;
    }
});
Object.defineProperty(exports, "stringToBuffer", {
    enumerable: true,
    get: function() {
        return node_1.stringToBuffer;
    }
});
Object.defineProperty(exports, "getCryptoDriver", {
    enumerable: true,
    get: function() {
        return node_1.getCryptoDriver;
    }
});
Object.defineProperty(exports, "bundleAndSignData", {
    enumerable: true,
    get: function() {
        return node_1.bundleAndSignData;
    }
});
Object.defineProperty(exports, "Arweave", {
    enumerable: true,
    get: function() {
        return node_1.Arweave;
    }
}); //# sourceMappingURL=utils.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/provenance.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Provenance = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
class Provenance {
    constructor(irys){
        this.irys = irys;
    }
    upload(data, opts) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.irys.uploadWithReceipt(data, opts);
        });
    }
    uploadProof(proofFields) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return yield this.irys.uploadWithReceipt("", {
                tags: Object.entries(Object.assign({
                    dataProtocol: "Provenance-Confirmation"
                }, proofFields)).map(([k, v])=>({
                        name: tagMap[k],
                        value: v
                    }))
            });
        });
    }
    getAllProofs(searchBy, opts) {
        var _a, _b, _c;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const queryTags = Object.entries(searchBy).map(([k, v])=>({
                    name: tagMap[k],
                    values: [
                        v
                    ]
                }));
            if (queryTags.length === 0) throw new Error(`Getting a provenance proof requires at least one query element`);
            const query = `
    query ($tags: [TagFilter!]) {
      transactions(tags: $tags) {
        edges {
          node {
            id
            receipt {
              deadlineHeight
              signature
              timestamp
              version
            }
            tags {
              name
              value
            }
          }
        }
      }
    }
    `;
            const txs = [];
            let endCursor = null;
            do {
                const gqlRes = yield this.irys.api.post("/graphql", {
                    query,
                    variables: {
                        tags: queryTags,
                        limit: (_a = opts === null || opts === void 0 ? void 0 : opts.limit) !== null && _a !== void 0 ? _a : null,
                        after: endCursor
                    }
                }, undefined);
                endCursor = ((_c = (_b = gqlRes.data.data.transactions) === null || _b === void 0 ? void 0 : _b.pageInfo) === null || _c === void 0 ? void 0 : _c.hasNextPage) ? gqlRes.data.data.transactions.pageInfo.endCursor : null;
                txs.push(...gqlRes.data.data.transactions.edges.map((t)=>t.node));
            }while (endCursor)
            return txs;
        });
    }
    getProof(searchBy) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const res = (yield this.getAllProofs(searchBy, {
                limit: 1
            })).at(0);
            if (!res) throw new Error(`Unable to locate proof with fields ${JSON.stringify(searchBy)}`);
            return res;
        });
    }
}
exports.Provenance = Provenance;
const tagMap = {
    dataProtocol: "Data-Protocol",
    hashingAlgo: "Hashing-Algo",
    dataHash: "Data-Hash",
    uploadedFor: "Uploaded-For",
    prompt: "Prompt",
    promptHash: "Prompt-Hash",
    model: "Model"
}; //# sourceMappingURL=provenance.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/provenance.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.NodeProvenance = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const provenance_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/provenance.js [app-route] (ecmascript)");
class NodeProvenance extends provenance_1.Provenance {
    constructor(irys){
        super(irys);
    }
    uploadFile(path, opts) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.irys.uploadFile(path, Object.assign(Object.assign({}, opts), {
                upload: Object.assign({}, opts === null || opts === void 0 ? void 0 : opts.upload)
            }));
        });
    }
    uploadFolder(path, { batchSize = 10, keepDeleted = true, indexFile, interactivePreflight, logFunction, manifestTags, itemOptions } = {
        batchSize: 10,
        keepDeleted: true
    }) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.irys.uploadFolder(path, {
                batchSize,
                keepDeleted,
                indexFile,
                interactivePreflight,
                logFunction,
                manifestTags,
                itemOptions: Object.assign(Object.assign({}, itemOptions), {
                    upload: Object.assign({}, itemOptions === null || itemOptions === void 0 ? void 0 : itemOptions.upload)
                })
            });
        });
    }
}
exports.NodeProvenance = NodeProvenance; //# sourceMappingURL=provenance.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/approval.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.UploadApprovalMetaTags = exports.UploadApprovalTags = exports.Approval = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const utils_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)"));
class Approval {
    constructor(irys){
        this.irys = irys;
    }
    getApprovals({ payingAddresses, tokens = [
        this.irys.token
    ], approvedAddresses = [
        this.irys.address
    ] }) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.queryApproval.payingAddresses(payingAddresses).tokens(tokens).approvedAddresses(approvedAddresses);
        });
    }
    getCreatedApprovals({ payingAddresses = [
        this.irys.address
    ], tokens = [
        this.irys.token
    ], approvedAddresses }) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.queryApproval.payingAddresses(payingAddresses).tokens(tokens).approvedAddresses(approvedAddresses);
        });
    }
    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
    get queryApproval() {
        return this.irys.query().search("irys:paymentApprovals");
    }
    getApproval({ payingAddress = this.irys.address, token = this.irys.token, approvedAddress }) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const res = yield this.irys.api.get("/account/approval", {
                params: {
                    payingAddress,
                    token,
                    approvedAddress
                }
            });
            if (res.status === 404) return {
                amount: "0"
            };
            utils_1.default.checkAndThrow(res);
            return res.data;
        });
    }
    getApprovedBalanceFrom(payingAddress) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!payingAddress) throw new Error("Paying address is required");
            return yield this.getApproval({
                payingAddress,
                approvedAddress: this.irys.address,
                token: this.irys.token
            });
        });
    }
    createApproval({ approvedAddress, amount, expiresInSeconds }) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const tags = [
                {
                    name: UploadApprovalTags.APPROVE_PAYMENT,
                    value: approvedAddress
                },
                {
                    name: UploadApprovalMetaTags.AMOUNT,
                    value: amount.toString()
                }
            ];
            if (expiresInSeconds) tags.push({
                name: UploadApprovalMetaTags.EXPIRE_SECONDS,
                value: expiresInSeconds.toString()
            });
            return yield this.irys.upload("", {
                tags
            });
        });
    }
    revokeApproval({ approvedAddress }) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const tags = [
                {
                    name: UploadApprovalTags.DELETE_APPROVAL,
                    value: approvedAddress
                }
            ];
            return yield this.irys.upload("", {
                tags
            });
        });
    }
}
exports.Approval = Approval;
var UploadApprovalTags;
(function(UploadApprovalTags) {
    UploadApprovalTags["APPROVE_PAYMENT"] = "x-irys-approve-payment";
    UploadApprovalTags["DELETE_APPROVAL"] = "x-irys-delete-payment-approval";
})(UploadApprovalTags || (exports.UploadApprovalTags = UploadApprovalTags = {}));
var UploadApprovalMetaTags;
(function(UploadApprovalMetaTags) {
    UploadApprovalMetaTags["AMOUNT"] = "x-amount";
    UploadApprovalMetaTags["EXPIRE_SECONDS"] = "x-expire-seconds";
})(UploadApprovalMetaTags || (exports.UploadApprovalMetaTags = UploadApprovalMetaTags = {})); //# sourceMappingURL=approval.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/base.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseNodeIrys = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/hack.js [app-route] (ecmascript)");
const transactions_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/transactions.js [app-route] (ecmascript)");
const api_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/api.js [app-route] (ecmascript)"));
const fund_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/fund.js [app-route] (ecmascript)"));
const irys_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/irys.js [app-route] (ecmascript)"));
const utils_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)"));
const upload_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/upload.js [app-route] (ecmascript)"));
const arbundles = tslib_1.__importStar(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/utils.js [app-route] (ecmascript)"));
const provenance_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/provenance.js [app-route] (ecmascript)");
const approval_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/approval.js [app-route] (ecmascript)");
class BaseNodeIrys extends irys_1.default {
    /**
     * Constructs a new Irys instance, as well as supporting subclasses
     * @param url - URL to the bundler
     * @param key - private key (in whatever form required)
     */ constructor({ url, network, config, getTokenConfig }){
        var _a, _b;
        super({
            url,
            network,
            arbundles
        });
        this.debug = (_a = config === null || config === void 0 ? void 0 : config.debug) !== null && _a !== void 0 ? _a : false;
        this.api = new api_1.default({
            url: this.url,
            timeout: (_b = config === null || config === void 0 ? void 0 : config.timeout) !== null && _b !== void 0 ? _b : 100000,
            headers: config === null || config === void 0 ? void 0 : config.headers
        });
        this.tokenConfig = getTokenConfig(this);
        if (this.url.host.includes("devnet.irys.xyz") && !(config === null || config === void 0 ? void 0 : config.providerUrl)) throw new Error(`Using ${this.url.host} requires a dev/testnet RPC to be configured! see https://docs.irys.xyz/developer-docs/using-devnet`);
        this.token = this.tokenConfig.name;
        this.address = this.tokenConfig.address;
        this.utils = new utils_1.default(this.api, this.token, this.tokenConfig);
        this.funder = new fund_1.default(this.utils);
        this.uploader = new upload_1.default(this.api, this.utils, this.token, this.tokenConfig, this.IrysTransaction);
        this.provenance = new provenance_1.NodeProvenance(this);
        this.transactions = new transactions_1.Transaction(this);
        this.approval = new approval_1.Approval(this);
        this._readyPromise = this.tokenConfig.ready ? this.tokenConfig.ready() : new Promise((r)=>r());
    }
    /**
     * Upload a file at the specified path to the bundler
     * @param path path to the file to upload
     * @returns bundler response
     */ uploadFile(path, opts) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.uploader.uploadFile(path, opts);
        });
    }
    /**
     * @param path - path to the folder to be uploaded
     * @param indexFile - path to the index file (i.e index.html)
     * @param batchSize - number of items to upload concurrently
     * @param interactivePreflight - whether to interactively prompt the user for confirmation of upload (CLI ONLY)
     * @param keepDeleted - Whether to keep previously uploaded (but now deleted) files in the manifest
     * @param logFunction - for handling logging from the uploader for UX
     * @param manifestTags - For allowing the caller to pass tags that will be added to the manifest transaction.
     * @returns
     */ uploadFolder(path, { batchSize = 10, keepDeleted = true, indexFile, interactivePreflight, logFunction, manifestTags, itemOptions } = {}) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.uploader.uploadFolder(path, {
                indexFile,
                batchSize,
                interactivePreflight,
                keepDeleted,
                logFunction,
                manifestTags,
                itemOptions
            });
        });
    }
}
exports.BaseNodeIrys = BaseNodeIrys;
exports.default = BaseNodeIrys; //# sourceMappingURL=base.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/base.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getRedstonePrice = exports.BaseNodeToken = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const axios_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/axios@1.7.9/node_modules/axios/dist/node/axios.cjs [app-route] (ecmascript)"));
const utils_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)"));
class BaseNodeToken {
    constructor(config){
        this.minConfirm = 5;
        this.isSlow = false;
        this.needsFee = true;
        Object.assign(this, config);
        this._address = this.wallet ? this.ownerToAddress(this.getPublicKey()) : undefined;
    }
    // common methods
    get address() {
        return this._address;
    }
    price() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return getRedstonePrice(this.ticker);
        });
    }
}
exports.BaseNodeToken = BaseNodeToken;
function getRedstonePrice(token) {
    return tslib_1.__awaiter(this, void 0, void 0, function*() {
        const res = yield axios_1.default.get(`https://api.redstone.finance/prices?symbol=${token}&provider=redstone&limit=1`);
        yield utils_1.default.checkAndThrow(res, "Getting price data");
        return res.data[0].value;
    });
}
exports.getRedstonePrice = getRedstonePrice; //# sourceMappingURL=base.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/arweave.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const arbundles_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/index.js [app-route] (ecmascript)");
const base64url_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const crypto_1 = tslib_1.__importDefault(__turbopack_require__("[externals]/crypto [external] (crypto, cjs)"));
const base_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/base.js [app-route] (ecmascript)");
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/utils.js [app-route] (ecmascript)");
class ArweaveConfig extends base_1.BaseNodeToken {
    constructor(config){
        super(config);
        this.base = [
            "winston",
            1e12
        ];
        this.needsFee = true;
    }
    getProvider() {
        var _a, _b;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.providerInstance) {
                const purl = new URL((_a = this.providerUrl) !== null && _a !== void 0 ? _a : "https://arweave.net");
                // this.providerInstance = Arweave.init({
                //   host: purl.hostname,
                //   protocol: purl.protocol.replaceAll(":", "").replaceAll("/", ""),
                //   port: purl.port,
                //   network: this?.opts?.network,
                // });
                this.providerInstance = new utils_1.Arweave({
                    url: purl,
                    network: (_b = this === null || this === void 0 ? void 0 : this.opts) === null || _b === void 0 ? void 0 : _b.network
                });
            }
            return this.providerInstance;
        });
    }
    getTx(txId) {
        var _a, _b, _c, _d;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const arweave = yield this.getProvider();
            const txs = yield arweave.transactions.getStatus(txId);
            let tx;
            if (txs.status === 200) {
                tx = yield arweave.transactions.get(txId);
            }
            const confirmed = txs.status !== 202 && ((_b = (_a = txs.confirmed) === null || _a === void 0 ? void 0 : _a.number_of_confirmations) !== null && _b !== void 0 ? _b : 0) >= this.minConfirm;
            let owner;
            if (tx === null || tx === void 0 ? void 0 : tx.owner) {
                owner = this.ownerToAddress(tx.owner);
            }
            return {
                from: owner !== null && owner !== void 0 ? owner : undefined,
                to: (_c = tx === null || tx === void 0 ? void 0 : tx.target) !== null && _c !== void 0 ? _c : undefined,
                amount: new bignumber_js_1.default((_d = tx === null || tx === void 0 ? void 0 : tx.quantity) !== null && _d !== void 0 ? _d : 0),
                pending: txs.status === 202,
                confirmed
            };
        });
    }
    ownerToAddress(owner) {
        return utils_1.Arweave.utils.bufferTob64Url(crypto_1.default.createHash("sha256").update(utils_1.Arweave.utils.b64UrlToBuffer(Buffer.isBuffer(owner) ? (0, base64url_1.default)(owner) : owner)).digest());
    }
    sign(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return (yield this.getProvider()).crypto.sign(this.wallet, data);
        });
    }
    getSigner() {
        return new arbundles_1.ArweaveSigner(this.wallet);
    }
    verify(pub, data, signature) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (Buffer.isBuffer(pub)) {
                pub = pub.toString();
            }
            return (yield this.getProvider()).crypto.verify(pub, data, signature);
        });
    }
    getCurrentHeight() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return (yield this.getProvider()).network.getInfo().then((r)=>new bignumber_js_1.default(r.height));
        });
    }
    getFee(_amount, to) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            // amount is the amount of winston being transferred, but arweave prices based on the size of the transaction. so we set size to 0 here
            return new bignumber_js_1.default((yield (yield this.getProvider()).transactions.getPrice(0, to))).integerValue(bignumber_js_1.default.ROUND_CEIL);
        });
    }
    sendTx(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = yield this.getProvider();
            const res = yield provider.transactions.post(data);
            if (res.statusText.includes("Nodes rejected the TX headers")) {
                // check user balance
                const balance = new bignumber_js_1.default((yield provider.wallets.getBalance(this.address)));
                if (balance.isLessThanOrEqualTo(data.quantity)) throw new Error(`${this.address} has a balance of ${balance.toString()} winston, less than the required ${new bignumber_js_1.default(data.reward).plus(data.quantity)}.`);
            }
            return res;
        });
    }
    createTx(amount, to, fee) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const arweave = yield this.getProvider();
            const tx = yield arweave.createTransaction({
                quantity: new bignumber_js_1.default(amount).toString(),
                reward: fee,
                target: to
            }, this.wallet);
            yield arweave.transactions.sign(tx, this.wallet);
            return {
                txId: tx.id,
                tx
            };
        });
    }
    getPublicKey() {
        return this.wallet.n;
    }
}
exports.default = ArweaveConfig; //# sourceMappingURL=arweave.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/ethereum.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const bignumber_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+bignumber@5.7.0/node_modules/@ethersproject/bignumber/lib.esm/index.js [app-route] (ecmascript)");
const providers_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+providers@5.7.2_bufferutil@4.0.9_utf-8-validate@5.0.10/node_modules/@ethersproject/providers/lib.esm/index.js [app-route] (ecmascript)");
const wallet_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+wallet@5.7.0/node_modules/@ethersproject/wallet/lib.esm/index.js [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const arbundles_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/index.js [app-route] (ecmascript)");
const base_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/base.js [app-route] (ecmascript)");
const ethereumSigner = arbundles_1.EthereumSigner;
class EthereumConfig extends base_1.BaseNodeToken {
    constructor(config){
        super(config);
        this.base = [
            "wei",
            1e18
        ];
    }
    getProvider() {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.providerInstance) {
                this.providerInstance = new providers_1.JsonRpcProvider(Object.assign({
                    url: this.providerUrl,
                    skipFetchSetup: true
                }, (_a = this === null || this === void 0 ? void 0 : this.opts) === null || _a === void 0 ? void 0 : _a.providerOptions));
                yield this.providerInstance.ready;
            }
            return this.providerInstance;
        });
    }
    getTx(txId) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = yield this.getProvider();
            const response = yield provider.getTransaction(txId);
            if (!response) throw new Error("Tx doesn't exist");
            if (!response.to) throw new Error(`Unable to determine transaction ${txId} recipient`);
            // console.log(response.confirmations);
            return {
                from: response.from,
                to: response.to,
                blockHeight: response.blockNumber ? new bignumber_js_1.default(response.blockNumber) : undefined,
                amount: new bignumber_js_1.default(response.value.toHexString(), 16),
                pending: response.blockNumber ? false : true,
                confirmed: response.confirmations >= this.minConfirm
            };
        });
    }
    ownerToAddress(owner) {
        return "0x" + (0, arbundles_1.keccak256)(owner.slice(1)).slice(-20).toString("hex");
    }
    sign(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const signer = this.getSigner();
            return signer.sign(data);
        });
    }
    getSigner() {
        return new ethereumSigner(this.wallet);
    }
    verify(pub, data, signature) {
        return ethereumSigner.verify(pub, data, signature);
    }
    getCurrentHeight() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const response = yield (yield this.getProvider()).send("eth_blockNumber", []);
            return new bignumber_js_1.default(response, 16);
        });
    }
    getFee(amount, to) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = yield this.getProvider();
            const _amount = new bignumber_js_1.default(amount);
            const tx = {
                from: this.address,
                to,
                value: "0x" + _amount.toString(16)
            };
            const estimatedGas = yield provider.estimateGas(tx);
            const gasPrice = yield provider.getGasPrice();
            // const b = await provider.send("eth_maxPriorityFeePerGas", [])
            // console.log(b)
            return new bignumber_js_1.default(estimatedGas.mul(gasPrice).toString());
        });
    }
    sendTx(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return yield (yield this.getProvider()).sendTransaction(data).catch((e)=>{
                console.error(`Error occurred while sending a tx - ${e}`);
                throw e;
            });
        });
    }
    createTx(amount, to, fee) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = yield this.getProvider();
            const wallet = new wallet_1.Wallet(this.wallet, provider);
            const _amount = "0x" + new bignumber_js_1.default(amount).toString(16);
            let gasPrice = yield provider.getGasPrice();
            const gasEstimate = fee ? bignumber_1.BigNumber.from(new bignumber_js_1.default(fee).dividedToIntegerBy(gasPrice.toString()).toFixed()) : undefined;
            // const estimatedGas = await provider.estimateGas({ from: this.address, to, value: _amount });
            // console.log({ gasPrice, estimatedGas })
            // if (fee) {
            //     gasPrice = ethers.BigNumber.from(Math.ceil(+fee / estimatedGas.toNumber()))
            // }
            if (this.name === "matic") {
                gasPrice = bignumber_1.BigNumber.from(new bignumber_js_1.default(gasPrice.toString()).multipliedBy(10).decimalPlaces(0).toString());
            }
            const tx = yield wallet.populateTransaction({
                to,
                value: _amount,
                from: this.address,
                gasPrice,
                // gasLimit: estimatedGas,
                gasLimit: gasEstimate
            });
            // tx.gasLimit = ethers.BigNumber.from(+(tx.gasLimit.toString()) * 4)
            const signedTx = yield wallet.signTransaction(tx);
            const txId = "0x" + (0, arbundles_1.keccak256)(Buffer.from(signedTx.slice(2), "hex")).toString("hex");
            // const c = await provider.call(tx);
            // console.log(c)
            return {
                txId,
                tx: signedTx
            };
        });
    }
    getPublicKey() {
        return this.getSigner().publicKey;
    }
}
exports.default = EthereumConfig; //# sourceMappingURL=ethereum.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/erc20.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const contracts_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+contracts@5.7.0/node_modules/@ethersproject/contracts/lib.esm/index.js [app-route] (ecmascript)");
const wallet_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+wallet@5.7.0/node_modules/@ethersproject/wallet/lib.esm/index.js [app-route] (ecmascript)");
const arbundles_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/index.js [app-route] (ecmascript)");
const base_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/base.js [app-route] (ecmascript)");
const ethereum_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/ethereum.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)");
class ERC20Config extends ethereum_1.default {
    constructor(config){
        super(config);
        this.contractAddress = config.contractAddress;
    }
    getContract() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.contractInstance) {
                this.contractInstance = new contracts_1.Contract(this.contractAddress, utils_1.erc20abi, new wallet_1.Wallet(this.wallet, (yield this.getProvider())));
                this.base = [
                    "wei",
                    Math.pow(10, (yield this.contractInstance.decimals()))
                ];
            }
            return this.contractInstance;
        });
    }
    getTx(txId) {
        const _super = Object.create(null, {
            getProvider: {
                get: ()=>super.getProvider
            }
        });
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const response = yield (yield _super.getProvider.call(this)).getTransaction(txId);
            if (!response) throw new Error("Tx doesn't exist");
            if (response.data.length !== 138 || response.data.slice(2, 10) !== "a9059cbb" // standard ERC20-ABI method ID for transfers
            ) {
                throw new Error("Tx isn't a ERC20 transfer");
            }
            const to = `0x${response.data.slice(34, 74)}`;
            const amount = new bignumber_js_1.default(response.data.slice(74), 16);
            return {
                from: response.from,
                to,
                blockHeight: response.blockNumber ? new bignumber_js_1.default(response.blockNumber) : undefined,
                amount,
                pending: response.blockNumber ? false : true,
                confirmed: response.confirmations >= this.minConfirm
            };
        });
    }
    getFee(amount, to) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const _amount = "0x" + new bignumber_js_1.default(amount).toString(16);
            const contract = yield this.getContract();
            const provider = yield this.getProvider();
            const gasPrice = yield provider.getGasPrice();
            const gasLimit = yield contract.estimateGas.transfer(to, _amount);
            const units = new bignumber_js_1.default(gasPrice.mul(gasLimit).toString()); // price in WEI
            return units;
        // below is cost in contract token units for the gas price
        // const [fiatGasPrice] = await this.getGas(); // get price of gas units
        // const value = fiatGasPrice.multipliedBy(units); // value of the fee
        // // convert value
        // const ctPrice = new BigNumber(await this.price()); // price for this token
        // const ctAmount = new BigNumber(value).dividedToIntegerBy(ctPrice);
        // // const b = ctAmount.multipliedBy(ctPrice)
        // // const c = value.dividedBy(this.base[1])
        // // console.log(b);
        // // console.log(c)
        // return ctAmount;
        });
    }
    createTx(amount, to, _fee) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = yield this.getProvider();
            const wallet = new wallet_1.Wallet(this.wallet, provider);
            const contract = yield this.getContract();
            const _amount = "0x" + new bignumber_js_1.default(amount).toString(16);
            const tx = yield contract.populateTransaction.transfer(to, _amount);
            // Needed *specifically* for ERC20
            tx.gasPrice = yield provider.getGasPrice();
            tx.gasLimit = yield contract.estimateGas.transfer(to, _amount);
            tx.chainId = (yield provider.getNetwork()).chainId;
            if (!this.address) throw new Error("Address is undefined - you might be missing a wallet, or have not run Irys.ready()");
            tx.nonce = yield provider.getTransactionCount(this.address);
            const signedTx = yield wallet.signTransaction(tx);
            const txId = "0x" + (0, arbundles_1.keccak256)(Buffer.from(signedTx.slice(2), "hex")).toString("hex");
            return {
                txId,
                tx: signedTx
            };
        });
    }
    // TODO: create a nicer solution than just overrides (larger issue: some currencies aren't on redstone)
    getGas() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return [
                new bignumber_js_1.default((yield (0, base_1.getRedstonePrice)("ETH"))),
                1e18
            ];
        });
    }
}
exports.default = ERC20Config; //# sourceMappingURL=erc20.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/near.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const crypto_1 = __turbopack_require__("[project]/node_modules/.pnpm/@near-js+crypto@0.0.3/node_modules/@near-js/crypto/lib/index.js [app-route] (ecmascript)");
const providers_1 = __turbopack_require__("[project]/node_modules/.pnpm/@near-js+providers@0.0.4_encoding@0.1.13/node_modules/@near-js/providers/lib/index.js [app-route] (ecmascript)");
const borsh_1 = __turbopack_require__("[project]/node_modules/.pnpm/borsh@2.0.0/node_modules/borsh/lib/cjs/index.js [app-route] (ecmascript)");
const arbundles_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/index.js [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const base_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/base.js [app-route] (ecmascript)");
const bs58_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bs58@5.0.0/node_modules/bs58/index.js [app-route] (ecmascript)"));
const bn_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const js_sha256_1 = __turbopack_require__("[project]/node_modules/.pnpm/js-sha256@0.9.0/node_modules/js-sha256/src/sha256.js [app-route] (ecmascript)");
const transactions_1 = __turbopack_require__("[project]/node_modules/.pnpm/@near-js+transactions@0.1.1/node_modules/@near-js/transactions/lib/index.js [app-route] (ecmascript)");
const near_seed_phrase_1 = __turbopack_require__("[project]/node_modules/.pnpm/near-seed-phrase@0.2.1/node_modules/near-seed-phrase/index.js [app-route] (ecmascript)");
const base64url_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const axios_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/axios@1.7.9/node_modules/axios/dist/node/axios.cjs [app-route] (ecmascript)"));
class NearConfig extends base_1.BaseNodeToken {
    constructor(config){
        var _a;
        let wallet = config.wallet;
        if (typeof wallet === "string" && ((_a = wallet === null || wallet === void 0 ? void 0 : wallet.split(":")) === null || _a === void 0 ? void 0 : _a[0]) !== "ed25519") {
            wallet = (0, near_seed_phrase_1.parseSeedPhrase)(wallet, near_seed_phrase_1.KEY_DERIVATION_PATH).secretKey;
        }
        config.wallet = wallet;
        super(config);
        this.base = [
            "yoctoNEAR",
            1e24
        ];
        this.keyPair = crypto_1.KeyPair.fromString(this.wallet);
    }
    getProvider() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.providerInstance) {
                this.providerInstance = new providers_1.JsonRpcProvider({
                    url: this.providerUrl
                });
            }
            return this.providerInstance;
        });
    }
    /**
     * NEAR wants both the sender ID and tx Hash, so we have to concatenate to keep with the interface.
     * @param txId assumes format senderID:txHash
     */ getTx(txId) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            // NOTE: their type defs are out of date with their actual API (23-01-2022)... beware the expect-error when debugging!
            const provider = yield this.getProvider();
            const [id, hash] = txId.split(":");
            const status = yield provider.txStatusReceipts(bs58_1.default.decode(hash), id);
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            const blockHeight = yield provider.block(status.transaction_outcome.block_hash);
            const latestBlockHeight = (yield provider.block({
                finality: "final"
            })).header.height;
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            if (status.receipts_outcome[0].outcome.status.SuccessValue !== "") {
                throw new Error("Transaction failed!");
            }
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            const deposit = (_a = status.receipts[0].receipt.Action.actions[0].Transfer.deposit) !== null && _a !== void 0 ? _a : 0;
            return {
                from: id,
                to: status.transaction.receiver_id,
                amount: new bignumber_js_1.default(deposit),
                blockHeight: new bignumber_js_1.default(blockHeight.header.height),
                pending: false,
                confirmed: latestBlockHeight - blockHeight.header.height >= this.minConfirm
            };
        });
    }
    /**
     * address = accountID
     * @param owner // assumed to be the "ed25519:" header + b58 encoded key
     */ ownerToAddress(owner) {
        return Buffer.from(typeof owner === "string" ? bs58_1.default.decode(owner.replace("ed25519:", "")) : bs58_1.default.decode(bs58_1.default.encode(owner))).toString("hex");
    }
    sign(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.getSigner().sign(data);
        });
    }
    getSigner() {
        return new arbundles_1.NearSigner(this.wallet);
    }
    verify(pub, data, signature) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return arbundles_1.NearSigner.verify(pub, data, signature);
        });
    }
    getCurrentHeight() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = yield this.getProvider();
            const res = yield provider.status();
            return new bignumber_js_1.default(res.sync_info.latest_block_height);
        });
    }
    /**
     * NOTE: assumes only operation is transfer
     * @param _amount
     * @param _to
     * @returns
     */ getFee(_amount, _to) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            // TODO: use https://docs.near.org/docs/concepts/gas and https://docs.near.org/docs/api/rpc/protocol#genesis-config
            // to derive cost from genesis config to generalise support.
            const provider = yield this.getProvider();
            const res = yield provider.gasPrice(null); // null == gas price as of latest block
            // multiply by action cost in gas units (assume only action is transfer)
            // 4.5x10^11 gas units for fund transfers
            return new bignumber_js_1.default(res.gas_price).multipliedBy(450000000000);
        });
    }
    sendTx(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = yield this.getProvider();
            // // hack to fix near SDK issue
            // we manually encode as due to a lack of node_module flattening, two classes (who are otherwise identical)
            // are imported from two different locations, meaning JS's equivalency is broken (not the same internal object)
            // this bypasses this issue by ensuring the class is imported from the "flat" version
            // const res = await provider.sendTransaction(data);
            const expectedSignedTransactionClass = [
                ...transactions_1.SCHEMA.keys()
            ].find((c)=>c.name === "SignedTransaction");
            data.constructor = expectedSignedTransactionClass;
            const encodedTransaction = (0, transactions_1.encodeTransaction)(data);
            const res = yield provider.sendJsonRpc("broadcast_tx_commit", [
                Buffer.from(encodedTransaction).toString("base64")
            ]);
            return `${this.address}:${res.transaction.hash}`; // encode into compound format
        });
    }
    createTx(amount, to, _fee) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = yield this.getProvider();
            const accessKey = yield provider.query({
                request_type: "view_access_key",
                finality: "final",
                account_id: this.address,
                public_key: this.keyPair.getPublicKey().toString()
            });
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            const nonce = ++accessKey.nonce;
            const recentBlockHash = Buffer.from(bs58_1.default.decode(accessKey.block_hash));
            const actions = [
                transactions_1.actionCreators.transfer(new bn_js_1.default(new bignumber_js_1.default(amount).toFixed().toString()))
            ];
            if (!this.address) throw new Error("Address is undefined - you might be missing a wallet, or have not run Irys.ready()");
            const tx = (0, transactions_1.createTransaction)(this.address, this.keyPair.getPublicKey(), to, nonce, actions, recentBlockHash);
            // hack to fix near SDK issue
            const expectedPublicKeyClass = [
                ...transactions_1.SCHEMA.keys()
            ].find((c)=>c.name === "PublicKey");
            tx.publicKey.constructor = expectedPublicKeyClass;
            const serialTx = (0, borsh_1.serialize)(transactions_1.SCHEMA, tx);
            const serialTxHash = new Uint8Array(js_sha256_1.sha256.array(serialTx));
            const signature = this.keyPair.sign(serialTxHash);
            const signedTx = new transactions_1.SignedTransaction({
                transaction: tx,
                signature: new transactions_1.Signature({
                    keyType: tx.publicKey.keyType,
                    data: signature.signature
                })
            });
            return {
                tx: signedTx,
                txId: undefined
            };
        });
    }
    getPublicKey() {
        this.keyPair = crypto_1.KeyPair.fromString(this.wallet);
        return Buffer.from(this.keyPair.getPublicKey().data);
    }
    ready() {
        var _a, _b;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            try {
                // resolve loaded pubkey to parent address
                const pubkey = this.keyPair.getPublicKey().toString();
                const resolved = yield axios_1.default.get(`${this.IrysUrl}account/near/lookup?address=${base64url_1.default.encode(pubkey.split(":")[1])}`).catch((e)=>{
                    return e;
                });
                this._address = (_b = (_a = resolved === null || resolved === void 0 ? void 0 : resolved.data) === null || _a === void 0 ? void 0 : _a.address) !== null && _b !== void 0 ? _b : this._address;
            } catch (e) {
                console.error(e);
            }
        });
    }
}
exports.default = NearConfig; //# sourceMappingURL=near.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/solana.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const arbundles_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/index.js [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const bs58_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bs58@5.0.0/node_modules/bs58/index.js [app-route] (ecmascript)"));
const tweetnacl_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tweetnacl@1.0.3/node_modules/tweetnacl/nacl-fast.js [app-route] (ecmascript)"));
const base_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/base.js [app-route] (ecmascript)");
const async_retry_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/async-retry@1.3.3/node_modules/async-retry/lib/index.js [app-route] (ecmascript)"));
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
class SolanaConfig extends base_1.BaseNodeToken {
    constructor(config){
        var _a, _b;
        super(config);
        this.minConfirm = 1;
        this.finality = "finalized";
        this.base = [
            "lamports",
            1e9
        ];
        this.finality = (_b = (_a = this === null || this === void 0 ? void 0 : this.opts) === null || _a === void 0 ? void 0 : _a.finality) !== null && _b !== void 0 ? _b : "finalized";
    }
    getProvider() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.providerInstance) {
                this.providerInstance = new web3_js_1.Connection(this.providerUrl, {
                    confirmTransactionInitialTimeout: 60000,
                    commitment: this.finality
                });
            }
            return this.providerInstance;
        });
    }
    getKeyPair() {
        let key = this.wallet;
        if (typeof key !== "string") {
            key = bs58_1.default.encode(Buffer.from(key));
        }
        return web3_js_1.Keypair.fromSecretKey(bs58_1.default.decode(key));
    }
    getTx(txId) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const connection = yield this.getProvider();
            const stx = yield connection.getTransaction(txId, {
                commitment: this.finality,
                maxSupportedTransactionVersion: 0
            });
            if (!stx) throw new Error("Confirmed tx not found");
            const currentSlot = yield connection.getSlot(this.finality);
            if (!stx.meta) throw new Error(`Unable to resolve transaction ${txId}`);
            const amount = new bignumber_js_1.default(stx.meta.postBalances[1]).minus(new bignumber_js_1.default(stx.meta.preBalances[1]));
            const staticAccountKeys = stx.transaction.message.getAccountKeys().staticAccountKeys;
            const tx = {
                from: staticAccountKeys[0].toBase58(),
                to: staticAccountKeys[1].toBase58(),
                amount: amount,
                blockHeight: new bignumber_js_1.default(stx.slot),
                pending: false,
                confirmed: currentSlot - stx.slot >= 1
            };
            return tx;
        });
    }
    ownerToAddress(owner) {
        return bs58_1.default.encode(owner);
    }
    sign(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return yield (yield this.getSigner()).sign(data);
        });
    }
    getSigner() {
        const keyp = this.getKeyPair();
        const keypb = bs58_1.default.encode(Buffer.concat([
            Buffer.from(keyp.secretKey),
            keyp.publicKey.toBuffer()
        ]));
        return new arbundles_1.HexSolanaSigner(keypb);
    }
    verify(pub, data, signature) {
        return arbundles_1.HexSolanaSigner.verify(pub, data, signature);
    }
    getCurrentHeight() {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return new bignumber_js_1.default((_a = (yield (yield this.getProvider()).getEpochInfo()).blockHeight) !== null && _a !== void 0 ? _a : 0);
        });
    }
    getFee(amount, to, multiplier) {
        var _a, _b, _c;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const connection = yield this.getProvider();
            const unsignedTx = yield this._createTxUnsigned(amount, to !== null && to !== void 0 ? to : "DHyDV2ZjN3rB6qNGXS48dP5onfbZd3fAEz6C5HJwSqRD");
            const computeBudget = new bignumber_js_1.default((_a = yield unsignedTx.getEstimatedFee(connection)) !== null && _a !== void 0 ? _a : 5000);
            const recentPrio = yield (_b = connection === null || connection === void 0 ? void 0 : connection.getRecentPrioritizationFees) === null || _b === void 0 ? void 0 : _b.call(connection).catch((_)=>[
                    {
                        prioritizationFee: 0
                    }
                ]);
            const prioAvg = recentPrio.reduce((n, p)=>n.plus(p.prioritizationFee), new bignumber_js_1.default(0)).dividedToIntegerBy((_c = recentPrio.length) !== null && _c !== void 0 ? _c : 1);
            return {
                computeBudget,
                computeUnitPrice: prioAvg.multipliedBy(multiplier !== null && multiplier !== void 0 ? multiplier : 1).integerValue(bignumber_js_1.default.ROUND_CEIL)
            };
        });
    }
    sendTx(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const connection = yield this.getProvider();
            try {
                return yield (0, web3_js_1.sendAndConfirmTransaction)(connection, data, [
                    this.getKeyPair()
                ], {
                    commitment: this.finality
                });
            } catch (e) {
                if (e.message.includes("30.")) {
                    const txId = e.message.match(/[A-Za-z0-9]{87,88}/g);
                    if (!txId) throw e;
                    try {
                        const conf = yield connection.confirmTransaction({
                            signature: txId[0],
                            blockhash: data.recentBlockhash,
                            lastValidBlockHeight: data.lastValidBlockHeight
                        }, this.finality);
                        if (conf) return undefined;
                        throw {
                            message: e.message,
                            txId: txId[0]
                        };
                    } catch (e) {
                        throw {
                            message: e.message,
                            txId: txId[0]
                        };
                    }
                }
                throw e;
            }
        });
    }
    _createTxUnsigned(amount, to, fee) {
        var _a, _b;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const keys = this.getKeyPair();
            const blockHashInfo = yield (0, async_retry_1.default)((bail)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    var _c;
                    try {
                        return yield (yield this.getProvider()).getLatestBlockhash(this.finality);
                    } catch (e) {
                        if ((_c = e.message) === null || _c === void 0 ? void 0 : _c.includes("blockhash")) throw e;
                        else bail(e);
                        throw new Error("Unreachable");
                    }
                }), {
                retries: 3,
                minTimeout: 1000
            });
            const transaction = new web3_js_1.Transaction(Object.assign(Object.assign({}, blockHashInfo), {
                feePayer: keys.publicKey
            }));
            transaction.add(web3_js_1.SystemProgram.transfer({
                fromPubkey: keys.publicKey,
                toPubkey: new web3_js_1.PublicKey(to),
                lamports: +new bignumber_js_1.default(amount).toNumber()
            }));
            if (!((_b = (_a = this === null || this === void 0 ? void 0 : this.config) === null || _a === void 0 ? void 0 : _a.opts) === null || _b === void 0 ? void 0 : _b.disablePriorityFees) && fee) {
                transaction.add(web3_js_1.ComputeBudgetProgram.setComputeUnitPrice({
                    microLamports: fee.computeUnitPrice.toNumber()
                }));
                transaction.add(web3_js_1.ComputeBudgetProgram.setComputeUnitLimit({
                    units: fee.computeBudget.toNumber()
                }));
            }
            return transaction;
        });
    }
    createTx(amount, to, fee) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const keys = this.getKeyPair();
            const unsignedTx = yield this._createTxUnsigned(amount, to, fee);
            const transactionBuffer = unsignedTx.serializeMessage();
            const signature = tweetnacl_1.default.sign.detached(transactionBuffer, keys.secretKey);
            unsignedTx.addSignature(keys.publicKey, Buffer.from(signature));
            return {
                tx: unsignedTx,
                txId: undefined
            };
        });
    }
    getPublicKey() {
        const key = this.getKeyPair();
        return key.publicKey.toBuffer();
    }
}
exports.default = SolanaConfig; //# sourceMappingURL=solana.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/algorand.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const arbundles_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/index.js [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const base_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/base.js [app-route] (ecmascript)");
const axios_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/axios@1.7.9/node_modules/axios/dist/node/axios.cjs [app-route] (ecmascript)"));
const algosdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/algosdk@1.24.1_encoding@0.1.13/node_modules/algosdk/dist/esm/index.js [app-route] (ecmascript)");
class AlgorandConfig extends base_1.BaseNodeToken {
    constructor(config){
        super(config);
        this.base = [
            "microAlgos",
            1e6
        ];
        this.keyPair = (0, algosdk_1.mnemonicToSecretKey)(this.wallet);
        this.apiURL = config.providerUrl;
        if (!config.opts.indexerUrl) throw new Error(`Algorand: required client constructor option 'opts.indexerUrl' is undefined`);
        this.indexerURL = config.opts.indexerUrl;
    }
    getTx(txId) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const endpoint = `${this.indexerURL}/v2/transactions/${txId}`;
            const response = yield axios_1.default.get(endpoint);
            const latestBlockHeight = new bignumber_js_1.default((yield this.getCurrentHeight())).toNumber();
            const txBlockHeight = new bignumber_js_1.default(response.data.transaction["confirmed-round"]);
            const tx = {
                from: response.data.transaction.sender,
                to: response.data.transaction["payment-transaction"].receiver,
                amount: new bignumber_js_1.default(response.data.transaction["payment-transaction"].amount),
                blockHeight: txBlockHeight,
                pending: false,
                confirmed: latestBlockHeight - txBlockHeight.toNumber() >= this.minConfirm
            };
            return tx;
        });
    }
    ownerToAddress(owner) {
        return (0, algosdk_1.encodeAddress)(owner);
    }
    sign(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.getSigner().sign(data);
        });
    }
    getSigner() {
        return new arbundles_1.AlgorandSigner(this.keyPair.sk, this.getPublicKey());
    }
    verify(pub, data, signature) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return arbundles_1.AlgorandSigner.verify(pub, data, signature);
        });
    }
    getCurrentHeight() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            //  "last-round" = blockheight
            const endpoint = `${this.apiURL}/v2/transactions/params`;
            const response = yield axios_1.default.get(endpoint);
            return new bignumber_js_1.default((yield response.data["last-round"]));
        });
    }
    getFee() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const endpoint = `${this.apiURL}/v2/transactions/params`;
            const response = yield axios_1.default.get(endpoint);
            return new bignumber_js_1.default(response.data["min-fee"]);
        });
    }
    sendTx(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const endpoint = `${this.apiURL}/v2/transactions`;
            const response = yield axios_1.default.post(endpoint, data);
            return response.data.txId;
        });
    }
    createTx(amount, to) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const endpoint = `${this.apiURL}/v2/transactions/params`;
            const response = yield axios_1.default.get(endpoint);
            const params = yield response.data;
            const unsigned = (0, algosdk_1.makePaymentTxnWithSuggestedParamsFromObject)({
                from: this.keyPair.addr,
                to: to,
                amount: new bignumber_js_1.default(amount).toNumber(),
                note: undefined,
                suggestedParams: {
                    fee: params.fee,
                    firstRound: params["last-round"],
                    flatFee: false,
                    genesisHash: params["genesis-hash"],
                    genesisID: params["genesis-id"],
                    lastRound: params["last-round"] + 1000
                }
            });
            const signed = (0, algosdk_1.signTransaction)(unsigned, this.keyPair.sk);
            return {
                tx: signed.blob,
                txId: signed.txID
            };
        });
    }
    getPublicKey() {
        this.keyPair = (0, algosdk_1.mnemonicToSecretKey)(this.wallet);
        const pub = (0, algosdk_1.decodeAddress)(this.keyPair.addr).publicKey;
        return Buffer.from(pub);
    }
}
exports.default = AlgorandConfig; //# sourceMappingURL=algorand.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/aptos.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const arbundles_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/index.js [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const base_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/base.js [app-route] (ecmascript)");
const js_sha3_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/js-sha3@0.8.0/node_modules/js-sha3/src/sha3.js [app-route] (ecmascript)"));
const ts_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@aptos-labs+ts-sdk@1.33.1/node_modules/@aptos-labs/ts-sdk/dist/common/index.js [app-route] (ecmascript)");
const async_retry_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/async-retry@1.3.3/node_modules/async-retry/lib/index.js [app-route] (ecmascript)"));
class AptosConfig extends base_1.BaseNodeToken {
    constructor(config){
        var _a, _b, _c;
        if (typeof config.wallet === "string" && config.wallet.length === 66) {
            // If signingFunction is provided, the given `wallet` is a public key
            if ((_a = config === null || config === void 0 ? void 0 : config.opts) === null || _a === void 0 ? void 0 : _a.signingFunction) {
                config.wallet = Buffer.from(config.wallet.slice(2), "hex");
            } else {
                config.wallet = new ts_sdk_1.Ed25519PrivateKey(config.wallet);
                // @ts-expect-error custom prop
                config.accountInstance = ts_sdk_1.Account.fromPrivateKey({
                    privateKey: config === null || config === void 0 ? void 0 : config.wallet
                });
            }
        }
        super(config);
        this.txLock = Promise.resolve();
        this.locked = false;
        // @ts-expect-error assignment doesn't carry through for some reason
        this.accountInstance = config.accountInstance;
        this.signingFn = (_b = config === null || config === void 0 ? void 0 : config.opts) === null || _b === void 0 ? void 0 : _b.signingFunction;
        this.needsFee = true;
        this.base = [
            "octa",
            1e8
        ];
        // In the Aptos context, this.providerUrl is the Aptos Network enum type we want
        // to work with. read more https://github.com/aptos-labs/aptos-ts-sdk/blob/main/src/api/aptosConfig.ts#L14
        // this.providerUrl is a Network enum type represents the current configured network
        this.aptosConfig = new ts_sdk_1.AptosConfig(Object.assign({
            network: this.providerUrl
        }, (_c = config === null || config === void 0 ? void 0 : config.opts) === null || _c === void 0 ? void 0 : _c.aptosSdkConfig));
    }
    getProvider() {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return (_a = this.providerInstance) !== null && _a !== void 0 ? _a : this.providerInstance = new ts_sdk_1.Aptos(this.aptosConfig);
        });
    }
    getTx(txId) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const client = yield this.getProvider();
            const tx = yield client.waitForTransaction({
                transactionHash: txId
            });
            const payload = tx === null || tx === void 0 ? void 0 : tx.payload;
            if (!tx.success) {
                throw new Error((_a = tx === null || tx === void 0 ? void 0 : tx.vm_status) !== null && _a !== void 0 ? _a : "Unknown Aptos error");
            }
            if (!((payload === null || payload === void 0 ? void 0 : payload.function) === "0x1::coin::transfer" && (payload === null || payload === void 0 ? void 0 : payload.type_arguments[0]) === "0x1::aptos_coin::AptosCoin" && (tx === null || tx === void 0 ? void 0 : tx.vm_status) === "Executed successfully")) {
                throw new Error(`Aptos tx ${txId} failed validation`);
            }
            const isPending = tx.type === "pending_transaction";
            return {
                to: payload.arguments[0],
                from: tx.sender,
                amount: new bignumber_js_1.default(payload.arguments[1]),
                pending: isPending,
                confirmed: !isPending
            };
        });
    }
    ownerToAddress(owner) {
        const hash = js_sha3_1.default.sha3_256.create();
        hash.update(Buffer.from(owner));
        hash.update("\x00");
        return `0x${hash.hex()}`;
    }
    sign(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return yield this.getSigner().sign(data);
        });
    }
    getSigner() {
        if (this.signerInstance) return this.signerInstance;
        if (this.signingFn) {
            const signer = new arbundles_1.AptosSigner("", "0x" + this.getPublicKey().toString("hex"));
            signer.sign = this.signingFn; // override signer fn
            return this.signerInstance = signer;
        } else {
            // @ts-expect-error private field use
            return this.signerInstance = new arbundles_1.AptosSigner(this.accountInstance.privateKey.toString(), this.accountInstance.publicKey.toString());
        }
    }
    verify(pub, data, signature) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return yield arbundles_1.AptosSigner.verify(pub, data, signature);
        });
    }
    getCurrentHeight() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return new bignumber_js_1.default((yield (yield this.getProvider()).getLedgerInfo()).block_height);
        });
    }
    getFee(amount, to) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.address) throw new Error("Address is undefined - you might be missing a wallet, or have not run Irys.ready()");
            const client = yield this.getProvider();
            const transaction = yield client.transaction.build.simple({
                sender: this.address,
                data: {
                    function: "0x1::coin::transfer",
                    typeArguments: [
                        "0x1::aptos_coin::AptosCoin"
                    ],
                    functionArguments: [
                        to !== null && to !== void 0 ? to : "0x149f7dc9c8e43c14ab46d3a6b62cfe84d67668f764277411f98732bf6718acf9",
                        new bignumber_js_1.default(amount).toNumber()
                    ]
                }
            });
            const accountAuthenticator = new ts_sdk_1.AccountAuthenticatorEd25519(new ts_sdk_1.Ed25519PublicKey(this.getPublicKey()), new ts_sdk_1.Ed25519Signature(new Uint8Array(64)));
            const transactionAuthenticator = new ts_sdk_1.TransactionAuthenticatorEd25519(accountAuthenticator.public_key, accountAuthenticator.signature);
            const signedSimulation = new ts_sdk_1.SignedTransaction(transaction.rawTransaction, transactionAuthenticator).bcsToBytes();
            const queryParams = {
                estimate_gas_unit_price: true,
                estimate_max_gas_amount: true
            };
            const [simulationResult] = yield (0, async_retry_1.default)((_)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    var _a;
                    const { data } = yield (0, ts_sdk_1.postAptosFullNode)({
                        aptosConfig: this.aptosConfig,
                        body: signedSimulation,
                        path: "transactions/simulate",
                        params: queryParams,
                        originMethod: "simulateTransaction",
                        contentType: ts_sdk_1.MimeType.BCS_SIGNED_TRANSACTION
                    });
                    if (!data[0].success || data[0].gas_used === "0") throw new Error(`${(_a = data[0]) === null || _a === void 0 ? void 0 : _a.vm_status} - ${JSON.stringify(data[0])}`);
                    return data;
                }), {
                retries: 3,
                maxTimeout: 1000,
                minTimeout: 200
            }).catch((e)=>{
                var _a;
                if (this.irys.debug) console.warn(`Tx simulation failed (3 attempts): ${(_a = e === null || e === void 0 ? void 0 : e.message) !== null && _a !== void 0 ? _a : e}`);
                return [
                    {
                        gas_unit_price: "100",
                        gas_used: "10"
                    }
                ];
            });
            return {
                gasUnitPrice: +simulationResult.gas_unit_price,
                maxGasAmount: Math.ceil(+simulationResult.gas_used * 2)
            };
        // const simulationResult = await client.simulateTransaction(this.accountInstance, rawTransaction, { estimateGasUnitPrice: true, estimateMaxGasAmount: true });
        // return new BigNumber(simulationResult?.[0].gas_unit_price).multipliedBy(simulationResult?.[0].gas_used);
        // const est = await provider.client.transactions.estimateGasPrice();
        // return new BigNumber(est.gas_estimate/* (await (await this.getProvider()).client.transactions.estimateGasPrice()).gas_estimate */); // * by gas limit (for upper limit)
        });
    }
    sendTx(data) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = yield this.getProvider();
            const { data: postData } = yield (0, ts_sdk_1.postAptosFullNode)({
                aptosConfig: this.aptosConfig,
                body: data.tx,
                path: "transactions",
                originMethod: "submitTransaction",
                contentType: ts_sdk_1.MimeType.BCS_SIGNED_TRANSACTION
            });
            yield provider.waitForTransaction({
                transactionHash: postData.hash
            });
            (_a = data.unlock) === null || _a === void 0 ? void 0 : _a.call(data);
            return postData.hash;
        });
    }
    createTx(amount, to, fee) {
        var _a, _b;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.address) throw new Error("Address is undefined - you might be missing a wallet, or have not run irys.ready()");
            // mutex so multiple aptos txs aren't in flight with the same sequence number
            const unlock = yield this.lock();
            const client = yield this.getProvider();
            const transaction = yield client.transaction.build.simple({
                sender: this.address,
                data: {
                    function: "0x1::coin::transfer",
                    typeArguments: [
                        "0x1::aptos_coin::AptosCoin"
                    ],
                    functionArguments: [
                        to,
                        new bignumber_js_1.default(amount).toNumber()
                    ]
                },
                options: {
                    gasUnitPrice: (_a = fee === null || fee === void 0 ? void 0 : fee.gasUnitPrice) !== null && _a !== void 0 ? _a : 100,
                    maxGasAmount: (_b = fee === null || fee === void 0 ? void 0 : fee.maxGasAmount) !== null && _b !== void 0 ? _b : 10
                }
            });
            const message = (0, ts_sdk_1.generateSigningMessageForTransaction)(transaction);
            const signerSignature = yield this.sign(message);
            const senderAuthenticator = new ts_sdk_1.AccountAuthenticatorEd25519(new ts_sdk_1.Ed25519PublicKey(this.getPublicKey()), new ts_sdk_1.Ed25519Signature(signerSignature));
            const signedTransaction = (0, ts_sdk_1.generateSignedTransaction)({
                transaction,
                senderAuthenticator
            });
            return {
                txId: undefined,
                tx: {
                    tx: signedTransaction,
                    unlock
                }
            };
        });
    }
    getPublicKey() {
        var _a;
        if ((_a = this.opts) === null || _a === void 0 ? void 0 : _a.signingFunction) return this.wallet;
        return Buffer.from(this.accountInstance.publicKey.toUint8Array());
    }
    ready() {
        var _a, _b;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const client = yield this.getProvider();
            this._address = yield client.lookupOriginalAccountAddress({
                authenticationKey: (_a = this.address) !== null && _a !== void 0 ? _a : ""
            }).then((hs)=>hs.toString()).catch((_)=>this._address); // fallback to original
            if (((_b = this._address) === null || _b === void 0 ? void 0 : _b.length) == 66 && this._address.charAt(2) === "0") {
                this._address = this._address.slice(0, 2) + this._address.slice(3);
            }
        });
    }
    // basic async mutex for transaction creation - done so sequenceNumbers don't overlap
    lock() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            this.locked = true;
            let unlockNext;
            const willLock = new Promise((r)=>unlockNext = r);
            willLock.then(()=>this.locked = false);
            const willUnlock = this.txLock.then(()=>unlockNext);
            this.txLock = this.txLock.then(()=>willLock);
            return willUnlock;
        });
    }
}
exports.default = AptosConfig; //# sourceMappingURL=aptos.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/multiAptos.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const aptos_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/aptos.js [app-route] (ecmascript)"));
const arbundles_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/index.js [app-route] (ecmascript)");
const ts_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@aptos-labs+ts-sdk@1.33.1/node_modules/@aptos-labs/ts-sdk/dist/common/index.js [app-route] (ecmascript)");
class MultiSignatureAptos extends aptos_1.default {
    constructor(config){
        var _a;
        super(config);
        this.collectSignatures = (_a = this === null || this === void 0 ? void 0 : this.opts) === null || _a === void 0 ? void 0 : _a.collectSignatures;
        this.needsFee = true;
    }
    /**
     * @param owner compound MultiEd25519PublicKey .toBytes()
     */ ownerToAddress(pubKey) {
        // deserialise key
        const multiSigPublicKey = this.deserialisePubKey(pubKey);
        // derive address
        const authKey2 = ts_sdk_1.AuthenticationKey.fromPublicKeyAndScheme({
            publicKey: multiSigPublicKey,
            scheme: ts_sdk_1.SigningScheme.MultiEd25519
        });
        return authKey2.derivedAddress().toString();
    }
    deserialisePubKey(pubKey) {
        const threshold = +pubKey.slice(32 * 32).toString();
        const keys = [];
        const nullBuf = Buffer.alloc(32, 0);
        for(let i = 0; i < 32; i++){
            const key = pubKey.subarray(i * 32, (i + 1) * 32);
            if (!key.equals(nullBuf)) keys.push(new ts_sdk_1.Ed25519PublicKey(key));
        }
        // reconstruct key
        return new ts_sdk_1.MultiEd25519PublicKey({
            publicKeys: keys,
            threshold
        });
    }
    getPublicKey() {
        const { participants, threshold } = this.wallet;
        const pkey = Buffer.alloc(32 * 32 + 1);
        participants.forEach((k, i)=>{
            pkey.set(k, i * 32);
        });
        pkey.set(Buffer.from(threshold.toString()), 1024);
        return pkey;
    }
    getFee(amount, to) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const client = yield this.getProvider();
            if (!this.address) throw new Error("Address is undefined - you might be missing a wallet, or have not run Irys.ready()");
            const transaction = yield client.transaction.build.simple({
                sender: this.address,
                data: {
                    function: "0x1::coin::transfer",
                    typeArguments: [
                        "0x1::aptos_coin::AptosCoin"
                    ],
                    functionArguments: [
                        to !== null && to !== void 0 ? to : "0x149f7dc9c8e43c14ab46d3a6b62cfe84d67668f764277411f98732bf6718acf9",
                        new bignumber_js_1.default(amount).toNumber()
                    ]
                }
            });
            const accountAuthenticator = new ts_sdk_1.AccountAuthenticatorEd25519(new ts_sdk_1.Ed25519PublicKey(this.getPublicKey()), new ts_sdk_1.Ed25519Signature(new Uint8Array(64)));
            const transactionAuthenticator = new ts_sdk_1.TransactionAuthenticatorEd25519(accountAuthenticator.public_key, accountAuthenticator.signature);
            const signedSimulation = new ts_sdk_1.SignedTransaction(transaction.rawTransaction, transactionAuthenticator).bcsToBytes();
            const queryParams = {
                estimate_gas_unit_price: true,
                estimate_max_gas_amount: true
            };
            const { data } = yield (0, ts_sdk_1.postAptosFullNode)({
                aptosConfig: this.aptosConfig,
                body: signedSimulation,
                path: "transactions/simulate",
                params: queryParams,
                originMethod: "simulateTransaction",
                contentType: ts_sdk_1.MimeType.BCS_SIGNED_TRANSACTION
            });
            return {
                gasUnitPrice: +data[0].gas_unit_price,
                maxGasAmount: +data[0].max_gas_amount
            };
        });
    }
    createTx(amount, to, fee) {
        var _a, _b;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const client = yield this.getProvider();
            const { participants, threshold } = this.wallet;
            const multiSigPublicKey = new ts_sdk_1.MultiEd25519PublicKey({
                publicKeys: participants.map((v)=>new ts_sdk_1.Ed25519PublicKey(v)),
                threshold
            });
            const authKey = ts_sdk_1.AuthenticationKey.fromPublicKeyAndScheme({
                publicKey: multiSigPublicKey,
                scheme: ts_sdk_1.SigningScheme.MultiEd25519
            });
            const mutisigAccountAddress = authKey.derivedAddress();
            const token = (0, ts_sdk_1.parseTypeTag)("0x1::aptos_coin::AptosCoin");
            const entryFunctionPayload = ts_sdk_1.EntryFunction.build(`0x1::coin`, `transfer`, [
                token
            ], [
                ts_sdk_1.AccountAddress.from(to),
                new ts_sdk_1.U64(new bignumber_js_1.default(amount).toNumber())
            ]);
            const [{ sequence_number: sequenceNumber }, chainId] = yield Promise.all([
                client.getAccountInfo({
                    accountAddress: mutisigAccountAddress
                }),
                client.getChainId()
            ]);
            const rawTx = new ts_sdk_1.RawTransaction(// Transaction sender account address
            ts_sdk_1.AccountAddress.from(mutisigAccountAddress), BigInt(sequenceNumber), new ts_sdk_1.TransactionPayloadEntryFunction(entryFunctionPayload), // Max gas unit to spend
            BigInt((_a = fee === null || fee === void 0 ? void 0 : fee.maxGasAmount) !== null && _a !== void 0 ? _a : 10000), // Gas price per unit
            BigInt((_b = fee === null || fee === void 0 ? void 0 : fee.gasUnitPrice) !== null && _b !== void 0 ? _b : 100), // Expiration timestamp. Transaction is discarded if it is not executed within 1000 seconds (16.6 minutes) from now.
            BigInt(Math.floor(Date.now() / 1000) + 1000), new ts_sdk_1.ChainId(chainId));
            return {
                tx: rawTx,
                txId: undefined
            };
        });
    }
    sendTx(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const client = yield this.getProvider();
            const signingMessage = (0, ts_sdk_1.generateSigningMessageForTransaction)(data);
            const { signatures, bitmap } = yield this.collectSignatures(signingMessage);
            const encodedBitmap = ts_sdk_1.MultiEd25519Signature.createBitmap({
                bits: bitmap
            });
            const muliEd25519Sig = new ts_sdk_1.MultiEd25519Signature({
                signatures: signatures.map((s)=>new ts_sdk_1.Ed25519Signature(s)),
                bitmap: encodedBitmap
            });
            const authenticator = new ts_sdk_1.TransactionAuthenticatorMultiEd25519(this.deserialisePubKey(this.getPublicKey()), muliEd25519Sig);
            const bcsTxn = new ts_sdk_1.SignedTransaction(data, authenticator);
            const { data: postData } = yield (0, ts_sdk_1.postAptosFullNode)({
                aptosConfig: this.aptosConfig,
                body: bcsTxn,
                path: "transactions",
                originMethod: "submitTransaction",
                contentType: ts_sdk_1.MimeType.BCS_SIGNED_TRANSACTION
            });
            yield client.waitForTransaction({
                transactionHash: postData.hash
            });
            return postData.hash;
        });
    }
    getSigner() {
        var _a;
        if (this.signerInstance) return this.signerInstance;
        const pkey = Buffer.alloc(1025);
        const deserKey = this.deserialisePubKey(this.getPublicKey());
        deserKey.publicKeys.forEach((k, i)=>{
            pkey.set(k.toUint8Array(), i * 32);
        });
        pkey.set(Buffer.from(deserKey.threshold.toString()), 1024);
        return (_a = this.signerInstance) !== null && _a !== void 0 ? _a : this.signerInstance = new arbundles_1.MultiSignatureAptosSigner(pkey, this.collectSignatures);
    }
    ready() {
        const _super = Object.create(null, {
            ready: {
                get: ()=>super.ready
            }
        });
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            yield _super.ready.call(this);
        });
    }
    verify(pub, data, signature) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return yield arbundles_1.MultiSignatureAptosSigner.verify(pub, data, signature);
        });
    }
}
exports.default = MultiSignatureAptos; //# sourceMappingURL=multiAptos.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const arweave_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/arweave.js [app-route] (ecmascript)"));
const erc20_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/erc20.js [app-route] (ecmascript)"));
const ethereum_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/ethereum.js [app-route] (ecmascript)"));
const near_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/near.js [app-route] (ecmascript)"));
const solana_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/solana.js [app-route] (ecmascript)"));
const algorand_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/algorand.js [app-route] (ecmascript)"));
const axios_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/axios@1.7.9/node_modules/axios/dist/node/axios.cjs [app-route] (ecmascript)"));
const utils_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)"));
const aptos_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/aptos.js [app-route] (ecmascript)"));
const multiAptos_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/multiAptos.js [app-route] (ecmascript)"));
const ts_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@aptos-labs+ts-sdk@1.33.1/node_modules/@aptos-labs/ts-sdk/dist/common/index.js [app-route] (ecmascript)");
function getTokenConfig(irys, token, wallet, url, providerUrl, contractAddress, opts) {
    switch(token){
        case "arweave":
            return new arweave_1.default({
                irys: irys,
                name: "arweave",
                ticker: "AR",
                minConfirm: 10,
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://arweave.net",
                wallet,
                isSlow: true,
                opts
            });
        case "ethereum":
            return new ethereum_1.default({
                irys: irys,
                name: "ethereum",
                ticker: "ETH",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://cloudflare-eth.com/",
                wallet,
                opts
            });
        case "matic":
            return new ethereum_1.default({
                irys: irys,
                name: "matic",
                ticker: "MATIC",
                minConfirm: 1,
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://polygon-rpc.com/",
                wallet,
                opts
            });
        case "bnb":
            return new ethereum_1.default({
                irys: irys,
                name: "bnb",
                ticker: "BNB",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://bsc-dataseed.binance.org/",
                wallet,
                opts
            });
        case "fantom":
            return new ethereum_1.default({
                irys: irys,
                name: "fantom",
                ticker: "FTM",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://rpc.ftm.tools/",
                wallet,
                opts
            });
        case "solana":
            return new solana_1.default({
                irys: irys,
                name: "solana",
                ticker: "SOL",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://api.mainnet-beta.solana.com/",
                wallet,
                opts
            });
        case "avalanche":
            return new ethereum_1.default({
                irys: irys,
                name: "avalanche",
                ticker: "AVAX",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://api.avax-test.network/ext/bc/C/rpc/",
                wallet,
                opts
            });
        case "boba-eth":
            return new ethereum_1.default({
                irys: irys,
                name: "boba-eth",
                ticker: "ETH",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://mainnet.boba.network/",
                minConfirm: 1,
                wallet,
                opts
            });
        case "base-eth":
            return new ethereum_1.default({
                irys: irys,
                name: "base-eth",
                ticker: "ETH",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://mainnet.base.org/",
                minConfirm: 2,
                wallet,
                opts
            });
        case "usdc-eth":
            return new erc20_1.default({
                irys: irys,
                name: "usdc-eth",
                ticker: "USDC",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://cloudflare-eth.com/",
                contractAddress: contractAddress !== null && contractAddress !== void 0 ? contractAddress : "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
                wallet,
                opts
            });
        case "boba":
            {
                const k = new erc20_1.default({
                    irys: irys,
                    name: "boba",
                    ticker: "BOBA",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://mainnet.boba.network/",
                    contractAddress: contractAddress !== null && contractAddress !== void 0 ? contractAddress : "0xa18bF3994C0Cc6E3b63ac420308E5383f53120D7",
                    minConfirm: 1,
                    wallet,
                    opts
                });
                // for L1 mainnet: "https://main-light.eth.linkpool.io/" and "0x42bbfa2e77757c645eeaad1655e0911a7553efbc"
                k.price = ()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                        var _a;
                        const res = yield axios_1.default.post("https://api.livecoinwatch.com/coins/single", JSON.stringify({
                            currency: "USD",
                            code: `${k.ticker}`
                        }), {
                            headers: {
                                "x-api-key": "75a7a824-6577-45e6-ad86-511d590c7cc8",
                                "content-type": "application/json"
                            }
                        });
                        yield utils_1.default.checkAndThrow(res, "Getting price data");
                        if (!((_a = res === null || res === void 0 ? void 0 : res.data) === null || _a === void 0 ? void 0 : _a.rate)) {
                            throw new Error(`unable to get price for ${k.name}`);
                        }
                        return +res.data.rate;
                    });
                return k;
            }
        case "arbitrum":
            return new ethereum_1.default({
                irys: irys,
                name: "arbitrum",
                ticker: "ETH",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://arb1.arbitrum.io/rpc/",
                wallet,
                opts
            });
        case "chainlink":
            return new erc20_1.default({
                irys: irys,
                name: "chainlink",
                ticker: "LINK",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://main-light.eth.linkpool.io/",
                contractAddress: contractAddress !== null && contractAddress !== void 0 ? contractAddress : "0x514910771AF9Ca656af840dff83E8264EcF986CA",
                wallet,
                opts
            });
        case "kyve":
            {
                const k = new erc20_1.default({
                    irys: irys,
                    name: "kyve",
                    ticker: "KYVE",
                    minConfirm: 0,
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://moonbeam-alpha.api.onfinality.io/public",
                    contractAddress: contractAddress !== null && contractAddress !== void 0 ? contractAddress : "0x3cf97096ccdb7c3a1d741973e351cb97a2ede2c1",
                    isSlow: true,
                    wallet,
                    opts
                });
                k.price = ()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                        return 100;
                    }); // TODO: replace for mainnet
                k.getGas = ()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                        return [
                            new bignumber_js_1.default(100),
                            1e18
                        ];
                    });
                return k; // TODO: ensure units above are right
            }
        case "near":
            {
                return new near_1.default({
                    irys: irys,
                    name: "near",
                    ticker: "NEAR",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://rpc.mainnet.near.org",
                    wallet,
                    IrysUrl: url,
                    opts
                });
            }
        case "algorand":
            {
                return new algorand_1.default({
                    irys: irys,
                    name: "algorand",
                    ticker: "ALGO",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://mainnet-api.algonode.cloud",
                    wallet,
                    opts: Object.assign({
                        indexerUrl: "https://mainnet-idx.algonode.cloud"
                    }, opts)
                });
            }
        case "aptos":
            {
                return new aptos_1.default({
                    irys: irys,
                    name: "aptos",
                    ticker: "APTOS",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : ts_sdk_1.Network.MAINNET,
                    wallet,
                    opts
                });
            }
        case "multiaptos":
            {
                return new multiAptos_1.default({
                    irys: irys,
                    name: "aptos",
                    ticker: "APTOS",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : ts_sdk_1.Network.MAINNET,
                    wallet,
                    opts
                });
            }
        case "usdc-polygon":
            return new erc20_1.default({
                irys,
                name: "usdc-polygon",
                ticker: "USDC",
                wallet,
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://polygon-rpc.com",
                contractAddress: contractAddress !== null && contractAddress !== void 0 ? contractAddress : "0x3c499c542cef5e3811e1192ce70d8cc03d5c3359"
            });
        case "bera":
            return new ethereum_1.default({
                irys: irys,
                name: "bera",
                ticker: "BERA",
                // TODO: make sure this is set to mainnet
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://bartio.rpc.berachain.com/",
                minConfirm: 1,
                wallet,
                opts
            });
        case "scroll-eth":
            return new ethereum_1.default({
                irys: irys,
                name: "scroll-eth",
                ticker: "ETH",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://rpc.scroll.io",
                wallet,
                opts
            });
        case "linea-eth":
            return new ethereum_1.default({
                irys: irys,
                name: "linea-eth",
                ticker: "ETH",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://rpc.linea.build",
                wallet,
                opts
            });
        case "iotex":
            return new ethereum_1.default({
                irys: irys,
                name: "iotex",
                ticker: "IOTX",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://babel-api.mainnet.iotex.io/",
                wallet,
                opts
            });
        default:
            throw new Error(`Unknown/Unsupported token ${token}`);
    }
}
exports.default = getTokenConfig; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/irys.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.NodeIrys = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const base_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/base.js [app-route] (ecmascript)");
const tokens_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/tokens/index.js [app-route] (ecmascript)"));
class NodeIrys extends base_1.BaseNodeIrys {
    /**
     * Constructs a new Irys instance, as well as supporting subclasses
     * @param url - URL to the bundler
     * @param key - private key (in whatever form required)
     */ constructor({ url, token, network, key, config }){
        super({
            url,
            config,
            network,
            getTokenConfig: (irys)=>{
                return (0, tokens_1.default)(irys, token.toLowerCase(), key, irys.api.getConfig().url.toString(), config === null || config === void 0 ? void 0 : config.providerUrl, config === null || config === void 0 ? void 0 : config.contractAddress, config === null || config === void 0 ? void 0 : config.tokenOpts);
            }
        });
    }
    static init(opts) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const { url, token, privateKey, publicKey, signingFunction, collectSignatures, providerUrl, timeout, contractAddress } = opts;
            const Irys = new NodeIrys({
                url,
                token,
                key: signingFunction ? publicKey : privateKey,
                config: {
                    providerUrl,
                    timeout,
                    contractAddress,
                    tokenOpts: {
                        signingFunction,
                        collectSignatures
                    }
                }
            });
            yield Irys.ready();
            return Irys;
        });
    }
}
exports.NodeIrys = NodeIrys;
exports.default = NodeIrys; //# sourceMappingURL=irys.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.NodeIrys = exports.default = void 0;
var irys_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/irys.js [app-route] (ecmascript)");
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return __importDefault(irys_1).default;
    }
});
var irys_2 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/irys.js [app-route] (ecmascript)");
Object.defineProperty(exports, "NodeIrys", {
    enumerable: true,
    get: function() {
        return __importDefault(irys_2).default;
    }
}); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Arweave = exports.bundleAndSignData = exports.getCryptoDriver = exports.stringToBuffer = exports.deepHash = exports.DataItem = exports.createData = void 0;
const web_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/webIndex.js [app-route] (ecmascript)");
Object.defineProperty(exports, "createData", {
    enumerable: true,
    get: function() {
        return web_1.createData;
    }
});
Object.defineProperty(exports, "DataItem", {
    enumerable: true,
    get: function() {
        return web_1.DataItem;
    }
});
Object.defineProperty(exports, "deepHash", {
    enumerable: true,
    get: function() {
        return web_1.deepHash;
    }
});
Object.defineProperty(exports, "stringToBuffer", {
    enumerable: true,
    get: function() {
        return web_1.stringToBuffer;
    }
});
Object.defineProperty(exports, "getCryptoDriver", {
    enumerable: true,
    get: function() {
        return web_1.getCryptoDriver;
    }
});
Object.defineProperty(exports, "bundleAndSignData", {
    enumerable: true,
    get: function() {
        return web_1.bundleAndSignData;
    }
});
Object.defineProperty(exports, "Arweave", {
    enumerable: true,
    get: function() {
        return web_1.Arweave;
    }
}); //# sourceMappingURL=utils.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/upload.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WebUploader = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const upload_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/upload.js [app-route] (ecmascript)"));
const arbundles_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/index.js [app-route] (ecmascript)");
class WebUploader extends upload_1.default {
    constructor(irys){
        super(irys.api, irys.utils, irys.token, irys.tokenConfig, irys.IrysTransaction);
        this.irys = irys;
    }
    /**
     * Uploads a tagged file object, automatically adding the content-type tag if it's not present
     * @param file - File object to upload
     * @param opts - optional options for the upload / data item creation
     * @returns
     */ uploadFile(file, opts) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const hasContentType = (opts === null || opts === void 0 ? void 0 : opts.tags) ? opts.tags.some(({ name })=>name.toLowerCase() === "content-type") : false;
            const tags = hasContentType ? opts === null || opts === void 0 ? void 0 : opts.tags : [
                ...(_a = opts === null || opts === void 0 ? void 0 : opts.tags) !== null && _a !== void 0 ? _a : [],
                {
                    name: "Content-Type",
                    value: file.type
                }
            ];
            return this.uploadData(Buffer.from((yield file.arrayBuffer())), Object.assign({
                tags
            }, opts));
        });
    }
    /**
     * Uploads a list of `File` objects & a generated folder manifest as a nested bundle using a temporary signing key.
     *
     * @param files list of `File` objects to upload - note: this code determines the paths via the File's `name` property - if it's undefined, it falls back to `webkitRelativePath`
     * @param {string} [opts.indexFileRelPath] Relative path for the index file, i.e `folder/index.html`
     * @param {Tag[]} [opts.manifestTags] List of tags to add onto the manifest transaction
     * @param {JWKInterface} [opts.throwawayKey] Provide your own throwaway JWK to use for signing the items in the bundle
     * @param {boolean} [opts.separateManifestTx=false] Whether upload the manifest as a separate tx (not in the nested bundle) - note: transactions in a nested bundle are not indexed by bundlr GQL - if you have tags you want to use to find the manifest, set this option to true
     *
     * @returns Standard upload response from the bundler node, plus the throwaway key & address, manifest, manifest TxId and the list of generated transactions
     */ uploadFolder(files, opts) {
        var _a, _b, _c, _d;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const txs = [];
            const txMap = new Map();
            const throwawayKey = (_a = opts === null || opts === void 0 ? void 0 : opts.throwawayKey) !== null && _a !== void 0 ? _a : yield this.irys.arbundles.getCryptoDriver().generateJWK();
            const ephemeralSigner = new arbundles_1.ArweaveSigner(throwawayKey);
            for (const file of files){
                const path = (_b = file.name) !== null && _b !== void 0 ? _b : file.webkitRelativePath;
                const hasContentType = file.tags ? file.tags.some(({ name })=>name.toLowerCase() === "content-type") : false;
                const tags = hasContentType ? file.tags : [
                    ...(_c = file.tags) !== null && _c !== void 0 ? _c : [],
                    {
                        name: "Content-Type",
                        value: file.type
                    }
                ];
                const tx = this.irys.arbundles.createData(Buffer.from((yield file.arrayBuffer())), ephemeralSigner, {
                    tags
                });
                yield tx.sign(ephemeralSigner);
                txs.push(tx);
                txMap.set(path, tx.id);
            }
            // generate manifest, add to bundle
            const manifest = yield this.generateManifest({
                items: txMap,
                indexFile: opts === null || opts === void 0 ? void 0 : opts.indexFileRelPath
            });
            const manifestTx = this.irys.arbundles.createData(JSON.stringify(manifest), (opts === null || opts === void 0 ? void 0 : opts.separateManifestTx) ? this.irys.tokenConfig.getSigner() : ephemeralSigner, {
                tags: [
                    {
                        name: "Type",
                        value: "manifest"
                    },
                    {
                        name: "Content-Type",
                        value: "application/x.arweave-manifest+json"
                    },
                    ...(_d = opts === null || opts === void 0 ? void 0 : opts.manifestTags) !== null && _d !== void 0 ? _d : []
                ]
            });
            if ((opts === null || opts === void 0 ? void 0 : opts.separateManifestTx) === true) {
                yield manifestTx.sign(this.irys.tokenConfig.getSigner());
                yield this.uploadTransaction(manifestTx, Object.assign({}, opts));
            } else {
                yield manifestTx.sign(ephemeralSigner);
                txs.push(manifestTx);
            }
            // upload bundle
            const bundleRes = yield this.uploadBundle(txs, Object.assign({}, opts));
            return Object.assign(Object.assign({}, bundleRes.data), {
                manifestId: manifestTx.id,
                manifest,
                throwawayKey: bundleRes.throwawayKey,
                throwawayKeyAddress: bundleRes.throwawayKeyAddress,
                txs: bundleRes.txs
            });
        });
    }
}
exports.WebUploader = WebUploader; //# sourceMappingURL=upload.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/base.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseWebIrys = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/hack.js [app-route] (ecmascript)");
const api_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/api.js [app-route] (ecmascript)"));
const fund_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/fund.js [app-route] (ecmascript)"));
const irys_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/irys.js [app-route] (ecmascript)"));
const utils_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)"));
const provenance_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/provenance.js [app-route] (ecmascript)");
const transactions_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/transactions.js [app-route] (ecmascript)");
const arbundles = tslib_1.__importStar(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/utils.js [app-route] (ecmascript)"));
const upload_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/upload.js [app-route] (ecmascript)");
const approval_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/approval.js [app-route] (ecmascript)");
class BaseWebIrys extends irys_1.default {
    constructor({ url, network, wallet, config, getTokenConfig }){
        var _a, _b, _c;
        // @ts-expect-error types
        super({
            url,
            network,
            arbundles
        });
        this.debug = (_a = config === null || config === void 0 ? void 0 : config.debug) !== null && _a !== void 0 ? _a : false;
        this.api = new api_1.default({
            url: this.url,
            timeout: (_b = config === null || config === void 0 ? void 0 : config.timeout) !== null && _b !== void 0 ? _b : 100000,
            headers: config === null || config === void 0 ? void 0 : config.headers
        });
        this.tokenConfig = getTokenConfig(this);
        if (this.url.host.includes("devnet.irys.xyz") && !((config === null || config === void 0 ? void 0 : config.providerUrl) || (wallet === null || wallet === void 0 ? void 0 : wallet.rpcUrl) || ((_c = this === null || this === void 0 ? void 0 : this.tokenConfig) === null || _c === void 0 ? void 0 : _c.inheritsRPC))) throw new Error(`Using ${this.url.host} requires a dev/testnet RPC to be configured! see https://docs.irys.xyz/developer-docs/using-devnet`);
        this.token = this.tokenConfig.name;
        this.utils = new utils_1.default(this.api, this.token, this.tokenConfig);
        this.uploader = new upload_1.WebUploader(this);
        this.funder = new fund_1.default(this.utils);
        this.uploader = new upload_1.WebUploader(this);
        this.provenance = new provenance_1.Provenance(this);
        this.transactions = new transactions_1.Transaction(this);
        this.approval = new approval_1.Approval(this);
        this.address = "Please run `await Irys.ready()`";
        this.uploadFolder = this.uploader.uploadFolder.bind(this.uploader);
        this.uploadFile = this.uploader.uploadFile.bind(this.uploader);
    }
}
exports.BaseWebIrys = BaseWebIrys; //# sourceMappingURL=base.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/base.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getRedstonePrice = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/utils.js [app-route] (ecmascript)");
const base64url_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const axios_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/axios@1.7.9/node_modules/axios/dist/node/axios.cjs [app-route] (ecmascript)"));
const utils_2 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)"));
class BaseWebToken {
    constructor(config){
        this.minConfirm = 5;
        this.isSlow = false;
        this.needsFee = true;
        this.inheritsRPC = false;
        Object.assign(this, config);
        this.config = config;
    }
    // common methods
    get address() {
        return this._address;
    }
    ready() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            this._address = this.wallet ? this.ownerToAddress((yield this.getPublicKey())) : undefined;
        });
    }
    getId(item) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return base64url_1.default.encode(Buffer.from((yield (0, utils_1.getCryptoDriver)().hash((yield item.rawSignature())))));
        });
    }
    price() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return getRedstonePrice(this.ticker);
        });
    }
}
exports.default = BaseWebToken;
function getRedstonePrice(token) {
    return tslib_1.__awaiter(this, void 0, void 0, function*() {
        const res = yield axios_1.default.get(`https://api.redstone.finance/prices?symbol=${token}&provider=redstone&limit=1`);
        yield utils_2.default.checkAndThrow(res, "Getting price data");
        return res.data[0].value;
    });
}
exports.getRedstonePrice = getRedstonePrice; //# sourceMappingURL=base.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/ethereum.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const bignumber_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+bignumber@5.7.0/node_modules/@ethersproject/bignumber/lib.esm/index.js [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const base_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/base.js [app-route] (ecmascript)"));
const web_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/webIndex.js [app-route] (ecmascript)");
const ethereumSigner = web_1.InjectedTypedEthereumSigner;
class EthereumConfig extends base_1.default {
    constructor(config){
        super(config);
        this.inheritsRPC = true;
        this.base = [
            "wei",
            1e18
        ];
    }
    getTx(txId) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = this.providerInstance;
            const response = yield provider.getTransaction(txId);
            if (!response) throw new Error("Tx doesn't exist");
            if (!response.to) throw new Error(`Unable to resolve transactions ${txId} receiver`);
            return {
                from: response.from,
                to: response.to,
                blockHeight: response.blockNumber ? new bignumber_js_1.default(response.blockNumber) : undefined,
                amount: new bignumber_js_1.default(response.value.toHexString(), 16),
                pending: response.blockNumber ? false : true,
                confirmed: response.confirmations >= this.minConfirm
            };
        });
    }
    ownerToAddress(owner) {
        // return (
        //   "0x" +
        //   keccak256(Buffer.from(owner.slice(1)))
        //     .slice(-20)
        //     .toString("hex")
        // );
        // return owner;
        return owner.toString().toLowerCase();
    }
    sign(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const signer = yield this.getSigner();
            return signer.sign(data);
        });
    }
    getSigner() {
        if (!this.signer) {
            this.signer = new web_1.InjectedTypedEthereumSigner(this.wallet);
        }
        return this.signer;
    }
    verify(pub, data, signature) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return ethereumSigner.verify(pub, data, signature);
        });
    }
    getCurrentHeight() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = this.providerInstance;
            const response = yield provider.send("eth_blockNumber", []);
            return new bignumber_js_1.default(response, 16);
        });
    }
    getFee(amount, to) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = this.providerInstance;
            const tx = {
                to,
                from: this.address,
                value: "0x" + new bignumber_js_1.default(amount).toString(16)
            };
            const estimatedGas = yield provider.estimateGas(tx);
            const gasPrice = yield provider.getGasPrice();
            return new bignumber_js_1.default(estimatedGas.mul(gasPrice).toString());
        });
    }
    sendTx(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const signer = this.w3signer;
            const receipt = yield signer.sendTransaction(data); // .catch((e) => { console.error(`Sending tx: ${e}`) })
            return receipt ? receipt.hash : undefined;
        });
    }
    createTx(amount, to, _fee) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const amountc = bignumber_1.BigNumber.from(new bignumber_js_1.default(amount).toFixed());
            const signer = this.w3signer;
            const estimatedGas = yield signer.estimateGas({
                to,
                from: this.address,
                value: amountc.toHexString()
            });
            let gasPrice = yield signer.getGasPrice();
            if (this.name === "matic") {
                gasPrice = bignumber_1.BigNumber.from(new bignumber_js_1.default(gasPrice.toString()).multipliedBy(10).decimalPlaces(0).toString());
            }
            const txr = yield signer.populateTransaction({
                to,
                from: this.address,
                value: amountc.toHexString(),
                gasPrice,
                gasLimit: estimatedGas
            });
            return {
                txId: undefined,
                tx: txr
            };
        });
    }
    getPublicKey() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.address;
        });
    }
    ready() {
        var _a, _b;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            this.w3signer = yield this.wallet.getSigner();
            this._address = (yield this.w3signer.getAddress()).toString().toLowerCase();
            yield this.getSigner().ready();
            // this.providerInstance = new .JsonRpcProvider(this.providerUrl);
            this.providerInstance = this.wallet;
            yield (_b = (_a = this.providerInstance) === null || _a === void 0 ? void 0 : _a._ready) === null || _b === void 0 ? void 0 : _b.call(_a);
        });
    }
}
exports.default = EthereumConfig; //# sourceMappingURL=ethereum.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/near.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const web_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/webIndex.js [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const crypto_1 = __turbopack_require__("[project]/node_modules/.pnpm/@near-js+crypto@0.0.3/node_modules/@near-js/crypto/lib/index.js [app-route] (ecmascript)");
const keystores_browser_1 = __turbopack_require__("[project]/node_modules/.pnpm/@near-js+keystores-browser@0.0.3/node_modules/@near-js/keystores-browser/lib/index.js [app-route] (ecmascript)");
const transactions_1 = __turbopack_require__("[project]/node_modules/.pnpm/@near-js+transactions@0.1.1/node_modules/@near-js/transactions/lib/index.js [app-route] (ecmascript)");
const bs58_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bs58@5.0.0/node_modules/bs58/index.js [app-route] (ecmascript)"));
const borsh_1 = __turbopack_require__("[project]/node_modules/.pnpm/borsh@2.0.0/node_modules/borsh/lib/cjs/index.js [app-route] (ecmascript)");
const bn_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const js_sha256_1 = __turbopack_require__("[project]/node_modules/.pnpm/js-sha256@0.9.0/node_modules/js-sha256/src/sha256.js [app-route] (ecmascript)");
const base_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/base.js [app-route] (ecmascript)"));
class NearConfig extends base_1.default {
    constructor(config){
        super(config);
        this.near = this.wallet._near;
        this.base = [
            "yoctoNEAR",
            1e25
        ];
    // this.keyPair = KeyPair.fromString(this.wallet)
    }
    ready() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.wallet.isSignedIn()) {
                throw new Error("Wallet has not been signed in!");
            }
            const keystore = new keystores_browser_1.BrowserLocalStorageKeyStore();
            const account = this.wallet.account();
            // console.log(this.address)
            // console.log(await account.getAccessKeys())
            // this._address = this.wallet.getAccountId()
            // this.keyPair = KeyPair.fromString(this.wallet)
            // console.log(await account.getAccessKeys())
            this.keyPair = yield keystore.getKey(this.wallet._networkId, account.accountId);
            if (!this.keyPair) {
                this.keyPair = crypto_1.KeyPair.fromRandom("ed25519");
                const publicKey = this.keyPair.getPublicKey().toString();
                // this.wallet._networkId
                yield keystore.setKey(this.wallet._networkId, account.accountId, this.keyPair);
                // can't do this :c
                // console.log(publicKey)
                yield account.addKey(publicKey);
            }
            // console.log(this.keyPair.getPublicKey().toString());
            // this._address = this.ownerToAddress(Buffer.from(this.keyPair.getPublicKey().data));
            this._address = yield this.wallet.getAccountId();
            // this.providerInstance = new providers.JsonRpcProvider({ url: this.providerUrl });
            this.providerInstance = this.wallet._near.connection.provider;
        // console.log(this.keyPair);
        });
    }
    /**
     * NEAR wants both the sender ID and tx Hash, so we have to concatenate to keep with the interface.
     * @param txId assumes format senderID:txHash
     */ getTx(txId) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            // NOTE: their type defs are out of date with their actual API (23-01-2022)... beware the expect-error when debugging!
            const provider = yield this.providerInstance;
            const [id, hash] = txId.split(":");
            const status = yield provider.txStatusReceipts(bs58_1.default.decode(hash), id);
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            const blockHeight = yield provider.block(status.transaction_outcome.block_hash);
            const latestBlockHeight = (yield provider.block({
                finality: "final"
            })).header.height;
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            if (status.receipts_outcome[0].outcome.status.SuccessValue !== "") {
                throw new Error("Transaction failed!");
            }
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            const deposit = (_a = status.receipts[0].receipt.Action.actions[0].Transfer.deposit) !== null && _a !== void 0 ? _a : 0;
            // console.log(decode(status.receipts_outcome[0].block_hash))
            // // const routcometx = await provider.txStatusReceipts(decode(status.receipts_outcome[0].block_hash), status.receipts_outcome[0].id)
            // console.log({ blockHeight, status, latestBlockHeight })
            return {
                from: id,
                to: status.transaction.receiver_id,
                amount: new bignumber_js_1.default(deposit),
                blockHeight: new bignumber_js_1.default(blockHeight.header.height),
                pending: false,
                confirmed: latestBlockHeight - blockHeight.header.height >= this.minConfirm
            };
        });
    }
    /**
     * address = accountID
     * @param owner // assumed to be the "ed25519:" header + b58 encoded key
     */ ownerToAddress(owner) {
        // should just return the loaded address?
        const pubkey = typeof owner === "string" ? owner : bs58_1.default.encode(owner);
        return Buffer.from(bs58_1.default.decode(pubkey.replace("ed25519:", ""))).toString("hex");
    }
    sign(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.getSigner().sign(data);
        });
    }
    getSigner() {
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        return new web_1.NearSigner(this.keyPair.secretKey);
    }
    verify(pub, data, signature) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return web_1.NearSigner.verify(pub, data, signature);
        });
    }
    getCurrentHeight() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            // const provider = await this.getProvider();
            const res = yield this.providerInstance.status();
            return new bignumber_js_1.default(res.sync_info.latest_block_height);
        });
    }
    getFee(_amount, _to) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            // const provider = await this.getProvider();
            // one unit of gas
            // const res = await provider.connection.provider.gasPrice(await (await this.getCurrentHeight()).toNumber())
            const latestBlockHeight = (yield this.providerInstance.block({
                finality: "final"
            })).header.height;
            const res = yield this.providerInstance.gasPrice(latestBlockHeight); // null == gas price as of latest block
            // multiply by action cost in gas units (assume only action is transfer)
            // 4.5x10^11 gas units for fund transfers
            return new bignumber_js_1.default(res.gas_price).multipliedBy(450000000000);
        });
    }
    sendTx(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            data;
            const res = yield this.providerInstance.sendTransaction(data);
            return `${this.address}:${res.transaction.hash}`; // encode into compound format
        });
    }
    createTx(amount, to, _fee) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.address) throw new Error("Address is undefined - you might be missing a wallet, or have not run Irys.ready()");
            const accessKey = yield this.providerInstance.query({
                request_type: "view_access_key",
                finality: "final",
                account_id: this.address,
                public_key: this.keyPair.getPublicKey().toString()
            });
            // console.log(accessKey);
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            const nonce = ++accessKey.nonce;
            const recentBlockHash = Buffer.from(bs58_1.default.decode(accessKey.block_hash));
            const actions = [
                transactions_1.actionCreators.transfer(new bn_js_1.default(new bignumber_js_1.default(amount).toString()))
            ];
            const tx = (0, transactions_1.createTransaction)(this.address, this.keyPair.getPublicKey(), to, nonce, actions, recentBlockHash);
            const serialTx = (0, borsh_1.serialize)(transactions_1.SCHEMA, tx);
            const serialTxHash = new Uint8Array(js_sha256_1.sha256.array(serialTx));
            const signature = this.keyPair.sign(serialTxHash);
            const signedTx = new transactions_1.SignedTransaction({
                transaction: tx,
                signature: new transactions_1.Signature({
                    keyType: tx.publicKey.keyType,
                    data: signature.signature
                })
            });
            return {
                tx: signedTx,
                txId: undefined
            };
        });
    }
    getPublicKey() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return Buffer.from(this.keyPair.getPublicKey().data);
        });
    }
}
exports.default = NearConfig; //# sourceMappingURL=near.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/solana.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const web_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/webIndex.js [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const base_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/base.js [app-route] (ecmascript)"));
const bs58_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bs58@5.0.0/node_modules/bs58/index.js [app-route] (ecmascript)"));
const async_retry_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/async-retry@1.3.3/node_modules/async-retry/lib/index.js [app-route] (ecmascript)"));
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
class SolanaConfig extends base_1.default {
    constructor(config){
        var _a, _b;
        super(config);
        this.minConfirm = 1;
        this.finality = "finalized";
        this.base = [
            "lamports",
            1e9
        ];
        this.finality = (_b = (_a = this === null || this === void 0 ? void 0 : this.opts) === null || _a === void 0 ? void 0 : _a.finality) !== null && _b !== void 0 ? _b : "finalized";
    }
    getProvider() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.providerInstance) {
                this.providerInstance = new web3_js_1.Connection(this.providerUrl, {
                    confirmTransactionInitialTimeout: 60000,
                    commitment: this.finality
                });
            }
            return this.providerInstance;
        });
    }
    getTx(txId) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const connection = yield this.getProvider();
            const stx = yield connection.getTransaction(txId, {
                commitment: this.finality,
                maxSupportedTransactionVersion: 0
            });
            if (!stx) throw new Error("Confirmed tx not found");
            const currentSlot = yield connection.getSlot(this.finality);
            if (!stx.meta) throw new Error(`Unable to resolve transaction ${txId}`);
            const amount = new bignumber_js_1.default(stx.meta.postBalances[1]).minus(new bignumber_js_1.default(stx.meta.preBalances[1]));
            const staticAccountKeys = stx.transaction.message.getAccountKeys().staticAccountKeys;
            const tx = {
                from: staticAccountKeys[0].toBase58(),
                to: staticAccountKeys[1].toBase58(),
                amount: amount,
                blockHeight: new bignumber_js_1.default(stx.slot),
                pending: false,
                confirmed: currentSlot - stx.slot >= 1
            };
            return tx;
        });
    }
    ownerToAddress(owner) {
        if (typeof owner === "string") {
            owner = Buffer.from(owner);
        }
        return bs58_1.default.encode(owner);
    }
    sign(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return yield (yield this.getSigner()).sign(data);
        });
    }
    getSigner() {
        if (!this.signer) {
            // if (this.wallet?.name === "Phantom") {
            //     this.signer = new PhantomSigner(this.wallet)
            // } else {
            //     this.signer = new InjectedSolanaSigner(this.wallet)
            // }
            this.signer = new web_1.HexInjectedSolanaSigner(this.wallet);
        }
        return this.signer;
    }
    verify(pub, data, signature) {
        // if (this.wallet?.name === "Phantom") {
        //     return PhantomSigner.verify(pub, data, signature)
        // }
        // return InjectedSolanaSigner.verify(pub, data, signature);
        return web_1.HexInjectedSolanaSigner.verify(pub, data, signature);
    }
    getCurrentHeight() {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return new bignumber_js_1.default((_a = (yield (yield this.getProvider()).getEpochInfo()).blockHeight) !== null && _a !== void 0 ? _a : 0);
        });
    }
    getFee(amount, to, multiplier) {
        var _a, _b, _c;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const connection = yield this.getProvider();
            const unsignedTx = yield this._createTxUnsigned(amount, to !== null && to !== void 0 ? to : "DHyDV2ZjN3rB6qNGXS48dP5onfbZd3fAEz6C5HJwSqRD");
            const computeBudget = new bignumber_js_1.default((_a = yield unsignedTx.getEstimatedFee(connection)) !== null && _a !== void 0 ? _a : 5000);
            const recentPrio = yield (_b = connection === null || connection === void 0 ? void 0 : connection.getRecentPrioritizationFees) === null || _b === void 0 ? void 0 : _b.call(connection).catch((_)=>[
                    {
                        prioritizationFee: 0
                    }
                ]);
            const prioAvg = recentPrio.reduce((n, p)=>n.plus(p.prioritizationFee), new bignumber_js_1.default(0)).dividedToIntegerBy((_c = recentPrio.length) !== null && _c !== void 0 ? _c : 1);
            return {
                computeBudget,
                computeUnitPrice: prioAvg.multipliedBy(multiplier !== null && multiplier !== void 0 ? multiplier : 1).integerValue(bignumber_js_1.default.ROUND_CEIL)
            };
        });
    }
    sendTx(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return yield this.wallet.sendTransaction(data, (yield this.getProvider()), {
                skipPreflight: true
            });
        });
    }
    _createTxUnsigned(amount, to, fee) {
        var _a, _b;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const pubkey = new web3_js_1.PublicKey((yield this.getPublicKey()));
            const blockHashInfo = yield (0, async_retry_1.default)((bail)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    var _c;
                    try {
                        return yield (yield this.getProvider()).getLatestBlockhash(this.finality);
                    } catch (e) {
                        if ((_c = e.message) === null || _c === void 0 ? void 0 : _c.includes("blockhash")) throw e;
                        else bail(e);
                        throw new Error("Unreachable");
                    }
                }), {
                retries: 3,
                minTimeout: 1000
            });
            const transaction = new web3_js_1.Transaction(Object.assign(Object.assign({}, blockHashInfo), {
                feePayer: pubkey
            }));
            transaction.add(web3_js_1.SystemProgram.transfer({
                fromPubkey: pubkey,
                toPubkey: new web3_js_1.PublicKey(to),
                lamports: +new bignumber_js_1.default(amount).toNumber()
            }));
            if (!((_b = (_a = this === null || this === void 0 ? void 0 : this.config) === null || _a === void 0 ? void 0 : _a.opts) === null || _b === void 0 ? void 0 : _b.disablePriorityFees) && fee) {
                transaction.add(web3_js_1.ComputeBudgetProgram.setComputeUnitPrice({
                    microLamports: fee.computeUnitPrice.toNumber()
                }));
                transaction.add(web3_js_1.ComputeBudgetProgram.setComputeUnitLimit({
                    units: fee.computeBudget.toNumber()
                }));
            }
            return transaction;
        });
    }
    createTx(amount, to, _fee) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const transaction = yield this._createTxUnsigned(amount, to, _fee);
            return {
                tx: transaction,
                txId: undefined
            };
        });
    }
    getPublicKey() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.wallet.publicKey) throw new Error("Wallet.publicKey is undefined");
            return this.wallet.publicKey.toBuffer();
        });
    }
}
exports.default = SolanaConfig; //# sourceMappingURL=solana.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/erc20.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const contracts_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+contracts@5.7.0/node_modules/@ethersproject/contracts/lib.esm/index.js [app-route] (ecmascript)");
const ethereum_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/ethereum.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)");
class ERC20Config extends ethereum_1.default {
    constructor(config){
        super(config);
        this.contractAddress = config.contractAddress;
    }
    getContract() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.contractInstance) {
                // @ts-expect-error minimal type
                this.contractInstance = new contracts_1.Contract(this.contractAddress, utils_1.erc20abi, this.w3signer);
                this.base = [
                    "wei",
                    Math.pow(10, (yield this.contractInstance.decimals()))
                ];
            }
            return this.contractInstance;
        });
    }
    getTx(txId) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const response = yield this.providerInstance.getTransaction(txId);
            if (!response) throw new Error("Tx doesn't exist");
            if (response.data.length !== 138 || response.data.slice(2, 10) !== "a9059cbb" // standard ERC20-ABI method ID for transfers
            ) {
                throw new Error("Tx isn't a ERC20 transfer");
            }
            const to = `0x${response.data.slice(34, 74)}`;
            const amount = new bignumber_js_1.default(response.data.slice(74), 16);
            return {
                from: response.from,
                to,
                blockHeight: response.blockNumber ? new bignumber_js_1.default(response.blockNumber) : undefined,
                amount,
                pending: response.blockNumber ? false : true,
                confirmed: response.confirmations >= this.minConfirm
            };
        });
    }
    getFee(amount, to) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const _amount = "0x" + new bignumber_js_1.default(amount).toString(16);
            const contract = yield this.getContract();
            const gasPrice = yield this.providerInstance.getGasPrice();
            const gasLimit = yield contract.estimateGas.transfer(to, _amount);
            const units = new bignumber_js_1.default(gasPrice.mul(gasLimit).toString()); // price in WEI
            return units;
        });
    }
    createTx(amount, to, _fee) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            // const provider = await this.getProvider()
            // const wallet = new Wallet(this.wallet, this.providerInstance);
            const contract = yield this.getContract();
            const _amount = "0x" + new bignumber_js_1.default(amount).toString(16);
            const tx = yield contract.populateTransaction.transfer(to, _amount);
            // Needed *specifically* for ERC20
            tx.gasPrice = yield this.providerInstance.getGasPrice();
            tx.gasLimit = yield contract.estimateGas.transfer(to, _amount);
            tx.chainId = (yield this.providerInstance.getNetwork()).chainId;
            if (!this.address) throw new Error("Address is undefined - you might be missing a wallet, or have not run Irys.ready()");
            tx.nonce = yield this.providerInstance.getTransactionCount(this.address);
            // const txr = this.w3signer.populateTransaction()
            // const signedTx = await this.wallet.signTransaction(tx);
            // const txId = "0x" + keccak256(Buffer.from(signedTx.slice(2), "hex")).toString("hex");
            return {
                txId: undefined,
                tx: tx
            };
        });
    }
}
exports.default = ERC20Config; //# sourceMappingURL=erc20.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/aptos.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const ts_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@aptos-labs+ts-sdk@1.33.1/node_modules/@aptos-labs/ts-sdk/dist/common/index.js [app-route] (ecmascript)");
const web_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/webIndex.js [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const js_sha3_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/js-sha3@0.8.0/node_modules/js-sha3/src/sha3.js [app-route] (ecmascript)"));
const base_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/base.js [app-route] (ecmascript)"));
class AptosConfig extends base_1.default {
    constructor(config){
        var _a;
        super(config);
        this.signingFn = (_a = config === null || config === void 0 ? void 0 : config.opts) === null || _a === void 0 ? void 0 : _a.signingFunction;
        this.base = [
            "octa",
            1e8
        ];
    }
    getProvider() {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return (_a = this.providerInstance) !== null && _a !== void 0 ? _a : this.providerInstance = new ts_sdk_1.Aptos(this.aptosConfig);
        });
    }
    getTx(txId) {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const client = yield this.getProvider();
            const tx = yield client.waitForTransaction({
                transactionHash: txId
            });
            const payload = tx === null || tx === void 0 ? void 0 : tx.payload;
            if (!tx.success) {
                throw new Error((_a = tx === null || tx === void 0 ? void 0 : tx.vm_status) !== null && _a !== void 0 ? _a : "Unknown Aptos error");
            }
            if (!((payload === null || payload === void 0 ? void 0 : payload.function) === "0x1::coin::transfer" && (payload === null || payload === void 0 ? void 0 : payload.type_arguments[0]) === "0x1::aptos_coin::AptosCoin" && (tx === null || tx === void 0 ? void 0 : tx.vm_status) === "Executed successfully")) {
                throw new Error(`Aptos tx ${txId} failed validation`);
            }
            const isPending = tx.type === "pending_transaction";
            return {
                to: payload.arguments[0],
                from: tx.sender,
                amount: new bignumber_js_1.default(payload.arguments[1]),
                pending: isPending,
                confirmed: !isPending
            };
        });
    }
    ownerToAddress(owner) {
        const hash = js_sha3_1.default.sha3_256.create();
        hash.update(Buffer.from(owner));
        hash.update("\x00");
        return `0x${hash.hex()}`;
    }
    sign(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return yield this.getSigner().sign(data);
        });
    }
    getSigner() {
        if (this.signerInstance) return this.signerInstance;
        if (this.signingFn) {
            const signer = new web_1.AptosSigner("", "0x" + this._publicKey.toString("hex"));
            signer.sign = this.signingFn; // override signer fn
            return this.signerInstance = signer;
        }
        return this.signerInstance = new web_1.InjectedAptosSigner(this.wallet, this._publicKey);
    }
    verify(pub, data, signature) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return yield web_1.InjectedAptosSigner.verify(pub, data, signature);
        });
    }
    getCurrentHeight() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return new bignumber_js_1.default((yield (yield this.getProvider()).getLedgerInfo()).block_height);
        });
    }
    getFee(amount, to) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const client = yield this.getProvider();
            if (!this.address) throw new Error("Address is undefined - you might be missing a wallet, or have not run Irys.ready()");
            const transaction = yield client.transaction.build.simple({
                sender: this.address,
                data: {
                    function: "0x1::coin::transfer",
                    typeArguments: [
                        "0x1::aptos_coin::AptosCoin"
                    ],
                    functionArguments: [
                        to !== null && to !== void 0 ? to : "0x149f7dc9c8e43c14ab46d3a6b62cfe84d67668f764277411f98732bf6718acf9",
                        new bignumber_js_1.default(amount).toNumber()
                    ]
                }
            });
            const accountAuthenticator = new ts_sdk_1.AccountAuthenticatorEd25519(new ts_sdk_1.Ed25519PublicKey((yield this.getPublicKey())), new ts_sdk_1.Ed25519Signature(new Uint8Array(64)));
            const transactionAuthenticator = new ts_sdk_1.TransactionAuthenticatorEd25519(accountAuthenticator.public_key, accountAuthenticator.signature);
            const signedSimulation = new ts_sdk_1.SignedTransaction(transaction.rawTransaction, transactionAuthenticator).bcsToBytes();
            const queryParams = {
                estimate_gas_unit_price: true,
                estimate_max_gas_amount: true
            };
            const { data } = yield (0, ts_sdk_1.postAptosFullNode)({
                aptosConfig: this.aptosConfig,
                body: signedSimulation,
                path: "transactions/simulate",
                params: queryParams,
                originMethod: "simulateTransaction",
                contentType: ts_sdk_1.MimeType.BCS_SIGNED_TRANSACTION
            });
            return {
                gasUnitPrice: +data[0].gas_unit_price,
                maxGasAmount: +data[0].max_gas_amount
            };
        // const simulationResult = await client.simulateTransaction(this.accountInstance, rawTransaction, { estimateGasUnitPrice: true, estimateMaxGasAmount: true });
        // return new BigNumber(simulationResult?.[0].gas_unit_price).multipliedBy(simulationResult?.[0].gas_used);
        // const est = await provider.client.transactions.estimateGasPrice();
        // return new BigNumber(est.gas_estimate/* (await (await this.getProvider()).client.transactions.estimateGasPrice()).gas_estimate */); // * by gas limit (for upper limit)
        });
    }
    sendTx(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (!this.signingFn) return (yield this.wallet.signAndSubmitTransaction(data)).hash;
            // return (await (await (this.getProvider())).submitSignedBCSTransaction(data)).hash;
            const provider = yield this.getProvider();
            const { data: postData } = yield (0, ts_sdk_1.postAptosFullNode)({
                aptosConfig: this.aptosConfig,
                body: data,
                path: "transactions",
                originMethod: "submitTransaction",
                contentType: ts_sdk_1.MimeType.BCS_SIGNED_TRANSACTION
            });
            yield provider.waitForTransaction({
                transactionHash: postData.hash
            });
            return postData.hash;
        });
    }
    createTx(amount, to, fee) {
        var _a, _b;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const txData = {
                sender: this.address,
                data: {
                    function: "0x1::coin::transfer",
                    typeArguments: [
                        "0x1::aptos_coin::AptosCoin"
                    ],
                    functionArguments: [
                        to,
                        new bignumber_js_1.default(amount).toNumber()
                    ]
                },
                options: {
                    gasUnitPrice: (_a = fee === null || fee === void 0 ? void 0 : fee.gasUnitPrice) !== null && _a !== void 0 ? _a : 100,
                    maxGasAmount: (_b = fee === null || fee === void 0 ? void 0 : fee.maxGasAmount) !== null && _b !== void 0 ? _b : 10
                }
            };
            if (!this.signingFn) return {
                txId: undefined,
                tx: txData
            };
            const client = yield this.getProvider();
            // @ts-expect-error type issue
            const transaction = yield client.transaction.build.simple(txData);
            const message = (0, ts_sdk_1.generateSigningMessageForTransaction)(transaction);
            const signerSignature = yield this.sign(message);
            const senderAuthenticator = new ts_sdk_1.AccountAuthenticatorEd25519(new ts_sdk_1.Ed25519PublicKey((yield this.getPublicKey())), new ts_sdk_1.Ed25519Signature(signerSignature));
            const signedTransaction = (0, ts_sdk_1.generateSignedTransaction)({
                transaction,
                senderAuthenticator
            });
            return {
                txId: undefined,
                tx: signedTransaction
            };
        });
    }
    getPublicKey() {
        var _a;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return (_a = this._publicKey) !== null && _a !== void 0 ? _a : this._publicKey = this.signingFn ? Buffer.from(this.wallet.slice(2), "hex") : Buffer.from(this.wallet.account.publicKey.toString().slice(2), "hex");
        });
    }
    ready() {
        var _a, _b, _c, _d;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            // In the Aptos context, this.providerUrl is the Aptos Network enum type we want
            // to work with. read more https://github.com/aptos-labs/aptos-ts-sdk/blob/main/src/api/aptosConfig.ts#L14
            // this.providerUrl is a Network enum type represents the current configured network
            this.aptosConfig = new ts_sdk_1.AptosConfig(Object.assign({
                network: this.providerUrl
            }, (_b = (_a = this.config) === null || _a === void 0 ? void 0 : _a.opts) === null || _b === void 0 ? void 0 : _b.aptosSdkConfig));
            this._publicKey = yield this.getPublicKey();
            this._address = this.ownerToAddress(this._publicKey);
            const client = yield this.getProvider();
            this._address = yield client.lookupOriginalAccountAddress({
                authenticationKey: (_c = this.address) !== null && _c !== void 0 ? _c : ""
            }).then((hs)=>hs.toString()).catch((_)=>this._address); // fallback to original
            if (((_d = this._address) === null || _d === void 0 ? void 0 : _d.length) == 66 && this._address.charAt(2) === "0") {
                this._address = this._address.slice(0, 2) + this._address.slice(3);
            }
        });
    }
}
exports.default = AptosConfig; //# sourceMappingURL=aptos.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/providers/ethereum/ethersv5.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.EthereumEthersV5 = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const ethereum_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/ethereum.js [app-route] (ecmascript)"));
class EthereumEthersV5 extends ethereum_1.default {
}
exports.EthereumEthersV5 = EthereumEthersV5; //# sourceMappingURL=ethersv5.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/providers/ethereum/ethersv6.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.EthereumEthersV6 = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const bignumber_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+bignumber@5.7.0/node_modules/@ethersproject/bignumber/lib.esm/index.js [app-route] (ecmascript)");
const ethereum_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/ethereum.js [app-route] (ecmascript)"));
class EthereumEthersV6 extends ethereum_1.default {
    createTx(amount, to, _fee) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const signer = this.w3signer;
            const tx = {
                to,
                from: this.address,
                value: amount.toString(),
                gasLimit: BigInt(0)
            };
            const estimatedGas = yield this.provider.estimateGas(tx);
            tx.gasLimit = estimatedGas;
            const txr = yield signer.populateTransaction(tx);
            return {
                tx: txr,
                txId: undefined
            };
        });
    }
    getTx(txId) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = this.provider;
            const response = yield provider.getTransaction(txId);
            if (!response) throw new Error("Tx doesn't exist");
            if (!response.to) throw new Error(`Unable to resolve transactions ${txId} receiver`);
            return {
                from: response.from,
                to: response.to,
                blockHeight: response.blockNumber ? new bignumber_js_1.default(response.blockNumber) : undefined,
                amount: new bignumber_js_1.default(response.value.toString()),
                pending: response.blockNumber ? false : true,
                confirmed: (yield response.confirmations()) >= this.minConfirm
            };
        });
    }
    getFee(amount, to) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = this.providerInstance;
            const tx = {
                to,
                from: this.address,
                value: "0x" + new bignumber_js_1.default(amount).toString(16)
            };
            const estimatedGas = yield provider.estimateGas(tx);
            const gasPrice = yield provider.getGasPrice();
            return new bignumber_js_1.default(gasPrice.mul(estimatedGas).toString());
        });
    }
    ready() {
        const _super = Object.create(null, {
            ready: {
                get: ()=>super.ready
            }
        });
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const provider = this.wallet;
            this.provider = provider;
            const signer = yield provider.getSigner();
            signer._signTypedData = (domain, types, value)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    return signer.signTypedData(domain, types, value);
                });
            // @ts-expect-error fix
            provider.getSigner = ()=>signer;
            // @ts-expect-error fix
            this.wallet = provider;
            provider.getGasPrice = ()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                    return provider.getFeeData().then((r)=>{
                        var _a;
                        return bignumber_1.BigNumber.from((_a = r.gasPrice) !== null && _a !== void 0 ? _a : 0);
                    });
                });
            // @ts-expect-error fix
            this.providerInstance = provider;
            yield _super.ready.call(this);
        });
    }
}
exports.EthereumEthersV6 = EthereumEthersV6; //# sourceMappingURL=ethersv6.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/arweave.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ArweaveWebIrys = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const arbundles_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/index.js [app-route] (ecmascript)");
const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const crypto_1 = tslib_1.__importDefault(__turbopack_require__("[externals]/crypto [external] (crypto, cjs)"));
const base64url_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/utils.js [app-route] (ecmascript)");
const base_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/base.js [app-route] (ecmascript)"));
const base_2 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/base.js [app-route] (ecmascript)");
class ArweaveConfig extends base_1.default {
    constructor(config){
        super(config);
        this.isSlow = true;
        this.base = [
            "winston",
            1e12
        ];
        this.needsFee = true;
    }
    getProvider() {
        var _a, _b;
        if (!this.providerInstance) {
            const purl = new URL((_a = this.providerUrl) !== null && _a !== void 0 ? _a : "https://arweave.net");
            // let config;
            // try {
            //   config = this.wallet.getArweaveConfig();
            // } catch (e) {}
            this.providerInstance = utils_1.Arweave.init(/* config ??  */ {
                url: purl,
                network: (_b = this === null || this === void 0 ? void 0 : this.opts) === null || _b === void 0 ? void 0 : _b.network
            });
        }
        return this.providerInstance;
    }
    getTx(txId) {
        var _a, _b, _c, _d;
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const arweave = yield this.getProvider();
            const txs = yield arweave.transactions.getStatus(txId);
            let tx;
            if (txs.status === 200) {
                tx = yield arweave.transactions.get(txId);
            }
            const confirmed = txs.status !== 202 && ((_b = (_a = txs.confirmed) === null || _a === void 0 ? void 0 : _a.number_of_confirmations) !== null && _b !== void 0 ? _b : 0) >= this.minConfirm;
            let owner;
            if (tx === null || tx === void 0 ? void 0 : tx.owner) {
                owner = this.ownerToAddress(tx.owner);
            }
            return {
                from: owner !== null && owner !== void 0 ? owner : undefined,
                to: (_c = tx === null || tx === void 0 ? void 0 : tx.target) !== null && _c !== void 0 ? _c : undefined,
                amount: new bignumber_js_1.default((_d = tx === null || tx === void 0 ? void 0 : tx.quantity) !== null && _d !== void 0 ? _d : 0),
                pending: txs.status === 202,
                confirmed
            };
        });
    }
    ownerToAddress(owner) {
        return utils_1.Arweave.utils.bufferTob64Url(crypto_1.default.createHash("sha256").update(utils_1.Arweave.utils.b64UrlToBuffer(Buffer.isBuffer(owner) ? (0, base64url_1.default)(owner) : owner)).digest());
    }
    sign(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return this.getSigner().sign(data);
        });
    }
    getSigner() {
        var _a, _b;
        if (this.signerInstance) return this.signerInstance;
        switch((_b = (_a = this === null || this === void 0 ? void 0 : this.opts) === null || _a === void 0 ? void 0 : _a.provider) !== null && _b !== void 0 ? _b : "arconnect"){
            case "arconnect":
                this.signerInstance = new arbundles_1.ArconnectSigner(this.wallet, this.getProvider());
        }
        return this.signerInstance;
    }
    verify(pub, data, signature) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            if (Buffer.isBuffer(pub)) {
                pub = pub.toString();
            }
            return this.getProvider().crypto.verify(pub, data, signature);
        });
    }
    getCurrentHeight() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return (yield this.getProvider()).network.getInfo().then((r)=>new bignumber_js_1.default(r.height));
        });
    }
    getFee(amount, to) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return new bignumber_js_1.default((yield (yield this.getProvider()).transactions.getPrice(new bignumber_js_1.default(amount).toNumber(), to))).integerValue(bignumber_js_1.default.ROUND_CEIL);
        });
    }
    sendTx(data) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            return yield (yield this.getProvider()).transactions.post(data);
        });
    }
    createTx(amount, to, fee) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const arweave = yield this.getProvider();
            const atx = yield arweave.createTransaction({
                quantity: new bignumber_js_1.default(amount).toString(),
                reward: fee === null || fee === void 0 ? void 0 : fee.toString(),
                target: to
            });
            // @ts-expect-error override
            atx.merkle = undefined;
            // @ts-expect-error override
            atx.deepHash = undefined;
            // @ts-expect-error types
            const tx = yield this.wallet.sign(atx);
            return {
                txId: tx.id,
                tx
            };
        });
    }
    getPublicKey() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const signer = this.getSigner();
            yield signer.setPublicKey();
            return utils_1.Arweave.utils.bufferTob64Url(signer.publicKey);
        });
    }
    ready() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const pubKey = yield this.getPublicKey();
            const address = this.ownerToAddress(pubKey);
            this._address = address;
        });
    }
}
exports.default = ArweaveConfig;
class ArweaveWebIrys extends base_2.BaseWebIrys {
    constructor({ url, wallet, config }){
        super({
            url,
            wallet,
            config,
            getTokenConfig: (irys)=>{
                var _a;
                return new ArweaveConfig({
                    irys,
                    name: "arweave",
                    ticker: "AR",
                    providerUrl: (_a = config === null || config === void 0 ? void 0 : config.providerUrl) !== null && _a !== void 0 ? _a : "https://arweave.net",
                    wallet: wallet.provider
                });
            }
        });
    }
}
exports.ArweaveWebIrys = ArweaveWebIrys; //# sourceMappingURL=arweave.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/shims/privy.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.augmentTokenPrivy = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
function augmentTokenPrivy(tokenConfig, opts) {
    return tslib_1.__awaiter(this, void 0, void 0, function*() {
        if (!opts.sendTransaction) throw new Error("missing required sendTransaction function - add sendTransaction from the usePrivy hook to the wallet object");
        const sendTransaction = opts.sendTransaction;
        tokenConfig.sendTx = (data)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                return sendTransaction(Object.assign(Object.assign({}, data), {
                    gasLimit: data.gasLimit.toHexString(),
                    maxFeePerGas: data.maxFeePerGas.toHexString(),
                    maxPriorityFeePerGas: data.maxPriorityFeePerGas.toHexString()
                })).then((r)=>r.transactionHash);
            });
    });
}
exports.augmentTokenPrivy = augmentTokenPrivy; //# sourceMappingURL=privy.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/shims/viemv2.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.augmentViemV2 = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
/* eslint-disable @typescript-eslint/explicit-function-return-type */ const bignumber_js_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const web_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/webIndex.js [app-route] (ecmascript)");
// TODO: figure out a better way to do this.
function augmentViemV2(tokenConfig, opts) {
    var _a;
    const walletClient = opts.provider;
    const publicClient = opts.publicClient;
    const accountIndex = (_a = opts.accountIndex) !== null && _a !== void 0 ? _a : 0;
    tokenConfig.ready = (function() {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            yield this.getSigner().ready();
            this._address = yield walletClient.getAddresses().then((r)=>r[accountIndex].toString().toLowerCase());
            this.providerInstance = this.wallet;
        });
    }).bind(tokenConfig);
    tokenConfig.getFee = (_amount)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
            return new bignumber_js_1.default(0);
        });
    tokenConfig.getSigner = (function() {
        if (!this.signer) {
            this.signer = new web_1.InjectedTypedEthereumSigner({
                getSigner: ()=>({
                        getAddress: ()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                                return walletClient.getAddresses().then((r)=>r[accountIndex]);
                            }),
                        _signTypedData: (domain, types, message)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                                message["Transaction hash"] = "0x" + Buffer.from(message["Transaction hash"]).toString("hex");
                                // @ts-expect-error types
                                return yield walletClient.signTypedData({
                                    account: message.address,
                                    domain,
                                    types,
                                    primaryType: "Bundlr",
                                    message
                                });
                            })
                    })
            });
        }
        return this.signer;
    }).bind(tokenConfig);
    tokenConfig.getCurrentHeight = ()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
            return new bignumber_js_1.default((yield publicClient.getBlockNumber()).toString());
        });
    // if this is ERC20
    if (tokenConfig.contractAddress) {
        throw new Error("viemv2 is not supported for ERC20 tokens");
    } else {
        // this is a full chain
        tokenConfig.getTx = (txId)=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                const tx = yield publicClient.getTransaction({
                    hash: txId
                });
                const currentHeight = yield publicClient.getBlockNumber();
                return {
                    to: tx.to,
                    from: tx.from,
                    blockHeight: new bignumber_js_1.default(tx.blockNumber.toString()),
                    amount: new bignumber_js_1.default(tx.value.toString()),
                    pending: tx.blockNumber ? false : true,
                    confirmed: currentHeight - tx.blockNumber >= tokenConfig.minConfirm
                };
            });
        tokenConfig.createTx = (function(amount, to) {
            return tslib_1.__awaiter(this, void 0, void 0, function*() {
                const config = {
                    account: tokenConfig.address,
                    to,
                    value: amount.toString()
                };
                return {
                    txId: undefined,
                    tx: config
                };
            });
        }).bind(tokenConfig);
        tokenConfig.sendTx = function(data) {
            return tslib_1.__awaiter(this, void 0, void 0, function*() {
                return yield walletClient.sendTransaction({
                    account: data.account,
                    to: data.to,
                    value: data.value,
                    chain: walletClient.chain
                });
            });
        };
    }
}
exports.augmentViemV2 = augmentViemV2; //# sourceMappingURL=viemv2.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const ethereum_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/ethereum.js [app-route] (ecmascript)"));
const near_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/near.js [app-route] (ecmascript)"));
const solana_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/solana.js [app-route] (ecmascript)"));
const erc20_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/erc20.js [app-route] (ecmascript)"));
const axios_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/axios@1.7.9/node_modules/axios/dist/node/axios.cjs [app-route] (ecmascript)"));
const utils_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/utils.js [app-route] (ecmascript)"));
const aptos_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/aptos.js [app-route] (ecmascript)"));
const ethersv5_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/providers/ethereum/ethersv5.js [app-route] (ecmascript)");
const ethersv6_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/providers/ethereum/ethersv6.js [app-route] (ecmascript)");
const arweave_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/arweave.js [app-route] (ecmascript)"));
const privy_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/shims/privy.js [app-route] (ecmascript)");
const viemv2_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/shims/viemv2.js [app-route] (ecmascript)");
const ts_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@aptos-labs+ts-sdk@1.33.1/node_modules/@aptos-labs/ts-sdk/dist/common/index.js [app-route] (ecmascript)");
function getTokenConfig({ irys, token, wallet, providerUrl, contractAddress, providerName, tokenOpts: opts }) {
    switch(token){
        case "ethereum":
            return resolveProvider({
                family: "ethereum",
                providerName,
                config: {
                    irys: irys,
                    name: "ethereum",
                    ticker: "ETH",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://cloudflare-eth.com/",
                    wallet: wallet,
                    opts
                }
            });
        case "matic":
            return resolveProvider({
                family: "ethereum",
                providerName,
                config: {
                    irys: irys,
                    name: "matic",
                    ticker: "MATIC",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://polygon-rpc.com",
                    wallet: wallet,
                    minConfirm: 1,
                    opts
                }
            });
        case "arbitrum":
            return resolveProvider({
                family: "ethereum",
                providerName,
                config: {
                    irys: irys,
                    name: "arbitrum",
                    ticker: "ETH",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://arb1.arbitrum.io/rpc",
                    wallet: wallet,
                    opts
                }
            });
        case "bnb":
            return resolveProvider({
                family: "ethereum",
                providerName,
                config: {
                    irys: irys,
                    name: "bnb",
                    ticker: "BNB",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://bsc-dataseed.binance.org",
                    wallet: wallet,
                    opts
                }
            });
        case "avalanche":
            return resolveProvider({
                family: "ethereum",
                providerName,
                config: {
                    irys: irys,
                    name: "avalanche",
                    ticker: "AVAX",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://api.avax.network/ext/bc/C/rpc",
                    wallet: wallet,
                    opts
                }
            });
        case "boba-eth":
            return resolveProvider({
                family: "ethereum",
                providerName,
                config: {
                    irys: irys,
                    name: "boba-eth",
                    ticker: "ETH",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://mainnet.boba.network/",
                    minConfirm: 1,
                    wallet: wallet,
                    opts
                }
            });
        case "boba":
            {
                const k = new erc20_1.default({
                    irys: irys,
                    name: "boba",
                    ticker: "BOBA",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://mainnet.boba.network/",
                    contractAddress: contractAddress !== null && contractAddress !== void 0 ? contractAddress : "0xa18bF3994C0Cc6E3b63ac420308E5383f53120D7",
                    minConfirm: 1,
                    wallet: wallet,
                    opts
                });
                // for L1 mainnet: "https://main-light.eth.linkpool.io/" and "0x42bbfa2e77757c645eeaad1655e0911a7553efbc"
                k.price = ()=>tslib_1.__awaiter(this, void 0, void 0, function*() {
                        var _a;
                        const res = yield axios_1.default.post("https://api.livecoinwatch.com/coins/single", JSON.stringify({
                            currency: "USD",
                            code: `${k.ticker}`
                        }), {
                            headers: {
                                "x-api-key": "75a7a824-6577-45e6-ad86-511d590c7cc8",
                                "content-type": "application/json"
                            }
                        });
                        yield utils_1.default.checkAndThrow(res, "Getting price data");
                        if (!((_a = res === null || res === void 0 ? void 0 : res.data) === null || _a === void 0 ? void 0 : _a.rate)) {
                            throw new Error(`unable to get price for ${k.name}`);
                        }
                        return +res.data.rate;
                    });
                return k;
            }
        case "solana":
            return new solana_1.default({
                irys: irys,
                name: "solana",
                ticker: "SOL",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://api.mainnet-beta.solana.com/",
                wallet: wallet,
                opts
            });
        // case "algorand":
        //     return new AlgorandConfig({ name: "algorand", ticker: "ALGO", providerUrl: providerUrl ?? "https://api.mainnet-beta.solana.com/", wallet: wallet })
        case "near":
            return new near_1.default({
                irys: irys,
                name: "near",
                ticker: "NEAR",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://rpc.mainnet.near.org",
                wallet: wallet,
                opts
            });
        case "aptos":
            return new aptos_1.default({
                irys: irys,
                name: "aptos",
                ticker: "APTOS",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : ts_sdk_1.Network.MAINNET,
                wallet: wallet,
                opts
            });
        case "arweave":
            return new arweave_1.default({
                irys: irys,
                name: "arweave",
                ticker: "AR",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://arweave.net",
                wallet: wallet,
                opts
            });
        case "base-eth":
            return resolveProvider({
                family: "ethereum",
                providerName,
                config: {
                    irys: irys,
                    name: "base-eth",
                    ticker: "ETH",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://mainnet.base.org/",
                    minConfirm: 2,
                    wallet: wallet,
                    opts
                }
            });
        case "usdc-eth":
            return new erc20_1.default({
                irys: irys,
                name: "usdc-eth",
                ticker: "USDC",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://cloudflare-eth.com/",
                contractAddress: contractAddress !== null && contractAddress !== void 0 ? contractAddress : "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
                wallet,
                opts
            });
        case "usdc-polygon":
            return new erc20_1.default({
                irys,
                name: "usdc-polygon",
                ticker: "USDC",
                providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://polygon-rpc.com",
                contractAddress: contractAddress !== null && contractAddress !== void 0 ? contractAddress : "0x3c499c542cef5e3811e1192ce70d8cc03d5c3359",
                opts
            });
        case "bera":
            return resolveProvider({
                family: "ethereum",
                providerName,
                config: {
                    irys: irys,
                    name: "bera",
                    ticker: "BERA",
                    // TODO: make sure this is set to mainnet
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://bartio.rpc.berachain.com/",
                    wallet: wallet,
                    opts
                }
            });
        case "scroll-eth":
            return resolveProvider({
                family: "ethereum",
                providerName,
                config: {
                    irys: irys,
                    name: "scroll-eth",
                    ticker: "ETH",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://rpc.scroll.io",
                    wallet: wallet,
                    opts
                }
            });
        case "linea-eth":
            return resolveProvider({
                family: "ethereum",
                providerName,
                config: {
                    irys: irys,
                    name: "linea-eth",
                    ticker: "ETH",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://rpc.linea.build",
                    wallet: wallet,
                    opts
                }
            });
        case "iotex":
            return resolveProvider({
                family: "ethereum",
                providerName,
                config: {
                    irys: irys,
                    name: "iotex",
                    ticker: "IOTX",
                    providerUrl: providerUrl !== null && providerUrl !== void 0 ? providerUrl : "https://babel-api.mainnet.iotex.io/",
                    wallet: wallet,
                    opts
                }
            });
        default:
            throw new Error(`Unknown/Unsupported token ${token}`);
    }
}
exports.default = getTokenConfig;
function resolveProvider({ family, providerName, config }) {
    let cfg;
    switch(family){
        case "ethereum":
            switch(providerName){
                case "ethersv5":
                    return new ethersv5_1.EthereumEthersV5(config);
                case "ethersv6":
                    return new ethersv6_1.EthereumEthersV6(config);
                case "privy-embedded":
                    cfg = new ethersv5_1.EthereumEthersV5(config);
                    (0, privy_1.augmentTokenPrivy)(cfg, config.opts);
                    return cfg;
                case "viemv2":
                    cfg = new ethereum_1.default(config);
                    (0, viemv2_1.augmentViemV2)(cfg, config.opts);
                    return cfg;
                default:
                    return new ethereum_1.default(config);
            }
        default:
            throw new Error(`Unknown token family ${family}`);
    }
} //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/irys.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WebIrys = void 0;
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
const base_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/base.js [app-route] (ecmascript)");
const tokens_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/tokens/index.js [app-route] (ecmascript)"));
class WebIrys extends base_1.BaseWebIrys {
    constructor({ url, network, token, wallet, config }){
        super({
            url,
            wallet,
            config,
            network,
            getTokenConfig: (irys)=>{
                var _a, _b;
                return (0, tokens_1.default)({
                    irys,
                    token: token.toLowerCase(),
                    wallet: (_a = wallet === null || wallet === void 0 ? void 0 : wallet.provider) !== null && _a !== void 0 ? _a : wallet,
                    providerUrl: (_b = config === null || config === void 0 ? void 0 : config.providerUrl) !== null && _b !== void 0 ? _b : wallet === null || wallet === void 0 ? void 0 : wallet.rpcUrl,
                    contractAddress: config === null || config === void 0 ? void 0 : config.contractAddress,
                    providerName: wallet === null || wallet === void 0 ? void 0 : wallet.name,
                    tokenOpts: Object.assign(Object.assign({}, config === null || config === void 0 ? void 0 : config.tokenOpts), wallet)
                });
            }
        });
    }
    static init(opts) {
        return tslib_1.__awaiter(this, void 0, void 0, function*() {
            const { url, token, provider, publicKey, signingFunction, collectSignatures, providerUrl, timeout, contractAddress } = opts;
            const Irys = new WebIrys({
                url,
                token,
                // @ts-expect-error types
                wallet: {
                    name: "init",
                    provider: signingFunction ? publicKey : provider
                },
                config: {
                    providerUrl,
                    timeout,
                    contractAddress,
                    tokenOpts: {
                        signingFunction,
                        collectSignatures
                    }
                }
            });
            yield Irys.ready();
            return Irys;
        });
    }
}
exports.WebIrys = WebIrys;
exports.default = WebIrys; //# sourceMappingURL=irys.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WebIrys = exports.default = void 0;
var irys_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/irys.js [app-route] (ecmascript)");
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return __importDefault(irys_1).default;
    }
});
var irys_2 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/irys.js [app-route] (ecmascript)");
Object.defineProperty(exports, "WebIrys", {
    enumerable: true,
    get: function() {
        return __importDefault(irys_2).default;
    }
}); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/cjsIndex.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
const tslib_1 = __turbopack_require__("[project]/node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs [app-route] (ecmascript)");
__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/common/hack.js [app-route] (ecmascript)");
const index_1 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/node/index.js [app-route] (ecmascript)"));
const index_2 = tslib_1.__importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+sdk@0.2.11_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@irys/sdk/build/cjs/web/index.js [app-route] (ecmascript)"));
// this class allows for CJS imports without .default, as well as still allowing for destructured Node/WebIrys imports.
class IndexIrys extends index_1.default {
}
IndexIrys.default = IndexIrys;
IndexIrys.NodeIrys = index_1.default;
IndexIrys.WebIrys = index_2.default;
module.exports = IndexIrys; //# sourceMappingURL=cjsIndex.js.map
}}),

};

//# sourceMappingURL=6e6eb_%40irys_sdk_build_cjs_0be53b._.js.map
module.exports = {

"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/PoolAccount.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PoolAccount = void 0;
var PoolAccount = function() {
    function PoolAccount(publicKey, parseData) {
        this.publicKey = publicKey;
        Object.assign(this, parseData);
    }
    PoolAccount.from = function(publicKey, parseData) {
        return new PoolAccount(publicKey, parseData);
    };
    PoolAccount.prototype.updatePoolData = function(parseData) {
        Object.assign(this, parseData);
    };
    PoolAccount.prototype.getTokenId = function(custodyKey) {
        return this.custodies.findIndex(function(i) {
            return i.toBase58() == custodyKey.toBase58();
        });
    };
    return PoolAccount;
}();
exports.PoolAccount = PoolAccount;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/CustodyAccount.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.CustodyAccount = void 0;
var CustodyAccount = function() {
    function CustodyAccount(publicKey, parseData) {
        this.publicKey = publicKey;
        Object.assign(this, parseData);
    }
    CustodyAccount.from = function(publicKey, parseData) {
        return new CustodyAccount(publicKey, parseData);
    };
    CustodyAccount.prototype.updateCustodyData = function(custody) {
        Object.assign(this, __assign({}, custody));
    };
    return CustodyAccount;
}();
exports.CustodyAccount = CustodyAccount;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/constants/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.METAPLEX_PROGRAM_ID = exports.DAY_SECONDS = exports.BN_ONE = exports.BN_ZERO = exports.ORACLE_EXPONENT = exports.RATE_POWER = exports.RATE_DECIMALS = exports.LP_DECIMALS = exports.BPS_POWER = exports.BPS_DECIMALS = exports.USD_DECIMALS = exports.PERCENTAGE_DECIMALS = void 0;
var web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.95.8_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
var bn_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)");
exports.PERCENTAGE_DECIMALS = 4;
exports.USD_DECIMALS = 6;
exports.BPS_DECIMALS = 4;
exports.BPS_POWER = Math.pow(10, exports.BPS_DECIMALS);
exports.LP_DECIMALS = exports.USD_DECIMALS;
exports.RATE_DECIMALS = 9;
exports.RATE_POWER = Math.pow(10, exports.RATE_DECIMALS);
exports.ORACLE_EXPONENT = 9;
exports.BN_ZERO = new bn_js_1.BN(0);
exports.BN_ONE = new bn_js_1.BN(1);
exports.DAY_SECONDS = new bn_js_1.BN(3600);
exports.METAPLEX_PROGRAM_ID = new web3_js_1.PublicKey("metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s");
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/types/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DEFAULT_POSITION = exports.FeesAction = exports.FeesMode = exports.OracleType = exports.Side = exports.Privilege = exports.isOneOfVariant = exports.isVariant = void 0;
var web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.95.8_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
var constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/constants/index.js [app-route] (ecmascript)");
function isVariant(object, type) {
    return object.hasOwnProperty(type);
}
exports.isVariant = isVariant;
function isOneOfVariant(object, types) {
    return types.reduce(function(result, type) {
        return result || object.hasOwnProperty(type);
    }, false);
}
exports.isOneOfVariant = isOneOfVariant;
var Privilege = function() {
    function Privilege() {}
    Privilege.None = {
        none: {}
    };
    Privilege.NFT = {
        nft: {}
    };
    Privilege.Referral = {
        referral: {}
    };
    return Privilege;
}();
exports.Privilege = Privilege;
var Side = function() {
    function Side() {}
    Side.None = {
        none: {}
    };
    Side.Long = {
        long: {}
    };
    Side.Short = {
        short: {}
    };
    return Side;
}();
exports.Side = Side;
var OracleType = function() {
    function OracleType() {}
    OracleType.None = {
        none: {}
    };
    OracleType.Test = {
        test: {}
    };
    OracleType.Pyth = {
        pyth: {}
    };
    return OracleType;
}();
exports.OracleType = OracleType;
var FeesMode = function() {
    function FeesMode() {}
    FeesMode.Fixed = {
        fixed: {}
    };
    FeesMode.Linear = {
        linear: {}
    };
    return FeesMode;
}();
exports.FeesMode = FeesMode;
var FeesAction = function() {
    function FeesAction() {}
    FeesAction.AddLiquidity = {
        addLiquidity: {}
    };
    FeesAction.RemoveLiquidity = {
        removeLiquidity: {}
    };
    FeesAction.SwapIn = {
        swapIn: {}
    };
    FeesAction.SwapOut = {
        swapOut: {}
    };
    FeesAction.StableSwapIn = {
        stableSwapIn: {}
    };
    FeesAction.StableSwapOut = {
        stableSwapOut: {}
    };
    return FeesAction;
}();
exports.FeesAction = FeesAction;
exports.DEFAULT_POSITION = {
    owner: web3_js_1.PublicKey.default,
    delegate: web3_js_1.PublicKey.default,
    market: web3_js_1.PublicKey.default,
    openTime: constants_1.BN_ZERO,
    updateTime: constants_1.BN_ZERO,
    entryPrice: {
        price: constants_1.BN_ZERO,
        exponent: 0
    },
    sizeAmount: constants_1.BN_ZERO,
    sizeUsd: constants_1.BN_ZERO,
    lockedAmount: constants_1.BN_ZERO,
    lockedUsd: constants_1.BN_ZERO,
    collateralAmount: constants_1.BN_ZERO,
    collateralUsd: constants_1.BN_ZERO,
    unsettledAmount: constants_1.BN_ZERO,
    unsettledFeesUsd: constants_1.BN_ZERO,
    cumulativeLockFeeSnapshot: constants_1.BN_ZERO,
    takeProfitPrice: {
        price: constants_1.BN_ZERO,
        exponent: 0
    },
    stopLossPrice: {
        price: constants_1.BN_ZERO,
        exponent: 0
    },
    sizeDecimals: 0,
    lockedDecimals: 0,
    collateralDecimals: 0,
    bump: 0
};
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/PositionAccount.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PositionAccount = void 0;
var PositionAccount = function() {
    function PositionAccount(publicKey, parseData) {
        this.publicKey = publicKey;
        Object.assign(this, parseData);
    }
    PositionAccount.from = function(publicKey, parseData) {
        return new PositionAccount(publicKey, parseData);
    };
    PositionAccount.prototype.clone = function() {
        return __assign({}, this);
    };
    PositionAccount.prototype.updatePositionData = function(position) {
        Object.assign(this, __assign({}, position));
    };
    return PositionAccount;
}();
exports.PositionAccount = PositionAccount;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/MarketAccount.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.MarketAccount = void 0;
var web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.95.8_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
var types_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/types/index.js [app-route] (ecmascript)");
var PositionAccount_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/PositionAccount.js [app-route] (ecmascript)");
var constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/constants/index.js [app-route] (ecmascript)");
var MarketAccount = function() {
    function MarketAccount(publicKey, parseData) {
        this.publicKey = publicKey;
        Object.assign(this, parseData);
    }
    MarketAccount.from = function(publicKey, parseData) {
        return new MarketAccount(publicKey, parseData);
    };
    MarketAccount.prototype.updateMarketData = function(market) {
        Object.assign(this, __assign({}, market));
    };
    MarketAccount.prototype.getCollectivePosition = function() {
        if (this.collectivePosition.openPositions.gt(constants_1.BN_ZERO)) {
            var obj = __assign({
                entryPrice: this.collectivePosition.averageEntryPrice,
                sizeAmount: this.collectivePosition.sizeAmount,
                sizeUsd: this.collectivePosition.sizeUsd,
                collateralAmount: this.collectivePosition.collateralAmount,
                collateralUsd: this.collectivePosition.collateralUsd,
                lockedAmount: this.collectivePosition.lockedAmount,
                lockedUsd: this.collectivePosition.lockedUsd,
                unsettledFeesUsd: this.collectivePosition.unsettledFeeUsd,
                cumulativeLockFeeSnapshot: this.collectivePosition.cumulativeLockFeeSnapshot
            }, types_1.DEFAULT_POSITION);
            return new PositionAccount_1.PositionAccount(web3_js_1.PublicKey.default, obj);
        } else {
            return new PositionAccount_1.PositionAccount(web3_js_1.PublicKey.default, types_1.DEFAULT_POSITION);
        }
    };
    return MarketAccount;
}();
exports.MarketAccount = MarketAccount;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/OrderAccount.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.OrderAccount = void 0;
var OrderAccount = function() {
    function OrderAccount(publicKey, parseData) {
        this.publicKey = publicKey;
        Object.assign(this, parseData);
    }
    OrderAccount.from = function(publicKey, parseData) {
        return new OrderAccount(publicKey, parseData);
    };
    OrderAccount.prototype.clone = function() {
        return __assign({}, this);
    };
    OrderAccount.prototype.updateOrderAccountData = function(order) {
        Object.assign(this, __assign({}, order));
    };
    return OrderAccount;
}();
exports.OrderAccount = OrderAccount;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/TradingAccount.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TradingAccount = void 0;
var TradingAccount = function() {
    function TradingAccount(publicKey, parseData) {
        this.publicKey = publicKey;
        Object.assign(this, parseData);
    }
    TradingAccount.from = function(publicKey, parseData) {
        return new TradingAccount(publicKey, parseData);
    };
    TradingAccount.prototype.updatePoolData = function(parseData) {
        Object.assign(this, parseData);
    };
    return TradingAccount;
}();
exports.TradingAccount = TradingAccount;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = this && this.__generator || function(thisArg, body) {
    var _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, f, y, t, g;
    return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    "TURBOPACK unreachable";
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.checkedDecimalDiv = exports.checkedDecimalMul = exports.checkedDecimalCeilMul = exports.checkedCeilDiv = exports.scaleToExponent = exports.checkIfAccountExists = exports.nativeToUiDecimals = exports.validateNumberString = exports.uiDecimalsToNative = exports.toUiDecimalsOldSDK = exports.getUnixTs = void 0;
var bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
var constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/constants/index.js [app-route] (ecmascript)");
var bignumber_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
var getUnixTs = function() {
    return new Date().getTime() / 1000;
};
exports.getUnixTs = getUnixTs;
function toUiDecimalsOldSDK(nativeAmount, decimals, precision, commaSeperated) {
    if (precision === void 0) {
        precision = 3;
    }
    if (commaSeperated === void 0) {
        commaSeperated = false;
    }
    if (precision > decimals) {
        throw 'not allowed precision> decimals';
    }
    var r = '';
    if (nativeAmount instanceof bn_js_1.default) {
        var nativeAmountString = nativeAmount.toString();
        var d = nativeAmountString.slice(decimals * -1);
        var p = d.slice(0, precision);
        var nativeAmountWithoutDecimalsStr = nativeAmount.div(new bn_js_1.default(Math.pow(10, decimals))).toString();
        r = nativeAmountWithoutDecimalsStr + '.' + p;
    } else if (typeof nativeAmount === 'string') {
        if (isNaN(Number(nativeAmount))) {
            throw 'String No valid ';
        }
        if (nativeAmount.length < decimals) {
            nativeAmount = nativeAmount.padStart(decimals, '0');
        }
        var d = nativeAmount.slice(decimals * -1);
        var p = d.slice(0, precision);
        var nativeAmountWithoutDecimalsStr = new bn_js_1.default(nativeAmount).div(new bn_js_1.default(Math.pow(10, decimals))).toString();
        r = nativeAmountWithoutDecimalsStr + '.' + p;
    } else if (typeof nativeAmount === 'number') {
        var d = nativeAmount.toString().slice(decimals * -1);
        var p = d.slice(0, precision);
        var nativeAmountWithoutDecimalsStr = new bn_js_1.default(nativeAmount).div(new bn_js_1.default(Math.pow(10, decimals))).toString();
        r = nativeAmountWithoutDecimalsStr + '.' + p;
    } else {
        return 'type unknown';
    }
    if (commaSeperated) {
        return Number(r).toLocaleString();
    } else {
        return r;
    }
}
exports.toUiDecimalsOldSDK = toUiDecimalsOldSDK;
var uiDecimalsToNative = function(amountUi, decimals) {
    var valueBigNumber = new bignumber_js_1.default(amountUi).multipliedBy(new bignumber_js_1.default(Math.pow(10, decimals)));
    return new bn_js_1.default(valueBigNumber.toFixed(0, bignumber_js_1.default.ROUND_DOWN));
};
exports.uiDecimalsToNative = uiDecimalsToNative;
var validateNumberString = function(str) {
    if (typeof str === 'undefined') {
        return false;
    }
    if (str.trim() === '') {
        return false;
    }
    if (isNaN(Number(str))) {
        return false;
    }
    return true;
};
exports.validateNumberString = validateNumberString;
function nativeToUiDecimals(nativeAmount, decimals, precision, commaSeperated) {
    if (!precision) precision = decimals;
    if (!(0, exports.validateNumberString)(nativeAmount.toString())) {
        console.log("error - nativeAmount:", nativeAmount);
        throw "nativeToUiDecimals error: ".concat(nativeAmount, " Not valid ");
    }
    if (nativeAmount instanceof bignumber_js_1.default) {} else if (nativeAmount instanceof bn_js_1.default) {} else if (typeof nativeAmount === 'string') {
        if (isNaN(Number(nativeAmount))) {
            throw new Error("nativeToUiDecimals error: String Not valid ::: ".concat(nativeAmount));
        }
    } else if (typeof nativeAmount === 'number') {} else {}
    var denominator = new bignumber_js_1.default(10).pow(decimals);
    var r = new bignumber_js_1.default(nativeAmount.toString()).div(denominator).toFixed(precision, bignumber_js_1.default.ROUND_DOWN);
    if (commaSeperated) {
        return Number(r).toLocaleString('en-US', {
            maximumFractionDigits: 2,
            minimumFractionDigits: 2
        });
    } else {
        return r;
    }
}
exports.nativeToUiDecimals = nativeToUiDecimals;
function checkIfAccountExists(account, connection) {
    return __awaiter(this, void 0, void 0, function() {
        var bal;
        return __generator(this, function(_a) {
            switch(_a.label){
                case 0:
                    return [
                        4,
                        connection.getBalance(account)
                    ];
                case 1:
                    bal = _a.sent();
                    if (bal > 0) {
                        return [
                            2,
                            true
                        ];
                    } else {
                        return [
                            2,
                            false
                        ];
                    }
                    return [
                        2
                    ];
            }
        });
    });
}
exports.checkIfAccountExists = checkIfAccountExists;
var scaleToExponent = function(arg, exponent, target_exponent) {
    if (target_exponent.eq(exponent)) {
        return arg;
    }
    var delta = target_exponent.sub(exponent);
    if (delta.gt(constants_1.BN_ZERO)) {
        return arg.div(new bn_js_1.default(10).pow(delta));
    } else {
        return arg.mul(new bn_js_1.default(10).pow(delta.muln(-1)));
    }
};
exports.scaleToExponent = scaleToExponent;
var checkedCeilDiv = function(arg1, arg2) {
    if (arg1.gt(constants_1.BN_ZERO)) {
        if (arg1.eq(arg2) && !arg2.isZero()) {
            return constants_1.BN_ONE;
        }
        var res = arg1.sub(constants_1.BN_ONE).div(arg2);
        if (!res) {
            throw Error("error :: MathOverflow");
        }
        return res.add(constants_1.BN_ONE);
    } else {
        var res = arg1.div(arg2);
        if (!res) {
            throw Error("error :: MathOverflow");
        }
        return res;
    }
};
exports.checkedCeilDiv = checkedCeilDiv;
var checkedDecimalCeilMul = function(coefficient1, exponent1, coefficient2, exponent2, target_exponent) {
    if (coefficient1.isZero() || coefficient2.isZero()) {
        return constants_1.BN_ZERO;
    }
    var target_power = exponent1.add(exponent2).sub(target_exponent);
    if (target_power.gt(constants_1.BN_ZERO)) {
        return coefficient1.mul(coefficient2).mul(new bn_js_1.default(10).pow(target_power));
    } else {
        var a = coefficient1.mul(coefficient2);
        var b = new bn_js_1.default(10).pow(target_power.muln(-1));
        return (0, exports.checkedCeilDiv)(a, b);
    }
};
exports.checkedDecimalCeilMul = checkedDecimalCeilMul;
var checkedDecimalMul = function(coefficient1, exponent1, coefficient2, exponent2, target_exponent) {
    if (coefficient1.isZero() || coefficient2.isZero()) {
        return constants_1.BN_ZERO;
    }
    var target_power = exponent1.add(exponent2).sub(target_exponent);
    if (target_power.gt(constants_1.BN_ZERO)) {
        return coefficient1.mul(coefficient2).mul(new bn_js_1.default(10).pow(target_power));
    } else {
        return coefficient1.mul(coefficient2).div(new bn_js_1.default(10).pow(target_power.muln(-1)));
    }
};
exports.checkedDecimalMul = checkedDecimalMul;
var checkedDecimalDiv = function(coefficient1, exponent1, coefficient2, exponent2, target_exponent) {
    if (coefficient2.isZero()) {
        throw Error("\"Error: Overflow in ".concat(coefficient1, " / ").concat(coefficient2));
    }
    if (coefficient1.isZero()) {
        return constants_1.BN_ZERO;
    }
    var scale_factor = constants_1.BN_ZERO;
    var target_power = exponent1.sub(exponent2).sub(target_exponent);
    if (exponent1.gt(constants_1.BN_ZERO)) {
        scale_factor = scale_factor.add(exponent1);
    }
    if (exponent2.lt(constants_1.BN_ZERO)) {
        scale_factor = scale_factor.sub(exponent2);
        target_power = target_power.add(exponent2);
    }
    if (target_exponent.lt(constants_1.BN_ZERO)) {
        scale_factor = scale_factor.sub(target_exponent);
        target_power = target_power.add(target_exponent);
    }
    var scaled_coeff1 = constants_1.BN_ZERO;
    if (scale_factor.gt(constants_1.BN_ZERO)) {
        scaled_coeff1 = coefficient1.mul(new bn_js_1.default(10).pow(scale_factor));
    } else {
        scaled_coeff1 = coefficient1;
    }
    ;
    if (target_power.gte(constants_1.BN_ZERO)) {
        return scaled_coeff1.div(coefficient2).mul(new bn_js_1.default(10).pow(target_power));
    } else {
        return scaled_coeff1.div(coefficient2).div(new bn_js_1.default(10).pow(target_power.muln(-1)));
    }
};
exports.checkedDecimalDiv = checkedDecimalDiv;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/rpc.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __extends = this && this.__extends || function() {
    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || ({
            __proto__: []
        }) instanceof Array && function(d, b) {
            d.__proto__ = b;
        } || function(d, b) {
            for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
        };
        return extendStatics(d, b);
    };
    return function(d, b) {
        if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = this && this.__generator || function(thisArg, body) {
    var _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, f, y, t, g;
    return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    "TURBOPACK unreachable";
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
};
var __spreadArray = this && this.__spreadArray || function(to, from, pack) {
    if (pack || arguments.length === 2) for(var i = 0, l = from.length, ar; i < l; i++){
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TransactionFailError = exports.createComputeBudgetIx = exports.confirmTransactionV3 = exports.sendTransactionV3 = exports.confirmTransactionV2 = exports.sendTransactionV2 = exports.confirmTransaction = exports.sendTransaction = void 0;
var nodewallet_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.27.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/cjs/nodewallet.js [app-route] (ecmascript)"));
var bytes_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.27.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/cjs/utils/bytes/index.js [app-route] (ecmascript)");
var web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.95.8_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function sendTransaction(provider, ixs, opts) {
    var _a, _b, _c, _d;
    if (opts === void 0) {
        opts = {};
    }
    return __awaiter(this, void 0, void 0, function() {
        var connection, latestBlockhash, _e, payer, message, vtx, signature;
        return __generator(this, function(_f) {
            switch(_f.label){
                case 0:
                    connection = provider.connection;
                    if (!((_a = opts.latestBlockhash) !== null && _a !== void 0)) return [
                        3,
                        1
                    ];
                    _e = _a;
                    return [
                        3,
                        3
                    ];
                case 1:
                    return [
                        4,
                        connection.getLatestBlockhash((_c = (_b = opts.preflightCommitment) !== null && _b !== void 0 ? _b : provider.opts.preflightCommitment) !== null && _c !== void 0 ? _c : 'finalized')
                    ];
                case 2:
                    _e = _f.sent();
                    _f.label = 3;
                case 3:
                    latestBlockhash = _e;
                    payer = provider.wallet;
                    if (opts.prioritizationFee) {
                        ixs = __spreadArray(__spreadArray([], ixs, true), [
                            (0, exports.createComputeBudgetIx)(opts.prioritizationFee)
                        ], false);
                    }
                    message = web3_js_1.MessageV0.compile({
                        payerKey: provider.wallet.publicKey,
                        instructions: ixs,
                        recentBlockhash: latestBlockhash.blockhash,
                        addressLookupTableAccounts: opts.alts
                    });
                    vtx = new web3_js_1.VersionedTransaction(message);
                    if ((_d = opts === null || opts === void 0 ? void 0 : opts.additionalSigners) === null || _d === void 0 ? void 0 : _d.length) {
                        vtx.sign(__spreadArray([], opts === null || opts === void 0 ? void 0 : opts.additionalSigners, true));
                    }
                    if (!(typeof payer.signTransaction === 'function' && !(payer instanceof nodewallet_1.default || payer.constructor.name == 'NodeWallet'))) return [
                        3,
                        5
                    ];
                    return [
                        4,
                        payer.signTransaction(vtx)
                    ];
                case 4:
                    vtx = _f.sent();
                    return [
                        3,
                        6
                    ];
                case 5:
                    vtx.sign([
                        payer.payer
                    ]);
                    _f.label = 6;
                case 6:
                    return [
                        4,
                        connection.sendTransaction(vtx, {
                            skipPreflight: true
                        })
                    ];
                case 7:
                    signature = _f.sent();
                    return [
                        2,
                        signature
                    ];
            }
        });
    });
}
exports.sendTransaction = sendTransaction;
function confirmTransaction(provider, signature, opts) {
    var _a, _b, _c, _d;
    if (opts === void 0) {
        opts = {};
    }
    return __awaiter(this, void 0, void 0, function() {
        var connection, latestBlockhash, _e, txConfirmationCommitment, status;
        return __generator(this, function(_f) {
            switch(_f.label){
                case 0:
                    connection = provider.connection;
                    if (!((_a = opts.latestBlockhash) !== null && _a !== void 0)) return [
                        3,
                        1
                    ];
                    _e = _a;
                    return [
                        3,
                        3
                    ];
                case 1:
                    return [
                        4,
                        connection.getLatestBlockhash((_c = (_b = opts.preflightCommitment) !== null && _b !== void 0 ? _b : provider.opts.preflightCommitment) !== null && _c !== void 0 ? _c : 'finalized')
                    ];
                case 2:
                    _e = _f.sent();
                    _f.label = 3;
                case 3:
                    latestBlockhash = _e;
                    txConfirmationCommitment = (_d = opts.txConfirmationCommitment) !== null && _d !== void 0 ? _d : 'processed';
                    if (!(latestBlockhash.blockhash != null && latestBlockhash.lastValidBlockHeight != null)) return [
                        3,
                        5
                    ];
                    return [
                        4,
                        connection.confirmTransaction({
                            signature: signature,
                            blockhash: latestBlockhash.blockhash,
                            lastValidBlockHeight: latestBlockhash.lastValidBlockHeight
                        }, txConfirmationCommitment)
                    ];
                case 4:
                    status = _f.sent().value;
                    return [
                        3,
                        7
                    ];
                case 5:
                    return [
                        4,
                        connection.confirmTransaction(signature, txConfirmationCommitment)
                    ];
                case 6:
                    status = _f.sent().value;
                    _f.label = 7;
                case 7:
                    if (status.err) {
                        console.warn('Tx status: ', status);
                        throw new TransactionFailError({
                            txid: signature,
                            message: "".concat(JSON.stringify(status))
                        });
                    }
                    return [
                        2,
                        signature
                    ];
            }
        });
    });
}
exports.confirmTransaction = confirmTransaction;
function sendTransactionV2(provider, ixs, opts) {
    var _a, _b, _c, _d;
    if (opts === void 0) {
        opts = {};
    }
    return __awaiter(this, void 0, void 0, function() {
        var connection, latestBlockhash, _e, payer, message, vtx, signature;
        return __generator(this, function(_f) {
            switch(_f.label){
                case 0:
                    connection = provider.connection;
                    if (!((_a = opts.latestBlockhash) !== null && _a !== void 0)) return [
                        3,
                        1
                    ];
                    _e = _a;
                    return [
                        3,
                        3
                    ];
                case 1:
                    return [
                        4,
                        connection.getLatestBlockhash((_c = (_b = opts.preflightCommitment) !== null && _b !== void 0 ? _b : provider.opts.preflightCommitment) !== null && _c !== void 0 ? _c : 'finalized')
                    ];
                case 2:
                    _e = _f.sent();
                    _f.label = 3;
                case 3:
                    latestBlockhash = _e;
                    payer = provider.wallet;
                    if (opts.prioritizationFee) {
                        ixs = __spreadArray(__spreadArray([], ixs, true), [
                            (0, exports.createComputeBudgetIx)(opts.prioritizationFee)
                        ], false);
                    }
                    message = web3_js_1.MessageV0.compile({
                        payerKey: provider.wallet.publicKey,
                        instructions: ixs,
                        recentBlockhash: latestBlockhash.blockhash,
                        addressLookupTableAccounts: opts.alts
                    });
                    vtx = new web3_js_1.VersionedTransaction(message);
                    if ((_d = opts === null || opts === void 0 ? void 0 : opts.additionalSigners) === null || _d === void 0 ? void 0 : _d.length) {
                        vtx.sign(__spreadArray([], opts === null || opts === void 0 ? void 0 : opts.additionalSigners, true));
                    }
                    if (!(typeof payer.signTransaction === 'function' && !(payer instanceof nodewallet_1.default || payer.constructor.name == 'NodeWallet'))) return [
                        3,
                        5
                    ];
                    return [
                        4,
                        payer.signTransaction(vtx)
                    ];
                case 4:
                    vtx = _f.sent();
                    return [
                        3,
                        6
                    ];
                case 5:
                    vtx.sign([
                        payer.payer
                    ]);
                    _f.label = 6;
                case 6:
                    return [
                        4,
                        connection.sendTransaction(vtx, {
                            skipPreflight: true
                        })
                    ];
                case 7:
                    signature = _f.sent();
                    return [
                        2,
                        {
                            signature: signature,
                            versionedTransaction: vtx
                        }
                    ];
            }
        });
    });
}
exports.sendTransactionV2 = sendTransactionV2;
var sleep = function(ms) {
    return new Promise(function(r) {
        return setTimeout(r, ms);
    });
};
function confirmTransactionV2(provider, versionedTransaction, signature, opts) {
    if (opts === void 0) {
        opts = {};
    }
    return __awaiter(this, void 0, void 0, function() {
        var connection, status, done, blockhashResponse, lastValidBlockHeight, blockheight, signatureStatuses, result, x;
        return __generator(this, function(_a) {
            switch(_a.label){
                case 0:
                    connection = provider.connection;
                    done = false;
                    return [
                        4,
                        connection.getLatestBlockhashAndContext()
                    ];
                case 1:
                    blockhashResponse = _a.sent();
                    lastValidBlockHeight = blockhashResponse.context.slot + 150;
                    return [
                        4,
                        connection.getBlockHeight()
                    ];
                case 2:
                    blockheight = _a.sent();
                    _a.label = 3;
                case 3:
                    if (!(blockheight < lastValidBlockHeight && !done)) return [
                        3,
                        8
                    ];
                    return [
                        4,
                        connection.getSignatureStatuses([
                            signature
                        ])
                    ];
                case 4:
                    signatureStatuses = _a.sent();
                    result = signatureStatuses && signatureStatuses.value[0];
                    if (!result) {} else if (result.err) {
                        done = true;
                        status = result.err;
                    } else if (![
                        'processed',
                        'confirmed',
                        'finalized'
                    ].includes(result.confirmationStatus)) {} else {
                        done = true;
                        status = result;
                    }
                    return [
                        4,
                        connection.sendTransaction(versionedTransaction, {
                            skipPreflight: true
                        })
                    ];
                case 5:
                    x = _a.sent();
                    return [
                        4,
                        sleep(1000)
                    ];
                case 6:
                    _a.sent();
                    return [
                        4,
                        connection.getBlockHeight()
                    ];
                case 7:
                    blockheight = _a.sent();
                    return [
                        3,
                        3
                    ];
                case 8:
                    if (status.err) {
                        console.warn('Tx status: ', status);
                        throw new TransactionFailError({
                            txid: signature,
                            message: "".concat(JSON.stringify(status))
                        });
                    }
                    return [
                        2,
                        signature
                    ];
            }
        });
    });
}
exports.confirmTransactionV2 = confirmTransactionV2;
function sendTransactionV3(provider, ixs, opts) {
    var _a, _b, _c, _d;
    if (opts === void 0) {
        opts = {};
    }
    return __awaiter(this, void 0, void 0, function() {
        var connection, latestBlockhash, _e, payer, message, vtx, tx, signature;
        return __generator(this, function(_f) {
            switch(_f.label){
                case 0:
                    connection = provider.connection;
                    if (!((_a = opts.latestBlockhash) !== null && _a !== void 0)) return [
                        3,
                        1
                    ];
                    _e = _a;
                    return [
                        3,
                        3
                    ];
                case 1:
                    return [
                        4,
                        connection.getLatestBlockhash((_c = (_b = opts.preflightCommitment) !== null && _b !== void 0 ? _b : provider.opts.preflightCommitment) !== null && _c !== void 0 ? _c : 'finalized')
                    ];
                case 2:
                    _e = _f.sent();
                    _f.label = 3;
                case 3:
                    latestBlockhash = _e;
                    payer = provider.wallet;
                    message = web3_js_1.MessageV0.compile({
                        payerKey: provider.wallet.publicKey,
                        instructions: ixs,
                        recentBlockhash: latestBlockhash.blockhash,
                        addressLookupTableAccounts: opts.alts
                    });
                    vtx = new web3_js_1.VersionedTransaction(message);
                    if ((_d = opts === null || opts === void 0 ? void 0 : opts.additionalSigners) === null || _d === void 0 ? void 0 : _d.length) {
                        vtx.sign(__spreadArray([], opts === null || opts === void 0 ? void 0 : opts.additionalSigners, true));
                    }
                    if (!(typeof payer.signTransaction === 'function' && !(payer instanceof nodewallet_1.default || payer.constructor.name == 'NodeWallet'))) return [
                        3,
                        5
                    ];
                    return [
                        4,
                        payer.signTransaction(vtx)
                    ];
                case 4:
                    vtx = _f.sent();
                    return [
                        3,
                        6
                    ];
                case 5:
                    vtx.sign([
                        payer.payer
                    ]);
                    _f.label = 6;
                case 6:
                    bytes_1.bs58.encode(vtx.serialize());
                    tx = bytes_1.bs58.encode(vtx.serialize());
                    return [
                        4,
                        connection.sendTransaction(vtx, {
                            skipPreflight: true,
                            maxRetries: 0
                        })
                    ];
                case 7:
                    signature = _f.sent();
                    return [
                        2,
                        {
                            signature: signature,
                            versionedTransaction: vtx
                        }
                    ];
            }
        });
    });
}
exports.sendTransactionV3 = sendTransactionV3;
function confirmTransactionV3(provider, versionedTransaction, signature, opts) {
    if (opts === void 0) {
        opts = {};
    }
    return __awaiter(this, void 0, void 0, function() {
        var connection, status, blockhashResponse, lastValidBlockHeight, blockheight, signatureStatuses, result, x;
        return __generator(this, function(_a) {
            switch(_a.label){
                case 0:
                    connection = provider.connection;
                    return [
                        4,
                        connection.getLatestBlockhashAndContext()
                    ];
                case 1:
                    blockhashResponse = _a.sent();
                    lastValidBlockHeight = blockhashResponse.context.slot + 150;
                    return [
                        4,
                        connection.getBlockHeight()
                    ];
                case 2:
                    blockheight = _a.sent();
                    _a.label = 3;
                case 3:
                    if (!(blockheight < lastValidBlockHeight)) return [
                        3,
                        8
                    ];
                    console.log('inside while :', signature, blockheight, lastValidBlockHeight);
                    return [
                        4,
                        connection.getSignatureStatuses([
                            signature
                        ])
                    ];
                case 4:
                    signatureStatuses = _a.sent();
                    result = signatureStatuses && signatureStatuses.value[0];
                    console.log('result:', result, signatureStatuses.value[0]);
                    if (!result) {} else if (result.err) {
                        status = result;
                        console.log('breakinng with err', result.err);
                        return [
                            3,
                            8
                        ];
                    } else if (![
                        'processed',
                        'confirmed',
                        'finalized'
                    ].includes(result.confirmationStatus)) {} else {
                        status = result;
                        console.log('breakinng with susccess', result);
                        return [
                            3,
                            8
                        ];
                    }
                    console.log('status:', status);
                    return [
                        4,
                        connection.sendTransaction(versionedTransaction, {
                            skipPreflight: true,
                            maxRetries: 0
                        })
                    ];
                case 5:
                    x = _a.sent();
                    console.log('retyr send :', x);
                    return [
                        4,
                        sleep(2000)
                    ];
                case 6:
                    _a.sent();
                    return [
                        4,
                        connection.getBlockHeight()
                    ];
                case 7:
                    blockheight = _a.sent();
                    return [
                        3,
                        3
                    ];
                case 8:
                    if (status.err) {
                        console.warn('Tx status: ', status);
                        throw new TransactionFailError({
                            txid: signature,
                            message: "".concat(JSON.stringify(status))
                        });
                    }
                    return [
                        2,
                        signature
                    ];
            }
        });
    });
}
exports.confirmTransactionV3 = confirmTransactionV3;
var createComputeBudgetIx = function(microLamports) {
    var computeBudgetIx = web3_js_1.ComputeBudgetProgram.setComputeUnitPrice({
        microLamports: microLamports
    });
    return computeBudgetIx;
};
exports.createComputeBudgetIx = createComputeBudgetIx;
var TransactionFailError = function(_super) {
    __extends(TransactionFailError, _super);
    function TransactionFailError(_a) {
        var txid = _a.txid, message = _a.message;
        var _this = _super.call(this) || this;
        _this.message = message;
        _this.txid = txid;
        return _this;
    }
    return TransactionFailError;
}(Error);
exports.TransactionFailError = TransactionFailError;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/getNftAccounts.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getNftAccounts = void 0;
var web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.95.8_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
var types_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/types/index.js [app-route] (ecmascript)");
var getNftAccounts = function(nftTradingAccount, nftReferralAccount, nftRebateTokenAccount, privilege) {
    if ((0, types_1.isVariant)(privilege, 'none')) {
        return [];
    }
    if (nftTradingAccount.equals(web3_js_1.PublicKey.default) || nftReferralAccount.equals(web3_js_1.PublicKey.default) || nftRebateTokenAccount.equals(web3_js_1.PublicKey.default)) {
        console.log("skipping refferals");
        return [];
    }
    var isNFTPrivilege = (0, types_1.isVariant)(privilege, 'nft');
    return [
        {
            pubkey: nftReferralAccount,
            isSigner: false,
            isWritable: !isNFTPrivilege
        },
        {
            pubkey: nftTradingAccount,
            isSigner: false,
            isWritable: true
        },
        {
            pubkey: nftRebateTokenAccount,
            isSigner: false,
            isWritable: !isNFTPrivilege
        }
    ];
};
exports.getNftAccounts = getNftAccounts;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/IdlCoder.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.IdlCoder = void 0;
var camelcase_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/camelcase@6.3.0/node_modules/camelcase/index.js [app-route] (ecmascript)"));
var borsh = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+borsh@0.30.1_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10_/node_modules/@coral-xyz/borsh/dist/index.js [app-route] (ecmascript)"));
var anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.27.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
var IdlCoder = function() {
    function IdlCoder() {}
    IdlCoder.fieldLayout = function(field, types) {
        var fieldName = field.name !== undefined ? (0, camelcase_1.default)(field.name) : undefined;
        switch(field.type){
            case 'bool':
                {
                    return borsh.bool(fieldName);
                }
            case 'u8':
                {
                    return borsh.u8(fieldName);
                }
            case 'i8':
                {
                    return borsh.i8(fieldName);
                }
            case 'u16':
                {
                    return borsh.u16(fieldName);
                }
            case 'i16':
                {
                    return borsh.i16(fieldName);
                }
            case 'u32':
                {
                    return borsh.u32(fieldName);
                }
            case 'i32':
                {
                    return borsh.i32(fieldName);
                }
            case 'f32':
                {
                    return borsh.f32(fieldName);
                }
            case 'u64':
                {
                    return borsh.u64(fieldName);
                }
            case 'i64':
                {
                    return borsh.i64(fieldName);
                }
            case 'f64':
                {
                    return borsh.f64(fieldName);
                }
            case 'u128':
                {
                    return borsh.u128(fieldName);
                }
            case 'i128':
                {
                    return borsh.i128(fieldName);
                }
            case 'u256':
                {
                    return borsh.u256(fieldName);
                }
            case 'i256':
                {
                    return borsh.i256(fieldName);
                }
            case 'bytes':
                {
                    return borsh.vecU8(fieldName);
                }
            case 'string':
                {
                    return borsh.str(fieldName);
                }
            case 'publicKey':
                {
                    return borsh.publicKey(fieldName);
                }
            default:
                {
                    if ('vec' in field.type) {
                        return borsh.vec(IdlCoder.fieldLayout({
                            name: undefined,
                            type: field.type.vec
                        }, types), fieldName);
                    } else if ('option' in field.type) {
                        return borsh.option(IdlCoder.fieldLayout({
                            name: undefined,
                            type: field.type.option
                        }, types), fieldName);
                    } else if ('defined' in field.type) {
                        var defined_1 = field.type.defined;
                        if (types === undefined) {
                            throw new anchor_1.IdlError('User defined types not provided');
                        }
                        var filtered = types.filter(function(t) {
                            return t.name === defined_1;
                        });
                        if (filtered.length !== 1) {
                            throw new anchor_1.IdlError("Type not found: ".concat(JSON.stringify(field)));
                        }
                        return IdlCoder.typeDefLayout(filtered[0], types, fieldName);
                    } else if ('array' in field.type) {
                        var arrayTy = field.type.array[0];
                        var arrayLen = field.type.array[1];
                        var innerLayout = IdlCoder.fieldLayout({
                            name: undefined,
                            type: arrayTy
                        }, types);
                        return borsh.array(innerLayout, arrayLen, fieldName);
                    } else {
                        throw new Error("Not yet implemented: ".concat(field));
                    }
                }
        }
    };
    IdlCoder.typeDefLayout = function(typeDef, types, name) {
        if (types === void 0) {
            types = [];
        }
        if (typeDef.type.kind === 'struct') {
            var fieldLayouts = typeDef.type.fields.map(function(field) {
                var x = IdlCoder.fieldLayout(field, types);
                return x;
            });
            return borsh.struct(fieldLayouts, name);
        } else if (typeDef.type.kind === 'enum') {
            var variants = typeDef.type.variants.map(function(variant) {
                var name = (0, camelcase_1.default)(variant.name);
                if (variant.fields === undefined) {
                    return borsh.struct([], name);
                }
                var fieldLayouts = variant.fields.map(function(f, i) {
                    if (!f.hasOwnProperty('name')) {
                        return IdlCoder.fieldLayout({
                            type: f,
                            name: i.toString()
                        }, types);
                    }
                    return IdlCoder.fieldLayout(f, types);
                });
                return borsh.struct(fieldLayouts, name);
            });
            if (name !== undefined) {
                return borsh.rustEnum(variants).replicate(name);
            }
            return borsh.rustEnum(variants, name);
        } else {
            throw new Error("Unknown type kint: ".concat(typeDef));
        }
    };
    return IdlCoder;
}();
exports.IdlCoder = IdlCoder;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/anchorCpiEvents.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = this && this.__generator || function(thisArg, body) {
    var _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, f, y, t, g;
    return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    "TURBOPACK unreachable";
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getCpiEventsFromTransaction = exports.getAndValidateEvent = void 0;
var anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.27.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
var perpetuals_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/idl/perpetuals.js [app-route] (ecmascript)");
var bytes_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.27.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/cjs/utils/bytes/index.js [app-route] (ecmascript)");
function getAndValidateEvent(previousProgram, currentProgram, eventAuthority, eventCoder, ixData) {
    var eventTag = Buffer.from([
        0x1d,
        0x9a,
        0xcb,
        0x51,
        0x2e,
        0xa5,
        0x45,
        0xe4
    ].reverse());
    if (!ixData.slice(0, 8).equals(eventTag)) {
        throw new Error("Invalid CPI Event: Event tag mismatch");
    }
    var expectedAuthority = anchor_1.web3.PublicKey.findProgramAddressSync([
        Buffer.from("__event_authority")
    ], currentProgram)[0];
    if (expectedAuthority.toString() !== eventAuthority.toString()) {
        throw new Error("Invalid CPI Event: Event authority does not match");
    }
    var event = eventCoder.decode(bytes_1.base64.encode(ixData.slice(8)));
    if (!event) {
        throw new Error("Invalid CPI Event: Failed to decode event");
    }
    return event;
}
exports.getAndValidateEvent = getAndValidateEvent;
var getCpiEventsFromTransaction = function(response) {
    return __awaiter(void 0, void 0, void 0, function() {
        var instructions, innerInstructions, accounts, eventCoder, events, _loop_1, _i, innerInstructions_1, packet;
        var _a, _b;
        return __generator(this, function(_c) {
            instructions = response.transaction.message.compiledInstructions;
            innerInstructions = response.meta.innerInstructions;
            accounts = response.transaction.message.staticAccountKeys.concat((_a = response.meta.loadedAddresses.writable) !== null && _a !== void 0 ? _a : []).concat((_b = response.meta.loadedAddresses.readonly) !== null && _b !== void 0 ? _b : []);
            eventCoder = new anchor_1.BorshEventCoder(perpetuals_1.IDL);
            events = [];
            _loop_1 = function(packet) {
                var previousProgram = accounts[instructions[packet.index].programIdIndex];
                packet.instructions.forEach(function(instruction, indexofInnerIns) {
                    var bytes = bytes_1.bs58.decode(instruction.data);
                    var currentProgram = accounts[instruction.programIdIndex];
                    var eventAuthority = accounts[instruction.accounts[0]];
                    try {
                        var event_1 = getAndValidateEvent(previousProgram, currentProgram, eventAuthority, eventCoder, bytes);
                        events.push(event_1);
                    } catch (err) {}
                });
            };
            for(_i = 0, innerInstructions_1 = innerInstructions; _i < innerInstructions_1.length; _i++){
                packet = innerInstructions_1[_i];
                _loop_1(packet);
            }
            return [
                2,
                events
            ];
        });
    });
};
exports.getCpiEventsFromTransaction = getCpiEventsFromTransaction;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/alt.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = this && this.__generator || function(thisArg, body) {
    var _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, f, y, t, g;
    return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    "TURBOPACK unreachable";
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getAddressesInTable = exports.addAddressesToTable = exports.createLookupTable = void 0;
var web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.95.8_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function createLookupTable(authority, payer, connection) {
    return __awaiter(this, void 0, void 0, function() {
        var _a, lookupTableInst, lookUpTableAddress, _b, _c;
        var _d;
        return __generator(this, function(_e) {
            switch(_e.label){
                case 0:
                    _c = (_b = web3_js_1.AddressLookupTableProgram).createLookupTable;
                    _d = {
                        authority: authority,
                        payer: payer
                    };
                    return [
                        4,
                        connection.getSlot()
                    ];
                case 1:
                    _a = _c.apply(_b, [
                        (_d.recentSlot = _e.sent(), _d)
                    ]), lookupTableInst = _a[0], lookUpTableAddress = _a[1];
                    return [
                        2,
                        {
                            lookupTableInst: lookupTableInst,
                            lookUpTableAddress: lookUpTableAddress
                        }
                    ];
            }
        });
    });
}
exports.createLookupTable = createLookupTable;
function addAddressesToTable(authority, payer, lookUpTableAddress, addressesToAdd) {
    return __awaiter(this, void 0, void 0, function() {
        var addAddressesInstruction;
        return __generator(this, function(_a) {
            addAddressesInstruction = web3_js_1.AddressLookupTableProgram.extendLookupTable({
                payer: payer,
                authority: authority,
                lookupTable: lookUpTableAddress,
                addresses: addressesToAdd
            });
            return [
                2,
                addAddressesInstruction
            ];
        });
    });
}
exports.addAddressesToTable = addAddressesToTable;
function getAddressesInTable(connection, lookUpTableAddress) {
    return __awaiter(this, void 0, void 0, function() {
        var lookupTableAccount;
        return __generator(this, function(_a) {
            switch(_a.label){
                case 0:
                    return [
                        4,
                        connection.getAddressLookupTable(lookUpTableAddress)
                    ];
                case 1:
                    lookupTableAccount = _a.sent();
                    if (!lookupTableAccount.value) return [
                        2
                    ];
                    return [
                        2,
                        lookupTableAccount.value.state.addresses
                    ];
            }
        });
    });
}
exports.getAddressesInTable = getAddressesInTable;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/OraclePrice.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.OraclePrice = void 0;
var anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.27.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
var constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/constants/index.js [app-route] (ecmascript)");
var utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/index.js [app-route] (ecmascript)");
var OraclePrice = function() {
    function OraclePrice(parseData) {
        Object.assign(this, parseData);
    }
    OraclePrice.from = function(parseData) {
        return new OraclePrice(parseData);
    };
    OraclePrice.prototype.toContractOraclePrice = function() {
        return {
            price: this.price,
            exponent: this.exponent.toNumber()
        };
    };
    OraclePrice.prototype.cmp = function(other) {
        var lhs, rhs;
        if (this.exponent.eq(other.exponent)) {
            lhs = this.price;
            rhs = other.price;
        } else if (this.exponent.lt(other.exponent)) {
            var scaled_price = other.scale_to_exponent(this.exponent);
            lhs = this.price;
            rhs = scaled_price.price;
        } else {
            var scaled_price = this.scale_to_exponent(other.exponent);
            lhs = scaled_price.price;
            rhs = other.price;
        }
        ;
        return lhs.cmp(rhs);
    };
    OraclePrice.prototype.getDivergenceFactor = function(other) {
        var thisPrice, reference;
        if (this.exponent.lte(other.exponent)) {
            thisPrice = this;
            reference = other.scale_to_exponent(this.exponent);
        } else {
            thisPrice = this.scale_to_exponent(other.exponent);
            reference = other;
        }
        if (!thisPrice.exponent.eq(reference.exponent)) {
            throw "Exponents mistmatch ".concat(thisPrice.exponent.toNumber(), " != ").concat(reference.exponent.toNumber());
        }
        var factor;
        if (thisPrice.price.gt(reference.price)) {
            factor = OraclePrice.from({
                price: thisPrice.price.sub(reference.price).div(reference.price),
                exponent: thisPrice.exponent,
                confidence: constants_1.BN_ZERO,
                timestamp: constants_1.BN_ZERO
            });
        } else {
            if (!reference.price.isZero()) {
                factor = OraclePrice.from({
                    price: reference.price.sub(thisPrice.price).div(reference.price),
                    exponent: thisPrice.exponent,
                    confidence: constants_1.BN_ZERO,
                    timestamp: constants_1.BN_ZERO
                });
            } else {
                factor = OraclePrice.from({
                    price: constants_1.BN_ZERO,
                    exponent: thisPrice.exponent,
                    confidence: constants_1.BN_ZERO,
                    timestamp: constants_1.BN_ZERO
                });
            }
        }
        return factor.scale_to_exponent(new anchor_1.BN(-1 * constants_1.BPS_DECIMALS)).price;
    };
    OraclePrice.prototype.scale_to_exponent = function(target_exponent) {
        if (!target_exponent.isNeg()) {
            throw new Error("Target exponent must be negative");
        }
        if (target_exponent.eq(this.exponent)) {
            return this;
        }
        var delta = target_exponent.sub(this.exponent);
        if (delta.gt(constants_1.BN_ZERO)) {
            return new OraclePrice({
                price: this.price.div(new anchor_1.BN(10).pow(delta)),
                confidence: this.confidence.div(new anchor_1.BN(10).pow(delta)),
                exponent: target_exponent
            });
        } else {
            return new OraclePrice({
                price: this.price.mul(new anchor_1.BN(10).pow(delta.neg())),
                confidence: this.confidence.mul(new anchor_1.BN(10).pow(delta.neg())),
                exponent: target_exponent
            });
        }
    };
    OraclePrice.prototype.getTokenAmount = function(asset_amount_usd, token_decimals) {
        if (asset_amount_usd.isZero() || this.price.isZero()) {
            return constants_1.BN_ZERO;
        }
        return (0, utils_1.checkedDecimalDiv)(asset_amount_usd, new anchor_1.BN(-1 * constants_1.USD_DECIMALS), this.price, this.exponent, new anchor_1.BN(-1 * token_decimals));
    };
    OraclePrice.prototype.getAssetAmountUsd = function(token_amount, token_decimals) {
        if (token_amount.isZero() || this.price.isZero()) {
            return constants_1.BN_ZERO;
        }
        return (0, utils_1.checkedDecimalMul)(token_amount, new anchor_1.BN(-1 * token_decimals), this.price, this.exponent, new anchor_1.BN(-1 * constants_1.USD_DECIMALS));
    };
    OraclePrice.prototype.toUiPrice = function(precision) {
        return (0, utils_1.nativeToUiDecimals)(this.price, this.exponent.toNumber() * -1, precision);
    };
    return OraclePrice;
}();
exports.OraclePrice = OraclePrice;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/backupOracle.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = this && this.__generator || function(thisArg, body) {
    var _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, f, y, t, g;
    return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    "TURBOPACK unreachable";
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
var _a;
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createBackupOracleInstruction = exports.getBackupOracleInstruction = exports.getPythnetOraclePrices = exports.pythPriceServiceConnection = exports.API_ENDPOINT = void 0;
var price_service_client_1 = __turbopack_require__("[project]/node_modules/.pnpm/@pythnetwork+price-service-client@1.9.0_bufferutil@4.0.9_utf-8-validate@5.0.10/node_modules/@pythnetwork/price-service-client/lib/index.js [app-route] (ecmascript)");
var web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.95.8_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
var bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
var bs58_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bs58@5.0.0/node_modules/bs58/index.js [app-route] (ecmascript)"));
var tweetnacl_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tweetnacl@1.0.3/node_modules/tweetnacl/nacl-fast.js [app-route] (ecmascript)"));
exports.API_ENDPOINT = (_a = process.env.NEXT_PUBLIC_API_ENDPOINT) !== null && _a !== void 0 ? _a : 'https://api.prod.flash.trade';
exports.pythPriceServiceConnection = new price_service_client_1.PriceServiceConnection('https://hermes.pyth.network', {
    priceFeedRequestConfig: {}
});
var getPythnetOraclePrices = function(program, poolConfig, backupOracleSecretKey) {
    return __awaiter(void 0, void 0, void 0, function() {
        var custodyMintKeys, pythPriceIds, _loop_1, _i, custodyMintKeys_1, custodyMintKey, currentPrices, backupOracleAccount, caches_1, permissionlessPythCache, message, signature, preInstruction;
        return __generator(this, function(_a) {
            switch(_a.label){
                case 0:
                    custodyMintKeys = poolConfig.custodies.map(function(f) {
                        return f.mintKey;
                    });
                    pythPriceIds = [];
                    _loop_1 = function(custodyMintKey) {
                        var t = poolConfig.tokens.find(function(f) {
                            return f.mintKey.equals(custodyMintKey);
                        });
                        if (t) {
                            pythPriceIds.push(t.pythPriceId);
                        }
                    };
                    for(_i = 0, custodyMintKeys_1 = custodyMintKeys; _i < custodyMintKeys_1.length; _i++){
                        custodyMintKey = custodyMintKeys_1[_i];
                        _loop_1(custodyMintKey);
                    }
                    return [
                        4,
                        exports.pythPriceServiceConnection.getLatestPriceFeeds(pythPriceIds)
                    ];
                case 1:
                    currentPrices = _a.sent();
                    if (!currentPrices) return [
                        2
                    ];
                    backupOracleAccount = web3_js_1.Keypair.fromSecretKey(bs58_1.default.decode(backupOracleSecretKey));
                    if (pythPriceIds.length === currentPrices.length) {
                        caches_1 = currentPrices.map(function(price) {
                            var uncheckedPrice = price.getPriceUnchecked();
                            var uncheckedEmaPrice = price.getEmaPriceUnchecked();
                            return {
                                price: new bn_js_1.default(uncheckedPrice.price),
                                expo: uncheckedPrice.expo,
                                conf: new bn_js_1.default(uncheckedPrice.conf),
                                emaPrice: new bn_js_1.default(uncheckedEmaPrice.price),
                                publishTime: new bn_js_1.default(uncheckedPrice.publishTime)
                            };
                        });
                        permissionlessPythCache = {
                            backupCache: caches_1
                        };
                        message = program._coder.types.encode('PermissionlessPythCache', permissionlessPythCache);
                        signature = tweetnacl_1.default.sign.detached(message, backupOracleAccount.secretKey);
                        preInstruction = web3_js_1.Ed25519Program.createInstructionWithPublicKey({
                            publicKey: backupOracleAccount.publicKey.toBytes(),
                            message: message,
                            signature: signature
                        });
                        return [
                            2,
                            preInstruction
                        ];
                    }
                    return [
                        2
                    ];
            }
        });
    });
};
exports.getPythnetOraclePrices = getPythnetOraclePrices;
var getBackupOracleInstruction = function(program, poolConfig, backupOracleSecretKey, backupCaches) {
    var custodiesLength = poolConfig.custodies.length;
    if (!backupCaches.length) {
        console.error("incorrect prices passed ,", custodiesLength, backupCaches.length);
        throw new Error("incorrect prices passed : custodiesLength: ".concat(custodiesLength, " , backupCaches.length: ").concat(backupCaches.length));
    }
    ;
    var backupOracleAccount = web3_js_1.Keypair.fromSecretKey(bs58_1.default.decode(backupOracleSecretKey));
    if (custodiesLength === backupCaches.length) {
        var permissionlessPythCache = {
            backupCache: backupCaches
        };
        var message = program._coder.types.encode('PermissionlessPythCache', permissionlessPythCache);
        var signature = tweetnacl_1.default.sign.detached(message, backupOracleAccount.secretKey);
        var preInstruction = web3_js_1.Ed25519Program.createInstructionWithPublicKey({
            publicKey: backupOracleAccount.publicKey.toBytes(),
            message: message,
            signature: signature
        });
        return preInstruction;
    } else {
        console.error("incorrect prices passed ,", custodiesLength, backupCaches.length);
        throw new Error("incorrect prices passed : custodiesLength: ".concat(custodiesLength, " , currentPrices.length: ").concat(backupCaches.length));
    }
};
exports.getBackupOracleInstruction = getBackupOracleInstruction;
function createBackupOracleInstruction(poolAddress, overrideCheck) {
    if (overrideCheck === void 0) {
        overrideCheck = false;
    }
    return __awaiter(this, void 0, void 0, function() {
        var backupOracleData, backUpOracleInstruction, error_1;
        return __generator(this, function(_a) {
            switch(_a.label){
                case 0:
                    _a.trys.push([
                        0,
                        3,
                        ,
                        4
                    ]);
                    return [
                        4,
                        fetch("".concat(exports.API_ENDPOINT, "/backup-oracle/prices?poolAddress=").concat(poolAddress))
                    ];
                case 1:
                    return [
                        4,
                        _a.sent().json()
                    ];
                case 2:
                    backupOracleData = _a.sent();
                    backUpOracleInstruction = new web3_js_1.TransactionInstruction({
                        keys: backupOracleData.keys,
                        programId: new web3_js_1.PublicKey(backupOracleData.programId),
                        data: Buffer.from(backupOracleData.data)
                    });
                    return [
                        2,
                        [
                            backUpOracleInstruction
                        ]
                    ];
                case 3:
                    error_1 = _a.sent();
                    console.error('Error creating backup oracle instruction:', error_1);
                    return [
                        3,
                        4
                    ];
                case 4:
                    return [
                        2,
                        []
                    ];
            }
        });
    });
}
exports.createBackupOracleInstruction = createBackupOracleInstruction;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/ViewHelper.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = this && this.__generator || function(thisArg, body) {
    var _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, f, y, t, g;
    return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    "TURBOPACK unreachable";
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
};
var __spreadArray = this && this.__spreadArray || function(to, from, pack) {
    if (pack || arguments.length === 2) for(var i = 0, l = from.length, ar; i < l; i++){
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ViewHelper = void 0;
var web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.95.8_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
var base64_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.27.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/cjs/utils/bytes/base64.js [app-route] (ecmascript)");
var perpetuals_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/idl/perpetuals.js [app-route] (ecmascript)");
var IdlCoder_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/IdlCoder.js [app-route] (ecmascript)");
var ViewHelper = function() {
    function ViewHelper(client) {
        this.perpetualsClient = client;
    }
    ViewHelper.prototype.decodeLogs = function(data, instructionNumber, instructionName) {
        var _a, _b, _c;
        if (instructionName === void 0) {
            instructionName = '';
        }
        try {
            var returnPrefix_1 = "Program return: ".concat(this.perpetualsClient.programId, " ");
            if (data.value.logs && data.value.err === null) {
                var returnLog = data.value.logs.find(function(l) {
                    return l.startsWith(returnPrefix_1);
                });
                if (!returnLog) {
                    throw new Error('View expected return log');
                }
                var returnData = (0, base64_1.decode)(returnLog.slice(returnPrefix_1.length));
                var returnType = perpetuals_1.IDL.instructions[instructionNumber].returns;
                if (!returnType) {
                    throw new Error('View expected return type');
                }
                var coder = IdlCoder_1.IdlCoder.fieldLayout({
                    type: returnType
                }, Array.from(__spreadArray(__spreadArray([], (_a = perpetuals_1.IDL.accounts) !== null && _a !== void 0 ? _a : [], true), (_b = perpetuals_1.IDL.types) !== null && _b !== void 0 ? _b : [], true)));
                return coder.decode(returnData);
            } else {
                console.error('No Logs Found : name : data:', instructionName, data);
                console.error('Logs err::', (_c = data.value.logs) === null || _c === void 0 ? void 0 : _c.toString());
                throw new Error("FLASH No Logs Found ".concat({
                    cause: data
                }));
            }
        } catch (error) {
            console.log("decode error::", error);
        }
    };
    ViewHelper.prototype.simulateTransaction = function(transaction) {
        return __awaiter(this, void 0, void 0, function() {
            var latestBlockhash, messageV0, transaction2;
            return __generator(this, function(_a) {
                switch(_a.label){
                    case 0:
                        transaction.feePayer = this.perpetualsClient.provider.publicKey;
                        return [
                            4,
                            this.perpetualsClient.provider.connection.getLatestBlockhash('confirmed')
                        ];
                    case 1:
                        latestBlockhash = _a.sent();
                        messageV0 = new web3_js_1.TransactionMessage({
                            payerKey: this.perpetualsClient.provider.publicKey,
                            recentBlockhash: latestBlockhash.blockhash,
                            instructions: transaction.instructions
                        }).compileToV0Message(this.perpetualsClient.addressLookupTables);
                        transaction2 = new web3_js_1.VersionedTransaction(messageV0);
                        return [
                            2,
                            this.perpetualsClient.provider.connection.simulateTransaction(transaction2, {
                                sigVerify: false,
                                replaceRecentBlockhash: true
                            })
                        ];
                }
            });
        });
    };
    return ViewHelper;
}();
exports.ViewHelper = ViewHelper;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/PoolConfig.json (json)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__(JSON.parse("{\"cluster_urls\":{\"devnet\":\"https://api.devnet.solana.com\",\"localnet\":\"http://127.0.0.1:8899\",\"mainnet\":\"https://api.mainnet-beta.solana.com\",\"testnet\":\"http://api.testnet.rpcpool.com\"},\"pools\":[{\"programId\":\"FLASH6Lo6h3iasJKWDs2F8TkW2UKf3s15C8PMGuVfgBn\",\"perpComposibilityProgramId\":\"FSWAPViR8ny5K96hezav8jynVubP2dJ2L7SbKzds2hwm\",\"fbNftRewardProgramId\":\"FBRWDXSLysNbFQk64MQJcpkXP8e4fjezsGabV8jV7d7o\",\"cluster\":\"mainnet-beta\",\"poolName\":\"Crypto.1\",\"poolAddress\":\"HfF7GCcEc76xubFCHLLXRdYcgRzwjEPdfKWqzRS8Ncog\",\"stakedLpTokenMint\":\"9Fzv4s5t2bNwwJoeeywMwypop3JegsuDb1eDbMnPr4TX\",\"compoundingTokenMint\":\"NUZ3FDWTtN5SP72BsefbsqpnbAY5oe21LE8bCSkqsEK\",\"stakedLpVault\":\"4XUhXBvgyCyU6LdZnutxj8Zc7oXPnTeKeEBwBmne47Bq\",\"compoundingLpVault\":\"BKnxrbQ6itdCz7r8erknRosvJ7NBuXoTjU3NZaEsyDQH\",\"metadataAccount\":\"H9kfgaiHv8LnQUBWVoM8x69bidG2d16uWPDbMS3JCP5c\",\"lpDecimals\":6,\"compoundingLpTokenSymbol\":\"FLP.1\",\"stakedLpTokenSymbol\":\"sFLP.1\",\"perpetuals\":\"7DWCtB5Z8rPiyBMKUwqyC95R9tJpbhoQhLM9LbK3Z5QZ\",\"transferAuthority\":\"81xGAvJ27ZeRThU2JEfKAUeT4Fx6qCCd8WHZpujZbiiG\",\"multisig\":\"3FqKnAQrvr6G6AqCAWKdqg9fVe6ceAk3A5Y1ibeQqV2V\",\"addressLookupTableAddresses\":[\"AUebVLw8UwN35Us2XcPQaTQejJoQ5T7ckWzxHTwN1mkM\"],\"backupOracle\":\"AjAubETeBLhebBxLcErmzbavZfqF9bCxkpRAdyJtoi9G\",\"nftCollectionAddress\":\"H4EQ8pcE7PQSQGG1WYW4hAA1nizU6ULYipHZcYk9b64u\",\"rewardDistributionProgram\":{\"programId\":\"FARNT7LL119pmy9vSkN9q1ApZESPaKHuuX5Acz1oBoME\",\"transferAuthority\":\"E2GZM2FQmX2uGBcBpLQB3s5UhPJvM2F8BgHEkBG45xBN\",\"rewardVault\":\"6sXyDryKp6hqV6E1jc7gbzTeWxTFUW1A6s39vzp55hLL\",\"rewardMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"rewardTokenAccount\":\"EhH4KEra2UfKdwRErjEFf2286BQ3BstKxfLiyYnF513h\"},\"tokens\":[{\"symbol\":\"USDC\",\"mintKey\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\",\"isToken2022\":false},{\"symbol\":\"SOL\",\"mintKey\":\"So11111111111111111111111111111111111111112\",\"decimals\":9,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.SOL/USD\",\"pythPriceId\":\"0xef0d8b6fda2ceba41da15d4095d1da392a0d2f8ed0c6c7bc0f4cfac8c280b56d\",\"isToken2022\":false},{\"symbol\":\"WSOL\",\"mintKey\":\"So11111111111111111111111111111111111111112\",\"decimals\":9,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.SOL/USD\",\"pythPriceId\":\"0xef0d8b6fda2ceba41da15d4095d1da392a0d2f8ed0c6c7bc0f4cfac8c280b56d\",\"isToken2022\":false},{\"symbol\":\"BTC\",\"mintKey\":\"3NZ9JMVBmGAqocybic2c7LQCJScmgsAZ6vQqTDzcqmJh\",\"decimals\":8,\"usdPrecision\":2,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.BTC/USD\",\"pythPriceId\":\"0xe62df6c8b4a85fe1a67db44dc12de5db330f7ac66b72dc658afedf0f4a415b43\",\"isToken2022\":false},{\"symbol\":\"ETH\",\"mintKey\":\"7vfCXTUXx5WJV5JADk17DUJ4ksgau7utNKj4b963voxs\",\"decimals\":8,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.ETH/USD\",\"pythPriceId\":\"0xff61491a931112ddf1bd8147cd1b641375f79f5825126d665480874634fd0ace\",\"isToken2022\":false}],\"custodies\":[{\"custodyId\":0,\"custodyAccount\":\"5N2St2e1BdgWsJiXxfetwWKkHS1BYochAp1ruPFJUfgY\",\"tokenAccount\":\"BC5xAUpEbfeSWi5fJdvhFQhM3eMbTok2c7SY62daB3da\",\"symbol\":\"USDC\",\"mintKey\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":2,\"isStable\":true,\"isVirtual\":false,\"intOracleAddress\":\"GCtJxWQ57B3BJUYdWrhb3TUxzeiDUx275ZCxKkTV6G3N\",\"extOracleAddress\":\"Dpw1EAVrSB1ibxiDQyTAW6Zip3J4Btk2x4SgApQCeFbX\",\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\"},{\"custodyId\":1,\"custodyAccount\":\"BjzZ33nMnbXZ7rw3Uy9Uu1W7BDCzzugqkiZoamJHRKF7\",\"tokenAccount\":\"Hhed3wTHoVoPpnuBntGf236UfowMMAXfxqTLkMyJJENe\",\"symbol\":\"SOL\",\"mintKey\":\"So11111111111111111111111111111111111111112\",\"decimals\":9,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"DXqtMo8qRBfHcK11kBnSaCSXkWKk1huMf94R6sAxLHtf\",\"extOracleAddress\":\"7UVimffxr9ow1uXYxsr4LHAcV58mLzhmwaeKvJ1pjLiE\",\"pythTicker\":\"Crypto.SOL/USD\",\"pythPriceId\":\"0xef0d8b6fda2ceba41da15d4095d1da392a0d2f8ed0c6c7bc0f4cfac8c280b56d\"},{\"custodyId\":2,\"custodyAccount\":\"Ghi8YvZeDEzPAGvve7we3Rthquk84CULra6ERkGQF1Rv\",\"tokenAccount\":\"55UmrYacpb8v7gbKswDofmWjLS8TSP3VB8NKjNfxu11d\",\"symbol\":\"BTC\",\"mintKey\":\"3NZ9JMVBmGAqocybic2c7LQCJScmgsAZ6vQqTDzcqmJh\",\"decimals\":8,\"usdPrecision\":2,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"BYj2rSPK5JcvvVZGBN88j1TmW7mmtf1Rx3GMTqvdwB5c\",\"extOracleAddress\":\"4cSM2e6rvbGQUFiJbqytoVMi5GgghSMr8LwVrT9VPSPo\",\"pythTicker\":\"Crypto.BTC/USD\",\"pythPriceId\":\"0xe62df6c8b4a85fe1a67db44dc12de5db330f7ac66b72dc658afedf0f4a415b43\"},{\"custodyId\":3,\"custodyAccount\":\"4oX9yQW5oW4MEjphzMuUV9gn5VQvjCL1LwkBqrSLscQ9\",\"tokenAccount\":\"FuFoCkfnrDjNmwPr54JEAYTUshXA4gQojevfvv3KXdx7\",\"symbol\":\"ETH\",\"mintKey\":\"7vfCXTUXx5WJV5JADk17DUJ4ksgau7utNKj4b963voxs\",\"decimals\":8,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"31QzXaaxY3XTfLM6QmSfELLFowQaNe6ytiT3GXpxBcbh\",\"extOracleAddress\":\"42amVS4KgzR9rA28tkVYqVXjq9Qa8dcZQMbH5EYFX6XC\",\"pythTicker\":\"Crypto.ETH/USD\",\"pythPriceId\":\"0xff61491a931112ddf1bd8147cd1b641375f79f5825126d665480874634fd0ace\"}],\"markets\":[{\"marketId\":0,\"marketAccount\":\"3vHoXbUvGhEHFsLUmxyC6VWsbYDreb1zMn9TAp5ijN5K\",\"pool\":\"HfF7GCcEc76xubFCHLLXRdYcgRzwjEPdfKWqzRS8Ncog\",\"targetCustody\":\"BjzZ33nMnbXZ7rw3Uy9Uu1W7BDCzzugqkiZoamJHRKF7\",\"collateralCustody\":\"BjzZ33nMnbXZ7rw3Uy9Uu1W7BDCzzugqkiZoamJHRKF7\",\"side\":\"long\",\"maxLev\":100,\"targetCustodyId\":1,\"collateralCustodyId\":1,\"targetMint\":\"So11111111111111111111111111111111111111112\",\"collateralMint\":\"So11111111111111111111111111111111111111112\"},{\"marketId\":1,\"marketAccount\":\"9tvuK63WUV2mgWt7AvWUm7kRUpFKsRX1jewyJ21VTWsM\",\"pool\":\"HfF7GCcEc76xubFCHLLXRdYcgRzwjEPdfKWqzRS8Ncog\",\"targetCustody\":\"BjzZ33nMnbXZ7rw3Uy9Uu1W7BDCzzugqkiZoamJHRKF7\",\"collateralCustody\":\"5N2St2e1BdgWsJiXxfetwWKkHS1BYochAp1ruPFJUfgY\",\"side\":\"short\",\"maxLev\":100,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"So11111111111111111111111111111111111111112\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":2,\"marketAccount\":\"GGV4VHTAEyWGyGubXTiQZiPajCEtGv2Ed2G2BHmY3zNZ\",\"pool\":\"HfF7GCcEc76xubFCHLLXRdYcgRzwjEPdfKWqzRS8Ncog\",\"targetCustody\":\"Ghi8YvZeDEzPAGvve7we3Rthquk84CULra6ERkGQF1Rv\",\"collateralCustody\":\"Ghi8YvZeDEzPAGvve7we3Rthquk84CULra6ERkGQF1Rv\",\"side\":\"long\",\"maxLev\":100,\"targetCustodyId\":2,\"collateralCustodyId\":2,\"targetMint\":\"3NZ9JMVBmGAqocybic2c7LQCJScmgsAZ6vQqTDzcqmJh\",\"collateralMint\":\"3NZ9JMVBmGAqocybic2c7LQCJScmgsAZ6vQqTDzcqmJh\"},{\"marketId\":3,\"marketAccount\":\"AAHFmCVd4JXXrLFmGBataeCJ6CwrYs4cYMiebXmBFvPE\",\"pool\":\"HfF7GCcEc76xubFCHLLXRdYcgRzwjEPdfKWqzRS8Ncog\",\"targetCustody\":\"Ghi8YvZeDEzPAGvve7we3Rthquk84CULra6ERkGQF1Rv\",\"collateralCustody\":\"5N2St2e1BdgWsJiXxfetwWKkHS1BYochAp1ruPFJUfgY\",\"side\":\"short\",\"maxLev\":100,\"targetCustodyId\":2,\"collateralCustodyId\":0,\"targetMint\":\"3NZ9JMVBmGAqocybic2c7LQCJScmgsAZ6vQqTDzcqmJh\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":4,\"marketAccount\":\"8r5MBC3oULSWdm69yn2q3gBLp6h1AL4Wo11LBzcCZGWJ\",\"pool\":\"HfF7GCcEc76xubFCHLLXRdYcgRzwjEPdfKWqzRS8Ncog\",\"targetCustody\":\"4oX9yQW5oW4MEjphzMuUV9gn5VQvjCL1LwkBqrSLscQ9\",\"collateralCustody\":\"4oX9yQW5oW4MEjphzMuUV9gn5VQvjCL1LwkBqrSLscQ9\",\"side\":\"long\",\"maxLev\":100,\"targetCustodyId\":3,\"collateralCustodyId\":3,\"targetMint\":\"7vfCXTUXx5WJV5JADk17DUJ4ksgau7utNKj4b963voxs\",\"collateralMint\":\"7vfCXTUXx5WJV5JADk17DUJ4ksgau7utNKj4b963voxs\"},{\"marketId\":5,\"marketAccount\":\"GxkxRPheec7f9ZbamzeWdiHiMbrgyoUV7MFPxXW1387q\",\"pool\":\"HfF7GCcEc76xubFCHLLXRdYcgRzwjEPdfKWqzRS8Ncog\",\"targetCustody\":\"4oX9yQW5oW4MEjphzMuUV9gn5VQvjCL1LwkBqrSLscQ9\",\"collateralCustody\":\"5N2St2e1BdgWsJiXxfetwWKkHS1BYochAp1ruPFJUfgY\",\"side\":\"short\",\"maxLev\":100,\"targetCustodyId\":3,\"collateralCustodyId\":0,\"targetMint\":\"7vfCXTUXx5WJV5JADk17DUJ4ksgau7utNKj4b963voxs\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"}]},{\"programId\":\"FLASH6Lo6h3iasJKWDs2F8TkW2UKf3s15C8PMGuVfgBn\",\"perpComposibilityProgramId\":\"FSWAPViR8ny5K96hezav8jynVubP2dJ2L7SbKzds2hwm\",\"fbNftRewardProgramId\":\"FBRWDXSLysNbFQk64MQJcpkXP8e4fjezsGabV8jV7d7o\",\"cluster\":\"mainnet-beta\",\"poolName\":\"Virtual.1\",\"poolAddress\":\"KwhpybQPe9xuZFmAfcjLHj3ukownWex1ratyascAC1X\",\"stakedLpTokenMint\":\"CrdMPbjooMmz6RoVgUnczWoeZka2QF14pikcCTpzRMxz\",\"compoundingTokenMint\":\"AbVzeRUss8QJYzv2WDizDJ2RtsD1jkVyRjNdAzX94JhG\",\"stakedLpVault\":\"ZY6ECXS7TKCKk89fekXhut7SrwRXRYFKCjc7oftWCoV\",\"compoundingLpVault\":\"7g9wcgKLr9vBB4Ssz3y6yCZ8CdydChzHm1MenftBfrxs\",\"metadataAccount\":\"HD5cfUWyMw8J1CaRENKw8zruY9DMJDWni5iejg4onY7G\",\"lpDecimals\":6,\"compoundingLpTokenSymbol\":\"FLP.2\",\"stakedLpTokenSymbol\":\"sFLP.2\",\"perpetuals\":\"7DWCtB5Z8rPiyBMKUwqyC95R9tJpbhoQhLM9LbK3Z5QZ\",\"transferAuthority\":\"81xGAvJ27ZeRThU2JEfKAUeT4Fx6qCCd8WHZpujZbiiG\",\"multisig\":\"3FqKnAQrvr6G6AqCAWKdqg9fVe6ceAk3A5Y1ibeQqV2V\",\"addressLookupTableAddresses\":[\"AUebVLw8UwN35Us2XcPQaTQejJoQ5T7ckWzxHTwN1mkM\"],\"backupOracle\":\"AjAubETeBLhebBxLcErmzbavZfqF9bCxkpRAdyJtoi9G\",\"nftCollectionAddress\":\"H4EQ8pcE7PQSQGG1WYW4hAA1nizU6ULYipHZcYk9b64u\",\"rewardDistributionProgram\":{\"programId\":\"FARNT7LL119pmy9vSkN9q1ApZESPaKHuuX5Acz1oBoME\",\"transferAuthority\":\"E2GZM2FQmX2uGBcBpLQB3s5UhPJvM2F8BgHEkBG45xBN\",\"rewardVault\":\"6sXyDryKp6hqV6E1jc7gbzTeWxTFUW1A6s39vzp55hLL\",\"rewardMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"rewardTokenAccount\":\"EhH4KEra2UfKdwRErjEFf2286BQ3BstKxfLiyYnF513h\"},\"tokens\":[{\"symbol\":\"USDC\",\"mintKey\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\",\"isToken2022\":false},{\"symbol\":\"XAU\",\"mintKey\":\"XAUfcdPHmEBnj78YnZ5YxqdwBmgbwoY5VfrRwETnKuQ\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":true,\"pythTicker\":\"Metal.XAU/USD\",\"pythPriceId\":\"0x765d2ba906dbc32ca17cc11f5310a89e9ee1f6420508c63861f2f8ba4ee34bb2\",\"isToken2022\":false},{\"symbol\":\"XAG\",\"mintKey\":\"XAGLictSZUYkCHgBWoPitFCDJECNZx1DVTzV74iM9dP\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":true,\"pythTicker\":\"Metal.XAG/USD\",\"pythPriceId\":\"0xf2fb02c32b055c805e7238d628e5e9dadef274376114eb1f012337cabe93871e\",\"isToken2022\":false},{\"symbol\":\"EUR\",\"mintKey\":\"EURPnveVbdoJkGs7qYqsEWBcCH4ZHChKEBbDGaQx4rUK\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":true,\"pythTicker\":\"FX.EUR/USD\",\"pythPriceId\":\"0xa995d00bb36a63cef7fd2c287dc105fc8f3d93779f062f09551b0af3e81ec30b\",\"isToken2022\":false},{\"symbol\":\"GBP\",\"mintKey\":\"GBPvXsT3uQVBmipvhhU5NW1JfhMJ2maYqLAbPzUq5NnY\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":true,\"pythTicker\":\"FX.GBP/USD\",\"pythPriceId\":\"0x84c2dde9633d93d1bcad84e7dc41c9d56578b7ec52fabedc1f335d673df0a7c1\",\"isToken2022\":false},{\"symbol\":\"AUD\",\"mintKey\":\"AUDdbsJZpT1pFErezhe9pvcf97XnvD8oo8etZbeFbBX\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":true,\"pythTicker\":\"FX.AUD/USD\",\"pythPriceId\":\"0x67a6f93030420c1c9e3fe37c1ab6b77966af82f995944a9fefce357a22854a80\",\"isToken2022\":false}],\"custodies\":[{\"custodyId\":0,\"custodyAccount\":\"9yANuRkTRxb9jjxnG1h3xcUz2kM8fJgDbdYJV4PfZ7dy\",\"tokenAccount\":\"7b2jY9CeCWCnyKBvaLSnsV7qwUhbJGsJTPdyCsspPY7Q\",\"symbol\":\"USDC\",\"mintKey\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":2,\"isStable\":true,\"isVirtual\":false,\"intOracleAddress\":\"GCtJxWQ57B3BJUYdWrhb3TUxzeiDUx275ZCxKkTV6G3N\",\"extOracleAddress\":\"Dpw1EAVrSB1ibxiDQyTAW6Zip3J4Btk2x4SgApQCeFbX\",\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\"},{\"custodyId\":1,\"custodyAccount\":\"3j1xiP6GckKCzsTm6sni5iy6zrpZX5BWZGbKCq5buk4d\",\"tokenAccount\":\"Ej1uR6uJvbBDhPnftbUy5GtdJiHrZKnKn9uWV728edxd\",\"symbol\":\"XAU\",\"mintKey\":\"XAUfcdPHmEBnj78YnZ5YxqdwBmgbwoY5VfrRwETnKuQ\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":true,\"intOracleAddress\":\"9JUUs2uFLHmPo6gTXJecYB6txdY2VXV2tfu2WQQjsNAu\",\"extOracleAddress\":\"2uPQGpm8X4ZkxMHxrAW1QuhXcse1AHEgPih6Xp9NuEWW\",\"pythTicker\":\"Metal.XAU/USD\",\"pythPriceId\":\"0x765d2ba906dbc32ca17cc11f5310a89e9ee1f6420508c63861f2f8ba4ee34bb2\"},{\"custodyId\":2,\"custodyAccount\":\"GMqeFJ8LG5BcrRtVgvfQuA7giBETcY76ikC8h5hPh59h\",\"tokenAccount\":\"74SPExqfArpVpCvhnoDRWxdsk72KkERD1o8yCkSXfUpm\",\"symbol\":\"XAG\",\"mintKey\":\"XAGLictSZUYkCHgBWoPitFCDJECNZx1DVTzV74iM9dP\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":true,\"intOracleAddress\":\"8Fwj8PHmoXzX7XMSiCiSvCwXTdfJ9U9SPcu4gbN3mCUN\",\"extOracleAddress\":\"H9JxsWwtDZxjSL6m7cdCVsWibj3JBMD9sxqLjadoZnot\",\"pythTicker\":\"Metal.XAG/USD\",\"pythPriceId\":\"0xf2fb02c32b055c805e7238d628e5e9dadef274376114eb1f012337cabe93871e\"},{\"custodyId\":3,\"custodyAccount\":\"7WWSRZSgFmp7UDfD1KHWYJ2CqXVbpCdQ5cQfgBxjpFeL\",\"tokenAccount\":\"4kYBdq8PVyt1KXhHk6Mcc3wDLJCjZ4maZZdsoorSEfn8\",\"symbol\":\"EUR\",\"mintKey\":\"EURPnveVbdoJkGs7qYqsEWBcCH4ZHChKEBbDGaQx4rUK\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":true,\"intOracleAddress\":\"Fs9bKiF3eZMkQic39UD96A1jTqgrYHARCaPQ5MppYWay\",\"extOracleAddress\":\"Fu76ChamBDjE8UuGLV6GP2AcPPSU6gjhkNhAyuoPm7ny\",\"pythTicker\":\"FX.EUR/USD\",\"pythPriceId\":\"0xa995d00bb36a63cef7fd2c287dc105fc8f3d93779f062f09551b0af3e81ec30b\"},{\"custodyId\":4,\"custodyAccount\":\"Ah1Kd146CtAexGvbVNWRMQ8aXJTJDf4AopNLQZKGfYck\",\"tokenAccount\":\"2r28rhDGgUjhw6kJCg8oYifP6aVQ7jbgm7Ae2Jmnrigu\",\"symbol\":\"GBP\",\"mintKey\":\"GBPvXsT3uQVBmipvhhU5NW1JfhMJ2maYqLAbPzUq5NnY\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":true,\"intOracleAddress\":\"Gsy7UDnDQYVKcEcNtu8TZbjuE5eDaMsdQEJwygmMT6Ro\",\"extOracleAddress\":\"G25Tm7UkVruTJ7mcbCxFm45XGWwsH72nJKNGcHEQw1tU\",\"pythTicker\":\"FX.GBP/USD\",\"pythPriceId\":\"0x84c2dde9633d93d1bcad84e7dc41c9d56578b7ec52fabedc1f335d673df0a7c1\"},{\"custodyId\":5,\"custodyAccount\":\"AFrALLNuCbBBnhUvEjxrK96e8yjComh2xuTak1y5TEJL\",\"tokenAccount\":\"6yofaNof5vxFfpRMmrmGK2Qge5aSUTAvUW15cL7z8fB1\",\"symbol\":\"AUD\",\"mintKey\":\"AUDdbsJZpT1pFErezhe9pvcf97XnvD8oo8etZbeFbBX\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":true,\"intOracleAddress\":\"3RDtyt5bEFEmWwh99mDN7amsn1uz4eVQ8CJuXzAGaKL8\",\"extOracleAddress\":\"6pPXqXcgFFoLEcXfedWJy3ypNZVJ1F3mgipaDFsvZ1co\",\"pythTicker\":\"FX.AUD/USD\",\"pythPriceId\":\"0x67a6f93030420c1c9e3fe37c1ab6b77966af82f995944a9fefce357a22854a80\"}],\"markets\":[{\"marketId\":0,\"marketAccount\":\"88zawd3Rw6tknWvgEm8QBgBuf5Y2GTeA18S788qUrSnM\",\"pool\":\"KwhpybQPe9xuZFmAfcjLHj3ukownWex1ratyascAC1X\",\"targetCustody\":\"3j1xiP6GckKCzsTm6sni5iy6zrpZX5BWZGbKCq5buk4d\",\"collateralCustody\":\"9yANuRkTRxb9jjxnG1h3xcUz2kM8fJgDbdYJV4PfZ7dy\",\"side\":\"long\",\"maxLev\":100,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"XAUfcdPHmEBnj78YnZ5YxqdwBmgbwoY5VfrRwETnKuQ\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":1,\"marketAccount\":\"G2rj5artQzevbsQtCJ1rkDt3Pd5b6ZYAf8e9AjZPipui\",\"pool\":\"KwhpybQPe9xuZFmAfcjLHj3ukownWex1ratyascAC1X\",\"targetCustody\":\"3j1xiP6GckKCzsTm6sni5iy6zrpZX5BWZGbKCq5buk4d\",\"collateralCustody\":\"9yANuRkTRxb9jjxnG1h3xcUz2kM8fJgDbdYJV4PfZ7dy\",\"side\":\"short\",\"maxLev\":100,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"XAUfcdPHmEBnj78YnZ5YxqdwBmgbwoY5VfrRwETnKuQ\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":2,\"marketAccount\":\"Caqzhuj2Hj5MUwQigdtLNokLZbuqs6NrcmwWbMsSqwqH\",\"pool\":\"KwhpybQPe9xuZFmAfcjLHj3ukownWex1ratyascAC1X\",\"targetCustody\":\"GMqeFJ8LG5BcrRtVgvfQuA7giBETcY76ikC8h5hPh59h\",\"collateralCustody\":\"9yANuRkTRxb9jjxnG1h3xcUz2kM8fJgDbdYJV4PfZ7dy\",\"side\":\"long\",\"maxLev\":100,\"targetCustodyId\":2,\"collateralCustodyId\":0,\"targetMint\":\"XAGLictSZUYkCHgBWoPitFCDJECNZx1DVTzV74iM9dP\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":3,\"marketAccount\":\"7JwSejqoicRSzks3mKwk9TPp5rUNhUttKx2yzgU8UGtc\",\"pool\":\"KwhpybQPe9xuZFmAfcjLHj3ukownWex1ratyascAC1X\",\"targetCustody\":\"GMqeFJ8LG5BcrRtVgvfQuA7giBETcY76ikC8h5hPh59h\",\"collateralCustody\":\"9yANuRkTRxb9jjxnG1h3xcUz2kM8fJgDbdYJV4PfZ7dy\",\"side\":\"short\",\"maxLev\":100,\"targetCustodyId\":2,\"collateralCustodyId\":0,\"targetMint\":\"XAGLictSZUYkCHgBWoPitFCDJECNZx1DVTzV74iM9dP\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":4,\"marketAccount\":\"DXbQZYeT1LfyJvr86wnaMhwkPaFHazmHJkuyb1XzCmo3\",\"pool\":\"KwhpybQPe9xuZFmAfcjLHj3ukownWex1ratyascAC1X\",\"targetCustody\":\"7WWSRZSgFmp7UDfD1KHWYJ2CqXVbpCdQ5cQfgBxjpFeL\",\"collateralCustody\":\"9yANuRkTRxb9jjxnG1h3xcUz2kM8fJgDbdYJV4PfZ7dy\",\"side\":\"long\",\"maxLev\":100,\"targetCustodyId\":3,\"collateralCustodyId\":0,\"targetMint\":\"EURPnveVbdoJkGs7qYqsEWBcCH4ZHChKEBbDGaQx4rUK\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":5,\"marketAccount\":\"2CvUh7whei331D2djP4W2QwV7UUiMbpKgfJNSDojcjne\",\"pool\":\"KwhpybQPe9xuZFmAfcjLHj3ukownWex1ratyascAC1X\",\"targetCustody\":\"7WWSRZSgFmp7UDfD1KHWYJ2CqXVbpCdQ5cQfgBxjpFeL\",\"collateralCustody\":\"9yANuRkTRxb9jjxnG1h3xcUz2kM8fJgDbdYJV4PfZ7dy\",\"side\":\"short\",\"maxLev\":100,\"targetCustodyId\":3,\"collateralCustodyId\":0,\"targetMint\":\"EURPnveVbdoJkGs7qYqsEWBcCH4ZHChKEBbDGaQx4rUK\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":6,\"marketAccount\":\"8p5imag5r4JBZoxb7Wq8ysgu9LpkPix7n4i9z6TJZDt7\",\"pool\":\"KwhpybQPe9xuZFmAfcjLHj3ukownWex1ratyascAC1X\",\"targetCustody\":\"Ah1Kd146CtAexGvbVNWRMQ8aXJTJDf4AopNLQZKGfYck\",\"collateralCustody\":\"9yANuRkTRxb9jjxnG1h3xcUz2kM8fJgDbdYJV4PfZ7dy\",\"side\":\"long\",\"maxLev\":100,\"targetCustodyId\":4,\"collateralCustodyId\":0,\"targetMint\":\"GBPvXsT3uQVBmipvhhU5NW1JfhMJ2maYqLAbPzUq5NnY\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":7,\"marketAccount\":\"6pKnzQwmrSCz6HK4C4qXUscysGpQj381ksmNwmVHSdJ4\",\"pool\":\"KwhpybQPe9xuZFmAfcjLHj3ukownWex1ratyascAC1X\",\"targetCustody\":\"Ah1Kd146CtAexGvbVNWRMQ8aXJTJDf4AopNLQZKGfYck\",\"collateralCustody\":\"9yANuRkTRxb9jjxnG1h3xcUz2kM8fJgDbdYJV4PfZ7dy\",\"side\":\"short\",\"maxLev\":100,\"targetCustodyId\":4,\"collateralCustodyId\":0,\"targetMint\":\"GBPvXsT3uQVBmipvhhU5NW1JfhMJ2maYqLAbPzUq5NnY\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":8,\"marketAccount\":\"CxC8u5SBCtu9a53x7jSZtaAuJoKYA2ukXLuMuB9NtqoQ\",\"pool\":\"KwhpybQPe9xuZFmAfcjLHj3ukownWex1ratyascAC1X\",\"targetCustody\":\"AFrALLNuCbBBnhUvEjxrK96e8yjComh2xuTak1y5TEJL\",\"collateralCustody\":\"9yANuRkTRxb9jjxnG1h3xcUz2kM8fJgDbdYJV4PfZ7dy\",\"side\":\"long\",\"maxLev\":100,\"targetCustodyId\":5,\"collateralCustodyId\":0,\"targetMint\":\"AUDdbsJZpT1pFErezhe9pvcf97XnvD8oo8etZbeFbBX\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":9,\"marketAccount\":\"JCwYots22PTcPn2XQz9un15kMj6tqEYjUKgQaay5sMY1\",\"pool\":\"KwhpybQPe9xuZFmAfcjLHj3ukownWex1ratyascAC1X\",\"targetCustody\":\"AFrALLNuCbBBnhUvEjxrK96e8yjComh2xuTak1y5TEJL\",\"collateralCustody\":\"9yANuRkTRxb9jjxnG1h3xcUz2kM8fJgDbdYJV4PfZ7dy\",\"side\":\"short\",\"maxLev\":100,\"targetCustodyId\":5,\"collateralCustodyId\":0,\"targetMint\":\"AUDdbsJZpT1pFErezhe9pvcf97XnvD8oo8etZbeFbBX\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"}]},{\"programId\":\"FLASH6Lo6h3iasJKWDs2F8TkW2UKf3s15C8PMGuVfgBn\",\"perpComposibilityProgramId\":\"FSWAPViR8ny5K96hezav8jynVubP2dJ2L7SbKzds2hwm\",\"fbNftRewardProgramId\":\"FBRWDXSLysNbFQk64MQJcpkXP8e4fjezsGabV8jV7d7o\",\"cluster\":\"mainnet-beta\",\"poolName\":\"Governance.1\",\"poolAddress\":\"D6bfytnxoZBSzJM7fcixg5sgWJ2hj8SbwkPvb2r8XpbH\",\"stakedLpTokenMint\":\"6afu2XRPMg8JAhzBsJ9DXsQRCFhkzbC4UaFMZepm6AHb\",\"compoundingTokenMint\":\"4PZTRNrHnxWBqLRvX5nuE6m1cNR8RqB4kWvVYjDkMd2H\",\"stakedLpVault\":\"EhiSmAktg5AqZfKwV8igfnTqZZsaAdFfZBLGLEmGjyvw\",\"compoundingLpVault\":\"ErSLQ5u1bA8XYQES78mCbybCnFsPmgruGTKELkaeMnLx\",\"metadataAccount\":\"G86ybpQVnnQUBPPPHNT9jERuSPJ9HFEo5PDcSaMQhRMX\",\"lpDecimals\":6,\"compoundingLpTokenSymbol\":\"FLP.3\",\"stakedLpTokenSymbol\":\"sFLP.3\",\"perpetuals\":\"7DWCtB5Z8rPiyBMKUwqyC95R9tJpbhoQhLM9LbK3Z5QZ\",\"transferAuthority\":\"81xGAvJ27ZeRThU2JEfKAUeT4Fx6qCCd8WHZpujZbiiG\",\"multisig\":\"3FqKnAQrvr6G6AqCAWKdqg9fVe6ceAk3A5Y1ibeQqV2V\",\"addressLookupTableAddresses\":[\"AUebVLw8UwN35Us2XcPQaTQejJoQ5T7ckWzxHTwN1mkM\"],\"backupOracle\":\"AjAubETeBLhebBxLcErmzbavZfqF9bCxkpRAdyJtoi9G\",\"nftCollectionAddress\":\"H4EQ8pcE7PQSQGG1WYW4hAA1nizU6ULYipHZcYk9b64u\",\"rewardDistributionProgram\":{\"programId\":\"FARNT7LL119pmy9vSkN9q1ApZESPaKHuuX5Acz1oBoME\",\"transferAuthority\":\"E2GZM2FQmX2uGBcBpLQB3s5UhPJvM2F8BgHEkBG45xBN\",\"rewardVault\":\"6sXyDryKp6hqV6E1jc7gbzTeWxTFUW1A6s39vzp55hLL\",\"rewardMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"rewardTokenAccount\":\"EhH4KEra2UfKdwRErjEFf2286BQ3BstKxfLiyYnF513h\"},\"tokens\":[{\"symbol\":\"USDC\",\"mintKey\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\",\"isToken2022\":false},{\"symbol\":\"JUP\",\"mintKey\":\"JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.JUP/USD\",\"pythPriceId\":\"0x0a0408d619e9380abad35060f9192039ed5042fa6f82301d0e48bb52be830996\",\"isToken2022\":false},{\"symbol\":\"PYTH\",\"mintKey\":\"HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.PYTH/USD\",\"pythPriceId\":\"0x0bbf28e9a841a1cc788f6a361b17ca072d0ea3098a1e5df1c3922d06719579ff\",\"isToken2022\":false},{\"symbol\":\"JTO\",\"mintKey\":\"jtojtomepa8beP8AuQc6eXt5FriJwfFMwQx2v2f9mCL\",\"decimals\":9,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.JTO/USD\",\"pythPriceId\":\"0xb43660a5f790c69354b0729a5ef9d50d68f1df92107540210b9cccba1f947cc2\",\"isToken2022\":false},{\"symbol\":\"W\",\"mintKey\":\"85VBFQZC9TZkfaptBWjvUw7YbZjy52A6mjtPGjstQAmQ\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.W/USD\",\"pythPriceId\":\"0xeff7446475e218517566ea99e72a4abec2e1bd8498b43b7d8331e29dcb059389\",\"isToken2022\":false},{\"symbol\":\"RAY\",\"mintKey\":\"4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.RAY/USD\",\"pythPriceId\":\"0x91568baa8beb53db23eb3fb7f22c6e8bd303d103919e19733f2bb642d3e7987a\",\"isToken2022\":false},{\"symbol\":\"KMNO\",\"mintKey\":\"KMNo3nJsBXfcpJTVhZcXLW7RmTwTt4GVFE7suUBo9sS\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.KMNO/USD\",\"pythPriceId\":\"0xb17e5bc5de742a8a378b54c9c75442b7d51e30ada63f28d9bd28d3c0e26511a0\",\"isToken2022\":false}],\"custodies\":[{\"custodyId\":0,\"custodyAccount\":\"6fiadNoZVTha5NdaktZgJ3PHm7bncZpiqGvFbCsrUv72\",\"tokenAccount\":\"CjRKKtT3DCsDh7gvQwkX1aCLpYhhDUKaNrJhUzGtsHUC\",\"symbol\":\"USDC\",\"mintKey\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":2,\"isStable\":true,\"isVirtual\":false,\"intOracleAddress\":\"GCtJxWQ57B3BJUYdWrhb3TUxzeiDUx275ZCxKkTV6G3N\",\"extOracleAddress\":\"Dpw1EAVrSB1ibxiDQyTAW6Zip3J4Btk2x4SgApQCeFbX\",\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\"},{\"custodyId\":1,\"custodyAccount\":\"GvxrQuz7tHxqiyfJNnGKh4GAPYycZ3cvqgmwifduiBCf\",\"tokenAccount\":\"CjSYeE668mfLdY7hi1B1ocLMzAVAFFtEhjKrGo8hgvuy\",\"symbol\":\"JUP\",\"mintKey\":\"JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"72rMJMG5jyAsiVXkxde2zWgELXj1yfqc3sYgAj1ENYns\",\"extOracleAddress\":\"7dbob1psH1iZBS7qPsm3Kwbf5DzSXK8Jyg31CTgTnxH5\",\"pythTicker\":\"Crypto.JUP/USD\",\"pythPriceId\":\"0x0a0408d619e9380abad35060f9192039ed5042fa6f82301d0e48bb52be830996\"},{\"custodyId\":2,\"custodyAccount\":\"A8SKWb3pwbFUtxLQhnpUTfy7CkxBpWGvTLYyJyWHCMWv\",\"tokenAccount\":\"5rdgpCu7xFDhyksEAyUxsyuH9q1KQReKg1FwzmGA7mFq\",\"symbol\":\"PYTH\",\"mintKey\":\"HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"7HWfFZn87wBjpexboZBcV35UjTYmeaS9Kdg5jcHsbqdr\",\"extOracleAddress\":\"8vjchtMuJNY4oFQdTi8yCe6mhCaNBFaUbktT482TpLPS\",\"pythTicker\":\"Crypto.PYTH/USD\",\"pythPriceId\":\"0x0bbf28e9a841a1cc788f6a361b17ca072d0ea3098a1e5df1c3922d06719579ff\"},{\"custodyId\":3,\"custodyAccount\":\"43f5Y7ysVysbkwqnRSjggCPPj4gvuaVnmgz9MkPUk88L\",\"tokenAccount\":\"FahFdXRRn1iodaCs9MZyNjSb62TTpaQCD98Xcsdowdgf\",\"symbol\":\"JTO\",\"mintKey\":\"jtojtomepa8beP8AuQc6eXt5FriJwfFMwQx2v2f9mCL\",\"decimals\":9,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"E2jXqDkASx9njXWhnnjDGxefcEw8LoeyD3We2g3Ja5pX\",\"extOracleAddress\":\"7ajR2zA4MGMMTqRAVjghTKqPPn4kbrj3pYkAVRVwTGzP\",\"pythTicker\":\"Crypto.JTO/USD\",\"pythPriceId\":\"0xb43660a5f790c69354b0729a5ef9d50d68f1df92107540210b9cccba1f947cc2\"},{\"custodyId\":4,\"custodyAccount\":\"58NxGYaVq1CXpNJUsvUDGgBeBtMcoGHP8u58KSk2bagE\",\"tokenAccount\":\"4xooDvD4S1BJECjGnKmzNJQrtSxxXVpHRHLiZYc5xyC3\",\"symbol\":\"W\",\"mintKey\":\"85VBFQZC9TZkfaptBWjvUw7YbZjy52A6mjtPGjstQAmQ\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"F1xtMtakpmtDvtrGs7YXeJHAmQi4owUxNns5P5qsZN35\",\"extOracleAddress\":\"BEMsCSQEGi2kwPA4mKnGjxnreijhMki7L4eeb96ypzF9\",\"pythTicker\":\"Crypto.W/USD\",\"pythPriceId\":\"0xeff7446475e218517566ea99e72a4abec2e1bd8498b43b7d8331e29dcb059389\"},{\"custodyId\":5,\"custodyAccount\":\"AuzpQGWBNTYKXj4pe5WPoT95dc2T7ouMWpjcriF9t4XS\",\"tokenAccount\":\"C1SwCemkW7DzfZFEuzT1R3GbGtqQoy5PERoGDV8iiX4M\",\"symbol\":\"RAY\",\"mintKey\":\"4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"4RBgyAzw964UJa7QTjpq52h29YrBuyCrkfYAXbWzgV5v\",\"extOracleAddress\":\"Hhipna3EoWR7u8pDruUg8RxhP5F6XLh6SEHMVDmZhWi8\",\"pythTicker\":\"Crypto.RAY/USD\",\"pythPriceId\":\"0x91568baa8beb53db23eb3fb7f22c6e8bd303d103919e19733f2bb642d3e7987a\"},{\"custodyId\":6,\"custodyAccount\":\"5JtPiHFmkb1nv1Qvs3sryLgXmjs8p5iQexAseC2Ljjzg\",\"tokenAccount\":\"EofwtSbFk3fsVWYKdYp5nzkhK5At8yRM6YA2YxNE5iWV\",\"symbol\":\"KMNO\",\"mintKey\":\"KMNo3nJsBXfcpJTVhZcXLW7RmTwTt4GVFE7suUBo9sS\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"4tNprL7ziCzxHotNnuNWE8Z8znvQbg2irng4SEyjy9rs\",\"extOracleAddress\":\"ArjngUHXrQPr1wH9Bqrji9hdDQirM6ijbzc1Jj1fXUk7\",\"pythTicker\":\"Crypto.KMNO/USD\",\"pythPriceId\":\"0xb17e5bc5de742a8a378b54c9c75442b7d51e30ada63f28d9bd28d3c0e26511a0\"}],\"markets\":[{\"marketId\":0,\"marketAccount\":\"5QQstJ2LpeHESWqGTWBw5aid8h4cdVUjXU61R84Pj2jr\",\"pool\":\"D6bfytnxoZBSzJM7fcixg5sgWJ2hj8SbwkPvb2r8XpbH\",\"targetCustody\":\"GvxrQuz7tHxqiyfJNnGKh4GAPYycZ3cvqgmwifduiBCf\",\"collateralCustody\":\"GvxrQuz7tHxqiyfJNnGKh4GAPYycZ3cvqgmwifduiBCf\",\"side\":\"long\",\"maxLev\":50,\"targetCustodyId\":1,\"collateralCustodyId\":1,\"targetMint\":\"JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN\",\"collateralMint\":\"JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN\"},{\"marketId\":1,\"marketAccount\":\"Hi8kSmbtzucZpEYxvcq2H1QuyUCRuY3m7WGmTF2RhkVw\",\"pool\":\"D6bfytnxoZBSzJM7fcixg5sgWJ2hj8SbwkPvb2r8XpbH\",\"targetCustody\":\"GvxrQuz7tHxqiyfJNnGKh4GAPYycZ3cvqgmwifduiBCf\",\"collateralCustody\":\"6fiadNoZVTha5NdaktZgJ3PHm7bncZpiqGvFbCsrUv72\",\"side\":\"short\",\"maxLev\":50,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":2,\"marketAccount\":\"9V9eYLhVV13VoSfi3McfMcN7ie4WNkRdTbHggkaT8QCQ\",\"pool\":\"D6bfytnxoZBSzJM7fcixg5sgWJ2hj8SbwkPvb2r8XpbH\",\"targetCustody\":\"A8SKWb3pwbFUtxLQhnpUTfy7CkxBpWGvTLYyJyWHCMWv\",\"collateralCustody\":\"A8SKWb3pwbFUtxLQhnpUTfy7CkxBpWGvTLYyJyWHCMWv\",\"side\":\"long\",\"maxLev\":50,\"targetCustodyId\":2,\"collateralCustodyId\":2,\"targetMint\":\"HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3\",\"collateralMint\":\"HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3\"},{\"marketId\":3,\"marketAccount\":\"2By2fgwfZQetZ56414KBDMZwNBstg3GAJtEePQtf3Aty\",\"pool\":\"D6bfytnxoZBSzJM7fcixg5sgWJ2hj8SbwkPvb2r8XpbH\",\"targetCustody\":\"A8SKWb3pwbFUtxLQhnpUTfy7CkxBpWGvTLYyJyWHCMWv\",\"collateralCustody\":\"6fiadNoZVTha5NdaktZgJ3PHm7bncZpiqGvFbCsrUv72\",\"side\":\"short\",\"maxLev\":50,\"targetCustodyId\":2,\"collateralCustodyId\":0,\"targetMint\":\"HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":4,\"marketAccount\":\"7gnDo7scDFYmEnXW2JrGRzCrynmbakoCMqaEo7d2fydG\",\"pool\":\"D6bfytnxoZBSzJM7fcixg5sgWJ2hj8SbwkPvb2r8XpbH\",\"targetCustody\":\"43f5Y7ysVysbkwqnRSjggCPPj4gvuaVnmgz9MkPUk88L\",\"collateralCustody\":\"43f5Y7ysVysbkwqnRSjggCPPj4gvuaVnmgz9MkPUk88L\",\"side\":\"long\",\"maxLev\":50,\"targetCustodyId\":3,\"collateralCustodyId\":3,\"targetMint\":\"jtojtomepa8beP8AuQc6eXt5FriJwfFMwQx2v2f9mCL\",\"collateralMint\":\"jtojtomepa8beP8AuQc6eXt5FriJwfFMwQx2v2f9mCL\"},{\"marketId\":5,\"marketAccount\":\"G7RdCWx4eNfLdagGp4H2tKwhTi9JihBozVLGMVduF1Xe\",\"pool\":\"D6bfytnxoZBSzJM7fcixg5sgWJ2hj8SbwkPvb2r8XpbH\",\"targetCustody\":\"43f5Y7ysVysbkwqnRSjggCPPj4gvuaVnmgz9MkPUk88L\",\"collateralCustody\":\"6fiadNoZVTha5NdaktZgJ3PHm7bncZpiqGvFbCsrUv72\",\"side\":\"short\",\"maxLev\":50,\"targetCustodyId\":3,\"collateralCustodyId\":0,\"targetMint\":\"jtojtomepa8beP8AuQc6eXt5FriJwfFMwQx2v2f9mCL\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":6,\"marketAccount\":\"Dk2P1xDyewb9nxsMacw6gfuhTb3DqPZM1Sm97K66CTQK\",\"pool\":\"D6bfytnxoZBSzJM7fcixg5sgWJ2hj8SbwkPvb2r8XpbH\",\"targetCustody\":\"58NxGYaVq1CXpNJUsvUDGgBeBtMcoGHP8u58KSk2bagE\",\"collateralCustody\":\"58NxGYaVq1CXpNJUsvUDGgBeBtMcoGHP8u58KSk2bagE\",\"side\":\"long\",\"maxLev\":50,\"targetCustodyId\":4,\"collateralCustodyId\":4,\"targetMint\":\"85VBFQZC9TZkfaptBWjvUw7YbZjy52A6mjtPGjstQAmQ\",\"collateralMint\":\"85VBFQZC9TZkfaptBWjvUw7YbZjy52A6mjtPGjstQAmQ\"},{\"marketId\":7,\"marketAccount\":\"9mMAN4hFvw5AGB6eNay1WvNsGoyK9xcBafZ5tVbHcHQq\",\"pool\":\"D6bfytnxoZBSzJM7fcixg5sgWJ2hj8SbwkPvb2r8XpbH\",\"targetCustody\":\"58NxGYaVq1CXpNJUsvUDGgBeBtMcoGHP8u58KSk2bagE\",\"collateralCustody\":\"6fiadNoZVTha5NdaktZgJ3PHm7bncZpiqGvFbCsrUv72\",\"side\":\"short\",\"maxLev\":50,\"targetCustodyId\":4,\"collateralCustodyId\":0,\"targetMint\":\"85VBFQZC9TZkfaptBWjvUw7YbZjy52A6mjtPGjstQAmQ\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":8,\"marketAccount\":\"aZCThBPnK1j8feCAKnVtS3QjULzNwPDy4a8V3FzbM9V\",\"pool\":\"D6bfytnxoZBSzJM7fcixg5sgWJ2hj8SbwkPvb2r8XpbH\",\"targetCustody\":\"AuzpQGWBNTYKXj4pe5WPoT95dc2T7ouMWpjcriF9t4XS\",\"collateralCustody\":\"AuzpQGWBNTYKXj4pe5WPoT95dc2T7ouMWpjcriF9t4XS\",\"side\":\"long\",\"maxLev\":50,\"targetCustodyId\":5,\"collateralCustodyId\":5,\"targetMint\":\"4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R\",\"collateralMint\":\"4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R\"},{\"marketId\":9,\"marketAccount\":\"6u6QrwkmAF4kzk41FkjpLv8AbYaTtkRtbmVZsPSf7wSd\",\"pool\":\"D6bfytnxoZBSzJM7fcixg5sgWJ2hj8SbwkPvb2r8XpbH\",\"targetCustody\":\"AuzpQGWBNTYKXj4pe5WPoT95dc2T7ouMWpjcriF9t4XS\",\"collateralCustody\":\"6fiadNoZVTha5NdaktZgJ3PHm7bncZpiqGvFbCsrUv72\",\"side\":\"short\",\"maxLev\":50,\"targetCustodyId\":5,\"collateralCustodyId\":0,\"targetMint\":\"4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":10,\"marketAccount\":\"FaT568uYioPFsf2rFgSSFrNyrqHZfG9LZBReaq56dSYJ\",\"pool\":\"D6bfytnxoZBSzJM7fcixg5sgWJ2hj8SbwkPvb2r8XpbH\",\"targetCustody\":\"5JtPiHFmkb1nv1Qvs3sryLgXmjs8p5iQexAseC2Ljjzg\",\"collateralCustody\":\"5JtPiHFmkb1nv1Qvs3sryLgXmjs8p5iQexAseC2Ljjzg\",\"side\":\"long\",\"maxLev\":50,\"targetCustodyId\":6,\"collateralCustodyId\":6,\"targetMint\":\"KMNo3nJsBXfcpJTVhZcXLW7RmTwTt4GVFE7suUBo9sS\",\"collateralMint\":\"KMNo3nJsBXfcpJTVhZcXLW7RmTwTt4GVFE7suUBo9sS\"},{\"marketId\":11,\"marketAccount\":\"Hfkgp91DXQivzd8XihGHh7ansPm1SFfosNZ5CN3yz1PW\",\"pool\":\"D6bfytnxoZBSzJM7fcixg5sgWJ2hj8SbwkPvb2r8XpbH\",\"targetCustody\":\"5JtPiHFmkb1nv1Qvs3sryLgXmjs8p5iQexAseC2Ljjzg\",\"collateralCustody\":\"6fiadNoZVTha5NdaktZgJ3PHm7bncZpiqGvFbCsrUv72\",\"side\":\"short\",\"maxLev\":50,\"targetCustodyId\":6,\"collateralCustodyId\":0,\"targetMint\":\"KMNo3nJsBXfcpJTVhZcXLW7RmTwTt4GVFE7suUBo9sS\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"}]},{\"programId\":\"FLASH6Lo6h3iasJKWDs2F8TkW2UKf3s15C8PMGuVfgBn\",\"perpComposibilityProgramId\":\"FSWAPViR8ny5K96hezav8jynVubP2dJ2L7SbKzds2hwm\",\"fbNftRewardProgramId\":\"FBRWDXSLysNbFQk64MQJcpkXP8e4fjezsGabV8jV7d7o\",\"cluster\":\"mainnet-beta\",\"poolName\":\"Community.1\",\"poolAddress\":\"6HukhSeVVLQekKaGJYkwztBacjhKLKywVPrmcvccaYMz\",\"stakedLpTokenMint\":\"GnxdTsSQNQ3FF72nTyWo4SUt59Tt1MqDkRRfoPtKjMvJ\",\"compoundingTokenMint\":\"EngqvevoQ8yaNdtxY7sSh5J7NF74k3cDKi9v9pHi5H3B\",\"stakedLpVault\":\"BX61fNmuhXtPPRaRTo2bAQFyhnmBqAXWG41PUqQx62yr\",\"compoundingLpVault\":\"7b2cF1GvcrRWXHbkgHLjwc2qLe4Vqncc4v6N6weMirfw\",\"metadataAccount\":\"8HPm3sNXqFxNkEDYBMwX1BnXxxfn4XY6Jt5b8ikv6m7b\",\"lpDecimals\":6,\"compoundingLpTokenSymbol\":\"FLP.4\",\"stakedLpTokenSymbol\":\"sFLP.4\",\"perpetuals\":\"7DWCtB5Z8rPiyBMKUwqyC95R9tJpbhoQhLM9LbK3Z5QZ\",\"transferAuthority\":\"81xGAvJ27ZeRThU2JEfKAUeT4Fx6qCCd8WHZpujZbiiG\",\"multisig\":\"3FqKnAQrvr6G6AqCAWKdqg9fVe6ceAk3A5Y1ibeQqV2V\",\"addressLookupTableAddresses\":[\"AUebVLw8UwN35Us2XcPQaTQejJoQ5T7ckWzxHTwN1mkM\"],\"backupOracle\":\"AjAubETeBLhebBxLcErmzbavZfqF9bCxkpRAdyJtoi9G\",\"nftCollectionAddress\":\"H4EQ8pcE7PQSQGG1WYW4hAA1nizU6ULYipHZcYk9b64u\",\"rewardDistributionProgram\":{\"programId\":\"FARNT7LL119pmy9vSkN9q1ApZESPaKHuuX5Acz1oBoME\",\"transferAuthority\":\"E2GZM2FQmX2uGBcBpLQB3s5UhPJvM2F8BgHEkBG45xBN\",\"rewardVault\":\"6sXyDryKp6hqV6E1jc7gbzTeWxTFUW1A6s39vzp55hLL\",\"rewardMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"rewardTokenAccount\":\"EhH4KEra2UfKdwRErjEFf2286BQ3BstKxfLiyYnF513h\"},\"tokens\":[{\"symbol\":\"USDC\",\"mintKey\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\",\"isToken2022\":false},{\"symbol\":\"BONK\",\"mintKey\":\"DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263\",\"decimals\":5,\"usdPrecision\":8,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.BONK/USD\",\"pythPriceId\":\"0x72b021217ca3fe68922a19aaf990109cb9d84e9ad004b4d2025ad6f529314419\",\"isToken2022\":false},{\"symbol\":\"PENGU\",\"mintKey\":\"2zMMhcVQEXDtdE6vsFS7S7D5oUodfJHE8vd1gnBouauv\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.PENGU/USD\",\"pythPriceId\":\"0xbed3097008b9b5e3c93bec20be79cb43986b85a996475589351a21e67bae9b61\",\"isToken2022\":false}],\"custodies\":[{\"custodyId\":0,\"custodyAccount\":\"qFFbK8PHbNt4433AUTHHDsmDuQGTQhixc8t4sCzugG4\",\"tokenAccount\":\"FNC4jkJLqxFdL7xhujj5TGhnSAbS1ZJSrNqs6MhPGpn1\",\"symbol\":\"USDC\",\"mintKey\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":2,\"isStable\":true,\"isVirtual\":false,\"intOracleAddress\":\"GCtJxWQ57B3BJUYdWrhb3TUxzeiDUx275ZCxKkTV6G3N\",\"extOracleAddress\":\"Dpw1EAVrSB1ibxiDQyTAW6Zip3J4Btk2x4SgApQCeFbX\",\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\"},{\"custodyId\":1,\"custodyAccount\":\"7gfDTeMREaKcg3SMfrgVP7fjrstmrzzAeYCAcVaHTV9h\",\"tokenAccount\":\"9FY4Fcb5rE5xvNhewkFCU8beh1CJPn4G5tfh6okhS71T\",\"symbol\":\"BONK\",\"mintKey\":\"DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263\",\"decimals\":5,\"usdPrecision\":8,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"J7ruj3xnMc3etbcPxRoTTaHBpDCwF8LeA73k3TidKXCK\",\"extOracleAddress\":\"DBE3N8uNjhKPRHfANdwGvCZghWXyLPdqdSbEW2XFwBiX\",\"pythTicker\":\"Crypto.BONK/USD\",\"pythPriceId\":\"0x72b021217ca3fe68922a19aaf990109cb9d84e9ad004b4d2025ad6f529314419\"},{\"custodyId\":2,\"custodyAccount\":\"Gw81Uk5LarYkoCtwY95b1uT8tqTyzYQf3WM3yvgi9N43\",\"tokenAccount\":\"Hg8ydKCrr2dMovMp8gGHU26mP49f7S6QBudZ6GapChWS\",\"symbol\":\"PENGU\",\"mintKey\":\"2zMMhcVQEXDtdE6vsFS7S7D5oUodfJHE8vd1gnBouauv\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"HkbXAhndY1nErJ176ncjSYait341g23mBLcsRpFSM4QP\",\"extOracleAddress\":\"27zzC5wXCeZeuJ3h9uAJzV5tGn6r5Tzo98S1ZceYKEb8\",\"pythTicker\":\"Crypto.PENGU/USD\",\"pythPriceId\":\"0xbed3097008b9b5e3c93bec20be79cb43986b85a996475589351a21e67bae9b61\"}],\"markets\":[{\"marketId\":0,\"marketAccount\":\"DvvnSEZueicT9UN9WMvfYP3B4NQDgiNjjtbKLenLakxv\",\"pool\":\"6HukhSeVVLQekKaGJYkwztBacjhKLKywVPrmcvccaYMz\",\"targetCustody\":\"7gfDTeMREaKcg3SMfrgVP7fjrstmrzzAeYCAcVaHTV9h\",\"collateralCustody\":\"7gfDTeMREaKcg3SMfrgVP7fjrstmrzzAeYCAcVaHTV9h\",\"side\":\"long\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":1,\"targetMint\":\"DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263\",\"collateralMint\":\"DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263\"},{\"marketId\":1,\"marketAccount\":\"3EYDn8VkY19QBStG4QtvLAdPScReLS7kuchhterF7ADP\",\"pool\":\"6HukhSeVVLQekKaGJYkwztBacjhKLKywVPrmcvccaYMz\",\"targetCustody\":\"7gfDTeMREaKcg3SMfrgVP7fjrstmrzzAeYCAcVaHTV9h\",\"collateralCustody\":\"qFFbK8PHbNt4433AUTHHDsmDuQGTQhixc8t4sCzugG4\",\"side\":\"short\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"},{\"marketId\":2,\"marketAccount\":\"FPYjBQg9PL1qjCEqSK6RDs4T9Lhip1uJytkpB7zzG35N\",\"pool\":\"6HukhSeVVLQekKaGJYkwztBacjhKLKywVPrmcvccaYMz\",\"targetCustody\":\"Gw81Uk5LarYkoCtwY95b1uT8tqTyzYQf3WM3yvgi9N43\",\"collateralCustody\":\"Gw81Uk5LarYkoCtwY95b1uT8tqTyzYQf3WM3yvgi9N43\",\"side\":\"long\",\"maxLev\":10,\"targetCustodyId\":2,\"collateralCustodyId\":2,\"targetMint\":\"2zMMhcVQEXDtdE6vsFS7S7D5oUodfJHE8vd1gnBouauv\",\"collateralMint\":\"2zMMhcVQEXDtdE6vsFS7S7D5oUodfJHE8vd1gnBouauv\"},{\"marketId\":3,\"marketAccount\":\"A39w24T4wWqx9ZRk8dPKQjQL9xgwBhPGc1dBmFfBh4mY\",\"pool\":\"6HukhSeVVLQekKaGJYkwztBacjhKLKywVPrmcvccaYMz\",\"targetCustody\":\"Gw81Uk5LarYkoCtwY95b1uT8tqTyzYQf3WM3yvgi9N43\",\"collateralCustody\":\"qFFbK8PHbNt4433AUTHHDsmDuQGTQhixc8t4sCzugG4\",\"side\":\"short\",\"maxLev\":10,\"targetCustodyId\":2,\"collateralCustodyId\":0,\"targetMint\":\"2zMMhcVQEXDtdE6vsFS7S7D5oUodfJHE8vd1gnBouauv\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"}]},{\"programId\":\"FLASH6Lo6h3iasJKWDs2F8TkW2UKf3s15C8PMGuVfgBn\",\"perpComposibilityProgramId\":\"FSWAPViR8ny5K96hezav8jynVubP2dJ2L7SbKzds2hwm\",\"fbNftRewardProgramId\":\"FBRWDXSLysNbFQk64MQJcpkXP8e4fjezsGabV8jV7d7o\",\"cluster\":\"mainnet-beta\",\"poolName\":\"Community.2\",\"poolAddress\":\"DP1FnZjWzDjSMQA64BcMzUdpDpyAQ6723d5fpX4yTk5G\",\"stakedLpTokenMint\":\"EsdayVbDQYQdy54TQh5iASMTkCzmhxsx6MpCvyrtYaUZ\",\"compoundingTokenMint\":\"Ab6K8anKSwAz8VXJPVvAVjPQMJNoVhwzfF7FtAB5PNW9\",\"stakedLpVault\":\"DCW9WsRzhsXQ78MLenwFaRc5BUGBUADXNaNnuzRWoAHd\",\"compoundingLpVault\":\"5A8RtiyHc44b2s75ayrLbH6DN6j8TwufkVwqvUEqtbY9\",\"metadataAccount\":\"BR4ZZ8wkomYSbiap9jDfTPCBT348eciPWBnLHUXKu5rL\",\"lpDecimals\":6,\"compoundingLpTokenSymbol\":\"FLP.5\",\"stakedLpTokenSymbol\":\"sFLP.5\",\"perpetuals\":\"7DWCtB5Z8rPiyBMKUwqyC95R9tJpbhoQhLM9LbK3Z5QZ\",\"transferAuthority\":\"81xGAvJ27ZeRThU2JEfKAUeT4Fx6qCCd8WHZpujZbiiG\",\"multisig\":\"3FqKnAQrvr6G6AqCAWKdqg9fVe6ceAk3A5Y1ibeQqV2V\",\"addressLookupTableAddresses\":[\"AUebVLw8UwN35Us2XcPQaTQejJoQ5T7ckWzxHTwN1mkM\"],\"backupOracle\":\"AjAubETeBLhebBxLcErmzbavZfqF9bCxkpRAdyJtoi9G\",\"nftCollectionAddress\":\"H4EQ8pcE7PQSQGG1WYW4hAA1nizU6ULYipHZcYk9b64u\",\"rewardDistributionProgram\":{\"programId\":\"FARNT7LL119pmy9vSkN9q1ApZESPaKHuuX5Acz1oBoME\",\"transferAuthority\":\"E2GZM2FQmX2uGBcBpLQB3s5UhPJvM2F8BgHEkBG45xBN\",\"rewardVault\":\"6sXyDryKp6hqV6E1jc7gbzTeWxTFUW1A6s39vzp55hLL\",\"rewardMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"rewardTokenAccount\":\"EhH4KEra2UfKdwRErjEFf2286BQ3BstKxfLiyYnF513h\"},\"tokens\":[{\"symbol\":\"USDC\",\"mintKey\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\",\"isToken2022\":false},{\"symbol\":\"WIF\",\"mintKey\":\"EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.WIF/USD\",\"pythPriceId\":\"0x4ca4beeca86f0d164160323817a4e42b10010a724c2217c6ee41b54cd4cc61fc\",\"isToken2022\":false}],\"custodies\":[{\"custodyId\":0,\"custodyAccount\":\"EtLnmKsmbTPH1mUhZSNU5ErEoFrSgYoxoKX8BSzEZmnn\",\"tokenAccount\":\"AnMZk127cCBTx24dzbZKjDTXajzMyYwLTFQiBacwPBts\",\"symbol\":\"USDC\",\"mintKey\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":2,\"isStable\":true,\"isVirtual\":false,\"intOracleAddress\":\"GCtJxWQ57B3BJUYdWrhb3TUxzeiDUx275ZCxKkTV6G3N\",\"extOracleAddress\":\"Dpw1EAVrSB1ibxiDQyTAW6Zip3J4Btk2x4SgApQCeFbX\",\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\"},{\"custodyId\":1,\"custodyAccount\":\"AMAea38ijDJuoq14mwxzQkGEyZEnjw69eqrMQ9uHPdyP\",\"tokenAccount\":\"CtqrRhvwVu9vFhcHpokoc25GMSB8HNxEmHvbVscvasBM\",\"symbol\":\"WIF\",\"mintKey\":\"EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"4jibMQPD7xKhsU8tsrMcbKLrd7ADdRJDLr61CG4NGvQm\",\"extOracleAddress\":\"6B23K3tkb51vLZA14jcEQVCA1pfHptzEHFA93V5dYwbT\",\"pythTicker\":\"Crypto.WIF/USD\",\"pythPriceId\":\"0x4ca4beeca86f0d164160323817a4e42b10010a724c2217c6ee41b54cd4cc61fc\"}],\"markets\":[{\"marketId\":0,\"marketAccount\":\"DRMbqfx6No2MzRLtyo4RUaKExe4daiVAXKsX3F3RAK3u\",\"pool\":\"DP1FnZjWzDjSMQA64BcMzUdpDpyAQ6723d5fpX4yTk5G\",\"targetCustody\":\"AMAea38ijDJuoq14mwxzQkGEyZEnjw69eqrMQ9uHPdyP\",\"collateralCustody\":\"AMAea38ijDJuoq14mwxzQkGEyZEnjw69eqrMQ9uHPdyP\",\"side\":\"long\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":1,\"targetMint\":\"EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm\",\"collateralMint\":\"EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm\"},{\"marketId\":1,\"marketAccount\":\"9X4S2ZeFdpoTe5LkEUZ6hPqkTo6k4LyYpBZJiwBVRj6\",\"pool\":\"DP1FnZjWzDjSMQA64BcMzUdpDpyAQ6723d5fpX4yTk5G\",\"targetCustody\":\"AMAea38ijDJuoq14mwxzQkGEyZEnjw69eqrMQ9uHPdyP\",\"collateralCustody\":\"EtLnmKsmbTPH1mUhZSNU5ErEoFrSgYoxoKX8BSzEZmnn\",\"side\":\"short\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"}]},{\"programId\":\"FLASH6Lo6h3iasJKWDs2F8TkW2UKf3s15C8PMGuVfgBn\",\"perpComposibilityProgramId\":\"FSWAPViR8ny5K96hezav8jynVubP2dJ2L7SbKzds2hwm\",\"fbNftRewardProgramId\":\"FBRWDXSLysNbFQk64MQJcpkXP8e4fjezsGabV8jV7d7o\",\"cluster\":\"mainnet-beta\",\"poolName\":\"Community.3\",\"poolAddress\":\"F8qWvHm5F288VodQ7zGLhnrbbRR3zDbae6aNE53HQ98f\",\"stakedLpTokenMint\":\"Cwneu1mq39LExywGhY79nzxeAAGnQhPVijZr98P9hs3Q\",\"compoundingTokenMint\":\"C9HErFA8ABcAjfMRp4eySQx8dDB6u92CdqjsnSgYyHGa\",\"stakedLpVault\":\"J6g9q4VwzX8F2VA22cB572WghsJgnFRYoJhEVSqSWx58\",\"compoundingLpVault\":\"58Vw9F231HwHZ6Cqgey3r3BZDbrxcaTGt5YbZsgYkwTp\",\"metadataAccount\":\"9DLY54Dj7qEvFzRZgupyozwxJNGAGP8wFrg7p48zZs3c\",\"lpDecimals\":6,\"compoundingLpTokenSymbol\":\"FLP.6\",\"stakedLpTokenSymbol\":\"sFLP.6\",\"perpetuals\":\"7DWCtB5Z8rPiyBMKUwqyC95R9tJpbhoQhLM9LbK3Z5QZ\",\"transferAuthority\":\"81xGAvJ27ZeRThU2JEfKAUeT4Fx6qCCd8WHZpujZbiiG\",\"multisig\":\"3FqKnAQrvr6G6AqCAWKdqg9fVe6ceAk3A5Y1ibeQqV2V\",\"addressLookupTableAddresses\":[\"AUebVLw8UwN35Us2XcPQaTQejJoQ5T7ckWzxHTwN1mkM\"],\"backupOracle\":\"AjAubETeBLhebBxLcErmzbavZfqF9bCxkpRAdyJtoi9G\",\"nftCollectionAddress\":\"H4EQ8pcE7PQSQGG1WYW4hAA1nizU6ULYipHZcYk9b64u\",\"rewardDistributionProgram\":{\"programId\":\"FARNT7LL119pmy9vSkN9q1ApZESPaKHuuX5Acz1oBoME\",\"transferAuthority\":\"E2GZM2FQmX2uGBcBpLQB3s5UhPJvM2F8BgHEkBG45xBN\",\"rewardVault\":\"6sXyDryKp6hqV6E1jc7gbzTeWxTFUW1A6s39vzp55hLL\",\"rewardMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"rewardTokenAccount\":\"EhH4KEra2UfKdwRErjEFf2286BQ3BstKxfLiyYnF513h\"},\"tokens\":[{\"symbol\":\"USDC\",\"mintKey\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\",\"isToken2022\":false},{\"symbol\":\"SAMO\",\"mintKey\":\"7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU\",\"decimals\":9,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.SAMO/USD\",\"pythPriceId\":\"0x49601625e1a342c1f90c3fe6a03ae0251991a1d76e480d2741524c29037be28a\",\"isToken2022\":false}],\"custodies\":[{\"custodyId\":0,\"custodyAccount\":\"888zpafZJEtPYp15HJocz45rw7kTr8BnEM9Hvcd7opy3\",\"tokenAccount\":\"BAB98S63TMUmeJLL6ZSAv9o9wX2mCMiUzFb1vhPS4dbF\",\"symbol\":\"USDC\",\"mintKey\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":2,\"isStable\":true,\"isVirtual\":false,\"intOracleAddress\":\"GCtJxWQ57B3BJUYdWrhb3TUxzeiDUx275ZCxKkTV6G3N\",\"extOracleAddress\":\"Dpw1EAVrSB1ibxiDQyTAW6Zip3J4Btk2x4SgApQCeFbX\",\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\"},{\"custodyId\":1,\"custodyAccount\":\"ArnD1faZVVkkewX4HUSoDuht46egAtVvhDTFMJn3DkFo\",\"tokenAccount\":\"DvXbMKMk7JESxckPR8knPffm779TwERtAFo3HhJTohtQ\",\"symbol\":\"SAMO\",\"mintKey\":\"7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU\",\"decimals\":9,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"7SMPa7rEnjgeDjp8S6i9yH522SXK2vQwNModGxcA5U8Y\",\"extOracleAddress\":\"2eUVzcYccqXzsDU1iBuatUaDCbRKBjegEaPPeChzfocG\",\"pythTicker\":\"Crypto.SAMO/USD\",\"pythPriceId\":\"0x49601625e1a342c1f90c3fe6a03ae0251991a1d76e480d2741524c29037be28a\"}],\"markets\":[{\"marketId\":0,\"marketAccount\":\"FULXckUCpsHnUsaXZNys4bFCbY5s2199SEg6eyeQuxTH\",\"pool\":\"F8qWvHm5F288VodQ7zGLhnrbbRR3zDbae6aNE53HQ98f\",\"targetCustody\":\"ArnD1faZVVkkewX4HUSoDuht46egAtVvhDTFMJn3DkFo\",\"collateralCustody\":\"ArnD1faZVVkkewX4HUSoDuht46egAtVvhDTFMJn3DkFo\",\"side\":\"long\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":1,\"targetMint\":\"7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU\",\"collateralMint\":\"7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU\"},{\"marketId\":1,\"marketAccount\":\"GchNQzigTFP4bUuH3LwdoDSvn1fexHw84Gtjap8x8Ppm\",\"pool\":\"F8qWvHm5F288VodQ7zGLhnrbbRR3zDbae6aNE53HQ98f\",\"targetCustody\":\"ArnD1faZVVkkewX4HUSoDuht46egAtVvhDTFMJn3DkFo\",\"collateralCustody\":\"888zpafZJEtPYp15HJocz45rw7kTr8BnEM9Hvcd7opy3\",\"side\":\"short\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU\",\"collateralMint\":\"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v\"}]},{\"programId\":\"FTN6rgbaaxwT8mpRuC55EFTwpHB3BwnHJ91Lqv4ZVCfW\",\"perpComposibilityProgramId\":\"SWAP4AE4N1if9qKD7dgfQgmRBRv1CtWG8xDs4HP14ST\",\"fbNftRewardProgramId\":\"FB8mxzFuW99ExD1B14hFqoeWWS1UdbuK6iY2PVPpKFQi\",\"cluster\":\"devnet\",\"poolName\":\"devnet.1\",\"poolAddress\":\"7jA4ZSGwaBxXk5EmPKDCSc5RtZNHxyoxy22iQt3D2mH9\",\"stakedLpTokenMint\":\"H4h7nsZaz53KZHMdSXc5byBjcbymEFYX6an8UVbh51yU\",\"compoundingTokenMint\":\"AJPPBo7PqA1uLoVLVRX4UPdzVsb4S2Qvw8V1XiyCTiLA\",\"stakedLpVault\":\"5saGiRTc9iszokguCfPs7vtgmhsCpqYLfbRgemvsxM4T\",\"compoundingLpVault\":\"22q1V7YKmJ9Hz4oh5BxYjLWSPN18eoPqwChEUToFbixy\",\"metadataAccount\":\"7NvA4CEqr9Tei1MDDKrbYFKV5D39fkPPEfRv5Z5ZXZEb\",\"lpDecimals\":6,\"compoundingLpTokenSymbol\":\"FLP.1\",\"stakedLpTokenSymbol\":\"sFLP.1\",\"perpetuals\":\"445GcRLAJ64DcxSRbvQTkbwXgWUyubAxzQUQ2wL73KLS\",\"transferAuthority\":\"EPyHAAHUYnFATwd8CJ7owLnozFeS8pFsr3RNJD1eueYq\",\"multisig\":\"Eu3cBFRo18AeN9BFb5ndzk2PEmBT7yWEhh3VkG21pyGo\",\"addressLookupTableAddresses\":[\"8YQHv2K84A7a7UA6tKKwrD4DsnKHAa24qLYMEH17Atwc\"],\"backupOracle\":\"AHaKsRB4tsGSzFfFqAxUpfRRmsUj5EhwHSxSXK2UGRp5\",\"nftCollectionAddress\":\"3rkRzHdN7dXy5CQfX3Lz6UBBJ2F9n58VEpvDSmbaVHt9\",\"rewardDistributionProgram\":{\"programId\":\"FARTfzmezUtejeF42vfyvX96NWq1BuAcXFiAQuz6wZZg\",\"transferAuthority\":\"4cgNvcrPFxmgJVyQNJqM8Sb6eJnDktr5mWA3gSkdNcyT\",\"rewardVault\":\"DrXUtn8BRUYAo1i3ZTkPRXqU7w2KGbCjiskzH8wGExGK\",\"rewardMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"rewardTokenAccount\":\"6X9LbFxtvjGxBEgHiE3KLQjJtAqkThqrhCufLhrPfMEp\"},\"tokens\":[{\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\",\"isToken2022\":false},{\"symbol\":\"SOL\",\"mintKey\":\"So11111111111111111111111111111111111111112\",\"decimals\":9,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.SOL/USD\",\"pythPriceId\":\"0xef0d8b6fda2ceba41da15d4095d1da392a0d2f8ed0c6c7bc0f4cfac8c280b56d\",\"isToken2022\":false},{\"symbol\":\"WSOL\",\"mintKey\":\"So11111111111111111111111111111111111111112\",\"decimals\":9,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.SOL/USD\",\"pythPriceId\":\"0xef0d8b6fda2ceba41da15d4095d1da392a0d2f8ed0c6c7bc0f4cfac8c280b56d\",\"isToken2022\":false},{\"symbol\":\"BTC\",\"mintKey\":\"B8DYqbh57aEPRbUq7reyueY6jaYoN75js5YsiM84tFfP\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.BTC/USD\",\"pythPriceId\":\"0xe62df6c8b4a85fe1a67db44dc12de5db330f7ac66b72dc658afedf0f4a415b43\",\"isToken2022\":false},{\"symbol\":\"ETH\",\"mintKey\":\"BA17bkYW78GvnirtgRHcceQxZdwkhpzbvrwDU6voUXRz\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.ETH/USD\",\"pythPriceId\":\"0xff61491a931112ddf1bd8147cd1b641375f79f5825126d665480874634fd0ace\",\"isToken2022\":false}],\"custodies\":[{\"custodyId\":0,\"custodyAccount\":\"AqZSmo7tVgPrZ72kSpRugN8pTCBTHovw65qPikP15dmK\",\"tokenAccount\":\"8q8f5sp7kwGktJzboffVcKhXanGcJJ9HbqFH1LU8B1Ux\",\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"intOracleAddress\":\"CuzxxETyjZkGVJmUv4zJTjoo4YE5HHdNm4AT4krtTikY\",\"extOracleAddress\":\"Dpw1EAVrSB1ibxiDQyTAW6Zip3J4Btk2x4SgApQCeFbX\",\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\"},{\"custodyId\":1,\"custodyAccount\":\"8BHHyTJKvZXQkjCeigdkH7hAFcnfX5ecXwysjLnG18FT\",\"tokenAccount\":\"8Qa3fV58Lu8WsiPRnkn4xx3PyA2wxE62ESHLXxhesWST\",\"symbol\":\"SOL\",\"mintKey\":\"So11111111111111111111111111111111111111112\",\"decimals\":9,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"4JwcQt7a1Qis1RxixRJ2g6QgiF1aJay32hgWrMa7ptgD\",\"extOracleAddress\":\"7UVimffxr9ow1uXYxsr4LHAcV58mLzhmwaeKvJ1pjLiE\",\"pythTicker\":\"Crypto.SOL/USD\",\"pythPriceId\":\"0xef0d8b6fda2ceba41da15d4095d1da392a0d2f8ed0c6c7bc0f4cfac8c280b56d\"},{\"custodyId\":2,\"custodyAccount\":\"F8peHuGzRwLAgRXm9CGQNKqpWkxTkJQVZw6uLJPx12TV\",\"tokenAccount\":\"CEgxrynA9ifMkbiGC8za4LgrvbvzZYSoh1iYQ1n7qMAJ\",\"symbol\":\"BTC\",\"mintKey\":\"B8DYqbh57aEPRbUq7reyueY6jaYoN75js5YsiM84tFfP\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":6,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"9YK4f2wPWRzJcC9iN8Bqhd7RWPewVh4kom7UVZhaJwbN\",\"extOracleAddress\":\"4cSM2e6rvbGQUFiJbqytoVMi5GgghSMr8LwVrT9VPSPo\",\"pythTicker\":\"Crypto.BTC/USD\",\"pythPriceId\":\"0xe62df6c8b4a85fe1a67db44dc12de5db330f7ac66b72dc658afedf0f4a415b43\"},{\"custodyId\":3,\"custodyAccount\":\"4Xtj4GEPwHjeXeDRmcAyAoZyPH4bsEQ4qFyhcK8bBGgy\",\"tokenAccount\":\"7rUd15esvCwMCQZfrr3s2WnPYkQtB75AvLNBoEZs5XHJ\",\"symbol\":\"ETH\",\"mintKey\":\"BA17bkYW78GvnirtgRHcceQxZdwkhpzbvrwDU6voUXRz\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"CMVuTVTME7PfxvtfFSURkktfaHEW6Yzbio2FLa29TngK\",\"extOracleAddress\":\"42amVS4KgzR9rA28tkVYqVXjq9Qa8dcZQMbH5EYFX6XC\",\"pythTicker\":\"Crypto.ETH/USD\",\"pythPriceId\":\"0xff61491a931112ddf1bd8147cd1b641375f79f5825126d665480874634fd0ace\"}],\"markets\":[{\"marketId\":0,\"marketAccount\":\"7HkcVQpXAR9RB4aQhuV9TAXaSLWGbu5JMs6M3EWB3Gj2\",\"pool\":\"7jA4ZSGwaBxXk5EmPKDCSc5RtZNHxyoxy22iQt3D2mH9\",\"targetCustody\":\"8BHHyTJKvZXQkjCeigdkH7hAFcnfX5ecXwysjLnG18FT\",\"collateralCustody\":\"8BHHyTJKvZXQkjCeigdkH7hAFcnfX5ecXwysjLnG18FT\",\"side\":\"long\",\"maxLev\":100,\"targetCustodyId\":1,\"collateralCustodyId\":1,\"targetMint\":\"So11111111111111111111111111111111111111112\",\"collateralMint\":\"So11111111111111111111111111111111111111112\"},{\"marketId\":1,\"marketAccount\":\"Fj1hwfeccqjSAKGkX6jEbJZ2auW2zWsoYPjzugwKBTpJ\",\"pool\":\"7jA4ZSGwaBxXk5EmPKDCSc5RtZNHxyoxy22iQt3D2mH9\",\"targetCustody\":\"8BHHyTJKvZXQkjCeigdkH7hAFcnfX5ecXwysjLnG18FT\",\"collateralCustody\":\"AqZSmo7tVgPrZ72kSpRugN8pTCBTHovw65qPikP15dmK\",\"side\":\"short\",\"maxLev\":100,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"So11111111111111111111111111111111111111112\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":2,\"marketAccount\":\"GZ9HHuNoz17Tj6xBks1ZRAN4k4h47E88iEeBoeZUTNbX\",\"pool\":\"7jA4ZSGwaBxXk5EmPKDCSc5RtZNHxyoxy22iQt3D2mH9\",\"targetCustody\":\"F8peHuGzRwLAgRXm9CGQNKqpWkxTkJQVZw6uLJPx12TV\",\"collateralCustody\":\"F8peHuGzRwLAgRXm9CGQNKqpWkxTkJQVZw6uLJPx12TV\",\"side\":\"long\",\"maxLev\":100,\"targetCustodyId\":2,\"collateralCustodyId\":2,\"targetMint\":\"B8DYqbh57aEPRbUq7reyueY6jaYoN75js5YsiM84tFfP\",\"collateralMint\":\"B8DYqbh57aEPRbUq7reyueY6jaYoN75js5YsiM84tFfP\"},{\"marketId\":3,\"marketAccount\":\"FXVWNVv1y7vS7boZmTWq9TujhdZLfGmrWFDEqnTpg9zU\",\"pool\":\"7jA4ZSGwaBxXk5EmPKDCSc5RtZNHxyoxy22iQt3D2mH9\",\"targetCustody\":\"F8peHuGzRwLAgRXm9CGQNKqpWkxTkJQVZw6uLJPx12TV\",\"collateralCustody\":\"AqZSmo7tVgPrZ72kSpRugN8pTCBTHovw65qPikP15dmK\",\"side\":\"short\",\"maxLev\":100,\"targetCustodyId\":2,\"collateralCustodyId\":0,\"targetMint\":\"B8DYqbh57aEPRbUq7reyueY6jaYoN75js5YsiM84tFfP\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":4,\"marketAccount\":\"4xZb6fic3bDcXG38tXzjQ5n7qRpPoQt7P2rRfEPfYYmz\",\"pool\":\"7jA4ZSGwaBxXk5EmPKDCSc5RtZNHxyoxy22iQt3D2mH9\",\"targetCustody\":\"4Xtj4GEPwHjeXeDRmcAyAoZyPH4bsEQ4qFyhcK8bBGgy\",\"collateralCustody\":\"4Xtj4GEPwHjeXeDRmcAyAoZyPH4bsEQ4qFyhcK8bBGgy\",\"side\":\"long\",\"maxLev\":100,\"targetCustodyId\":3,\"collateralCustodyId\":3,\"targetMint\":\"BA17bkYW78GvnirtgRHcceQxZdwkhpzbvrwDU6voUXRz\",\"collateralMint\":\"BA17bkYW78GvnirtgRHcceQxZdwkhpzbvrwDU6voUXRz\"},{\"marketId\":5,\"marketAccount\":\"96GfXnGddBdZbFfbLAcpj4BLAvKj8VAoAti97vhvsizG\",\"pool\":\"7jA4ZSGwaBxXk5EmPKDCSc5RtZNHxyoxy22iQt3D2mH9\",\"targetCustody\":\"4Xtj4GEPwHjeXeDRmcAyAoZyPH4bsEQ4qFyhcK8bBGgy\",\"collateralCustody\":\"AqZSmo7tVgPrZ72kSpRugN8pTCBTHovw65qPikP15dmK\",\"side\":\"short\",\"maxLev\":100,\"targetCustodyId\":3,\"collateralCustodyId\":0,\"targetMint\":\"BA17bkYW78GvnirtgRHcceQxZdwkhpzbvrwDU6voUXRz\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"}]},{\"programId\":\"FTN6rgbaaxwT8mpRuC55EFTwpHB3BwnHJ91Lqv4ZVCfW\",\"perpComposibilityProgramId\":\"SWAP4AE4N1if9qKD7dgfQgmRBRv1CtWG8xDs4HP14ST\",\"fbNftRewardProgramId\":\"FB8mxzFuW99ExD1B14hFqoeWWS1UdbuK6iY2PVPpKFQi\",\"cluster\":\"devnet\",\"poolName\":\"devnet.2\",\"poolAddress\":\"5MCtcNsF3dxna8ArzMamyciWDV3TBkiAzY1NqLtNiXvw\",\"stakedLpTokenMint\":\"CEBnqSukYQjcRiKiZKmkbJSDYojtc4GdSipKJ5bSYvHd\",\"compoundingTokenMint\":\"C6UBsabfTL8dCygt53jf4gf6KdwPBRKXihquJyy6RJUe\",\"stakedLpVault\":\"CEBnqSukYQjcRiKiZKmkbJSDYojtc4GdSipKJ5bSYvHd\",\"compoundingLpVault\":\"QaqqTcSztmAJuATYTeJSp4c8f4AjS2Bk2cvkWAETVD2\",\"metadataAccount\":\"CeUy9d6CGyj4mL3JVhYKK2A462yjpb4FGyWUyA7zDoWi\",\"lpDecimals\":6,\"compoundingLpTokenSymbol\":\"FLP.2\",\"stakedLpTokenSymbol\":\"sFLP.2\",\"perpetuals\":\"445GcRLAJ64DcxSRbvQTkbwXgWUyubAxzQUQ2wL73KLS\",\"transferAuthority\":\"EPyHAAHUYnFATwd8CJ7owLnozFeS8pFsr3RNJD1eueYq\",\"multisig\":\"Eu3cBFRo18AeN9BFb5ndzk2PEmBT7yWEhh3VkG21pyGo\",\"addressLookupTableAddresses\":[\"8YQHv2K84A7a7UA6tKKwrD4DsnKHAa24qLYMEH17Atwc\"],\"backupOracle\":\"AHaKsRB4tsGSzFfFqAxUpfRRmsUj5EhwHSxSXK2UGRp5\",\"nftCollectionAddress\":\"3rkRzHdN7dXy5CQfX3Lz6UBBJ2F9n58VEpvDSmbaVHt9\",\"rewardDistributionProgram\":{\"programId\":\"FARTfzmezUtejeF42vfyvX96NWq1BuAcXFiAQuz6wZZg\",\"transferAuthority\":\"4cgNvcrPFxmgJVyQNJqM8Sb6eJnDktr5mWA3gSkdNcyT\",\"rewardVault\":\"DrXUtn8BRUYAo1i3ZTkPRXqU7w2KGbCjiskzH8wGExGK\",\"rewardMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"rewardTokenAccount\":\"6X9LbFxtvjGxBEgHiE3KLQjJtAqkThqrhCufLhrPfMEp\"},\"tokens\":[{\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\",\"isToken2022\":false},{\"symbol\":\"XAU\",\"mintKey\":\"xaucSYSxjZF4EbsLqAGRvPcuD1uXAj9awmsxYkUAavx\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":true,\"pythTicker\":\"Metal.XAU/USD\",\"pythPriceId\":\"0x765d2ba906dbc32ca17cc11f5310a89e9ee1f6420508c63861f2f8ba4ee34bb2\",\"isToken2022\":false},{\"symbol\":\"XAG\",\"mintKey\":\"xagGMhSCG8WDsf3zFep6sGtvyY1D78roKCHTJtEWg4Z\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":true,\"pythTicker\":\"Metal.XAG/USD\",\"pythPriceId\":\"0xf2fb02c32b055c805e7238d628e5e9dadef274376114eb1f012337cabe93871e\",\"isToken2022\":false},{\"symbol\":\"EUR\",\"mintKey\":\"eurExbEMAz5jq8r31EGc3gg9ddu7ftBJWg8A6hYsvng\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":true,\"pythTicker\":\"FX.EUR/USD\",\"pythPriceId\":\"0xa995d00bb36a63cef7fd2c287dc105fc8f3d93779f062f09551b0af3e81ec30b\",\"isToken2022\":false},{\"symbol\":\"GBP\",\"mintKey\":\"gbpLV6AqxQGSMFsuSfcutvWnfjLUqKq63GoXLAHXXKV\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":true,\"pythTicker\":\"FX.GBP/USD\",\"pythPriceId\":\"0x84c2dde9633d93d1bcad84e7dc41c9d56578b7ec52fabedc1f335d673df0a7c1\",\"isToken2022\":false},{\"symbol\":\"AUD\",\"mintKey\":\"auduqqUHqZC3DRmZaAtzccTs3NTi1fSYp5rgg4uYwFz\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":true,\"pythTicker\":\"FX.AUD/USD\",\"pythPriceId\":\"0x67a6f93030420c1c9e3fe37c1ab6b77966af82f995944a9fefce357a22854a80\",\"isToken2022\":false}],\"custodies\":[{\"custodyId\":0,\"custodyAccount\":\"8DrHPGQq4dBrSYV2oy8oDi3sQDSgeCaAe1jq3s9tSh42\",\"tokenAccount\":\"33GEjYtTbKXtBJSpR92DMqBUWUhgMXRUmRe5BaV5ximh\",\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"intOracleAddress\":\"CuzxxETyjZkGVJmUv4zJTjoo4YE5HHdNm4AT4krtTikY\",\"extOracleAddress\":\"Dpw1EAVrSB1ibxiDQyTAW6Zip3J4Btk2x4SgApQCeFbX\",\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\"},{\"custodyId\":1,\"custodyAccount\":\"3de6DnZhfv7TmuaAsfzBtkmueWxLQuJ772ATYB7GCguW\",\"tokenAccount\":\"CQ33dxTZwEaqYMEzD2yJLW4U4z81YLiwZkoEhbeZ31zS\",\"symbol\":\"XAU\",\"mintKey\":\"xaucSYSxjZF4EbsLqAGRvPcuD1uXAj9awmsxYkUAavx\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":true,\"intOracleAddress\":\"GKQnYPbwmkhdkUn2maAokiD49zcBfncZ3x4sfTWm85tN\",\"extOracleAddress\":\"2uPQGpm8X4ZkxMHxrAW1QuhXcse1AHEgPih6Xp9NuEWW\",\"pythTicker\":\"Metal.XAU/USD\",\"pythPriceId\":\"0x765d2ba906dbc32ca17cc11f5310a89e9ee1f6420508c63861f2f8ba4ee34bb2\"},{\"custodyId\":2,\"custodyAccount\":\"4x2hq8Jtji4H5SRDrZenBtpsCuJh8Rt8hV1sBACxGuRn\",\"tokenAccount\":\"6Mj9PmAdFjbSAduKE9i4Pvx6LiPzbS8VexBvKry9VHco\",\"symbol\":\"XAG\",\"mintKey\":\"xagGMhSCG8WDsf3zFep6sGtvyY1D78roKCHTJtEWg4Z\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":true,\"intOracleAddress\":\"6QLKbCJ7CvvySAecJF8Ao6DzeLRC23XJeegaioY5B2qJ\",\"extOracleAddress\":\"H9JxsWwtDZxjSL6m7cdCVsWibj3JBMD9sxqLjadoZnot\",\"pythTicker\":\"Metal.XAG/USD\",\"pythPriceId\":\"0xf2fb02c32b055c805e7238d628e5e9dadef274376114eb1f012337cabe93871e\"},{\"custodyId\":3,\"custodyAccount\":\"EoCbHAPYhUPZY977AKU7j4XU5rgYnbjQMnB9nqZYCrrG\",\"tokenAccount\":\"sYnuU1vKqGaU5V9A7F83yiGAKNVhpPHSHooAn4qqSWr\",\"symbol\":\"EUR\",\"mintKey\":\"eurExbEMAz5jq8r31EGc3gg9ddu7ftBJWg8A6hYsvng\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":true,\"intOracleAddress\":\"6VeDqEd85fd4ePyBhhHvvKJnnsaj2zBiUApyMy8JGY7h\",\"extOracleAddress\":\"Fu76ChamBDjE8UuGLV6GP2AcPPSU6gjhkNhAyuoPm7ny\",\"pythTicker\":\"FX.EUR/USD\",\"pythPriceId\":\"0xa995d00bb36a63cef7fd2c287dc105fc8f3d93779f062f09551b0af3e81ec30b\"},{\"custodyId\":4,\"custodyAccount\":\"HP4DsgavjjEDVgbStiNuYdCHwE2kNS5LSaEUXcgAaNS7\",\"tokenAccount\":\"67VncQVTiodQXitq6Bq7JpUfQLY6x4VVL2YLr475ouif\",\"symbol\":\"GBP\",\"mintKey\":\"gbpLV6AqxQGSMFsuSfcutvWnfjLUqKq63GoXLAHXXKV\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":true,\"intOracleAddress\":\"4dpwvLtUxQHbV8hx8LKLkdGgJ5m7kYRhkjhurijPj9Ww\",\"extOracleAddress\":\"G25Tm7UkVruTJ7mcbCxFm45XGWwsH72nJKNGcHEQw1tU\",\"pythTicker\":\"FX.GBP/USD\",\"pythPriceId\":\"0x84c2dde9633d93d1bcad84e7dc41c9d56578b7ec52fabedc1f335d673df0a7c1\"},{\"custodyId\":5,\"custodyAccount\":\"GcMKm7441Vx3rtUuE4qQzV7tWmv8mHWShZ9CerasWuwc\",\"tokenAccount\":\"B4z3UgMM4KnCyWbrju8HWhLX7b7xd1TSrdheLMDtTj2N\",\"symbol\":\"AUD\",\"mintKey\":\"auduqqUHqZC3DRmZaAtzccTs3NTi1fSYp5rgg4uYwFz\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":true,\"intOracleAddress\":\"BttDaqMMzPPvUvakrRsddcjJxiTs2qTmrCcWvk5nvtc9\",\"extOracleAddress\":\"6pPXqXcgFFoLEcXfedWJy3ypNZVJ1F3mgipaDFsvZ1co\",\"pythTicker\":\"FX.AUD/USD\",\"pythPriceId\":\"0x67a6f93030420c1c9e3fe37c1ab6b77966af82f995944a9fefce357a22854a80\"}],\"markets\":[{\"marketId\":0,\"marketAccount\":\"B71om3HUqZ64e9wRj1R8LbWUFvw6cde4yuU4yXvo4GYv\",\"pool\":\"5MCtcNsF3dxna8ArzMamyciWDV3TBkiAzY1NqLtNiXvw\",\"targetCustody\":\"3de6DnZhfv7TmuaAsfzBtkmueWxLQuJ772ATYB7GCguW\",\"collateralCustody\":\"8DrHPGQq4dBrSYV2oy8oDi3sQDSgeCaAe1jq3s9tSh42\",\"side\":\"long\",\"maxLev\":200,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"xaucSYSxjZF4EbsLqAGRvPcuD1uXAj9awmsxYkUAavx\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":1,\"marketAccount\":\"9wV2Y87ix64cFP6B3VNxuXiabTPYgAm65MuqgivXVUn7\",\"pool\":\"5MCtcNsF3dxna8ArzMamyciWDV3TBkiAzY1NqLtNiXvw\",\"targetCustody\":\"3de6DnZhfv7TmuaAsfzBtkmueWxLQuJ772ATYB7GCguW\",\"collateralCustody\":\"8DrHPGQq4dBrSYV2oy8oDi3sQDSgeCaAe1jq3s9tSh42\",\"side\":\"short\",\"maxLev\":200,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"xaucSYSxjZF4EbsLqAGRvPcuD1uXAj9awmsxYkUAavx\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":2,\"marketAccount\":\"33tCg8Mao8ga7tC6XaFdAVCswXx1rmSWQ15k3bafv2Nc\",\"pool\":\"5MCtcNsF3dxna8ArzMamyciWDV3TBkiAzY1NqLtNiXvw\",\"targetCustody\":\"4x2hq8Jtji4H5SRDrZenBtpsCuJh8Rt8hV1sBACxGuRn\",\"collateralCustody\":\"8DrHPGQq4dBrSYV2oy8oDi3sQDSgeCaAe1jq3s9tSh42\",\"side\":\"long\",\"maxLev\":200,\"targetCustodyId\":2,\"collateralCustodyId\":0,\"targetMint\":\"xagGMhSCG8WDsf3zFep6sGtvyY1D78roKCHTJtEWg4Z\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":3,\"marketAccount\":\"5jZUiUV8BXdE1xDkVShLTKmPHhM4mk7vo9mASa3yZJZD\",\"pool\":\"5MCtcNsF3dxna8ArzMamyciWDV3TBkiAzY1NqLtNiXvw\",\"targetCustody\":\"4x2hq8Jtji4H5SRDrZenBtpsCuJh8Rt8hV1sBACxGuRn\",\"collateralCustody\":\"8DrHPGQq4dBrSYV2oy8oDi3sQDSgeCaAe1jq3s9tSh42\",\"side\":\"short\",\"maxLev\":200,\"targetCustodyId\":2,\"collateralCustodyId\":0,\"targetMint\":\"xagGMhSCG8WDsf3zFep6sGtvyY1D78roKCHTJtEWg4Z\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":4,\"marketAccount\":\"4ryTFNWPE1J1X3akTrXjygS47b9agM9uGGByc1TvxbdN\",\"pool\":\"5MCtcNsF3dxna8ArzMamyciWDV3TBkiAzY1NqLtNiXvw\",\"targetCustody\":\"EoCbHAPYhUPZY977AKU7j4XU5rgYnbjQMnB9nqZYCrrG\",\"collateralCustody\":\"8DrHPGQq4dBrSYV2oy8oDi3sQDSgeCaAe1jq3s9tSh42\",\"side\":\"long\",\"maxLev\":200,\"targetCustodyId\":3,\"collateralCustodyId\":0,\"targetMint\":\"eurExbEMAz5jq8r31EGc3gg9ddu7ftBJWg8A6hYsvng\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":5,\"marketAccount\":\"Cz3FVEBdQ2Ns2uorfM6ZjWbvqMNRSnSHaTFprAcKUzEJ\",\"pool\":\"5MCtcNsF3dxna8ArzMamyciWDV3TBkiAzY1NqLtNiXvw\",\"targetCustody\":\"EoCbHAPYhUPZY977AKU7j4XU5rgYnbjQMnB9nqZYCrrG\",\"collateralCustody\":\"8DrHPGQq4dBrSYV2oy8oDi3sQDSgeCaAe1jq3s9tSh42\",\"side\":\"short\",\"maxLev\":200,\"targetCustodyId\":3,\"collateralCustodyId\":0,\"targetMint\":\"eurExbEMAz5jq8r31EGc3gg9ddu7ftBJWg8A6hYsvng\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":6,\"marketAccount\":\"9DsZe98fHrdqpswQEy1Hj7rnNdFJ8CnHdU1bxLAHgMge\",\"pool\":\"5MCtcNsF3dxna8ArzMamyciWDV3TBkiAzY1NqLtNiXvw\",\"targetCustody\":\"HP4DsgavjjEDVgbStiNuYdCHwE2kNS5LSaEUXcgAaNS7\",\"collateralCustody\":\"8DrHPGQq4dBrSYV2oy8oDi3sQDSgeCaAe1jq3s9tSh42\",\"side\":\"long\",\"maxLev\":200,\"targetCustodyId\":4,\"collateralCustodyId\":0,\"targetMint\":\"gbpLV6AqxQGSMFsuSfcutvWnfjLUqKq63GoXLAHXXKV\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":7,\"marketAccount\":\"5bZp6dEDMq3Bb7r4YidXtvffZdxfsU3qZ9ueSZt4vu6S\",\"pool\":\"5MCtcNsF3dxna8ArzMamyciWDV3TBkiAzY1NqLtNiXvw\",\"targetCustody\":\"HP4DsgavjjEDVgbStiNuYdCHwE2kNS5LSaEUXcgAaNS7\",\"collateralCustody\":\"8DrHPGQq4dBrSYV2oy8oDi3sQDSgeCaAe1jq3s9tSh42\",\"side\":\"short\",\"maxLev\":200,\"targetCustodyId\":4,\"collateralCustodyId\":0,\"targetMint\":\"gbpLV6AqxQGSMFsuSfcutvWnfjLUqKq63GoXLAHXXKV\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":8,\"marketAccount\":\"6yCsUoaTU4JVNikkEXfCV7KKDh7FcMY23hcvKk9dqhqf\",\"pool\":\"5MCtcNsF3dxna8ArzMamyciWDV3TBkiAzY1NqLtNiXvw\",\"targetCustody\":\"GcMKm7441Vx3rtUuE4qQzV7tWmv8mHWShZ9CerasWuwc\",\"collateralCustody\":\"8DrHPGQq4dBrSYV2oy8oDi3sQDSgeCaAe1jq3s9tSh42\",\"side\":\"long\",\"maxLev\":200,\"targetCustodyId\":5,\"collateralCustodyId\":0,\"targetMint\":\"auduqqUHqZC3DRmZaAtzccTs3NTi1fSYp5rgg4uYwFz\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":9,\"marketAccount\":\"BnA1TVMsE4jsrdCwo38n6EwpRCkKzVxwVhXE7izmBd8F\",\"pool\":\"5MCtcNsF3dxna8ArzMamyciWDV3TBkiAzY1NqLtNiXvw\",\"targetCustody\":\"GcMKm7441Vx3rtUuE4qQzV7tWmv8mHWShZ9CerasWuwc\",\"collateralCustody\":\"8DrHPGQq4dBrSYV2oy8oDi3sQDSgeCaAe1jq3s9tSh42\",\"side\":\"short\",\"maxLev\":200,\"targetCustodyId\":5,\"collateralCustodyId\":0,\"targetMint\":\"auduqqUHqZC3DRmZaAtzccTs3NTi1fSYp5rgg4uYwFz\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"}]},{\"programId\":\"FTN6rgbaaxwT8mpRuC55EFTwpHB3BwnHJ91Lqv4ZVCfW\",\"perpComposibilityProgramId\":\"SWAP4AE4N1if9qKD7dgfQgmRBRv1CtWG8xDs4HP14ST\",\"fbNftRewardProgramId\":\"FB8mxzFuW99ExD1B14hFqoeWWS1UdbuK6iY2PVPpKFQi\",\"cluster\":\"devnet\",\"poolName\":\"devnet.3\",\"poolAddress\":\"FpRXePeSYyPZrBKrCSvLNSQGYT6gkgZXGDCBWVVRkNRT\",\"stakedLpTokenMint\":\"BAh7XbUKRFYtt5a9FjJqeyUqqrx3SZqayiPosYiZFneJ\",\"compoundingTokenMint\":\"CU1z35oJ56ZFq1jgsaKPzbWT72BPKQ2UBDP35Lm1uo9C\",\"stakedLpVault\":\"5HYrb2rKjF2b2ye5EiZAYeBYNeNEUzCct3N2rBmVjzLu\",\"compoundingLpVault\":\"JAjvysq2TmczcVBQL3XcB5hmbxcPLeFdaHebsb5YLPpX\",\"metadataAccount\":\"Hm6oanS5hrcu3QMC4jumKq2U5aUaJrfasE1sQ2Lct3zF\",\"lpDecimals\":6,\"compoundingLpTokenSymbol\":\"FLP.3\",\"stakedLpTokenSymbol\":\"sFLP.3\",\"perpetuals\":\"445GcRLAJ64DcxSRbvQTkbwXgWUyubAxzQUQ2wL73KLS\",\"transferAuthority\":\"EPyHAAHUYnFATwd8CJ7owLnozFeS8pFsr3RNJD1eueYq\",\"multisig\":\"Eu3cBFRo18AeN9BFb5ndzk2PEmBT7yWEhh3VkG21pyGo\",\"addressLookupTableAddresses\":[\"8YQHv2K84A7a7UA6tKKwrD4DsnKHAa24qLYMEH17Atwc\"],\"backupOracle\":\"AHaKsRB4tsGSzFfFqAxUpfRRmsUj5EhwHSxSXK2UGRp5\",\"nftCollectionAddress\":\"3rkRzHdN7dXy5CQfX3Lz6UBBJ2F9n58VEpvDSmbaVHt9\",\"rewardDistributionProgram\":{\"programId\":\"FARTfzmezUtejeF42vfyvX96NWq1BuAcXFiAQuz6wZZg\",\"transferAuthority\":\"4cgNvcrPFxmgJVyQNJqM8Sb6eJnDktr5mWA3gSkdNcyT\",\"rewardVault\":\"DrXUtn8BRUYAo1i3ZTkPRXqU7w2KGbCjiskzH8wGExGK\",\"rewardMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"rewardTokenAccount\":\"6X9LbFxtvjGxBEgHiE3KLQjJtAqkThqrhCufLhrPfMEp\"},\"tokens\":[{\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\",\"isToken2022\":false},{\"symbol\":\"JUP\",\"mintKey\":\"jupFZJoi1GKLMyt2J2Ui13BNTNh47XQtYPpNucbMAF4\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.JUP/USD\",\"pythPriceId\":\"0x0a0408d619e9380abad35060f9192039ed5042fa6f82301d0e48bb52be830996\",\"isToken2022\":false},{\"symbol\":\"PYTH\",\"mintKey\":\"pythwankpPj8tfCtBEW6BBE6oVC6ZFWF8tjyLPRSr45\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.PYTH/USD\",\"pythPriceId\":\"0x0bbf28e9a841a1cc788f6a361b17ca072d0ea3098a1e5df1c3922d06719579ff\",\"isToken2022\":false},{\"symbol\":\"JTO\",\"mintKey\":\"jtoLsU5JqXTYzPzRwGK7UmsNgy1EN6BwNRr6KMJKcXi\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.JTO/USD\",\"pythPriceId\":\"0xb43660a5f790c69354b0729a5ef9d50d68f1df92107540210b9cccba1f947cc2\",\"isToken2022\":false},{\"symbol\":\"W\",\"mintKey\":\"wda4XRBjGzP2kbCuapvfseNnH49WNkTqLw5szmjjxDG\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.W/USD\",\"pythPriceId\":\"0xeff7446475e218517566ea99e72a4abec2e1bd8498b43b7d8331e29dcb059389\",\"isToken2022\":false},{\"symbol\":\"RAY\",\"mintKey\":\"ray4PVwCwoM4ADM3qKar3Wy6v7eA2zcMtHWv7LAPGe8\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.RAY/USD\",\"pythPriceId\":\"0x91568baa8beb53db23eb3fb7f22c6e8bd303d103919e19733f2bb642d3e7987a\",\"isToken2022\":false},{\"symbol\":\"KMNO\",\"mintKey\":\"kmnooU2T6dYeVvPcwFjtNwDdgfNtAY6qs8tnxacZQxb\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.KMNO/USD\",\"pythPriceId\":\"0xb17e5bc5de742a8a378b54c9c75442b7d51e30ada63f28d9bd28d3c0e26511a0\",\"isToken2022\":false}],\"custodies\":[{\"custodyId\":0,\"custodyAccount\":\"4BwjABgU78jqjKeyCemyCCLwEtFdZ8JSeP9ogPMQS8Zg\",\"tokenAccount\":\"D9VVWWx8RxGhZH8ZSuFVEaCSjASLHV2jdVErxPREsbAm\",\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"intOracleAddress\":\"CuzxxETyjZkGVJmUv4zJTjoo4YE5HHdNm4AT4krtTikY\",\"extOracleAddress\":\"Dpw1EAVrSB1ibxiDQyTAW6Zip3J4Btk2x4SgApQCeFbX\",\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\"},{\"custodyId\":1,\"custodyAccount\":\"D5FjET7npedKke6fxyqonk7Fr3iDpHEsWMTtdnArFewp\",\"tokenAccount\":\"Azh5RKzpuaEE9LWx6DrDxgZTwmLnywspCoxnjY13j6Xe\",\"symbol\":\"JUP\",\"mintKey\":\"jupFZJoi1GKLMyt2J2Ui13BNTNh47XQtYPpNucbMAF4\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"UoMv2PWy6uzLj9KLJNSRQ3s9bSp7CXWVFbBnjPcRnZk\",\"extOracleAddress\":\"7dbob1psH1iZBS7qPsm3Kwbf5DzSXK8Jyg31CTgTnxH5\",\"pythTicker\":\"Crypto.JUP/USD\",\"pythPriceId\":\"0x0a0408d619e9380abad35060f9192039ed5042fa6f82301d0e48bb52be830996\"},{\"custodyId\":2,\"custodyAccount\":\"BsWPLoGv392eTqtgCyqV9VLuTs2KhkhfzgMtFVF587oA\",\"tokenAccount\":\"UqfSTS68EiQF38kFDAd8JcbTMLhgZobVkf65N3rf1PS\",\"symbol\":\"PYTH\",\"mintKey\":\"pythwankpPj8tfCtBEW6BBE6oVC6ZFWF8tjyLPRSr45\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"FGx7LQvhNqbZCfxyChfLEy6svZWFmAwzY6vGs8cZH2Pf\",\"extOracleAddress\":\"8vjchtMuJNY4oFQdTi8yCe6mhCaNBFaUbktT482TpLPS\",\"pythTicker\":\"Crypto.PYTH/USD\",\"pythPriceId\":\"0x0bbf28e9a841a1cc788f6a361b17ca072d0ea3098a1e5df1c3922d06719579ff\"},{\"custodyId\":3,\"custodyAccount\":\"Du9y3QF4DRuBqNaTSobJ8a84HXnzgA8hf5Qgbgh4nviu\",\"tokenAccount\":\"8HcGUBwes1izREEK2LCjXLfxB5E6WcZxgzF4E5rbnvVb\",\"symbol\":\"JTO\",\"mintKey\":\"jtoLsU5JqXTYzPzRwGK7UmsNgy1EN6BwNRr6KMJKcXi\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"J5b2iRft9n3RLyk6K7yNTN8h1qUc9iG6vjXMUqdtcUcj\",\"extOracleAddress\":\"7ajR2zA4MGMMTqRAVjghTKqPPn4kbrj3pYkAVRVwTGzP\",\"pythTicker\":\"Crypto.JTO/USD\",\"pythPriceId\":\"0xb43660a5f790c69354b0729a5ef9d50d68f1df92107540210b9cccba1f947cc2\"},{\"custodyId\":4,\"custodyAccount\":\"7DLv5QVuRizNG4P5ak8jZRdn9PeSETSeGogzPMh6p3WU\",\"tokenAccount\":\"71EcBjgsDBQJHGrD3kUKRHbKVr6jWZgpee7aRrcsxH9K\",\"symbol\":\"W\",\"mintKey\":\"wda4XRBjGzP2kbCuapvfseNnH49WNkTqLw5szmjjxDG\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"H4JgM7j6H19YrvzGmrx67LDQRemm4G1ocgjASBfB7WBR\",\"extOracleAddress\":\"BEMsCSQEGi2kwPA4mKnGjxnreijhMki7L4eeb96ypzF9\",\"pythTicker\":\"Crypto.W/USD\",\"pythPriceId\":\"0xeff7446475e218517566ea99e72a4abec2e1bd8498b43b7d8331e29dcb059389\"},{\"custodyId\":5,\"custodyAccount\":\"4t4CxpF8cjtgdiVKNgpsM5i7K3C1zUpvUcbG4hCToNfD\",\"tokenAccount\":\"7nrpffKQc34xvzZu1e1TEzoHE9jnP1d2DDnERP77SGsk\",\"symbol\":\"RAY\",\"mintKey\":\"ray4PVwCwoM4ADM3qKar3Wy6v7eA2zcMtHWv7LAPGe8\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"96rdpwQ8J8ESbnzCZL3egYLa4kGPtfJTbTqg1KijouLF\",\"extOracleAddress\":\"Hhipna3EoWR7u8pDruUg8RxhP5F6XLh6SEHMVDmZhWi8\",\"pythTicker\":\"Crypto.RAY/USD\",\"pythPriceId\":\"0x91568baa8beb53db23eb3fb7f22c6e8bd303d103919e19733f2bb642d3e7987a\"},{\"custodyId\":6,\"custodyAccount\":\"DHaP6PyLpgugW3NumW8GpMddbwNKpnckhet9ec92qE5p\",\"tokenAccount\":\"83zjqztJKnNH7MwjYswGa6tsnDH5SMqCv6ANjJWEkLGc\",\"symbol\":\"KMNO\",\"mintKey\":\"kmnooU2T6dYeVvPcwFjtNwDdgfNtAY6qs8tnxacZQxb\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"DveCuL8dUoNgVsnTiWfq6eh74dmp5sY7kFBEfZJiVtkg\",\"extOracleAddress\":\"ArjngUHXrQPr1wH9Bqrji9hdDQirM6ijbzc1Jj1fXUk7\",\"pythTicker\":\"Crypto.KMNO/USD\",\"pythPriceId\":\"0xb17e5bc5de742a8a378b54c9c75442b7d51e30ada63f28d9bd28d3c0e26511a0\"}],\"markets\":[{\"marketId\":0,\"marketAccount\":\"Fkg1HVxR6jMoQUgUegLUcjUifRSx3Dvr33PGGfVp3W77\",\"pool\":\"FpRXePeSYyPZrBKrCSvLNSQGYT6gkgZXGDCBWVVRkNRT\",\"targetCustody\":\"D5FjET7npedKke6fxyqonk7Fr3iDpHEsWMTtdnArFewp\",\"collateralCustody\":\"D5FjET7npedKke6fxyqonk7Fr3iDpHEsWMTtdnArFewp\",\"side\":\"long\",\"maxLev\":50,\"targetCustodyId\":1,\"collateralCustodyId\":1,\"targetMint\":\"jupFZJoi1GKLMyt2J2Ui13BNTNh47XQtYPpNucbMAF4\",\"collateralMint\":\"jupFZJoi1GKLMyt2J2Ui13BNTNh47XQtYPpNucbMAF4\"},{\"marketId\":1,\"marketAccount\":\"5mXpc1W2Sm93tT9GSbjpcm8o1VTSMWbCbc3Qgc9fBX2P\",\"pool\":\"FpRXePeSYyPZrBKrCSvLNSQGYT6gkgZXGDCBWVVRkNRT\",\"targetCustody\":\"D5FjET7npedKke6fxyqonk7Fr3iDpHEsWMTtdnArFewp\",\"collateralCustody\":\"4BwjABgU78jqjKeyCemyCCLwEtFdZ8JSeP9ogPMQS8Zg\",\"side\":\"short\",\"maxLev\":50,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"jupFZJoi1GKLMyt2J2Ui13BNTNh47XQtYPpNucbMAF4\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":2,\"marketAccount\":\"AYUfYB4FNVsvhC1tHxACirxYV3UPfMrKpq6MKabCuw9Y\",\"pool\":\"FpRXePeSYyPZrBKrCSvLNSQGYT6gkgZXGDCBWVVRkNRT\",\"targetCustody\":\"BsWPLoGv392eTqtgCyqV9VLuTs2KhkhfzgMtFVF587oA\",\"collateralCustody\":\"BsWPLoGv392eTqtgCyqV9VLuTs2KhkhfzgMtFVF587oA\",\"side\":\"long\",\"maxLev\":50,\"targetCustodyId\":2,\"collateralCustodyId\":2,\"targetMint\":\"pythwankpPj8tfCtBEW6BBE6oVC6ZFWF8tjyLPRSr45\",\"collateralMint\":\"pythwankpPj8tfCtBEW6BBE6oVC6ZFWF8tjyLPRSr45\"},{\"marketId\":3,\"marketAccount\":\"38zQypDNfUhthfZDgEvp33yWWiBqGSdHyZ4wwnDGTap3\",\"pool\":\"FpRXePeSYyPZrBKrCSvLNSQGYT6gkgZXGDCBWVVRkNRT\",\"targetCustody\":\"BsWPLoGv392eTqtgCyqV9VLuTs2KhkhfzgMtFVF587oA\",\"collateralCustody\":\"4BwjABgU78jqjKeyCemyCCLwEtFdZ8JSeP9ogPMQS8Zg\",\"side\":\"short\",\"maxLev\":50,\"targetCustodyId\":2,\"collateralCustodyId\":0,\"targetMint\":\"pythwankpPj8tfCtBEW6BBE6oVC6ZFWF8tjyLPRSr45\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":4,\"marketAccount\":\"3Hi1EDVqdYBzcbiSAdeiJksgK7QrryY2cXZwCwJPq3E3\",\"pool\":\"FpRXePeSYyPZrBKrCSvLNSQGYT6gkgZXGDCBWVVRkNRT\",\"targetCustody\":\"Du9y3QF4DRuBqNaTSobJ8a84HXnzgA8hf5Qgbgh4nviu\",\"collateralCustody\":\"Du9y3QF4DRuBqNaTSobJ8a84HXnzgA8hf5Qgbgh4nviu\",\"side\":\"long\",\"maxLev\":50,\"targetCustodyId\":3,\"collateralCustodyId\":3,\"targetMint\":\"jtoLsU5JqXTYzPzRwGK7UmsNgy1EN6BwNRr6KMJKcXi\",\"collateralMint\":\"jtoLsU5JqXTYzPzRwGK7UmsNgy1EN6BwNRr6KMJKcXi\"},{\"marketId\":5,\"marketAccount\":\"ELng4KqEbAbxHDPeREwTnB2oaQBPxoNTqXFBQ1ZUGUio\",\"pool\":\"FpRXePeSYyPZrBKrCSvLNSQGYT6gkgZXGDCBWVVRkNRT\",\"targetCustody\":\"Du9y3QF4DRuBqNaTSobJ8a84HXnzgA8hf5Qgbgh4nviu\",\"collateralCustody\":\"4BwjABgU78jqjKeyCemyCCLwEtFdZ8JSeP9ogPMQS8Zg\",\"side\":\"short\",\"maxLev\":50,\"targetCustodyId\":3,\"collateralCustodyId\":0,\"targetMint\":\"jtoLsU5JqXTYzPzRwGK7UmsNgy1EN6BwNRr6KMJKcXi\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":6,\"marketAccount\":\"9zvixTyYoxSeiEW1Acb3aScdi6HUPbSGQqTLa1PinAZb\",\"pool\":\"FpRXePeSYyPZrBKrCSvLNSQGYT6gkgZXGDCBWVVRkNRT\",\"targetCustody\":\"7DLv5QVuRizNG4P5ak8jZRdn9PeSETSeGogzPMh6p3WU\",\"collateralCustody\":\"7DLv5QVuRizNG4P5ak8jZRdn9PeSETSeGogzPMh6p3WU\",\"side\":\"long\",\"maxLev\":50,\"targetCustodyId\":4,\"collateralCustodyId\":4,\"targetMint\":\"wda4XRBjGzP2kbCuapvfseNnH49WNkTqLw5szmjjxDG\",\"collateralMint\":\"wda4XRBjGzP2kbCuapvfseNnH49WNkTqLw5szmjjxDG\"},{\"marketId\":7,\"marketAccount\":\"7AcT3XJsLT97MeXUpai71zEuFGdg5QetbTDTQheWMqFT\",\"pool\":\"FpRXePeSYyPZrBKrCSvLNSQGYT6gkgZXGDCBWVVRkNRT\",\"targetCustody\":\"7DLv5QVuRizNG4P5ak8jZRdn9PeSETSeGogzPMh6p3WU\",\"collateralCustody\":\"4BwjABgU78jqjKeyCemyCCLwEtFdZ8JSeP9ogPMQS8Zg\",\"side\":\"short\",\"maxLev\":50,\"targetCustodyId\":4,\"collateralCustodyId\":0,\"targetMint\":\"wda4XRBjGzP2kbCuapvfseNnH49WNkTqLw5szmjjxDG\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":8,\"marketAccount\":\"CmKDkRzjB4sGiVqui7JPKL5wARFjcryPNFTbwDgPNxzB\",\"pool\":\"FpRXePeSYyPZrBKrCSvLNSQGYT6gkgZXGDCBWVVRkNRT\",\"targetCustody\":\"4t4CxpF8cjtgdiVKNgpsM5i7K3C1zUpvUcbG4hCToNfD\",\"collateralCustody\":\"4t4CxpF8cjtgdiVKNgpsM5i7K3C1zUpvUcbG4hCToNfD\",\"side\":\"long\",\"maxLev\":50,\"targetCustodyId\":5,\"collateralCustodyId\":5,\"targetMint\":\"ray4PVwCwoM4ADM3qKar3Wy6v7eA2zcMtHWv7LAPGe8\",\"collateralMint\":\"ray4PVwCwoM4ADM3qKar3Wy6v7eA2zcMtHWv7LAPGe8\"},{\"marketId\":9,\"marketAccount\":\"8nY84A5Pmw4DVkrAUXMsSQ7QgzWFw68tzsZnJrMqZohb\",\"pool\":\"FpRXePeSYyPZrBKrCSvLNSQGYT6gkgZXGDCBWVVRkNRT\",\"targetCustody\":\"4t4CxpF8cjtgdiVKNgpsM5i7K3C1zUpvUcbG4hCToNfD\",\"collateralCustody\":\"4BwjABgU78jqjKeyCemyCCLwEtFdZ8JSeP9ogPMQS8Zg\",\"side\":\"short\",\"maxLev\":50,\"targetCustodyId\":5,\"collateralCustodyId\":0,\"targetMint\":\"ray4PVwCwoM4ADM3qKar3Wy6v7eA2zcMtHWv7LAPGe8\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":10,\"marketAccount\":\"5MyvTFC9WrYNpkiMJLCvd1N8zUCgFGxQFEuQMV1AbM1Y\",\"pool\":\"FpRXePeSYyPZrBKrCSvLNSQGYT6gkgZXGDCBWVVRkNRT\",\"targetCustody\":\"DHaP6PyLpgugW3NumW8GpMddbwNKpnckhet9ec92qE5p\",\"collateralCustody\":\"DHaP6PyLpgugW3NumW8GpMddbwNKpnckhet9ec92qE5p\",\"side\":\"long\",\"maxLev\":50,\"targetCustodyId\":6,\"collateralCustodyId\":6,\"targetMint\":\"kmnooU2T6dYeVvPcwFjtNwDdgfNtAY6qs8tnxacZQxb\",\"collateralMint\":\"kmnooU2T6dYeVvPcwFjtNwDdgfNtAY6qs8tnxacZQxb\"},{\"marketId\":11,\"marketAccount\":\"tkzeXG2G7bzmCSZsZcYzXMeifMLbaF9hJBM7ao2gt2Y\",\"pool\":\"FpRXePeSYyPZrBKrCSvLNSQGYT6gkgZXGDCBWVVRkNRT\",\"targetCustody\":\"DHaP6PyLpgugW3NumW8GpMddbwNKpnckhet9ec92qE5p\",\"collateralCustody\":\"4BwjABgU78jqjKeyCemyCCLwEtFdZ8JSeP9ogPMQS8Zg\",\"side\":\"short\",\"maxLev\":50,\"targetCustodyId\":6,\"collateralCustodyId\":0,\"targetMint\":\"kmnooU2T6dYeVvPcwFjtNwDdgfNtAY6qs8tnxacZQxb\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"}]},{\"programId\":\"FTN6rgbaaxwT8mpRuC55EFTwpHB3BwnHJ91Lqv4ZVCfW\",\"perpComposibilityProgramId\":\"SWAP4AE4N1if9qKD7dgfQgmRBRv1CtWG8xDs4HP14ST\",\"fbNftRewardProgramId\":\"FB8mxzFuW99ExD1B14hFqoeWWS1UdbuK6iY2PVPpKFQi\",\"cluster\":\"devnet\",\"poolName\":\"devnet.4\",\"poolAddress\":\"2SLfjsonPtdBugZke3UJzQ8s7DcHQHJxqUuVN1wrthnc\",\"stakedLpTokenMint\":\"58YkJCFQZ3htRUtkHMdUZNfdpEcjGTFi1jx3DceZvd6N\",\"compoundingTokenMint\":\"82Jj9HJbrz4w2ZeFaGpco76sR6BmQLYYgoSkAeyHqAgj\",\"stakedLpVault\":\"5HYrb2rKjF2b2ye5EiZAYeBYNeNEUzCct3N2rBmVjzLu\",\"compoundingLpVault\":\"6kbPgYxXiAvr2ELTsGEMQ9cqcJj5mF3haVtunDPwKYvx\",\"metadataAccount\":\"Hm6oanS5hrcu3QMC4jumKq2U5aUaJrfasE1sQ2Lct3zF\",\"lpDecimals\":6,\"compoundingLpTokenSymbol\":\"FLP.4\",\"stakedLpTokenSymbol\":\"sFLP.4\",\"perpetuals\":\"445GcRLAJ64DcxSRbvQTkbwXgWUyubAxzQUQ2wL73KLS\",\"transferAuthority\":\"EPyHAAHUYnFATwd8CJ7owLnozFeS8pFsr3RNJD1eueYq\",\"multisig\":\"Eu3cBFRo18AeN9BFb5ndzk2PEmBT7yWEhh3VkG21pyGo\",\"addressLookupTableAddresses\":[\"8YQHv2K84A7a7UA6tKKwrD4DsnKHAa24qLYMEH17Atwc\"],\"backupOracle\":\"AHaKsRB4tsGSzFfFqAxUpfRRmsUj5EhwHSxSXK2UGRp5\",\"nftCollectionAddress\":\"3rkRzHdN7dXy5CQfX3Lz6UBBJ2F9n58VEpvDSmbaVHt9\",\"rewardDistributionProgram\":{\"programId\":\"FARTfzmezUtejeF42vfyvX96NWq1BuAcXFiAQuz6wZZg\",\"transferAuthority\":\"4cgNvcrPFxmgJVyQNJqM8Sb6eJnDktr5mWA3gSkdNcyT\",\"rewardVault\":\"DrXUtn8BRUYAo1i3ZTkPRXqU7w2KGbCjiskzH8wGExGK\",\"rewardMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"rewardTokenAccount\":\"6X9LbFxtvjGxBEgHiE3KLQjJtAqkThqrhCufLhrPfMEp\"},\"tokens\":[{\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\",\"isToken2022\":false},{\"symbol\":\"BONK\",\"mintKey\":\"bonkmzC5QamYYD9LE73evR6UH49ojDxsFt9Juwqsx7h\",\"decimals\":5,\"usdPrecision\":8,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.BONK/USD\",\"pythPriceId\":\"0x72b021217ca3fe68922a19aaf990109cb9d84e9ad004b4d2025ad6f529314419\",\"isToken2022\":false},{\"symbol\":\"PENGU\",\"mintKey\":\"pguzpUxEhB5Rd3dUhioFBQd8RTkQzrkE4JBenyC86ZU\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.PENGU/USD\",\"pythPriceId\":\"0xbed3097008b9b5e3c93bec20be79cb43986b85a996475589351a21e67bae9b61\",\"isToken2022\":false}],\"custodies\":[{\"custodyId\":0,\"custodyAccount\":\"9ikjiYhjcNhGF7t6zfsDpXh2MwCT2ydm5rFsB4yN3XEs\",\"tokenAccount\":\"3RP193kSDd3q1gFuLD2EwX5vAsqRhfTXttehNyjqVrSY\",\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"intOracleAddress\":\"CuzxxETyjZkGVJmUv4zJTjoo4YE5HHdNm4AT4krtTikY\",\"extOracleAddress\":\"Dpw1EAVrSB1ibxiDQyTAW6Zip3J4Btk2x4SgApQCeFbX\",\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\"},{\"custodyId\":1,\"custodyAccount\":\"DtmPaayiEidB5VQEZXCv5g54F5aaTguCQXck13wfE7Sp\",\"tokenAccount\":\"2iNWe4jjHowqZcKZwcV8oRXt5wWs1dQw7FX1vLiLa3un\",\"symbol\":\"BONK\",\"mintKey\":\"bonkmzC5QamYYD9LE73evR6UH49ojDxsFt9Juwqsx7h\",\"decimals\":5,\"usdPrecision\":8,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"Gmp635ELmurCvcrbTwuY2AJyqVf74DzaSzgJ1xNYMGiB\",\"extOracleAddress\":\"DBE3N8uNjhKPRHfANdwGvCZghWXyLPdqdSbEW2XFwBiX\",\"pythTicker\":\"Crypto.BONK/USD\",\"pythPriceId\":\"0x72b021217ca3fe68922a19aaf990109cb9d84e9ad004b4d2025ad6f529314419\"},{\"custodyId\":2,\"custodyAccount\":\"D3o8xWXiaCx3JfWAFn2PGtGVChXUM2NtA7zLLZ7jSY4Z\",\"tokenAccount\":\"7eVBaHXQ16EburMqUusg4ZQKFqaSJVn8jaPo2sNWG3Cm\",\"symbol\":\"PENGU\",\"mintKey\":\"pguzpUxEhB5Rd3dUhioFBQd8RTkQzrkE4JBenyC86ZU\",\"decimals\":5,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"BfsFWptshYaaQAByxv5MwgnPWSPcuTZ86jET6z9VHDVp\",\"extOracleAddress\":\"27zzC5wXCeZeuJ3h9uAJzV5tGn6r5Tzo98S1ZceYKEb8\",\"pythTicker\":\"Crypto.PENGU/USD\",\"pythPriceId\":\"0xbed3097008b9b5e3c93bec20be79cb43986b85a996475589351a21e67bae9b61\"}],\"markets\":[{\"marketId\":0,\"marketAccount\":\"GfSgg8DkT7GQwAcbnvwokuy2rzDR6X9Zdc13JtTdTGyw\",\"pool\":\"2SLfjsonPtdBugZke3UJzQ8s7DcHQHJxqUuVN1wrthnc\",\"targetCustody\":\"DtmPaayiEidB5VQEZXCv5g54F5aaTguCQXck13wfE7Sp\",\"collateralCustody\":\"DtmPaayiEidB5VQEZXCv5g54F5aaTguCQXck13wfE7Sp\",\"side\":\"long\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":1,\"targetMint\":\"bonkmzC5QamYYD9LE73evR6UH49ojDxsFt9Juwqsx7h\",\"collateralMint\":\"bonkmzC5QamYYD9LE73evR6UH49ojDxsFt9Juwqsx7h\"},{\"marketId\":1,\"marketAccount\":\"6KaEvCmhy3YwqikB2MsmzTKWR7HJsSmmmPaoaYRTxg71\",\"pool\":\"2SLfjsonPtdBugZke3UJzQ8s7DcHQHJxqUuVN1wrthnc\",\"targetCustody\":\"DtmPaayiEidB5VQEZXCv5g54F5aaTguCQXck13wfE7Sp\",\"collateralCustody\":\"9ikjiYhjcNhGF7t6zfsDpXh2MwCT2ydm5rFsB4yN3XEs\",\"side\":\"short\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"bonkmzC5QamYYD9LE73evR6UH49ojDxsFt9Juwqsx7h\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"},{\"marketId\":2,\"marketAccount\":\"H9h7SvUvLZzkVjrpj5XmrryLYrVzyWtjgW8MnrC7vofL\",\"pool\":\"2SLfjsonPtdBugZke3UJzQ8s7DcHQHJxqUuVN1wrthnc\",\"targetCustody\":\"D3o8xWXiaCx3JfWAFn2PGtGVChXUM2NtA7zLLZ7jSY4Z\",\"collateralCustody\":\"D3o8xWXiaCx3JfWAFn2PGtGVChXUM2NtA7zLLZ7jSY4Z\",\"side\":\"long\",\"maxLev\":10,\"targetCustodyId\":2,\"collateralCustodyId\":2,\"targetMint\":\"pguzpUxEhB5Rd3dUhioFBQd8RTkQzrkE4JBenyC86ZU\",\"collateralMint\":\"pguzpUxEhB5Rd3dUhioFBQd8RTkQzrkE4JBenyC86ZU\"},{\"marketId\":3,\"marketAccount\":\"13rECe3spGy1A8SqtRP9xv3PHeUEwqgft2Ur2Qxzkfji\",\"pool\":\"2SLfjsonPtdBugZke3UJzQ8s7DcHQHJxqUuVN1wrthnc\",\"targetCustody\":\"D3o8xWXiaCx3JfWAFn2PGtGVChXUM2NtA7zLLZ7jSY4Z\",\"collateralCustody\":\"9ikjiYhjcNhGF7t6zfsDpXh2MwCT2ydm5rFsB4yN3XEs\",\"side\":\"short\",\"maxLev\":10,\"targetCustodyId\":2,\"collateralCustodyId\":0,\"targetMint\":\"pguzpUxEhB5Rd3dUhioFBQd8RTkQzrkE4JBenyC86ZU\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"}]},{\"programId\":\"FTN6rgbaaxwT8mpRuC55EFTwpHB3BwnHJ91Lqv4ZVCfW\",\"perpComposibilityProgramId\":\"SWAP4AE4N1if9qKD7dgfQgmRBRv1CtWG8xDs4HP14ST\",\"fbNftRewardProgramId\":\"FB8mxzFuW99ExD1B14hFqoeWWS1UdbuK6iY2PVPpKFQi\",\"cluster\":\"devnet\",\"poolName\":\"devnet.5\",\"poolAddress\":\"74MmsAH8H4S95KbBgWA4XP4vHcxe7jxEopjUkMabQUa\",\"stakedLpTokenMint\":\"FBZ3eWtCmwkEnEMQ1t7dStRV5Xb5B41xfwWNsBmSUxFT\",\"compoundingLpVault\":\"Dtn4WLDRA8GdAj9BU27wXzV8C4ayb8375qd8m5o1atCt\",\"compoundingTokenMint\":\"A2aKhBQiNTTZmXrR1bUoRwMCGuDtaQ8Hi8uesozqoc3x\",\"stakedLpVault\":\"11111111111111111111111111111111\",\"metadataAccount\":\"5J42aH92z42HaUzSHoaA4iCCBE1iUsVt2u5oaYdN5yPx\",\"lpDecimals\":6,\"compoundingLpTokenSymbol\":\"FLP.5\",\"stakedLpTokenSymbol\":\"sFLP.5\",\"perpetuals\":\"445GcRLAJ64DcxSRbvQTkbwXgWUyubAxzQUQ2wL73KLS\",\"transferAuthority\":\"EPyHAAHUYnFATwd8CJ7owLnozFeS8pFsr3RNJD1eueYq\",\"multisig\":\"Eu3cBFRo18AeN9BFb5ndzk2PEmBT7yWEhh3VkG21pyGo\",\"addressLookupTableAddresses\":[\"8YQHv2K84A7a7UA6tKKwrD4DsnKHAa24qLYMEH17Atwc\"],\"backupOracle\":\"AHaKsRB4tsGSzFfFqAxUpfRRmsUj5EhwHSxSXK2UGRp5\",\"nftCollectionAddress\":\"3rkRzHdN7dXy5CQfX3Lz6UBBJ2F9n58VEpvDSmbaVHt9\",\"rewardDistributionProgram\":{\"programId\":\"FARTfzmezUtejeF42vfyvX96NWq1BuAcXFiAQuz6wZZg\",\"transferAuthority\":\"4cgNvcrPFxmgJVyQNJqM8Sb6eJnDktr5mWA3gSkdNcyT\",\"rewardVault\":\"DrXUtn8BRUYAo1i3ZTkPRXqU7w2KGbCjiskzH8wGExGK\",\"rewardMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"rewardTokenAccount\":\"6X9LbFxtvjGxBEgHiE3KLQjJtAqkThqrhCufLhrPfMEp\"},\"tokens\":[{\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\",\"isToken2022\":false},{\"symbol\":\"WIF\",\"mintKey\":\"wif1hWbc3yHA6ij5iPLhnMV19EDFcN6WETVP3QV16dQ\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.WIF/USD\",\"pythPriceId\":\"0x4ca4beeca86f0d164160323817a4e42b10010a724c2217c6ee41b54cd4cc61fc\",\"isToken2022\":false}],\"custodies\":[{\"custodyId\":0,\"custodyAccount\":\"6nMH1Yz7dDgqE4qiFP7FESD233zDBexuBsefGSshAJnM\",\"tokenAccount\":\"DWUskQVRKoQ1WL9Q1Qze6k2xSJTu5AmaZrnmTG6Fhhqi\",\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"intOracleAddress\":\"CuzxxETyjZkGVJmUv4zJTjoo4YE5HHdNm4AT4krtTikY\",\"extOracleAddress\":\"Dpw1EAVrSB1ibxiDQyTAW6Zip3J4Btk2x4SgApQCeFbX\",\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\"},{\"custodyId\":1,\"custodyAccount\":\"8Z94RGNLFuAxxgi3e4TQ2mxsmD4JJypxFTVaTw5BANC7\",\"tokenAccount\":\"6S2w3K3Vp71nW7QkFK2betj23cTWjDjTWqHvVdwWhj4R\",\"symbol\":\"WIF\",\"mintKey\":\"wif1hWbc3yHA6ij5iPLhnMV19EDFcN6WETVP3QV16dQ\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"BdeNEwrZ4UG3MRGSdE2JJNnbXvuz2VihqR4FzQ4Ms3uF\",\"extOracleAddress\":\"6B23K3tkb51vLZA14jcEQVCA1pfHptzEHFA93V5dYwbT\",\"pythTicker\":\"Crypto.WIF/USD\",\"pythPriceId\":\"0x4ca4beeca86f0d164160323817a4e42b10010a724c2217c6ee41b54cd4cc61fc\"}],\"markets\":[{\"marketId\":0,\"marketAccount\":\"YypLTvzuQhHN36oz2CcyxfNXPcp9BEURBVvftfzZnLM\",\"pool\":\"74MmsAH8H4S95KbBgWA4XP4vHcxe7jxEopjUkMabQUa\",\"targetCustody\":\"8Z94RGNLFuAxxgi3e4TQ2mxsmD4JJypxFTVaTw5BANC7\",\"collateralCustody\":\"8Z94RGNLFuAxxgi3e4TQ2mxsmD4JJypxFTVaTw5BANC7\",\"side\":\"long\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":1,\"targetMint\":\"wif1hWbc3yHA6ij5iPLhnMV19EDFcN6WETVP3QV16dQ\",\"collateralMint\":\"wif1hWbc3yHA6ij5iPLhnMV19EDFcN6WETVP3QV16dQ\"},{\"marketId\":1,\"marketAccount\":\"F8Ac9tLngosbTtawdHzQ6dkFBHmkff6ZLX1YMk9N4yiR\",\"pool\":\"74MmsAH8H4S95KbBgWA4XP4vHcxe7jxEopjUkMabQUa\",\"targetCustody\":\"8Z94RGNLFuAxxgi3e4TQ2mxsmD4JJypxFTVaTw5BANC7\",\"collateralCustody\":\"6nMH1Yz7dDgqE4qiFP7FESD233zDBexuBsefGSshAJnM\",\"side\":\"short\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"wif1hWbc3yHA6ij5iPLhnMV19EDFcN6WETVP3QV16dQ\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"}]},{\"programId\":\"FTN6rgbaaxwT8mpRuC55EFTwpHB3BwnHJ91Lqv4ZVCfW\",\"perpComposibilityProgramId\":\"SWAP4AE4N1if9qKD7dgfQgmRBRv1CtWG8xDs4HP14ST\",\"fbNftRewardProgramId\":\"FB8mxzFuW99ExD1B14hFqoeWWS1UdbuK6iY2PVPpKFQi\",\"cluster\":\"devnet\",\"poolName\":\"devnet.6\",\"poolAddress\":\"CVdbySirAWcygBo3WsmJH1QPnQi3oyDaDWv5C3d3xQAH\",\"stakedLpTokenMint\":\"EBCDSC4GefRn8RqJ55q2HytHpnzJyRpGSK6wWyBepezn\",\"compoundingLpVault\":\"EwX8L54yzXsKKoKV3htPyrrbxVH4x5F9kaHvo5NWN7Qz\",\"compoundingTokenMint\":\"CF3z7VsqrVwuY26nmVgJTdprYhYsY6MN8nWm6mJw43tJ\",\"stakedLpVault\":\"C4Gq9n2UU1SAnsQd2hTjMvgFgTiTjYPuLKiFDfA5hEVz\",\"metadataAccount\":\"ET8kzufP9ppbBCYrEuhSq2Dt6DWdg52rBKxrMiLNdi7s\",\"lpDecimals\":6,\"compoundingLpTokenSymbol\":\"FLP.6\",\"stakedLpTokenSymbol\":\"sFLP.6\",\"perpetuals\":\"445GcRLAJ64DcxSRbvQTkbwXgWUyubAxzQUQ2wL73KLS\",\"transferAuthority\":\"EPyHAAHUYnFATwd8CJ7owLnozFeS8pFsr3RNJD1eueYq\",\"multisig\":\"Eu3cBFRo18AeN9BFb5ndzk2PEmBT7yWEhh3VkG21pyGo\",\"addressLookupTableAddresses\":[\"8YQHv2K84A7a7UA6tKKwrD4DsnKHAa24qLYMEH17Atwc\"],\"backupOracle\":\"AHaKsRB4tsGSzFfFqAxUpfRRmsUj5EhwHSxSXK2UGRp5\",\"nftCollectionAddress\":\"3rkRzHdN7dXy5CQfX3Lz6UBBJ2F9n58VEpvDSmbaVHt9\",\"rewardDistributionProgram\":{\"programId\":\"FARTfzmezUtejeF42vfyvX96NWq1BuAcXFiAQuz6wZZg\",\"transferAuthority\":\"4cgNvcrPFxmgJVyQNJqM8Sb6eJnDktr5mWA3gSkdNcyT\",\"rewardVault\":\"DrXUtn8BRUYAo1i3ZTkPRXqU7w2KGbCjiskzH8wGExGK\",\"rewardMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"rewardTokenAccount\":\"6X9LbFxtvjGxBEgHiE3KLQjJtAqkThqrhCufLhrPfMEp\"},\"tokens\":[{\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\",\"isToken2022\":false},{\"symbol\":\"SAMO\",\"mintKey\":\"samcjumzkf9RJcLpEKgLoNcznnXBX2Zsgg3jmYdXyoi\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.SAMO/USD\",\"pythPriceId\":\"0x49601625e1a342c1f90c3fe6a03ae0251991a1d76e480d2741524c29037be28a\",\"isToken2022\":false}],\"custodies\":[{\"custodyId\":0,\"custodyAccount\":\"AJWCQ8atLYkjKDQ2mBvRx2kUqwkADghZaWwJyk5rq86g\",\"tokenAccount\":\"986J89p9CrrDWCLuwD8ZB8SAXtBT9dX8TW4GHi4vssfF\",\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"intOracleAddress\":\"CuzxxETyjZkGVJmUv4zJTjoo4YE5HHdNm4AT4krtTikY\",\"extOracleAddress\":\"Dpw1EAVrSB1ibxiDQyTAW6Zip3J4Btk2x4SgApQCeFbX\",\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\"},{\"custodyId\":1,\"custodyAccount\":\"F5JkHhc88PgvtPMdQfgZUZzbKDvbJPvSeDkZ2r2QL1P7\",\"tokenAccount\":\"7zv7KYSyULR7E3utBjBRxyw6U2Jz1VLir7xMM3UFjTkd\",\"symbol\":\"SAMO\",\"mintKey\":\"samcjumzkf9RJcLpEKgLoNcznnXBX2Zsgg3jmYdXyoi\",\"decimals\":6,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"7xDa6nvmCeG8cfAuAtspNHppq1V68E2fQT2i2CeubpGn\",\"extOracleAddress\":\"2eUVzcYccqXzsDU1iBuatUaDCbRKBjegEaPPeChzfocG\",\"pythTicker\":\"Crypto.SAMO/USD\",\"pythPriceId\":\"0x49601625e1a342c1f90c3fe6a03ae0251991a1d76e480d2741524c29037be28a\"}],\"markets\":[{\"marketId\":0,\"marketAccount\":\"5imEjk3DH84hj5ZwnusPndzz2EX14rypTQnFvmq7zQWT\",\"pool\":\"CVdbySirAWcygBo3WsmJH1QPnQi3oyDaDWv5C3d3xQAH\",\"targetCustody\":\"F5JkHhc88PgvtPMdQfgZUZzbKDvbJPvSeDkZ2r2QL1P7\",\"collateralCustody\":\"F5JkHhc88PgvtPMdQfgZUZzbKDvbJPvSeDkZ2r2QL1P7\",\"side\":\"long\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":1,\"targetMint\":\"samcjumzkf9RJcLpEKgLoNcznnXBX2Zsgg3jmYdXyoi\",\"collateralMint\":\"samcjumzkf9RJcLpEKgLoNcznnXBX2Zsgg3jmYdXyoi\"},{\"marketId\":1,\"marketAccount\":\"3A4Utfy9yQnLoNVpoocWzUXgRuWHeUVhanKNgnBF8krs\",\"pool\":\"CVdbySirAWcygBo3WsmJH1QPnQi3oyDaDWv5C3d3xQAH\",\"targetCustody\":\"F5JkHhc88PgvtPMdQfgZUZzbKDvbJPvSeDkZ2r2QL1P7\",\"collateralCustody\":\"AJWCQ8atLYkjKDQ2mBvRx2kUqwkADghZaWwJyk5rq86g\",\"side\":\"short\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"samcjumzkf9RJcLpEKgLoNcznnXBX2Zsgg3jmYdXyoi\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"}]},{\"programId\":\"FTN6rgbaaxwT8mpRuC55EFTwpHB3BwnHJ91Lqv4ZVCfW\",\"perpComposibilityProgramId\":\"SWAP4AE4N1if9qKD7dgfQgmRBRv1CtWG8xDs4HP14ST\",\"fbNftRewardProgramId\":\"FB8mxzFuW99ExD1B14hFqoeWWS1UdbuK6iY2PVPpKFQi\",\"cluster\":\"devnet\",\"poolName\":\"devnet.7\",\"poolAddress\":\"2DBAc35Ef4ai8xYt2mtdQNkfM43ge4bCpanLhSRDAmX2\",\"stakedLpTokenMint\":\"3Sc1v1xRzWYKJhDo7NjsUYKmy3aF58C5sgBVdU1VtiQK\",\"compoundingLpVault\":\"C8UEVGPv2AcQoXJTLntTUB2hqd81Lqyg4m7CHtzQx9Cu\",\"compoundingTokenMint\":\"FPCPGYTYGh86JrMsN8wpQQ6YEumrjuCigZC7hSHK4Lg7\",\"stakedLpVault\":\"3gGuMrKXcNGrZQKkRueSDWbSCVhEfhEMLEfCtVTFudeG\",\"metadataAccount\":\"E1cw2L2GU8BPsRHb2kUXkcfrhwv5FaCeKU91LWdtyjWp\",\"lpDecimals\":6,\"compoundingLpTokenSymbol\":\"FLP.7\",\"stakedLpTokenSymbol\":\"sFLP.7\",\"perpetuals\":\"445GcRLAJ64DcxSRbvQTkbwXgWUyubAxzQUQ2wL73KLS\",\"transferAuthority\":\"EPyHAAHUYnFATwd8CJ7owLnozFeS8pFsr3RNJD1eueYq\",\"multisig\":\"Eu3cBFRo18AeN9BFb5ndzk2PEmBT7yWEhh3VkG21pyGo\",\"addressLookupTableAddresses\":[\"8YQHv2K84A7a7UA6tKKwrD4DsnKHAa24qLYMEH17Atwc\"],\"backupOracle\":\"AHaKsRB4tsGSzFfFqAxUpfRRmsUj5EhwHSxSXK2UGRp5\",\"nftCollectionAddress\":\"3rkRzHdN7dXy5CQfX3Lz6UBBJ2F9n58VEpvDSmbaVHt9\",\"rewardDistributionProgram\":{\"programId\":\"FARTfzmezUtejeF42vfyvX96NWq1BuAcXFiAQuz6wZZg\",\"transferAuthority\":\"4cgNvcrPFxmgJVyQNJqM8Sb6eJnDktr5mWA3gSkdNcyT\",\"rewardVault\":\"DrXUtn8BRUYAo1i3ZTkPRXqU7w2KGbCjiskzH8wGExGK\",\"rewardMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"rewardTokenAccount\":\"6X9LbFxtvjGxBEgHiE3KLQjJtAqkThqrhCufLhrPfMEp\"},\"tokens\":[{\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\",\"isToken2022\":false},{\"symbol\":\"AI16Z\",\"mintKey\":\"ai16pTnXpFj4FN9Xa5gvdSvgHkHPG1HRBExmPfDcQ6g\",\"decimals\":9,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"pythTicker\":\"Crypto.AI16Z/USD\",\"pythPriceId\":\"2551eca7784671173def2c41e6f3e51e11cd87494863f1d208fdd8c64a1f85ae\",\"isToken2022\":true}],\"custodies\":[{\"custodyId\":0,\"custodyAccount\":\"55nYDgXWE6CPM83QxSmbV9GSdSpt8cJACpKB5YTP8ML2\",\"tokenAccount\":\"Ae4RszYoTqWjJeCjXBRKecREwgtjFndCMvaUwg9NS2n6\",\"symbol\":\"USDC\",\"mintKey\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\",\"decimals\":6,\"usdPrecision\":2,\"tokenPrecision\":4,\"isStable\":true,\"isVirtual\":false,\"intOracleAddress\":\"CuzxxETyjZkGVJmUv4zJTjoo4YE5HHdNm4AT4krtTikY\",\"extOracleAddress\":\"Dpw1EAVrSB1ibxiDQyTAW6Zip3J4Btk2x4SgApQCeFbX\",\"pythTicker\":\"Crypto.USDC/USD\",\"pythPriceId\":\"0xeaa020c61cc479712813461ce153894a96a6c00b21ed0cfc2798d1f9a9e9c94a\"},{\"custodyId\":1,\"custodyAccount\":\"EYCsHjVcCrpqcN7gNbZXzX3tB3xdDjvzAQeAwWXoMY94\",\"tokenAccount\":\"47R83ugBsb2qLjtUQ6Y2mQK2zwusa6xir65q3jRzHjb1\",\"symbol\":\"AI16Z\",\"mintKey\":\"ai16pTnXpFj4FN9Xa5gvdSvgHkHPG1HRBExmPfDcQ6g\",\"decimals\":9,\"usdPrecision\":4,\"tokenPrecision\":4,\"isStable\":false,\"isVirtual\":false,\"intOracleAddress\":\"HFyJLowp5ByuHEvz6jvaDYpwKUyt7Tovk5cbSz5vgGDG\",\"extOracleAddress\":\"BxizdE1Rd9yeCXUaorGNGLc4qHbqBULxiBtjRX37HjSV\",\"pythTicker\":\"Crypto.AI16Z/USD\",\"pythPriceId\":\"2551eca7784671173def2c41e6f3e51e11cd87494863f1d208fdd8c64a1f85ae\"}],\"markets\":[{\"marketId\":0,\"marketAccount\":\"2qv7g6uo3y8a9EP7zYF4hqLH34A9BkVT32jXs1yZyTV9\",\"pool\":\"2DBAc35Ef4ai8xYt2mtdQNkfM43ge4bCpanLhSRDAmX2\",\"targetCustody\":\"EYCsHjVcCrpqcN7gNbZXzX3tB3xdDjvzAQeAwWXoMY94\",\"collateralCustody\":\"EYCsHjVcCrpqcN7gNbZXzX3tB3xdDjvzAQeAwWXoMY94\",\"side\":\"long\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":1,\"targetMint\":\"ai16pTnXpFj4FN9Xa5gvdSvgHkHPG1HRBExmPfDcQ6g\",\"collateralMint\":\"ai16pTnXpFj4FN9Xa5gvdSvgHkHPG1HRBExmPfDcQ6g\"},{\"marketId\":1,\"marketAccount\":\"DNCr6HQSPvvb6LNkVBMFVpTPiceJMSBDhrkpLjVBnCw7\",\"pool\":\"2DBAc35Ef4ai8xYt2mtdQNkfM43ge4bCpanLhSRDAmX2\",\"targetCustody\":\"EYCsHjVcCrpqcN7gNbZXzX3tB3xdDjvzAQeAwWXoMY94\",\"collateralCustody\":\"55nYDgXWE6CPM83QxSmbV9GSdSpt8cJACpKB5YTP8ML2\",\"side\":\"short\",\"maxLev\":10,\"targetCustodyId\":1,\"collateralCustodyId\":0,\"targetMint\":\"ai16pTnXpFj4FN9Xa5gvdSvgHkHPG1HRBExmPfDcQ6g\",\"collateralMint\":\"Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr\"}]}]}"));}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/PoolConfig.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __assign = this && this.__assign || function() {
    __assign = Object.assign || function(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PoolConfig = void 0;
var web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.95.8_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
var PoolConfig_json_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/PoolConfig.json (json)"));
var types_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/types/index.js [app-route] (ecmascript)");
var PoolConfig = function() {
    function PoolConfig(programId, perpComposibilityProgramId, fbNftRewardProgramId, cluster, poolName, poolAddress, stakedLpTokenMint, compoundingTokenMint, stakedLpVault, compoundingLpVault, lpDecimals, compoundingLpTokenSymbol, stakedLpTokenSymbol, perpetuals, transferAuthority, multisig, addressLookupTableAddresses, backupOracle, nftCollectionAddress, rewardDistributionProgram, tokens, custodies, markets) {
        var _this = this;
        this.programId = programId;
        this.perpComposibilityProgramId = perpComposibilityProgramId;
        this.fbNftRewardProgramId = fbNftRewardProgramId;
        this.cluster = cluster;
        this.poolName = poolName;
        this.poolAddress = poolAddress;
        this.stakedLpTokenMint = stakedLpTokenMint;
        this.compoundingTokenMint = compoundingTokenMint;
        this.stakedLpVault = stakedLpVault;
        this.compoundingLpVault = compoundingLpVault;
        this.lpDecimals = lpDecimals;
        this.compoundingLpTokenSymbol = compoundingLpTokenSymbol;
        this.stakedLpTokenSymbol = stakedLpTokenSymbol;
        this.perpetuals = perpetuals;
        this.transferAuthority = transferAuthority;
        this.multisig = multisig;
        this.addressLookupTableAddresses = addressLookupTableAddresses;
        this.backupOracle = backupOracle;
        this.nftCollectionAddress = nftCollectionAddress;
        this.rewardDistributionProgram = rewardDistributionProgram;
        this.tokens = tokens;
        this.custodies = custodies;
        this.markets = markets;
        this.getTokenFromSymbol = function(symbol) {
            return _this.tokens.find(function(f) {
                return f.symbol.toUpperCase() === symbol.toUpperCase();
            });
        };
        this.getTokenFromMintString = function(mint) {
            return _this.tokens.find(function(f) {
                return f.mintKey.toBase58() === mint;
            });
        };
        this.getTokenFromMintPk = function(mint) {
            return _this.tokens.find(function(f) {
                return f.mintKey.equals(mint);
            });
        };
    }
    PoolConfig.prototype.getAllTokenMints = function() {
        return Array.from(this.tokens.map(function(token) {
            return new web3_js_1.PublicKey(token.mintKey);
        }));
    };
    PoolConfig.prototype.getMarketConfigByPk = function(marketAccountPk) {
        var market = this.markets.find(function(f) {
            return f.marketAccount.equals(marketAccountPk);
        });
        if (!market) throw new Error("No such market ".concat(marketAccountPk.toBase58(), " exists."));
        return market;
    };
    PoolConfig.prototype.getMarketConfig = function(targetCustody, collateralCustody, side) {
        var marketAccountPk = this.getMarketPk(targetCustody, collateralCustody, side);
        var market = this.markets.find(function(f) {
            return f.marketAccount.equals(marketAccountPk);
        });
        if (!market) return null;
        return market;
    };
    PoolConfig.prototype.getMarketPk = function(targetCustody, collateralCustody, side) {
        return web3_js_1.PublicKey.findProgramAddressSync([
            Buffer.from('market'),
            targetCustody.toBuffer(),
            collateralCustody.toBuffer(),
            Buffer.from([
                (0, types_1.isVariant)(side, 'long') ? 1 : 2
            ])
        ], this.programId)[0];
    };
    PoolConfig.prototype.getPositionFromMarketPk = function(owner, marketAccount) {
        return web3_js_1.PublicKey.findProgramAddressSync([
            Buffer.from("position"),
            owner.toBuffer(),
            marketAccount.toBuffer()
        ], this.programId)[0];
    };
    PoolConfig.prototype.getOrderFromMarketPk = function(owner, marketAccount) {
        return web3_js_1.PublicKey.findProgramAddressSync([
            Buffer.from("order"),
            owner.toBuffer(),
            marketAccount.toBuffer()
        ], this.programId)[0];
    };
    PoolConfig.prototype.getPositionFromCustodyPk = function(owner, targetCustody, collateralCustody, side) {
        return web3_js_1.PublicKey.findProgramAddressSync([
            Buffer.from("position"),
            owner.toBuffer(),
            this.getMarketPk(targetCustody, collateralCustody, side).toBuffer()
        ], this.programId)[0];
    };
    PoolConfig.prototype.doesMarketExist = function(pubkey) {
        return;
    };
    PoolConfig.prototype.getAllMarketPks = function() {
        return this.markets.map(function(m) {
            return m.marketAccount;
        });
    };
    PoolConfig.prototype.getNonStableTokens = function() {
        return Array.from(this.tokens.filter(function(token) {
            return !token.isStable;
        }).map(function(token) {
            return new web3_js_1.PublicKey(token.mintKey);
        }));
    };
    PoolConfig.prototype.getAllCustodies = function() {
        return Array.from(this.custodies.map(function(custody) {
            return new web3_js_1.PublicKey(custody.custodyAccount);
        }));
    };
    PoolConfig.prototype.getNonStableCustodies = function() {
        return Array.from(this.custodies.filter(function(custody) {
            return !custody.isStable;
        }).map(function(custody) {
            return new web3_js_1.PublicKey(custody.custodyAccount);
        }));
    };
    PoolConfig.getCustodyConfig = function(custodyAccountPk, poolName, cluster) {
        return this.fromIdsByName(poolName, cluster).custodies.find(function(f) {
            return f.custodyAccount.toBase58() === custodyAccountPk.toString();
        });
    };
    PoolConfig.prototype.getCustodyIdFromCustodyAccount = function(custodyAccountPk) {
        return this.custodies.find(function(f) {
            return f.custodyAccount.toBase58() === custodyAccountPk.toString();
        }).custodyId;
    };
    PoolConfig.prototype.getCustodyAccountFromCustodyId = function(custodyId) {
        return this.custodies.find(function(f) {
            return f.custodyId === custodyId;
        }).custodyAccount;
    };
    PoolConfig.getTokensInPool = function(name, cluster) {
        var poolConfig = PoolConfig_json_1.default.pools.find(function(pool) {
            return pool['poolName'] === name && cluster === pool['cluster'];
        });
        if (!poolConfig) throw new Error("No pool config ".concat(name, " found in Ids!"));
        var tokens = poolConfig['tokens'].map(function(i) {
            return __assign(__assign({}, i), {
                usdPrecision: i.usdPrecision,
                tokenPrecision: i.tokenPrecision,
                mintKey: new web3_js_1.PublicKey(i.mintKey)
            });
        });
        return tokens;
    };
    PoolConfig.buildPoolconfigFromJson = function(poolConfig) {
        var tokens;
        try {
            tokens = poolConfig['tokens'].map(function(i) {
                return __assign(__assign({}, i), {
                    mintKey: new web3_js_1.PublicKey(i.mintKey)
                });
            });
        } catch (error) {
            console.log("ERROR: buildPoolconfigFromJson  unable to load tokens ");
        }
        var custodies;
        try {
            custodies = poolConfig['custodies'].map(function(i, index) {
                return __assign(__assign({}, i), {
                    custodyId: i.custodyId,
                    custodyAccount: new web3_js_1.PublicKey(i.custodyAccount),
                    tokenAccount: new web3_js_1.PublicKey(i.tokenAccount),
                    mintKey: new web3_js_1.PublicKey(i.mintKey),
                    intOracleAccount: new web3_js_1.PublicKey(i.intOracleAddress),
                    extOracleAccount: new web3_js_1.PublicKey(i.extOracleAddress),
                    usdPrecision: i.usdPrecision,
                    tokenPrecision: i.tokenPrecision
                });
            });
        } catch (error) {
            console.log("ERROR: buildPoolconfigFromJson  unable to load custodies ");
        }
        var addressLookupTableAddresses;
        try {
            addressLookupTableAddresses = poolConfig['addressLookupTableAddresses'].map(function(i) {
                return new web3_js_1.PublicKey(i);
            });
        } catch (error) {
            console.log("ERROR: buildPoolconfigFromJson  unable to load addressLookupTableAddresses ");
        }
        var markets;
        try {
            markets = poolConfig['markets'].map(function(i) {
                return __assign(__assign({}, i), {
                    marketAccount: new web3_js_1.PublicKey(i.marketAccount),
                    pool: new web3_js_1.PublicKey(i.pool),
                    targetCustody: new web3_js_1.PublicKey(i.targetCustody),
                    collateralCustody: new web3_js_1.PublicKey(i.collateralCustody),
                    side: i.side === 'long' ? types_1.Side.Long : types_1.Side.Short,
                    maxLev: i.maxLev,
                    targetMint: new web3_js_1.PublicKey(i.targetMint),
                    collateralMint: new web3_js_1.PublicKey(i.collateralMint)
                });
            });
        } catch (error) {
            console.log("ERROR: buildPoolconfigFromJson  unable to load markets ");
        }
        return new PoolConfig(new web3_js_1.PublicKey(poolConfig.programId), new web3_js_1.PublicKey(poolConfig.perpComposibilityProgramId), new web3_js_1.PublicKey(poolConfig.fbNftRewardProgramId), poolConfig.cluster, poolConfig.poolName, new web3_js_1.PublicKey(poolConfig.poolAddress), new web3_js_1.PublicKey(poolConfig.stakedLpTokenMint), new web3_js_1.PublicKey(poolConfig.compoundingTokenMint), new web3_js_1.PublicKey(poolConfig.stakedLpVault), new web3_js_1.PublicKey(poolConfig.compoundingLpVault), poolConfig.lpDecimals, poolConfig.compoundingLpTokenSymbol, poolConfig.stakedLpTokenSymbol, new web3_js_1.PublicKey(poolConfig.perpetuals), new web3_js_1.PublicKey(poolConfig.transferAuthority), new web3_js_1.PublicKey(poolConfig.multisig), addressLookupTableAddresses, new web3_js_1.PublicKey(poolConfig.backupOracle), new web3_js_1.PublicKey(poolConfig.nftCollectionAddress), {
            programId: new web3_js_1.PublicKey(poolConfig.rewardDistributionProgram.programId),
            rewardMint: new web3_js_1.PublicKey(poolConfig.rewardDistributionProgram.rewardMint),
            rewardTokenAccount: new web3_js_1.PublicKey(poolConfig.rewardDistributionProgram.rewardTokenAccount),
            rewardVault: new web3_js_1.PublicKey(poolConfig.rewardDistributionProgram.rewardVault),
            transferAuthority: new web3_js_1.PublicKey(poolConfig.rewardDistributionProgram.transferAuthority)
        }, tokens, custodies, markets);
    };
    PoolConfig.fromIdsByName = function(name, cluster) {
        var poolConfig = PoolConfig_json_1.default.pools.find(function(pool) {
            return pool['poolName'] === name && cluster === pool['cluster'];
        });
        if (!poolConfig) {
            throw new Error("No pool with ".concat(name, " found!"));
        }
        return PoolConfig.buildPoolconfigFromJson(poolConfig);
    };
    PoolConfig.fromIdsByPk = function(poolPk, cluster) {
        var poolConfig = PoolConfig_json_1.default.pools.find(function(pool) {
            return pool['poolAddress'] === poolPk.toString() && cluster === pool['cluster'];
        });
        if (!poolConfig) {
            throw new Error("No pool with ".concat(poolPk.toString(), " found!"));
        }
        return PoolConfig.buildPoolconfigFromJson(poolConfig);
    };
    return PoolConfig;
}();
exports.PoolConfig = PoolConfig;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/PoolDataClient.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PoolDataClient = void 0;
var constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/constants/index.js [app-route] (ecmascript)");
var anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.27.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
var utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/index.js [app-route] (ecmascript)");
var bignumber_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
var PoolDataClient = function() {
    function PoolDataClient(poolConfig, pool, lpTokenInfo, custodies) {
        this.poolConfig = poolConfig;
        this.pool = pool;
        this.lpTokenInfo = lpTokenInfo;
        this.custodies = custodies;
    }
    PoolDataClient.prototype.loadCustodies = function(custodies) {
        this.custodies = custodies;
    };
    PoolDataClient.prototype.loadPoolData = function(pool) {
        this.pool = pool;
    };
    PoolDataClient.prototype.loadLpData = function(lpTokenInfo) {
        this.lpTokenInfo = lpTokenInfo;
    };
    PoolDataClient.prototype.getLpStats = function(pricesMap) {
        var stableCoinAmountBni = new bignumber_js_1.default(0);
        var totalPoolValueUsdBnUi = new bignumber_js_1.default(0);
        var _loop_1 = function(custodyConfig) {
            if (custodyConfig.isVirtual) return "continue";
            var custodyAccount = this_1.custodies.find(function(t) {
                return t.mint.toBase58() === custodyConfig.mintKey.toBase58();
            });
            if (custodyAccount) {
                var priceBnUi = new bignumber_js_1.default(pricesMap.get(custodyConfig.symbol).price.toUiPrice(8));
                var ownedBnUi = new bignumber_js_1.default(custodyAccount.assets.owned.toString()).dividedBy(Math.pow(10, custodyConfig.decimals));
                var ownedUsdBnUi = ownedBnUi.multipliedBy(priceBnUi);
                if (custodyAccount.isStable) {
                    stableCoinAmountBni = stableCoinAmountBni.plus(ownedBnUi);
                }
                totalPoolValueUsdBnUi = totalPoolValueUsdBnUi.plus(ownedUsdBnUi);
            }
        };
        var this_1 = this;
        for(var _i = 0, _a = this.poolConfig.custodies; _i < _a.length; _i++){
            var custodyConfig = _a[_i];
            _loop_1(custodyConfig);
        }
        var lpTokenSupplyUi = new bignumber_js_1.default(this.lpTokenInfo.supply.toString()).dividedBy(Math.pow(10, constants_1.LP_DECIMALS));
        var lpTokenPriceUsdBnUi = this.lpTokenInfo.supply.toString() === '0' ? totalPoolValueUsdBnUi : totalPoolValueUsdBnUi.dividedBy(lpTokenSupplyUi);
        var stableCoinPercentageBnUi = stableCoinAmountBni.multipliedBy(100).dividedBy(totalPoolValueUsdBnUi);
        return {
            lpTokenSupply: new anchor_1.BN(this.lpTokenInfo.supply.toString()),
            decimals: this.poolConfig.lpDecimals,
            totalPoolValueUsd: (0, utils_1.uiDecimalsToNative)(totalPoolValueUsdBnUi.toString(), constants_1.USD_DECIMALS),
            totalPoolValueUsdUi: totalPoolValueUsdBnUi.toFixed(2, bignumber_js_1.default.ROUND_DOWN),
            price: (0, utils_1.uiDecimalsToNative)(lpTokenPriceUsdBnUi.toString(), constants_1.USD_DECIMALS),
            priceUi: lpTokenPriceUsdBnUi.toFixed(2, bignumber_js_1.default.ROUND_DOWN),
            stableCoinPercentage: stableCoinPercentageBnUi.toFixed(2, bignumber_js_1.default.ROUND_DOWN),
            marketCap: (0, utils_1.uiDecimalsToNative)(totalPoolValueUsdBnUi.toString(), constants_1.USD_DECIMALS)
        };
    };
    PoolDataClient.prototype.getCustodyStats = function(pricesMap) {
        var totalPoolValueUsd = this.getLpStats(pricesMap).totalPoolValueUsd;
        var totalPoolValueUsdUi = totalPoolValueUsd.isZero() ? '0' : (0, utils_1.nativeToUiDecimals)(totalPoolValueUsd, constants_1.USD_DECIMALS, constants_1.USD_DECIMALS);
        var custodyDetails = [];
        var _loop_2 = function(i) {
            var custodyConfig = this_2.poolConfig.custodies[i];
            if (custodyConfig.isVirtual) return "continue";
            var tokenRatio = this_2.pool.ratios[i];
            var custodyAccount = this_2.custodies.find(function(t) {
                return t.mint.toBase58() === custodyConfig.mintKey.toBase58();
            });
            if (!custodyAccount) return "continue";
            var priceBnUi = new bignumber_js_1.default(pricesMap.get(custodyConfig.symbol).price.toUiPrice(8));
            var ownedBnUi = new bignumber_js_1.default(custodyAccount.assets.owned.toString()).dividedBy(Math.pow(10, custodyConfig.decimals));
            var ownedUsdBnUi = ownedBnUi.multipliedBy(priceBnUi);
            var lockedBnUi = new bignumber_js_1.default(custodyAccount.assets.locked.toString()).dividedBy(Math.pow(10, custodyConfig.decimals));
            var utilizationBnUi = custodyAccount.assets.locked.isZero() || custodyAccount.assets.owned.isZero() ? new bignumber_js_1.default(0) : lockedBnUi.dividedBy(ownedBnUi).multipliedBy(100);
            var currentRatioBnUi = totalPoolValueUsd.isZero() ? new bignumber_js_1.default(0) : ownedBnUi.multipliedBy(priceBnUi).dividedBy(totalPoolValueUsdUi).multipliedBy(100);
            var minRatioBnUi = tokenRatio.min.isZero() ? new bignumber_js_1.default(5) : new bignumber_js_1.default(tokenRatio.min.toString()).div(100);
            var maxRatioBnUi = tokenRatio.max.toString() === '10000' ? new bignumber_js_1.default(95) : new bignumber_js_1.default(tokenRatio.max.toString()).div(100);
            var availableToAddUsdBnUi = currentRatioBnUi.isGreaterThanOrEqualTo(maxRatioBnUi) ? new bignumber_js_1.default(0) : maxRatioBnUi.minus(currentRatioBnUi).multipliedBy(totalPoolValueUsdUi).div(100);
            var availableToAddAmountBnUi = availableToAddUsdBnUi.dividedBy(priceBnUi);
            var availableToRemoveUsdUi = minRatioBnUi.isGreaterThanOrEqualTo(currentRatioBnUi) ? new bignumber_js_1.default(0) : currentRatioBnUi.minus(minRatioBnUi).multipliedBy(totalPoolValueUsdUi).div(100);
            var availableToRemoveAmountBnUi = availableToRemoveUsdUi.dividedBy(priceBnUi);
            var minCapacityUsdBnUi = minRatioBnUi.multipliedBy(totalPoolValueUsdUi).div(100);
            var minCapacityAmountBnUi = minCapacityUsdBnUi.dividedBy(priceBnUi);
            var maxCapacityUsdBnUi = maxRatioBnUi.multipliedBy(totalPoolValueUsdUi).div(100);
            var maxCapacityAmountBnUi = maxCapacityUsdBnUi.dividedBy(priceBnUi);
            if (custodyAccount && tokenRatio) {
                custodyDetails.push({
                    symbol: custodyConfig.symbol,
                    priceUi: pricesMap.get(custodyConfig.symbol).price.toUiPrice(custodyConfig.usdPrecision),
                    minRatio: tokenRatio.min,
                    minRatioUi: (0, utils_1.nativeToUiDecimals)(tokenRatio.min, 2, 2),
                    maxRatio: tokenRatio.max,
                    maxRatioUi: (0, utils_1.nativeToUiDecimals)(tokenRatio.max, 2, 2),
                    targetRatio: tokenRatio.target,
                    targetRatioUi: (0, utils_1.nativeToUiDecimals)(tokenRatio.target, 2, 2),
                    currentRatio: (0, utils_1.uiDecimalsToNative)(currentRatioBnUi.toString(), 2),
                    currentRatioUi: currentRatioBnUi.toFixed(2, bignumber_js_1.default.ROUND_DOWN),
                    utilizationUi: utilizationBnUi.toFixed(2, bignumber_js_1.default.ROUND_DOWN),
                    lockedAmountUi: lockedBnUi.toFixed(4, bignumber_js_1.default.ROUND_DOWN),
                    assetsOwnedAmountUi: ownedBnUi.toFixed(4, bignumber_js_1.default.ROUND_DOWN),
                    totalUsdOwnedAmountUi: ownedUsdBnUi.toFixed(2, bignumber_js_1.default.ROUND_DOWN),
                    availableToAddAmountUi: availableToAddAmountBnUi.toFixed(4, bignumber_js_1.default.ROUND_DOWN),
                    availableToAddUsdUi: availableToAddUsdBnUi.toFixed(2, bignumber_js_1.default.ROUND_DOWN),
                    availableToRemoveAmountUi: availableToRemoveAmountBnUi.toFixed(4, bignumber_js_1.default.ROUND_DOWN),
                    availableToRemoveUsdUi: availableToRemoveUsdUi.toFixed(2, bignumber_js_1.default.ROUND_DOWN),
                    minCapacityAmountUi: minCapacityAmountBnUi.toFixed(custodyConfig.decimals),
                    maxCapacityAmountUi: maxCapacityAmountBnUi.toFixed(custodyConfig.decimals)
                });
            }
        };
        var this_2 = this;
        for(var i = 0; i < this.poolConfig.custodies.length; i++){
            _loop_2(i);
        }
        return custodyDetails;
    };
    return PoolDataClient;
}();
exports.PoolDataClient = PoolDataClient;
}}),
"[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.IDL = void 0;
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/PoolAccount.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/CustodyAccount.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/MarketAccount.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/PositionAccount.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/OrderAccount.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/TradingAccount.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/OraclePrice.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/constants/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/types/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/PerpetualsClient.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/PoolConfig.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/PoolDataClient.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/ViewHelper.js [app-route] (ecmascript)"), exports);
var perpetuals_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/idl/perpetuals.js [app-route] (ecmascript)");
Object.defineProperty(exports, "IDL", {
    enumerable: true,
    get: function() {
        return perpetuals_1.IDL;
    }
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/rpc.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/IdlCoder.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/anchorCpiEvents.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/utils/alt.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/backupOracle.js [app-route] (ecmascript)"), exports);
}}),

};

//# sourceMappingURL=99887_flash-sdk_dist_9455a7._.js.map
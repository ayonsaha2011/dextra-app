module.exports = {

"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/helpers.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// @ts-nocheck
// Inlined because of ESM import issues
/*!
 * https://github.com/Starcounter-Jack/JSON-Patch
 * (c) 2017-2022 Joachim Wester
 * MIT licensed
 */ __turbopack_esm__({
    "PatchError": (()=>PatchError),
    "_deepClone": (()=>_deepClone),
    "_getPathRecursive": (()=>_getPathRecursive),
    "_objectKeys": (()=>_objectKeys),
    "escapePathComponent": (()=>escapePathComponent),
    "getPath": (()=>getPath),
    "hasOwnProperty": (()=>hasOwnProperty),
    "hasUndefined": (()=>hasUndefined),
    "isInteger": (()=>isInteger),
    "unescapePathComponent": (()=>unescapePathComponent)
});
const _hasOwnProperty = Object.prototype.hasOwnProperty;
function hasOwnProperty(obj, key) {
    return _hasOwnProperty.call(obj, key);
}
function _objectKeys(obj) {
    if (Array.isArray(obj)) {
        const keys = new Array(obj.length);
        for(let k = 0; k < keys.length; k++){
            keys[k] = "" + k;
        }
        return keys;
    }
    if (Object.keys) {
        return Object.keys(obj);
    }
    let keys = [];
    for(let i in obj){
        if (hasOwnProperty(obj, i)) {
            keys.push(i);
        }
    }
    return keys;
}
function _deepClone(obj) {
    switch(typeof obj){
        case "object":
            return JSON.parse(JSON.stringify(obj)); //Faster than ES5 clone - http://jsperf.com/deep-cloning-of-objects/5
        case "undefined":
            return null; //this is how JSON.stringify behaves for array items
        default:
            return obj; //no need to clone primitives
    }
}
function isInteger(str) {
    let i = 0;
    const len = str.length;
    let charCode;
    while(i < len){
        charCode = str.charCodeAt(i);
        if (charCode >= 48 && charCode <= 57) {
            i++;
            continue;
        }
        return false;
    }
    return true;
}
function escapePathComponent(path) {
    if (path.indexOf("/") === -1 && path.indexOf("~") === -1) return path;
    return path.replace(/~/g, "~0").replace(/\//g, "~1");
}
function unescapePathComponent(path) {
    return path.replace(/~1/g, "/").replace(/~0/g, "~");
}
function _getPathRecursive(root, obj) {
    let found;
    for(let key in root){
        if (hasOwnProperty(root, key)) {
            if (root[key] === obj) {
                return escapePathComponent(key) + "/";
            } else if (typeof root[key] === "object") {
                found = _getPathRecursive(root[key], obj);
                if (found != "") {
                    return escapePathComponent(key) + "/" + found;
                }
            }
        }
    }
    return "";
}
function getPath(root, obj) {
    if (root === obj) {
        return "/";
    }
    const path = _getPathRecursive(root, obj);
    if (path === "") {
        throw new Error("Object not found in root");
    }
    return `/${path}`;
}
function hasUndefined(obj) {
    if (obj === undefined) {
        return true;
    }
    if (obj) {
        if (Array.isArray(obj)) {
            for(let i = 0, len = obj.length; i < len; i++){
                if (hasUndefined(obj[i])) {
                    return true;
                }
            }
        } else if (typeof obj === "object") {
            const objKeys = _objectKeys(obj);
            const objKeysLength = objKeys.length;
            for(var i = 0; i < objKeysLength; i++){
                if (hasUndefined(obj[objKeys[i]])) {
                    return true;
                }
            }
        }
    }
    return false;
}
function patchErrorMessageFormatter(message, args) {
    const messageParts = [
        message
    ];
    for(const key in args){
        const value = typeof args[key] === "object" ? JSON.stringify(args[key], null, 2) : args[key]; // pretty print
        if (typeof value !== "undefined") {
            messageParts.push(`${key}: ${value}`);
        }
    }
    return messageParts.join("\n");
}
class PatchError extends Error {
    constructor(message, name, index, operation, tree){
        super(patchErrorMessageFormatter(message, {
            name,
            index,
            operation,
            tree
        }));
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: name
        });
        Object.defineProperty(this, "index", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: index
        });
        Object.defineProperty(this, "operation", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: operation
        });
        Object.defineProperty(this, "tree", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: tree
        });
        Object.setPrototypeOf(this, new.target.prototype); // restore prototype chain, see https://stackoverflow.com/a/48342359
        this.message = patchErrorMessageFormatter(message, {
            name,
            index,
            operation,
            tree
        });
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/core.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// @ts-nocheck
__turbopack_esm__({
    "JsonPatchError": (()=>JsonPatchError),
    "_areEquals": (()=>_areEquals),
    "applyOperation": (()=>applyOperation),
    "applyPatch": (()=>applyPatch),
    "applyReducer": (()=>applyReducer),
    "deepClone": (()=>deepClone),
    "getValueByPointer": (()=>getValueByPointer),
    "validate": (()=>validate),
    "validator": (()=>validator)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/helpers.js [app-route] (ecmascript)");
;
const JsonPatchError = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PatchError"];
const deepClone = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_deepClone"];
/* We use a Javascript hash to store each
 function. Each hash entry (property) uses
 the operation identifiers specified in rfc6902.
 In this way, we can map each patch operation
 to its dedicated function in efficient way.
 */ /* The operations applicable to an object */ const objOps = {
    add: function(obj, key, document) {
        obj[key] = this.value;
        return {
            newDocument: document
        };
    },
    remove: function(obj, key, document) {
        var removed = obj[key];
        delete obj[key];
        return {
            newDocument: document,
            removed
        };
    },
    replace: function(obj, key, document) {
        var removed = obj[key];
        obj[key] = this.value;
        return {
            newDocument: document,
            removed
        };
    },
    move: function(obj, key, document) {
        /* in case move target overwrites an existing value,
        return the removed value, this can be taxing performance-wise,
        and is potentially unneeded */ let removed = getValueByPointer(document, this.path);
        if (removed) {
            removed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_deepClone"])(removed);
        }
        const originalValue = applyOperation(document, {
            op: "remove",
            path: this.from
        }).removed;
        applyOperation(document, {
            op: "add",
            path: this.path,
            value: originalValue
        });
        return {
            newDocument: document,
            removed
        };
    },
    copy: function(obj, key, document) {
        const valueToCopy = getValueByPointer(document, this.from);
        // enforce copy by value so further operations don't affect source (see issue #177)
        applyOperation(document, {
            op: "add",
            path: this.path,
            value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_deepClone"])(valueToCopy)
        });
        return {
            newDocument: document
        };
    },
    test: function(obj, key, document) {
        return {
            newDocument: document,
            test: _areEquals(obj[key], this.value)
        };
    },
    _get: function(obj, key, document) {
        this.value = obj[key];
        return {
            newDocument: document
        };
    }
};
/* The operations applicable to an array. Many are the same as for the object */ var arrOps = {
    add: function(arr, i, document) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isInteger"])(i)) {
            arr.splice(i, 0, this.value);
        } else {
            // array props
            arr[i] = this.value;
        }
        // this may be needed when using '-' in an array
        return {
            newDocument: document,
            index: i
        };
    },
    remove: function(arr, i, document) {
        var removedList = arr.splice(i, 1);
        return {
            newDocument: document,
            removed: removedList[0]
        };
    },
    replace: function(arr, i, document) {
        var removed = arr[i];
        arr[i] = this.value;
        return {
            newDocument: document,
            removed
        };
    },
    move: objOps.move,
    copy: objOps.copy,
    test: objOps.test,
    _get: objOps._get
};
function getValueByPointer(document, pointer) {
    if (pointer == "") {
        return document;
    }
    var getOriginalDestination = {
        op: "_get",
        path: pointer
    };
    applyOperation(document, getOriginalDestination);
    return getOriginalDestination.value;
}
function applyOperation(document, operation, validateOperation = false, mutateDocument = true, banPrototypeModifications = true, index = 0) {
    if (validateOperation) {
        if (typeof validateOperation == "function") {
            validateOperation(operation, 0, document, operation.path);
        } else {
            validator(operation, 0);
        }
    }
    /* ROOT OPERATIONS */ if (operation.path === "") {
        let returnValue = {
            newDocument: document
        };
        if (operation.op === "add") {
            returnValue.newDocument = operation.value;
            return returnValue;
        } else if (operation.op === "replace") {
            returnValue.newDocument = operation.value;
            returnValue.removed = document; //document we removed
            return returnValue;
        } else if (operation.op === "move" || operation.op === "copy") {
            // it's a move or copy to root
            returnValue.newDocument = getValueByPointer(document, operation.from); // get the value by json-pointer in `from` field
            if (operation.op === "move") {
                // report removed item
                returnValue.removed = document;
            }
            return returnValue;
        } else if (operation.op === "test") {
            returnValue.test = _areEquals(document, operation.value);
            if (returnValue.test === false) {
                throw new JsonPatchError("Test operation failed", "TEST_OPERATION_FAILED", index, operation, document);
            }
            returnValue.newDocument = document;
            return returnValue;
        } else if (operation.op === "remove") {
            // a remove on root
            returnValue.removed = document;
            returnValue.newDocument = null;
            return returnValue;
        } else if (operation.op === "_get") {
            operation.value = document;
            return returnValue;
        } else {
            /* bad operation */ if (validateOperation) {
                throw new JsonPatchError("Operation `op` property is not one of operations defined in RFC-6902", "OPERATION_OP_INVALID", index, operation, document);
            } else {
                return returnValue;
            }
        }
    } else {
        if (!mutateDocument) {
            document = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_deepClone"])(document);
        }
        const path = operation.path || "";
        const keys = path.split("/");
        let obj = document;
        let t = 1; //skip empty element - http://jsperf.com/to-shift-or-not-to-shift
        let len = keys.length;
        let existingPathFragment = undefined;
        let key;
        let validateFunction;
        if (typeof validateOperation == "function") {
            validateFunction = validateOperation;
        } else {
            validateFunction = validator;
        }
        while(true){
            key = keys[t];
            if (key && key.indexOf("~") != -1) {
                key = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["unescapePathComponent"])(key);
            }
            if (banPrototypeModifications && (key == "__proto__" || key == "prototype" && t > 0 && keys[t - 1] == "constructor")) {
                throw new TypeError("JSON-Patch: modifying `__proto__` or `constructor/prototype` prop is banned for security reasons, if this was on purpose, please set `banPrototypeModifications` flag false and pass it to this function. More info in fast-json-patch README");
            }
            if (validateOperation) {
                if (existingPathFragment === undefined) {
                    if (obj[key] === undefined) {
                        existingPathFragment = keys.slice(0, t).join("/");
                    } else if (t == len - 1) {
                        existingPathFragment = operation.path;
                    }
                    if (existingPathFragment !== undefined) {
                        validateFunction(operation, 0, document, existingPathFragment);
                    }
                }
            }
            t++;
            if (Array.isArray(obj)) {
                if (key === "-") {
                    key = obj.length;
                } else {
                    if (validateOperation && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isInteger"])(key)) {
                        throw new JsonPatchError("Expected an unsigned base-10 integer value, making the new referenced value the array element with the zero-based index", "OPERATION_PATH_ILLEGAL_ARRAY_INDEX", index, operation, document);
                    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isInteger"])(key)) {
                        key = ~~key;
                    }
                }
                if (t >= len) {
                    if (validateOperation && operation.op === "add" && key > obj.length) {
                        throw new JsonPatchError("The specified index MUST NOT be greater than the number of elements in the array", "OPERATION_VALUE_OUT_OF_BOUNDS", index, operation, document);
                    }
                    const returnValue = arrOps[operation.op].call(operation, obj, key, document); // Apply patch
                    if (returnValue.test === false) {
                        throw new JsonPatchError("Test operation failed", "TEST_OPERATION_FAILED", index, operation, document);
                    }
                    return returnValue;
                }
            } else {
                if (t >= len) {
                    const returnValue = objOps[operation.op].call(operation, obj, key, document); // Apply patch
                    if (returnValue.test === false) {
                        throw new JsonPatchError("Test operation failed", "TEST_OPERATION_FAILED", index, operation, document);
                    }
                    return returnValue;
                }
            }
            obj = obj[key];
            // If we have more keys in the path, but the next value isn't a non-null object,
            // throw an OPERATION_PATH_UNRESOLVABLE error instead of iterating again.
            if (validateOperation && t < len && (!obj || typeof obj !== "object")) {
                throw new JsonPatchError("Cannot perform operation at the desired path", "OPERATION_PATH_UNRESOLVABLE", index, operation, document);
            }
        }
    }
}
function applyPatch(document, patch, validateOperation, mutateDocument = true, banPrototypeModifications = true) {
    if (validateOperation) {
        if (!Array.isArray(patch)) {
            throw new JsonPatchError("Patch sequence must be an array", "SEQUENCE_NOT_AN_ARRAY");
        }
    }
    if (!mutateDocument) {
        document = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_deepClone"])(document);
    }
    const results = new Array(patch.length);
    for(let i = 0, length = patch.length; i < length; i++){
        // we don't need to pass mutateDocument argument because if it was true, we already deep cloned the object, we'll just pass `true`
        results[i] = applyOperation(document, patch[i], validateOperation, true, banPrototypeModifications, i);
        document = results[i].newDocument; // in case root was replaced
    }
    results.newDocument = document;
    return results;
}
function applyReducer(document, operation, index) {
    const operationResult = applyOperation(document, operation);
    if (operationResult.test === false) {
        // failed test
        throw new JsonPatchError("Test operation failed", "TEST_OPERATION_FAILED", index, operation, document);
    }
    return operationResult.newDocument;
}
function validator(operation, index, document, existingPathFragment) {
    if (typeof operation !== "object" || operation === null || Array.isArray(operation)) {
        throw new JsonPatchError("Operation is not an object", "OPERATION_NOT_AN_OBJECT", index, operation, document);
    } else if (!objOps[operation.op]) {
        throw new JsonPatchError("Operation `op` property is not one of operations defined in RFC-6902", "OPERATION_OP_INVALID", index, operation, document);
    } else if (typeof operation.path !== "string") {
        throw new JsonPatchError("Operation `path` property is not a string", "OPERATION_PATH_INVALID", index, operation, document);
    } else if (operation.path.indexOf("/") !== 0 && operation.path.length > 0) {
        // paths that aren't empty string should start with "/"
        throw new JsonPatchError('Operation `path` property must start with "/"', "OPERATION_PATH_INVALID", index, operation, document);
    } else if ((operation.op === "move" || operation.op === "copy") && typeof operation.from !== "string") {
        throw new JsonPatchError("Operation `from` property is not present (applicable in `move` and `copy` operations)", "OPERATION_FROM_REQUIRED", index, operation, document);
    } else if ((operation.op === "add" || operation.op === "replace" || operation.op === "test") && operation.value === undefined) {
        throw new JsonPatchError("Operation `value` property is not present (applicable in `add`, `replace` and `test` operations)", "OPERATION_VALUE_REQUIRED", index, operation, document);
    } else if ((operation.op === "add" || operation.op === "replace" || operation.op === "test") && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["hasUndefined"])(operation.value)) {
        throw new JsonPatchError("Operation `value` property is not present (applicable in `add`, `replace` and `test` operations)", "OPERATION_VALUE_CANNOT_CONTAIN_UNDEFINED", index, operation, document);
    } else if (document) {
        if (operation.op == "add") {
            var pathLen = operation.path.split("/").length;
            var existingPathLen = existingPathFragment.split("/").length;
            if (pathLen !== existingPathLen + 1 && pathLen !== existingPathLen) {
                throw new JsonPatchError("Cannot perform an `add` operation at the desired path", "OPERATION_PATH_CANNOT_ADD", index, operation, document);
            }
        } else if (operation.op === "replace" || operation.op === "remove" || operation.op === "_get") {
            if (operation.path !== existingPathFragment) {
                throw new JsonPatchError("Cannot perform the operation at a path that does not exist", "OPERATION_PATH_UNRESOLVABLE", index, operation, document);
            }
        } else if (operation.op === "move" || operation.op === "copy") {
            var existingValue = {
                op: "_get",
                path: operation.from,
                value: undefined
            };
            var error = validate([
                existingValue
            ], document);
            if (error && error.name === "OPERATION_PATH_UNRESOLVABLE") {
                throw new JsonPatchError("Cannot perform the operation from a path that does not exist", "OPERATION_FROM_UNRESOLVABLE", index, operation, document);
            }
        }
    }
}
function validate(sequence, document, externalValidator) {
    try {
        if (!Array.isArray(sequence)) {
            throw new JsonPatchError("Patch sequence must be an array", "SEQUENCE_NOT_AN_ARRAY");
        }
        if (document) {
            //clone document and sequence so that we can safely try applying operations
            applyPatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_deepClone"])(document), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_deepClone"])(sequence), externalValidator || true);
        } else {
            externalValidator = externalValidator || validator;
            for(var i = 0; i < sequence.length; i++){
                externalValidator(sequence[i], i, document, undefined);
            }
        }
    } catch (e) {
        if (e instanceof JsonPatchError) {
            return e;
        } else {
            throw e;
        }
    }
}
function _areEquals(a, b) {
    if (a === b) return true;
    if (a && b && typeof a == "object" && typeof b == "object") {
        var arrA = Array.isArray(a), arrB = Array.isArray(b), i, length, key;
        if (arrA && arrB) {
            length = a.length;
            if (length != b.length) return false;
            for(i = length; i-- !== 0;)if (!_areEquals(a[i], b[i])) return false;
            return true;
        }
        if (arrA != arrB) return false;
        var keys = Object.keys(a);
        length = keys.length;
        if (length !== Object.keys(b).length) return false;
        for(i = length; i-- !== 0;)if (!b.hasOwnProperty(keys[i])) return false;
        for(i = length; i-- !== 0;){
            key = keys[i];
            if (!_areEquals(a[key], b[key])) return false;
        }
        return true;
    }
    return a !== a && b !== b;
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/duplex.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// @ts-nocheck
// Inlined because of ESM import issues
/*!
 * https://github.com/Starcounter-Jack/JSON-Patch
 * (c) 2013-2021 Joachim Wester
 * MIT license
 */ __turbopack_esm__({
    "compare": (()=>compare),
    "generate": (()=>generate),
    "observe": (()=>observe),
    "unobserve": (()=>unobserve)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/helpers.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$core$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/core.js [app-route] (ecmascript)");
;
;
var beforeDict = new WeakMap();
class Mirror {
    constructor(obj){
        Object.defineProperty(this, "obj", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "observers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        Object.defineProperty(this, "value", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.obj = obj;
    }
}
class ObserverInfo {
    constructor(callback, observer){
        Object.defineProperty(this, "callback", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "observer", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.callback = callback;
        this.observer = observer;
    }
}
function getMirror(obj) {
    return beforeDict.get(obj);
}
function getObserverFromMirror(mirror, callback) {
    return mirror.observers.get(callback);
}
function removeObserverFromMirror(mirror, observer) {
    mirror.observers.delete(observer.callback);
}
function unobserve(root, observer) {
    observer.unobserve();
}
function observe(obj, callback) {
    var patches = [];
    var observer;
    var mirror = getMirror(obj);
    if (!mirror) {
        mirror = new Mirror(obj);
        beforeDict.set(obj, mirror);
    } else {
        const observerInfo = getObserverFromMirror(mirror, callback);
        observer = observerInfo && observerInfo.observer;
    }
    if (observer) {
        return observer;
    }
    observer = {};
    mirror.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_deepClone"])(obj);
    if (callback) {
        observer.callback = callback;
        observer.next = null;
        var dirtyCheck = ()=>{
            generate(observer);
        };
        var fastCheck = ()=>{
            clearTimeout(observer.next);
            observer.next = setTimeout(dirtyCheck);
        };
        if ("TURBOPACK compile-time falsy", 0) {
            "TURBOPACK unreachable";
        }
    }
    observer.patches = patches;
    observer.object = obj;
    observer.unobserve = ()=>{
        generate(observer);
        clearTimeout(observer.next);
        removeObserverFromMirror(mirror, observer);
        if ("TURBOPACK compile-time falsy", 0) {
            "TURBOPACK unreachable";
        }
    };
    mirror.observers.set(callback, new ObserverInfo(callback, observer));
    return observer;
}
function generate(observer, invertible = false) {
    var mirror = beforeDict.get(observer.object);
    _generate(mirror.value, observer.object, observer.patches, "", invertible);
    if (observer.patches.length) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$core$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["applyPatch"])(mirror.value, observer.patches);
    }
    var temp = observer.patches;
    if (temp.length > 0) {
        observer.patches = [];
        if (observer.callback) {
            observer.callback(temp);
        }
    }
    return temp;
}
// Dirty check if obj is different from mirror, generate patches and update mirror
function _generate(mirror, obj, patches, path, invertible) {
    if (obj === mirror) {
        return;
    }
    if (typeof obj.toJSON === "function") {
        obj = obj.toJSON();
    }
    var newKeys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_objectKeys"])(obj);
    var oldKeys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_objectKeys"])(mirror);
    var changed = false;
    var deleted = false;
    //if ever "move" operation is implemented here, make sure this test runs OK: "should not generate the same patch twice (move)"
    for(var t = oldKeys.length - 1; t >= 0; t--){
        var key = oldKeys[t];
        var oldVal = mirror[key];
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["hasOwnProperty"])(obj, key) && !(obj[key] === undefined && oldVal !== undefined && Array.isArray(obj) === false)) {
            var newVal = obj[key];
            if (typeof oldVal == "object" && oldVal != null && typeof newVal == "object" && newVal != null && Array.isArray(oldVal) === Array.isArray(newVal)) {
                _generate(oldVal, newVal, patches, path + "/" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["escapePathComponent"])(key), invertible);
            } else {
                if (oldVal !== newVal) {
                    changed = true;
                    if (invertible) {
                        patches.push({
                            op: "test",
                            path: path + "/" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["escapePathComponent"])(key),
                            value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_deepClone"])(oldVal)
                        });
                    }
                    patches.push({
                        op: "replace",
                        path: path + "/" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["escapePathComponent"])(key),
                        value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_deepClone"])(newVal)
                    });
                }
            }
        } else if (Array.isArray(mirror) === Array.isArray(obj)) {
            if (invertible) {
                patches.push({
                    op: "test",
                    path: path + "/" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["escapePathComponent"])(key),
                    value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_deepClone"])(oldVal)
                });
            }
            patches.push({
                op: "remove",
                path: path + "/" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["escapePathComponent"])(key)
            });
            deleted = true; // property has been deleted
        } else {
            if (invertible) {
                patches.push({
                    op: "test",
                    path,
                    value: mirror
                });
            }
            patches.push({
                op: "replace",
                path,
                value: obj
            });
            changed = true;
        }
    }
    if (!deleted && newKeys.length == oldKeys.length) {
        return;
    }
    for(var t = 0; t < newKeys.length; t++){
        var key = newKeys[t];
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["hasOwnProperty"])(mirror, key) && obj[key] !== undefined) {
            patches.push({
                op: "add",
                path: path + "/" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["escapePathComponent"])(key),
                value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_deepClone"])(obj[key])
            });
        }
    }
}
function compare(tree1, tree2, invertible = false) {
    var patches = [];
    _generate(tree1, tree2, patches, "", invertible);
    return patches;
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/index.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
/**
 * Default export for backwards compat
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$core$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/core.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/helpers.js [app-route] (ecmascript)");
;
;
;
;
;
const __TURBOPACK__default__export__ = {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$core$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__,
    // ...duplex,
    JsonPatchError: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PatchError"],
    deepClone: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_deepClone"],
    escapePathComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["escapePathComponent"],
    unescapePathComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["unescapePathComponent"]
};
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/index.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$core$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/core.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$duplex$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/duplex.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$helpers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/helpers.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/index.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/load/map_keys.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "keyFromJson": (()=>keyFromJson),
    "keyToJson": (()=>keyToJson),
    "mapKeys": (()=>mapKeys)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$decamelize$40$1$2e$2$2e$0$2f$node_modules$2f$decamelize$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/decamelize@1.2.0/node_modules/decamelize/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$camelcase$40$6$2e$3$2e$0$2f$node_modules$2f$camelcase$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/camelcase@6.3.0/node_modules/camelcase/index.js [app-route] (ecmascript)");
;
;
function keyToJson(key, map) {
    return map?.[key] || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$decamelize$40$1$2e$2$2e$0$2f$node_modules$2f$decamelize$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])(key);
}
function keyFromJson(key, map) {
    return map?.[key] || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$camelcase$40$6$2e$3$2e$0$2f$node_modules$2f$camelcase$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])(key);
}
function mapKeys(fields, mapper, map) {
    const mapped = {};
    for(const key in fields){
        if (Object.hasOwn(fields, key)) {
            mapped[mapper(key, map)] = fields[key];
        }
    }
    return mapped;
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/load/serializable.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Serializable": (()=>Serializable),
    "get_lc_unique_name": (()=>get_lc_unique_name)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$load$2f$map_keys$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/load/map_keys.js [app-route] (ecmascript)");
;
function shallowCopy(obj) {
    return Array.isArray(obj) ? [
        ...obj
    ] : {
        ...obj
    };
}
function replaceSecrets(root, secretsMap) {
    const result = shallowCopy(root);
    for (const [path, secretId] of Object.entries(secretsMap)){
        const [last, ...partsReverse] = path.split(".").reverse();
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let current = result;
        for (const part of partsReverse.reverse()){
            if (current[part] === undefined) {
                break;
            }
            current[part] = shallowCopy(current[part]);
            current = current[part];
        }
        if (current[last] !== undefined) {
            current[last] = {
                lc: 1,
                type: "secret",
                id: [
                    secretId
                ]
            };
        }
    }
    return result;
}
function get_lc_unique_name(// eslint-disable-next-line @typescript-eslint/no-use-before-define
serializableClass) {
    // "super" here would refer to the parent class of Serializable,
    // when we want the parent class of the module actually calling this method.
    const parentClass = Object.getPrototypeOf(serializableClass);
    const lcNameIsSubclassed = typeof serializableClass.lc_name === "function" && (typeof parentClass.lc_name !== "function" || serializableClass.lc_name() !== parentClass.lc_name());
    if (lcNameIsSubclassed) {
        return serializableClass.lc_name();
    } else {
        return serializableClass.name;
    }
}
class Serializable {
    /**
     * The name of the serializable. Override to provide an alias or
     * to preserve the serialized module name in minified environments.
     *
     * Implemented as a static method to support loading logic.
     */ static lc_name() {
        return this.name;
    }
    /**
     * The final serialized identifier for the module.
     */ get lc_id() {
        return [
            ...this.lc_namespace,
            get_lc_unique_name(this.constructor)
        ];
    }
    /**
     * A map of secrets, which will be omitted from serialization.
     * Keys are paths to the secret in constructor args, e.g. "foo.bar.baz".
     * Values are the secret ids, which will be used when deserializing.
     */ get lc_secrets() {
        return undefined;
    }
    /**
     * A map of additional attributes to merge with constructor args.
     * Keys are the attribute names, e.g. "foo".
     * Values are the attribute values, which will be serialized.
     * These attributes need to be accepted by the constructor as arguments.
     */ get lc_attributes() {
        return undefined;
    }
    /**
     * A map of aliases for constructor args.
     * Keys are the attribute names, e.g. "foo".
     * Values are the alias that will replace the key in serialization.
     * This is used to eg. make argument names match Python.
     */ get lc_aliases() {
        return undefined;
    }
    constructor(kwargs, ..._args){
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "lc_kwargs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.lc_kwargs = kwargs || {};
    }
    toJSON() {
        if (!this.lc_serializable) {
            return this.toJSONNotImplemented();
        }
        if (// eslint-disable-next-line no-instanceof/no-instanceof
        this.lc_kwargs instanceof Serializable || typeof this.lc_kwargs !== "object" || Array.isArray(this.lc_kwargs)) {
            // We do not support serialization of classes with arg not a POJO
            // I'm aware the check above isn't as strict as it could be
            return this.toJSONNotImplemented();
        }
        const aliases = {};
        const secrets = {};
        const kwargs = Object.keys(this.lc_kwargs).reduce((acc, key)=>{
            acc[key] = key in this ? this[key] : this.lc_kwargs[key];
            return acc;
        }, {});
        // get secrets, attributes and aliases from all superclasses
        for(// eslint-disable-next-line @typescript-eslint/no-this-alias
        let current = Object.getPrototypeOf(this); current; current = Object.getPrototypeOf(current)){
            Object.assign(aliases, Reflect.get(current, "lc_aliases", this));
            Object.assign(secrets, Reflect.get(current, "lc_secrets", this));
            Object.assign(kwargs, Reflect.get(current, "lc_attributes", this));
        }
        // include all secrets used, even if not in kwargs,
        // will be replaced with sentinel value in replaceSecrets
        Object.keys(secrets).forEach((keyPath)=>{
            // eslint-disable-next-line @typescript-eslint/no-this-alias, @typescript-eslint/no-explicit-any
            let read = this;
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            let write = kwargs;
            const [last, ...partsReverse] = keyPath.split(".").reverse();
            for (const key of partsReverse.reverse()){
                if (!(key in read) || read[key] === undefined) return;
                if (!(key in write) || write[key] === undefined) {
                    if (typeof read[key] === "object" && read[key] != null) {
                        write[key] = {};
                    } else if (Array.isArray(read[key])) {
                        write[key] = [];
                    }
                }
                read = read[key];
                write = write[key];
            }
            if (last in read && read[last] !== undefined) {
                write[last] = write[last] || read[last];
            }
        });
        return {
            lc: 1,
            type: "constructor",
            id: this.lc_id,
            kwargs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$load$2f$map_keys$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mapKeys"])(Object.keys(secrets).length ? replaceSecrets(kwargs, secrets) : kwargs, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$load$2f$map_keys$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["keyToJson"], aliases)
        };
    }
    toJSONNotImplemented() {
        return {
            lc: 1,
            type: "not_implemented",
            id: this.lc_id
        };
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/env.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "getEnv": (()=>getEnv),
    "getEnvironmentVariable": (()=>getEnvironmentVariable),
    "getRuntimeEnvironment": (()=>getRuntimeEnvironment),
    "isBrowser": (()=>isBrowser),
    "isDeno": (()=>isDeno),
    "isJsDom": (()=>isJsDom),
    "isNode": (()=>isNode),
    "isWebWorker": (()=>isWebWorker)
});
const isBrowser = ()=>"undefined" !== "undefined" && typeof window.document !== "undefined";
const isWebWorker = ()=>typeof globalThis === "object" && globalThis.constructor && globalThis.constructor.name === "DedicatedWorkerGlobalScope";
const isJsDom = ()=>"undefined" !== "undefined" && window.name === "nodejs" || typeof navigator !== "undefined" && (navigator.userAgent.includes("Node.js") || navigator.userAgent.includes("jsdom"));
const isDeno = ()=>typeof Deno !== "undefined";
const isNode = ()=>typeof process !== "undefined" && typeof process.versions !== "undefined" && typeof process.versions.node !== "undefined" && !isDeno();
const getEnv = ()=>{
    let env;
    if (isBrowser()) {
        env = "browser";
    } else if (isNode()) {
        env = "node";
    } else if (isWebWorker()) {
        env = "webworker";
    } else if (isJsDom()) {
        env = "jsdom";
    } else if (isDeno()) {
        env = "deno";
    } else {
        env = "other";
    }
    return env;
};
let runtimeEnvironment;
async function getRuntimeEnvironment() {
    if (runtimeEnvironment === undefined) {
        const env = getEnv();
        runtimeEnvironment = {
            library: "langchain-js",
            runtime: env
        };
    }
    return runtimeEnvironment;
}
function getEnvironmentVariable(name) {
    // Certain Deno setups will throw an error if you try to access environment variables
    // https://github.com/langchain-ai/langchainjs/issues/1412
    try {
        if (typeof process !== "undefined") {
            // eslint-disable-next-line no-process-env
            return process.env?.[name];
        } else if (isDeno()) {
            return Deno?.env.get(name);
        } else {
            return undefined;
        }
    } catch (e) {
        return undefined;
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/callbacks/base.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "BaseCallbackHandler": (()=>BaseCallbackHandler),
    "callbackHandlerPrefersStreaming": (()=>callbackHandlerPrefersStreaming),
    "isBaseCallbackHandler": (()=>isBaseCallbackHandler)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$load$2f$serializable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/load/serializable.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/env.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/uuid@10.0.0/node_modules/uuid/dist/esm-node/index.js [app-route] (ecmascript)");
;
;
;
/**
 * Abstract class that provides a set of optional methods that can be
 * overridden in derived classes to handle various events during the
 * execution of a LangChain application.
 */ class BaseCallbackHandlerMethodsClass {
}
function callbackHandlerPrefersStreaming(x) {
    return "lc_prefer_streaming" in x && x.lc_prefer_streaming;
}
class BaseCallbackHandler extends BaseCallbackHandlerMethodsClass {
    get lc_namespace() {
        return [
            "langchain_core",
            "callbacks",
            this.name
        ];
    }
    get lc_secrets() {
        return undefined;
    }
    get lc_attributes() {
        return undefined;
    }
    get lc_aliases() {
        return undefined;
    }
    /**
     * The name of the serializable. Override to provide an alias or
     * to preserve the serialized module name in minified environments.
     *
     * Implemented as a static method to support loading logic.
     */ static lc_name() {
        return this.name;
    }
    /**
     * The final serialized identifier for the module.
     */ get lc_id() {
        return [
            ...this.lc_namespace,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$load$2f$serializable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["get_lc_unique_name"])(this.constructor)
        ];
    }
    constructor(input){
        super();
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "lc_kwargs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "ignoreLLM", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "ignoreChain", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "ignoreAgent", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "ignoreRetriever", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "ignoreCustomEvent", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "raiseError", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "awaitHandlers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getEnvironmentVariable"])("LANGCHAIN_CALLBACKS_BACKGROUND") === "false"
        });
        this.lc_kwargs = input || {};
        if (input) {
            this.ignoreLLM = input.ignoreLLM ?? this.ignoreLLM;
            this.ignoreChain = input.ignoreChain ?? this.ignoreChain;
            this.ignoreAgent = input.ignoreAgent ?? this.ignoreAgent;
            this.ignoreRetriever = input.ignoreRetriever ?? this.ignoreRetriever;
            this.ignoreCustomEvent = input.ignoreCustomEvent ?? this.ignoreCustomEvent;
            this.raiseError = input.raiseError ?? this.raiseError;
            this.awaitHandlers = this.raiseError || (input._awaitHandler ?? this.awaitHandlers);
        }
    }
    copy() {
        return new this.constructor(this);
    }
    toJSON() {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$load$2f$serializable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Serializable"].prototype.toJSON.call(this);
    }
    toJSONNotImplemented() {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$load$2f$serializable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Serializable"].prototype.toJSONNotImplemented.call(this);
    }
    static fromMethods(methods) {
        class Handler extends BaseCallbackHandler {
            constructor(){
                super();
                Object.defineProperty(this, "name", {
                    enumerable: true,
                    configurable: true,
                    writable: true,
                    value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__.v4()
                });
                Object.assign(this, methods);
            }
        }
        return new Handler();
    }
}
const isBaseCallbackHandler = (x)=>{
    const callbackHandler = x;
    return callbackHandler !== undefined && typeof callbackHandler.copy === "function" && typeof callbackHandler.name === "string" && typeof callbackHandler.awaitHandlers === "boolean";
};
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/base.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "BaseTracer": (()=>BaseTracer),
    "isBaseTracer": (()=>isBaseTracer)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/callbacks/base.js [app-route] (ecmascript)");
;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function _coerceToDict(value, defaultKey) {
    return value && !Array.isArray(value) && typeof value === "object" ? value : {
        [defaultKey]: value
    };
}
function stripNonAlphanumeric(input) {
    return input.replace(/[-:.]/g, "");
}
function convertToDottedOrderFormat(epoch, runId, executionOrder) {
    const paddedOrder = executionOrder.toFixed(0).slice(0, 3).padStart(3, "0");
    return stripNonAlphanumeric(`${new Date(epoch).toISOString().slice(0, -1)}${paddedOrder}Z`) + runId;
}
function isBaseTracer(x) {
    return typeof x._addRunToRunMap === "function";
}
class BaseTracer extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseCallbackHandler"] {
    constructor(_fields){
        super(...arguments);
        Object.defineProperty(this, "runMap", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
    }
    copy() {
        return this;
    }
    stringifyError(error) {
        // eslint-disable-next-line no-instanceof/no-instanceof
        if (error instanceof Error) {
            return error.message + (error?.stack ? `\n\n${error.stack}` : "");
        }
        if (typeof error === "string") {
            return error;
        }
        return `${error}`;
    }
    _addChildRun(parentRun, childRun) {
        parentRun.child_runs.push(childRun);
    }
    _addRunToRunMap(run) {
        const currentDottedOrder = convertToDottedOrderFormat(run.start_time, run.id, run.execution_order);
        const storedRun = {
            ...run
        };
        if (storedRun.parent_run_id !== undefined) {
            const parentRun = this.runMap.get(storedRun.parent_run_id);
            if (parentRun) {
                this._addChildRun(parentRun, storedRun);
                parentRun.child_execution_order = Math.max(parentRun.child_execution_order, storedRun.child_execution_order);
                storedRun.trace_id = parentRun.trace_id;
                if (parentRun.dotted_order !== undefined) {
                    storedRun.dotted_order = [
                        parentRun.dotted_order,
                        currentDottedOrder
                    ].join(".");
                } else {
                // This can happen naturally for callbacks added within a run
                // console.debug(`Parent run with UUID ${storedRun.parent_run_id} has no dotted order.`);
                }
            } else {
            // This can happen naturally for callbacks added within a run
            // console.debug(
            //   `Parent run with UUID ${storedRun.parent_run_id} not found.`
            // );
            }
        } else {
            storedRun.trace_id = storedRun.id;
            storedRun.dotted_order = currentDottedOrder;
        }
        this.runMap.set(storedRun.id, storedRun);
        return storedRun;
    }
    async _endTrace(run) {
        const parentRun = run.parent_run_id !== undefined && this.runMap.get(run.parent_run_id);
        if (parentRun) {
            parentRun.child_execution_order = Math.max(parentRun.child_execution_order, run.child_execution_order);
        } else {
            await this.persistRun(run);
        }
        this.runMap.delete(run.id);
        await this.onRunUpdate?.(run);
    }
    _getExecutionOrder(parentRunId) {
        const parentRun = parentRunId !== undefined && this.runMap.get(parentRunId);
        // If a run has no parent then execution order is 1
        if (!parentRun) {
            return 1;
        }
        return parentRun.child_execution_order + 1;
    }
    /**
     * Create and add a run to the run map for LLM start events.
     * This must sometimes be done synchronously to avoid race conditions
     * when callbacks are backgrounded, so we expose it as a separate method here.
     */ _createRunForLLMStart(llm, prompts, runId, parentRunId, extraParams, tags, metadata, name) {
        const execution_order = this._getExecutionOrder(parentRunId);
        const start_time = Date.now();
        const finalExtraParams = metadata ? {
            ...extraParams,
            metadata
        } : extraParams;
        const run = {
            id: runId,
            name: name ?? llm.id[llm.id.length - 1],
            parent_run_id: parentRunId,
            start_time,
            serialized: llm,
            events: [
                {
                    name: "start",
                    time: new Date(start_time).toISOString()
                }
            ],
            inputs: {
                prompts
            },
            execution_order,
            child_runs: [],
            child_execution_order: execution_order,
            run_type: "llm",
            extra: finalExtraParams ?? {},
            tags: tags || []
        };
        return this._addRunToRunMap(run);
    }
    async handleLLMStart(llm, prompts, runId, parentRunId, extraParams, tags, metadata, name) {
        const run = this.runMap.get(runId) ?? this._createRunForLLMStart(llm, prompts, runId, parentRunId, extraParams, tags, metadata, name);
        await this.onRunCreate?.(run);
        await this.onLLMStart?.(run);
        return run;
    }
    /**
     * Create and add a run to the run map for chat model start events.
     * This must sometimes be done synchronously to avoid race conditions
     * when callbacks are backgrounded, so we expose it as a separate method here.
     */ _createRunForChatModelStart(llm, messages, runId, parentRunId, extraParams, tags, metadata, name) {
        const execution_order = this._getExecutionOrder(parentRunId);
        const start_time = Date.now();
        const finalExtraParams = metadata ? {
            ...extraParams,
            metadata
        } : extraParams;
        const run = {
            id: runId,
            name: name ?? llm.id[llm.id.length - 1],
            parent_run_id: parentRunId,
            start_time,
            serialized: llm,
            events: [
                {
                    name: "start",
                    time: new Date(start_time).toISOString()
                }
            ],
            inputs: {
                messages
            },
            execution_order,
            child_runs: [],
            child_execution_order: execution_order,
            run_type: "llm",
            extra: finalExtraParams ?? {},
            tags: tags || []
        };
        return this._addRunToRunMap(run);
    }
    async handleChatModelStart(llm, messages, runId, parentRunId, extraParams, tags, metadata, name) {
        const run = this.runMap.get(runId) ?? this._createRunForChatModelStart(llm, messages, runId, parentRunId, extraParams, tags, metadata, name);
        await this.onRunCreate?.(run);
        await this.onLLMStart?.(run);
        return run;
    }
    async handleLLMEnd(output, runId) {
        const run = this.runMap.get(runId);
        if (!run || run?.run_type !== "llm") {
            throw new Error("No LLM run to end.");
        }
        run.end_time = Date.now();
        run.outputs = output;
        run.events.push({
            name: "end",
            time: new Date(run.end_time).toISOString()
        });
        await this.onLLMEnd?.(run);
        await this._endTrace(run);
        return run;
    }
    async handleLLMError(error, runId) {
        const run = this.runMap.get(runId);
        if (!run || run?.run_type !== "llm") {
            throw new Error("No LLM run to end.");
        }
        run.end_time = Date.now();
        run.error = this.stringifyError(error);
        run.events.push({
            name: "error",
            time: new Date(run.end_time).toISOString()
        });
        await this.onLLMError?.(run);
        await this._endTrace(run);
        return run;
    }
    /**
     * Create and add a run to the run map for chain start events.
     * This must sometimes be done synchronously to avoid race conditions
     * when callbacks are backgrounded, so we expose it as a separate method here.
     */ _createRunForChainStart(chain, inputs, runId, parentRunId, tags, metadata, runType, name) {
        const execution_order = this._getExecutionOrder(parentRunId);
        const start_time = Date.now();
        const run = {
            id: runId,
            name: name ?? chain.id[chain.id.length - 1],
            parent_run_id: parentRunId,
            start_time,
            serialized: chain,
            events: [
                {
                    name: "start",
                    time: new Date(start_time).toISOString()
                }
            ],
            inputs,
            execution_order,
            child_execution_order: execution_order,
            run_type: runType ?? "chain",
            child_runs: [],
            extra: metadata ? {
                metadata
            } : {},
            tags: tags || []
        };
        return this._addRunToRunMap(run);
    }
    async handleChainStart(chain, inputs, runId, parentRunId, tags, metadata, runType, name) {
        const run = this.runMap.get(runId) ?? this._createRunForChainStart(chain, inputs, runId, parentRunId, tags, metadata, runType, name);
        await this.onRunCreate?.(run);
        await this.onChainStart?.(run);
        return run;
    }
    async handleChainEnd(outputs, runId, _parentRunId, _tags, kwargs) {
        const run = this.runMap.get(runId);
        if (!run) {
            throw new Error("No chain run to end.");
        }
        run.end_time = Date.now();
        run.outputs = _coerceToDict(outputs, "output");
        run.events.push({
            name: "end",
            time: new Date(run.end_time).toISOString()
        });
        if (kwargs?.inputs !== undefined) {
            run.inputs = _coerceToDict(kwargs.inputs, "input");
        }
        await this.onChainEnd?.(run);
        await this._endTrace(run);
        return run;
    }
    async handleChainError(error, runId, _parentRunId, _tags, kwargs) {
        const run = this.runMap.get(runId);
        if (!run) {
            throw new Error("No chain run to end.");
        }
        run.end_time = Date.now();
        run.error = this.stringifyError(error);
        run.events.push({
            name: "error",
            time: new Date(run.end_time).toISOString()
        });
        if (kwargs?.inputs !== undefined) {
            run.inputs = _coerceToDict(kwargs.inputs, "input");
        }
        await this.onChainError?.(run);
        await this._endTrace(run);
        return run;
    }
    /**
     * Create and add a run to the run map for tool start events.
     * This must sometimes be done synchronously to avoid race conditions
     * when callbacks are backgrounded, so we expose it as a separate method here.
     */ _createRunForToolStart(tool, input, runId, parentRunId, tags, metadata, name) {
        const execution_order = this._getExecutionOrder(parentRunId);
        const start_time = Date.now();
        const run = {
            id: runId,
            name: name ?? tool.id[tool.id.length - 1],
            parent_run_id: parentRunId,
            start_time,
            serialized: tool,
            events: [
                {
                    name: "start",
                    time: new Date(start_time).toISOString()
                }
            ],
            inputs: {
                input
            },
            execution_order,
            child_execution_order: execution_order,
            run_type: "tool",
            child_runs: [],
            extra: metadata ? {
                metadata
            } : {},
            tags: tags || []
        };
        return this._addRunToRunMap(run);
    }
    async handleToolStart(tool, input, runId, parentRunId, tags, metadata, name) {
        const run = this.runMap.get(runId) ?? this._createRunForToolStart(tool, input, runId, parentRunId, tags, metadata, name);
        await this.onRunCreate?.(run);
        await this.onToolStart?.(run);
        return run;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async handleToolEnd(output, runId) {
        const run = this.runMap.get(runId);
        if (!run || run?.run_type !== "tool") {
            throw new Error("No tool run to end");
        }
        run.end_time = Date.now();
        run.outputs = {
            output
        };
        run.events.push({
            name: "end",
            time: new Date(run.end_time).toISOString()
        });
        await this.onToolEnd?.(run);
        await this._endTrace(run);
        return run;
    }
    async handleToolError(error, runId) {
        const run = this.runMap.get(runId);
        if (!run || run?.run_type !== "tool") {
            throw new Error("No tool run to end");
        }
        run.end_time = Date.now();
        run.error = this.stringifyError(error);
        run.events.push({
            name: "error",
            time: new Date(run.end_time).toISOString()
        });
        await this.onToolError?.(run);
        await this._endTrace(run);
        return run;
    }
    async handleAgentAction(action, runId) {
        const run = this.runMap.get(runId);
        if (!run || run?.run_type !== "chain") {
            return;
        }
        const agentRun = run;
        agentRun.actions = agentRun.actions || [];
        agentRun.actions.push(action);
        agentRun.events.push({
            name: "agent_action",
            time: new Date().toISOString(),
            kwargs: {
                action
            }
        });
        await this.onAgentAction?.(run);
    }
    async handleAgentEnd(action, runId) {
        const run = this.runMap.get(runId);
        if (!run || run?.run_type !== "chain") {
            return;
        }
        run.events.push({
            name: "agent_end",
            time: new Date().toISOString(),
            kwargs: {
                action
            }
        });
        await this.onAgentEnd?.(run);
    }
    /**
     * Create and add a run to the run map for retriever start events.
     * This must sometimes be done synchronously to avoid race conditions
     * when callbacks are backgrounded, so we expose it as a separate method here.
     */ _createRunForRetrieverStart(retriever, query, runId, parentRunId, tags, metadata, name) {
        const execution_order = this._getExecutionOrder(parentRunId);
        const start_time = Date.now();
        const run = {
            id: runId,
            name: name ?? retriever.id[retriever.id.length - 1],
            parent_run_id: parentRunId,
            start_time,
            serialized: retriever,
            events: [
                {
                    name: "start",
                    time: new Date(start_time).toISOString()
                }
            ],
            inputs: {
                query
            },
            execution_order,
            child_execution_order: execution_order,
            run_type: "retriever",
            child_runs: [],
            extra: metadata ? {
                metadata
            } : {},
            tags: tags || []
        };
        return this._addRunToRunMap(run);
    }
    async handleRetrieverStart(retriever, query, runId, parentRunId, tags, metadata, name) {
        const run = this.runMap.get(runId) ?? this._createRunForRetrieverStart(retriever, query, runId, parentRunId, tags, metadata, name);
        await this.onRunCreate?.(run);
        await this.onRetrieverStart?.(run);
        return run;
    }
    async handleRetrieverEnd(documents, runId) {
        const run = this.runMap.get(runId);
        if (!run || run?.run_type !== "retriever") {
            throw new Error("No retriever run to end");
        }
        run.end_time = Date.now();
        run.outputs = {
            documents
        };
        run.events.push({
            name: "end",
            time: new Date(run.end_time).toISOString()
        });
        await this.onRetrieverEnd?.(run);
        await this._endTrace(run);
        return run;
    }
    async handleRetrieverError(error, runId) {
        const run = this.runMap.get(runId);
        if (!run || run?.run_type !== "retriever") {
            throw new Error("No retriever run to end");
        }
        run.end_time = Date.now();
        run.error = this.stringifyError(error);
        run.events.push({
            name: "error",
            time: new Date(run.end_time).toISOString()
        });
        await this.onRetrieverError?.(run);
        await this._endTrace(run);
        return run;
    }
    async handleText(text, runId) {
        const run = this.runMap.get(runId);
        if (!run || run?.run_type !== "chain") {
            return;
        }
        run.events.push({
            name: "text",
            time: new Date().toISOString(),
            kwargs: {
                text
            }
        });
        await this.onText?.(run);
    }
    async handleLLMNewToken(token, idx, runId, _parentRunId, _tags, fields) {
        const run = this.runMap.get(runId);
        if (!run || run?.run_type !== "llm") {
            throw new Error(`Invalid "runId" provided to "handleLLMNewToken" callback.`);
        }
        run.events.push({
            name: "new_token",
            time: new Date().toISOString(),
            kwargs: {
                token,
                idx,
                chunk: fields?.chunk
            }
        });
        await this.onLLMNewToken?.(run, token, {
            chunk: fields?.chunk
        });
        return run;
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/console.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ConsoleCallbackHandler": (()=>ConsoleCallbackHandler)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$ansi$2d$styles$40$5$2e$2$2e$0$2f$node_modules$2f$ansi$2d$styles$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/ansi-styles@5.2.0/node_modules/ansi-styles/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/base.js [app-route] (ecmascript)");
;
;
function wrap(style, text) {
    return `${style.open}${text}${style.close}`;
}
function tryJsonStringify(obj, fallback) {
    try {
        return JSON.stringify(obj, null, 2);
    } catch (err) {
        return fallback;
    }
}
function formatKVMapItem(value) {
    if (typeof value === "string") {
        return value.trim();
    }
    if (value === null || value === undefined) {
        return value;
    }
    return tryJsonStringify(value, value.toString());
}
function elapsed(run) {
    if (!run.end_time) return "";
    const elapsed = run.end_time - run.start_time;
    if (elapsed < 1000) {
        return `${elapsed}ms`;
    }
    return `${(elapsed / 1000).toFixed(2)}s`;
}
const { color } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$ansi$2d$styles$40$5$2e$2$2e$0$2f$node_modules$2f$ansi$2d$styles$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"];
class ConsoleCallbackHandler extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseTracer"] {
    constructor(){
        super(...arguments);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "console_callback_handler"
        });
    }
    /**
     * Method used to persist the run. In this case, it simply returns a
     * resolved promise as there's no persistence logic.
     * @param _run The run to persist.
     * @returns A resolved promise.
     */ persistRun(_run) {
        return Promise.resolve();
    }
    // utility methods
    /**
     * Method used to get all the parent runs of a given run.
     * @param run The run whose parents are to be retrieved.
     * @returns An array of parent runs.
     */ getParents(run) {
        const parents = [];
        let currentRun = run;
        while(currentRun.parent_run_id){
            const parent = this.runMap.get(currentRun.parent_run_id);
            if (parent) {
                parents.push(parent);
                currentRun = parent;
            } else {
                break;
            }
        }
        return parents;
    }
    /**
     * Method used to get a string representation of the run's lineage, which
     * is used in logging.
     * @param run The run whose lineage is to be retrieved.
     * @returns A string representation of the run's lineage.
     */ getBreadcrumbs(run) {
        const parents = this.getParents(run).reverse();
        const string = [
            ...parents,
            run
        ].map((parent, i, arr)=>{
            const name = `${parent.execution_order}:${parent.run_type}:${parent.name}`;
            return i === arr.length - 1 ? wrap(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$ansi$2d$styles$40$5$2e$2$2e$0$2f$node_modules$2f$ansi$2d$styles$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].bold, name) : name;
        }).join(" > ");
        return wrap(color.grey, string);
    }
    // logging methods
    /**
     * Method used to log the start of a chain run.
     * @param run The chain run that has started.
     * @returns void
     */ onChainStart(run) {
        const crumbs = this.getBreadcrumbs(run);
        console.log(`${wrap(color.green, "[chain/start]")} [${crumbs}] Entering Chain run with input: ${tryJsonStringify(run.inputs, "[inputs]")}`);
    }
    /**
     * Method used to log the end of a chain run.
     * @param run The chain run that has ended.
     * @returns void
     */ onChainEnd(run) {
        const crumbs = this.getBreadcrumbs(run);
        console.log(`${wrap(color.cyan, "[chain/end]")} [${crumbs}] [${elapsed(run)}] Exiting Chain run with output: ${tryJsonStringify(run.outputs, "[outputs]")}`);
    }
    /**
     * Method used to log any errors of a chain run.
     * @param run The chain run that has errored.
     * @returns void
     */ onChainError(run) {
        const crumbs = this.getBreadcrumbs(run);
        console.log(`${wrap(color.red, "[chain/error]")} [${crumbs}] [${elapsed(run)}] Chain run errored with error: ${tryJsonStringify(run.error, "[error]")}`);
    }
    /**
     * Method used to log the start of an LLM run.
     * @param run The LLM run that has started.
     * @returns void
     */ onLLMStart(run) {
        const crumbs = this.getBreadcrumbs(run);
        const inputs = "prompts" in run.inputs ? {
            prompts: run.inputs.prompts.map((p)=>p.trim())
        } : run.inputs;
        console.log(`${wrap(color.green, "[llm/start]")} [${crumbs}] Entering LLM run with input: ${tryJsonStringify(inputs, "[inputs]")}`);
    }
    /**
     * Method used to log the end of an LLM run.
     * @param run The LLM run that has ended.
     * @returns void
     */ onLLMEnd(run) {
        const crumbs = this.getBreadcrumbs(run);
        console.log(`${wrap(color.cyan, "[llm/end]")} [${crumbs}] [${elapsed(run)}] Exiting LLM run with output: ${tryJsonStringify(run.outputs, "[response]")}`);
    }
    /**
     * Method used to log any errors of an LLM run.
     * @param run The LLM run that has errored.
     * @returns void
     */ onLLMError(run) {
        const crumbs = this.getBreadcrumbs(run);
        console.log(`${wrap(color.red, "[llm/error]")} [${crumbs}] [${elapsed(run)}] LLM run errored with error: ${tryJsonStringify(run.error, "[error]")}`);
    }
    /**
     * Method used to log the start of a tool run.
     * @param run The tool run that has started.
     * @returns void
     */ onToolStart(run) {
        const crumbs = this.getBreadcrumbs(run);
        console.log(`${wrap(color.green, "[tool/start]")} [${crumbs}] Entering Tool run with input: "${formatKVMapItem(run.inputs.input)}"`);
    }
    /**
     * Method used to log the end of a tool run.
     * @param run The tool run that has ended.
     * @returns void
     */ onToolEnd(run) {
        const crumbs = this.getBreadcrumbs(run);
        console.log(`${wrap(color.cyan, "[tool/end]")} [${crumbs}] [${elapsed(run)}] Exiting Tool run with output: "${formatKVMapItem(run.outputs?.output)}"`);
    }
    /**
     * Method used to log any errors of a tool run.
     * @param run The tool run that has errored.
     * @returns void
     */ onToolError(run) {
        const crumbs = this.getBreadcrumbs(run);
        console.log(`${wrap(color.red, "[tool/error]")} [${crumbs}] [${elapsed(run)}] Tool run errored with error: ${tryJsonStringify(run.error, "[error]")}`);
    }
    /**
     * Method used to log the start of a retriever run.
     * @param run The retriever run that has started.
     * @returns void
     */ onRetrieverStart(run) {
        const crumbs = this.getBreadcrumbs(run);
        console.log(`${wrap(color.green, "[retriever/start]")} [${crumbs}] Entering Retriever run with input: ${tryJsonStringify(run.inputs, "[inputs]")}`);
    }
    /**
     * Method used to log the end of a retriever run.
     * @param run The retriever run that has ended.
     * @returns void
     */ onRetrieverEnd(run) {
        const crumbs = this.getBreadcrumbs(run);
        console.log(`${wrap(color.cyan, "[retriever/end]")} [${crumbs}] [${elapsed(run)}] Exiting Retriever run with output: ${tryJsonStringify(run.outputs, "[outputs]")}`);
    }
    /**
     * Method used to log any errors of a retriever run.
     * @param run The retriever run that has errored.
     * @returns void
     */ onRetrieverError(run) {
        const crumbs = this.getBreadcrumbs(run);
        console.log(`${wrap(color.red, "[retriever/error]")} [${crumbs}] [${elapsed(run)}] Retriever run errored with error: ${tryJsonStringify(run.error, "[error]")}`);
    }
    /**
     * Method used to log the action selected by the agent.
     * @param run The run in which the agent action occurred.
     * @returns void
     */ onAgentAction(run) {
        const agentRun = run;
        const crumbs = this.getBreadcrumbs(run);
        console.log(`${wrap(color.blue, "[agent/action]")} [${crumbs}] Agent selected action: ${tryJsonStringify(agentRun.actions[agentRun.actions.length - 1], "[action]")}`);
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/errors/index.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable @typescript-eslint/no-explicit-any */ /* eslint-disable no-param-reassign */ __turbopack_esm__({
    "addLangChainErrorFields": (()=>addLangChainErrorFields)
});
function addLangChainErrorFields(error, lc_error_code) {
    error.lc_error_code = lc_error_code;
    error.message = `${error.message}\n\nTroubleshooting URL: https://js.langchain.com/docs/troubleshooting/errors/${lc_error_code}/\n`;
    return error;
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tools/utils.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ToolInputParsingException": (()=>ToolInputParsingException),
    "_isToolCall": (()=>_isToolCall)
});
function _isToolCall(toolCall) {
    return !!(toolCall && typeof toolCall === "object" && "type" in toolCall && toolCall.type === "tool_call");
}
class ToolInputParsingException extends Error {
    constructor(message, output){
        super(message);
        Object.defineProperty(this, "output", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.output = output;
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/json.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "parseJsonMarkdown": (()=>parseJsonMarkdown),
    "parsePartialJson": (()=>parsePartialJson)
});
function parseJsonMarkdown(s, parser = parsePartialJson) {
    // eslint-disable-next-line no-param-reassign
    s = s.trim();
    const match = /```(json)?(.*)```/s.exec(s);
    if (!match) {
        return parser(s);
    } else {
        return parser(match[2]);
    }
}
function parsePartialJson(s) {
    // If the input is undefined, return null to indicate failure.
    if (typeof s === "undefined") {
        return null;
    }
    // Attempt to parse the string as-is.
    try {
        return JSON.parse(s);
    } catch (error) {
    // Pass
    }
    // Initialize variables.
    let new_s = "";
    const stack = [];
    let isInsideString = false;
    let escaped = false;
    // Process each character in the string one at a time.
    for (let char of s){
        if (isInsideString) {
            if (char === '"' && !escaped) {
                isInsideString = false;
            } else if (char === "\n" && !escaped) {
                char = "\\n"; // Replace the newline character with the escape sequence.
            } else if (char === "\\") {
                escaped = !escaped;
            } else {
                escaped = false;
            }
        } else {
            if (char === '"') {
                isInsideString = true;
                escaped = false;
            } else if (char === "{") {
                stack.push("}");
            } else if (char === "[") {
                stack.push("]");
            } else if (char === "}" || char === "]") {
                if (stack && stack[stack.length - 1] === char) {
                    stack.pop();
                } else {
                    // Mismatched closing character; the input is malformed.
                    return null;
                }
            }
        }
        // Append the processed character to the new string.
        new_s += char;
    }
    // If we're still inside a string at the end of processing,
    // we need to close the string.
    if (isInsideString) {
        new_s += '"';
    }
    // Close any remaining open structures in the reverse order that they were opened.
    for(let i = stack.length - 1; i >= 0; i -= 1){
        new_s += stack[i];
    }
    // Attempt to parse the modified string as JSON.
    try {
        return JSON.parse(new_s);
    } catch (error) {
        // If we still can't parse the string as JSON, return null to indicate failure.
        return null;
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/base.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "BaseMessage": (()=>BaseMessage),
    "BaseMessageChunk": (()=>BaseMessageChunk),
    "_isMessageFieldWithRole": (()=>_isMessageFieldWithRole),
    "_mergeDicts": (()=>_mergeDicts),
    "_mergeLists": (()=>_mergeLists),
    "_mergeObj": (()=>_mergeObj),
    "_mergeStatus": (()=>_mergeStatus),
    "isBaseMessage": (()=>isBaseMessage),
    "isBaseMessageChunk": (()=>isBaseMessageChunk),
    "isOpenAIToolCallArray": (()=>isOpenAIToolCallArray),
    "mergeContent": (()=>mergeContent)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$load$2f$serializable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/load/serializable.js [app-route] (ecmascript)");
;
function mergeContent(firstContent, secondContent) {
    // If first content is a string
    if (typeof firstContent === "string") {
        if (typeof secondContent === "string") {
            return firstContent + secondContent;
        } else {
            return [
                {
                    type: "text",
                    text: firstContent
                },
                ...secondContent
            ];
        }
    // If both are arrays
    } else if (Array.isArray(secondContent)) {
        return _mergeLists(firstContent, secondContent) ?? [
            ...firstContent,
            ...secondContent
        ];
    } else {
        // Otherwise, add the second content as a new element of the list
        return [
            ...firstContent,
            {
                type: "text",
                text: secondContent
            }
        ];
    }
}
function _mergeStatus(left, right) {
    if (left === "error" || right === "error") {
        return "error";
    }
    return "success";
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function stringifyWithDepthLimit(obj, depthLimit) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    function helper(obj, currentDepth) {
        if (typeof obj !== "object" || obj === null || obj === undefined) {
            return obj;
        }
        if (currentDepth >= depthLimit) {
            if (Array.isArray(obj)) {
                return "[Array]";
            }
            return "[Object]";
        }
        if (Array.isArray(obj)) {
            return obj.map((item)=>helper(item, currentDepth + 1));
        }
        const result = {};
        for (const key of Object.keys(obj)){
            result[key] = helper(obj[key], currentDepth + 1);
        }
        return result;
    }
    return JSON.stringify(helper(obj, 0), null, 2);
}
class BaseMessage extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$load$2f$serializable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Serializable"] {
    get lc_aliases() {
        // exclude snake case conversion to pascal case
        return {
            additional_kwargs: "additional_kwargs",
            response_metadata: "response_metadata"
        };
    }
    /**
     * @deprecated
     * Use {@link BaseMessage.content} instead.
     */ get text() {
        return typeof this.content === "string" ? this.content : "";
    }
    /** The type of the message. */ getType() {
        return this._getType();
    }
    constructor(fields, /** @deprecated */ kwargs){
        if (typeof fields === "string") {
            // eslint-disable-next-line no-param-reassign
            fields = {
                content: fields,
                additional_kwargs: kwargs,
                response_metadata: {}
            };
        }
        // Make sure the default value for additional_kwargs is passed into super() for serialization
        if (!fields.additional_kwargs) {
            // eslint-disable-next-line no-param-reassign
            fields.additional_kwargs = {};
        }
        if (!fields.response_metadata) {
            // eslint-disable-next-line no-param-reassign
            fields.response_metadata = {};
        }
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "messages"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        /** The content of the message. */ Object.defineProperty(this, "content", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** The name of the message sender in a multi-user chat. */ Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Additional keyword arguments */ Object.defineProperty(this, "additional_kwargs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Response metadata. For example: response headers, logprobs, token counts. */ Object.defineProperty(this, "response_metadata", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /**
         * An optional unique identifier for the message. This should ideally be
         * provided by the provider/model which created the message.
         */ Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.name = fields.name;
        this.content = fields.content;
        this.additional_kwargs = fields.additional_kwargs;
        this.response_metadata = fields.response_metadata;
        this.id = fields.id;
    }
    toDict() {
        return {
            type: this._getType(),
            data: this.toJSON().kwargs
        };
    }
    static lc_name() {
        return "BaseMessage";
    }
    // Can't be protected for silly reasons
    get _printableFields() {
        return {
            id: this.id,
            content: this.content,
            name: this.name,
            additional_kwargs: this.additional_kwargs,
            response_metadata: this.response_metadata
        };
    }
    // this private method is used to update the ID for the runtime
    // value as well as in lc_kwargs for serialisation
    _updateId(value) {
        this.id = value;
        // lc_attributes wouldn't work here, because jest compares the
        // whole object
        this.lc_kwargs.id = value;
    }
    get [Symbol.toStringTag]() {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return this.constructor.lc_name();
    }
    // Override the default behavior of console.log
    [Symbol.for("nodejs.util.inspect.custom")](depth) {
        if (depth === null) {
            return this;
        }
        const printable = stringifyWithDepthLimit(this._printableFields, Math.max(4, depth));
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return `${this.constructor.lc_name()} ${printable}`;
    }
}
function isOpenAIToolCallArray(value) {
    return Array.isArray(value) && value.every((v)=>typeof v.index === "number");
}
function _mergeDicts(// eslint-disable-next-line @typescript-eslint/no-explicit-any
left, // eslint-disable-next-line @typescript-eslint/no-explicit-any
right) {
    const merged = {
        ...left
    };
    for (const [key, value] of Object.entries(right)){
        if (merged[key] == null) {
            merged[key] = value;
        } else if (value == null) {
            continue;
        } else if (typeof merged[key] !== typeof value || Array.isArray(merged[key]) !== Array.isArray(value)) {
            throw new Error(`field[${key}] already exists in the message chunk, but with a different type.`);
        } else if (typeof merged[key] === "string") {
            if (key === "type") {
                continue;
            }
            merged[key] += value;
        } else if (typeof merged[key] === "object" && !Array.isArray(merged[key])) {
            merged[key] = _mergeDicts(merged[key], value);
        } else if (Array.isArray(merged[key])) {
            merged[key] = _mergeLists(merged[key], value);
        } else if (merged[key] === value) {
            continue;
        } else {
            console.warn(`field[${key}] already exists in this message chunk and value has unsupported type.`);
        }
    }
    return merged;
}
function _mergeLists(left, right) {
    if (left === undefined && right === undefined) {
        return undefined;
    } else if (left === undefined || right === undefined) {
        return left || right;
    } else {
        const merged = [
            ...left
        ];
        for (const item of right){
            if (typeof item === "object" && "index" in item && typeof item.index === "number") {
                const toMerge = merged.findIndex((leftItem)=>leftItem.index === item.index);
                if (toMerge !== -1) {
                    merged[toMerge] = _mergeDicts(merged[toMerge], item);
                } else {
                    merged.push(item);
                }
            } else if (typeof item === "object" && "text" in item && item.text === "") {
                continue;
            } else {
                merged.push(item);
            }
        }
        return merged;
    }
}
function _mergeObj(left, right) {
    if (!left && !right) {
        throw new Error("Cannot merge two undefined objects.");
    }
    if (!left || !right) {
        return left || right;
    } else if (typeof left !== typeof right) {
        throw new Error(`Cannot merge objects of different types.\nLeft ${typeof left}\nRight ${typeof right}`);
    } else if (typeof left === "string" && typeof right === "string") {
        return left + right;
    } else if (Array.isArray(left) && Array.isArray(right)) {
        return _mergeLists(left, right);
    } else if (typeof left === "object" && typeof right === "object") {
        return _mergeDicts(left, right);
    } else if (left === right) {
        return left;
    } else {
        throw new Error(`Can not merge objects of different types.\nLeft ${left}\nRight ${right}`);
    }
}
class BaseMessageChunk extends BaseMessage {
}
function _isMessageFieldWithRole(x) {
    return typeof x.role === "string";
}
function isBaseMessage(messageLike) {
    return typeof messageLike?._getType === "function";
}
function isBaseMessageChunk(messageLike) {
    return isBaseMessage(messageLike) && typeof messageLike.concat === "function";
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/tool.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ToolMessage": (()=>ToolMessage),
    "ToolMessageChunk": (()=>ToolMessageChunk),
    "defaultToolCallParser": (()=>defaultToolCallParser),
    "isDirectToolOutput": (()=>isDirectToolOutput),
    "isToolMessage": (()=>isToolMessage),
    "isToolMessageChunk": (()=>isToolMessageChunk)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/base.js [app-route] (ecmascript)");
;
function isDirectToolOutput(x) {
    return x != null && typeof x === "object" && "lc_direct_tool_output" in x && x.lc_direct_tool_output === true;
}
class ToolMessage extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessage"] {
    static lc_name() {
        return "ToolMessage";
    }
    get lc_aliases() {
        // exclude snake case conversion to pascal case
        return {
            tool_call_id: "tool_call_id"
        };
    }
    constructor(fields, tool_call_id, name){
        if (typeof fields === "string") {
            // eslint-disable-next-line no-param-reassign, @typescript-eslint/no-non-null-assertion
            fields = {
                content: fields,
                name,
                tool_call_id: tool_call_id
            };
        }
        super(fields);
        Object.defineProperty(this, "lc_direct_tool_output", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        /**
         * Status of the tool invocation.
         * @version 0.2.19
         */ Object.defineProperty(this, "status", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "tool_call_id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /**
         * Artifact of the Tool execution which is not meant to be sent to the model.
         *
         * Should only be specified if it is different from the message content, e.g. if only
         * a subset of the full tool output is being passed as message content but the full
         * output is needed in other parts of the code.
         */ // eslint-disable-next-line @typescript-eslint/no-explicit-any
        Object.defineProperty(this, "artifact", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.tool_call_id = fields.tool_call_id;
        this.artifact = fields.artifact;
        this.status = fields.status;
    }
    _getType() {
        return "tool";
    }
    static isInstance(message) {
        return message._getType() === "tool";
    }
    get _printableFields() {
        return {
            ...super._printableFields,
            tool_call_id: this.tool_call_id,
            artifact: this.artifact
        };
    }
}
class ToolMessageChunk extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessageChunk"] {
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "tool_call_id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /**
         * Status of the tool invocation.
         * @version 0.2.19
         */ Object.defineProperty(this, "status", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /**
         * Artifact of the Tool execution which is not meant to be sent to the model.
         *
         * Should only be specified if it is different from the message content, e.g. if only
         * a subset of the full tool output is being passed as message content but the full
         * output is needed in other parts of the code.
         */ // eslint-disable-next-line @typescript-eslint/no-explicit-any
        Object.defineProperty(this, "artifact", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.tool_call_id = fields.tool_call_id;
        this.artifact = fields.artifact;
        this.status = fields.status;
    }
    static lc_name() {
        return "ToolMessageChunk";
    }
    _getType() {
        return "tool";
    }
    concat(chunk) {
        return new ToolMessageChunk({
            content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mergeContent"])(this.content, chunk.content),
            additional_kwargs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeDicts"])(this.additional_kwargs, chunk.additional_kwargs),
            response_metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeDicts"])(this.response_metadata, chunk.response_metadata),
            artifact: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeObj"])(this.artifact, chunk.artifact),
            tool_call_id: this.tool_call_id,
            id: this.id ?? chunk.id,
            status: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeStatus"])(this.status, chunk.status)
        });
    }
    get _printableFields() {
        return {
            ...super._printableFields,
            tool_call_id: this.tool_call_id,
            artifact: this.artifact
        };
    }
}
function defaultToolCallParser(// eslint-disable-next-line @typescript-eslint/no-explicit-any
rawToolCalls) {
    const toolCalls = [];
    const invalidToolCalls = [];
    for (const toolCall of rawToolCalls){
        if (!toolCall.function) {
            continue;
        } else {
            const functionName = toolCall.function.name;
            try {
                const functionArgs = JSON.parse(toolCall.function.arguments);
                const parsed = {
                    name: functionName || "",
                    args: functionArgs || {},
                    id: toolCall.id
                };
                toolCalls.push(parsed);
            } catch (error) {
                invalidToolCalls.push({
                    name: functionName,
                    args: toolCall.function.arguments,
                    id: toolCall.id,
                    error: "Malformed args."
                });
            }
        }
    }
    return [
        toolCalls,
        invalidToolCalls
    ];
}
function isToolMessage(x) {
    return x._getType() === "tool";
}
function isToolMessageChunk(x) {
    return x._getType() === "tool";
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/ai.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "AIMessage": (()=>AIMessage),
    "AIMessageChunk": (()=>AIMessageChunk),
    "isAIMessage": (()=>isAIMessage),
    "isAIMessageChunk": (()=>isAIMessageChunk)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$json$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/json.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$tool$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/tool.js [app-route] (ecmascript)");
;
;
;
class AIMessage extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessage"] {
    get lc_aliases() {
        // exclude snake case conversion to pascal case
        return {
            ...super.lc_aliases,
            tool_calls: "tool_calls",
            invalid_tool_calls: "invalid_tool_calls"
        };
    }
    constructor(fields, /** @deprecated */ kwargs){
        let initParams;
        if (typeof fields === "string") {
            initParams = {
                content: fields,
                tool_calls: [],
                invalid_tool_calls: [],
                additional_kwargs: kwargs ?? {}
            };
        } else {
            initParams = fields;
            const rawToolCalls = initParams.additional_kwargs?.tool_calls;
            const toolCalls = initParams.tool_calls;
            if (!(rawToolCalls == null) && rawToolCalls.length > 0 && (toolCalls === undefined || toolCalls.length === 0)) {
                console.warn([
                    "New LangChain packages are available that more efficiently handle",
                    "tool calling.\n\nPlease upgrade your packages to versions that set",
                    "message tool calls. e.g., `yarn add @langchain/anthropic`,",
                    "yarn add @langchain/openai`, etc."
                ].join(" "));
            }
            try {
                if (!(rawToolCalls == null) && toolCalls === undefined) {
                    const [toolCalls, invalidToolCalls] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$tool$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["defaultToolCallParser"])(rawToolCalls);
                    initParams.tool_calls = toolCalls ?? [];
                    initParams.invalid_tool_calls = invalidToolCalls ?? [];
                } else {
                    initParams.tool_calls = initParams.tool_calls ?? [];
                    initParams.invalid_tool_calls = initParams.invalid_tool_calls ?? [];
                }
            } catch (e) {
                // Do nothing if parsing fails
                initParams.tool_calls = [];
                initParams.invalid_tool_calls = [];
            }
        }
        // Sadly, TypeScript only allows super() calls at root if the class has
        // properties with initializers, so we have to check types twice.
        super(initParams);
        // These are typed as optional to avoid breaking changes and allow for casting
        // from BaseMessage.
        Object.defineProperty(this, "tool_calls", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "invalid_tool_calls", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        /**
         * If provided, token usage information associated with the message.
         */ Object.defineProperty(this, "usage_metadata", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        if (typeof initParams !== "string") {
            this.tool_calls = initParams.tool_calls ?? this.tool_calls;
            this.invalid_tool_calls = initParams.invalid_tool_calls ?? this.invalid_tool_calls;
        }
        this.usage_metadata = initParams.usage_metadata;
    }
    static lc_name() {
        return "AIMessage";
    }
    _getType() {
        return "ai";
    }
    get _printableFields() {
        return {
            ...super._printableFields,
            tool_calls: this.tool_calls,
            invalid_tool_calls: this.invalid_tool_calls,
            usage_metadata: this.usage_metadata
        };
    }
}
function isAIMessage(x) {
    return x._getType() === "ai";
}
function isAIMessageChunk(x) {
    return x._getType() === "ai";
}
class AIMessageChunk extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessageChunk"] {
    constructor(fields){
        let initParams;
        if (typeof fields === "string") {
            initParams = {
                content: fields,
                tool_calls: [],
                invalid_tool_calls: [],
                tool_call_chunks: []
            };
        } else if (fields.tool_call_chunks === undefined) {
            initParams = {
                ...fields,
                tool_calls: fields.tool_calls ?? [],
                invalid_tool_calls: [],
                tool_call_chunks: [],
                usage_metadata: fields.usage_metadata !== undefined ? fields.usage_metadata : undefined
            };
        } else {
            const toolCalls = [];
            const invalidToolCalls = [];
            for (const toolCallChunk of fields.tool_call_chunks){
                let parsedArgs = {};
                try {
                    parsedArgs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$json$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parsePartialJson"])(toolCallChunk.args || "{}");
                    if (parsedArgs === null || typeof parsedArgs !== "object" || Array.isArray(parsedArgs)) {
                        throw new Error("Malformed tool call chunk args.");
                    }
                    toolCalls.push({
                        name: toolCallChunk.name ?? "",
                        args: parsedArgs,
                        id: toolCallChunk.id,
                        type: "tool_call"
                    });
                } catch (e) {
                    invalidToolCalls.push({
                        name: toolCallChunk.name,
                        args: toolCallChunk.args,
                        id: toolCallChunk.id,
                        error: "Malformed args.",
                        type: "invalid_tool_call"
                    });
                }
            }
            initParams = {
                ...fields,
                tool_calls: toolCalls,
                invalid_tool_calls: invalidToolCalls,
                usage_metadata: fields.usage_metadata !== undefined ? fields.usage_metadata : undefined
            };
        }
        // Sadly, TypeScript only allows super() calls at root if the class has
        // properties with initializers, so we have to check types twice.
        super(initParams);
        // Must redeclare tool call fields since there is no multiple inheritance in JS.
        // These are typed as optional to avoid breaking changes and allow for casting
        // from BaseMessage.
        Object.defineProperty(this, "tool_calls", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "invalid_tool_calls", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "tool_call_chunks", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        /**
         * If provided, token usage information associated with the message.
         */ Object.defineProperty(this, "usage_metadata", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.tool_call_chunks = initParams.tool_call_chunks ?? this.tool_call_chunks;
        this.tool_calls = initParams.tool_calls ?? this.tool_calls;
        this.invalid_tool_calls = initParams.invalid_tool_calls ?? this.invalid_tool_calls;
        this.usage_metadata = initParams.usage_metadata;
    }
    get lc_aliases() {
        // exclude snake case conversion to pascal case
        return {
            ...super.lc_aliases,
            tool_calls: "tool_calls",
            invalid_tool_calls: "invalid_tool_calls",
            tool_call_chunks: "tool_call_chunks"
        };
    }
    static lc_name() {
        return "AIMessageChunk";
    }
    _getType() {
        return "ai";
    }
    get _printableFields() {
        return {
            ...super._printableFields,
            tool_calls: this.tool_calls,
            tool_call_chunks: this.tool_call_chunks,
            invalid_tool_calls: this.invalid_tool_calls,
            usage_metadata: this.usage_metadata
        };
    }
    concat(chunk) {
        const combinedFields = {
            content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mergeContent"])(this.content, chunk.content),
            additional_kwargs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeDicts"])(this.additional_kwargs, chunk.additional_kwargs),
            response_metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeDicts"])(this.response_metadata, chunk.response_metadata),
            tool_call_chunks: [],
            id: this.id ?? chunk.id
        };
        if (this.tool_call_chunks !== undefined || chunk.tool_call_chunks !== undefined) {
            const rawToolCalls = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeLists"])(this.tool_call_chunks, chunk.tool_call_chunks);
            if (rawToolCalls !== undefined && rawToolCalls.length > 0) {
                combinedFields.tool_call_chunks = rawToolCalls;
            }
        }
        if (this.usage_metadata !== undefined || chunk.usage_metadata !== undefined) {
            const inputTokenDetails = {
                ...(this.usage_metadata?.input_token_details?.audio !== undefined || chunk.usage_metadata?.input_token_details?.audio !== undefined) && {
                    audio: (this.usage_metadata?.input_token_details?.audio ?? 0) + (chunk.usage_metadata?.input_token_details?.audio ?? 0)
                },
                ...(this.usage_metadata?.input_token_details?.cache_read !== undefined || chunk.usage_metadata?.input_token_details?.cache_read !== undefined) && {
                    cache_read: (this.usage_metadata?.input_token_details?.cache_read ?? 0) + (chunk.usage_metadata?.input_token_details?.cache_read ?? 0)
                },
                ...(this.usage_metadata?.input_token_details?.cache_creation !== undefined || chunk.usage_metadata?.input_token_details?.cache_creation !== undefined) && {
                    cache_creation: (this.usage_metadata?.input_token_details?.cache_creation ?? 0) + (chunk.usage_metadata?.input_token_details?.cache_creation ?? 0)
                }
            };
            const outputTokenDetails = {
                ...(this.usage_metadata?.output_token_details?.audio !== undefined || chunk.usage_metadata?.output_token_details?.audio !== undefined) && {
                    audio: (this.usage_metadata?.output_token_details?.audio ?? 0) + (chunk.usage_metadata?.output_token_details?.audio ?? 0)
                },
                ...(this.usage_metadata?.output_token_details?.reasoning !== undefined || chunk.usage_metadata?.output_token_details?.reasoning !== undefined) && {
                    reasoning: (this.usage_metadata?.output_token_details?.reasoning ?? 0) + (chunk.usage_metadata?.output_token_details?.reasoning ?? 0)
                }
            };
            const left = this.usage_metadata ?? {
                input_tokens: 0,
                output_tokens: 0,
                total_tokens: 0
            };
            const right = chunk.usage_metadata ?? {
                input_tokens: 0,
                output_tokens: 0,
                total_tokens: 0
            };
            const usage_metadata = {
                input_tokens: left.input_tokens + right.input_tokens,
                output_tokens: left.output_tokens + right.output_tokens,
                total_tokens: left.total_tokens + right.total_tokens,
                // Do not include `input_token_details` / `output_token_details` keys in combined fields
                // unless their values are defined.
                ...Object.keys(inputTokenDetails).length > 0 && {
                    input_token_details: inputTokenDetails
                },
                ...Object.keys(outputTokenDetails).length > 0 && {
                    output_token_details: outputTokenDetails
                }
            };
            combinedFields.usage_metadata = usage_metadata;
        }
        return new AIMessageChunk(combinedFields);
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/chat.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ChatMessage": (()=>ChatMessage),
    "ChatMessageChunk": (()=>ChatMessageChunk),
    "isChatMessage": (()=>isChatMessage),
    "isChatMessageChunk": (()=>isChatMessageChunk)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/base.js [app-route] (ecmascript)");
;
class ChatMessage extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessage"] {
    static lc_name() {
        return "ChatMessage";
    }
    static _chatMessageClass() {
        return ChatMessage;
    }
    constructor(fields, role){
        if (typeof fields === "string") {
            // eslint-disable-next-line no-param-reassign, @typescript-eslint/no-non-null-assertion
            fields = {
                content: fields,
                role: role
            };
        }
        super(fields);
        Object.defineProperty(this, "role", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.role = fields.role;
    }
    _getType() {
        return "generic";
    }
    static isInstance(message) {
        return message._getType() === "generic";
    }
    get _printableFields() {
        return {
            ...super._printableFields,
            role: this.role
        };
    }
}
class ChatMessageChunk extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessageChunk"] {
    static lc_name() {
        return "ChatMessageChunk";
    }
    constructor(fields, role){
        if (typeof fields === "string") {
            // eslint-disable-next-line no-param-reassign, @typescript-eslint/no-non-null-assertion
            fields = {
                content: fields,
                role: role
            };
        }
        super(fields);
        Object.defineProperty(this, "role", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.role = fields.role;
    }
    _getType() {
        return "generic";
    }
    concat(chunk) {
        return new ChatMessageChunk({
            content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mergeContent"])(this.content, chunk.content),
            additional_kwargs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeDicts"])(this.additional_kwargs, chunk.additional_kwargs),
            response_metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeDicts"])(this.response_metadata, chunk.response_metadata),
            role: this.role,
            id: this.id ?? chunk.id
        });
    }
    get _printableFields() {
        return {
            ...super._printableFields,
            role: this.role
        };
    }
}
function isChatMessage(x) {
    return x._getType() === "generic";
}
function isChatMessageChunk(x) {
    return x._getType() === "generic";
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/function.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "FunctionMessage": (()=>FunctionMessage),
    "FunctionMessageChunk": (()=>FunctionMessageChunk),
    "isFunctionMessage": (()=>isFunctionMessage),
    "isFunctionMessageChunk": (()=>isFunctionMessageChunk)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/base.js [app-route] (ecmascript)");
;
class FunctionMessage extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessage"] {
    static lc_name() {
        return "FunctionMessage";
    }
    constructor(fields, /** @deprecated */ name){
        if (typeof fields === "string") {
            // eslint-disable-next-line no-param-reassign, @typescript-eslint/no-non-null-assertion
            fields = {
                content: fields,
                name: name
            };
        }
        super(fields);
    }
    _getType() {
        return "function";
    }
}
class FunctionMessageChunk extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessageChunk"] {
    static lc_name() {
        return "FunctionMessageChunk";
    }
    _getType() {
        return "function";
    }
    concat(chunk) {
        return new FunctionMessageChunk({
            content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mergeContent"])(this.content, chunk.content),
            additional_kwargs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeDicts"])(this.additional_kwargs, chunk.additional_kwargs),
            response_metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeDicts"])(this.response_metadata, chunk.response_metadata),
            name: this.name ?? "",
            id: this.id ?? chunk.id
        });
    }
}
function isFunctionMessage(x) {
    return x._getType() === "function";
}
function isFunctionMessageChunk(x) {
    return x._getType() === "function";
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/human.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "HumanMessage": (()=>HumanMessage),
    "HumanMessageChunk": (()=>HumanMessageChunk),
    "isHumanMessage": (()=>isHumanMessage),
    "isHumanMessageChunk": (()=>isHumanMessageChunk)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/base.js [app-route] (ecmascript)");
;
class HumanMessage extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessage"] {
    static lc_name() {
        return "HumanMessage";
    }
    _getType() {
        return "human";
    }
}
class HumanMessageChunk extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessageChunk"] {
    static lc_name() {
        return "HumanMessageChunk";
    }
    _getType() {
        return "human";
    }
    concat(chunk) {
        return new HumanMessageChunk({
            content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mergeContent"])(this.content, chunk.content),
            additional_kwargs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeDicts"])(this.additional_kwargs, chunk.additional_kwargs),
            response_metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeDicts"])(this.response_metadata, chunk.response_metadata),
            id: this.id ?? chunk.id
        });
    }
}
function isHumanMessage(x) {
    return x.getType() === "human";
}
function isHumanMessageChunk(x) {
    return x.getType() === "human";
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/system.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "SystemMessage": (()=>SystemMessage),
    "SystemMessageChunk": (()=>SystemMessageChunk),
    "isSystemMessage": (()=>isSystemMessage),
    "isSystemMessageChunk": (()=>isSystemMessageChunk)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/base.js [app-route] (ecmascript)");
;
class SystemMessage extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessage"] {
    static lc_name() {
        return "SystemMessage";
    }
    _getType() {
        return "system";
    }
}
class SystemMessageChunk extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessageChunk"] {
    static lc_name() {
        return "SystemMessageChunk";
    }
    _getType() {
        return "system";
    }
    concat(chunk) {
        return new SystemMessageChunk({
            content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mergeContent"])(this.content, chunk.content),
            additional_kwargs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeDicts"])(this.additional_kwargs, chunk.additional_kwargs),
            response_metadata: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_mergeDicts"])(this.response_metadata, chunk.response_metadata),
            id: this.id ?? chunk.id
        });
    }
}
function isSystemMessage(x) {
    return x._getType() === "system";
}
function isSystemMessageChunk(x) {
    return x._getType() === "system";
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/utils.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "coerceMessageLikeToMessage": (()=>coerceMessageLikeToMessage),
    "convertToChunk": (()=>convertToChunk),
    "getBufferString": (()=>getBufferString),
    "mapChatMessagesToStoredMessages": (()=>mapChatMessagesToStoredMessages),
    "mapStoredMessageToChatMessage": (()=>mapStoredMessageToChatMessage),
    "mapStoredMessagesToChatMessages": (()=>mapStoredMessagesToChatMessages)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$errors$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/errors/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tools$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tools/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/ai.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/chat.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$function$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/function.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/human.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/system.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$tool$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/tool.js [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
;
function _coerceToolCall(toolCall) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tools$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_isToolCall"])(toolCall)) {
        return toolCall;
    } else if (typeof toolCall.id === "string" && toolCall.type === "function" && typeof toolCall.function === "object" && toolCall.function !== null && "arguments" in toolCall.function && typeof toolCall.function.arguments === "string" && "name" in toolCall.function && typeof toolCall.function.name === "string") {
        // Handle OpenAI tool call format
        return {
            id: toolCall.id,
            args: JSON.parse(toolCall.function.arguments),
            name: toolCall.function.name,
            type: "tool_call"
        };
    } else {
        // TODO: Throw an error?
        return toolCall;
    }
}
function isSerializedConstructor(x) {
    return typeof x === "object" && x != null && x.lc === 1 && Array.isArray(x.id) && x.kwargs != null && typeof x.kwargs === "object";
}
function _constructMessageFromParams(params) {
    let type;
    let rest;
    // Support serialized messages
    if (isSerializedConstructor(params)) {
        const className = params.id.at(-1);
        if (className === "HumanMessage" || className === "HumanMessageChunk") {
            type = "user";
        } else if (className === "AIMessage" || className === "AIMessageChunk") {
            type = "assistant";
        } else if (className === "SystemMessage" || className === "SystemMessageChunk") {
            type = "system";
        } else {
            type = "unknown";
        }
        rest = params.kwargs;
    } else {
        const { type: extractedType, ...otherParams } = params;
        type = extractedType;
        rest = otherParams;
    }
    if (type === "human" || type === "user") {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HumanMessage"](rest);
    } else if (type === "ai" || type === "assistant") {
        const { tool_calls: rawToolCalls, ...other } = rest;
        if (!Array.isArray(rawToolCalls)) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AIMessage"](rest);
        }
        const tool_calls = rawToolCalls.map(_coerceToolCall);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AIMessage"]({
            ...other,
            tool_calls
        });
    } else if (type === "system") {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemMessage"](rest);
    } else if (type === "developer") {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemMessage"]({
            ...rest,
            additional_kwargs: {
                ...rest.additional_kwargs,
                __openai_role__: "developer"
            }
        });
    } else if (type === "tool" && "tool_call_id" in rest) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$tool$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ToolMessage"]({
            ...rest,
            content: rest.content,
            tool_call_id: rest.tool_call_id,
            name: rest.name
        });
    } else {
        const error = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$errors$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["addLangChainErrorFields"])(new Error(`Unable to coerce message from array: only human, AI, system, developer, or tool message coercion is currently supported.\n\nReceived: ${JSON.stringify(params, null, 2)}`), "MESSAGE_COERCION_FAILURE");
        throw error;
    }
}
function coerceMessageLikeToMessage(messageLike) {
    if (typeof messageLike === "string") {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HumanMessage"](messageLike);
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseMessage"])(messageLike)) {
        return messageLike;
    }
    if (Array.isArray(messageLike)) {
        const [type, content] = messageLike;
        return _constructMessageFromParams({
            type,
            content
        });
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_isMessageFieldWithRole"])(messageLike)) {
        const { role: type, ...rest } = messageLike;
        return _constructMessageFromParams({
            ...rest,
            type
        });
    } else {
        return _constructMessageFromParams(messageLike);
    }
}
function getBufferString(messages, humanPrefix = "Human", aiPrefix = "AI") {
    const string_messages = [];
    for (const m of messages){
        let role;
        if (m._getType() === "human") {
            role = humanPrefix;
        } else if (m._getType() === "ai") {
            role = aiPrefix;
        } else if (m._getType() === "system") {
            role = "System";
        } else if (m._getType() === "function") {
            role = "Function";
        } else if (m._getType() === "tool") {
            role = "Tool";
        } else if (m._getType() === "generic") {
            role = m.role;
        } else {
            throw new Error(`Got unsupported message type: ${m._getType()}`);
        }
        const nameStr = m.name ? `${m.name}, ` : "";
        const readableContent = typeof m.content === "string" ? m.content : JSON.stringify(m.content, null, 2);
        string_messages.push(`${role}: ${nameStr}${readableContent}`);
    }
    return string_messages.join("\n");
}
/**
 * Maps messages from an older format (V1) to the current `StoredMessage`
 * format. If the message is already in the `StoredMessage` format, it is
 * returned as is. Otherwise, it transforms the V1 message into a
 * `StoredMessage`. This function is important for maintaining
 * compatibility with older message formats.
 */ function mapV1MessageToStoredMessage(message) {
    // TODO: Remove this mapper when we deprecate the old message format.
    if (message.data !== undefined) {
        return message;
    } else {
        const v1Message = message;
        return {
            type: v1Message.type,
            data: {
                content: v1Message.text,
                role: v1Message.role,
                name: undefined,
                tool_call_id: undefined
            }
        };
    }
}
function mapStoredMessageToChatMessage(message) {
    const storedMessage = mapV1MessageToStoredMessage(message);
    switch(storedMessage.type){
        case "human":
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HumanMessage"](storedMessage.data);
        case "ai":
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AIMessage"](storedMessage.data);
        case "system":
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemMessage"](storedMessage.data);
        case "function":
            if (storedMessage.data.name === undefined) {
                throw new Error("Name must be defined for function messages");
            }
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$function$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["FunctionMessage"](storedMessage.data);
        case "tool":
            if (storedMessage.data.tool_call_id === undefined) {
                throw new Error("Tool call ID must be defined for tool messages");
            }
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$tool$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ToolMessage"](storedMessage.data);
        case "generic":
            {
                if (storedMessage.data.role === undefined) {
                    throw new Error("Role must be defined for chat messages");
                }
                return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatMessage"](storedMessage.data);
            }
        default:
            throw new Error(`Got unexpected type: ${storedMessage.type}`);
    }
}
function mapStoredMessagesToChatMessages(messages) {
    return messages.map(mapStoredMessageToChatMessage);
}
function mapChatMessagesToStoredMessages(messages) {
    return messages.map((message)=>message.toDict());
}
function convertToChunk(message) {
    const type = message._getType();
    if (type === "human") {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HumanMessageChunk"]({
            ...message
        });
    } else if (type === "ai") {
        let aiChunkFields = {
            ...message
        };
        if ("tool_calls" in aiChunkFields) {
            aiChunkFields = {
                ...aiChunkFields,
                tool_call_chunks: aiChunkFields.tool_calls?.map((tc)=>({
                        ...tc,
                        type: "tool_call_chunk",
                        index: undefined,
                        args: JSON.stringify(tc.args)
                    }))
            };
        }
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AIMessageChunk"]({
            ...aiChunkFields
        });
    } else if (type === "system") {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemMessageChunk"]({
            ...message
        });
    } else if (type === "function") {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$function$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["FunctionMessageChunk"]({
            ...message
        });
    // eslint-disable-next-line @typescript-eslint/no-use-before-define
    } else if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatMessage"].isInstance(message)) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatMessageChunk"]({
            ...message
        });
    } else {
        throw new Error("Unknown message type.");
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/tracer.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "getDefaultLangChainClientSingleton": (()=>getDefaultLangChainClientSingleton),
    "setDefaultLangChainClientSingleton": (()=>setDefaultLangChainClientSingleton)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/langsmith@0.2.15_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/langsmith/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/env.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$client$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/langsmith@0.2.15_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/langsmith/dist/client.js [app-route] (ecmascript)");
;
;
let client;
const getDefaultLangChainClientSingleton = ()=>{
    if (client === undefined) {
        const clientParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getEnvironmentVariable"])("LANGCHAIN_CALLBACKS_BACKGROUND") === "false" ? {
            // LangSmith has its own backgrounding system
            blockOnRootRunFinalization: true
        } : {};
        client = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$client$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Client"](clientParams);
    }
    return client;
};
const setDefaultLangChainClientSingleton = (newClient)=>{
    client = newClient;
};
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/tracer_langchain.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "LangChainTracer": (()=>LangChainTracer)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$run_trees$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/langsmith@0.2.15_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/langsmith/run_trees.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$singletons$2f$traceable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/langsmith@0.2.15_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/langsmith/singletons/traceable.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/env.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$tracer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/tracer.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$run_trees$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/langsmith@0.2.15_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/langsmith/dist/run_trees.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$singletons$2f$traceable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/langsmith@0.2.15_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/langsmith/dist/singletons/traceable.js [app-route] (ecmascript)");
;
;
;
;
;
class LangChainTracer extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseTracer"] {
    constructor(fields = {}){
        super(fields);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "langchain_tracer"
        });
        Object.defineProperty(this, "projectName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "exampleId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "client", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        const { exampleId, projectName, client } = fields;
        this.projectName = projectName ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getEnvironmentVariable"])("LANGCHAIN_PROJECT") ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getEnvironmentVariable"])("LANGCHAIN_SESSION");
        this.exampleId = exampleId;
        this.client = client ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$tracer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDefaultLangChainClientSingleton"])();
        const traceableTree = LangChainTracer.getTraceableRunTree();
        if (traceableTree) {
            this.updateFromRunTree(traceableTree);
        }
    }
    async _convertToCreate(run, example_id = undefined) {
        return {
            ...run,
            extra: {
                ...run.extra,
                runtime: await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRuntimeEnvironment"])()
            },
            child_runs: undefined,
            session_name: this.projectName,
            reference_example_id: run.parent_run_id ? undefined : example_id
        };
    }
    async persistRun(_run) {}
    async onRunCreate(run) {
        const persistedRun = await this._convertToCreate(run, this.exampleId);
        await this.client.createRun(persistedRun);
    }
    async onRunUpdate(run) {
        const runUpdate = {
            end_time: run.end_time,
            error: run.error,
            outputs: run.outputs,
            events: run.events,
            inputs: run.inputs,
            trace_id: run.trace_id,
            dotted_order: run.dotted_order,
            parent_run_id: run.parent_run_id
        };
        await this.client.updateRun(run.id, runUpdate);
    }
    getRun(id) {
        return this.runMap.get(id);
    }
    updateFromRunTree(runTree) {
        let rootRun = runTree;
        const visited = new Set();
        while(rootRun.parent_run){
            if (visited.has(rootRun.id)) break;
            visited.add(rootRun.id);
            if (!rootRun.parent_run) break;
            rootRun = rootRun.parent_run;
        }
        visited.clear();
        const queue = [
            rootRun
        ];
        while(queue.length > 0){
            const current = queue.shift();
            if (!current || visited.has(current.id)) continue;
            visited.add(current.id);
            // @ts-expect-error Types of property 'events' are incompatible.
            this.runMap.set(current.id, current);
            if (current.child_runs) {
                queue.push(...current.child_runs);
            }
        }
        this.client = runTree.client ?? this.client;
        this.projectName = runTree.project_name ?? this.projectName;
        this.exampleId = runTree.reference_example_id ?? this.exampleId;
    }
    convertToRunTree(id) {
        const runTreeMap = {};
        const runTreeList = [];
        for (const [id, run] of this.runMap){
            // by converting the run map to a run tree, we are doing a copy
            // thus, any mutation performed on the run tree will not be reflected
            // back in the run map
            // TODO: Stop using `this.runMap` in favour of LangSmith's `RunTree`
            const runTree = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$run_trees$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RunTree"]({
                ...run,
                child_runs: [],
                parent_run: undefined,
                // inherited properties
                client: this.client,
                project_name: this.projectName,
                reference_example_id: this.exampleId,
                tracingEnabled: true
            });
            runTreeMap[id] = runTree;
            runTreeList.push([
                id,
                run.dotted_order
            ]);
        }
        runTreeList.sort((a, b)=>{
            if (!a[1] || !b[1]) return 0;
            return a[1].localeCompare(b[1]);
        });
        for (const [id] of runTreeList){
            const run = this.runMap.get(id);
            const runTree = runTreeMap[id];
            if (!run || !runTree) continue;
            if (run.parent_run_id) {
                const parentRunTree = runTreeMap[run.parent_run_id];
                if (parentRunTree) {
                    parentRunTree.child_runs.push(runTree);
                    runTree.parent_run = parentRunTree;
                }
            }
        }
        return runTreeMap[id];
    }
    static getTraceableRunTree() {
        try {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$singletons$2f$traceable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCurrentRunTree"])();
        } catch  {
            return undefined;
        }
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/async_local_storage/globals.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "TRACING_ALS_KEY": (()=>TRACING_ALS_KEY),
    "_CONTEXT_VARIABLES_KEY": (()=>_CONTEXT_VARIABLES_KEY),
    "getGlobalAsyncLocalStorageInstance": (()=>getGlobalAsyncLocalStorageInstance),
    "setGlobalAsyncLocalStorageInstance": (()=>setGlobalAsyncLocalStorageInstance)
});
const TRACING_ALS_KEY = Symbol.for("ls:tracing_async_local_storage");
const _CONTEXT_VARIABLES_KEY = Symbol.for("lc:context_variables");
const setGlobalAsyncLocalStorageInstance = (instance)=>{
    globalThis[TRACING_ALS_KEY] = instance;
};
const getGlobalAsyncLocalStorageInstance = ()=>{
    return globalThis[TRACING_ALS_KEY];
};
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/callbacks.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable @typescript-eslint/no-explicit-any */ __turbopack_esm__({
    "awaitAllCallbacks": (()=>awaitAllCallbacks),
    "consumeCallback": (()=>consumeCallback),
    "getQueue": (()=>getQueue)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$p$2d$queue$40$6$2e$6$2e$2$2f$node_modules$2f$p$2d$queue$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/p-queue@6.6.2/node_modules/p-queue/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/async_local_storage/globals.js [app-route] (ecmascript)");
;
;
let queue;
/**
 * Creates a queue using the p-queue library. The queue is configured to
 * auto-start and has a concurrency of 1, meaning it will process tasks
 * one at a time.
 */ function createQueue() {
    const PQueue = "default" in __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$p$2d$queue$40$6$2e$6$2e$2$2f$node_modules$2f$p$2d$queue$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"] ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$p$2d$queue$40$6$2e$6$2e$2$2f$node_modules$2f$p$2d$queue$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].default : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$p$2d$queue$40$6$2e$6$2e$2$2f$node_modules$2f$p$2d$queue$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"];
    return new PQueue({
        autoStart: true,
        concurrency: 1
    });
}
function getQueue() {
    if (typeof queue === "undefined") {
        queue = createQueue();
    }
    return queue;
}
async function consumeCallback(promiseFn, wait) {
    if (wait === true) {
        // Clear config since callbacks are not part of the root run
        // Avoid using global singleton due to circuluar dependency issues
        const asyncLocalStorageInstance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGlobalAsyncLocalStorageInstance"])();
        if (asyncLocalStorageInstance !== undefined) {
            await asyncLocalStorageInstance.run(undefined, async ()=>promiseFn());
        } else {
            await promiseFn();
        }
    } else {
        queue = getQueue();
        void queue.add(async ()=>{
            const asyncLocalStorageInstance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGlobalAsyncLocalStorageInstance"])();
            if (asyncLocalStorageInstance !== undefined) {
                await asyncLocalStorageInstance.run(undefined, async ()=>promiseFn());
            } else {
                await promiseFn();
            }
        });
    }
}
function awaitAllCallbacks() {
    return typeof queue !== "undefined" ? queue.onIdle() : Promise.resolve();
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/callbacks/promises.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/callbacks/promises.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/callbacks.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$promises$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/callbacks/promises.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/callbacks.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "isTracingEnabled": (()=>isTracingEnabled)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/env.js [app-route] (ecmascript)");
;
const isTracingEnabled = (tracingEnabled)=>{
    if (tracingEnabled !== undefined) {
        return tracingEnabled;
    }
    const envVars = [
        "LANGSMITH_TRACING_V2",
        "LANGCHAIN_TRACING_V2",
        "LANGSMITH_TRACING",
        "LANGCHAIN_TRACING"
    ];
    return !!envVars.find((envVar)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getEnvironmentVariable"])(envVar) === "true");
};
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/async_local_storage/context.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "_getConfigureHooks": (()=>_getConfigureHooks),
    "getContextVariable": (()=>getContextVariable),
    "registerConfigureHook": (()=>registerConfigureHook),
    "setContextVariable": (()=>setContextVariable)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$run_trees$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/langsmith@0.2.15_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/langsmith/run_trees.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/async_local_storage/globals.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$run_trees$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/langsmith@0.2.15_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/langsmith/dist/run_trees.js [app-route] (ecmascript)");
;
;
function setContextVariable(name, value) {
    // Avoid using global singleton due to circuluar dependency issues
    const asyncLocalStorageInstance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGlobalAsyncLocalStorageInstance"])();
    if (asyncLocalStorageInstance === undefined) {
        throw new Error(`Internal error: Global shared async local storage instance has not been initialized.`);
    }
    const runTree = asyncLocalStorageInstance.getStore();
    const contextVars = {
        ...runTree?.[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_CONTEXT_VARIABLES_KEY"]]
    };
    contextVars[name] = value;
    let newValue = {};
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$run_trees$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isRunTree"])(runTree)) {
        newValue = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$run_trees$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RunTree"](runTree);
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    newValue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_CONTEXT_VARIABLES_KEY"]] = contextVars;
    asyncLocalStorageInstance.enterWith(newValue);
}
function getContextVariable(name) {
    // Avoid using global singleton due to circuluar dependency issues
    const asyncLocalStorageInstance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGlobalAsyncLocalStorageInstance"])();
    if (asyncLocalStorageInstance === undefined) {
        return undefined;
    }
    const runTree = asyncLocalStorageInstance.getStore();
    return runTree?.[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_CONTEXT_VARIABLES_KEY"]]?.[name];
}
const LC_CONFIGURE_HOOKS_KEY = Symbol("lc:configure_hooks");
const _getConfigureHooks = ()=>getContextVariable(LC_CONFIGURE_HOOKS_KEY) || [];
const registerConfigureHook = (config)=>{
    if (config.envVar && !config.handlerClass) {
        throw new Error("If envVar is set, handlerClass must also be set to a non-None value.");
    }
    setContextVariable(LC_CONFIGURE_HOOKS_KEY, [
        ..._getConfigureHooks(),
        config
    ]);
};
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/callbacks/manager.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "BaseCallbackManager": (()=>BaseCallbackManager),
    "BaseRunManager": (()=>BaseRunManager),
    "CallbackManager": (()=>CallbackManager),
    "CallbackManagerForChainRun": (()=>CallbackManagerForChainRun),
    "CallbackManagerForLLMRun": (()=>CallbackManagerForLLMRun),
    "CallbackManagerForRetrieverRun": (()=>CallbackManagerForRetrieverRun),
    "CallbackManagerForToolRun": (()=>CallbackManagerForToolRun),
    "TraceGroup": (()=>TraceGroup),
    "ensureHandler": (()=>ensureHandler),
    "parseCallbackConfigArg": (()=>parseCallbackConfigArg),
    "traceAsGroup": (()=>traceAsGroup)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/callbacks/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$console$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/console.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/env.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$tracer_langchain$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/tracer_langchain.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$promises$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/callbacks/promises.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/callbacks.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$context$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/async_local_storage/context.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/callbacks.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/uuid@10.0.0/node_modules/uuid/dist/esm-node/v4.js [app-route] (ecmascript) <export default as v4>");
;
;
;
;
;
;
;
;
;
;
function parseCallbackConfigArg(arg) {
    if (!arg) {
        return {};
    } else if (Array.isArray(arg) || "name" in arg) {
        return {
            callbacks: arg
        };
    } else {
        return arg;
    }
}
class BaseCallbackManager {
    setHandler(handler) {
        return this.setHandlers([
            handler
        ]);
    }
}
class BaseRunManager {
    constructor(runId, handlers, inheritableHandlers, tags, inheritableTags, metadata, inheritableMetadata, _parentRunId){
        Object.defineProperty(this, "runId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: runId
        });
        Object.defineProperty(this, "handlers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: handlers
        });
        Object.defineProperty(this, "inheritableHandlers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: inheritableHandlers
        });
        Object.defineProperty(this, "tags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: tags
        });
        Object.defineProperty(this, "inheritableTags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: inheritableTags
        });
        Object.defineProperty(this, "metadata", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: metadata
        });
        Object.defineProperty(this, "inheritableMetadata", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: inheritableMetadata
        });
        Object.defineProperty(this, "_parentRunId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: _parentRunId
        });
    }
    get parentRunId() {
        return this._parentRunId;
    }
    async handleText(text) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                try {
                    await handler.handleText?.(text, this.runId, this._parentRunId, this.tags);
                } catch (err) {
                    const logFunction = handler.raiseError ? console.error : console.warn;
                    logFunction(`Error in handler ${handler.constructor.name}, handleText: ${err}`);
                    if (handler.raiseError) {
                        throw err;
                    }
                }
            }, handler.awaitHandlers)));
    }
    async handleCustomEvent(eventName, // eslint-disable-next-line @typescript-eslint/no-explicit-any
    data, _runId, _tags, // eslint-disable-next-line @typescript-eslint/no-explicit-any
    _metadata) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                try {
                    await handler.handleCustomEvent?.(eventName, data, this.runId, this.tags, this.metadata);
                } catch (err) {
                    const logFunction = handler.raiseError ? console.error : console.warn;
                    logFunction(`Error in handler ${handler.constructor.name}, handleCustomEvent: ${err}`);
                    if (handler.raiseError) {
                        throw err;
                    }
                }
            }, handler.awaitHandlers)));
    }
}
class CallbackManagerForRetrieverRun extends BaseRunManager {
    getChild(tag) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        const manager = new CallbackManager(this.runId);
        manager.setHandlers(this.inheritableHandlers);
        manager.addTags(this.inheritableTags);
        manager.addMetadata(this.inheritableMetadata);
        if (tag) {
            manager.addTags([
                tag
            ], false);
        }
        return manager;
    }
    async handleRetrieverEnd(documents) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                if (!handler.ignoreRetriever) {
                    try {
                        await handler.handleRetrieverEnd?.(documents, this.runId, this._parentRunId, this.tags);
                    } catch (err) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleRetriever`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }
            }, handler.awaitHandlers)));
    }
    async handleRetrieverError(err) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                if (!handler.ignoreRetriever) {
                    try {
                        await handler.handleRetrieverError?.(err, this.runId, this._parentRunId, this.tags);
                    } catch (error) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleRetrieverError: ${error}`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }
            }, handler.awaitHandlers)));
    }
}
class CallbackManagerForLLMRun extends BaseRunManager {
    async handleLLMNewToken(token, idx, _runId, _parentRunId, _tags, fields) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                if (!handler.ignoreLLM) {
                    try {
                        await handler.handleLLMNewToken?.(token, idx ?? {
                            prompt: 0,
                            completion: 0
                        }, this.runId, this._parentRunId, this.tags, fields);
                    } catch (err) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleLLMNewToken: ${err}`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }
            }, handler.awaitHandlers)));
    }
    async handleLLMError(err) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                if (!handler.ignoreLLM) {
                    try {
                        await handler.handleLLMError?.(err, this.runId, this._parentRunId, this.tags);
                    } catch (err) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleLLMError: ${err}`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }
            }, handler.awaitHandlers)));
    }
    async handleLLMEnd(output) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                if (!handler.ignoreLLM) {
                    try {
                        await handler.handleLLMEnd?.(output, this.runId, this._parentRunId, this.tags);
                    } catch (err) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleLLMEnd: ${err}`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }
            }, handler.awaitHandlers)));
    }
}
class CallbackManagerForChainRun extends BaseRunManager {
    getChild(tag) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        const manager = new CallbackManager(this.runId);
        manager.setHandlers(this.inheritableHandlers);
        manager.addTags(this.inheritableTags);
        manager.addMetadata(this.inheritableMetadata);
        if (tag) {
            manager.addTags([
                tag
            ], false);
        }
        return manager;
    }
    async handleChainError(err, _runId, _parentRunId, _tags, kwargs) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                if (!handler.ignoreChain) {
                    try {
                        await handler.handleChainError?.(err, this.runId, this._parentRunId, this.tags, kwargs);
                    } catch (err) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleChainError: ${err}`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }
            }, handler.awaitHandlers)));
    }
    async handleChainEnd(output, _runId, _parentRunId, _tags, kwargs) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                if (!handler.ignoreChain) {
                    try {
                        await handler.handleChainEnd?.(output, this.runId, this._parentRunId, this.tags, kwargs);
                    } catch (err) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleChainEnd: ${err}`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }
            }, handler.awaitHandlers)));
    }
    async handleAgentAction(action) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                if (!handler.ignoreAgent) {
                    try {
                        await handler.handleAgentAction?.(action, this.runId, this._parentRunId, this.tags);
                    } catch (err) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleAgentAction: ${err}`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }
            }, handler.awaitHandlers)));
    }
    async handleAgentEnd(action) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                if (!handler.ignoreAgent) {
                    try {
                        await handler.handleAgentEnd?.(action, this.runId, this._parentRunId, this.tags);
                    } catch (err) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleAgentEnd: ${err}`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }
            }, handler.awaitHandlers)));
    }
}
class CallbackManagerForToolRun extends BaseRunManager {
    getChild(tag) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        const manager = new CallbackManager(this.runId);
        manager.setHandlers(this.inheritableHandlers);
        manager.addTags(this.inheritableTags);
        manager.addMetadata(this.inheritableMetadata);
        if (tag) {
            manager.addTags([
                tag
            ], false);
        }
        return manager;
    }
    async handleToolError(err) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                if (!handler.ignoreAgent) {
                    try {
                        await handler.handleToolError?.(err, this.runId, this._parentRunId, this.tags);
                    } catch (err) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleToolError: ${err}`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }
            }, handler.awaitHandlers)));
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async handleToolEnd(output) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                if (!handler.ignoreAgent) {
                    try {
                        await handler.handleToolEnd?.(output, this.runId, this._parentRunId, this.tags);
                    } catch (err) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleToolEnd: ${err}`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }
            }, handler.awaitHandlers)));
    }
}
class CallbackManager extends BaseCallbackManager {
    constructor(parentRunId, options){
        super();
        Object.defineProperty(this, "handlers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "inheritableHandlers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "tags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "inheritableTags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "metadata", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: {}
        });
        Object.defineProperty(this, "inheritableMetadata", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: {}
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "callback_manager"
        });
        Object.defineProperty(this, "_parentRunId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.handlers = options?.handlers ?? this.handlers;
        this.inheritableHandlers = options?.inheritableHandlers ?? this.inheritableHandlers;
        this.tags = options?.tags ?? this.tags;
        this.inheritableTags = options?.inheritableTags ?? this.inheritableTags;
        this.metadata = options?.metadata ?? this.metadata;
        this.inheritableMetadata = options?.inheritableMetadata ?? this.inheritableMetadata;
        this._parentRunId = parentRunId;
    }
    /**
     * Gets the parent run ID, if any.
     *
     * @returns The parent run ID.
     */ getParentRunId() {
        return this._parentRunId;
    }
    async handleLLMStart(llm, prompts, runId = undefined, _parentRunId = undefined, extraParams = undefined, _tags = undefined, _metadata = undefined, runName = undefined) {
        return Promise.all(prompts.map(async (prompt, idx)=>{
            // Can't have duplicate runs with the same run ID (if provided)
            const runId_ = idx === 0 && runId ? runId : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])();
            await Promise.all(this.handlers.map((handler)=>{
                if (handler.ignoreLLM) {
                    return;
                }
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseTracer"])(handler)) {
                    // Create and add run to the run map.
                    // We do this synchronously to avoid race conditions
                    // when callbacks are backgrounded.
                    handler._createRunForLLMStart(llm, [
                        prompt
                    ], runId_, this._parentRunId, extraParams, this.tags, this.metadata, runName);
                }
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                    try {
                        await handler.handleLLMStart?.(llm, [
                            prompt
                        ], runId_, this._parentRunId, extraParams, this.tags, this.metadata, runName);
                    } catch (err) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleLLMStart: ${err}`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }, handler.awaitHandlers);
            }));
            return new CallbackManagerForLLMRun(runId_, this.handlers, this.inheritableHandlers, this.tags, this.inheritableTags, this.metadata, this.inheritableMetadata, this._parentRunId);
        }));
    }
    async handleChatModelStart(llm, messages, runId = undefined, _parentRunId = undefined, extraParams = undefined, _tags = undefined, _metadata = undefined, runName = undefined) {
        return Promise.all(messages.map(async (messageGroup, idx)=>{
            // Can't have duplicate runs with the same run ID (if provided)
            const runId_ = idx === 0 && runId ? runId : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])();
            await Promise.all(this.handlers.map((handler)=>{
                if (handler.ignoreLLM) {
                    return;
                }
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseTracer"])(handler)) {
                    // Create and add run to the run map.
                    // We do this synchronously to avoid race conditions
                    // when callbacks are backgrounded.
                    handler._createRunForChatModelStart(llm, [
                        messageGroup
                    ], runId_, this._parentRunId, extraParams, this.tags, this.metadata, runName);
                }
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                    try {
                        if (handler.handleChatModelStart) {
                            await handler.handleChatModelStart?.(llm, [
                                messageGroup
                            ], runId_, this._parentRunId, extraParams, this.tags, this.metadata, runName);
                        } else if (handler.handleLLMStart) {
                            const messageString = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getBufferString"])(messageGroup);
                            await handler.handleLLMStart?.(llm, [
                                messageString
                            ], runId_, this._parentRunId, extraParams, this.tags, this.metadata, runName);
                        }
                    } catch (err) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleLLMStart: ${err}`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }, handler.awaitHandlers);
            }));
            return new CallbackManagerForLLMRun(runId_, this.handlers, this.inheritableHandlers, this.tags, this.inheritableTags, this.metadata, this.inheritableMetadata, this._parentRunId);
        }));
    }
    async handleChainStart(chain, inputs, runId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])(), runType = undefined, _tags = undefined, _metadata = undefined, runName = undefined) {
        await Promise.all(this.handlers.map((handler)=>{
            if (handler.ignoreChain) {
                return;
            }
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseTracer"])(handler)) {
                // Create and add run to the run map.
                // We do this synchronously to avoid race conditions
                // when callbacks are backgrounded.
                handler._createRunForChainStart(chain, inputs, runId, this._parentRunId, this.tags, this.metadata, runType, runName);
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                try {
                    await handler.handleChainStart?.(chain, inputs, runId, this._parentRunId, this.tags, this.metadata, runType, runName);
                } catch (err) {
                    const logFunction = handler.raiseError ? console.error : console.warn;
                    logFunction(`Error in handler ${handler.constructor.name}, handleChainStart: ${err}`);
                    if (handler.raiseError) {
                        throw err;
                    }
                }
            }, handler.awaitHandlers);
        }));
        return new CallbackManagerForChainRun(runId, this.handlers, this.inheritableHandlers, this.tags, this.inheritableTags, this.metadata, this.inheritableMetadata, this._parentRunId);
    }
    async handleToolStart(tool, input, runId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])(), _parentRunId = undefined, _tags = undefined, _metadata = undefined, runName = undefined) {
        await Promise.all(this.handlers.map((handler)=>{
            if (handler.ignoreAgent) {
                return;
            }
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseTracer"])(handler)) {
                // Create and add run to the run map.
                // We do this synchronously to avoid race conditions
                // when callbacks are backgrounded.
                handler._createRunForToolStart(tool, input, runId, this._parentRunId, this.tags, this.metadata, runName);
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                try {
                    await handler.handleToolStart?.(tool, input, runId, this._parentRunId, this.tags, this.metadata, runName);
                } catch (err) {
                    const logFunction = handler.raiseError ? console.error : console.warn;
                    logFunction(`Error in handler ${handler.constructor.name}, handleToolStart: ${err}`);
                    if (handler.raiseError) {
                        throw err;
                    }
                }
            }, handler.awaitHandlers);
        }));
        return new CallbackManagerForToolRun(runId, this.handlers, this.inheritableHandlers, this.tags, this.inheritableTags, this.metadata, this.inheritableMetadata, this._parentRunId);
    }
    async handleRetrieverStart(retriever, query, runId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])(), _parentRunId = undefined, _tags = undefined, _metadata = undefined, runName = undefined) {
        await Promise.all(this.handlers.map((handler)=>{
            if (handler.ignoreRetriever) {
                return;
            }
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseTracer"])(handler)) {
                // Create and add run to the run map.
                // We do this synchronously to avoid race conditions
                // when callbacks are backgrounded.
                handler._createRunForRetrieverStart(retriever, query, runId, this._parentRunId, this.tags, this.metadata, runName);
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                try {
                    await handler.handleRetrieverStart?.(retriever, query, runId, this._parentRunId, this.tags, this.metadata, runName);
                } catch (err) {
                    const logFunction = handler.raiseError ? console.error : console.warn;
                    logFunction(`Error in handler ${handler.constructor.name}, handleRetrieverStart: ${err}`);
                    if (handler.raiseError) {
                        throw err;
                    }
                }
            }, handler.awaitHandlers);
        }));
        return new CallbackManagerForRetrieverRun(runId, this.handlers, this.inheritableHandlers, this.tags, this.inheritableTags, this.metadata, this.inheritableMetadata, this._parentRunId);
    }
    async handleCustomEvent(eventName, // eslint-disable-next-line @typescript-eslint/no-explicit-any
    data, runId, _tags, // eslint-disable-next-line @typescript-eslint/no-explicit-any
    _metadata) {
        await Promise.all(this.handlers.map((handler)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeCallback"])(async ()=>{
                if (!handler.ignoreCustomEvent) {
                    try {
                        await handler.handleCustomEvent?.(eventName, data, runId, this.tags, this.metadata);
                    } catch (err) {
                        const logFunction = handler.raiseError ? console.error : console.warn;
                        logFunction(`Error in handler ${handler.constructor.name}, handleCustomEvent: ${err}`);
                        if (handler.raiseError) {
                            throw err;
                        }
                    }
                }
            }, handler.awaitHandlers)));
    }
    addHandler(handler, inherit = true) {
        this.handlers.push(handler);
        if (inherit) {
            this.inheritableHandlers.push(handler);
        }
    }
    removeHandler(handler) {
        this.handlers = this.handlers.filter((_handler)=>_handler !== handler);
        this.inheritableHandlers = this.inheritableHandlers.filter((_handler)=>_handler !== handler);
    }
    setHandlers(handlers, inherit = true) {
        this.handlers = [];
        this.inheritableHandlers = [];
        for (const handler of handlers){
            this.addHandler(handler, inherit);
        }
    }
    addTags(tags, inherit = true) {
        this.removeTags(tags); // Remove duplicates
        this.tags.push(...tags);
        if (inherit) {
            this.inheritableTags.push(...tags);
        }
    }
    removeTags(tags) {
        this.tags = this.tags.filter((tag)=>!tags.includes(tag));
        this.inheritableTags = this.inheritableTags.filter((tag)=>!tags.includes(tag));
    }
    addMetadata(metadata, inherit = true) {
        this.metadata = {
            ...this.metadata,
            ...metadata
        };
        if (inherit) {
            this.inheritableMetadata = {
                ...this.inheritableMetadata,
                ...metadata
            };
        }
    }
    removeMetadata(metadata) {
        for (const key of Object.keys(metadata)){
            delete this.metadata[key];
            delete this.inheritableMetadata[key];
        }
    }
    copy(additionalHandlers = [], inherit = true) {
        const manager = new CallbackManager(this._parentRunId);
        for (const handler of this.handlers){
            const inheritable = this.inheritableHandlers.includes(handler);
            manager.addHandler(handler, inheritable);
        }
        for (const tag of this.tags){
            const inheritable = this.inheritableTags.includes(tag);
            manager.addTags([
                tag
            ], inheritable);
        }
        for (const key of Object.keys(this.metadata)){
            const inheritable = Object.keys(this.inheritableMetadata).includes(key);
            manager.addMetadata({
                [key]: this.metadata[key]
            }, inheritable);
        }
        for (const handler of additionalHandlers){
            if (// Prevent multiple copies of console_callback_handler
            manager.handlers.filter((h)=>h.name === "console_callback_handler").some((h)=>h.name === handler.name)) {
                continue;
            }
            manager.addHandler(handler, inherit);
        }
        return manager;
    }
    static fromHandlers(handlers) {
        class Handler extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseCallbackHandler"] {
            constructor(){
                super();
                Object.defineProperty(this, "name", {
                    enumerable: true,
                    configurable: true,
                    writable: true,
                    value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])()
                });
                Object.assign(this, handlers);
            }
        }
        const manager = new this();
        manager.addHandler(new Handler());
        return manager;
    }
    static configure(inheritableHandlers, localHandlers, inheritableTags, localTags, inheritableMetadata, localMetadata, options) {
        return this._configureSync(inheritableHandlers, localHandlers, inheritableTags, localTags, inheritableMetadata, localMetadata, options);
    }
    // TODO: Deprecate async method in favor of this one.
    static _configureSync(inheritableHandlers, localHandlers, inheritableTags, localTags, inheritableMetadata, localMetadata, options) {
        let callbackManager;
        if (inheritableHandlers || localHandlers) {
            if (Array.isArray(inheritableHandlers) || !inheritableHandlers) {
                callbackManager = new CallbackManager();
                callbackManager.setHandlers(inheritableHandlers?.map(ensureHandler) ?? [], true);
            } else {
                callbackManager = inheritableHandlers;
            }
            callbackManager = callbackManager.copy(Array.isArray(localHandlers) ? localHandlers.map(ensureHandler) : localHandlers?.handlers, false);
        }
        const verboseEnabled = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getEnvironmentVariable"])("LANGCHAIN_VERBOSE") === "true" || options?.verbose;
        const tracingV2Enabled = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$tracer_langchain$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LangChainTracer"].getTraceableRunTree()?.tracingEnabled || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$callbacks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isTracingEnabled"])();
        const tracingEnabled = tracingV2Enabled || ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getEnvironmentVariable"])("LANGCHAIN_TRACING") ?? false);
        if (verboseEnabled || tracingEnabled) {
            if (!callbackManager) {
                callbackManager = new CallbackManager();
            }
            if (verboseEnabled && !callbackManager.handlers.some((handler)=>handler.name === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$console$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ConsoleCallbackHandler"].prototype.name)) {
                const consoleHandler = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$console$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ConsoleCallbackHandler"]();
                callbackManager.addHandler(consoleHandler, true);
            }
            if (tracingEnabled && !callbackManager.handlers.some((handler)=>handler.name === "langchain_tracer")) {
                if (tracingV2Enabled) {
                    const tracerV2 = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$tracer_langchain$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LangChainTracer"]();
                    callbackManager.addHandler(tracerV2, true);
                    // handoff between langchain and langsmith/traceable
                    // override the parent run ID
                    callbackManager._parentRunId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$tracer_langchain$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LangChainTracer"].getTraceableRunTree()?.id ?? callbackManager._parentRunId;
                }
            }
        }
        for (const { contextVar, inheritable = true, handlerClass, envVar } of (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$context$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_getConfigureHooks"])()){
            const createIfNotInContext = envVar && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getEnvironmentVariable"])(envVar) === "true" && handlerClass;
            let handler;
            const contextVarValue = contextVar !== undefined ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$context$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getContextVariable"])(contextVar) : undefined;
            if (contextVarValue && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseCallbackHandler"])(contextVarValue)) {
                handler = contextVarValue;
            } else if (createIfNotInContext) {
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                handler = new handlerClass({});
            }
            if (handler !== undefined) {
                if (!callbackManager) {
                    callbackManager = new CallbackManager();
                }
                if (!callbackManager.handlers.some((h)=>h.name === handler.name)) {
                    callbackManager.addHandler(handler, inheritable);
                }
            }
        }
        if (inheritableTags || localTags) {
            if (callbackManager) {
                callbackManager.addTags(inheritableTags ?? []);
                callbackManager.addTags(localTags ?? [], false);
            }
        }
        if (inheritableMetadata || localMetadata) {
            if (callbackManager) {
                callbackManager.addMetadata(inheritableMetadata ?? {});
                callbackManager.addMetadata(localMetadata ?? {}, false);
            }
        }
        return callbackManager;
    }
}
function ensureHandler(handler) {
    if ("name" in handler) {
        return handler;
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseCallbackHandler"].fromMethods(handler);
}
class TraceGroup {
    constructor(groupName, options){
        Object.defineProperty(this, "groupName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: groupName
        });
        Object.defineProperty(this, "options", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: options
        });
        Object.defineProperty(this, "runManager", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    async getTraceGroupCallbackManager(group_name, inputs, options) {
        const cb = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$tracer_langchain$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LangChainTracer"](options);
        const cm = await CallbackManager.configure([
            cb
        ]);
        const runManager = await cm?.handleChainStart({
            lc: 1,
            type: "not_implemented",
            id: [
                "langchain",
                "callbacks",
                "groups",
                group_name
            ]
        }, inputs ?? {});
        if (!runManager) {
            throw new Error("Failed to create run group callback manager.");
        }
        return runManager;
    }
    async start(inputs) {
        if (!this.runManager) {
            this.runManager = await this.getTraceGroupCallbackManager(this.groupName, inputs, this.options);
        }
        return this.runManager.getChild();
    }
    async error(err) {
        if (this.runManager) {
            await this.runManager.handleChainError(err);
            this.runManager = undefined;
        }
    }
    async end(output) {
        if (this.runManager) {
            await this.runManager.handleChainEnd(output ?? {});
            this.runManager = undefined;
        }
    }
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function _coerceToDict(value, defaultKey) {
    return value && !Array.isArray(value) && typeof value === "object" ? value : {
        [defaultKey]: value
    };
}
async function traceAsGroup(groupOptions, enclosedCode, ...args) {
    const traceGroup = new TraceGroup(groupOptions.name, groupOptions);
    const callbackManager = await traceGroup.start({
        ...args
    });
    try {
        const result = await enclosedCode(callbackManager, ...args);
        await traceGroup.end(_coerceToDict(result, "output"));
        return result;
    } catch (err) {
        await traceGroup.error(err);
        throw err;
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/async_local_storage/index.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable @typescript-eslint/no-explicit-any */ __turbopack_esm__({
    "AsyncLocalStorageProviderSingleton": (()=>AsyncLocalStorageProviderSingleton),
    "MockAsyncLocalStorage": (()=>MockAsyncLocalStorage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/langsmith@0.2.15_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/langsmith/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/async_local_storage/globals.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$manager$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/callbacks/manager.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$run_trees$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/langsmith@0.2.15_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/langsmith/dist/run_trees.js [app-route] (ecmascript)");
;
;
;
class MockAsyncLocalStorage {
    getStore() {
        return undefined;
    }
    run(_store, callback) {
        return callback();
    }
    enterWith(_store) {
        return undefined;
    }
}
const mockAsyncLocalStorage = new MockAsyncLocalStorage();
const LC_CHILD_KEY = Symbol.for("lc:child_config");
class AsyncLocalStorageProvider {
    getInstance() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGlobalAsyncLocalStorageInstance"])() ?? mockAsyncLocalStorage;
    }
    getRunnableConfig() {
        const storage = this.getInstance();
        // this has the runnable config
        // which means that we should also have an instance of a LangChainTracer
        // with the run map prepopulated
        return storage.getStore()?.extra?.[LC_CHILD_KEY];
    }
    runWithConfig(config, callback, avoidCreatingRootRunTree) {
        const callbackManager = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$manager$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CallbackManager"]._configureSync(config?.callbacks, undefined, config?.tags, undefined, config?.metadata);
        const storage = this.getInstance();
        const previousValue = storage.getStore();
        const parentRunId = callbackManager?.getParentRunId();
        const langChainTracer = callbackManager?.handlers?.find((handler)=>handler?.name === "langchain_tracer");
        let runTree;
        if (langChainTracer && parentRunId) {
            runTree = langChainTracer.convertToRunTree(parentRunId);
        } else if (!avoidCreatingRootRunTree) {
            runTree = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$run_trees$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RunTree"]({
                name: "<runnable_lambda>",
                tracingEnabled: false
            });
        }
        if (runTree) {
            runTree.extra = {
                ...runTree.extra,
                [LC_CHILD_KEY]: config
            };
        }
        if (previousValue !== undefined && previousValue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_CONTEXT_VARIABLES_KEY"]] !== undefined) {
            runTree[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_CONTEXT_VARIABLES_KEY"]] = previousValue[__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_CONTEXT_VARIABLES_KEY"]];
        }
        return storage.run(runTree, callback);
    }
    initializeGlobalInstance(instance) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getGlobalAsyncLocalStorageInstance"])() === undefined) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["setGlobalAsyncLocalStorageInstance"])(instance);
        }
    }
}
const AsyncLocalStorageProviderSingleton = new AsyncLocalStorageProvider();
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/index.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
;
;
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/index.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/async_local_storage/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$globals$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/async_local_storage/globals.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/index.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/config.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "DEFAULT_RECURSION_LIMIT": (()=>DEFAULT_RECURSION_LIMIT),
    "ensureConfig": (()=>ensureConfig),
    "getCallbackManagerForConfig": (()=>getCallbackManagerForConfig),
    "mergeConfigs": (()=>mergeConfigs),
    "patchConfig": (()=>patchConfig),
    "pickRunnableConfigKeys": (()=>pickRunnableConfigKeys)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$manager$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/callbacks/manager.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/async_local_storage/index.js [app-route] (ecmascript)");
;
;
const DEFAULT_RECURSION_LIMIT = 25;
async function getCallbackManagerForConfig(config) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$manager$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CallbackManager"]._configureSync(config?.callbacks, undefined, config?.tags, undefined, config?.metadata);
}
function mergeConfigs(...configs) {
    // We do not want to call ensureConfig on the empty state here as this may cause
    // double loading of callbacks if async local storage is being used.
    const copy = {};
    for (const options of configs.filter((c)=>!!c)){
        for (const key of Object.keys(options)){
            if (key === "metadata") {
                copy[key] = {
                    ...copy[key],
                    ...options[key]
                };
            } else if (key === "tags") {
                const baseKeys = copy[key] ?? [];
                copy[key] = [
                    ...new Set(baseKeys.concat(options[key] ?? []))
                ];
            } else if (key === "configurable") {
                copy[key] = {
                    ...copy[key],
                    ...options[key]
                };
            } else if (key === "timeout") {
                if (copy.timeout === undefined) {
                    copy.timeout = options.timeout;
                } else if (options.timeout !== undefined) {
                    copy.timeout = Math.min(copy.timeout, options.timeout);
                }
            } else if (key === "signal") {
                if (copy.signal === undefined) {
                    copy.signal = options.signal;
                } else if (options.signal !== undefined) {
                    if ("any" in AbortSignal) {
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        copy.signal = AbortSignal.any([
                            copy.signal,
                            options.signal
                        ]);
                    } else {
                        copy.signal = options.signal;
                    }
                }
            } else if (key === "callbacks") {
                const baseCallbacks = copy.callbacks;
                const providedCallbacks = options.callbacks;
                // callbacks can be either undefined, Array<handler> or manager
                // so merging two callbacks values has 6 cases
                if (Array.isArray(providedCallbacks)) {
                    if (!baseCallbacks) {
                        copy.callbacks = providedCallbacks;
                    } else if (Array.isArray(baseCallbacks)) {
                        copy.callbacks = baseCallbacks.concat(providedCallbacks);
                    } else {
                        // baseCallbacks is a manager
                        const manager = baseCallbacks.copy();
                        for (const callback of providedCallbacks){
                            manager.addHandler((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$manager$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureHandler"])(callback), true);
                        }
                        copy.callbacks = manager;
                    }
                } else if (providedCallbacks) {
                    // providedCallbacks is a manager
                    if (!baseCallbacks) {
                        copy.callbacks = providedCallbacks;
                    } else if (Array.isArray(baseCallbacks)) {
                        const manager = providedCallbacks.copy();
                        for (const callback of baseCallbacks){
                            manager.addHandler((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$manager$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureHandler"])(callback), true);
                        }
                        copy.callbacks = manager;
                    } else {
                        // baseCallbacks is also a manager
                        copy.callbacks = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$manager$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["CallbackManager"](providedCallbacks._parentRunId, {
                            handlers: baseCallbacks.handlers.concat(providedCallbacks.handlers),
                            inheritableHandlers: baseCallbacks.inheritableHandlers.concat(providedCallbacks.inheritableHandlers),
                            tags: Array.from(new Set(baseCallbacks.tags.concat(providedCallbacks.tags))),
                            inheritableTags: Array.from(new Set(baseCallbacks.inheritableTags.concat(providedCallbacks.inheritableTags))),
                            metadata: {
                                ...baseCallbacks.metadata,
                                ...providedCallbacks.metadata
                            }
                        });
                    }
                }
            } else {
                const typedKey = key;
                copy[typedKey] = options[typedKey] ?? copy[typedKey];
            }
        }
    }
    return copy;
}
const PRIMITIVES = new Set([
    "string",
    "number",
    "boolean"
]);
function ensureConfig(config) {
    const implicitConfig = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncLocalStorageProviderSingleton"].getRunnableConfig();
    let empty = {
        tags: [],
        metadata: {},
        recursionLimit: 25,
        runId: undefined
    };
    if (implicitConfig) {
        // Don't allow runId and runName to be loaded implicitly, as this can cause
        // child runs to improperly inherit their parents' run ids.
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { runId, runName, ...rest } = implicitConfig;
        empty = Object.entries(rest).reduce(// eslint-disable-next-line @typescript-eslint/no-explicit-any
        (currentConfig, [key, value])=>{
            if (value !== undefined) {
                // eslint-disable-next-line no-param-reassign
                currentConfig[key] = value;
            }
            return currentConfig;
        }, empty);
    }
    if (config) {
        empty = Object.entries(config).reduce(// eslint-disable-next-line @typescript-eslint/no-explicit-any
        (currentConfig, [key, value])=>{
            if (value !== undefined) {
                // eslint-disable-next-line no-param-reassign
                currentConfig[key] = value;
            }
            return currentConfig;
        }, empty);
    }
    if (empty?.configurable) {
        for (const key of Object.keys(empty.configurable)){
            if (PRIMITIVES.has(typeof empty.configurable[key]) && !empty.metadata?.[key]) {
                if (!empty.metadata) {
                    empty.metadata = {};
                }
                empty.metadata[key] = empty.configurable[key];
            }
        }
    }
    if (empty.timeout !== undefined) {
        if (empty.timeout <= 0) {
            throw new Error("Timeout must be a positive number");
        }
        const timeoutSignal = AbortSignal.timeout(empty.timeout);
        if (empty.signal !== undefined) {
            if ("any" in AbortSignal) {
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                empty.signal = AbortSignal.any([
                    empty.signal,
                    timeoutSignal
                ]);
            }
        } else {
            empty.signal = timeoutSignal;
        }
        delete empty.timeout;
    }
    return empty;
}
function patchConfig(config = {}, { callbacks, maxConcurrency, recursionLimit, runName, configurable, runId } = {}) {
    const newConfig = ensureConfig(config);
    if (callbacks !== undefined) {
        /**
         * If we're replacing callbacks we need to unset runName
         * since that should apply only to the same run as the original callbacks
         */ delete newConfig.runName;
        newConfig.callbacks = callbacks;
    }
    if (recursionLimit !== undefined) {
        newConfig.recursionLimit = recursionLimit;
    }
    if (maxConcurrency !== undefined) {
        newConfig.maxConcurrency = maxConcurrency;
    }
    if (runName !== undefined) {
        newConfig.runName = runName;
    }
    if (configurable !== undefined) {
        newConfig.configurable = {
            ...newConfig.configurable,
            ...configurable
        };
    }
    if (runId !== undefined) {
        delete newConfig.runId;
    }
    return newConfig;
}
function pickRunnableConfigKeys(config) {
    return config ? {
        configurable: config.configurable,
        recursionLimit: config.recursionLimit,
        callbacks: config.callbacks,
        tags: config.tags,
        metadata: config.metadata,
        maxConcurrency: config.maxConcurrency,
        timeout: config.timeout,
        signal: config.signal
    } : undefined;
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/signal.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "raceWithSignal": (()=>raceWithSignal)
});
async function raceWithSignal(promise, signal) {
    if (signal === undefined) {
        return promise;
    }
    let listener;
    return Promise.race([
        promise.catch((err)=>{
            if (!signal?.aborted) {
                throw err;
            } else {
                return undefined;
            }
        }),
        new Promise((_, reject)=>{
            listener = ()=>{
                reject(new Error("Aborted"));
            };
            signal.addEventListener("abort", listener);
            // Must be here inside the promise to avoid a race condition
            if (signal.aborted) {
                reject(new Error("Aborted"));
            }
        })
    ]).finally(()=>signal.removeEventListener("abort", listener));
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/stream.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "AsyncGeneratorWithSetup": (()=>AsyncGeneratorWithSetup),
    "IterableReadableStream": (()=>IterableReadableStream),
    "atee": (()=>atee),
    "concat": (()=>concat),
    "pipeGeneratorWithSetup": (()=>pipeGeneratorWithSetup)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/config.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$signal$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/signal.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/async_local_storage/index.js [app-route] (ecmascript)");
;
;
;
class IterableReadableStream extends ReadableStream {
    constructor(){
        super(...arguments);
        Object.defineProperty(this, "reader", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    ensureReader() {
        if (!this.reader) {
            this.reader = this.getReader();
        }
    }
    async next() {
        this.ensureReader();
        try {
            const result = await this.reader.read();
            if (result.done) {
                this.reader.releaseLock(); // release lock when stream becomes closed
                return {
                    done: true,
                    value: undefined
                };
            } else {
                return {
                    done: false,
                    value: result.value
                };
            }
        } catch (e) {
            this.reader.releaseLock(); // release lock when stream becomes errored
            throw e;
        }
    }
    async return() {
        this.ensureReader();
        // If wrapped in a Node stream, cancel is already called.
        if (this.locked) {
            const cancelPromise = this.reader.cancel(); // cancel first, but don't await yet
            this.reader.releaseLock(); // release lock first
            await cancelPromise; // now await it
        }
        return {
            done: true,
            value: undefined
        };
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async throw(e) {
        this.ensureReader();
        if (this.locked) {
            const cancelPromise = this.reader.cancel(); // cancel first, but don't await yet
            this.reader.releaseLock(); // release lock first
            await cancelPromise; // now await it
        }
        throw e;
    }
    [Symbol.asyncIterator]() {
        return this;
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore Not present in Node 18 types, required in latest Node 22
    async [Symbol.asyncDispose]() {
        await this.return();
    }
    static fromReadableStream(stream) {
        // From https://developer.mozilla.org/en-US/docs/Web/API/Streams_API/Using_readable_streams#reading_the_stream
        const reader = stream.getReader();
        return new IterableReadableStream({
            start (controller) {
                return pump();
                "TURBOPACK unreachable";
                function pump() {
                    return reader.read().then(({ done, value })=>{
                        // When no more data needs to be consumed, close the stream
                        if (done) {
                            controller.close();
                            return;
                        }
                        // Enqueue the next data chunk into our target stream
                        controller.enqueue(value);
                        return pump();
                    });
                }
            },
            cancel () {
                reader.releaseLock();
            }
        });
    }
    static fromAsyncGenerator(generator) {
        return new IterableReadableStream({
            async pull (controller) {
                const { value, done } = await generator.next();
                // When no more data needs to be consumed, close the stream
                if (done) {
                    controller.close();
                }
                // Fix: `else if (value)` will hang the streaming when nullish value (e.g. empty string) is pulled
                controller.enqueue(value);
            },
            async cancel (reason) {
                await generator.return(reason);
            }
        });
    }
}
function atee(iter, length = 2) {
    const buffers = Array.from({
        length
    }, ()=>[]);
    return buffers.map(async function* makeIter(buffer) {
        while(true){
            if (buffer.length === 0) {
                const result = await iter.next();
                for (const buffer of buffers){
                    buffer.push(result);
                }
            } else if (buffer[0].done) {
                return;
            } else {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                yield buffer.shift().value;
            }
        }
    });
}
function concat(first, second) {
    if (Array.isArray(first) && Array.isArray(second)) {
        return first.concat(second);
    } else if (typeof first === "string" && typeof second === "string") {
        return first + second;
    } else if (typeof first === "number" && typeof second === "number") {
        return first + second;
    } else if (// eslint-disable-next-line @typescript-eslint/no-explicit-any
    "concat" in first && // eslint-disable-next-line @typescript-eslint/no-explicit-any
    typeof first.concat === "function") {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return first.concat(second);
    } else if (typeof first === "object" && typeof second === "object") {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const chunk = {
            ...first
        };
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        for (const [key, value] of Object.entries(second)){
            if (key in chunk && !Array.isArray(chunk[key])) {
                chunk[key] = concat(chunk[key], value);
            } else {
                chunk[key] = value;
            }
        }
        return chunk;
    } else {
        throw new Error(`Cannot concat ${typeof first} and ${typeof second}`);
    }
}
class AsyncGeneratorWithSetup {
    constructor(params){
        Object.defineProperty(this, "generator", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "setup", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "config", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "signal", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "firstResult", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "firstResultUsed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        this.generator = params.generator;
        this.config = params.config;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        this.signal = params.signal ?? this.config?.signal;
        // setup is a promise that resolves only after the first iterator value
        // is available. this is useful when setup of several piped generators
        // needs to happen in logical order, ie. in the order in which input to
        // to each generator is available.
        this.setup = new Promise((resolve, reject)=>{
            void __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncLocalStorageProviderSingleton"].runWithConfig((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["pickRunnableConfigKeys"])(params.config), async ()=>{
                this.firstResult = params.generator.next();
                if (params.startSetup) {
                    this.firstResult.then(params.startSetup).then(resolve, reject);
                } else {
                    this.firstResult.then((_result)=>resolve(undefined), reject);
                }
            }, true);
        });
    }
    async next(...args) {
        this.signal?.throwIfAborted();
        if (!this.firstResultUsed) {
            this.firstResultUsed = true;
            return this.firstResult;
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncLocalStorageProviderSingleton"].runWithConfig((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["pickRunnableConfigKeys"])(this.config), this.signal ? async ()=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$signal$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["raceWithSignal"])(this.generator.next(...args), this.signal);
        } : async ()=>{
            return this.generator.next(...args);
        }, true);
    }
    async return(value) {
        return this.generator.return(value);
    }
    async throw(e) {
        return this.generator.throw(e);
    }
    [Symbol.asyncIterator]() {
        return this;
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore Not present in Node 18 types, required in latest Node 22
    async [Symbol.asyncDispose]() {
        await this.return();
    }
}
async function pipeGeneratorWithSetup(to, generator, startSetup, signal, ...args) {
    const gen = new AsyncGeneratorWithSetup({
        generator,
        startSetup,
        signal
    });
    const setup = await gen.setup;
    return {
        output: to(gen, setup, ...args),
        setup
    };
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/log_stream.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "LogStreamCallbackHandler": (()=>LogStreamCallbackHandler),
    "RunLog": (()=>RunLog),
    "RunLogPatch": (()=>RunLogPatch),
    "isLogStreamHandler": (()=>isLogStreamHandler)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/stream.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/ai.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$core$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/core.js [app-route] (ecmascript)");
;
;
;
;
class RunLogPatch {
    constructor(fields){
        Object.defineProperty(this, "ops", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.ops = fields.ops ?? [];
    }
    concat(other) {
        const ops = this.ops.concat(other.ops);
        const states = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$core$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["applyPatch"])({}, ops);
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new RunLog({
            ops,
            state: states[states.length - 1].newDocument
        });
    }
}
class RunLog extends RunLogPatch {
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "state", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.state = fields.state;
    }
    concat(other) {
        const ops = this.ops.concat(other.ops);
        const states = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$core$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["applyPatch"])(this.state, other.ops);
        return new RunLog({
            ops,
            state: states[states.length - 1].newDocument
        });
    }
    static fromRunLogPatch(patch) {
        const states = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$core$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["applyPatch"])({}, patch.ops);
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new RunLog({
            ops: patch.ops,
            state: states[states.length - 1].newDocument
        });
    }
}
const isLogStreamHandler = (handler)=>handler.name === "log_stream_tracer";
/**
 * Extract standardized inputs from a run.
 *
 * Standardizes the inputs based on the type of the runnable used.
 *
 * @param run - Run object
 * @param schemaFormat - The schema format to use.
 *
 * @returns Valid inputs are only dict. By conventions, inputs always represented
 * invocation using named arguments.
 * A null means that the input is not yet known!
 */ async function _getStandardizedInputs(run, schemaFormat) {
    if (schemaFormat === "original") {
        throw new Error("Do not assign inputs with original schema drop the key for now. " + "When inputs are added to streamLog they should be added with " + "standardized schema for streaming events.");
    }
    const { inputs } = run;
    if ([
        "retriever",
        "llm",
        "prompt"
    ].includes(run.run_type)) {
        return inputs;
    }
    if (Object.keys(inputs).length === 1 && inputs?.input === "") {
        return undefined;
    }
    // new style chains
    // These nest an additional 'input' key inside the 'inputs' to make sure
    // the input is always a dict. We need to unpack and user the inner value.
    // We should try to fix this in Runnables and callbacks/tracers
    // Runnables should be using a null type here not a placeholder
    // dict.
    return inputs.input;
}
async function _getStandardizedOutputs(run, schemaFormat) {
    const { outputs } = run;
    if (schemaFormat === "original") {
        // Return the old schema, without standardizing anything
        return outputs;
    }
    if ([
        "retriever",
        "llm",
        "prompt"
    ].includes(run.run_type)) {
        return outputs;
    }
    // TODO: Remove this hacky check
    if (outputs !== undefined && Object.keys(outputs).length === 1 && outputs?.output !== undefined) {
        return outputs.output;
    }
    return outputs;
}
function isChatGenerationChunk(x) {
    return x !== undefined && x.message !== undefined;
}
class LogStreamCallbackHandler extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseTracer"] {
    constructor(fields){
        super({
            _awaitHandler: true,
            ...fields
        });
        Object.defineProperty(this, "autoClose", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "includeNames", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "includeTypes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "includeTags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "excludeNames", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "excludeTypes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "excludeTags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "_schemaFormat", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "original"
        });
        Object.defineProperty(this, "rootId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "keyMapByRunId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: {}
        });
        Object.defineProperty(this, "counterMapByRunName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: {}
        });
        Object.defineProperty(this, "transformStream", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "writer", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "receiveStream", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "log_stream_tracer"
        });
        Object.defineProperty(this, "lc_prefer_streaming", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        this.autoClose = fields?.autoClose ?? true;
        this.includeNames = fields?.includeNames;
        this.includeTypes = fields?.includeTypes;
        this.includeTags = fields?.includeTags;
        this.excludeNames = fields?.excludeNames;
        this.excludeTypes = fields?.excludeTypes;
        this.excludeTags = fields?.excludeTags;
        this._schemaFormat = fields?._schemaFormat ?? this._schemaFormat;
        this.transformStream = new TransformStream();
        this.writer = this.transformStream.writable.getWriter();
        this.receiveStream = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IterableReadableStream"].fromReadableStream(this.transformStream.readable);
    }
    [Symbol.asyncIterator]() {
        return this.receiveStream;
    }
    async persistRun(_run) {
    // This is a legacy method only called once for an entire run tree
    // and is therefore not useful here
    }
    _includeRun(run) {
        if (run.id === this.rootId) {
            return false;
        }
        const runTags = run.tags ?? [];
        let include = this.includeNames === undefined && this.includeTags === undefined && this.includeTypes === undefined;
        if (this.includeNames !== undefined) {
            include = include || this.includeNames.includes(run.name);
        }
        if (this.includeTypes !== undefined) {
            include = include || this.includeTypes.includes(run.run_type);
        }
        if (this.includeTags !== undefined) {
            include = include || runTags.find((tag)=>this.includeTags?.includes(tag)) !== undefined;
        }
        if (this.excludeNames !== undefined) {
            include = include && !this.excludeNames.includes(run.name);
        }
        if (this.excludeTypes !== undefined) {
            include = include && !this.excludeTypes.includes(run.run_type);
        }
        if (this.excludeTags !== undefined) {
            include = include && runTags.every((tag)=>!this.excludeTags?.includes(tag));
        }
        return include;
    }
    async *tapOutputIterable(runId, output) {
        // Tap an output async iterator to stream its values to the log.
        for await (const chunk of output){
            // root run is handled in .streamLog()
            if (runId !== this.rootId) {
                // if we can't find the run silently ignore
                // eg. because this run wasn't included in the log
                const key = this.keyMapByRunId[runId];
                if (key) {
                    await this.writer.write(new RunLogPatch({
                        ops: [
                            {
                                op: "add",
                                path: `/logs/${key}/streamed_output/-`,
                                value: chunk
                            }
                        ]
                    }));
                }
            }
            yield chunk;
        }
    }
    async onRunCreate(run) {
        if (this.rootId === undefined) {
            this.rootId = run.id;
            await this.writer.write(new RunLogPatch({
                ops: [
                    {
                        op: "replace",
                        path: "",
                        value: {
                            id: run.id,
                            name: run.name,
                            type: run.run_type,
                            streamed_output: [],
                            final_output: undefined,
                            logs: {}
                        }
                    }
                ]
            }));
        }
        if (!this._includeRun(run)) {
            return;
        }
        if (this.counterMapByRunName[run.name] === undefined) {
            this.counterMapByRunName[run.name] = 0;
        }
        this.counterMapByRunName[run.name] += 1;
        const count = this.counterMapByRunName[run.name];
        this.keyMapByRunId[run.id] = count === 1 ? run.name : `${run.name}:${count}`;
        const logEntry = {
            id: run.id,
            name: run.name,
            type: run.run_type,
            tags: run.tags ?? [],
            metadata: run.extra?.metadata ?? {},
            start_time: new Date(run.start_time).toISOString(),
            streamed_output: [],
            streamed_output_str: [],
            final_output: undefined,
            end_time: undefined
        };
        if (this._schemaFormat === "streaming_events") {
            logEntry.inputs = await _getStandardizedInputs(run, this._schemaFormat);
        }
        await this.writer.write(new RunLogPatch({
            ops: [
                {
                    op: "add",
                    path: `/logs/${this.keyMapByRunId[run.id]}`,
                    value: logEntry
                }
            ]
        }));
    }
    async onRunUpdate(run) {
        try {
            const runName = this.keyMapByRunId[run.id];
            if (runName === undefined) {
                return;
            }
            const ops = [];
            if (this._schemaFormat === "streaming_events") {
                ops.push({
                    op: "replace",
                    path: `/logs/${runName}/inputs`,
                    value: await _getStandardizedInputs(run, this._schemaFormat)
                });
            }
            ops.push({
                op: "add",
                path: `/logs/${runName}/final_output`,
                value: await _getStandardizedOutputs(run, this._schemaFormat)
            });
            if (run.end_time !== undefined) {
                ops.push({
                    op: "add",
                    path: `/logs/${runName}/end_time`,
                    value: new Date(run.end_time).toISOString()
                });
            }
            const patch = new RunLogPatch({
                ops
            });
            await this.writer.write(patch);
        } finally{
            if (run.id === this.rootId) {
                const patch = new RunLogPatch({
                    ops: [
                        {
                            op: "replace",
                            path: "/final_output",
                            value: await _getStandardizedOutputs(run, this._schemaFormat)
                        }
                    ]
                });
                await this.writer.write(patch);
                if (this.autoClose) {
                    await this.writer.close();
                }
            }
        }
    }
    async onLLMNewToken(run, token, kwargs) {
        const runName = this.keyMapByRunId[run.id];
        if (runName === undefined) {
            return;
        }
        // TODO: Remove hack
        const isChatModel = run.inputs.messages !== undefined;
        let streamedOutputValue;
        if (isChatModel) {
            if (isChatGenerationChunk(kwargs?.chunk)) {
                streamedOutputValue = kwargs?.chunk;
            } else {
                streamedOutputValue = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AIMessageChunk"]({
                    id: `run-${run.id}`,
                    content: token
                });
            }
        } else {
            streamedOutputValue = token;
        }
        const patch = new RunLogPatch({
            ops: [
                {
                    op: "add",
                    path: `/logs/${runName}/streamed_output_str/-`,
                    value: token
                },
                {
                    op: "add",
                    path: `/logs/${runName}/streamed_output/-`,
                    value: streamedOutputValue
                }
            ]
        });
        await this.writer.write(patch);
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/outputs.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ChatGenerationChunk": (()=>ChatGenerationChunk),
    "GenerationChunk": (()=>GenerationChunk),
    "RUN_KEY": (()=>RUN_KEY)
});
const RUN_KEY = "__run";
class GenerationChunk {
    constructor(fields){
        Object.defineProperty(this, "text", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        Object.defineProperty(this, "generationInfo", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.text = fields.text;
        this.generationInfo = fields.generationInfo;
    }
    concat(chunk) {
        return new GenerationChunk({
            text: this.text + chunk.text,
            generationInfo: {
                ...this.generationInfo,
                ...chunk.generationInfo
            }
        });
    }
}
class ChatGenerationChunk extends GenerationChunk {
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "message", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.message = fields.message;
    }
    concat(chunk) {
        return new ChatGenerationChunk({
            text: this.text + chunk.text,
            generationInfo: {
                ...this.generationInfo,
                ...chunk.generationInfo
            },
            message: this.message.concat(chunk.message)
        });
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/event_stream.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "EventStreamCallbackHandler": (()=>EventStreamCallbackHandler),
    "isStreamEventsHandler": (()=>isStreamEventsHandler)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/stream.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/ai.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$outputs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/outputs.js [app-route] (ecmascript)");
;
;
;
;
function assignName({ name, serialized }) {
    if (name !== undefined) {
        return name;
    }
    if (serialized?.name !== undefined) {
        return serialized.name;
    } else if (serialized?.id !== undefined && Array.isArray(serialized?.id)) {
        return serialized.id[serialized.id.length - 1];
    }
    return "Unnamed";
}
const isStreamEventsHandler = (handler)=>handler.name === "event_stream_tracer";
class EventStreamCallbackHandler extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseTracer"] {
    constructor(fields){
        super({
            _awaitHandler: true,
            ...fields
        });
        Object.defineProperty(this, "autoClose", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "includeNames", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "includeTypes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "includeTags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "excludeNames", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "excludeTypes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "excludeTags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "runInfoMap", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        Object.defineProperty(this, "tappedPromises", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        Object.defineProperty(this, "transformStream", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "writer", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "receiveStream", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "event_stream_tracer"
        });
        Object.defineProperty(this, "lc_prefer_streaming", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        this.autoClose = fields?.autoClose ?? true;
        this.includeNames = fields?.includeNames;
        this.includeTypes = fields?.includeTypes;
        this.includeTags = fields?.includeTags;
        this.excludeNames = fields?.excludeNames;
        this.excludeTypes = fields?.excludeTypes;
        this.excludeTags = fields?.excludeTags;
        this.transformStream = new TransformStream();
        this.writer = this.transformStream.writable.getWriter();
        this.receiveStream = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IterableReadableStream"].fromReadableStream(this.transformStream.readable);
    }
    [Symbol.asyncIterator]() {
        return this.receiveStream;
    }
    async persistRun(_run) {
    // This is a legacy method only called once for an entire run tree
    // and is therefore not useful here
    }
    _includeRun(run) {
        const runTags = run.tags ?? [];
        let include = this.includeNames === undefined && this.includeTags === undefined && this.includeTypes === undefined;
        if (this.includeNames !== undefined) {
            include = include || this.includeNames.includes(run.name);
        }
        if (this.includeTypes !== undefined) {
            include = include || this.includeTypes.includes(run.runType);
        }
        if (this.includeTags !== undefined) {
            include = include || runTags.find((tag)=>this.includeTags?.includes(tag)) !== undefined;
        }
        if (this.excludeNames !== undefined) {
            include = include && !this.excludeNames.includes(run.name);
        }
        if (this.excludeTypes !== undefined) {
            include = include && !this.excludeTypes.includes(run.runType);
        }
        if (this.excludeTags !== undefined) {
            include = include && runTags.every((tag)=>!this.excludeTags?.includes(tag));
        }
        return include;
    }
    async *tapOutputIterable(runId, outputStream) {
        const firstChunk = await outputStream.next();
        if (firstChunk.done) {
            return;
        }
        const runInfo = this.runInfoMap.get(runId);
        // Run has finished, don't issue any stream events.
        // An example of this is for runnables that use the default
        // implementation of .stream(), which delegates to .invoke()
        // and calls .onChainEnd() before passing it to the iterator.
        if (runInfo === undefined) {
            yield firstChunk.value;
            return;
        }
        // Match format from handlers below
        function _formatOutputChunk(eventType, data) {
            if (eventType === "llm" && typeof data === "string") {
                return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$outputs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GenerationChunk"]({
                    text: data
                });
            }
            return data;
        }
        let tappedPromise = this.tappedPromises.get(runId);
        // if we are the first to tap, issue stream events
        if (tappedPromise === undefined) {
            let tappedPromiseResolver;
            tappedPromise = new Promise((resolve)=>{
                tappedPromiseResolver = resolve;
            });
            this.tappedPromises.set(runId, tappedPromise);
            try {
                const event = {
                    event: `on_${runInfo.runType}_stream`,
                    run_id: runId,
                    name: runInfo.name,
                    tags: runInfo.tags,
                    metadata: runInfo.metadata,
                    data: {}
                };
                await this.send({
                    ...event,
                    data: {
                        chunk: _formatOutputChunk(runInfo.runType, firstChunk.value)
                    }
                }, runInfo);
                yield firstChunk.value;
                for await (const chunk of outputStream){
                    // Don't yield tool and retriever stream events
                    if (runInfo.runType !== "tool" && runInfo.runType !== "retriever") {
                        await this.send({
                            ...event,
                            data: {
                                chunk: _formatOutputChunk(runInfo.runType, chunk)
                            }
                        }, runInfo);
                    }
                    yield chunk;
                }
            } finally{
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                tappedPromiseResolver();
            // Don't delete from the promises map to keep track of which runs have been tapped.
            }
        } else {
            // otherwise just pass through
            yield firstChunk.value;
            for await (const chunk of outputStream){
                yield chunk;
            }
        }
    }
    async send(payload, run) {
        if (this._includeRun(run)) {
            await this.writer.write(payload);
        }
    }
    async sendEndEvent(payload, run) {
        const tappedPromise = this.tappedPromises.get(payload.run_id);
        if (tappedPromise !== undefined) {
            void tappedPromise.then(()=>{
                void this.send(payload, run);
            });
        } else {
            await this.send(payload, run);
        }
    }
    async onLLMStart(run) {
        const runName = assignName(run);
        const runType = run.inputs.messages !== undefined ? "chat_model" : "llm";
        const runInfo = {
            tags: run.tags ?? [],
            metadata: run.extra?.metadata ?? {},
            name: runName,
            runType,
            inputs: run.inputs
        };
        this.runInfoMap.set(run.id, runInfo);
        const eventName = `on_${runType}_start`;
        await this.send({
            event: eventName,
            data: {
                input: run.inputs
            },
            name: runName,
            tags: run.tags ?? [],
            run_id: run.id,
            metadata: run.extra?.metadata ?? {}
        }, runInfo);
    }
    async onLLMNewToken(run, token, // eslint-disable-next-line @typescript-eslint/no-explicit-any
    kwargs) {
        const runInfo = this.runInfoMap.get(run.id);
        let chunk;
        let eventName;
        if (runInfo === undefined) {
            throw new Error(`onLLMNewToken: Run ID ${run.id} not found in run map.`);
        }
        // Top-level streaming events are covered by tapOutputIterable
        if (this.runInfoMap.size === 1) {
            return;
        }
        if (runInfo.runType === "chat_model") {
            eventName = "on_chat_model_stream";
            if (kwargs?.chunk === undefined) {
                chunk = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AIMessageChunk"]({
                    content: token,
                    id: `run-${run.id}`
                });
            } else {
                chunk = kwargs.chunk.message;
            }
        } else if (runInfo.runType === "llm") {
            eventName = "on_llm_stream";
            if (kwargs?.chunk === undefined) {
                chunk = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$outputs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GenerationChunk"]({
                    text: token
                });
            } else {
                chunk = kwargs.chunk;
            }
        } else {
            throw new Error(`Unexpected run type ${runInfo.runType}`);
        }
        await this.send({
            event: eventName,
            data: {
                chunk
            },
            run_id: run.id,
            name: runInfo.name,
            tags: runInfo.tags,
            metadata: runInfo.metadata
        }, runInfo);
    }
    async onLLMEnd(run) {
        const runInfo = this.runInfoMap.get(run.id);
        this.runInfoMap.delete(run.id);
        let eventName;
        if (runInfo === undefined) {
            throw new Error(`onLLMEnd: Run ID ${run.id} not found in run map.`);
        }
        const generations = run.outputs?.generations;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let output;
        if (runInfo.runType === "chat_model") {
            for (const generation of generations ?? []){
                if (output !== undefined) {
                    break;
                }
                output = generation[0]?.message;
            }
            eventName = "on_chat_model_end";
        } else if (runInfo.runType === "llm") {
            output = {
                generations: generations?.map((generation)=>{
                    return generation.map((chunk)=>{
                        return {
                            text: chunk.text,
                            generationInfo: chunk.generationInfo
                        };
                    });
                }),
                llmOutput: run.outputs?.llmOutput ?? {}
            };
            eventName = "on_llm_end";
        } else {
            throw new Error(`onLLMEnd: Unexpected run type: ${runInfo.runType}`);
        }
        await this.sendEndEvent({
            event: eventName,
            data: {
                output,
                input: runInfo.inputs
            },
            run_id: run.id,
            name: runInfo.name,
            tags: runInfo.tags,
            metadata: runInfo.metadata
        }, runInfo);
    }
    async onChainStart(run) {
        const runName = assignName(run);
        const runType = run.run_type ?? "chain";
        const runInfo = {
            tags: run.tags ?? [],
            metadata: run.extra?.metadata ?? {},
            name: runName,
            runType: run.run_type
        };
        let eventData = {};
        // Workaround Runnable core code not sending input when transform streaming.
        if (run.inputs.input === "" && Object.keys(run.inputs).length === 1) {
            eventData = {};
            runInfo.inputs = {};
        } else if (run.inputs.input !== undefined) {
            eventData.input = run.inputs.input;
            runInfo.inputs = run.inputs.input;
        } else {
            eventData.input = run.inputs;
            runInfo.inputs = run.inputs;
        }
        this.runInfoMap.set(run.id, runInfo);
        await this.send({
            event: `on_${runType}_start`,
            data: eventData,
            name: runName,
            tags: run.tags ?? [],
            run_id: run.id,
            metadata: run.extra?.metadata ?? {}
        }, runInfo);
    }
    async onChainEnd(run) {
        const runInfo = this.runInfoMap.get(run.id);
        this.runInfoMap.delete(run.id);
        if (runInfo === undefined) {
            throw new Error(`onChainEnd: Run ID ${run.id} not found in run map.`);
        }
        const eventName = `on_${run.run_type}_end`;
        const inputs = run.inputs ?? runInfo.inputs ?? {};
        const outputs = run.outputs?.output ?? run.outputs;
        const data = {
            output: outputs,
            input: inputs
        };
        if (inputs.input && Object.keys(inputs).length === 1) {
            data.input = inputs.input;
            runInfo.inputs = inputs.input;
        }
        await this.sendEndEvent({
            event: eventName,
            data,
            run_id: run.id,
            name: runInfo.name,
            tags: runInfo.tags,
            metadata: runInfo.metadata ?? {}
        }, runInfo);
    }
    async onToolStart(run) {
        const runName = assignName(run);
        const runInfo = {
            tags: run.tags ?? [],
            metadata: run.extra?.metadata ?? {},
            name: runName,
            runType: "tool",
            inputs: run.inputs ?? {}
        };
        this.runInfoMap.set(run.id, runInfo);
        await this.send({
            event: "on_tool_start",
            data: {
                input: run.inputs ?? {}
            },
            name: runName,
            run_id: run.id,
            tags: run.tags ?? [],
            metadata: run.extra?.metadata ?? {}
        }, runInfo);
    }
    async onToolEnd(run) {
        const runInfo = this.runInfoMap.get(run.id);
        this.runInfoMap.delete(run.id);
        if (runInfo === undefined) {
            throw new Error(`onToolEnd: Run ID ${run.id} not found in run map.`);
        }
        if (runInfo.inputs === undefined) {
            throw new Error(`onToolEnd: Run ID ${run.id} is a tool call, and is expected to have traced inputs.`);
        }
        const output = run.outputs?.output === undefined ? run.outputs : run.outputs.output;
        await this.sendEndEvent({
            event: "on_tool_end",
            data: {
                output,
                input: runInfo.inputs
            },
            run_id: run.id,
            name: runInfo.name,
            tags: runInfo.tags,
            metadata: runInfo.metadata
        }, runInfo);
    }
    async onRetrieverStart(run) {
        const runName = assignName(run);
        const runType = "retriever";
        const runInfo = {
            tags: run.tags ?? [],
            metadata: run.extra?.metadata ?? {},
            name: runName,
            runType,
            inputs: {
                query: run.inputs.query
            }
        };
        this.runInfoMap.set(run.id, runInfo);
        await this.send({
            event: "on_retriever_start",
            data: {
                input: {
                    query: run.inputs.query
                }
            },
            name: runName,
            tags: run.tags ?? [],
            run_id: run.id,
            metadata: run.extra?.metadata ?? {}
        }, runInfo);
    }
    async onRetrieverEnd(run) {
        const runInfo = this.runInfoMap.get(run.id);
        this.runInfoMap.delete(run.id);
        if (runInfo === undefined) {
            throw new Error(`onRetrieverEnd: Run ID ${run.id} not found in run map.`);
        }
        await this.sendEndEvent({
            event: "on_retriever_end",
            data: {
                output: run.outputs?.documents ?? run.outputs,
                input: runInfo.inputs
            },
            run_id: run.id,
            name: runInfo.name,
            tags: runInfo.tags,
            metadata: runInfo.metadata
        }, runInfo);
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async handleCustomEvent(eventName, data, runId) {
        const runInfo = this.runInfoMap.get(runId);
        if (runInfo === undefined) {
            throw new Error(`handleCustomEvent: Run ID ${runId} not found in run map.`);
        }
        await this.send({
            event: "on_custom_event",
            run_id: runId,
            name: eventName,
            tags: runInfo.tags,
            metadata: runInfo.metadata,
            data
        }, runInfo);
    }
    async finish() {
        const pendingPromises = [
            ...this.tappedPromises.values()
        ];
        void Promise.all(pendingPromises).finally(()=>{
            void this.writer.close();
        });
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/async_caller.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "AsyncCaller": (()=>AsyncCaller)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$p$2d$retry$40$4$2e$6$2e$2$2f$node_modules$2f$p$2d$retry$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/p-retry@4.6.2/node_modules/p-retry/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$p$2d$queue$40$6$2e$6$2e$2$2f$node_modules$2f$p$2d$queue$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/p-queue@6.6.2/node_modules/p-queue/dist/index.js [app-route] (ecmascript)");
;
;
const STATUS_NO_RETRY = [
    400,
    401,
    402,
    403,
    404,
    405,
    406,
    407,
    409
];
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const defaultFailedAttemptHandler = (error)=>{
    if (error.message.startsWith("Cancel") || error.message.startsWith("AbortError") || error.name === "AbortError") {
        throw error;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    if (error?.code === "ECONNABORTED") {
        throw error;
    }
    const status = // eslint-disable-next-line @typescript-eslint/no-explicit-any
    error?.response?.status ?? error?.status;
    if (status && STATUS_NO_RETRY.includes(+status)) {
        throw error;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    if (error?.error?.code === "insufficient_quota") {
        const err = new Error(error?.message);
        err.name = "InsufficientQuotaError";
        throw err;
    }
};
class AsyncCaller {
    constructor(params){
        Object.defineProperty(this, "maxConcurrency", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "maxRetries", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "onFailedAttempt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "queue", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.maxConcurrency = params.maxConcurrency ?? Infinity;
        this.maxRetries = params.maxRetries ?? 6;
        this.onFailedAttempt = params.onFailedAttempt ?? defaultFailedAttemptHandler;
        const PQueue = "default" in __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$p$2d$queue$40$6$2e$6$2e$2$2f$node_modules$2f$p$2d$queue$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"] ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$p$2d$queue$40$6$2e$6$2e$2$2f$node_modules$2f$p$2d$queue$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].default : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$p$2d$queue$40$6$2e$6$2e$2$2f$node_modules$2f$p$2d$queue$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"];
        this.queue = new PQueue({
            concurrency: this.maxConcurrency
        });
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    call(callable, ...args) {
        return this.queue.add(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$p$2d$retry$40$4$2e$6$2e$2$2f$node_modules$2f$p$2d$retry$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])(()=>callable(...args).catch((error)=>{
                    // eslint-disable-next-line no-instanceof/no-instanceof
                    if (error instanceof Error) {
                        throw error;
                    } else {
                        throw new Error(error);
                    }
                }), {
                onFailedAttempt: this.onFailedAttempt,
                retries: this.maxRetries,
                randomize: true
            }), {
            throwOnTimeout: true
        });
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    callWithOptions(options, callable, ...args) {
        // Note this doesn't cancel the underlying request,
        // when available prefer to use the signal option of the underlying call
        if (options.signal) {
            return Promise.race([
                this.call(callable, ...args),
                new Promise((_, reject)=>{
                    options.signal?.addEventListener("abort", ()=>{
                        reject(new Error("AbortError"));
                    });
                })
            ]);
        }
        return this.call(callable, ...args);
    }
    fetch(...args) {
        return this.call(()=>fetch(...args).then((res)=>res.ok ? res : Promise.reject(res)));
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/root_listener.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "RootListenersTracer": (()=>RootListenersTracer)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/base.js [app-route] (ecmascript)");
;
class RootListenersTracer extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseTracer"] {
    constructor({ config, onStart, onEnd, onError }){
        super({
            _awaitHandler: true
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "RootListenersTracer"
        });
        /** The Run's ID. Type UUID */ Object.defineProperty(this, "rootId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "config", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "argOnStart", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "argOnEnd", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "argOnError", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.config = config;
        this.argOnStart = onStart;
        this.argOnEnd = onEnd;
        this.argOnError = onError;
    }
    /**
     * This is a legacy method only called once for an entire run tree
     * therefore not useful here
     * @param {Run} _ Not used
     */ persistRun(_) {
        return Promise.resolve();
    }
    async onRunCreate(run) {
        if (this.rootId) {
            return;
        }
        this.rootId = run.id;
        if (this.argOnStart) {
            await this.argOnStart(run, this.config);
        }
    }
    async onRunUpdate(run) {
        if (run.id !== this.rootId) {
            return;
        }
        if (!run.error) {
            if (this.argOnEnd) {
                await this.argOnEnd(run, this.config);
            }
        } else if (this.argOnError) {
            await this.argOnError(run, this.config);
        }
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/utils.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// eslint-disable-next-line @typescript-eslint/no-explicit-any
__turbopack_esm__({
    "_RootEventFilter": (()=>_RootEventFilter),
    "isRunnableInterface": (()=>isRunnableInterface)
});
function isRunnableInterface(thing) {
    return thing ? thing.lc_runnable : false;
}
class _RootEventFilter {
    constructor(fields){
        Object.defineProperty(this, "includeNames", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "includeTypes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "includeTags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "excludeNames", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "excludeTypes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "excludeTags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.includeNames = fields.includeNames;
        this.includeTypes = fields.includeTypes;
        this.includeTags = fields.includeTags;
        this.excludeNames = fields.excludeNames;
        this.excludeTypes = fields.excludeTypes;
        this.excludeTags = fields.excludeTags;
    }
    includeEvent(event, rootType) {
        let include = this.includeNames === undefined && this.includeTypes === undefined && this.includeTags === undefined;
        const eventTags = event.tags ?? [];
        if (this.includeNames !== undefined) {
            include = include || this.includeNames.includes(event.name);
        }
        if (this.includeTypes !== undefined) {
            include = include || this.includeTypes.includes(rootType);
        }
        if (this.includeTags !== undefined) {
            include = include || eventTags.some((tag)=>this.includeTags?.includes(tag));
        }
        if (this.excludeNames !== undefined) {
            include = include && !this.excludeNames.includes(event.name);
        }
        if (this.excludeTypes !== undefined) {
            include = include && !this.excludeTypes.includes(rootType);
        }
        if (this.excludeTags !== undefined) {
            include = include && eventTags.every((tag)=>!this.excludeTags?.includes(tag));
        }
        return include;
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/graph_mermaid.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "drawMermaid": (()=>drawMermaid),
    "drawMermaidPng": (()=>drawMermaidPng)
});
function _escapeNodeLabel(nodeLabel) {
    // Escapes the node label for Mermaid syntax.
    return nodeLabel.replace(/[^a-zA-Z-_0-9]/g, "_");
}
const MARKDOWN_SPECIAL_CHARS = [
    "*",
    "_",
    "`"
];
function _generateMermaidGraphStyles(nodeColors) {
    let styles = "";
    for (const [className, color] of Object.entries(nodeColors)){
        styles += `\tclassDef ${className} ${color};\n`;
    }
    return styles;
}
function drawMermaid(nodes, edges, config) {
    const { firstNode, lastNode, nodeColors, withStyles = true, curveStyle = "linear", wrapLabelNWords = 9 } = config ?? {};
    // Initialize Mermaid graph configuration
    let mermaidGraph = withStyles ? `%%{init: {'flowchart': {'curve': '${curveStyle}'}}}%%\ngraph TD;\n` : "graph TD;\n";
    if (withStyles) {
        // Node formatting templates
        const defaultClassLabel = "default";
        const formatDict = {
            [defaultClassLabel]: "{0}({1})"
        };
        if (firstNode !== undefined) {
            formatDict[firstNode] = "{0}([{1}]):::first";
        }
        if (lastNode !== undefined) {
            formatDict[lastNode] = "{0}([{1}]):::last";
        }
        // Add nodes to the graph
        for (const [key, node] of Object.entries(nodes)){
            const nodeName = node.name.split(":").pop() ?? "";
            const label = MARKDOWN_SPECIAL_CHARS.some((char)=>nodeName.startsWith(char) && nodeName.endsWith(char)) ? `<p>${nodeName}</p>` : nodeName;
            let finalLabel = label;
            if (Object.keys(node.metadata ?? {}).length) {
                finalLabel += `<hr/><small><em>${Object.entries(node.metadata ?? {}).map(([k, v])=>`${k} = ${v}`).join("\n")}</em></small>`;
            }
            const nodeLabel = (formatDict[key] ?? formatDict[defaultClassLabel]).replace("{0}", _escapeNodeLabel(key)).replace("{1}", finalLabel);
            mermaidGraph += `\t${nodeLabel}\n`;
        }
    }
    // Group edges by their common prefixes
    const edgeGroups = {};
    for (const edge of edges){
        const srcParts = edge.source.split(":");
        const tgtParts = edge.target.split(":");
        const commonPrefix = srcParts.filter((src, i)=>src === tgtParts[i]).join(":");
        if (!edgeGroups[commonPrefix]) {
            edgeGroups[commonPrefix] = [];
        }
        edgeGroups[commonPrefix].push(edge);
    }
    const seenSubgraphs = new Set();
    function addSubgraph(edges, prefix) {
        const selfLoop = edges.length === 1 && edges[0].source === edges[0].target;
        if (prefix && !selfLoop) {
            const subgraph = prefix.split(":").pop();
            if (seenSubgraphs.has(subgraph)) {
                throw new Error(`Found duplicate subgraph '${subgraph}' -- this likely means that ` + "you're reusing a subgraph node with the same name. " + "Please adjust your graph to have subgraph nodes with unique names.");
            }
            seenSubgraphs.add(subgraph);
            mermaidGraph += `\tsubgraph ${subgraph}\n`;
        }
        for (const edge of edges){
            const { source, target, data, conditional } = edge;
            let edgeLabel = "";
            if (data !== undefined) {
                let edgeData = data;
                const words = edgeData.split(" ");
                if (words.length > wrapLabelNWords) {
                    edgeData = Array.from({
                        length: Math.ceil(words.length / wrapLabelNWords)
                    }, (_, i)=>words.slice(i * wrapLabelNWords, (i + 1) * wrapLabelNWords).join(" ")).join("&nbsp;<br>&nbsp;");
                }
                edgeLabel = conditional ? ` -. &nbsp;${edgeData}&nbsp; .-> ` : ` -- &nbsp;${edgeData}&nbsp; --> `;
            } else {
                edgeLabel = conditional ? " -.-> " : " --> ";
            }
            mermaidGraph += `\t${_escapeNodeLabel(source)}${edgeLabel}${_escapeNodeLabel(target)};\n`;
        }
        // Recursively add nested subgraphs
        for(const nestedPrefix in edgeGroups){
            if (nestedPrefix.startsWith(`${prefix}:`) && nestedPrefix !== prefix) {
                addSubgraph(edgeGroups[nestedPrefix], nestedPrefix);
            }
        }
        if (prefix && !selfLoop) {
            mermaidGraph += "\tend\n";
        }
    }
    // Start with the top-level edges (no common prefix)
    addSubgraph(edgeGroups[""] ?? [], "");
    // Add remaining subgraphs
    for(const prefix in edgeGroups){
        if (!prefix.includes(":") && prefix !== "") {
            addSubgraph(edgeGroups[prefix], prefix);
        }
    }
    // Add custom styles for nodes
    if (withStyles) {
        mermaidGraph += _generateMermaidGraphStyles(nodeColors ?? {});
    }
    return mermaidGraph;
}
async function drawMermaidPng(mermaidSyntax, config) {
    let { backgroundColor = "white" } = config ?? {};
    // Use btoa for compatibility, assume ASCII
    const mermaidSyntaxEncoded = btoa(mermaidSyntax);
    // Check if the background color is a hexadecimal color code using regex
    if (backgroundColor !== undefined) {
        const hexColorPattern = /^#(?:[0-9a-fA-F]{3}){1,2}$/;
        if (!hexColorPattern.test(backgroundColor)) {
            backgroundColor = `!${backgroundColor}`;
        }
    }
    const imageUrl = `https://mermaid.ink/img/${mermaidSyntaxEncoded}?bgColor=${backgroundColor}`;
    const res = await fetch(imageUrl);
    if (!res.ok) {
        throw new Error([
            `Failed to render the graph using the Mermaid.INK API.`,
            `Status code: ${res.status}`,
            `Status text: ${res.statusText}`
        ].join("\n"));
    }
    const content = await res.blob();
    return content;
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/graph.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Graph": (()=>Graph)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$2d$to$2d$json$2d$schema$40$3$2e$24$2e$1_zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/zod-to-json-schema@3.24.1_zod@3.24.1/node_modules/zod-to-json-schema/dist/esm/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$graph_mermaid$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/graph_mermaid.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$validate$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__validate$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/uuid@10.0.0/node_modules/uuid/dist/esm-node/validate.js [app-route] (ecmascript) <export default as validate>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$2d$to$2d$json$2d$schema$40$3$2e$24$2e$1_zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$zodToJsonSchema$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/zod-to-json-schema@3.24.1_zod@3.24.1/node_modules/zod-to-json-schema/dist/esm/zodToJsonSchema.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/uuid@10.0.0/node_modules/uuid/dist/esm-node/v4.js [app-route] (ecmascript) <export default as v4>");
;
;
;
;
function nodeDataStr(id, data) {
    if (id !== undefined && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$validate$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__validate$3e$__["validate"])(id)) {
        return id;
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isRunnableInterface"])(data)) {
        try {
            let dataStr = data.getName();
            dataStr = dataStr.startsWith("Runnable") ? dataStr.slice("Runnable".length) : dataStr;
            return dataStr;
        } catch (error) {
            return data.getName();
        }
    } else {
        return data.name ?? "UnknownSchema";
    }
}
function nodeDataJson(node) {
    // if node.data implements Runnable
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isRunnableInterface"])(node.data)) {
        return {
            type: "runnable",
            data: {
                id: node.data.lc_id,
                name: node.data.getName()
            }
        };
    } else {
        return {
            type: "schema",
            data: {
                ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$2d$to$2d$json$2d$schema$40$3$2e$24$2e$1_zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$zodToJsonSchema$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["zodToJsonSchema"])(node.data.schema),
                title: node.data.name
            }
        };
    }
}
class Graph {
    constructor(params){
        Object.defineProperty(this, "nodes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: {}
        });
        Object.defineProperty(this, "edges", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        this.nodes = params?.nodes ?? this.nodes;
        this.edges = params?.edges ?? this.edges;
    }
    // Convert the graph to a JSON-serializable format.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    toJSON() {
        const stableNodeIds = {};
        Object.values(this.nodes).forEach((node, i)=>{
            stableNodeIds[node.id] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$validate$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__validate$3e$__["validate"])(node.id) ? i : node.id;
        });
        return {
            nodes: Object.values(this.nodes).map((node)=>({
                    id: stableNodeIds[node.id],
                    ...nodeDataJson(node)
                })),
            edges: this.edges.map((edge)=>{
                const item = {
                    source: stableNodeIds[edge.source],
                    target: stableNodeIds[edge.target]
                };
                if (typeof edge.data !== "undefined") {
                    item.data = edge.data;
                }
                if (typeof edge.conditional !== "undefined") {
                    item.conditional = edge.conditional;
                }
                return item;
            })
        };
    }
    addNode(data, id, // eslint-disable-next-line @typescript-eslint/no-explicit-any
    metadata) {
        if (id !== undefined && this.nodes[id] !== undefined) {
            throw new Error(`Node with id ${id} already exists`);
        }
        const nodeId = id ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])();
        const node = {
            id: nodeId,
            data,
            name: nodeDataStr(id, data),
            metadata
        };
        this.nodes[nodeId] = node;
        return node;
    }
    removeNode(node) {
        // Remove the node from the nodes map
        delete this.nodes[node.id];
        // Filter out edges connected to the node
        this.edges = this.edges.filter((edge)=>edge.source !== node.id && edge.target !== node.id);
    }
    addEdge(source, target, data, conditional) {
        if (this.nodes[source.id] === undefined) {
            throw new Error(`Source node ${source.id} not in graph`);
        }
        if (this.nodes[target.id] === undefined) {
            throw new Error(`Target node ${target.id} not in graph`);
        }
        const edge = {
            source: source.id,
            target: target.id,
            data,
            conditional
        };
        this.edges.push(edge);
        return edge;
    }
    firstNode() {
        return _firstNode(this);
    }
    lastNode() {
        return _lastNode(this);
    }
    /**
     * Add all nodes and edges from another graph.
     * Note this doesn't check for duplicates, nor does it connect the graphs.
     */ extend(graph, prefix = "") {
        let finalPrefix = prefix;
        const nodeIds = Object.values(graph.nodes).map((node)=>node.id);
        if (nodeIds.every(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$validate$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__validate$3e$__["validate"])) {
            finalPrefix = "";
        }
        const prefixed = (id)=>{
            return finalPrefix ? `${finalPrefix}:${id}` : id;
        };
        Object.entries(graph.nodes).forEach(([key, value])=>{
            this.nodes[prefixed(key)] = {
                ...value,
                id: prefixed(key)
            };
        });
        const newEdges = graph.edges.map((edge)=>{
            return {
                ...edge,
                source: prefixed(edge.source),
                target: prefixed(edge.target)
            };
        });
        // Add all edges from the other graph
        this.edges = [
            ...this.edges,
            ...newEdges
        ];
        const first = graph.firstNode();
        const last = graph.lastNode();
        return [
            first ? {
                id: prefixed(first.id),
                data: first.data
            } : undefined,
            last ? {
                id: prefixed(last.id),
                data: last.data
            } : undefined
        ];
    }
    trimFirstNode() {
        const firstNode = this.firstNode();
        if (firstNode && _firstNode(this, [
            firstNode.id
        ])) {
            this.removeNode(firstNode);
        }
    }
    trimLastNode() {
        const lastNode = this.lastNode();
        if (lastNode && _lastNode(this, [
            lastNode.id
        ])) {
            this.removeNode(lastNode);
        }
    }
    /**
     * Return a new graph with all nodes re-identified,
     * using their unique, readable names where possible.
     */ reid() {
        const nodeLabels = Object.fromEntries(Object.values(this.nodes).map((node)=>[
                node.id,
                node.name
            ]));
        const nodeLabelCounts = new Map();
        Object.values(nodeLabels).forEach((label)=>{
            nodeLabelCounts.set(label, (nodeLabelCounts.get(label) || 0) + 1);
        });
        const getNodeId = (nodeId)=>{
            const label = nodeLabels[nodeId];
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$validate$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__validate$3e$__["validate"])(nodeId) && nodeLabelCounts.get(label) === 1) {
                return label;
            } else {
                return nodeId;
            }
        };
        return new Graph({
            nodes: Object.fromEntries(Object.entries(this.nodes).map(([id, node])=>[
                    getNodeId(id),
                    {
                        ...node,
                        id: getNodeId(id)
                    }
                ])),
            edges: this.edges.map((edge)=>({
                    ...edge,
                    source: getNodeId(edge.source),
                    target: getNodeId(edge.target)
                }))
        });
    }
    drawMermaid(params) {
        const { withStyles, curveStyle, nodeColors = {
            default: "fill:#f2f0ff,line-height:1.2",
            first: "fill-opacity:0",
            last: "fill:#bfb6fc"
        }, wrapLabelNWords } = params ?? {};
        const graph = this.reid();
        const firstNode = graph.firstNode();
        const lastNode = graph.lastNode();
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$graph_mermaid$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["drawMermaid"])(graph.nodes, graph.edges, {
            firstNode: firstNode?.id,
            lastNode: lastNode?.id,
            withStyles,
            curveStyle,
            nodeColors,
            wrapLabelNWords
        });
    }
    async drawMermaidPng(params) {
        const mermaidSyntax = this.drawMermaid(params);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$graph_mermaid$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["drawMermaidPng"])(mermaidSyntax, {
            backgroundColor: params?.backgroundColor
        });
    }
}
/**
 * Find the single node that is not a target of any edge.
 * Exclude nodes/sources with ids in the exclude list.
 * If there is no such node, or there are multiple, return undefined.
 * When drawing the graph, this node would be the origin.
 */ function _firstNode(graph, exclude = []) {
    const targets = new Set(graph.edges.filter((edge)=>!exclude.includes(edge.source)).map((edge)=>edge.target));
    const found = [];
    for (const node of Object.values(graph.nodes)){
        if (!exclude.includes(node.id) && !targets.has(node.id)) {
            found.push(node);
        }
    }
    return found.length === 1 ? found[0] : undefined;
}
/**
 * Find the single node that is not a source of any edge.
 * Exclude nodes/targets with ids in the exclude list.
 * If there is no such node, or there are multiple, return undefined.
 * When drawing the graph, this node would be the destination.
 */ function _lastNode(graph, exclude = []) {
    const sources = new Set(graph.edges.filter((edge)=>!exclude.includes(edge.target)).map((edge)=>edge.source));
    const found = [];
    for (const node of Object.values(graph.nodes)){
        if (!exclude.includes(node.id) && !sources.has(node.id)) {
            found.push(node);
        }
    }
    return found.length === 1 ? found[0] : undefined;
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/wrappers.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "convertToHttpEventStream": (()=>convertToHttpEventStream)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/stream.js [app-route] (ecmascript)");
;
function convertToHttpEventStream(stream) {
    const encoder = new TextEncoder();
    const finalStream = new ReadableStream({
        async start (controller) {
            for await (const chunk of stream){
                controller.enqueue(encoder.encode(`event: data\ndata: ${JSON.stringify(chunk)}\n\n`));
            }
            controller.enqueue(encoder.encode("event: end\n\n"));
            controller.close();
        }
    });
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IterableReadableStream"].fromReadableStream(finalStream);
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/iter.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "consumeAsyncIterableInContext": (()=>consumeAsyncIterableInContext),
    "consumeIteratorInContext": (()=>consumeIteratorInContext),
    "isAsyncIterable": (()=>isAsyncIterable),
    "isIterableIterator": (()=>isIterableIterator),
    "isIterator": (()=>isIterator)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/config.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/async_local_storage/index.js [app-route] (ecmascript)");
;
;
function isIterableIterator(thing) {
    return typeof thing === "object" && thing !== null && typeof thing[Symbol.iterator] === "function" && // avoid detecting array/set as iterator
    typeof thing.next === "function";
}
const isIterator = (x)=>x != null && typeof x === "object" && "next" in x && typeof x.next === "function";
function isAsyncIterable(thing) {
    return typeof thing === "object" && thing !== null && typeof thing[Symbol.asyncIterator] === "function";
}
function* consumeIteratorInContext(context, iter) {
    while(true){
        const { value, done } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncLocalStorageProviderSingleton"].runWithConfig((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["pickRunnableConfigKeys"])(context), iter.next.bind(iter), true);
        if (done) {
            break;
        } else {
            yield value;
        }
    }
}
async function* consumeAsyncIterableInContext(context, iter) {
    const iterator = iter[Symbol.asyncIterator]();
    while(true){
        const { value, done } = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncLocalStorageProviderSingleton"].runWithConfig((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["pickRunnableConfigKeys"])(context), iterator.next.bind(iter), true);
        if (done) {
            break;
        } else {
            yield value;
        }
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/base.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Runnable": (()=>Runnable),
    "RunnableAssign": (()=>RunnableAssign),
    "RunnableBinding": (()=>RunnableBinding),
    "RunnableEach": (()=>RunnableEach),
    "RunnableLambda": (()=>RunnableLambda),
    "RunnableMap": (()=>RunnableMap),
    "RunnableParallel": (()=>RunnableParallel),
    "RunnablePick": (()=>RunnablePick),
    "RunnableRetry": (()=>RunnableRetry),
    "RunnableSequence": (()=>RunnableSequence),
    "RunnableToolLike": (()=>RunnableToolLike),
    "RunnableTraceable": (()=>RunnableTraceable),
    "RunnableWithFallbacks": (()=>RunnableWithFallbacks),
    "_coerceToDict": (()=>_coerceToDict),
    "_coerceToRunnable": (()=>_coerceToRunnable),
    "convertRunnableToTool": (()=>convertRunnableToTool)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$p$2d$retry$40$4$2e$6$2e$2$2f$node_modules$2f$p$2d$retry$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/p-retry@4.6.2/node_modules/p-retry/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$singletons$2f$traceable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/langsmith@0.2.15_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/langsmith/singletons/traceable.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$log_stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/log_stream.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$event_stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/event_stream.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$load$2f$serializable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/load/serializable.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/stream.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$signal$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/signal.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/config.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$async_caller$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/async_caller.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$root_listener$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tracers/root_listener.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$graph$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/graph.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$wrappers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/wrappers.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$iter$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/iter.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tools$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/tools/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/uuid@10.0.0/node_modules/uuid/dist/esm-node/v4.js [app-route] (ecmascript) <export default as v4>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$singletons$2f$traceable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/langsmith@0.2.15_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/langsmith/dist/singletons/traceable.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/singletons/async_local_storage/index.js [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function _coerceToDict(value, defaultKey) {
    return value && !Array.isArray(value) && // eslint-disable-next-line no-instanceof/no-instanceof
    !(value instanceof Date) && typeof value === "object" ? value : {
        [defaultKey]: value
    };
}
class Runnable extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$load$2f$serializable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Serializable"] {
    constructor(){
        super(...arguments);
        Object.defineProperty(this, "lc_runnable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    getName(suffix) {
        const name = // eslint-disable-next-line @typescript-eslint/no-explicit-any
        this.name ?? this.constructor.lc_name() ?? this.constructor.name;
        return suffix ? `${name}${suffix}` : name;
    }
    /**
     * Bind arguments to a Runnable, returning a new Runnable.
     * @param kwargs
     * @returns A new RunnableBinding that, when invoked, will apply the bound args.
     */ bind(kwargs) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new RunnableBinding({
            bound: this,
            kwargs,
            config: {}
        });
    }
    /**
     * Return a new Runnable that maps a list of inputs to a list of outputs,
     * by calling invoke() with each input.
     */ map() {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new RunnableEach({
            bound: this
        });
    }
    /**
     * Add retry logic to an existing runnable.
     * @param kwargs
     * @returns A new RunnableRetry that, when invoked, will retry according to the parameters.
     */ withRetry(fields) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new RunnableRetry({
            bound: this,
            kwargs: {},
            config: {},
            maxAttemptNumber: fields?.stopAfterAttempt,
            ...fields
        });
    }
    /**
     * Bind config to a Runnable, returning a new Runnable.
     * @param config New configuration parameters to attach to the new runnable.
     * @returns A new RunnableBinding with a config matching what's passed.
     */ withConfig(config) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new RunnableBinding({
            bound: this,
            config,
            kwargs: {}
        });
    }
    /**
     * Create a new runnable from the current one that will try invoking
     * other passed fallback runnables if the initial invocation fails.
     * @param fields.fallbacks Other runnables to call if the runnable errors.
     * @returns A new RunnableWithFallbacks.
     */ withFallbacks(fields) {
        const fallbacks = Array.isArray(fields) ? fields : fields.fallbacks;
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new RunnableWithFallbacks({
            runnable: this,
            fallbacks
        });
    }
    _getOptionsList(options, length = 0) {
        if (Array.isArray(options) && options.length !== length) {
            throw new Error(`Passed "options" must be an array with the same length as the inputs, but got ${options.length} options for ${length} inputs`);
        }
        if (Array.isArray(options)) {
            return options.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"]);
        }
        if (length > 1 && !Array.isArray(options) && options.runId) {
            console.warn("Provided runId will be used only for the first element of the batch.");
            const subsequent = Object.fromEntries(Object.entries(options).filter(([key])=>key !== "runId"));
            return Array.from({
                length
            }, (_, i)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(i === 0 ? options : subsequent));
        }
        return Array.from({
            length
        }, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options));
    }
    async batch(inputs, options, batchOptions) {
        const configList = this._getOptionsList(options ?? {}, inputs.length);
        const maxConcurrency = configList[0]?.maxConcurrency ?? batchOptions?.maxConcurrency;
        const caller = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$async_caller$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncCaller"]({
            maxConcurrency,
            onFailedAttempt: (e)=>{
                throw e;
            }
        });
        const batchCalls = inputs.map((input, i)=>caller.call(async ()=>{
                try {
                    const result = await this.invoke(input, configList[i]);
                    return result;
                } catch (e) {
                    if (batchOptions?.returnExceptions) {
                        return e;
                    }
                    throw e;
                }
            }));
        return Promise.all(batchCalls);
    }
    /**
     * Default streaming implementation.
     * Subclasses should override this method if they support streaming output.
     * @param input
     * @param options
     */ async *_streamIterator(input, options) {
        yield this.invoke(input, options);
    }
    /**
     * Stream output in chunks.
     * @param input
     * @param options
     * @returns A readable stream that is also an iterable.
     */ async stream(input, options) {
        // Buffer the first streamed chunk to allow for initial errors
        // to surface immediately.
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        const wrappedGenerator = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncGeneratorWithSetup"]({
            generator: this._streamIterator(input, config),
            config
        });
        await wrappedGenerator.setup;
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IterableReadableStream"].fromAsyncGenerator(wrappedGenerator);
    }
    _separateRunnableConfigFromCallOptions(options) {
        let runnableConfig;
        if (options === undefined) {
            runnableConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        } else {
            runnableConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])({
                callbacks: options.callbacks,
                tags: options.tags,
                metadata: options.metadata,
                runName: options.runName,
                configurable: options.configurable,
                recursionLimit: options.recursionLimit,
                maxConcurrency: options.maxConcurrency,
                runId: options.runId,
                timeout: options.timeout,
                signal: options.signal
            });
        }
        const callOptions = {
            ...options
        };
        delete callOptions.callbacks;
        delete callOptions.tags;
        delete callOptions.metadata;
        delete callOptions.runName;
        delete callOptions.configurable;
        delete callOptions.recursionLimit;
        delete callOptions.maxConcurrency;
        delete callOptions.runId;
        delete callOptions.timeout;
        delete callOptions.signal;
        return [
            runnableConfig,
            callOptions
        ];
    }
    async _callWithConfig(func, input, options) {
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        const callbackManager_ = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCallbackManagerForConfig"])(config);
        const runManager = await callbackManager_?.handleChainStart(this.toJSON(), _coerceToDict(input, "input"), config.runId, config?.runType, undefined, undefined, config?.runName ?? this.getName());
        delete config.runId;
        let output;
        try {
            const promise = func.call(this, input, config, runManager);
            output = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$signal$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["raceWithSignal"])(promise, options?.signal);
        } catch (e) {
            await runManager?.handleChainError(e);
            throw e;
        }
        await runManager?.handleChainEnd(_coerceToDict(output, "output"));
        return output;
    }
    /**
     * Internal method that handles batching and configuration for a runnable
     * It takes a function, input values, and optional configuration, and
     * returns a promise that resolves to the output values.
     * @param func The function to be executed for each input value.
     * @param input The input values to be processed.
     * @param config Optional configuration for the function execution.
     * @returns A promise that resolves to the output values.
     */ async _batchWithConfig(func, inputs, options, batchOptions) {
        const optionsList = this._getOptionsList(options ?? {}, inputs.length);
        const callbackManagers = await Promise.all(optionsList.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCallbackManagerForConfig"]));
        const runManagers = await Promise.all(callbackManagers.map(async (callbackManager, i)=>{
            const handleStartRes = await callbackManager?.handleChainStart(this.toJSON(), _coerceToDict(inputs[i], "input"), optionsList[i].runId, optionsList[i].runType, undefined, undefined, optionsList[i].runName ?? this.getName());
            delete optionsList[i].runId;
            return handleStartRes;
        }));
        let outputs;
        try {
            const promise = func.call(this, inputs, optionsList, runManagers, batchOptions);
            outputs = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$signal$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["raceWithSignal"])(promise, optionsList?.[0]?.signal);
        } catch (e) {
            await Promise.all(runManagers.map((runManager)=>runManager?.handleChainError(e)));
            throw e;
        }
        await Promise.all(runManagers.map((runManager)=>runManager?.handleChainEnd(_coerceToDict(outputs, "output"))));
        return outputs;
    }
    /**
     * Helper method to transform an Iterator of Input values into an Iterator of
     * Output values, with callbacks.
     * Use this to implement `stream()` or `transform()` in Runnable subclasses.
     */ async *_transformStreamWithConfig(inputGenerator, transformer, options) {
        let finalInput;
        let finalInputSupported = true;
        let finalOutput;
        let finalOutputSupported = true;
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        const callbackManager_ = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCallbackManagerForConfig"])(config);
        async function* wrapInputForTracing() {
            for await (const chunk of inputGenerator){
                if (finalInputSupported) {
                    if (finalInput === undefined) {
                        finalInput = chunk;
                    } else {
                        try {
                            // eslint-disable-next-line @typescript-eslint/no-explicit-any
                            finalInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["concat"])(finalInput, chunk);
                        } catch  {
                            finalInput = undefined;
                            finalInputSupported = false;
                        }
                    }
                }
                yield chunk;
            }
        }
        let runManager;
        try {
            const pipe = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["pipeGeneratorWithSetup"])(transformer.bind(this), wrapInputForTracing(), async ()=>callbackManager_?.handleChainStart(this.toJSON(), {
                    input: ""
                }, config.runId, config.runType, undefined, undefined, config.runName ?? this.getName()), options?.signal, config);
            delete config.runId;
            runManager = pipe.setup;
            const streamEventsHandler = runManager?.handlers.find(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$event_stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isStreamEventsHandler"]);
            let iterator = pipe.output;
            if (streamEventsHandler !== undefined && runManager !== undefined) {
                iterator = streamEventsHandler.tapOutputIterable(runManager.runId, iterator);
            }
            const streamLogHandler = runManager?.handlers.find(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$log_stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isLogStreamHandler"]);
            if (streamLogHandler !== undefined && runManager !== undefined) {
                iterator = streamLogHandler.tapOutputIterable(runManager.runId, iterator);
            }
            for await (const chunk of iterator){
                yield chunk;
                if (finalOutputSupported) {
                    if (finalOutput === undefined) {
                        finalOutput = chunk;
                    } else {
                        try {
                            // eslint-disable-next-line @typescript-eslint/no-explicit-any
                            finalOutput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["concat"])(finalOutput, chunk);
                        } catch  {
                            finalOutput = undefined;
                            finalOutputSupported = false;
                        }
                    }
                }
            }
        } catch (e) {
            await runManager?.handleChainError(e, undefined, undefined, undefined, {
                inputs: _coerceToDict(finalInput, "input")
            });
            throw e;
        }
        await runManager?.handleChainEnd(finalOutput ?? {}, undefined, undefined, undefined, {
            inputs: _coerceToDict(finalInput, "input")
        });
    }
    getGraph(_) {
        const graph = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$graph$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Graph"]();
        // TODO: Add input schema for runnables
        const inputNode = graph.addNode({
            name: `${this.getName()}Input`,
            schema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].any()
        });
        const runnableNode = graph.addNode(this);
        // TODO: Add output schemas for runnables
        const outputNode = graph.addNode({
            name: `${this.getName()}Output`,
            schema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].any()
        });
        graph.addEdge(inputNode, runnableNode);
        graph.addEdge(runnableNode, outputNode);
        return graph;
    }
    /**
     * Create a new runnable sequence that runs each individual runnable in series,
     * piping the output of one runnable into another runnable or runnable-like.
     * @param coerceable A runnable, function, or object whose values are functions or runnables.
     * @returns A new runnable sequence.
     */ pipe(coerceable) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new RunnableSequence({
            first: this,
            last: _coerceToRunnable(coerceable)
        });
    }
    /**
     * Pick keys from the dict output of this runnable. Returns a new runnable.
     */ pick(keys) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return this.pipe(new RunnablePick(keys));
    }
    /**
     * Assigns new fields to the dict output of this runnable. Returns a new runnable.
     */ assign(mapping) {
        return this.pipe(// eslint-disable-next-line @typescript-eslint/no-use-before-define
        new RunnableAssign(// eslint-disable-next-line @typescript-eslint/no-use-before-define
        new RunnableMap({
            steps: mapping
        })));
    }
    /**
     * Default implementation of transform, which buffers input and then calls stream.
     * Subclasses should override this method if they can start producing output while
     * input is still being generated.
     * @param generator
     * @param options
     */ async *transform(generator, options) {
        let finalChunk;
        for await (const chunk of generator){
            if (finalChunk === undefined) {
                finalChunk = chunk;
            } else {
                // Make a best effort to gather, for any type that supports concat.
                // This method should throw an error if gathering fails.
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                finalChunk = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["concat"])(finalChunk, chunk);
            }
        }
        yield* this._streamIterator(finalChunk, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options));
    }
    /**
     * Stream all output from a runnable, as reported to the callback system.
     * This includes all inner runs of LLMs, Retrievers, Tools, etc.
     * Output is streamed as Log objects, which include a list of
     * jsonpatch ops that describe how the state of the run has changed in each
     * step, and the final state of the run.
     * The jsonpatch ops can be applied in order to construct state.
     * @param input
     * @param options
     * @param streamOptions
     */ async *streamLog(input, options, streamOptions) {
        const logStreamCallbackHandler = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$log_stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LogStreamCallbackHandler"]({
            ...streamOptions,
            autoClose: false,
            _schemaFormat: "original"
        });
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        yield* this._streamLog(input, logStreamCallbackHandler, config);
    }
    async *_streamLog(input, logStreamCallbackHandler, config) {
        const { callbacks } = config;
        if (callbacks === undefined) {
            // eslint-disable-next-line no-param-reassign
            config.callbacks = [
                logStreamCallbackHandler
            ];
        } else if (Array.isArray(callbacks)) {
            // eslint-disable-next-line no-param-reassign
            config.callbacks = callbacks.concat([
                logStreamCallbackHandler
            ]);
        } else {
            const copiedCallbacks = callbacks.copy();
            copiedCallbacks.addHandler(logStreamCallbackHandler, true);
            // eslint-disable-next-line no-param-reassign
            config.callbacks = copiedCallbacks;
        }
        const runnableStreamPromise = this.stream(input, config);
        async function consumeRunnableStream() {
            try {
                const runnableStream = await runnableStreamPromise;
                for await (const chunk of runnableStream){
                    const patch = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$log_stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RunLogPatch"]({
                        ops: [
                            {
                                op: "add",
                                path: "/streamed_output/-",
                                value: chunk
                            }
                        ]
                    });
                    await logStreamCallbackHandler.writer.write(patch);
                }
            } finally{
                await logStreamCallbackHandler.writer.close();
            }
        }
        const runnableStreamConsumePromise = consumeRunnableStream();
        try {
            for await (const log of logStreamCallbackHandler){
                yield log;
            }
        } finally{
            await runnableStreamConsumePromise;
        }
    }
    streamEvents(input, options, streamOptions) {
        let stream;
        if (options.version === "v1") {
            stream = this._streamEventsV1(input, options, streamOptions);
        } else if (options.version === "v2") {
            stream = this._streamEventsV2(input, options, streamOptions);
        } else {
            throw new Error(`Only versions "v1" and "v2" of the schema are currently supported.`);
        }
        if (options.encoding === "text/event-stream") {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$wrappers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["convertToHttpEventStream"])(stream);
        } else {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IterableReadableStream"].fromAsyncGenerator(stream);
        }
    }
    async *_streamEventsV2(input, options, streamOptions) {
        const eventStreamer = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$event_stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["EventStreamCallbackHandler"]({
            ...streamOptions,
            autoClose: false
        });
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        const runId = config.runId ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])();
        config.runId = runId;
        const callbacks = config.callbacks;
        if (callbacks === undefined) {
            config.callbacks = [
                eventStreamer
            ];
        } else if (Array.isArray(callbacks)) {
            config.callbacks = callbacks.concat(eventStreamer);
        } else {
            const copiedCallbacks = callbacks.copy();
            copiedCallbacks.addHandler(eventStreamer, true);
            // eslint-disable-next-line no-param-reassign
            config.callbacks = copiedCallbacks;
        }
        // Call the runnable in streaming mode,
        // add each chunk to the output stream
        const outerThis = this;
        async function consumeRunnableStream() {
            try {
                const runnableStream = await outerThis.stream(input, config);
                const tappedStream = eventStreamer.tapOutputIterable(runId, runnableStream);
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                for await (const _ of tappedStream){
                // Just iterate so that the callback handler picks up events
                }
            } finally{
                await eventStreamer.finish();
            }
        }
        const runnableStreamConsumePromise = consumeRunnableStream();
        let firstEventSent = false;
        let firstEventRunId;
        try {
            for await (const event of eventStreamer){
                // This is a work-around an issue where the inputs into the
                // chain are not available until the entire input is consumed.
                // As a temporary solution, we'll modify the input to be the input
                // that was passed into the chain.
                if (!firstEventSent) {
                    event.data.input = input;
                    firstEventSent = true;
                    firstEventRunId = event.run_id;
                    yield event;
                    continue;
                }
                if (event.run_id === firstEventRunId && event.event.endsWith("_end")) {
                    // If it's the end event corresponding to the root runnable
                    // we dont include the input in the event since it's guaranteed
                    // to be included in the first event.
                    if (event.data?.input) {
                        delete event.data.input;
                    }
                }
                yield event;
            }
        } finally{
            await runnableStreamConsumePromise;
        }
    }
    async *_streamEventsV1(input, options, streamOptions) {
        let runLog;
        let hasEncounteredStartEvent = false;
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        const rootTags = config.tags ?? [];
        const rootMetadata = config.metadata ?? {};
        const rootName = config.runName ?? this.getName();
        const logStreamCallbackHandler = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$log_stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LogStreamCallbackHandler"]({
            ...streamOptions,
            autoClose: false,
            _schemaFormat: "streaming_events"
        });
        const rootEventFilter = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_RootEventFilter"]({
            ...streamOptions
        });
        const logStream = this._streamLog(input, logStreamCallbackHandler, config);
        for await (const log of logStream){
            if (!runLog) {
                runLog = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$log_stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RunLog"].fromRunLogPatch(log);
            } else {
                runLog = runLog.concat(log);
            }
            if (runLog.state === undefined) {
                throw new Error(`Internal error: "streamEvents" state is missing. Please open a bug report.`);
            }
            // Yield the start event for the root runnable if it hasn't been seen.
            // The root run is never filtered out
            if (!hasEncounteredStartEvent) {
                hasEncounteredStartEvent = true;
                const state = {
                    ...runLog.state
                };
                const event = {
                    run_id: state.id,
                    event: `on_${state.type}_start`,
                    name: rootName,
                    tags: rootTags,
                    metadata: rootMetadata,
                    data: {
                        input
                    }
                };
                if (rootEventFilter.includeEvent(event, state.type)) {
                    yield event;
                }
            }
            const paths = log.ops.filter((op)=>op.path.startsWith("/logs/")).map((op)=>op.path.split("/")[2]);
            const dedupedPaths = [
                ...new Set(paths)
            ];
            for (const path of dedupedPaths){
                let eventType;
                let data = {};
                const logEntry = runLog.state.logs[path];
                if (logEntry.end_time === undefined) {
                    if (logEntry.streamed_output.length > 0) {
                        eventType = "stream";
                    } else {
                        eventType = "start";
                    }
                } else {
                    eventType = "end";
                }
                if (eventType === "start") {
                    // Include the inputs with the start event if they are available.
                    // Usually they will NOT be available for components that operate
                    // on streams, since those components stream the input and
                    // don't know its final value until the end of the stream.
                    if (logEntry.inputs !== undefined) {
                        data.input = logEntry.inputs;
                    }
                } else if (eventType === "end") {
                    if (logEntry.inputs !== undefined) {
                        data.input = logEntry.inputs;
                    }
                    data.output = logEntry.final_output;
                } else if (eventType === "stream") {
                    const chunkCount = logEntry.streamed_output.length;
                    if (chunkCount !== 1) {
                        throw new Error(`Expected exactly one chunk of streamed output, got ${chunkCount} instead. Encountered in: "${logEntry.name}"`);
                    }
                    data = {
                        chunk: logEntry.streamed_output[0]
                    };
                    // Clean up the stream, we don't need it anymore.
                    // And this avoids duplicates as well!
                    logEntry.streamed_output = [];
                }
                yield {
                    event: `on_${logEntry.type}_${eventType}`,
                    name: logEntry.name,
                    run_id: logEntry.id,
                    tags: logEntry.tags,
                    metadata: logEntry.metadata,
                    data
                };
            }
            // Finally, we take care of the streaming output from the root chain
            // if there is any.
            const { state } = runLog;
            if (state.streamed_output.length > 0) {
                const chunkCount = state.streamed_output.length;
                if (chunkCount !== 1) {
                    throw new Error(`Expected exactly one chunk of streamed output, got ${chunkCount} instead. Encountered in: "${state.name}"`);
                }
                const data = {
                    chunk: state.streamed_output[0]
                };
                // Clean up the stream, we don't need it anymore.
                state.streamed_output = [];
                const event = {
                    event: `on_${state.type}_stream`,
                    run_id: state.id,
                    tags: rootTags,
                    metadata: rootMetadata,
                    name: rootName,
                    data
                };
                if (rootEventFilter.includeEvent(event, state.type)) {
                    yield event;
                }
            }
        }
        const state = runLog?.state;
        if (state !== undefined) {
            // Finally, yield the end event for the root runnable.
            const event = {
                event: `on_${state.type}_end`,
                name: rootName,
                run_id: state.id,
                tags: rootTags,
                metadata: rootMetadata,
                data: {
                    output: state.final_output
                }
            };
            if (rootEventFilter.includeEvent(event, state.type)) yield event;
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static isRunnable(thing) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isRunnableInterface"])(thing);
    }
    /**
     * Bind lifecycle listeners to a Runnable, returning a new Runnable.
     * The Run object contains information about the run, including its id,
     * type, input, output, error, startTime, endTime, and any tags or metadata
     * added to the run.
     *
     * @param {Object} params - The object containing the callback functions.
     * @param {(run: Run) => void} params.onStart - Called before the runnable starts running, with the Run object.
     * @param {(run: Run) => void} params.onEnd - Called after the runnable finishes running, with the Run object.
     * @param {(run: Run) => void} params.onError - Called if the runnable throws an error, with the Run object.
     */ withListeners({ onStart, onEnd, onError }) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return new RunnableBinding({
            bound: this,
            config: {},
            configFactories: [
                (config)=>({
                        callbacks: [
                            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$root_listener$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RootListenersTracer"]({
                                config,
                                onStart,
                                onEnd,
                                onError
                            })
                        ]
                    })
            ]
        });
    }
    /**
     * Convert a runnable to a tool. Return a new instance of `RunnableToolLike`
     * which contains the runnable, name, description and schema.
     *
     * @template {T extends RunInput = RunInput} RunInput - The input type of the runnable. Should be the same as the `RunInput` type of the runnable.
     *
     * @param fields
     * @param {string | undefined} [fields.name] The name of the tool. If not provided, it will default to the name of the runnable.
     * @param {string | undefined} [fields.description] The description of the tool. Falls back to the description on the Zod schema if not provided, or undefined if neither are provided.
     * @param {z.ZodType<T>} [fields.schema] The Zod schema for the input of the tool. Infers the Zod type from the input type of the runnable.
     * @returns {RunnableToolLike<z.ZodType<T>, RunOutput>} An instance of `RunnableToolLike` which is a runnable that can be used as a tool.
     */ asTool(fields) {
        return convertRunnableToTool(this, fields);
    }
}
class RunnableBinding extends Runnable {
    static lc_name() {
        return "RunnableBinding";
    }
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "runnables"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "bound", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "config", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "kwargs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "configFactories", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.bound = fields.bound;
        this.kwargs = fields.kwargs;
        this.config = fields.config;
        this.configFactories = fields.configFactories;
    }
    getName(suffix) {
        return this.bound.getName(suffix);
    }
    async _mergeConfig(...options) {
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mergeConfigs"])(this.config, ...options);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mergeConfigs"])(config, ...this.configFactories ? await Promise.all(this.configFactories.map(async (configFactory)=>await configFactory(config))) : []);
    }
    bind(kwargs) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return new this.constructor({
            bound: this.bound,
            kwargs: {
                ...this.kwargs,
                ...kwargs
            },
            config: this.config
        });
    }
    withConfig(config) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return new this.constructor({
            bound: this.bound,
            kwargs: this.kwargs,
            config: {
                ...this.config,
                ...config
            }
        });
    }
    withRetry(fields) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return new this.constructor({
            bound: this.bound.withRetry(fields),
            kwargs: this.kwargs,
            config: this.config
        });
    }
    async invoke(input, options) {
        return this.bound.invoke(input, await this._mergeConfig((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options), this.kwargs));
    }
    async batch(inputs, options, batchOptions) {
        const mergedOptions = Array.isArray(options) ? await Promise.all(options.map(async (individualOption)=>this._mergeConfig((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(individualOption), this.kwargs))) : await this._mergeConfig((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options), this.kwargs);
        return this.bound.batch(inputs, mergedOptions, batchOptions);
    }
    async *_streamIterator(input, options) {
        yield* this.bound._streamIterator(input, await this._mergeConfig((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options), this.kwargs));
    }
    async stream(input, options) {
        return this.bound.stream(input, await this._mergeConfig((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options), this.kwargs));
    }
    async *transform(generator, options) {
        yield* this.bound.transform(generator, await this._mergeConfig((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options), this.kwargs));
    }
    streamEvents(input, options, streamOptions) {
        // eslint-disable-next-line @typescript-eslint/no-this-alias
        const outerThis = this;
        const generator = async function*() {
            yield* outerThis.bound.streamEvents(input, {
                ...await outerThis._mergeConfig((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options), outerThis.kwargs),
                version: options.version
            }, streamOptions);
        };
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IterableReadableStream"].fromAsyncGenerator(generator());
    }
    static isRunnableBinding(// eslint-disable-next-line @typescript-eslint/no-explicit-any
    thing) {
        return thing.bound && Runnable.isRunnable(thing.bound);
    }
    /**
     * Bind lifecycle listeners to a Runnable, returning a new Runnable.
     * The Run object contains information about the run, including its id,
     * type, input, output, error, startTime, endTime, and any tags or metadata
     * added to the run.
     *
     * @param {Object} params - The object containing the callback functions.
     * @param {(run: Run) => void} params.onStart - Called before the runnable starts running, with the Run object.
     * @param {(run: Run) => void} params.onEnd - Called after the runnable finishes running, with the Run object.
     * @param {(run: Run) => void} params.onError - Called if the runnable throws an error, with the Run object.
     */ withListeners({ onStart, onEnd, onError }) {
        return new RunnableBinding({
            bound: this.bound,
            kwargs: this.kwargs,
            config: this.config,
            configFactories: [
                (config)=>({
                        callbacks: [
                            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tracers$2f$root_listener$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RootListenersTracer"]({
                                config,
                                onStart,
                                onEnd,
                                onError
                            })
                        ]
                    })
            ]
        });
    }
}
class RunnableEach extends Runnable {
    static lc_name() {
        return "RunnableEach";
    }
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "runnables"
            ]
        });
        Object.defineProperty(this, "bound", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.bound = fields.bound;
    }
    /**
     * Binds the runnable with the specified arguments.
     * @param kwargs The arguments to bind the runnable with.
     * @returns A new instance of the `RunnableEach` class that is bound with the specified arguments.
     */ bind(kwargs) {
        return new RunnableEach({
            bound: this.bound.bind(kwargs)
        });
    }
    /**
     * Invokes the runnable with the specified input and configuration.
     * @param input The input to invoke the runnable with.
     * @param config The configuration to invoke the runnable with.
     * @returns A promise that resolves to the output of the runnable.
     */ async invoke(inputs, config) {
        return this._callWithConfig(this._invoke.bind(this), inputs, config);
    }
    /**
     * A helper method that is used to invoke the runnable with the specified input and configuration.
     * @param input The input to invoke the runnable with.
     * @param config The configuration to invoke the runnable with.
     * @returns A promise that resolves to the output of the runnable.
     */ async _invoke(inputs, config, runManager) {
        return this.bound.batch(inputs, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
            callbacks: runManager?.getChild()
        }));
    }
    /**
     * Bind lifecycle listeners to a Runnable, returning a new Runnable.
     * The Run object contains information about the run, including its id,
     * type, input, output, error, startTime, endTime, and any tags or metadata
     * added to the run.
     *
     * @param {Object} params - The object containing the callback functions.
     * @param {(run: Run) => void} params.onStart - Called before the runnable starts running, with the Run object.
     * @param {(run: Run) => void} params.onEnd - Called after the runnable finishes running, with the Run object.
     * @param {(run: Run) => void} params.onError - Called if the runnable throws an error, with the Run object.
     */ withListeners({ onStart, onEnd, onError }) {
        return new RunnableEach({
            bound: this.bound.withListeners({
                onStart,
                onEnd,
                onError
            })
        });
    }
}
class RunnableRetry extends RunnableBinding {
    static lc_name() {
        return "RunnableRetry";
    }
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "runnables"
            ]
        });
        Object.defineProperty(this, "maxAttemptNumber", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 3
        });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        Object.defineProperty(this, "onFailedAttempt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ()=>{}
        });
        this.maxAttemptNumber = fields.maxAttemptNumber ?? this.maxAttemptNumber;
        this.onFailedAttempt = fields.onFailedAttempt ?? this.onFailedAttempt;
    }
    _patchConfigForRetry(attempt, config, runManager) {
        const tag = attempt > 1 ? `retry:attempt:${attempt}` : undefined;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
            callbacks: runManager?.getChild(tag)
        });
    }
    async _invoke(input, config, runManager) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$p$2d$retry$40$4$2e$6$2e$2$2f$node_modules$2f$p$2d$retry$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])((attemptNumber)=>super.invoke(input, this._patchConfigForRetry(attemptNumber, config, runManager)), {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            onFailedAttempt: (error)=>this.onFailedAttempt(error, input),
            retries: Math.max(this.maxAttemptNumber - 1, 0),
            randomize: true
        });
    }
    /**
     * Method that invokes the runnable with the specified input, run manager,
     * and config. It handles the retry logic by catching any errors and
     * recursively invoking itself with the updated config for the next retry
     * attempt.
     * @param input The input for the runnable.
     * @param runManager The run manager for the runnable.
     * @param config The config for the runnable.
     * @returns A promise that resolves to the output of the runnable.
     */ async invoke(input, config) {
        return this._callWithConfig(this._invoke.bind(this), input, config);
    }
    async _batch(inputs, configs, runManagers, batchOptions) {
        const resultsMap = {};
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$p$2d$retry$40$4$2e$6$2e$2$2f$node_modules$2f$p$2d$retry$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])(async (attemptNumber)=>{
                const remainingIndexes = inputs.map((_, i)=>i).filter((i)=>resultsMap[i.toString()] === undefined || // eslint-disable-next-line no-instanceof/no-instanceof
                    resultsMap[i.toString()] instanceof Error);
                const remainingInputs = remainingIndexes.map((i)=>inputs[i]);
                const patchedConfigs = remainingIndexes.map((i)=>this._patchConfigForRetry(attemptNumber, configs?.[i], runManagers?.[i]));
                const results = await super.batch(remainingInputs, patchedConfigs, {
                    ...batchOptions,
                    returnExceptions: true
                });
                let firstException;
                for(let i = 0; i < results.length; i += 1){
                    const result = results[i];
                    const resultMapIndex = remainingIndexes[i];
                    // eslint-disable-next-line no-instanceof/no-instanceof
                    if (result instanceof Error) {
                        if (firstException === undefined) {
                            firstException = result;
                            // eslint-disable-next-line @typescript-eslint/no-explicit-any
                            firstException.input = remainingInputs[i];
                        }
                    }
                    resultsMap[resultMapIndex.toString()] = result;
                }
                if (firstException) {
                    throw firstException;
                }
                return results;
            }, {
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                onFailedAttempt: (error)=>this.onFailedAttempt(error, error.input),
                retries: Math.max(this.maxAttemptNumber - 1, 0),
                randomize: true
            });
        } catch (e) {
            if (batchOptions?.returnExceptions !== true) {
                throw e;
            }
        }
        return Object.keys(resultsMap).sort((a, b)=>parseInt(a, 10) - parseInt(b, 10)).map((key)=>resultsMap[parseInt(key, 10)]);
    }
    async batch(inputs, options, batchOptions) {
        return this._batchWithConfig(this._batch.bind(this), inputs, options, batchOptions);
    }
}
class RunnableSequence extends Runnable {
    static lc_name() {
        return "RunnableSequence";
    }
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "first", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "middle", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        Object.defineProperty(this, "last", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "omitSequenceTags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "runnables"
            ]
        });
        this.first = fields.first;
        this.middle = fields.middle ?? this.middle;
        this.last = fields.last;
        this.name = fields.name;
        this.omitSequenceTags = fields.omitSequenceTags ?? this.omitSequenceTags;
    }
    get steps() {
        return [
            this.first,
            ...this.middle,
            this.last
        ];
    }
    async invoke(input, options) {
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        const callbackManager_ = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCallbackManagerForConfig"])(config);
        const runManager = await callbackManager_?.handleChainStart(this.toJSON(), _coerceToDict(input, "input"), config.runId, undefined, undefined, undefined, config?.runName);
        delete config.runId;
        let nextStepInput = input;
        let finalOutput;
        try {
            const initialSteps = [
                this.first,
                ...this.middle
            ];
            for(let i = 0; i < initialSteps.length; i += 1){
                const step = initialSteps[i];
                const promise = step.invoke(nextStepInput, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
                    callbacks: runManager?.getChild(this.omitSequenceTags ? undefined : `seq:step:${i + 1}`)
                }));
                nextStepInput = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$signal$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["raceWithSignal"])(promise, options?.signal);
            }
            // TypeScript can't detect that the last output of the sequence returns RunOutput, so call it out of the loop here
            if (options?.signal?.aborted) {
                throw new Error("Aborted");
            }
            finalOutput = await this.last.invoke(nextStepInput, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
                callbacks: runManager?.getChild(this.omitSequenceTags ? undefined : `seq:step:${this.steps.length}`)
            }));
        } catch (e) {
            await runManager?.handleChainError(e);
            throw e;
        }
        await runManager?.handleChainEnd(_coerceToDict(finalOutput, "output"));
        return finalOutput;
    }
    async batch(inputs, options, batchOptions) {
        const configList = this._getOptionsList(options ?? {}, inputs.length);
        const callbackManagers = await Promise.all(configList.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCallbackManagerForConfig"]));
        const runManagers = await Promise.all(callbackManagers.map(async (callbackManager, i)=>{
            const handleStartRes = await callbackManager?.handleChainStart(this.toJSON(), _coerceToDict(inputs[i], "input"), configList[i].runId, undefined, undefined, undefined, configList[i].runName);
            delete configList[i].runId;
            return handleStartRes;
        }));
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let nextStepInputs = inputs;
        try {
            for(let i = 0; i < this.steps.length; i += 1){
                const step = this.steps[i];
                const promise = step.batch(nextStepInputs, runManagers.map((runManager, j)=>{
                    const childRunManager = runManager?.getChild(this.omitSequenceTags ? undefined : `seq:step:${i + 1}`);
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(configList[j], {
                        callbacks: childRunManager
                    });
                }), batchOptions);
                nextStepInputs = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$signal$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["raceWithSignal"])(promise, configList[0]?.signal);
            }
        } catch (e) {
            await Promise.all(runManagers.map((runManager)=>runManager?.handleChainError(e)));
            throw e;
        }
        await Promise.all(runManagers.map((runManager)=>runManager?.handleChainEnd(_coerceToDict(nextStepInputs, "output"))));
        return nextStepInputs;
    }
    async *_streamIterator(input, options) {
        const callbackManager_ = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCallbackManagerForConfig"])(options);
        const { runId, ...otherOptions } = options ?? {};
        const runManager = await callbackManager_?.handleChainStart(this.toJSON(), _coerceToDict(input, "input"), runId, undefined, undefined, undefined, otherOptions?.runName);
        const steps = [
            this.first,
            ...this.middle,
            this.last
        ];
        let concatSupported = true;
        let finalOutput;
        async function* inputGenerator() {
            yield input;
        }
        try {
            let finalGenerator = steps[0].transform(inputGenerator(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(otherOptions, {
                callbacks: runManager?.getChild(this.omitSequenceTags ? undefined : `seq:step:1`)
            }));
            for(let i = 1; i < steps.length; i += 1){
                const step = steps[i];
                finalGenerator = await step.transform(finalGenerator, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(otherOptions, {
                    callbacks: runManager?.getChild(this.omitSequenceTags ? undefined : `seq:step:${i + 1}`)
                }));
            }
            for await (const chunk of finalGenerator){
                options?.signal?.throwIfAborted();
                yield chunk;
                if (concatSupported) {
                    if (finalOutput === undefined) {
                        finalOutput = chunk;
                    } else {
                        try {
                            // eslint-disable-next-line @typescript-eslint/no-explicit-any
                            finalOutput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["concat"])(finalOutput, chunk);
                        } catch (e) {
                            finalOutput = undefined;
                            concatSupported = false;
                        }
                    }
                }
            }
        } catch (e) {
            await runManager?.handleChainError(e);
            throw e;
        }
        await runManager?.handleChainEnd(_coerceToDict(finalOutput, "output"));
    }
    getGraph(config) {
        const graph = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$graph$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Graph"]();
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let currentLastNode = null;
        this.steps.forEach((step, index)=>{
            const stepGraph = step.getGraph(config);
            if (index !== 0) {
                stepGraph.trimFirstNode();
            }
            if (index !== this.steps.length - 1) {
                stepGraph.trimLastNode();
            }
            graph.extend(stepGraph);
            const stepFirstNode = stepGraph.firstNode();
            if (!stepFirstNode) {
                throw new Error(`Runnable ${step} has no first node`);
            }
            if (currentLastNode) {
                graph.addEdge(currentLastNode, stepFirstNode);
            }
            currentLastNode = stepGraph.lastNode();
        });
        return graph;
    }
    pipe(coerceable) {
        if (RunnableSequence.isRunnableSequence(coerceable)) {
            return new RunnableSequence({
                first: this.first,
                middle: this.middle.concat([
                    this.last,
                    coerceable.first,
                    ...coerceable.middle
                ]),
                last: coerceable.last,
                name: this.name ?? coerceable.name
            });
        } else {
            return new RunnableSequence({
                first: this.first,
                middle: [
                    ...this.middle,
                    this.last
                ],
                last: _coerceToRunnable(coerceable),
                name: this.name
            });
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static isRunnableSequence(thing) {
        return Array.isArray(thing.middle) && Runnable.isRunnable(thing);
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static from([first, ...runnables], nameOrFields) {
        let extra = {};
        if (typeof nameOrFields === "string") {
            extra.name = nameOrFields;
        } else if (nameOrFields !== undefined) {
            extra = nameOrFields;
        }
        return new RunnableSequence({
            ...extra,
            first: _coerceToRunnable(first),
            middle: runnables.slice(0, -1).map(_coerceToRunnable),
            last: _coerceToRunnable(runnables[runnables.length - 1])
        });
    }
}
class RunnableMap extends Runnable {
    static lc_name() {
        return "RunnableMap";
    }
    getStepsKeys() {
        return Object.keys(this.steps);
    }
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "runnables"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "steps", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.steps = {};
        for (const [key, value] of Object.entries(fields.steps)){
            this.steps[key] = _coerceToRunnable(value);
        }
    }
    static from(steps) {
        return new RunnableMap({
            steps
        });
    }
    async invoke(input, options) {
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        const callbackManager_ = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCallbackManagerForConfig"])(config);
        const runManager = await callbackManager_?.handleChainStart(this.toJSON(), {
            input
        }, config.runId, undefined, undefined, undefined, config?.runName);
        delete config.runId;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const output = {};
        try {
            const promises = Object.entries(this.steps).map(async ([key, runnable])=>{
                output[key] = await runnable.invoke(input, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
                    callbacks: runManager?.getChild(`map:key:${key}`)
                }));
            });
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$signal$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["raceWithSignal"])(Promise.all(promises), options?.signal);
        } catch (e) {
            await runManager?.handleChainError(e);
            throw e;
        }
        await runManager?.handleChainEnd(output);
        return output;
    }
    async *_transform(generator, runManager, options) {
        // shallow copy steps to ignore changes while iterating
        const steps = {
            ...this.steps
        };
        // each step gets a copy of the input iterator
        const inputCopies = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["atee"])(generator, Object.keys(steps).length);
        // start the first iteration of each output iterator
        const tasks = new Map(Object.entries(steps).map(([key, runnable], i)=>{
            const gen = runnable.transform(inputCopies[i], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(options, {
                callbacks: runManager?.getChild(`map:key:${key}`)
            }));
            return [
                key,
                gen.next().then((result)=>({
                        key,
                        gen,
                        result
                    }))
            ];
        }));
        // yield chunks as they become available,
        // starting new iterations as needed,
        // until all iterators are done
        while(tasks.size){
            const promise = Promise.race(tasks.values());
            const { key, result, gen } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$signal$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["raceWithSignal"])(promise, options?.signal);
            tasks.delete(key);
            if (!result.done) {
                yield {
                    [key]: result.value
                };
                tasks.set(key, gen.next().then((result)=>({
                        key,
                        gen,
                        result
                    })));
            }
        }
    }
    transform(generator, options) {
        return this._transformStreamWithConfig(generator, this._transform.bind(this), options);
    }
    async stream(input, options) {
        async function* generator() {
            yield input;
        }
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        const wrappedGenerator = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncGeneratorWithSetup"]({
            generator: this.transform(generator(), config),
            config
        });
        await wrappedGenerator.setup;
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IterableReadableStream"].fromAsyncGenerator(wrappedGenerator);
    }
}
class RunnableTraceable extends Runnable {
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "runnables"
            ]
        });
        Object.defineProperty(this, "func", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$singletons$2f$traceable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isTraceableFunction"])(fields.func)) {
            throw new Error("RunnableTraceable requires a function that is wrapped in traceable higher-order function");
        }
        this.func = fields.func;
    }
    async invoke(input, options) {
        const [config] = this._getOptionsList(options ?? {}, 1);
        const callbacks = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCallbackManagerForConfig"])(config);
        const promise = this.func((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
            callbacks
        }), input);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$signal$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["raceWithSignal"])(promise, config?.signal);
    }
    async *_streamIterator(input, options) {
        const [config] = this._getOptionsList(options ?? {}, 1);
        const result = await this.invoke(input, options);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$iter$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isAsyncIterable"])(result)) {
            for await (const item of result){
                config?.signal?.throwIfAborted();
                yield item;
            }
            return;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$iter$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isIterator"])(result)) {
            while(true){
                config?.signal?.throwIfAborted();
                const state = result.next();
                if (state.done) break;
                yield state.value;
            }
            return;
        }
        yield result;
    }
    static from(func) {
        return new RunnableTraceable({
            func
        });
    }
}
function assertNonTraceableFunction(func) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$singletons$2f$traceable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isTraceableFunction"])(func)) {
        throw new Error("RunnableLambda requires a function that is not wrapped in traceable higher-order function. This shouldn't happen.");
    }
}
class RunnableLambda extends Runnable {
    static lc_name() {
        return "RunnableLambda";
    }
    constructor(fields){
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$langsmith$40$0$2e$2$2e$15_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f$langsmith$2f$dist$2f$singletons$2f$traceable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isTraceableFunction"])(fields.func)) {
            // eslint-disable-next-line no-constructor-return
            return RunnableTraceable.from(fields.func);
        }
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "runnables"
            ]
        });
        Object.defineProperty(this, "func", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        assertNonTraceableFunction(fields.func);
        this.func = fields.func;
    }
    static from(func) {
        return new RunnableLambda({
            func
        });
    }
    async _invoke(input, config, runManager) {
        return new Promise((resolve, reject)=>{
            const childConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
                callbacks: runManager?.getChild(),
                recursionLimit: (config?.recursionLimit ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RECURSION_LIMIT"]) - 1
            });
            void __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncLocalStorageProviderSingleton"].runWithConfig((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["pickRunnableConfigKeys"])(childConfig), async ()=>{
                try {
                    let output = await this.func(input, {
                        ...childConfig
                    });
                    if (output && Runnable.isRunnable(output)) {
                        if (config?.recursionLimit === 0) {
                            throw new Error("Recursion limit reached.");
                        }
                        output = await output.invoke(input, {
                            ...childConfig,
                            recursionLimit: (childConfig.recursionLimit ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RECURSION_LIMIT"]) - 1
                        });
                    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$iter$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isAsyncIterable"])(output)) {
                        let finalOutput;
                        for await (const chunk of (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$iter$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeAsyncIterableInContext"])(childConfig, output)){
                            config?.signal?.throwIfAborted();
                            if (finalOutput === undefined) {
                                finalOutput = chunk;
                            } else {
                                // Make a best effort to gather, for any type that supports concat.
                                try {
                                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                                    finalOutput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["concat"])(finalOutput, chunk);
                                } catch (e) {
                                    finalOutput = chunk;
                                }
                            }
                        }
                        output = finalOutput;
                    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$iter$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isIterableIterator"])(output)) {
                        let finalOutput;
                        for (const chunk of (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$iter$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeIteratorInContext"])(childConfig, output)){
                            config?.signal?.throwIfAborted();
                            if (finalOutput === undefined) {
                                finalOutput = chunk;
                            } else {
                                // Make a best effort to gather, for any type that supports concat.
                                try {
                                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                                    finalOutput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["concat"])(finalOutput, chunk);
                                } catch (e) {
                                    finalOutput = chunk;
                                }
                            }
                        }
                        output = finalOutput;
                    }
                    resolve(output);
                } catch (e) {
                    reject(e);
                }
            });
        });
    }
    async invoke(input, options) {
        return this._callWithConfig(this._invoke.bind(this), input, options);
    }
    async *_transform(generator, runManager, config) {
        let finalChunk;
        for await (const chunk of generator){
            if (finalChunk === undefined) {
                finalChunk = chunk;
            } else {
                // Make a best effort to gather, for any type that supports concat.
                try {
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    finalChunk = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["concat"])(finalChunk, chunk);
                } catch (e) {
                    finalChunk = chunk;
                }
            }
        }
        const childConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
            callbacks: runManager?.getChild(),
            recursionLimit: (config?.recursionLimit ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RECURSION_LIMIT"]) - 1
        });
        const output = await new Promise((resolve, reject)=>{
            void __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncLocalStorageProviderSingleton"].runWithConfig((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["pickRunnableConfigKeys"])(childConfig), async ()=>{
                try {
                    const res = await this.func(finalChunk, {
                        ...childConfig,
                        config: childConfig
                    });
                    resolve(res);
                } catch (e) {
                    reject(e);
                }
            });
        });
        if (output && Runnable.isRunnable(output)) {
            if (config?.recursionLimit === 0) {
                throw new Error("Recursion limit reached.");
            }
            const stream = await output.stream(finalChunk, childConfig);
            for await (const chunk of stream){
                yield chunk;
            }
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$iter$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isAsyncIterable"])(output)) {
            for await (const chunk of (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$iter$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeAsyncIterableInContext"])(childConfig, output)){
                config?.signal?.throwIfAborted();
                yield chunk;
            }
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$iter$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isIterableIterator"])(output)) {
            for (const chunk of (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$iter$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeIteratorInContext"])(childConfig, output)){
                config?.signal?.throwIfAborted();
                yield chunk;
            }
        } else {
            yield output;
        }
    }
    transform(generator, options) {
        return this._transformStreamWithConfig(generator, this._transform.bind(this), options);
    }
    async stream(input, options) {
        async function* generator() {
            yield input;
        }
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        const wrappedGenerator = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncGeneratorWithSetup"]({
            generator: this.transform(generator(), config),
            config
        });
        await wrappedGenerator.setup;
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IterableReadableStream"].fromAsyncGenerator(wrappedGenerator);
    }
}
class RunnableParallel extends RunnableMap {
}
class RunnableWithFallbacks extends Runnable {
    static lc_name() {
        return "RunnableWithFallbacks";
    }
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "runnables"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "runnable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "fallbacks", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.runnable = fields.runnable;
        this.fallbacks = fields.fallbacks;
    }
    *runnables() {
        yield this.runnable;
        for (const fallback of this.fallbacks){
            yield fallback;
        }
    }
    async invoke(input, options) {
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        const callbackManager_ = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCallbackManagerForConfig"])(config);
        const { runId, ...otherConfigFields } = config;
        const runManager = await callbackManager_?.handleChainStart(this.toJSON(), _coerceToDict(input, "input"), runId, undefined, undefined, undefined, otherConfigFields?.runName);
        const childConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(otherConfigFields, {
            callbacks: runManager?.getChild()
        });
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$singletons$2f$async_local_storage$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncLocalStorageProviderSingleton"].runWithConfig(childConfig, async ()=>{
            let firstError;
            for (const runnable of this.runnables()){
                config?.signal?.throwIfAborted();
                try {
                    const output = await runnable.invoke(input, childConfig);
                    await runManager?.handleChainEnd(_coerceToDict(output, "output"));
                    return output;
                } catch (e) {
                    if (firstError === undefined) {
                        firstError = e;
                    }
                }
            }
            if (firstError === undefined) {
                throw new Error("No error stored at end of fallback.");
            }
            await runManager?.handleChainError(firstError);
            throw firstError;
        });
        return res;
    }
    async *_streamIterator(input, options) {
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        const callbackManager_ = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCallbackManagerForConfig"])(config);
        const { runId, ...otherConfigFields } = config;
        const runManager = await callbackManager_?.handleChainStart(this.toJSON(), _coerceToDict(input, "input"), runId, undefined, undefined, undefined, otherConfigFields?.runName);
        let firstError;
        let stream;
        for (const runnable of this.runnables()){
            config?.signal?.throwIfAborted();
            const childConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(otherConfigFields, {
                callbacks: runManager?.getChild()
            });
            try {
                const originalStream = await runnable.stream(input, childConfig);
                stream = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$iter$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["consumeAsyncIterableInContext"])(childConfig, originalStream);
                break;
            } catch (e) {
                if (firstError === undefined) {
                    firstError = e;
                }
            }
        }
        if (stream === undefined) {
            const error = firstError ?? new Error("No error stored at end of fallback.");
            await runManager?.handleChainError(error);
            throw error;
        }
        let output;
        try {
            for await (const chunk of stream){
                yield chunk;
                try {
                    output = output === undefined ? output : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["concat"])(output, chunk);
                } catch (e) {
                    output = undefined;
                }
            }
        } catch (e) {
            await runManager?.handleChainError(e);
            throw e;
        }
        await runManager?.handleChainEnd(_coerceToDict(output, "output"));
    }
    async batch(inputs, options, batchOptions) {
        if (batchOptions?.returnExceptions) {
            throw new Error("Not implemented.");
        }
        const configList = this._getOptionsList(options ?? {}, inputs.length);
        const callbackManagers = await Promise.all(configList.map((config)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCallbackManagerForConfig"])(config)));
        const runManagers = await Promise.all(callbackManagers.map(async (callbackManager, i)=>{
            const handleStartRes = await callbackManager?.handleChainStart(this.toJSON(), _coerceToDict(inputs[i], "input"), configList[i].runId, undefined, undefined, undefined, configList[i].runName);
            delete configList[i].runId;
            return handleStartRes;
        }));
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let firstError;
        for (const runnable of this.runnables()){
            configList[0].signal?.throwIfAborted();
            try {
                const outputs = await runnable.batch(inputs, runManagers.map((runManager, j)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(configList[j], {
                        callbacks: runManager?.getChild()
                    })), batchOptions);
                await Promise.all(runManagers.map((runManager, i)=>runManager?.handleChainEnd(_coerceToDict(outputs[i], "output"))));
                return outputs;
            } catch (e) {
                if (firstError === undefined) {
                    firstError = e;
                }
            }
        }
        if (!firstError) {
            throw new Error("No error stored at end of fallbacks.");
        }
        await Promise.all(runManagers.map((runManager)=>runManager?.handleChainError(firstError)));
        throw firstError;
    }
}
function _coerceToRunnable(coerceable) {
    if (typeof coerceable === "function") {
        return new RunnableLambda({
            func: coerceable
        });
    } else if (Runnable.isRunnable(coerceable)) {
        return coerceable;
    } else if (!Array.isArray(coerceable) && typeof coerceable === "object") {
        const runnables = {};
        for (const [key, value] of Object.entries(coerceable)){
            runnables[key] = _coerceToRunnable(value);
        }
        return new RunnableMap({
            steps: runnables
        });
    } else {
        throw new Error(`Expected a Runnable, function or object.\nInstead got an unsupported type.`);
    }
}
class RunnableAssign extends Runnable {
    static lc_name() {
        return "RunnableAssign";
    }
    constructor(fields){
        // eslint-disable-next-line no-instanceof/no-instanceof
        if (fields instanceof RunnableMap) {
            // eslint-disable-next-line no-param-reassign
            fields = {
                mapper: fields
            };
        }
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "runnables"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "mapper", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.mapper = fields.mapper;
    }
    async invoke(input, options) {
        const mapperResult = await this.mapper.invoke(input, options);
        return {
            ...input,
            ...mapperResult
        };
    }
    async *_transform(generator, runManager, options) {
        // collect mapper keys
        const mapperKeys = this.mapper.getStepsKeys();
        // create two input gens, one for the mapper, one for the input
        const [forPassthrough, forMapper] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["atee"])(generator);
        // create mapper output gen
        const mapperOutput = this.mapper.transform(forMapper, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(options, {
            callbacks: runManager?.getChild()
        }));
        // start the mapper
        const firstMapperChunkPromise = mapperOutput.next();
        // yield the passthrough
        for await (const chunk of forPassthrough){
            if (typeof chunk !== "object" || Array.isArray(chunk)) {
                throw new Error(`RunnableAssign can only be used with objects as input, got ${typeof chunk}`);
            }
            const filtered = Object.fromEntries(Object.entries(chunk).filter(([key])=>!mapperKeys.includes(key)));
            if (Object.keys(filtered).length > 0) {
                yield filtered;
            }
        }
        // yield the mapper output
        yield (await firstMapperChunkPromise).value;
        for await (const chunk of mapperOutput){
            yield chunk;
        }
    }
    transform(generator, options) {
        return this._transformStreamWithConfig(generator, this._transform.bind(this), options);
    }
    async stream(input, options) {
        async function* generator() {
            yield input;
        }
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        const wrappedGenerator = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncGeneratorWithSetup"]({
            generator: this.transform(generator(), config),
            config
        });
        await wrappedGenerator.setup;
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IterableReadableStream"].fromAsyncGenerator(wrappedGenerator);
    }
}
class RunnablePick extends Runnable {
    static lc_name() {
        return "RunnablePick";
    }
    constructor(fields){
        if (typeof fields === "string" || Array.isArray(fields)) {
            // eslint-disable-next-line no-param-reassign
            fields = {
                keys: fields
            };
        }
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "runnables"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "keys", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.keys = fields.keys;
    }
    async _pick(input) {
        if (typeof this.keys === "string") {
            return input[this.keys];
        } else {
            const picked = this.keys.map((key)=>[
                    key,
                    input[key]
                ]).filter((v)=>v[1] !== undefined);
            return picked.length === 0 ? undefined : Object.fromEntries(picked);
        }
    }
    async invoke(input, options) {
        return this._callWithConfig(this._pick.bind(this), input, options);
    }
    async *_transform(generator) {
        for await (const chunk of generator){
            const picked = await this._pick(chunk);
            if (picked !== undefined) {
                yield picked;
            }
        }
    }
    transform(generator, options) {
        return this._transformStreamWithConfig(generator, this._transform.bind(this), options);
    }
    async stream(input, options) {
        async function* generator() {
            yield input;
        }
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        const wrappedGenerator = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncGeneratorWithSetup"]({
            generator: this.transform(generator(), config),
            config
        });
        await wrappedGenerator.setup;
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IterableReadableStream"].fromAsyncGenerator(wrappedGenerator);
    }
}
class RunnableToolLike extends RunnableBinding {
    constructor(fields){
        const sequence = RunnableSequence.from([
            RunnableLambda.from(async (input)=>{
                let toolInput;
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tools$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_isToolCall"])(input)) {
                    try {
                        toolInput = await this.schema.parseAsync(input.args);
                    } catch (e) {
                        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$tools$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ToolInputParsingException"](`Received tool input did not match expected schema`, JSON.stringify(input.args));
                    }
                } else {
                    toolInput = input;
                }
                return toolInput;
            }).withConfig({
                runName: `${fields.name}:parse_input`
            }),
            fields.bound
        ]).withConfig({
            runName: fields.name
        });
        super({
            bound: sequence,
            config: fields.config ?? {}
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "description", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "schema", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.name = fields.name;
        this.description = fields.description;
        this.schema = fields.schema;
    }
    static lc_name() {
        return "RunnableToolLike";
    }
}
function convertRunnableToTool(runnable, fields) {
    const name = fields.name ?? runnable.getName();
    const description = fields.description ?? fields.schema?.description;
    if (fields.schema.constructor === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].ZodString) {
        return new RunnableToolLike({
            name,
            description,
            schema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                input: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
            }).transform((input)=>input.input),
            bound: runnable
        });
    }
    return new RunnableToolLike({
        name,
        description,
        schema: fields.schema,
        bound: runnable
    });
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/base.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// Default generic "any" values are for backwards compatibility.
// Replace with "string" when we are comfortable with a breaking change.
__turbopack_esm__({
    "BasePromptTemplate": (()=>BasePromptTemplate)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/base.js [app-route] (ecmascript)");
;
class BasePromptTemplate extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Runnable"] {
    get lc_attributes() {
        return {
            partialVariables: undefined
        };
    }
    constructor(input){
        super(input);
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "prompts",
                this._getPromptType()
            ]
        });
        Object.defineProperty(this, "inputVariables", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "outputParser", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "partialVariables", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /**
         * Metadata to be used for tracing.
         */ Object.defineProperty(this, "metadata", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** Tags to be used for tracing. */ Object.defineProperty(this, "tags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        const { inputVariables } = input;
        if (inputVariables.includes("stop")) {
            throw new Error("Cannot have an input variable named 'stop', as it is used internally, please rename.");
        }
        Object.assign(this, input);
    }
    /**
     * Merges partial variables and user variables.
     * @param userVariables The user variables to merge with the partial variables.
     * @returns A Promise that resolves to an object containing the merged variables.
     */ async mergePartialAndUserVariables(userVariables) {
        const partialVariables = this.partialVariables ?? {};
        const partialValues = {};
        for (const [key, value] of Object.entries(partialVariables)){
            if (typeof value === "string") {
                partialValues[key] = value;
            } else {
                partialValues[key] = await value();
            }
        }
        const allKwargs = {
            ...partialValues,
            ...userVariables
        };
        return allKwargs;
    }
    /**
     * Invokes the prompt template with the given input and options.
     * @param input The input to invoke the prompt template with.
     * @param options Optional configuration for the callback.
     * @returns A Promise that resolves to the output of the prompt template.
     */ async invoke(input, options) {
        const metadata = {
            ...this.metadata,
            ...options?.metadata
        };
        const tags = [
            ...this.tags ?? [],
            ...options?.tags ?? []
        ];
        return this._callWithConfig((input)=>this.formatPromptValue(input), input, {
            ...options,
            tags,
            metadata,
            runType: "prompt"
        });
    }
    /**
     * Return a json-like object representing this prompt template.
     * @deprecated
     */ serialize() {
        throw new Error("Use .toJSON() instead");
    }
    /**
     * @deprecated
     * Load a prompt template from a json-like object describing it.
     *
     * @remarks
     * Deserializing needs to be async because templates (e.g. {@link FewShotPromptTemplate}) can
     * reference remote resources that we read asynchronously with a web
     * request.
     */ static async deserialize(data) {
        switch(data._type){
            case "prompt":
                {
                    const { PromptTemplate } = await __turbopack_require__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/prompt.js [app-route] (ecmascript, async loader)")(__turbopack_import__);
                    return PromptTemplate.deserialize(data);
                }
            case undefined:
                {
                    const { PromptTemplate } = await __turbopack_require__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/prompt.js [app-route] (ecmascript, async loader)")(__turbopack_import__);
                    return PromptTemplate.deserialize({
                        ...data,
                        _type: "prompt"
                    });
                }
            case "few_shot":
                {
                    const { FewShotPromptTemplate } = await __turbopack_require__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/few_shot.js [app-route] (ecmascript, async loader)")(__turbopack_import__);
                    return FewShotPromptTemplate.deserialize(data);
                }
            default:
                throw new Error(`Invalid prompt type in config: ${data._type}`);
        }
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/modifier.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "RemoveMessage": (()=>RemoveMessage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/base.js [app-route] (ecmascript)");
;
class RemoveMessage extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessage"] {
    constructor(fields){
        super({
            ...fields,
            content: ""
        });
        /**
         * The ID of the message to remove.
         */ Object.defineProperty(this, "id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.id = fields.id;
    }
    _getType() {
        return "remove";
    }
    get _printableFields() {
        return {
            ...super._printableFields,
            id: this.id
        };
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/transformers.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "defaultTextSplitter": (()=>defaultTextSplitter),
    "filterMessages": (()=>filterMessages),
    "mergeMessageRuns": (()=>mergeMessageRuns),
    "trimMessages": (()=>trimMessages)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/ai.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/chat.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$function$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/function.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/human.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$modifier$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/modifier.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/system.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$tool$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/tool.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/utils.js [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
;
const _isMessageType = (msg, types)=>{
    const typesAsStrings = [
        ...new Set(types?.map((t)=>{
            if (typeof t === "string") {
                return t;
            }
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const instantiatedMsgClass = new t({});
            if (!("_getType" in instantiatedMsgClass) || typeof instantiatedMsgClass._getType !== "function") {
                throw new Error("Invalid type provided.");
            }
            return instantiatedMsgClass._getType();
        }))
    ];
    const msgType = msg._getType();
    return typesAsStrings.some((t)=>t === msgType);
};
function filterMessages(messagesOrOptions, options) {
    if (Array.isArray(messagesOrOptions)) {
        return _filterMessages(messagesOrOptions, options);
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RunnableLambda"].from((input)=>{
        return _filterMessages(input, messagesOrOptions);
    });
}
function _filterMessages(messages, options = {}) {
    const { includeNames, excludeNames, includeTypes, excludeTypes, includeIds, excludeIds } = options;
    const filtered = [];
    for (const msg of messages){
        if (excludeNames && msg.name && excludeNames.includes(msg.name)) {
            continue;
        } else if (excludeTypes && _isMessageType(msg, excludeTypes)) {
            continue;
        } else if (excludeIds && msg.id && excludeIds.includes(msg.id)) {
            continue;
        }
        // default to inclusion when no inclusion criteria given.
        if (!(includeTypes || includeIds || includeNames)) {
            filtered.push(msg);
        } else if (includeNames && msg.name && includeNames.some((iName)=>iName === msg.name)) {
            filtered.push(msg);
        } else if (includeTypes && _isMessageType(msg, includeTypes)) {
            filtered.push(msg);
        } else if (includeIds && msg.id && includeIds.some((id)=>id === msg.id)) {
            filtered.push(msg);
        }
    }
    return filtered;
}
function mergeMessageRuns(messages) {
    if (Array.isArray(messages)) {
        return _mergeMessageRuns(messages);
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RunnableLambda"].from(_mergeMessageRuns);
}
function _mergeMessageRuns(messages) {
    if (!messages.length) {
        return [];
    }
    const merged = [];
    for (const msg of messages){
        const curr = msg; // Create a shallow copy of the message
        const last = merged.pop();
        if (!last) {
            merged.push(curr);
        } else if (curr._getType() === "tool" || !(curr._getType() === last._getType())) {
            merged.push(last, curr);
        } else {
            const lastChunk = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["convertToChunk"])(last);
            const currChunk = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["convertToChunk"])(curr);
            const mergedChunks = lastChunk.concat(currChunk);
            if (typeof lastChunk.content === "string" && typeof currChunk.content === "string") {
                mergedChunks.content = `${lastChunk.content}\n${currChunk.content}`;
            }
            merged.push(_chunkToMsg(mergedChunks));
        }
    }
    return merged;
}
function trimMessages(messagesOrOptions, options) {
    if (Array.isArray(messagesOrOptions)) {
        const messages = messagesOrOptions;
        if (!options) {
            throw new Error("Options parameter is required when providing messages.");
        }
        return _trimMessagesHelper(messages, options);
    } else {
        const trimmerOptions = messagesOrOptions;
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RunnableLambda"].from((input)=>_trimMessagesHelper(input, trimmerOptions));
    }
}
async function _trimMessagesHelper(messages, options) {
    const { maxTokens, tokenCounter, strategy = "last", allowPartial = false, endOn, startOn, includeSystem = false, textSplitter } = options;
    if (startOn && strategy === "first") {
        throw new Error("`startOn` should only be specified if `strategy` is 'last'.");
    }
    if (includeSystem && strategy === "first") {
        throw new Error("`includeSystem` should only be specified if `strategy` is 'last'.");
    }
    let listTokenCounter;
    if ("getNumTokens" in tokenCounter) {
        listTokenCounter = async (msgs)=>{
            const tokenCounts = await Promise.all(msgs.map((msg)=>tokenCounter.getNumTokens(msg.content)));
            return tokenCounts.reduce((sum, count)=>sum + count, 0);
        };
    } else {
        listTokenCounter = async (msgs)=>tokenCounter(msgs);
    }
    let textSplitterFunc = defaultTextSplitter;
    if (textSplitter) {
        if ("splitText" in textSplitter) {
            textSplitterFunc = textSplitter.splitText;
        } else {
            textSplitterFunc = async (text)=>textSplitter(text);
        }
    }
    if (strategy === "first") {
        return _firstMaxTokens(messages, {
            maxTokens,
            tokenCounter: listTokenCounter,
            textSplitter: textSplitterFunc,
            partialStrategy: allowPartial ? "first" : undefined,
            endOn
        });
    } else if (strategy === "last") {
        return _lastMaxTokens(messages, {
            maxTokens,
            tokenCounter: listTokenCounter,
            textSplitter: textSplitterFunc,
            allowPartial,
            includeSystem,
            startOn,
            endOn
        });
    } else {
        throw new Error(`Unrecognized strategy: '${strategy}'. Must be one of 'first' or 'last'.`);
    }
}
async function _firstMaxTokens(messages, options) {
    const { maxTokens, tokenCounter, textSplitter, partialStrategy, endOn } = options;
    let messagesCopy = [
        ...messages
    ];
    let idx = 0;
    for(let i = 0; i < messagesCopy.length; i += 1){
        const remainingMessages = i > 0 ? messagesCopy.slice(0, -i) : messagesCopy;
        if (await tokenCounter(remainingMessages) <= maxTokens) {
            idx = messagesCopy.length - i;
            break;
        }
    }
    if (idx < messagesCopy.length - 1 && partialStrategy) {
        let includedPartial = false;
        if (Array.isArray(messagesCopy[idx].content)) {
            const excluded = messagesCopy[idx];
            if (typeof excluded.content === "string") {
                throw new Error("Expected content to be an array.");
            }
            const numBlock = excluded.content.length;
            const reversedContent = partialStrategy === "last" ? [
                ...excluded.content
            ].reverse() : excluded.content;
            for(let i = 1; i <= numBlock; i += 1){
                const partialContent = partialStrategy === "first" ? reversedContent.slice(0, i) : reversedContent.slice(-i);
                const fields = Object.fromEntries(Object.entries(excluded).filter(([k])=>k !== "type" && !k.startsWith("lc_")));
                const updatedMessage = _switchTypeToMessage(excluded._getType(), {
                    ...fields,
                    content: partialContent
                });
                const slicedMessages = [
                    ...messagesCopy.slice(0, idx),
                    updatedMessage
                ];
                if (await tokenCounter(slicedMessages) <= maxTokens) {
                    messagesCopy = slicedMessages;
                    idx += 1;
                    includedPartial = true;
                } else {
                    break;
                }
            }
            if (includedPartial && partialStrategy === "last") {
                excluded.content = [
                    ...reversedContent
                ].reverse();
            }
        }
        if (!includedPartial) {
            const excluded = messagesCopy[idx];
            let text;
            if (Array.isArray(excluded.content) && excluded.content.some((block)=>typeof block === "string" || block.type === "text")) {
                const textBlock = excluded.content.find((block)=>block.type === "text" && block.text);
                text = textBlock?.text;
            } else if (typeof excluded.content === "string") {
                text = excluded.content;
            }
            if (text) {
                const splitTexts = await textSplitter(text);
                const numSplits = splitTexts.length;
                if (partialStrategy === "last") {
                    splitTexts.reverse();
                }
                for(let _ = 0; _ < numSplits - 1; _ += 1){
                    splitTexts.pop();
                    excluded.content = splitTexts.join("");
                    if (await tokenCounter([
                        ...messagesCopy.slice(0, idx),
                        excluded
                    ]) <= maxTokens) {
                        if (partialStrategy === "last") {
                            excluded.content = [
                                ...splitTexts
                            ].reverse().join("");
                        }
                        messagesCopy = [
                            ...messagesCopy.slice(0, idx),
                            excluded
                        ];
                        idx += 1;
                        break;
                    }
                }
            }
        }
    }
    if (endOn) {
        const endOnArr = Array.isArray(endOn) ? endOn : [
            endOn
        ];
        while(idx > 0 && !_isMessageType(messagesCopy[idx - 1], endOnArr)){
            idx -= 1;
        }
    }
    return messagesCopy.slice(0, idx);
}
async function _lastMaxTokens(messages, options) {
    const { allowPartial = false, includeSystem = false, endOn, startOn, ...rest } = options;
    if (endOn) {
        const endOnArr = Array.isArray(endOn) ? endOn : [
            endOn
        ];
        while(messages && !_isMessageType(messages[messages.length - 1], endOnArr)){
            messages.pop();
        }
    }
    const swappedSystem = includeSystem && messages[0]._getType() === "system";
    let reversed_ = swappedSystem ? messages.slice(0, 1).concat(messages.slice(1).reverse()) : messages.reverse();
    reversed_ = await _firstMaxTokens(reversed_, {
        ...rest,
        partialStrategy: allowPartial ? "last" : undefined,
        endOn: startOn
    });
    if (swappedSystem) {
        return [
            reversed_[0],
            ...reversed_.slice(1).reverse()
        ];
    } else {
        return reversed_.reverse();
    }
}
const _MSG_CHUNK_MAP = {
    human: {
        message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HumanMessage"],
        messageChunk: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HumanMessageChunk"]
    },
    ai: {
        message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AIMessage"],
        messageChunk: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AIMessageChunk"]
    },
    system: {
        message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemMessage"],
        messageChunk: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemMessageChunk"]
    },
    developer: {
        message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemMessage"],
        messageChunk: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemMessageChunk"]
    },
    tool: {
        message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$tool$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ToolMessage"],
        messageChunk: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$tool$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ToolMessageChunk"]
    },
    function: {
        message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$function$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["FunctionMessage"],
        messageChunk: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$function$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["FunctionMessageChunk"]
    },
    generic: {
        message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatMessage"],
        messageChunk: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatMessageChunk"]
    },
    remove: {
        message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$modifier$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RemoveMessage"],
        messageChunk: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$modifier$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RemoveMessage"]
    }
};
function _switchTypeToMessage(messageType, fields, returnChunk) {
    let chunk;
    let msg;
    switch(messageType){
        case "human":
            if (returnChunk) {
                chunk = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HumanMessageChunk"](fields);
            } else {
                msg = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HumanMessage"](fields);
            }
            break;
        case "ai":
            if (returnChunk) {
                let aiChunkFields = {
                    ...fields
                };
                if ("tool_calls" in aiChunkFields) {
                    aiChunkFields = {
                        ...aiChunkFields,
                        tool_call_chunks: aiChunkFields.tool_calls?.map((tc)=>({
                                ...tc,
                                type: "tool_call_chunk",
                                index: undefined,
                                args: JSON.stringify(tc.args)
                            }))
                    };
                }
                chunk = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AIMessageChunk"](aiChunkFields);
            } else {
                msg = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AIMessage"](fields);
            }
            break;
        case "system":
            if (returnChunk) {
                chunk = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemMessageChunk"](fields);
            } else {
                msg = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemMessage"](fields);
            }
            break;
        case "developer":
            if (returnChunk) {
                chunk = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemMessageChunk"]({
                    ...fields,
                    additional_kwargs: {
                        ...fields.additional_kwargs,
                        __openai_role__: "developer"
                    }
                });
            } else {
                msg = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemMessage"]({
                    ...fields,
                    additional_kwargs: {
                        ...fields.additional_kwargs,
                        __openai_role__: "developer"
                    }
                });
            }
            break;
        case "tool":
            if ("tool_call_id" in fields) {
                if (returnChunk) {
                    chunk = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$tool$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ToolMessageChunk"](fields);
                } else {
                    msg = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$tool$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ToolMessage"](fields);
                }
            } else {
                throw new Error("Can not convert ToolMessage to ToolMessageChunk if 'tool_call_id' field is not defined.");
            }
            break;
        case "function":
            if (returnChunk) {
                chunk = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$function$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["FunctionMessageChunk"](fields);
            } else {
                if (!fields.name) {
                    throw new Error("FunctionMessage must have a 'name' field");
                }
                msg = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$function$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["FunctionMessage"](fields);
            }
            break;
        case "generic":
            if ("role" in fields) {
                if (returnChunk) {
                    chunk = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatMessageChunk"](fields);
                } else {
                    msg = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatMessage"](fields);
                }
            } else {
                throw new Error("Can not convert ChatMessage to ChatMessageChunk if 'role' field is not defined.");
            }
            break;
        default:
            throw new Error(`Unrecognized message type ${messageType}`);
    }
    if (returnChunk && chunk) {
        return chunk;
    }
    if (msg) {
        return msg;
    }
    throw new Error(`Unrecognized message type ${messageType}`);
}
function _chunkToMsg(chunk) {
    const chunkType = chunk._getType();
    let msg;
    const fields = Object.fromEntries(Object.entries(chunk).filter(([k])=>![
            "type",
            "tool_call_chunks"
        ].includes(k) && !k.startsWith("lc_")));
    if (chunkType in _MSG_CHUNK_MAP) {
        msg = _switchTypeToMessage(chunkType, fields);
    }
    if (!msg) {
        throw new Error(`Unrecognized message chunk class ${chunkType}. Supported classes are ${Object.keys(_MSG_CHUNK_MAP)}`);
    }
    return msg;
}
function defaultTextSplitter(text) {
    const splits = text.split("\n");
    return Promise.resolve([
        ...splits.slice(0, -1).map((s)=>`${s}\n`),
        splits[splits.length - 1]
    ]);
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/index.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
;
;
;
;
;
;
;
;
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/index.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/ai.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/chat.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$function$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/function.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/human.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/system.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$transformers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/transformers.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$modifier$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/modifier.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$tool$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/tool.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/index.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompt_values.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "BasePromptValue": (()=>BasePromptValue),
    "ChatPromptValue": (()=>ChatPromptValue),
    "ImagePromptValue": (()=>ImagePromptValue),
    "StringPromptValue": (()=>StringPromptValue)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$load$2f$serializable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/load/serializable.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/human.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/utils.js [app-route] (ecmascript)");
;
;
;
class BasePromptValue extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$load$2f$serializable$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Serializable"] {
}
class StringPromptValue extends BasePromptValue {
    static lc_name() {
        return "StringPromptValue";
    }
    constructor(value){
        super({
            value
        });
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "prompt_values"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "value", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.value = value;
    }
    toString() {
        return this.value;
    }
    toChatMessages() {
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HumanMessage"](this.value)
        ];
    }
}
class ChatPromptValue extends BasePromptValue {
    static lc_name() {
        return "ChatPromptValue";
    }
    constructor(fields){
        if (Array.isArray(fields)) {
            // eslint-disable-next-line no-param-reassign
            fields = {
                messages: fields
            };
        }
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "prompt_values"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "messages", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.messages = fields.messages;
    }
    toString() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getBufferString"])(this.messages);
    }
    toChatMessages() {
        return this.messages;
    }
}
class ImagePromptValue extends BasePromptValue {
    static lc_name() {
        return "ImagePromptValue";
    }
    constructor(fields){
        if (!("imageUrl" in fields)) {
            // eslint-disable-next-line no-param-reassign
            fields = {
                imageUrl: fields
            };
        }
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "prompt_values"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "imageUrl", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /** @ignore */ Object.defineProperty(this, "value", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.imageUrl = fields.imageUrl;
    }
    toString() {
        return this.imageUrl.url;
    }
    toChatMessages() {
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HumanMessage"]({
                content: [
                    {
                        type: "image_url",
                        image_url: {
                            detail: this.imageUrl.detail,
                            url: this.imageUrl.url
                        }
                    }
                ]
            })
        ];
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/string.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// Default generic "any" values are for backwards compatibility.
// Replace with "string" when we are comfortable with a breaking change.
__turbopack_esm__({
    "BaseStringPromptTemplate": (()=>BaseStringPromptTemplate)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompt_values$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompt_values.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/base.js [app-route] (ecmascript)");
;
;
class BaseStringPromptTemplate extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BasePromptTemplate"] {
    /**
     * Formats the prompt given the input values and returns a formatted
     * prompt value.
     * @param values The input values to format the prompt.
     * @returns A Promise that resolves to a formatted prompt value.
     */ async formatPromptValue(values) {
        const formattedPrompt = await this.format(values);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompt_values$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StringPromptValue"](formattedPrompt);
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/template.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "DEFAULT_FORMATTER_MAPPING": (()=>DEFAULT_FORMATTER_MAPPING),
    "DEFAULT_PARSER_MAPPING": (()=>DEFAULT_PARSER_MAPPING),
    "checkValidTemplate": (()=>checkValidTemplate),
    "interpolateFString": (()=>interpolateFString),
    "interpolateMustache": (()=>interpolateMustache),
    "parseFString": (()=>parseFString),
    "parseMustache": (()=>parseMustache),
    "parseTemplate": (()=>parseTemplate),
    "renderTemplate": (()=>renderTemplate)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$mustache$40$4$2e$2$2e$0$2f$node_modules$2f$mustache$2f$mustache$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/mustache@4.2.0/node_modules/mustache/mustache.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$errors$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/errors/index.js [app-route] (ecmascript)");
;
;
function configureMustache() {
    // Use unescaped HTML
    // https://github.com/janl/mustache.js?tab=readme-ov-file#variables
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$mustache$40$4$2e$2$2e$0$2f$node_modules$2f$mustache$2f$mustache$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].escape = (text)=>text;
}
const parseFString = (template)=>{
    // Core logic replicated from internals of pythons built in Formatter class.
    // https://github.com/python/cpython/blob/135ec7cefbaffd516b77362ad2b2ad1025af462e/Objects/stringlib/unicode_format.h#L700-L706
    const chars = template.split("");
    const nodes = [];
    const nextBracket = (bracket, start)=>{
        for(let i = start; i < chars.length; i += 1){
            if (bracket.includes(chars[i])) {
                return i;
            }
        }
        return -1;
    };
    let i = 0;
    while(i < chars.length){
        if (chars[i] === "{" && i + 1 < chars.length && chars[i + 1] === "{") {
            nodes.push({
                type: "literal",
                text: "{"
            });
            i += 2;
        } else if (chars[i] === "}" && i + 1 < chars.length && chars[i + 1] === "}") {
            nodes.push({
                type: "literal",
                text: "}"
            });
            i += 2;
        } else if (chars[i] === "{") {
            const j = nextBracket("}", i);
            if (j < 0) {
                throw new Error("Unclosed '{' in template.");
            }
            nodes.push({
                type: "variable",
                name: chars.slice(i + 1, j).join("")
            });
            i = j + 1;
        } else if (chars[i] === "}") {
            throw new Error("Single '}' in template.");
        } else {
            const next = nextBracket("{}", i);
            const text = (next < 0 ? chars.slice(i) : chars.slice(i, next)).join("");
            nodes.push({
                type: "literal",
                text
            });
            i = next < 0 ? chars.length : next;
        }
    }
    return nodes;
};
/**
 * Convert the result of mustache.parse into an array of ParsedTemplateNode,
 * to make it compatible with other LangChain string parsing template formats.
 *
 * @param {mustache.TemplateSpans} template The result of parsing a mustache template with the mustache.js library.
 * @returns {ParsedTemplateNode[]}
 */ const mustacheTemplateToNodes = (template)=>template.map((temp)=>{
        if (temp[0] === "name") {
            const name = temp[1].includes(".") ? temp[1].split(".")[0] : temp[1];
            return {
                type: "variable",
                name
            };
        } else if ([
            "#",
            "&",
            "^",
            ">"
        ].includes(temp[0])) {
            // # represents a section, "&" represents an unescaped variable.
            // These should both be considered variables.
            return {
                type: "variable",
                name: temp[1]
            };
        } else {
            return {
                type: "literal",
                text: temp[1]
            };
        }
    });
const parseMustache = (template)=>{
    configureMustache();
    const parsed = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$mustache$40$4$2e$2$2e$0$2f$node_modules$2f$mustache$2f$mustache$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].parse(template);
    return mustacheTemplateToNodes(parsed);
};
const interpolateFString = (template, values)=>{
    return parseFString(template).reduce((res, node)=>{
        if (node.type === "variable") {
            if (node.name in values) {
                const stringValue = typeof values[node.name] === "string" ? values[node.name] : JSON.stringify(values[node.name]);
                return res + stringValue;
            }
            throw new Error(`(f-string) Missing value for input ${node.name}`);
        }
        return res + node.text;
    }, "");
};
const interpolateMustache = (template, values)=>{
    configureMustache();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$mustache$40$4$2e$2$2e$0$2f$node_modules$2f$mustache$2f$mustache$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].render(template, values);
};
const DEFAULT_FORMATTER_MAPPING = {
    "f-string": interpolateFString,
    mustache: interpolateMustache
};
const DEFAULT_PARSER_MAPPING = {
    "f-string": parseFString,
    mustache: parseMustache
};
const renderTemplate = (template, templateFormat, inputValues)=>{
    try {
        return DEFAULT_FORMATTER_MAPPING[templateFormat](template, inputValues);
    } catch (e) {
        const error = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$errors$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["addLangChainErrorFields"])(e, "INVALID_PROMPT_INPUT");
        throw error;
    }
};
const parseTemplate = (template, templateFormat)=>DEFAULT_PARSER_MAPPING[templateFormat](template);
const checkValidTemplate = (template, templateFormat, inputVariables)=>{
    if (!(templateFormat in DEFAULT_FORMATTER_MAPPING)) {
        const validFormats = Object.keys(DEFAULT_FORMATTER_MAPPING);
        throw new Error(`Invalid template format. Got \`${templateFormat}\`;
                         should be one of ${validFormats}`);
    }
    try {
        const dummyInputs = inputVariables.reduce((acc, v)=>{
            acc[v] = "foo";
            return acc;
        }, {});
        if (Array.isArray(template)) {
            template.forEach((message)=>{
                if (message.type === "text") {
                    renderTemplate(message.text, templateFormat, dummyInputs);
                } else if (message.type === "image_url") {
                    if (typeof message.image_url === "string") {
                        renderTemplate(message.image_url, templateFormat, dummyInputs);
                    } else {
                        const imageUrl = message.image_url.url;
                        renderTemplate(imageUrl, templateFormat, dummyInputs);
                    }
                } else {
                    throw new Error(`Invalid message template received. ${JSON.stringify(message, null, 2)}`);
                }
            });
        } else {
            renderTemplate(template, templateFormat, dummyInputs);
        }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (e) {
        throw new Error(`Invalid prompt schema: ${e.message}`);
    }
};
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/prompt.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// Default generic "any" values are for backwards compatibility.
// Replace with "string" when we are comfortable with a breaking change.
__turbopack_esm__({
    "PromptTemplate": (()=>PromptTemplate)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$string$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/string.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/template.js [app-route] (ecmascript)");
;
;
class PromptTemplate extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$string$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseStringPromptTemplate"] {
    static lc_name() {
        return "PromptTemplate";
    }
    constructor(input){
        super(input);
        Object.defineProperty(this, "template", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "templateFormat", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "f-string"
        });
        Object.defineProperty(this, "validateTemplate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        /**
         * Additional fields which should be included inside
         * the message content array if using a complex message
         * content.
         */ // eslint-disable-next-line @typescript-eslint/no-explicit-any
        Object.defineProperty(this, "additionalContentFields", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        // If input is mustache and validateTemplate is not defined, set it to false
        if (input.templateFormat === "mustache" && input.validateTemplate === undefined) {
            this.validateTemplate = false;
        }
        Object.assign(this, input);
        if (this.validateTemplate) {
            if (this.templateFormat === "mustache") {
                throw new Error("Mustache templates cannot be validated.");
            }
            let totalInputVariables = this.inputVariables;
            if (this.partialVariables) {
                totalInputVariables = totalInputVariables.concat(Object.keys(this.partialVariables));
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["checkValidTemplate"])(this.template, this.templateFormat, totalInputVariables);
        }
    }
    _getPromptType() {
        return "prompt";
    }
    /**
     * Formats the prompt template with the provided values.
     * @param values The values to be used to format the prompt template.
     * @returns A promise that resolves to a string which is the formatted prompt.
     */ async format(values) {
        const allValues = await this.mergePartialAndUserVariables(values);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["renderTemplate"])(this.template, this.templateFormat, allValues);
    }
    /**
     * Take examples in list format with prefix and suffix to create a prompt.
     *
     * Intended to be used a a way to dynamically create a prompt from examples.
     *
     * @param examples - List of examples to use in the prompt.
     * @param suffix - String to go after the list of examples. Should generally set up the user's input.
     * @param inputVariables - A list of variable names the final prompt template will expect
     * @param exampleSeparator - The separator to use in between examples
     * @param prefix - String that should go before any examples. Generally includes examples.
     *
     * @returns The final prompt template generated.
     */ static fromExamples(examples, suffix, inputVariables, exampleSeparator = "\n\n", prefix = "") {
        const template = [
            prefix,
            ...examples,
            suffix
        ].join(exampleSeparator);
        return new PromptTemplate({
            inputVariables,
            template
        });
    }
    static fromTemplate(template, options) {
        const { templateFormat = "f-string", ...rest } = options ?? {};
        const names = new Set();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseTemplate"])(template, templateFormat).forEach((node)=>{
            if (node.type === "variable") {
                names.add(node.name);
            }
        });
        return new PromptTemplate({
            // Rely on extracted types
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            inputVariables: [
                ...names
            ],
            templateFormat,
            template,
            ...rest
        });
    }
    /**
     * Partially applies values to the prompt template.
     * @param values The values to be partially applied to the prompt template.
     * @returns A new instance of PromptTemplate with the partially applied values.
     */ async partial(values) {
        const newInputVariables = this.inputVariables.filter((iv)=>!(iv in values));
        const newPartialVariables = {
            ...this.partialVariables ?? {},
            ...values
        };
        const promptDict = {
            ...this,
            inputVariables: newInputVariables,
            partialVariables: newPartialVariables
        };
        return new PromptTemplate(promptDict);
    }
    serialize() {
        if (this.outputParser !== undefined) {
            throw new Error("Cannot serialize a prompt template with an output parser");
        }
        return {
            _type: this._getPromptType(),
            input_variables: this.inputVariables,
            template: this.template,
            template_format: this.templateFormat
        };
    }
    static async deserialize(data) {
        if (!data.template) {
            throw new Error("Prompt template must have a template");
        }
        const res = new PromptTemplate({
            inputVariables: data.input_variables,
            template: data.template,
            templateFormat: data.template_format
        });
        return res;
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/image.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ImagePromptTemplate": (()=>ImagePromptTemplate)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompt_values$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompt_values.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/template.js [app-route] (ecmascript)");
;
;
;
class ImagePromptTemplate extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BasePromptTemplate"] {
    static lc_name() {
        return "ImagePromptTemplate";
    }
    constructor(input){
        super(input);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "prompts",
                "image"
            ]
        });
        Object.defineProperty(this, "template", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "templateFormat", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "f-string"
        });
        Object.defineProperty(this, "validateTemplate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        /**
         * Additional fields which should be included inside
         * the message content array if using a complex message
         * content.
         */ // eslint-disable-next-line @typescript-eslint/no-explicit-any
        Object.defineProperty(this, "additionalContentFields", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.template = input.template;
        this.templateFormat = input.templateFormat ?? this.templateFormat;
        this.validateTemplate = input.validateTemplate ?? this.validateTemplate;
        this.additionalContentFields = input.additionalContentFields;
        if (this.validateTemplate) {
            let totalInputVariables = this.inputVariables;
            if (this.partialVariables) {
                totalInputVariables = totalInputVariables.concat(Object.keys(this.partialVariables));
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["checkValidTemplate"])([
                {
                    type: "image_url",
                    image_url: this.template
                }
            ], this.templateFormat, totalInputVariables);
        }
    }
    _getPromptType() {
        return "prompt";
    }
    /**
     * Partially applies values to the prompt template.
     * @param values The values to be partially applied to the prompt template.
     * @returns A new instance of ImagePromptTemplate with the partially applied values.
     */ async partial(values) {
        const newInputVariables = this.inputVariables.filter((iv)=>!(iv in values));
        const newPartialVariables = {
            ...this.partialVariables ?? {},
            ...values
        };
        const promptDict = {
            ...this,
            inputVariables: newInputVariables,
            partialVariables: newPartialVariables
        };
        return new ImagePromptTemplate(promptDict);
    }
    /**
     * Formats the prompt template with the provided values.
     * @param values The values to be used to format the prompt template.
     * @returns A promise that resolves to a string which is the formatted prompt.
     */ async format(values) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const formatted = {};
        for (const [key, value] of Object.entries(this.template)){
            if (typeof value === "string") {
                formatted[key] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["renderTemplate"])(value, this.templateFormat, values);
            } else {
                formatted[key] = value;
            }
        }
        const url = values.url || formatted.url;
        const detail = values.detail || formatted.detail;
        if (!url) {
            throw new Error("Must provide either an image URL.");
        }
        if (typeof url !== "string") {
            throw new Error("url must be a string.");
        }
        const output = {
            url
        };
        if (detail) {
            output.detail = detail;
        }
        return output;
    }
    /**
     * Formats the prompt given the input values and returns a formatted
     * prompt value.
     * @param values The input values to format the prompt.
     * @returns A Promise that resolves to a formatted prompt value.
     */ async formatPromptValue(values) {
        const formattedPrompt = await this.format(values);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompt_values$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ImagePromptValue"](formattedPrompt);
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/chat.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// Default generic "any" values are for backwards compatibility.
// Replace with "string" when we are comfortable with a breaking change.
__turbopack_esm__({
    "AIMessagePromptTemplate": (()=>AIMessagePromptTemplate),
    "BaseChatPromptTemplate": (()=>BaseChatPromptTemplate),
    "BaseMessagePromptTemplate": (()=>BaseMessagePromptTemplate),
    "BaseMessageStringPromptTemplate": (()=>BaseMessageStringPromptTemplate),
    "ChatMessagePromptTemplate": (()=>ChatMessagePromptTemplate),
    "ChatPromptTemplate": (()=>ChatPromptTemplate),
    "HumanMessagePromptTemplate": (()=>HumanMessagePromptTemplate),
    "MessagesPlaceholder": (()=>MessagesPlaceholder),
    "SystemMessagePromptTemplate": (()=>SystemMessagePromptTemplate)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompt_values$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompt_values.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$string$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/string.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$prompt$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/prompt.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$image$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/image.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/template.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$errors$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/errors/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/chat.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/human.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/ai.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/system.js [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
;
class BaseMessagePromptTemplate extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Runnable"] {
    constructor(){
        super(...arguments);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "prompts",
                "chat"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
    }
    /**
     * Calls the formatMessages method with the provided input and options.
     * @param input Input for the formatMessages method
     * @param options Optional BaseCallbackConfig
     * @returns Formatted output messages
     */ async invoke(input, options) {
        return this._callWithConfig((input)=>this.formatMessages(input), input, {
            ...options,
            runType: "prompt"
        });
    }
}
class MessagesPlaceholder extends BaseMessagePromptTemplate {
    static lc_name() {
        return "MessagesPlaceholder";
    }
    constructor(fields){
        if (typeof fields === "string") {
            // eslint-disable-next-line no-param-reassign
            fields = {
                variableName: fields
            };
        }
        super(fields);
        Object.defineProperty(this, "variableName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "optional", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.variableName = fields.variableName;
        this.optional = fields.optional ?? false;
    }
    get inputVariables() {
        return [
            this.variableName
        ];
    }
    async formatMessages(values) {
        const input = values[this.variableName];
        if (this.optional && !input) {
            return [];
        } else if (!input) {
            const error = new Error(`Field "${this.variableName}" in prompt uses a MessagesPlaceholder, which expects an array of BaseMessages as an input value. Received: undefined`);
            error.name = "InputFormatError";
            throw error;
        }
        let formattedMessages;
        try {
            if (Array.isArray(input)) {
                formattedMessages = input.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["coerceMessageLikeToMessage"]);
            } else {
                formattedMessages = [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["coerceMessageLikeToMessage"])(input)
                ];
            }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        } catch (e) {
            const readableInput = typeof input === "string" ? input : JSON.stringify(input, null, 2);
            const error = new Error([
                `Field "${this.variableName}" in prompt uses a MessagesPlaceholder, which expects an array of BaseMessages or coerceable values as input.`,
                `Received value: ${readableInput}`,
                `Additional message: ${e.message}`
            ].join("\n\n"));
            error.name = "InputFormatError";
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            error.lc_error_code = e.lc_error_code;
            throw error;
        }
        return formattedMessages;
    }
}
class BaseMessageStringPromptTemplate extends BaseMessagePromptTemplate {
    constructor(fields){
        if (!("prompt" in fields)) {
            // eslint-disable-next-line no-param-reassign
            fields = {
                prompt: fields
            };
        }
        super(fields);
        Object.defineProperty(this, "prompt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.prompt = fields.prompt;
    }
    get inputVariables() {
        return this.prompt.inputVariables;
    }
    async formatMessages(values) {
        return [
            await this.format(values)
        ];
    }
}
class BaseChatPromptTemplate extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BasePromptTemplate"] {
    constructor(input){
        super(input);
    }
    async format(values) {
        return (await this.formatPromptValue(values)).toString();
    }
    async formatPromptValue(values) {
        const resultMessages = await this.formatMessages(values);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompt_values$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatPromptValue"](resultMessages);
    }
}
class ChatMessagePromptTemplate extends BaseMessageStringPromptTemplate {
    static lc_name() {
        return "ChatMessagePromptTemplate";
    }
    constructor(fields, role){
        if (!("prompt" in fields)) {
            // eslint-disable-next-line no-param-reassign, @typescript-eslint/no-non-null-assertion
            fields = {
                prompt: fields,
                role: role
            };
        }
        super(fields);
        Object.defineProperty(this, "role", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.role = fields.role;
    }
    async format(values) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatMessage"](await this.prompt.format(values), this.role);
    }
    static fromTemplate(template, role, options) {
        return new this(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$prompt$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PromptTemplate"].fromTemplate(template, {
            templateFormat: options?.templateFormat
        }), role);
    }
}
class _StringImageMessagePromptTemplate extends BaseMessagePromptTemplate {
    static _messageClass() {
        throw new Error("Can not invoke _messageClass from inside _StringImageMessagePromptTemplate");
    }
    constructor(/** @TODO When we come up with a better way to type prompt templates, fix this */ // eslint-disable-next-line @typescript-eslint/no-explicit-any
    fields, additionalOptions){
        if (!("prompt" in fields)) {
            // eslint-disable-next-line no-param-reassign
            fields = {
                prompt: fields
            };
        }
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "prompts",
                "chat"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "inputVariables", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "additionalOptions", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: {}
        });
        Object.defineProperty(this, "prompt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "messageClass", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        // ChatMessage contains role field, others don't.
        // Because of this, we have a separate class property for ChatMessage.
        Object.defineProperty(this, "chatMessageClass", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.prompt = fields.prompt;
        if (Array.isArray(this.prompt)) {
            let inputVariables = [];
            this.prompt.forEach((prompt)=>{
                if ("inputVariables" in prompt) {
                    inputVariables = inputVariables.concat(prompt.inputVariables);
                }
            });
            this.inputVariables = inputVariables;
        } else {
            this.inputVariables = this.prompt.inputVariables;
        }
        this.additionalOptions = additionalOptions ?? this.additionalOptions;
    }
    createMessage(content) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const constructor = this.constructor;
        if (constructor._messageClass()) {
            const MsgClass = constructor._messageClass();
            return new MsgClass({
                content
            });
        } else if (constructor.chatMessageClass) {
            const MsgClass = constructor.chatMessageClass();
            // Assuming ChatMessage constructor also takes a content argument
            return new MsgClass({
                content,
                role: this.getRoleFromMessageClass(MsgClass.lc_name())
            });
        } else {
            throw new Error("No message class defined");
        }
    }
    getRoleFromMessageClass(name) {
        switch(name){
            case "HumanMessage":
                return "human";
            case "AIMessage":
                return "ai";
            case "SystemMessage":
                return "system";
            case "ChatMessage":
                return "chat";
            default:
                throw new Error("Invalid message class name");
        }
    }
    static fromTemplate(template, additionalOptions) {
        if (typeof template === "string") {
            return new this(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$prompt$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PromptTemplate"].fromTemplate(template, additionalOptions));
        }
        const prompt = [];
        for (const item of template){
            if (typeof item === "string" || typeof item === "object" && "text" in item) {
                let text = "";
                if (typeof item === "string") {
                    text = item;
                } else if (typeof item.text === "string") {
                    text = item.text ?? "";
                }
                const options = {
                    ...additionalOptions,
                    ...typeof item !== "string" ? {
                        additionalContentFields: item
                    } : {}
                };
                prompt.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$prompt$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PromptTemplate"].fromTemplate(text, options));
            } else if (typeof item === "object" && "image_url" in item) {
                let imgTemplate = item.image_url ?? "";
                let imgTemplateObject;
                let inputVariables = [];
                if (typeof imgTemplate === "string") {
                    let parsedTemplate;
                    if (additionalOptions?.templateFormat === "mustache") {
                        parsedTemplate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseMustache"])(imgTemplate);
                    } else {
                        parsedTemplate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseFString"])(imgTemplate);
                    }
                    const variables = parsedTemplate.flatMap((item)=>item.type === "variable" ? [
                            item.name
                        ] : []);
                    if ((variables?.length ?? 0) > 0) {
                        if (variables.length > 1) {
                            throw new Error(`Only one format variable allowed per image template.\nGot: ${variables}\nFrom: ${imgTemplate}`);
                        }
                        inputVariables = [
                            variables[0]
                        ];
                    } else {
                        inputVariables = [];
                    }
                    imgTemplate = {
                        url: imgTemplate
                    };
                    imgTemplateObject = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$image$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ImagePromptTemplate"]({
                        template: imgTemplate,
                        inputVariables,
                        templateFormat: additionalOptions?.templateFormat,
                        additionalContentFields: item
                    });
                } else if (typeof imgTemplate === "object") {
                    if ("url" in imgTemplate) {
                        let parsedTemplate;
                        if (additionalOptions?.templateFormat === "mustache") {
                            parsedTemplate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseMustache"])(imgTemplate.url);
                        } else {
                            parsedTemplate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseFString"])(imgTemplate.url);
                        }
                        inputVariables = parsedTemplate.flatMap((item)=>item.type === "variable" ? [
                                item.name
                            ] : []);
                    } else {
                        inputVariables = [];
                    }
                    imgTemplateObject = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$image$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ImagePromptTemplate"]({
                        template: imgTemplate,
                        inputVariables,
                        templateFormat: additionalOptions?.templateFormat,
                        additionalContentFields: item
                    });
                } else {
                    throw new Error("Invalid image template");
                }
                prompt.push(imgTemplateObject);
            }
        }
        return new this({
            prompt,
            additionalOptions
        });
    }
    async format(input) {
        // eslint-disable-next-line no-instanceof/no-instanceof
        if (this.prompt instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$string$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseStringPromptTemplate"]) {
            const text = await this.prompt.format(input);
            return this.createMessage(text);
        } else {
            const content = [];
            for (const prompt of this.prompt){
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                let inputs = {};
                if (!("inputVariables" in prompt)) {
                    throw new Error(`Prompt ${prompt} does not have inputVariables defined.`);
                }
                for (const item of prompt.inputVariables){
                    if ("TURBOPACK compile-time falsy", 0) {
                        "TURBOPACK unreachable";
                    }
                    inputs = {
                        ...inputs,
                        [item]: input[item]
                    };
                }
                // eslint-disable-next-line no-instanceof/no-instanceof
                if (prompt instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$string$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseStringPromptTemplate"]) {
                    const formatted = await prompt.format(inputs);
                    let additionalContentFields;
                    if ("additionalContentFields" in prompt) {
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        additionalContentFields = prompt.additionalContentFields;
                    }
                    content.push({
                        ...additionalContentFields,
                        type: "text",
                        text: formatted
                    });
                /** @TODO replace this */ // eslint-disable-next-line no-instanceof/no-instanceof
                } else if (prompt instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$image$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ImagePromptTemplate"]) {
                    const formatted = await prompt.format(inputs);
                    let additionalContentFields;
                    if ("additionalContentFields" in prompt) {
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        additionalContentFields = prompt.additionalContentFields;
                    }
                    content.push({
                        ...additionalContentFields,
                        type: "image_url",
                        image_url: formatted
                    });
                }
            }
            return this.createMessage(content);
        }
    }
    async formatMessages(values) {
        return [
            await this.format(values)
        ];
    }
}
class HumanMessagePromptTemplate extends _StringImageMessagePromptTemplate {
    static _messageClass() {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HumanMessage"];
    }
    static lc_name() {
        return "HumanMessagePromptTemplate";
    }
}
class AIMessagePromptTemplate extends _StringImageMessagePromptTemplate {
    static _messageClass() {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AIMessage"];
    }
    static lc_name() {
        return "AIMessagePromptTemplate";
    }
}
class SystemMessagePromptTemplate extends _StringImageMessagePromptTemplate {
    static _messageClass() {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$system$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemMessage"];
    }
    static lc_name() {
        return "SystemMessagePromptTemplate";
    }
}
function _isBaseMessagePromptTemplate(baseMessagePromptTemplateLike) {
    return typeof baseMessagePromptTemplateLike.formatMessages === "function";
}
function _coerceMessagePromptTemplateLike(messagePromptTemplateLike, extra) {
    if (_isBaseMessagePromptTemplate(messagePromptTemplateLike) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseMessage"])(messagePromptTemplateLike)) {
        return messagePromptTemplateLike;
    }
    if (Array.isArray(messagePromptTemplateLike) && messagePromptTemplateLike[0] === "placeholder") {
        const messageContent = messagePromptTemplateLike[1];
        if (typeof messageContent !== "string" || messageContent[0] !== "{" || messageContent[messageContent.length - 1] !== "}") {
            throw new Error(`Invalid placeholder template: "${messagePromptTemplateLike[1]}". Expected a variable name surrounded by curly braces.`);
        }
        const variableName = messageContent.slice(1, -1);
        return new MessagesPlaceholder({
            variableName,
            optional: true
        });
    }
    const message = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["coerceMessageLikeToMessage"])(messagePromptTemplateLike);
    let templateData;
    if (typeof message.content === "string") {
        templateData = message.content;
    } else {
        // Assuming message.content is an array of complex objects, transform it.
        templateData = message.content.map((item)=>{
            if ("text" in item) {
                return {
                    ...item,
                    text: item.text
                };
            } else if ("image_url" in item) {
                return {
                    ...item,
                    image_url: item.image_url
                };
            } else {
                return item;
            }
        });
    }
    if (message._getType() === "human") {
        return HumanMessagePromptTemplate.fromTemplate(templateData, extra);
    } else if (message._getType() === "ai") {
        return AIMessagePromptTemplate.fromTemplate(templateData, extra);
    } else if (message._getType() === "system") {
        return SystemMessagePromptTemplate.fromTemplate(templateData, extra);
    } else if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatMessage"].isInstance(message)) {
        return ChatMessagePromptTemplate.fromTemplate(message.content, message.role, extra);
    } else {
        throw new Error(`Could not coerce message prompt template from input. Received message type: "${message._getType()}".`);
    }
}
function isMessagesPlaceholder(x) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return x.constructor.lc_name() === "MessagesPlaceholder";
}
class ChatPromptTemplate extends BaseChatPromptTemplate {
    static lc_name() {
        return "ChatPromptTemplate";
    }
    get lc_aliases() {
        return {
            promptMessages: "messages"
        };
    }
    constructor(input){
        super(input);
        Object.defineProperty(this, "promptMessages", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "validateTemplate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "templateFormat", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "f-string"
        });
        // If input is mustache and validateTemplate is not defined, set it to false
        if (input.templateFormat === "mustache" && input.validateTemplate === undefined) {
            this.validateTemplate = false;
        }
        Object.assign(this, input);
        if (this.validateTemplate) {
            const inputVariablesMessages = new Set();
            for (const promptMessage of this.promptMessages){
                // eslint-disable-next-line no-instanceof/no-instanceof
                if (promptMessage instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessage"]) continue;
                for (const inputVariable of promptMessage.inputVariables){
                    inputVariablesMessages.add(inputVariable);
                }
            }
            const totalInputVariables = this.inputVariables;
            const inputVariablesInstance = new Set(this.partialVariables ? totalInputVariables.concat(Object.keys(this.partialVariables)) : totalInputVariables);
            const difference = new Set([
                ...inputVariablesInstance
            ].filter((x)=>!inputVariablesMessages.has(x)));
            if (difference.size > 0) {
                throw new Error(`Input variables \`${[
                    ...difference
                ]}\` are not used in any of the prompt messages.`);
            }
            const otherDifference = new Set([
                ...inputVariablesMessages
            ].filter((x)=>!inputVariablesInstance.has(x)));
            if (otherDifference.size > 0) {
                throw new Error(`Input variables \`${[
                    ...otherDifference
                ]}\` are used in prompt messages but not in the prompt template.`);
            }
        }
    }
    _getPromptType() {
        return "chat";
    }
    async _parseImagePrompts(message, inputValues) {
        if (typeof message.content === "string") {
            return message;
        }
        const formattedMessageContent = await Promise.all(message.content.map(async (item)=>{
            if (item.type !== "image_url") {
                return item;
            }
            let imageUrl = "";
            if (typeof item.image_url === "string") {
                imageUrl = item.image_url;
            } else {
                imageUrl = item.image_url.url;
            }
            const promptTemplatePlaceholder = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$prompt$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PromptTemplate"].fromTemplate(imageUrl, {
                templateFormat: this.templateFormat
            });
            const formattedUrl = await promptTemplatePlaceholder.format(inputValues);
            if (typeof item.image_url !== "string" && "url" in item.image_url) {
                // eslint-disable-next-line no-param-reassign
                item.image_url.url = formattedUrl;
            } else {
                // eslint-disable-next-line no-param-reassign
                item.image_url = formattedUrl;
            }
            return item;
        }));
        // eslint-disable-next-line no-param-reassign
        message.content = formattedMessageContent;
        return message;
    }
    async formatMessages(values) {
        const allValues = await this.mergePartialAndUserVariables(values);
        let resultMessages = [];
        for (const promptMessage of this.promptMessages){
            // eslint-disable-next-line no-instanceof/no-instanceof
            if (promptMessage instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessage"]) {
                resultMessages.push(await this._parseImagePrompts(promptMessage, allValues));
            } else {
                const inputValues = promptMessage.inputVariables.reduce((acc, inputVariable)=>{
                    if (!(inputVariable in allValues) && !(isMessagesPlaceholder(promptMessage) && promptMessage.optional)) {
                        const error = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$errors$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["addLangChainErrorFields"])(new Error(`Missing value for input variable \`${inputVariable.toString()}\``), "INVALID_PROMPT_INPUT");
                        throw error;
                    }
                    acc[inputVariable] = allValues[inputVariable];
                    return acc;
                }, {});
                const message = await promptMessage.formatMessages(inputValues);
                resultMessages = resultMessages.concat(message);
            }
        }
        return resultMessages;
    }
    async partial(values) {
        // This is implemented in a way it doesn't require making
        // BaseMessagePromptTemplate aware of .partial()
        const newInputVariables = this.inputVariables.filter((iv)=>!(iv in values));
        const newPartialVariables = {
            ...this.partialVariables ?? {},
            ...values
        };
        const promptDict = {
            ...this,
            inputVariables: newInputVariables,
            partialVariables: newPartialVariables
        };
        return new ChatPromptTemplate(promptDict);
    }
    static fromTemplate(template, options) {
        const prompt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$prompt$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PromptTemplate"].fromTemplate(template, options);
        const humanTemplate = new HumanMessagePromptTemplate({
            prompt
        });
        return this.fromMessages([
            humanTemplate
        ]);
    }
    /**
     * Create a chat model-specific prompt from individual chat messages
     * or message-like tuples.
     * @param promptMessages Messages to be passed to the chat model
     * @returns A new ChatPromptTemplate
     */ static fromMessages(promptMessages, extra) {
        const flattenedMessages = promptMessages.reduce((acc, promptMessage)=>acc.concat(// eslint-disable-next-line no-instanceof/no-instanceof
            promptMessage instanceof ChatPromptTemplate ? promptMessage.promptMessages : [
                _coerceMessagePromptTemplateLike(promptMessage, extra)
            ]), []);
        const flattenedPartialVariables = promptMessages.reduce((acc, promptMessage)=>// eslint-disable-next-line no-instanceof/no-instanceof
            promptMessage instanceof ChatPromptTemplate ? Object.assign(acc, promptMessage.partialVariables) : acc, Object.create(null));
        const inputVariables = new Set();
        for (const promptMessage of flattenedMessages){
            // eslint-disable-next-line no-instanceof/no-instanceof
            if (promptMessage instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseMessage"]) continue;
            for (const inputVariable of promptMessage.inputVariables){
                if (inputVariable in flattenedPartialVariables) {
                    continue;
                }
                inputVariables.add(inputVariable);
            }
        }
        return new this({
            ...extra,
            inputVariables: [
                ...inputVariables
            ],
            promptMessages: flattenedMessages,
            partialVariables: flattenedPartialVariables,
            templateFormat: extra?.templateFormat
        });
    }
    /** @deprecated Renamed to .fromMessages */ // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static fromPromptMessages(promptMessages) {
        return this.fromMessages(promptMessages);
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/few_shot.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "FewShotChatMessagePromptTemplate": (()=>FewShotChatMessagePromptTemplate),
    "FewShotPromptTemplate": (()=>FewShotPromptTemplate)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$string$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/string.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/template.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$prompt$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/prompt.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/chat.js [app-route] (ecmascript)");
;
;
;
;
class FewShotPromptTemplate extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$string$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseStringPromptTemplate"] {
    constructor(input){
        super(input);
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "examples", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "exampleSelector", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "examplePrompt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "suffix", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ""
        });
        Object.defineProperty(this, "exampleSeparator", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "\n\n"
        });
        Object.defineProperty(this, "prefix", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ""
        });
        Object.defineProperty(this, "templateFormat", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "f-string"
        });
        Object.defineProperty(this, "validateTemplate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.assign(this, input);
        if (this.examples !== undefined && this.exampleSelector !== undefined) {
            throw new Error("Only one of 'examples' and 'example_selector' should be provided");
        }
        if (this.examples === undefined && this.exampleSelector === undefined) {
            throw new Error("One of 'examples' and 'example_selector' should be provided");
        }
        if (this.validateTemplate) {
            let totalInputVariables = this.inputVariables;
            if (this.partialVariables) {
                totalInputVariables = totalInputVariables.concat(Object.keys(this.partialVariables));
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["checkValidTemplate"])(this.prefix + this.suffix, this.templateFormat, totalInputVariables);
        }
    }
    _getPromptType() {
        return "few_shot";
    }
    static lc_name() {
        return "FewShotPromptTemplate";
    }
    async getExamples(inputVariables) {
        if (this.examples !== undefined) {
            return this.examples;
        }
        if (this.exampleSelector !== undefined) {
            return this.exampleSelector.selectExamples(inputVariables);
        }
        throw new Error("One of 'examples' and 'example_selector' should be provided");
    }
    async partial(values) {
        const newInputVariables = this.inputVariables.filter((iv)=>!(iv in values));
        const newPartialVariables = {
            ...this.partialVariables ?? {},
            ...values
        };
        const promptDict = {
            ...this,
            inputVariables: newInputVariables,
            partialVariables: newPartialVariables
        };
        return new FewShotPromptTemplate(promptDict);
    }
    /**
     * Formats the prompt with the given values.
     * @param values The values to format the prompt with.
     * @returns A promise that resolves to a string representing the formatted prompt.
     */ async format(values) {
        const allValues = await this.mergePartialAndUserVariables(values);
        const examples = await this.getExamples(allValues);
        const exampleStrings = await Promise.all(examples.map((example)=>this.examplePrompt.format(example)));
        const template = [
            this.prefix,
            ...exampleStrings,
            this.suffix
        ].join(this.exampleSeparator);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["renderTemplate"])(template, this.templateFormat, allValues);
    }
    serialize() {
        if (this.exampleSelector || !this.examples) {
            throw new Error("Serializing an example selector is not currently supported");
        }
        if (this.outputParser !== undefined) {
            throw new Error("Serializing an output parser is not currently supported");
        }
        return {
            _type: this._getPromptType(),
            input_variables: this.inputVariables,
            example_prompt: this.examplePrompt.serialize(),
            example_separator: this.exampleSeparator,
            suffix: this.suffix,
            prefix: this.prefix,
            template_format: this.templateFormat,
            examples: this.examples
        };
    }
    static async deserialize(data) {
        const { example_prompt } = data;
        if (!example_prompt) {
            throw new Error("Missing example prompt");
        }
        const examplePrompt = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$prompt$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PromptTemplate"].deserialize(example_prompt);
        let examples;
        if (Array.isArray(data.examples)) {
            examples = data.examples;
        } else {
            throw new Error("Invalid examples format. Only list or string are supported.");
        }
        return new FewShotPromptTemplate({
            inputVariables: data.input_variables,
            examplePrompt,
            examples,
            exampleSeparator: data.example_separator,
            prefix: data.prefix,
            suffix: data.suffix,
            templateFormat: data.template_format
        });
    }
}
class FewShotChatMessagePromptTemplate extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseChatPromptTemplate"] {
    _getPromptType() {
        return "few_shot_chat";
    }
    static lc_name() {
        return "FewShotChatMessagePromptTemplate";
    }
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "examples", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "exampleSelector", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "examplePrompt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "suffix", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ""
        });
        Object.defineProperty(this, "exampleSeparator", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "\n\n"
        });
        Object.defineProperty(this, "prefix", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ""
        });
        Object.defineProperty(this, "templateFormat", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "f-string"
        });
        Object.defineProperty(this, "validateTemplate", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        this.examples = fields.examples;
        this.examplePrompt = fields.examplePrompt;
        this.exampleSeparator = fields.exampleSeparator ?? "\n\n";
        this.exampleSelector = fields.exampleSelector;
        this.prefix = fields.prefix ?? "";
        this.suffix = fields.suffix ?? "";
        this.templateFormat = fields.templateFormat ?? "f-string";
        this.validateTemplate = fields.validateTemplate ?? true;
        if (this.examples !== undefined && this.exampleSelector !== undefined) {
            throw new Error("Only one of 'examples' and 'example_selector' should be provided");
        }
        if (this.examples === undefined && this.exampleSelector === undefined) {
            throw new Error("One of 'examples' and 'example_selector' should be provided");
        }
        if (this.validateTemplate) {
            let totalInputVariables = this.inputVariables;
            if (this.partialVariables) {
                totalInputVariables = totalInputVariables.concat(Object.keys(this.partialVariables));
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["checkValidTemplate"])(this.prefix + this.suffix, this.templateFormat, totalInputVariables);
        }
    }
    async getExamples(inputVariables) {
        if (this.examples !== undefined) {
            return this.examples;
        }
        if (this.exampleSelector !== undefined) {
            return this.exampleSelector.selectExamples(inputVariables);
        }
        throw new Error("One of 'examples' and 'example_selector' should be provided");
    }
    /**
     * Formats the list of values and returns a list of formatted messages.
     * @param values The values to format the prompt with.
     * @returns A promise that resolves to a string representing the formatted prompt.
     */ async formatMessages(values) {
        const allValues = await this.mergePartialAndUserVariables(values);
        let examples = await this.getExamples(allValues);
        examples = examples.map((example)=>{
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const result = {};
            this.examplePrompt.inputVariables.forEach((inputVariable)=>{
                result[inputVariable] = example[inputVariable];
            });
            return result;
        });
        const messages = [];
        for (const example of examples){
            const exampleMessages = await this.examplePrompt.formatMessages(example);
            messages.push(...exampleMessages);
        }
        return messages;
    }
    /**
     * Formats the prompt with the given values.
     * @param values The values to format the prompt with.
     * @returns A promise that resolves to a string representing the formatted prompt.
     */ async format(values) {
        const allValues = await this.mergePartialAndUserVariables(values);
        const examples = await this.getExamples(allValues);
        const exampleMessages = await Promise.all(examples.map((example)=>this.examplePrompt.formatMessages(example)));
        const exampleStrings = exampleMessages.flat().map((message)=>message.content);
        const template = [
            this.prefix,
            ...exampleStrings,
            this.suffix
        ].join(this.exampleSeparator);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["renderTemplate"])(template, this.templateFormat, allValues);
    }
    /**
     * Partially formats the prompt with the given values.
     * @param values The values to partially format the prompt with.
     * @returns A promise that resolves to an instance of `FewShotChatMessagePromptTemplate` with the given values partially formatted.
     */ async partial(values) {
        const newInputVariables = this.inputVariables.filter((variable)=>!(variable in values));
        const newPartialVariables = {
            ...this.partialVariables ?? {},
            ...values
        };
        const promptDict = {
            ...this,
            inputVariables: newInputVariables,
            partialVariables: newPartialVariables
        };
        return new FewShotChatMessagePromptTemplate(promptDict);
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/pipeline.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "PipelinePromptTemplate": (()=>PipelinePromptTemplate)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/chat.js [app-route] (ecmascript)");
;
;
class PipelinePromptTemplate extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BasePromptTemplate"] {
    static lc_name() {
        return "PipelinePromptTemplate";
    }
    constructor(input){
        super({
            ...input,
            inputVariables: []
        });
        Object.defineProperty(this, "pipelinePrompts", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "finalPrompt", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.pipelinePrompts = input.pipelinePrompts;
        this.finalPrompt = input.finalPrompt;
        this.inputVariables = this.computeInputValues();
    }
    /**
     * Computes the input values required by the pipeline prompts.
     * @returns Array of input values required by the pipeline prompts.
     */ computeInputValues() {
        const intermediateValues = this.pipelinePrompts.map((pipelinePrompt)=>pipelinePrompt.name);
        const inputValues = this.pipelinePrompts.map((pipelinePrompt)=>pipelinePrompt.prompt.inputVariables.filter((inputValue)=>!intermediateValues.includes(inputValue))).flat();
        return [
            ...new Set(inputValues)
        ];
    }
    static extractRequiredInputValues(allValues, requiredValueNames) {
        return requiredValueNames.reduce((requiredValues, valueName)=>{
            // eslint-disable-next-line no-param-reassign
            requiredValues[valueName] = allValues[valueName];
            return requiredValues;
        }, {});
    }
    /**
     * Formats the pipeline prompts based on the provided input values.
     * @param values Input values to format the pipeline prompts.
     * @returns Promise that resolves with the formatted input values.
     */ async formatPipelinePrompts(values) {
        const allValues = await this.mergePartialAndUserVariables(values);
        for (const { name: pipelinePromptName, prompt: pipelinePrompt } of this.pipelinePrompts){
            const pipelinePromptInputValues = PipelinePromptTemplate.extractRequiredInputValues(allValues, pipelinePrompt.inputVariables);
            // eslint-disable-next-line no-instanceof/no-instanceof
            if (pipelinePrompt instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatPromptTemplate"]) {
                allValues[pipelinePromptName] = await pipelinePrompt.formatMessages(pipelinePromptInputValues);
            } else {
                allValues[pipelinePromptName] = await pipelinePrompt.format(pipelinePromptInputValues);
            }
        }
        return PipelinePromptTemplate.extractRequiredInputValues(allValues, this.finalPrompt.inputVariables);
    }
    /**
     * Formats the final prompt value based on the provided input values.
     * @param values Input values to format the final prompt value.
     * @returns Promise that resolves with the formatted final prompt value.
     */ async formatPromptValue(values) {
        return this.finalPrompt.formatPromptValue(await this.formatPipelinePrompts(values));
    }
    async format(values) {
        return this.finalPrompt.format(await this.formatPipelinePrompts(values));
    }
    /**
     * Handles partial prompts, which are prompts that have been partially
     * filled with input values.
     * @param values Partial input values.
     * @returns Promise that resolves with a new PipelinePromptTemplate instance with updated input variables.
     */ async partial(values) {
        const promptDict = {
            ...this
        };
        promptDict.inputVariables = this.inputVariables.filter((iv)=>!(iv in values));
        promptDict.partialVariables = {
            ...this.partialVariables ?? {},
            ...values
        };
        return new PipelinePromptTemplate(promptDict);
    }
    serialize() {
        throw new Error("Not implemented.");
    }
    _getPromptType() {
        return "pipeline";
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/serde.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/structured.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "StructuredPrompt": (()=>StructuredPrompt)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/chat.js [app-route] (ecmascript)");
;
function isWithStructuredOutput(x) {
    return typeof x === "object" && x != null && "withStructuredOutput" in x && typeof x.withStructuredOutput === "function";
}
function isRunnableBinding(x) {
    return typeof x === "object" && x != null && "lc_id" in x && Array.isArray(x.lc_id) && x.lc_id.join("/") === "langchain_core/runnables/RunnableBinding";
}
class StructuredPrompt extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatPromptTemplate"] {
    get lc_aliases() {
        return {
            ...super.lc_aliases,
            schema: "schema_"
        };
    }
    constructor(input){
        super(input);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        Object.defineProperty(this, "schema", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "prompts",
                "structured"
            ]
        });
        this.schema = input.schema;
    }
    pipe(coerceable) {
        if (isWithStructuredOutput(coerceable)) {
            return super.pipe(coerceable.withStructuredOutput(this.schema));
        }
        if (isRunnableBinding(coerceable) && isWithStructuredOutput(coerceable.bound)) {
            return super.pipe(coerceable.bound.withStructuredOutput(this.schema).bind(coerceable.kwargs ?? {}).withConfig(coerceable.config));
        }
        throw new Error(`Structured prompts need to be piped to a language model that supports the "withStructuredOutput()" method.`);
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static fromMessagesAndSchema(promptMessages, schema) {
        return StructuredPrompt.fromMessages(promptMessages, {
            schema
        });
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/index.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
;
;
;
;
;
;
;
;
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/index.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$chat$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/chat.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$few_shot$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/few_shot.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$pipeline$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/pipeline.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$prompt$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/prompt.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$serde$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/serde.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$string$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/string.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$template$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/template.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$image$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/image.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$structured$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/structured.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/index.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/prompts.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/prompts.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompts$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompts/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$prompts$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/prompts.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/outputs.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/outputs.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$outputs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/outputs.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$outputs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/outputs.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/callbacks/manager.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/callbacks/manager.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$callbacks$2f$manager$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/callbacks/manager.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$callbacks$2f$manager$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/callbacks/manager.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/passthrough.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "RunnablePassthrough": (()=>RunnablePassthrough)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/stream.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/config.js [app-route] (ecmascript)");
;
;
;
class RunnablePassthrough extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Runnable"] {
    static lc_name() {
        return "RunnablePassthrough";
    }
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "runnables"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "func", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        if (fields) {
            this.func = fields.func;
        }
    }
    async invoke(input, options) {
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        if (this.func) {
            await this.func(input, config);
        }
        return this._callWithConfig((input)=>Promise.resolve(input), input, config);
    }
    async *transform(generator, options) {
        const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options);
        let finalOutput;
        let finalOutputSupported = true;
        for await (const chunk of this._transformStreamWithConfig(generator, (input)=>input, config)){
            yield chunk;
            if (finalOutputSupported) {
                if (finalOutput === undefined) {
                    finalOutput = chunk;
                } else {
                    try {
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        finalOutput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["concat"])(finalOutput, chunk);
                    } catch  {
                        finalOutput = undefined;
                        finalOutputSupported = false;
                    }
                }
            }
        }
        if (this.func && finalOutput !== undefined) {
            await this.func(finalOutput, config);
        }
    }
    /**
     * A runnable that assigns key-value pairs to the input.
     *
     * The example below shows how you could use it with an inline function.
     *
     * @example
     * ```typescript
     * const prompt =
     *   PromptTemplate.fromTemplate(`Write a SQL query to answer the question using the following schema: {schema}
     * Question: {question}
     * SQL Query:`);
     *
     * // The `RunnablePassthrough.assign()` is used here to passthrough the input from the `.invoke()`
     * // call (in this example it's the question), along with any inputs passed to the `.assign()` method.
     * // In this case, we're passing the schema.
     * const sqlQueryGeneratorChain = RunnableSequence.from([
     *   RunnablePassthrough.assign({
     *     schema: async () => db.getTableInfo(),
     *   }),
     *   prompt,
     *   new ChatOpenAI({}).bind({ stop: ["\nSQLResult:"] }),
     *   new StringOutputParser(),
     * ]);
     * const result = await sqlQueryGeneratorChain.invoke({
     *   question: "How many employees are there?",
     * });
     * ```
     */ static assign(mapping) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RunnableAssign"](new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RunnableMap"]({
            steps: mapping
        }));
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/router.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "RouterRunnable": (()=>RouterRunnable)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/config.js [app-route] (ecmascript)");
;
;
class RouterRunnable extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Runnable"] {
    static lc_name() {
        return "RouterRunnable";
    }
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "runnables"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "runnables", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.runnables = fields.runnables;
    }
    async invoke(input, options) {
        const { key, input: actualInput } = input;
        const runnable = this.runnables[key];
        if (runnable === undefined) {
            throw new Error(`No runnable associated with key "${key}".`);
        }
        return runnable.invoke(actualInput, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ensureConfig"])(options));
    }
    async batch(inputs, options, batchOptions) {
        const keys = inputs.map((input)=>input.key);
        const actualInputs = inputs.map((input)=>input.input);
        const missingKey = keys.find((key)=>this.runnables[key] === undefined);
        if (missingKey !== undefined) {
            throw new Error(`One or more keys do not have a corresponding runnable.`);
        }
        const runnables = keys.map((key)=>this.runnables[key]);
        const optionsList = this._getOptionsList(options ?? {}, inputs.length);
        const maxConcurrency = optionsList[0]?.maxConcurrency ?? batchOptions?.maxConcurrency;
        const batchSize = maxConcurrency && maxConcurrency > 0 ? maxConcurrency : inputs.length;
        const batchResults = [];
        for(let i = 0; i < actualInputs.length; i += batchSize){
            const batchPromises = actualInputs.slice(i, i + batchSize).map((actualInput, i)=>runnables[i].invoke(actualInput, optionsList[i]));
            const batchResult = await Promise.all(batchPromises);
            batchResults.push(batchResult);
        }
        return batchResults.flat();
    }
    async stream(input, options) {
        const { key, input: actualInput } = input;
        const runnable = this.runnables[key];
        if (runnable === undefined) {
            throw new Error(`No runnable associated with key "${key}".`);
        }
        return runnable.stream(actualInput, options);
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/branch.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "RunnableBranch": (()=>RunnableBranch)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/config.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/stream.js [app-route] (ecmascript)");
;
;
;
class RunnableBranch extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Runnable"] {
    static lc_name() {
        return "RunnableBranch";
    }
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "runnables"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "default", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "branches", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.branches = fields.branches;
        this.default = fields.default;
    }
    /**
     * Convenience method for instantiating a RunnableBranch from
     * RunnableLikes (objects, functions, or Runnables).
     *
     * Each item in the input except for the last one should be a
     * tuple with two items. The first is a "condition" RunnableLike that
     * returns "true" if the second RunnableLike in the tuple should run.
     *
     * The final item in the input should be a RunnableLike that acts as a
     * default branch if no other branches match.
     *
     * @example
     * ```ts
     * import { RunnableBranch } from "@langchain/core/runnables";
     *
     * const branch = RunnableBranch.from([
     *   [(x: number) => x > 0, (x: number) => x + 1],
     *   [(x: number) => x < 0, (x: number) => x - 1],
     *   (x: number) => x
     * ]);
     * ```
     * @param branches An array where the every item except the last is a tuple of [condition, runnable]
     *   pairs. The last item is a default runnable which is invoked if no other condition matches.
     * @returns A new RunnableBranch.
     */ // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static from(branches) {
        if (branches.length < 1) {
            throw new Error("RunnableBranch requires at least one branch");
        }
        const branchLikes = branches.slice(0, -1);
        const coercedBranches = branchLikes.map(([condition, runnable])=>[
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_coerceToRunnable"])(condition),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_coerceToRunnable"])(runnable)
            ]);
        const defaultBranch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_coerceToRunnable"])(branches[branches.length - 1]);
        return new this({
            branches: coercedBranches,
            default: defaultBranch
        });
    }
    async _invoke(input, config, runManager) {
        let result;
        for(let i = 0; i < this.branches.length; i += 1){
            const [condition, branchRunnable] = this.branches[i];
            const conditionValue = await condition.invoke(input, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
                callbacks: runManager?.getChild(`condition:${i + 1}`)
            }));
            if (conditionValue) {
                result = await branchRunnable.invoke(input, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
                    callbacks: runManager?.getChild(`branch:${i + 1}`)
                }));
                break;
            }
        }
        if (!result) {
            result = await this.default.invoke(input, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
                callbacks: runManager?.getChild("branch:default")
            }));
        }
        return result;
    }
    async invoke(input, config = {}) {
        return this._callWithConfig(this._invoke, input, config);
    }
    async *_streamIterator(input, config) {
        const callbackManager_ = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getCallbackManagerForConfig"])(config);
        const runManager = await callbackManager_?.handleChainStart(this.toJSON(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["_coerceToDict"])(input, "input"), config?.runId, undefined, undefined, undefined, config?.runName);
        let finalOutput;
        let finalOutputSupported = true;
        let stream;
        try {
            for(let i = 0; i < this.branches.length; i += 1){
                const [condition, branchRunnable] = this.branches[i];
                const conditionValue = await condition.invoke(input, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
                    callbacks: runManager?.getChild(`condition:${i + 1}`)
                }));
                if (conditionValue) {
                    stream = await branchRunnable.stream(input, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
                        callbacks: runManager?.getChild(`branch:${i + 1}`)
                    }));
                    for await (const chunk of stream){
                        yield chunk;
                        if (finalOutputSupported) {
                            if (finalOutput === undefined) {
                                finalOutput = chunk;
                            } else {
                                try {
                                    finalOutput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["concat"])(finalOutput, chunk);
                                } catch (e) {
                                    finalOutput = undefined;
                                    finalOutputSupported = false;
                                }
                            }
                        }
                    }
                    break;
                }
            }
            if (stream === undefined) {
                stream = await this.default.stream(input, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["patchConfig"])(config, {
                    callbacks: runManager?.getChild("branch:default")
                }));
                for await (const chunk of stream){
                    yield chunk;
                    if (finalOutputSupported) {
                        if (finalOutput === undefined) {
                            finalOutput = chunk;
                        } else {
                            try {
                                finalOutput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["concat"])(finalOutput, chunk);
                            } catch (e) {
                                finalOutput = undefined;
                                finalOutputSupported = false;
                            }
                        }
                    }
                }
            }
        } catch (e) {
            await runManager?.handleChainError(e);
            throw e;
        }
        await runManager?.handleChainEnd(finalOutput ?? {});
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/history.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "RunnableWithMessageHistory": (()=>RunnableWithMessageHistory)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$passthrough$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/passthrough.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/human.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/ai.js [app-route] (ecmascript)");
;
;
;
class RunnableWithMessageHistory extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RunnableBinding"] {
    constructor(fields){
        let historyChain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RunnableLambda"].from((input, options)=>this._enterHistory(input, options ?? {})).withConfig({
            runName: "loadHistory"
        });
        const messagesKey = fields.historyMessagesKey ?? fields.inputMessagesKey;
        if (messagesKey) {
            historyChain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$passthrough$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RunnablePassthrough"].assign({
                [messagesKey]: historyChain
            }).withConfig({
                runName: "insertHistory"
            });
        }
        const bound = historyChain.pipe(fields.runnable.withListeners({
            onEnd: (run, config)=>this._exitHistory(run, config ?? {})
        })).withConfig({
            runName: "RunnableWithMessageHistory"
        });
        const config = fields.config ?? {};
        super({
            ...fields,
            config,
            bound
        });
        Object.defineProperty(this, "runnable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "inputMessagesKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "outputMessagesKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "historyMessagesKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "getMessageHistory", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.runnable = fields.runnable;
        this.getMessageHistory = fields.getMessageHistory;
        this.inputMessagesKey = fields.inputMessagesKey;
        this.outputMessagesKey = fields.outputMessagesKey;
        this.historyMessagesKey = fields.historyMessagesKey;
    }
    _getInputMessages(// eslint-disable-next-line @typescript-eslint/no-explicit-any
    inputValue) {
        let parsedInputValue;
        if (typeof inputValue === "object" && !Array.isArray(inputValue) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseMessage"])(inputValue)) {
            let key;
            if (this.inputMessagesKey) {
                key = this.inputMessagesKey;
            } else if (Object.keys(inputValue).length === 1) {
                key = Object.keys(inputValue)[0];
            } else {
                key = "input";
            }
            if (Array.isArray(inputValue[key]) && Array.isArray(inputValue[key][0])) {
                parsedInputValue = inputValue[key][0];
            } else {
                parsedInputValue = inputValue[key];
            }
        } else {
            parsedInputValue = inputValue;
        }
        if (typeof parsedInputValue === "string") {
            return [
                new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$human$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HumanMessage"](parsedInputValue)
            ];
        } else if (Array.isArray(parsedInputValue)) {
            return parsedInputValue;
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseMessage"])(parsedInputValue)) {
            return [
                parsedInputValue
            ];
        } else {
            throw new Error(`Expected a string, BaseMessage, or array of BaseMessages.\nGot ${JSON.stringify(parsedInputValue, null, 2)}`);
        }
    }
    _getOutputMessages(// eslint-disable-next-line @typescript-eslint/no-explicit-any
    outputValue) {
        let parsedOutputValue;
        if (!Array.isArray(outputValue) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseMessage"])(outputValue) && typeof outputValue !== "string") {
            let key;
            if (this.outputMessagesKey !== undefined) {
                key = this.outputMessagesKey;
            } else if (Object.keys(outputValue).length === 1) {
                key = Object.keys(outputValue)[0];
            } else {
                key = "output";
            }
            // If you are wrapping a chat model directly
            // The output is actually this weird generations object
            if (outputValue.generations !== undefined) {
                parsedOutputValue = outputValue.generations[0][0].message;
            } else {
                parsedOutputValue = outputValue[key];
            }
        } else {
            parsedOutputValue = outputValue;
        }
        if (typeof parsedOutputValue === "string") {
            return [
                new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$ai$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AIMessage"](parsedOutputValue)
            ];
        } else if (Array.isArray(parsedOutputValue)) {
            return parsedOutputValue;
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseMessage"])(parsedOutputValue)) {
            return [
                parsedOutputValue
            ];
        } else {
            throw new Error(`Expected a string, BaseMessage, or array of BaseMessages. Received: ${JSON.stringify(parsedOutputValue, null, 2)}`);
        }
    }
    async _enterHistory(// eslint-disable-next-line @typescript-eslint/no-explicit-any
    input, kwargs) {
        const history = kwargs?.configurable?.messageHistory;
        const messages = await history.getMessages();
        if (this.historyMessagesKey === undefined) {
            return messages.concat(this._getInputMessages(input));
        }
        return messages;
    }
    async _exitHistory(run, config) {
        const history = config.configurable?.messageHistory;
        // Get input messages
        let inputs;
        // Chat model inputs are nested arrays
        if (Array.isArray(run.inputs) && Array.isArray(run.inputs[0])) {
            inputs = run.inputs[0];
        } else {
            inputs = run.inputs;
        }
        let inputMessages = this._getInputMessages(inputs);
        // If historic messages were prepended to the input messages, remove them to
        // avoid adding duplicate messages to history.
        if (this.historyMessagesKey === undefined) {
            const existingMessages = await history.getMessages();
            inputMessages = inputMessages.slice(existingMessages.length);
        }
        // Get output messages
        const outputValue = run.outputs;
        if (!outputValue) {
            throw new Error(`Output values from 'Run' undefined. Run: ${JSON.stringify(run, null, 2)}`);
        }
        const outputMessages = this._getOutputMessages(outputValue);
        await history.addMessages([
            ...inputMessages,
            ...outputMessages
        ]);
    }
    async _mergeConfig(...configs) {
        const config = await super._mergeConfig(...configs);
        // Extract sessionId
        if (!config.configurable || !config.configurable.sessionId) {
            const exampleInput = {
                [this.inputMessagesKey ?? "input"]: "foo"
            };
            const exampleConfig = {
                configurable: {
                    sessionId: "123"
                }
            };
            throw new Error(`sessionId is required. Pass it in as part of the config argument to .invoke() or .stream()\n` + `eg. chain.invoke(${JSON.stringify(exampleInput)}, ${JSON.stringify(exampleConfig)})`);
        }
        // attach messageHistory
        const { sessionId } = config.configurable;
        config.configurable.messageHistory = await this.getMessageHistory(sessionId);
        return config;
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/index.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
;
;
;
;
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/index.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/config.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$passthrough$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/passthrough.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$router$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/router.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$branch$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/branch.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$history$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/history.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/index.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/runnables.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/runnables.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$runnables$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/runnables.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/js-sha1/hash.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// @ts-nocheck
// Inlined to deal with portability issues with importing crypto module
/*
 * [js-sha1]{@link https://github.com/emn178/js-sha1}
 *
 * @version 0.6.0
 * @author Chen, Yi-Cyuan [emn178@gmail.com]
 * @copyright Chen, Yi-Cyuan 2014-2017
 * @license MIT
 */ /*jslint bitwise: true */ __turbopack_esm__({
    "insecureHash": (()=>insecureHash)
});
"use strict";
var root = ("TURBOPACK compile-time falsy", 0) ? ("TURBOPACK unreachable", undefined) : {};
var HEX_CHARS = "0123456789abcdef".split("");
var EXTRA = [
    -2147483648,
    8388608,
    32768,
    128
];
var SHIFT = [
    24,
    16,
    8,
    0
];
var OUTPUT_TYPES = [
    "hex",
    "array",
    "digest",
    "arrayBuffer"
];
var blocks = [];
function Sha1(sharedMemory) {
    if (sharedMemory) {
        blocks[0] = blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
        this.blocks = blocks;
    } else {
        this.blocks = [
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        ];
    }
    this.h0 = 0x67452301;
    this.h1 = 0xefcdab89;
    this.h2 = 0x98badcfe;
    this.h3 = 0x10325476;
    this.h4 = 0xc3d2e1f0;
    this.block = this.start = this.bytes = this.hBytes = 0;
    this.finalized = this.hashed = false;
    this.first = true;
}
Sha1.prototype.update = function(message) {
    if (this.finalized) {
        return;
    }
    var notString = typeof message !== "string";
    if (notString && message.constructor === root.ArrayBuffer) {
        message = new Uint8Array(message);
    }
    var code, index = 0, i, length = message.length || 0, blocks = this.blocks;
    while(index < length){
        if (this.hashed) {
            this.hashed = false;
            blocks[0] = this.block;
            blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
        }
        if (notString) {
            for(i = this.start; index < length && i < 64; ++index){
                blocks[i >> 2] |= message[index] << SHIFT[i++ & 3];
            }
        } else {
            for(i = this.start; index < length && i < 64; ++index){
                code = message.charCodeAt(index);
                if (code < 0x80) {
                    blocks[i >> 2] |= code << SHIFT[i++ & 3];
                } else if (code < 0x800) {
                    blocks[i >> 2] |= (0xc0 | code >> 6) << SHIFT[i++ & 3];
                    blocks[i >> 2] |= (0x80 | code & 0x3f) << SHIFT[i++ & 3];
                } else if (code < 0xd800 || code >= 0xe000) {
                    blocks[i >> 2] |= (0xe0 | code >> 12) << SHIFT[i++ & 3];
                    blocks[i >> 2] |= (0x80 | code >> 6 & 0x3f) << SHIFT[i++ & 3];
                    blocks[i >> 2] |= (0x80 | code & 0x3f) << SHIFT[i++ & 3];
                } else {
                    code = 0x10000 + ((code & 0x3ff) << 10 | message.charCodeAt(++index) & 0x3ff);
                    blocks[i >> 2] |= (0xf0 | code >> 18) << SHIFT[i++ & 3];
                    blocks[i >> 2] |= (0x80 | code >> 12 & 0x3f) << SHIFT[i++ & 3];
                    blocks[i >> 2] |= (0x80 | code >> 6 & 0x3f) << SHIFT[i++ & 3];
                    blocks[i >> 2] |= (0x80 | code & 0x3f) << SHIFT[i++ & 3];
                }
            }
        }
        this.lastByteIndex = i;
        this.bytes += i - this.start;
        if (i >= 64) {
            this.block = blocks[16];
            this.start = i - 64;
            this.hash();
            this.hashed = true;
        } else {
            this.start = i;
        }
    }
    if (this.bytes > 4294967295) {
        this.hBytes += this.bytes / 4294967296 << 0;
        this.bytes = this.bytes % 4294967296;
    }
    return this;
};
Sha1.prototype.finalize = function() {
    if (this.finalized) {
        return;
    }
    this.finalized = true;
    var blocks = this.blocks, i = this.lastByteIndex;
    blocks[16] = this.block;
    blocks[i >> 2] |= EXTRA[i & 3];
    this.block = blocks[16];
    if (i >= 56) {
        if (!this.hashed) {
            this.hash();
        }
        blocks[0] = this.block;
        blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
    }
    blocks[14] = this.hBytes << 3 | this.bytes >>> 29;
    blocks[15] = this.bytes << 3;
    this.hash();
};
Sha1.prototype.hash = function() {
    var a = this.h0, b = this.h1, c = this.h2, d = this.h3, e = this.h4;
    var f, j, t, blocks = this.blocks;
    for(j = 16; j < 80; ++j){
        t = blocks[j - 3] ^ blocks[j - 8] ^ blocks[j - 14] ^ blocks[j - 16];
        blocks[j] = t << 1 | t >>> 31;
    }
    for(j = 0; j < 20; j += 5){
        f = b & c | ~b & d;
        t = a << 5 | a >>> 27;
        e = t + f + e + 1518500249 + blocks[j] << 0;
        b = b << 30 | b >>> 2;
        f = a & b | ~a & c;
        t = e << 5 | e >>> 27;
        d = t + f + d + 1518500249 + blocks[j + 1] << 0;
        a = a << 30 | a >>> 2;
        f = e & a | ~e & b;
        t = d << 5 | d >>> 27;
        c = t + f + c + 1518500249 + blocks[j + 2] << 0;
        e = e << 30 | e >>> 2;
        f = d & e | ~d & a;
        t = c << 5 | c >>> 27;
        b = t + f + b + 1518500249 + blocks[j + 3] << 0;
        d = d << 30 | d >>> 2;
        f = c & d | ~c & e;
        t = b << 5 | b >>> 27;
        a = t + f + a + 1518500249 + blocks[j + 4] << 0;
        c = c << 30 | c >>> 2;
    }
    for(; j < 40; j += 5){
        f = b ^ c ^ d;
        t = a << 5 | a >>> 27;
        e = t + f + e + 1859775393 + blocks[j] << 0;
        b = b << 30 | b >>> 2;
        f = a ^ b ^ c;
        t = e << 5 | e >>> 27;
        d = t + f + d + 1859775393 + blocks[j + 1] << 0;
        a = a << 30 | a >>> 2;
        f = e ^ a ^ b;
        t = d << 5 | d >>> 27;
        c = t + f + c + 1859775393 + blocks[j + 2] << 0;
        e = e << 30 | e >>> 2;
        f = d ^ e ^ a;
        t = c << 5 | c >>> 27;
        b = t + f + b + 1859775393 + blocks[j + 3] << 0;
        d = d << 30 | d >>> 2;
        f = c ^ d ^ e;
        t = b << 5 | b >>> 27;
        a = t + f + a + 1859775393 + blocks[j + 4] << 0;
        c = c << 30 | c >>> 2;
    }
    for(; j < 60; j += 5){
        f = b & c | b & d | c & d;
        t = a << 5 | a >>> 27;
        e = t + f + e - 1894007588 + blocks[j] << 0;
        b = b << 30 | b >>> 2;
        f = a & b | a & c | b & c;
        t = e << 5 | e >>> 27;
        d = t + f + d - 1894007588 + blocks[j + 1] << 0;
        a = a << 30 | a >>> 2;
        f = e & a | e & b | a & b;
        t = d << 5 | d >>> 27;
        c = t + f + c - 1894007588 + blocks[j + 2] << 0;
        e = e << 30 | e >>> 2;
        f = d & e | d & a | e & a;
        t = c << 5 | c >>> 27;
        b = t + f + b - 1894007588 + blocks[j + 3] << 0;
        d = d << 30 | d >>> 2;
        f = c & d | c & e | d & e;
        t = b << 5 | b >>> 27;
        a = t + f + a - 1894007588 + blocks[j + 4] << 0;
        c = c << 30 | c >>> 2;
    }
    for(; j < 80; j += 5){
        f = b ^ c ^ d;
        t = a << 5 | a >>> 27;
        e = t + f + e - 899497514 + blocks[j] << 0;
        b = b << 30 | b >>> 2;
        f = a ^ b ^ c;
        t = e << 5 | e >>> 27;
        d = t + f + d - 899497514 + blocks[j + 1] << 0;
        a = a << 30 | a >>> 2;
        f = e ^ a ^ b;
        t = d << 5 | d >>> 27;
        c = t + f + c - 899497514 + blocks[j + 2] << 0;
        e = e << 30 | e >>> 2;
        f = d ^ e ^ a;
        t = c << 5 | c >>> 27;
        b = t + f + b - 899497514 + blocks[j + 3] << 0;
        d = d << 30 | d >>> 2;
        f = c ^ d ^ e;
        t = b << 5 | b >>> 27;
        a = t + f + a - 899497514 + blocks[j + 4] << 0;
        c = c << 30 | c >>> 2;
    }
    this.h0 = this.h0 + a << 0;
    this.h1 = this.h1 + b << 0;
    this.h2 = this.h2 + c << 0;
    this.h3 = this.h3 + d << 0;
    this.h4 = this.h4 + e << 0;
};
Sha1.prototype.hex = function() {
    this.finalize();
    var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
    return HEX_CHARS[h0 >> 28 & 0x0f] + HEX_CHARS[h0 >> 24 & 0x0f] + HEX_CHARS[h0 >> 20 & 0x0f] + HEX_CHARS[h0 >> 16 & 0x0f] + HEX_CHARS[h0 >> 12 & 0x0f] + HEX_CHARS[h0 >> 8 & 0x0f] + HEX_CHARS[h0 >> 4 & 0x0f] + HEX_CHARS[h0 & 0x0f] + HEX_CHARS[h1 >> 28 & 0x0f] + HEX_CHARS[h1 >> 24 & 0x0f] + HEX_CHARS[h1 >> 20 & 0x0f] + HEX_CHARS[h1 >> 16 & 0x0f] + HEX_CHARS[h1 >> 12 & 0x0f] + HEX_CHARS[h1 >> 8 & 0x0f] + HEX_CHARS[h1 >> 4 & 0x0f] + HEX_CHARS[h1 & 0x0f] + HEX_CHARS[h2 >> 28 & 0x0f] + HEX_CHARS[h2 >> 24 & 0x0f] + HEX_CHARS[h2 >> 20 & 0x0f] + HEX_CHARS[h2 >> 16 & 0x0f] + HEX_CHARS[h2 >> 12 & 0x0f] + HEX_CHARS[h2 >> 8 & 0x0f] + HEX_CHARS[h2 >> 4 & 0x0f] + HEX_CHARS[h2 & 0x0f] + HEX_CHARS[h3 >> 28 & 0x0f] + HEX_CHARS[h3 >> 24 & 0x0f] + HEX_CHARS[h3 >> 20 & 0x0f] + HEX_CHARS[h3 >> 16 & 0x0f] + HEX_CHARS[h3 >> 12 & 0x0f] + HEX_CHARS[h3 >> 8 & 0x0f] + HEX_CHARS[h3 >> 4 & 0x0f] + HEX_CHARS[h3 & 0x0f] + HEX_CHARS[h4 >> 28 & 0x0f] + HEX_CHARS[h4 >> 24 & 0x0f] + HEX_CHARS[h4 >> 20 & 0x0f] + HEX_CHARS[h4 >> 16 & 0x0f] + HEX_CHARS[h4 >> 12 & 0x0f] + HEX_CHARS[h4 >> 8 & 0x0f] + HEX_CHARS[h4 >> 4 & 0x0f] + HEX_CHARS[h4 & 0x0f];
};
Sha1.prototype.toString = Sha1.prototype.hex;
Sha1.prototype.digest = function() {
    this.finalize();
    var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
    return [
        h0 >> 24 & 0xff,
        h0 >> 16 & 0xff,
        h0 >> 8 & 0xff,
        h0 & 0xff,
        h1 >> 24 & 0xff,
        h1 >> 16 & 0xff,
        h1 >> 8 & 0xff,
        h1 & 0xff,
        h2 >> 24 & 0xff,
        h2 >> 16 & 0xff,
        h2 >> 8 & 0xff,
        h2 & 0xff,
        h3 >> 24 & 0xff,
        h3 >> 16 & 0xff,
        h3 >> 8 & 0xff,
        h3 & 0xff,
        h4 >> 24 & 0xff,
        h4 >> 16 & 0xff,
        h4 >> 8 & 0xff,
        h4 & 0xff
    ];
};
Sha1.prototype.array = Sha1.prototype.digest;
Sha1.prototype.arrayBuffer = function() {
    this.finalize();
    var buffer = new ArrayBuffer(20);
    var dataView = new DataView(buffer);
    dataView.setUint32(0, this.h0);
    dataView.setUint32(4, this.h1);
    dataView.setUint32(8, this.h2);
    dataView.setUint32(12, this.h3);
    dataView.setUint32(16, this.h4);
    return buffer;
};
const insecureHash = (message)=>{
    return new Sha1(true).update(message)["hex"]();
};
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/hash.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/hash.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$js$2d$sha1$2f$hash$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/js-sha1/hash.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$hash$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/hash.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/caches/base.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "BaseCache": (()=>BaseCache),
    "InMemoryCache": (()=>InMemoryCache),
    "deserializeStoredGeneration": (()=>deserializeStoredGeneration),
    "getCacheKey": (()=>getCacheKey),
    "serializeGeneration": (()=>serializeGeneration)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$hash$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/hash.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$js$2d$sha1$2f$hash$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/js-sha1/hash.js [app-route] (ecmascript)");
;
;
const getCacheKey = (...strings)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$js$2d$sha1$2f$hash$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["insecureHash"])(strings.join("_"));
function deserializeStoredGeneration(storedGeneration) {
    if (storedGeneration.message !== undefined) {
        return {
            text: storedGeneration.text,
            message: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mapStoredMessageToChatMessage"])(storedGeneration.message)
        };
    } else {
        return {
            text: storedGeneration.text
        };
    }
}
function serializeGeneration(generation) {
    const serializedValue = {
        text: generation.text
    };
    if (generation.message !== undefined) {
        serializedValue.message = generation.message.toDict();
    }
    return serializedValue;
}
class BaseCache {
}
const GLOBAL_MAP = new Map();
class InMemoryCache extends BaseCache {
    constructor(map){
        super();
        Object.defineProperty(this, "cache", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.cache = map ?? new Map();
    }
    /**
     * Retrieves data from the cache using a prompt and an LLM key. If the
     * data is not found, it returns null.
     * @param prompt The prompt used to find the data.
     * @param llmKey The LLM key used to find the data.
     * @returns The data corresponding to the prompt and LLM key, or null if not found.
     */ lookup(prompt, llmKey) {
        return Promise.resolve(this.cache.get(getCacheKey(prompt, llmKey)) ?? null);
    }
    /**
     * Updates the cache with new data using a prompt and an LLM key.
     * @param prompt The prompt used to store the data.
     * @param llmKey The LLM key used to store the data.
     * @param value The data to be stored.
     */ async update(prompt, llmKey, value) {
        this.cache.set(getCacheKey(prompt, llmKey), value);
    }
    /**
     * Returns a global instance of InMemoryCache using a predefined global
     * map as the initial cache.
     * @returns A global instance of InMemoryCache.
     */ static global() {
        return new InMemoryCache(GLOBAL_MAP);
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/tiktoken.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "encodingForModel": (()=>encodingForModel),
    "getEncoding": (()=>getEncoding)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$js$2d$tiktoken$40$1$2e$0$2e$16$2f$node_modules$2f$js$2d$tiktoken$2f$dist$2f$lite$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/js-tiktoken@1.0.16/node_modules/js-tiktoken/dist/lite.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$async_caller$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/async_caller.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$js$2d$tiktoken$40$1$2e$0$2e$16$2f$node_modules$2f$js$2d$tiktoken$2f$dist$2f$chunk$2d$3652LHBA$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/js-tiktoken@1.0.16/node_modules/js-tiktoken/dist/chunk-3652LHBA.js [app-route] (ecmascript)");
;
;
const cache = {};
const caller = /* #__PURE__ */ new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$async_caller$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncCaller"]({});
async function getEncoding(encoding) {
    if (!(encoding in cache)) {
        cache[encoding] = caller.fetch(`https://tiktoken.pages.dev/js/${encoding}.json`).then((res)=>res.json()).then((data)=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$js$2d$tiktoken$40$1$2e$0$2e$16$2f$node_modules$2f$js$2d$tiktoken$2f$dist$2f$chunk$2d$3652LHBA$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Tiktoken"](data)).catch((e)=>{
            delete cache[encoding];
            throw e;
        });
    }
    return await cache[encoding];
}
async function encodingForModel(model) {
    return getEncoding((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$js$2d$tiktoken$40$1$2e$0$2e$16$2f$node_modules$2f$js$2d$tiktoken$2f$dist$2f$chunk$2d$3652LHBA$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getEncodingNameForModel"])(model));
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/language_models/base.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "BaseLangChain": (()=>BaseLangChain),
    "BaseLanguageModel": (()=>BaseLanguageModel),
    "calculateMaxTokens": (()=>calculateMaxTokens),
    "getEmbeddingContextSize": (()=>getEmbeddingContextSize),
    "getModelContextSize": (()=>getModelContextSize),
    "getModelNameForTiktoken": (()=>getModelNameForTiktoken),
    "isOpenAITool": (()=>isOpenAITool)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$caches$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/caches/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompt_values$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/prompt_values.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$async_caller$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/async_caller.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$tiktoken$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/tiktoken.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/base.js [app-route] (ecmascript)");
;
;
;
;
;
;
const getModelNameForTiktoken = (modelName)=>{
    if (modelName.startsWith("gpt-3.5-turbo-16k")) {
        return "gpt-3.5-turbo-16k";
    }
    if (modelName.startsWith("gpt-3.5-turbo-")) {
        return "gpt-3.5-turbo";
    }
    if (modelName.startsWith("gpt-4-32k")) {
        return "gpt-4-32k";
    }
    if (modelName.startsWith("gpt-4-")) {
        return "gpt-4";
    }
    if (modelName.startsWith("gpt-4o")) {
        return "gpt-4o";
    }
    return modelName;
};
const getEmbeddingContextSize = (modelName)=>{
    switch(modelName){
        case "text-embedding-ada-002":
            return 8191;
        default:
            return 2046;
    }
};
const getModelContextSize = (modelName)=>{
    switch(getModelNameForTiktoken(modelName)){
        case "gpt-3.5-turbo-16k":
            return 16384;
        case "gpt-3.5-turbo":
            return 4096;
        case "gpt-4-32k":
            return 32768;
        case "gpt-4":
            return 8192;
        case "text-davinci-003":
            return 4097;
        case "text-curie-001":
            return 2048;
        case "text-babbage-001":
            return 2048;
        case "text-ada-001":
            return 2048;
        case "code-davinci-002":
            return 8000;
        case "code-cushman-001":
            return 2048;
        default:
            return 4097;
    }
};
function isOpenAITool(tool) {
    if (typeof tool !== "object" || !tool) return false;
    if ("type" in tool && tool.type === "function" && "function" in tool && typeof tool.function === "object" && tool.function && "name" in tool.function && "parameters" in tool.function) {
        return true;
    }
    return false;
}
const calculateMaxTokens = async ({ prompt, modelName })=>{
    let numTokens;
    try {
        numTokens = (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$tiktoken$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["encodingForModel"])(getModelNameForTiktoken(modelName))).encode(prompt).length;
    } catch (error) {
        console.warn("Failed to calculate number of tokens, falling back to approximate count");
        // fallback to approximate calculation if tiktoken is not available
        // each token is ~4 characters: https://help.openai.com/en/articles/4936856-what-are-tokens-and-how-to-count-them#
        numTokens = Math.ceil(prompt.length / 4);
    }
    const maxTokens = getModelContextSize(modelName);
    return maxTokens - numTokens;
};
const getVerbosity = ()=>false;
class BaseLangChain extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Runnable"] {
    get lc_attributes() {
        return {
            callbacks: undefined,
            verbose: undefined
        };
    }
    constructor(params){
        super(params);
        /**
         * Whether to print out response text.
         */ Object.defineProperty(this, "verbose", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "callbacks", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "tags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "metadata", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.verbose = params.verbose ?? getVerbosity();
        this.callbacks = params.callbacks;
        this.tags = params.tags ?? [];
        this.metadata = params.metadata ?? {};
    }
}
class BaseLanguageModel extends BaseLangChain {
    /**
     * Keys that the language model accepts as call options.
     */ get callKeys() {
        return [
            "stop",
            "timeout",
            "signal",
            "tags",
            "metadata",
            "callbacks"
        ];
    }
    constructor({ callbacks, callbackManager, ...params }){
        const { cache, ...rest } = params;
        super({
            callbacks: callbacks ?? callbackManager,
            ...rest
        });
        /**
         * The async caller should be used by subclasses to make any async calls,
         * which will thus benefit from the concurrency and retry logic.
         */ Object.defineProperty(this, "caller", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "cache", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "_encoding", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        if (typeof cache === "object") {
            this.cache = cache;
        } else if (cache) {
            this.cache = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$caches$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["InMemoryCache"].global();
        } else {
            this.cache = undefined;
        }
        this.caller = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$async_caller$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AsyncCaller"](params ?? {});
    }
    async getNumTokens(content) {
        // TODO: Figure out correct value.
        if (typeof content !== "string") {
            return 0;
        }
        // fallback to approximate calculation if tiktoken is not available
        let numTokens = Math.ceil(content.length / 4);
        if (!this._encoding) {
            try {
                this._encoding = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$tiktoken$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["encodingForModel"])("modelName" in this ? getModelNameForTiktoken(this.modelName) : "gpt2");
            } catch (error) {
                console.warn("Failed to calculate number of tokens, falling back to approximate count", error);
            }
        }
        if (this._encoding) {
            try {
                numTokens = this._encoding.encode(content).length;
            } catch (error) {
                console.warn("Failed to calculate number of tokens, falling back to approximate count", error);
            }
        }
        return numTokens;
    }
    static _convertInputToPromptValue(input) {
        if (typeof input === "string") {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompt_values$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StringPromptValue"](input);
        } else if (Array.isArray(input)) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$prompt_values$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatPromptValue"](input.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["coerceMessageLikeToMessage"]));
        } else {
            return input;
        }
    }
    /**
     * Get the identifying parameters of the LLM.
     */ // eslint-disable-next-line @typescript-eslint/no-explicit-any
    _identifyingParams() {
        return {};
    }
    /**
     * Create a unique cache key for a specific call to a specific language model.
     * @param callOptions Call options for the model
     * @returns A unique cache key.
     */ _getSerializedCacheKeyParametersForCall(// TODO: Fix when we remove the RunnableLambda backwards compatibility shim.
    { config, ...callOptions }) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const params = {
            ...this._identifyingParams(),
            ...callOptions,
            _type: this._llmType(),
            _model: this._modelType()
        };
        const filteredEntries = Object.entries(params).filter(([_, value])=>value !== undefined);
        const serializedEntries = filteredEntries.map(([key, value])=>`${key}:${JSON.stringify(value)}`).sort().join(",");
        return serializedEntries;
    }
    /**
     * @deprecated
     * Return a json-like object representing this LLM.
     */ serialize() {
        return {
            ...this._identifyingParams(),
            _type: this._llmType(),
            _model: this._modelType()
        };
    }
    /**
     * @deprecated
     * Load an LLM from a json-like object describing it.
     */ static async deserialize(_data) {
        throw new Error("Use .toJSON() instead");
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/language_models/base.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/language_models/base.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$language_models$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/language_models/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$language_models$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/language_models/base.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/base.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "BaseLLMOutputParser": (()=>BaseLLMOutputParser),
    "BaseOutputParser": (()=>BaseOutputParser),
    "OutputParserException": (()=>OutputParserException)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$errors$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/errors/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/runnables/base.js [app-route] (ecmascript)");
;
;
class BaseLLMOutputParser extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$runnables$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Runnable"] {
    /**
     * Parses the result of an LLM call with a given prompt. By default, it
     * simply calls `parseResult`.
     * @param generations The generations from an LLM call.
     * @param _prompt The prompt used in the LLM call.
     * @param callbacks Optional callbacks.
     * @returns A promise of the parsed output.
     */ parseResultWithPrompt(generations, _prompt, callbacks) {
        return this.parseResult(generations, callbacks);
    }
    _baseMessageToString(message) {
        return typeof message.content === "string" ? message.content : this._baseMessageContentToString(message.content);
    }
    _baseMessageContentToString(content) {
        return JSON.stringify(content);
    }
    /**
     * Calls the parser with a given input and optional configuration options.
     * If the input is a string, it creates a generation with the input as
     * text and calls `parseResult`. If the input is a `BaseMessage`, it
     * creates a generation with the input as a message and the content of the
     * input as text, and then calls `parseResult`.
     * @param input The input to the parser, which can be a string or a `BaseMessage`.
     * @param options Optional configuration options.
     * @returns A promise of the parsed output.
     */ async invoke(input, options) {
        if (typeof input === "string") {
            return this._callWithConfig(async (input, options)=>this.parseResult([
                    {
                        text: input
                    }
                ], options?.callbacks), input, {
                ...options,
                runType: "parser"
            });
        } else {
            return this._callWithConfig(async (input, options)=>this.parseResult([
                    {
                        message: input,
                        text: this._baseMessageToString(input)
                    }
                ], options?.callbacks), input, {
                ...options,
                runType: "parser"
            });
        }
    }
}
class BaseOutputParser extends BaseLLMOutputParser {
    parseResult(generations, callbacks) {
        return this.parse(generations[0].text, callbacks);
    }
    async parseWithPrompt(text, _prompt, callbacks) {
        return this.parse(text, callbacks);
    }
    /**
     * Return the string type key uniquely identifying this class of parser
     */ _type() {
        throw new Error("_type not implemented");
    }
}
class OutputParserException extends Error {
    constructor(message, llmOutput, observation, sendToLLM = false){
        super(message);
        Object.defineProperty(this, "llmOutput", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "observation", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "sendToLLM", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.llmOutput = llmOutput;
        this.observation = observation;
        this.sendToLLM = sendToLLM;
        if (sendToLLM) {
            if (observation === undefined || llmOutput === undefined) {
                throw new Error("Arguments 'observation' & 'llmOutput' are required if 'sendToLlm' is true");
            }
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$errors$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["addLangChainErrorFields"])(this, "OUTPUT_PARSING_FAILURE");
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/transform.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "BaseCumulativeTransformOutputParser": (()=>BaseCumulativeTransformOutputParser),
    "BaseTransformOutputParser": (()=>BaseTransformOutputParser)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$cfworker$2b$json$2d$schema$40$4$2e$1$2e$0$2f$node_modules$2f40$cfworker$2f$json$2d$schema$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@cfworker+json-schema@4.1.0/node_modules/@cfworker/json-schema/dist/esm/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/messages/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$outputs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/outputs.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$cfworker$2b$json$2d$schema$40$4$2e$1$2e$0$2f$node_modules$2f40$cfworker$2f$json$2d$schema$2f$dist$2f$esm$2f$deep$2d$compare$2d$strict$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@cfworker+json-schema@4.1.0/node_modules/@cfworker/json-schema/dist/esm/deep-compare-strict.js [app-route] (ecmascript)");
;
;
;
;
;
class BaseTransformOutputParser extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseOutputParser"] {
    async *_transform(inputGenerator) {
        for await (const chunk of inputGenerator){
            if (typeof chunk === "string") {
                yield this.parseResult([
                    {
                        text: chunk
                    }
                ]);
            } else {
                yield this.parseResult([
                    {
                        message: chunk,
                        text: this._baseMessageToString(chunk)
                    }
                ]);
            }
        }
    }
    /**
     * Transforms an asynchronous generator of input into an asynchronous
     * generator of parsed output.
     * @param inputGenerator An asynchronous generator of input.
     * @param options A configuration object.
     * @returns An asynchronous generator of parsed output.
     */ async *transform(inputGenerator, options) {
        yield* this._transformStreamWithConfig(inputGenerator, this._transform.bind(this), {
            ...options,
            runType: "parser"
        });
    }
}
class BaseCumulativeTransformOutputParser extends BaseTransformOutputParser {
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "diff", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        this.diff = fields?.diff ?? this.diff;
    }
    async *_transform(inputGenerator) {
        let prevParsed;
        let accGen;
        for await (const chunk of inputGenerator){
            if (typeof chunk !== "string" && typeof chunk.content !== "string") {
                throw new Error("Cannot handle non-string output.");
            }
            let chunkGen;
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseMessageChunk"])(chunk)) {
                if (typeof chunk.content !== "string") {
                    throw new Error("Cannot handle non-string message output.");
                }
                chunkGen = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$outputs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatGenerationChunk"]({
                    message: chunk,
                    text: chunk.content
                });
            } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isBaseMessage"])(chunk)) {
                if (typeof chunk.content !== "string") {
                    throw new Error("Cannot handle non-string message output.");
                }
                chunkGen = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$outputs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ChatGenerationChunk"]({
                    message: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$messages$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["convertToChunk"])(chunk),
                    text: chunk.content
                });
            } else {
                chunkGen = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$outputs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GenerationChunk"]({
                    text: chunk
                });
            }
            if (accGen === undefined) {
                accGen = chunkGen;
            } else {
                accGen = accGen.concat(chunkGen);
            }
            const parsed = await this.parsePartialResult([
                accGen
            ]);
            if (parsed !== undefined && parsed !== null && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$cfworker$2b$json$2d$schema$40$4$2e$1$2e$0$2f$node_modules$2f40$cfworker$2f$json$2d$schema$2f$dist$2f$esm$2f$deep$2d$compare$2d$strict$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deepCompareStrict"])(parsed, prevParsed)) {
                if (this.diff) {
                    yield this._diff(prevParsed, parsed);
                } else {
                    yield parsed;
                }
                prevParsed = parsed;
            }
        }
    }
    getFormatInstructions() {
        return "";
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/bytes.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "BytesOutputParser": (()=>BytesOutputParser)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$transform$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/transform.js [app-route] (ecmascript)");
;
class BytesOutputParser extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$transform$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseTransformOutputParser"] {
    constructor(){
        super(...arguments);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "output_parsers",
                "bytes"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        // TODO: Figure out why explicit typing is needed
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        Object.defineProperty(this, "textEncoder", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new TextEncoder()
        });
    }
    static lc_name() {
        return "BytesOutputParser";
    }
    parse(text) {
        return Promise.resolve(this.textEncoder.encode(text));
    }
    getFormatInstructions() {
        return "";
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/list.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "CommaSeparatedListOutputParser": (()=>CommaSeparatedListOutputParser),
    "CustomListOutputParser": (()=>CustomListOutputParser),
    "ListOutputParser": (()=>ListOutputParser),
    "MarkdownListOutputParser": (()=>MarkdownListOutputParser),
    "NumberedListOutputParser": (()=>NumberedListOutputParser)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$transform$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/transform.js [app-route] (ecmascript)");
;
;
class ListOutputParser extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$transform$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseTransformOutputParser"] {
    constructor(){
        super(...arguments);
        Object.defineProperty(this, "re", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    async *_transform(inputGenerator) {
        let buffer = "";
        for await (const input of inputGenerator){
            if (typeof input === "string") {
                // add current chunk to buffer
                buffer += input;
            } else {
                // extract message content and add to buffer
                buffer += input.content;
            }
            // get parts in buffer
            if (!this.re) {
                const parts = await this.parse(buffer);
                if (parts.length > 1) {
                    // if there are multiple parts, yield all but the last one
                    for (const part of parts.slice(0, -1)){
                        yield [
                            part
                        ];
                    }
                    // keep the last part in the buffer
                    buffer = parts[parts.length - 1];
                }
            } else {
                // if there is a regex, get all matches
                const matches = [
                    ...buffer.matchAll(this.re)
                ];
                if (matches.length > 1) {
                    let doneIdx = 0;
                    // if there are multiple matches, yield all but the last one
                    for (const match of matches.slice(0, -1)){
                        yield [
                            match[1]
                        ];
                        doneIdx += (match.index ?? 0) + match[0].length;
                    }
                    // keep the last match in the buffer
                    buffer = buffer.slice(doneIdx);
                }
            }
        }
        // yield the last part
        for (const part of (await this.parse(buffer))){
            yield [
                part
            ];
        }
    }
}
class CommaSeparatedListOutputParser extends ListOutputParser {
    constructor(){
        super(...arguments);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "output_parsers",
                "list"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
    }
    static lc_name() {
        return "CommaSeparatedListOutputParser";
    }
    /**
     * Parses the given text into an array of strings, using a comma as the
     * separator. If the parsing fails, throws an OutputParserException.
     * @param text The text to parse.
     * @returns An array of strings obtained by splitting the input text at each comma.
     */ async parse(text) {
        try {
            return text.trim().split(",").map((s)=>s.trim());
        } catch (e) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["OutputParserException"](`Could not parse output: ${text}`, text);
        }
    }
    /**
     * Provides instructions on the expected format of the response for the
     * CommaSeparatedListOutputParser.
     * @returns A string containing instructions on the expected format of the response.
     */ getFormatInstructions() {
        return `Your response should be a list of comma separated values, eg: \`foo, bar, baz\``;
    }
}
class CustomListOutputParser extends ListOutputParser {
    constructor({ length, separator }){
        super(...arguments);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "output_parsers",
                "list"
            ]
        });
        Object.defineProperty(this, "length", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "separator", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.length = length;
        this.separator = separator || ",";
    }
    /**
     * Parses the given text into an array of strings, using the specified
     * separator. If the parsing fails or the number of items in the list
     * doesn't match the expected length, throws an OutputParserException.
     * @param text The text to parse.
     * @returns An array of strings obtained by splitting the input text at each occurrence of the specified separator.
     */ async parse(text) {
        try {
            const items = text.trim().split(this.separator).map((s)=>s.trim());
            if (this.length !== undefined && items.length !== this.length) {
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["OutputParserException"](`Incorrect number of items. Expected ${this.length}, got ${items.length}.`);
            }
            return items;
        } catch (e) {
            if (Object.getPrototypeOf(e) === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["OutputParserException"].prototype) {
                throw e;
            }
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["OutputParserException"](`Could not parse output: ${text}`);
        }
    }
    /**
     * Provides instructions on the expected format of the response for the
     * CustomListOutputParser, including the number of items and the
     * separator.
     * @returns A string containing instructions on the expected format of the response.
     */ getFormatInstructions() {
        return `Your response should be a list of ${this.length === undefined ? "" : `${this.length} `}items separated by "${this.separator}" (eg: \`foo${this.separator} bar${this.separator} baz\`)`;
    }
}
class NumberedListOutputParser extends ListOutputParser {
    constructor(){
        super(...arguments);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "output_parsers",
                "list"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "re", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: /\d+\.\s([^\n]+)/g
        });
    }
    static lc_name() {
        return "NumberedListOutputParser";
    }
    getFormatInstructions() {
        return `Your response should be a numbered list with each item on a new line. For example: \n\n1. foo\n\n2. bar\n\n3. baz`;
    }
    async parse(text) {
        return [
            ...text.matchAll(this.re) ?? []
        ].map((m)=>m[1]);
    }
}
class MarkdownListOutputParser extends ListOutputParser {
    constructor(){
        super(...arguments);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "output_parsers",
                "list"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "re", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: /^\s*[-*]\s([^\n]+)$/gm
        });
    }
    static lc_name() {
        return "NumberedListOutputParser";
    }
    getFormatInstructions() {
        return `Your response should be a numbered list with each item on a new line. For example: \n\n1. foo\n\n2. bar\n\n3. baz`;
    }
    async parse(text) {
        return [
            ...text.matchAll(this.re) ?? []
        ].map((m)=>m[1]);
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/string.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "StringOutputParser": (()=>StringOutputParser)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$transform$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/transform.js [app-route] (ecmascript)");
;
class StringOutputParser extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$transform$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseTransformOutputParser"] {
    constructor(){
        super(...arguments);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "output_parsers",
                "string"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
    }
    static lc_name() {
        return "StrOutputParser";
    }
    /**
     * Parses a string output from an LLM call. This method is meant to be
     * implemented by subclasses to define how a string output from an LLM
     * should be parsed.
     * @param text The string output from an LLM call.
     * @param callbacks Optional callbacks.
     * @returns A promise of the parsed output.
     */ parse(text) {
        return Promise.resolve(text);
    }
    getFormatInstructions() {
        return "";
    }
    _textContentToString(content) {
        return content.text;
    }
    _imageUrlContentToString(_content) {
        throw new Error(`Cannot coerce a multimodal "image_url" message part into a string.`);
    }
    _messageContentComplexToString(content) {
        switch(content.type){
            case "text":
            case "text_delta":
                if ("text" in content) {
                    // Type guard for MessageContentText
                    return this._textContentToString(content);
                }
                break;
            case "image_url":
                if ("image_url" in content) {
                    // Type guard for MessageContentImageUrl
                    return this._imageUrlContentToString(content);
                }
                break;
            default:
                throw new Error(`Cannot coerce "${content.type}" message part into a string.`);
        }
        throw new Error(`Invalid content type: ${content.type}`);
    }
    _baseMessageContentToString(content) {
        return content.reduce((acc, item)=>acc + this._messageContentComplexToString(item), "");
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/structured.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "AsymmetricStructuredOutputParser": (()=>AsymmetricStructuredOutputParser),
    "JsonMarkdownStructuredOutputParser": (()=>JsonMarkdownStructuredOutputParser),
    "StructuredOutputParser": (()=>StructuredOutputParser)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$2d$to$2d$json$2d$schema$40$3$2e$24$2e$1_zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/zod-to-json-schema@3.24.1_zod@3.24.1/node_modules/zod-to-json-schema/dist/esm/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$2d$to$2d$json$2d$schema$40$3$2e$24$2e$1_zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$zodToJsonSchema$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/zod-to-json-schema@3.24.1_zod@3.24.1/node_modules/zod-to-json-schema/dist/esm/zodToJsonSchema.js [app-route] (ecmascript)");
;
;
;
class StructuredOutputParser extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseOutputParser"] {
    static lc_name() {
        return "StructuredOutputParser";
    }
    toJSON() {
        return this.toJSONNotImplemented();
    }
    constructor(schema){
        super(schema);
        Object.defineProperty(this, "schema", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: schema
        });
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain",
                "output_parsers",
                "structured"
            ]
        });
    }
    /**
     * Creates a new StructuredOutputParser from a Zod schema.
     * @param schema The Zod schema which the output should match
     * @returns A new instance of StructuredOutputParser.
     */ static fromZodSchema(schema) {
        return new this(schema);
    }
    /**
     * Creates a new StructuredOutputParser from a set of names and
     * descriptions.
     * @param schemas An object where each key is a name and each value is a description
     * @returns A new instance of StructuredOutputParser.
     */ static fromNamesAndDescriptions(schemas) {
        const zodSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object(Object.fromEntries(Object.entries(schemas).map(([name, description])=>[
                name,
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().describe(description)
            ])));
        return new this(zodSchema);
    }
    /**
     * Returns a markdown code snippet with a JSON object formatted according
     * to the schema.
     * @param options Optional. The options for formatting the instructions
     * @returns A markdown code snippet with a JSON object formatted according to the schema.
     */ getFormatInstructions() {
        return `You must format your output as a JSON value that adheres to a given "JSON Schema" instance.

"JSON Schema" is a declarative language that allows you to annotate and validate JSON documents.

For example, the example "JSON Schema" instance {{"properties": {{"foo": {{"description": "a list of test words", "type": "array", "items": {{"type": "string"}}}}}}, "required": ["foo"]}}}}
would match an object with one required property, "foo". The "type" property specifies "foo" must be an "array", and the "description" property semantically describes it as "a list of test words". The items within "foo" must be strings.
Thus, the object {{"foo": ["bar", "baz"]}} is a well-formatted instance of this example "JSON Schema". The object {{"properties": {{"foo": ["bar", "baz"]}}}} is not well-formatted.

Your output will be parsed and type-checked according to the provided schema instance, so make sure all fields in your output match the schema exactly and there are no trailing commas!

Here is the JSON Schema instance your output must adhere to. Include the enclosing markdown codeblock:
\`\`\`json
${JSON.stringify((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$2d$to$2d$json$2d$schema$40$3$2e$24$2e$1_zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$zodToJsonSchema$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["zodToJsonSchema"])(this.schema))}
\`\`\`
`;
    }
    /**
     * Parses the given text according to the schema.
     * @param text The text to parse
     * @returns The parsed output.
     */ async parse(text) {
        try {
            const json = text.includes("```") ? text.trim().split(/```(?:json)?/)[1] : text.trim();
            const escapedJson = json.replace(/"([^"\\]*(\\.[^"\\]*)*)"/g, (_match, capturedGroup)=>{
                const escapedInsideQuotes = capturedGroup.replace(/\n/g, "\\n");
                return `"${escapedInsideQuotes}"`;
            }).replace(/\n/g, "");
            return await this.schema.parseAsync(JSON.parse(escapedJson));
        } catch (e) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["OutputParserException"](`Failed to parse. Text: "${text}". Error: ${e}`, text);
        }
    }
}
class JsonMarkdownStructuredOutputParser extends StructuredOutputParser {
    static lc_name() {
        return "JsonMarkdownStructuredOutputParser";
    }
    getFormatInstructions(options) {
        const interpolationDepth = options?.interpolationDepth ?? 1;
        if (interpolationDepth < 1) {
            throw new Error("f string interpolation depth must be at least 1");
        }
        return `Return a markdown code snippet with a JSON object formatted to look like:\n\`\`\`json\n${this._schemaToInstruction((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$2d$to$2d$json$2d$schema$40$3$2e$24$2e$1_zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2d$to$2d$json$2d$schema$2f$dist$2f$esm$2f$zodToJsonSchema$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["zodToJsonSchema"])(this.schema)).replaceAll("{", "{".repeat(interpolationDepth)).replaceAll("}", "}".repeat(interpolationDepth))}\n\`\`\``;
    }
    _schemaToInstruction(schemaInput, indent = 2) {
        const schema = schemaInput;
        if ("type" in schema) {
            let nullable = false;
            let type;
            if (Array.isArray(schema.type)) {
                const nullIdx = schema.type.findIndex((type)=>type === "null");
                if (nullIdx !== -1) {
                    nullable = true;
                    schema.type.splice(nullIdx, 1);
                }
                type = schema.type.join(" | ");
            } else {
                type = schema.type;
            }
            if (schema.type === "object" && schema.properties) {
                const description = schema.description ? ` // ${schema.description}` : "";
                const properties = Object.entries(schema.properties).map(([key, value])=>{
                    const isOptional = schema.required?.includes(key) ? "" : " (optional)";
                    return `${" ".repeat(indent)}"${key}": ${this._schemaToInstruction(value, indent + 2)}${isOptional}`;
                }).join("\n");
                return `{\n${properties}\n${" ".repeat(indent - 2)}}${description}`;
            }
            if (schema.type === "array" && schema.items) {
                const description = schema.description ? ` // ${schema.description}` : "";
                return `array[\n${" ".repeat(indent)}${this._schemaToInstruction(schema.items, indent + 2)}\n${" ".repeat(indent - 2)}] ${description}`;
            }
            const isNullable = nullable ? " (nullable)" : "";
            const description = schema.description ? ` // ${schema.description}` : "";
            return `${type}${description}${isNullable}`;
        }
        if ("anyOf" in schema) {
            return schema.anyOf.map((s)=>this._schemaToInstruction(s, indent)).join(`\n${" ".repeat(indent - 2)}`);
        }
        throw new Error("unsupported schema type");
    }
    static fromZodSchema(schema) {
        return new this(schema);
    }
    static fromNamesAndDescriptions(schemas) {
        const zodSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object(Object.fromEntries(Object.entries(schemas).map(([name, description])=>[
                name,
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$24$2e$1$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().describe(description)
            ])));
        return new this(zodSchema);
    }
}
class AsymmetricStructuredOutputParser extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseOutputParser"] {
    constructor({ inputSchema }){
        super(...arguments);
        Object.defineProperty(this, "structuredInputParser", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.structuredInputParser = new JsonMarkdownStructuredOutputParser(inputSchema);
    }
    async parse(text) {
        let parsedInput;
        try {
            parsedInput = await this.structuredInputParser.parse(text);
        } catch (e) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["OutputParserException"](`Failed to parse. Text: "${text}". Error: ${e}`, text);
        }
        return this.outputProcessor(parsedInput);
    }
    getFormatInstructions() {
        return this.structuredInputParser.getFormatInstructions();
    }
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/json_patch.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/json_patch.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$json_patch$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/json_patch.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/json.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "JsonOutputParser": (()=>JsonOutputParser)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$duplex$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/duplex.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$json$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/json.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$transform$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/transform.js [app-route] (ecmascript)");
;
;
;
class JsonOutputParser extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$transform$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseCumulativeTransformOutputParser"] {
    constructor(){
        super(...arguments);
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "output_parsers"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
    }
    static lc_name() {
        return "JsonOutputParser";
    }
    _diff(prev, next) {
        if (!next) {
            return undefined;
        }
        if (!prev) {
            return [
                {
                    op: "replace",
                    path: "",
                    value: next
                }
            ];
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$duplex$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["compare"])(prev, next);
    }
    // This should actually return Partial<T>, but there's no way
    // to specify emitted chunks as instances separate from the main output type.
    async parsePartialResult(generations) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$json$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseJsonMarkdown"])(generations[0].text);
    }
    async parse(text) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$json$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseJsonMarkdown"])(text, JSON.parse);
    }
    getFormatInstructions() {
        return "";
    }
}
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/json.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$transform$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/transform.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$json_patch$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/json_patch.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$json$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/json.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$json$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/json.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/sax-js/sax.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// @ts-nocheck
// Inlined to deal with portability issues
// Originally from: https://github.com/isaacs/sax-js
__turbopack_esm__({
    "sax": (()=>sax)
});
const initializeSax = function() {
    const sax = {};
    sax.parser = function(strict, opt) {
        return new SAXParser(strict, opt);
    };
    sax.SAXParser = SAXParser;
    sax.SAXStream = SAXStream;
    sax.createStream = createStream;
    // When we pass the MAX_BUFFER_LENGTH position, start checking for buffer overruns.
    // When we check, schedule the next check for MAX_BUFFER_LENGTH - (max(buffer lengths)),
    // since that's the earliest that a buffer overrun could occur.  This way, checks are
    // as rare as required, but as often as necessary to ensure never crossing this bound.
    // Furthermore, buffers are only tested at most once per write(), so passing a very
    // large string into write() might have undesirable effects, but this is manageable by
    // the caller, so it is assumed to be safe.  Thus, a call to write() may, in the extreme
    // edge case, result in creating at most one complete copy of the string passed in.
    // Set to Infinity to have unlimited buffers.
    sax.MAX_BUFFER_LENGTH = 64 * 1024;
    const buffers = [
        "comment",
        "sgmlDecl",
        "textNode",
        "tagName",
        "doctype",
        "procInstName",
        "procInstBody",
        "entity",
        "attribName",
        "attribValue",
        "cdata",
        "script"
    ];
    sax.EVENTS = [
        "text",
        "processinginstruction",
        "sgmldeclaration",
        "doctype",
        "comment",
        "opentagstart",
        "attribute",
        "opentag",
        "closetag",
        "opencdata",
        "cdata",
        "closecdata",
        "error",
        "end",
        "ready",
        "script",
        "opennamespace",
        "closenamespace"
    ];
    function SAXParser(strict, opt) {
        if (!(this instanceof SAXParser)) {
            return new SAXParser(strict, opt);
        }
        var parser = this;
        clearBuffers(parser);
        parser.q = parser.c = "";
        parser.bufferCheckPosition = sax.MAX_BUFFER_LENGTH;
        parser.opt = opt || {};
        parser.opt.lowercase = parser.opt.lowercase || parser.opt.lowercasetags;
        parser.looseCase = parser.opt.lowercase ? "toLowerCase" : "toUpperCase";
        parser.tags = [];
        parser.closed = parser.closedRoot = parser.sawRoot = false;
        parser.tag = parser.error = null;
        parser.strict = !!strict;
        parser.noscript = !!(strict || parser.opt.noscript);
        parser.state = S.BEGIN;
        parser.strictEntities = parser.opt.strictEntities;
        parser.ENTITIES = parser.strictEntities ? Object.create(sax.XML_ENTITIES) : Object.create(sax.ENTITIES);
        parser.attribList = [];
        // namespaces form a prototype chain.
        // it always points at the current tag,
        // which protos to its parent tag.
        if (parser.opt.xmlns) {
            parser.ns = Object.create(rootNS);
        }
        // mostly just for error reporting
        parser.trackPosition = parser.opt.position !== false;
        if (parser.trackPosition) {
            parser.position = parser.line = parser.column = 0;
        }
        emit(parser, "onready");
    }
    if (!Object.create) {
        Object.create = function(o) {
            function F() {}
            F.prototype = o;
            var newf = new F();
            return newf;
        };
    }
    if (!Object.keys) {
        Object.keys = function(o) {
            var a = [];
            for(var i in o)if (o.hasOwnProperty(i)) a.push(i);
            return a;
        };
    }
    function checkBufferLength(parser) {
        var maxAllowed = Math.max(sax.MAX_BUFFER_LENGTH, 10);
        var maxActual = 0;
        for(var i = 0, l = buffers.length; i < l; i++){
            var len = parser[buffers[i]].length;
            if (len > maxAllowed) {
                // Text/cdata nodes can get big, and since they're buffered,
                // we can get here under normal conditions.
                // Avoid issues by emitting the text node now,
                // so at least it won't get any bigger.
                switch(buffers[i]){
                    case "textNode":
                        closeText(parser);
                        break;
                    case "cdata":
                        emitNode(parser, "oncdata", parser.cdata);
                        parser.cdata = "";
                        break;
                    case "script":
                        emitNode(parser, "onscript", parser.script);
                        parser.script = "";
                        break;
                    default:
                        error(parser, "Max buffer length exceeded: " + buffers[i]);
                }
            }
            maxActual = Math.max(maxActual, len);
        }
        // schedule the next check for the earliest possible buffer overrun.
        var m = sax.MAX_BUFFER_LENGTH - maxActual;
        parser.bufferCheckPosition = m + parser.position;
    }
    function clearBuffers(parser) {
        for(var i = 0, l = buffers.length; i < l; i++){
            parser[buffers[i]] = "";
        }
    }
    function flushBuffers(parser) {
        closeText(parser);
        if (parser.cdata !== "") {
            emitNode(parser, "oncdata", parser.cdata);
            parser.cdata = "";
        }
        if (parser.script !== "") {
            emitNode(parser, "onscript", parser.script);
            parser.script = "";
        }
    }
    SAXParser.prototype = {
        end: function() {
            end(this);
        },
        write: write,
        resume: function() {
            this.error = null;
            return this;
        },
        close: function() {
            return this.write(null);
        },
        flush: function() {
            flushBuffers(this);
        }
    };
    var Stream = ReadableStream;
    if (!Stream) Stream = function() {};
    var streamWraps = sax.EVENTS.filter(function(ev) {
        return ev !== "error" && ev !== "end";
    });
    function createStream(strict, opt) {
        return new SAXStream(strict, opt);
    }
    function SAXStream(strict, opt) {
        if (!(this instanceof SAXStream)) {
            return new SAXStream(strict, opt);
        }
        Stream.apply(this);
        this._parser = new SAXParser(strict, opt);
        this.writable = true;
        this.readable = true;
        var me = this;
        this._parser.onend = function() {
            me.emit("end");
        };
        this._parser.onerror = function(er) {
            me.emit("error", er);
            // if didn't throw, then means error was handled.
            // go ahead and clear error, so we can write again.
            me._parser.error = null;
        };
        this._decoder = null;
        streamWraps.forEach(function(ev) {
            Object.defineProperty(me, "on" + ev, {
                get: function() {
                    return me._parser["on" + ev];
                },
                set: function(h) {
                    if (!h) {
                        me.removeAllListeners(ev);
                        me._parser["on" + ev] = h;
                        return h;
                    }
                    me.on(ev, h);
                },
                enumerable: true,
                configurable: false
            });
        });
    }
    SAXStream.prototype = Object.create(Stream.prototype, {
        constructor: {
            value: SAXStream
        }
    });
    SAXStream.prototype.write = function(data) {
        this._parser.write(data.toString());
        this.emit("data", data);
        return true;
    };
    SAXStream.prototype.end = function(chunk) {
        if (chunk && chunk.length) {
            this.write(chunk);
        }
        this._parser.end();
        return true;
    };
    SAXStream.prototype.on = function(ev, handler) {
        var me = this;
        if (!me._parser["on" + ev] && streamWraps.indexOf(ev) !== -1) {
            me._parser["on" + ev] = function() {
                var args = arguments.length === 1 ? [
                    arguments[0]
                ] : Array.apply(null, arguments);
                args.splice(0, 0, ev);
                me.emit.apply(me, args);
            };
        }
        return Stream.prototype.on.call(me, ev, handler);
    };
    // this really needs to be replaced with character classes.
    // XML allows all manner of ridiculous numbers and digits.
    var CDATA = "[CDATA[";
    var DOCTYPE = "DOCTYPE";
    var XML_NAMESPACE = "http://www.w3.org/XML/1998/namespace";
    var XMLNS_NAMESPACE = "http://www.w3.org/2000/xmlns/";
    var rootNS = {
        xml: XML_NAMESPACE,
        xmlns: XMLNS_NAMESPACE
    };
    // http://www.w3.org/TR/REC-xml/#NT-NameStartChar
    // This implementation works on strings, a single character at a time
    // as such, it cannot ever support astral-plane characters (10000-EFFFF)
    // without a significant breaking change to either this  parser, or the
    // JavaScript language.  Implementation of an emoji-capable xml parser
    // is left as an exercise for the reader.
    var nameStart = /[:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/;
    var nameBody = /[:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u00B7\u0300-\u036F\u203F-\u2040.\d-]/;
    var entityStart = /[#:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/;
    var entityBody = /[#:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u00B7\u0300-\u036F\u203F-\u2040.\d-]/;
    function isWhitespace(c) {
        return c === " " || c === "\n" || c === "\r" || c === "\t";
    }
    function isQuote(c) {
        return c === '"' || c === "'";
    }
    function isAttribEnd(c) {
        return c === ">" || isWhitespace(c);
    }
    function isMatch(regex, c) {
        return regex.test(c);
    }
    function notMatch(regex, c) {
        return !isMatch(regex, c);
    }
    var S = 0;
    sax.STATE = {
        BEGIN: S++,
        BEGIN_WHITESPACE: S++,
        TEXT: S++,
        TEXT_ENTITY: S++,
        OPEN_WAKA: S++,
        SGML_DECL: S++,
        SGML_DECL_QUOTED: S++,
        DOCTYPE: S++,
        DOCTYPE_QUOTED: S++,
        DOCTYPE_DTD: S++,
        DOCTYPE_DTD_QUOTED: S++,
        COMMENT_STARTING: S++,
        COMMENT: S++,
        COMMENT_ENDING: S++,
        COMMENT_ENDED: S++,
        CDATA: S++,
        CDATA_ENDING: S++,
        CDATA_ENDING_2: S++,
        PROC_INST: S++,
        PROC_INST_BODY: S++,
        PROC_INST_ENDING: S++,
        OPEN_TAG: S++,
        OPEN_TAG_SLASH: S++,
        ATTRIB: S++,
        ATTRIB_NAME: S++,
        ATTRIB_NAME_SAW_WHITE: S++,
        ATTRIB_VALUE: S++,
        ATTRIB_VALUE_QUOTED: S++,
        ATTRIB_VALUE_CLOSED: S++,
        ATTRIB_VALUE_UNQUOTED: S++,
        ATTRIB_VALUE_ENTITY_Q: S++,
        ATTRIB_VALUE_ENTITY_U: S++,
        CLOSE_TAG: S++,
        CLOSE_TAG_SAW_WHITE: S++,
        SCRIPT: S++,
        SCRIPT_ENDING: S++
    };
    sax.XML_ENTITIES = {
        amp: "&",
        gt: ">",
        lt: "<",
        quot: '"',
        apos: "'"
    };
    sax.ENTITIES = {
        amp: "&",
        gt: ">",
        lt: "<",
        quot: '"',
        apos: "'",
        AElig: 198,
        Aacute: 193,
        Acirc: 194,
        Agrave: 192,
        Aring: 197,
        Atilde: 195,
        Auml: 196,
        Ccedil: 199,
        ETH: 208,
        Eacute: 201,
        Ecirc: 202,
        Egrave: 200,
        Euml: 203,
        Iacute: 205,
        Icirc: 206,
        Igrave: 204,
        Iuml: 207,
        Ntilde: 209,
        Oacute: 211,
        Ocirc: 212,
        Ograve: 210,
        Oslash: 216,
        Otilde: 213,
        Ouml: 214,
        THORN: 222,
        Uacute: 218,
        Ucirc: 219,
        Ugrave: 217,
        Uuml: 220,
        Yacute: 221,
        aacute: 225,
        acirc: 226,
        aelig: 230,
        agrave: 224,
        aring: 229,
        atilde: 227,
        auml: 228,
        ccedil: 231,
        eacute: 233,
        ecirc: 234,
        egrave: 232,
        eth: 240,
        euml: 235,
        iacute: 237,
        icirc: 238,
        igrave: 236,
        iuml: 239,
        ntilde: 241,
        oacute: 243,
        ocirc: 244,
        ograve: 242,
        oslash: 248,
        otilde: 245,
        ouml: 246,
        szlig: 223,
        thorn: 254,
        uacute: 250,
        ucirc: 251,
        ugrave: 249,
        uuml: 252,
        yacute: 253,
        yuml: 255,
        copy: 169,
        reg: 174,
        nbsp: 160,
        iexcl: 161,
        cent: 162,
        pound: 163,
        curren: 164,
        yen: 165,
        brvbar: 166,
        sect: 167,
        uml: 168,
        ordf: 170,
        laquo: 171,
        not: 172,
        shy: 173,
        macr: 175,
        deg: 176,
        plusmn: 177,
        sup1: 185,
        sup2: 178,
        sup3: 179,
        acute: 180,
        micro: 181,
        para: 182,
        middot: 183,
        cedil: 184,
        ordm: 186,
        raquo: 187,
        frac14: 188,
        frac12: 189,
        frac34: 190,
        iquest: 191,
        times: 215,
        divide: 247,
        OElig: 338,
        oelig: 339,
        Scaron: 352,
        scaron: 353,
        Yuml: 376,
        fnof: 402,
        circ: 710,
        tilde: 732,
        Alpha: 913,
        Beta: 914,
        Gamma: 915,
        Delta: 916,
        Epsilon: 917,
        Zeta: 918,
        Eta: 919,
        Theta: 920,
        Iota: 921,
        Kappa: 922,
        Lambda: 923,
        Mu: 924,
        Nu: 925,
        Xi: 926,
        Omicron: 927,
        Pi: 928,
        Rho: 929,
        Sigma: 931,
        Tau: 932,
        Upsilon: 933,
        Phi: 934,
        Chi: 935,
        Psi: 936,
        Omega: 937,
        alpha: 945,
        beta: 946,
        gamma: 947,
        delta: 948,
        epsilon: 949,
        zeta: 950,
        eta: 951,
        theta: 952,
        iota: 953,
        kappa: 954,
        lambda: 955,
        mu: 956,
        nu: 957,
        xi: 958,
        omicron: 959,
        pi: 960,
        rho: 961,
        sigmaf: 962,
        sigma: 963,
        tau: 964,
        upsilon: 965,
        phi: 966,
        chi: 967,
        psi: 968,
        omega: 969,
        thetasym: 977,
        upsih: 978,
        piv: 982,
        ensp: 8194,
        emsp: 8195,
        thinsp: 8201,
        zwnj: 8204,
        zwj: 8205,
        lrm: 8206,
        rlm: 8207,
        ndash: 8211,
        mdash: 8212,
        lsquo: 8216,
        rsquo: 8217,
        sbquo: 8218,
        ldquo: 8220,
        rdquo: 8221,
        bdquo: 8222,
        dagger: 8224,
        Dagger: 8225,
        bull: 8226,
        hellip: 8230,
        permil: 8240,
        prime: 8242,
        Prime: 8243,
        lsaquo: 8249,
        rsaquo: 8250,
        oline: 8254,
        frasl: 8260,
        euro: 8364,
        image: 8465,
        weierp: 8472,
        real: 8476,
        trade: 8482,
        alefsym: 8501,
        larr: 8592,
        uarr: 8593,
        rarr: 8594,
        darr: 8595,
        harr: 8596,
        crarr: 8629,
        lArr: 8656,
        uArr: 8657,
        rArr: 8658,
        dArr: 8659,
        hArr: 8660,
        forall: 8704,
        part: 8706,
        exist: 8707,
        empty: 8709,
        nabla: 8711,
        isin: 8712,
        notin: 8713,
        ni: 8715,
        prod: 8719,
        sum: 8721,
        minus: 8722,
        lowast: 8727,
        radic: 8730,
        prop: 8733,
        infin: 8734,
        ang: 8736,
        and: 8743,
        or: 8744,
        cap: 8745,
        cup: 8746,
        int: 8747,
        there4: 8756,
        sim: 8764,
        cong: 8773,
        asymp: 8776,
        ne: 8800,
        equiv: 8801,
        le: 8804,
        ge: 8805,
        sub: 8834,
        sup: 8835,
        nsub: 8836,
        sube: 8838,
        supe: 8839,
        oplus: 8853,
        otimes: 8855,
        perp: 8869,
        sdot: 8901,
        lceil: 8968,
        rceil: 8969,
        lfloor: 8970,
        rfloor: 8971,
        lang: 9001,
        rang: 9002,
        loz: 9674,
        spades: 9824,
        clubs: 9827,
        hearts: 9829,
        diams: 9830
    };
    Object.keys(sax.ENTITIES).forEach(function(key) {
        var e = sax.ENTITIES[key];
        var s = typeof e === "number" ? String.fromCharCode(e) : e;
        sax.ENTITIES[key] = s;
    });
    for(var s in sax.STATE){
        sax.STATE[sax.STATE[s]] = s;
    }
    // shorthand
    S = sax.STATE;
    function emit(parser, event, data) {
        parser[event] && parser[event](data);
    }
    function emitNode(parser, nodeType, data) {
        if (parser.textNode) closeText(parser);
        emit(parser, nodeType, data);
    }
    function closeText(parser) {
        parser.textNode = textopts(parser.opt, parser.textNode);
        if (parser.textNode) emit(parser, "ontext", parser.textNode);
        parser.textNode = "";
    }
    function textopts(opt, text) {
        if (opt.trim) text = text.trim();
        if (opt.normalize) text = text.replace(/\s+/g, " ");
        return text;
    }
    function error(parser, er) {
        closeText(parser);
        if (parser.trackPosition) {
            er += "\nLine: " + parser.line + "\nColumn: " + parser.column + "\nChar: " + parser.c;
        }
        er = new Error(er);
        parser.error = er;
        emit(parser, "onerror", er);
        return parser;
    }
    function end(parser) {
        if (parser.sawRoot && !parser.closedRoot) strictFail(parser, "Unclosed root tag");
        if (parser.state !== S.BEGIN && parser.state !== S.BEGIN_WHITESPACE && parser.state !== S.TEXT) {
            error(parser, "Unexpected end");
        }
        closeText(parser);
        parser.c = "";
        parser.closed = true;
        emit(parser, "onend");
        SAXParser.call(parser, parser.strict, parser.opt);
        return parser;
    }
    function strictFail(parser, message) {
        if (typeof parser !== "object" || !(parser instanceof SAXParser)) {
            throw new Error("bad call to strictFail");
        }
        if (parser.strict) {
            error(parser, message);
        }
    }
    function newTag(parser) {
        if (!parser.strict) parser.tagName = parser.tagName[parser.looseCase]();
        var parent = parser.tags[parser.tags.length - 1] || parser;
        var tag = parser.tag = {
            name: parser.tagName,
            attributes: {}
        };
        // will be overridden if tag contails an xmlns="foo" or xmlns:foo="bar"
        if (parser.opt.xmlns) {
            tag.ns = parent.ns;
        }
        parser.attribList.length = 0;
        emitNode(parser, "onopentagstart", tag);
    }
    function qname(name, attribute) {
        var i = name.indexOf(":");
        var qualName = i < 0 ? [
            "",
            name
        ] : name.split(":");
        var prefix = qualName[0];
        var local = qualName[1];
        // <x "xmlns"="http://foo">
        if (attribute && name === "xmlns") {
            prefix = "xmlns";
            local = "";
        }
        return {
            prefix: prefix,
            local: local
        };
    }
    function attrib(parser) {
        if (!parser.strict) {
            parser.attribName = parser.attribName[parser.looseCase]();
        }
        if (parser.attribList.indexOf(parser.attribName) !== -1 || parser.tag.attributes.hasOwnProperty(parser.attribName)) {
            parser.attribName = parser.attribValue = "";
            return;
        }
        if (parser.opt.xmlns) {
            var qn = qname(parser.attribName, true);
            var prefix = qn.prefix;
            var local = qn.local;
            if (prefix === "xmlns") {
                // namespace binding attribute. push the binding into scope
                if (local === "xml" && parser.attribValue !== XML_NAMESPACE) {
                    strictFail(parser, "xml: prefix must be bound to " + XML_NAMESPACE + "\n" + "Actual: " + parser.attribValue);
                } else if (local === "xmlns" && parser.attribValue !== XMLNS_NAMESPACE) {
                    strictFail(parser, "xmlns: prefix must be bound to " + XMLNS_NAMESPACE + "\n" + "Actual: " + parser.attribValue);
                } else {
                    var tag = parser.tag;
                    var parent = parser.tags[parser.tags.length - 1] || parser;
                    if (tag.ns === parent.ns) {
                        tag.ns = Object.create(parent.ns);
                    }
                    tag.ns[local] = parser.attribValue;
                }
            }
            // defer onattribute events until all attributes have been seen
            // so any new bindings can take effect. preserve attribute order
            // so deferred events can be emitted in document order
            parser.attribList.push([
                parser.attribName,
                parser.attribValue
            ]);
        } else {
            // in non-xmlns mode, we can emit the event right away
            parser.tag.attributes[parser.attribName] = parser.attribValue;
            emitNode(parser, "onattribute", {
                name: parser.attribName,
                value: parser.attribValue
            });
        }
        parser.attribName = parser.attribValue = "";
    }
    function openTag(parser, selfClosing) {
        if (parser.opt.xmlns) {
            // emit namespace binding events
            var tag = parser.tag;
            // add namespace info to tag
            var qn = qname(parser.tagName);
            tag.prefix = qn.prefix;
            tag.local = qn.local;
            tag.uri = tag.ns[qn.prefix] || "";
            if (tag.prefix && !tag.uri) {
                strictFail(parser, "Unbound namespace prefix: " + JSON.stringify(parser.tagName));
                tag.uri = qn.prefix;
            }
            var parent = parser.tags[parser.tags.length - 1] || parser;
            if (tag.ns && parent.ns !== tag.ns) {
                Object.keys(tag.ns).forEach(function(p) {
                    emitNode(parser, "onopennamespace", {
                        prefix: p,
                        uri: tag.ns[p]
                    });
                });
            }
            // handle deferred onattribute events
            // Note: do not apply default ns to attributes:
            //   http://www.w3.org/TR/REC-xml-names/#defaulting
            for(var i = 0, l = parser.attribList.length; i < l; i++){
                var nv = parser.attribList[i];
                var name = nv[0];
                var value = nv[1];
                var qualName = qname(name, true);
                var prefix = qualName.prefix;
                var local = qualName.local;
                var uri = prefix === "" ? "" : tag.ns[prefix] || "";
                var a = {
                    name: name,
                    value: value,
                    prefix: prefix,
                    local: local,
                    uri: uri
                };
                // if there's any attributes with an undefined namespace,
                // then fail on them now.
                if (prefix && prefix !== "xmlns" && !uri) {
                    strictFail(parser, "Unbound namespace prefix: " + JSON.stringify(prefix));
                    a.uri = prefix;
                }
                parser.tag.attributes[name] = a;
                emitNode(parser, "onattribute", a);
            }
            parser.attribList.length = 0;
        }
        parser.tag.isSelfClosing = !!selfClosing;
        // process the tag
        parser.sawRoot = true;
        parser.tags.push(parser.tag);
        emitNode(parser, "onopentag", parser.tag);
        if (!selfClosing) {
            // special case for <script> in non-strict mode.
            if (!parser.noscript && parser.tagName.toLowerCase() === "script") {
                parser.state = S.SCRIPT;
            } else {
                parser.state = S.TEXT;
            }
            parser.tag = null;
            parser.tagName = "";
        }
        parser.attribName = parser.attribValue = "";
        parser.attribList.length = 0;
    }
    function closeTag(parser) {
        if (!parser.tagName) {
            strictFail(parser, "Weird empty close tag.");
            parser.textNode += "</>";
            parser.state = S.TEXT;
            return;
        }
        if (parser.script) {
            if (parser.tagName !== "script") {
                parser.script += "</" + parser.tagName + ">";
                parser.tagName = "";
                parser.state = S.SCRIPT;
                return;
            }
            emitNode(parser, "onscript", parser.script);
            parser.script = "";
        }
        // first make sure that the closing tag actually exists.
        // <a><b></c></b></a> will close everything, otherwise.
        var t = parser.tags.length;
        var tagName = parser.tagName;
        if (!parser.strict) {
            tagName = tagName[parser.looseCase]();
        }
        var closeTo = tagName;
        while(t--){
            var close = parser.tags[t];
            if (close.name !== closeTo) {
                // fail the first time in strict mode
                strictFail(parser, "Unexpected close tag");
            } else {
                break;
            }
        }
        // didn't find it.  we already failed for strict, so just abort.
        if (t < 0) {
            strictFail(parser, "Unmatched closing tag: " + parser.tagName);
            parser.textNode += "</" + parser.tagName + ">";
            parser.state = S.TEXT;
            return;
        }
        parser.tagName = tagName;
        var s = parser.tags.length;
        while(s-- > t){
            var tag = parser.tag = parser.tags.pop();
            parser.tagName = parser.tag.name;
            emitNode(parser, "onclosetag", parser.tagName);
            var x = {};
            for(var i in tag.ns){
                x[i] = tag.ns[i];
            }
            var parent = parser.tags[parser.tags.length - 1] || parser;
            if (parser.opt.xmlns && tag.ns !== parent.ns) {
                // remove namespace bindings introduced by tag
                Object.keys(tag.ns).forEach(function(p) {
                    var n = tag.ns[p];
                    emitNode(parser, "onclosenamespace", {
                        prefix: p,
                        uri: n
                    });
                });
            }
        }
        if (t === 0) parser.closedRoot = true;
        parser.tagName = parser.attribValue = parser.attribName = "";
        parser.attribList.length = 0;
        parser.state = S.TEXT;
    }
    function parseEntity(parser) {
        var entity = parser.entity;
        var entityLC = entity.toLowerCase();
        var num;
        var numStr = "";
        if (parser.ENTITIES[entity]) {
            return parser.ENTITIES[entity];
        }
        if (parser.ENTITIES[entityLC]) {
            return parser.ENTITIES[entityLC];
        }
        entity = entityLC;
        if (entity.charAt(0) === "#") {
            if (entity.charAt(1) === "x") {
                entity = entity.slice(2);
                num = parseInt(entity, 16);
                numStr = num.toString(16);
            } else {
                entity = entity.slice(1);
                num = parseInt(entity, 10);
                numStr = num.toString(10);
            }
        }
        entity = entity.replace(/^0+/, "");
        if (isNaN(num) || numStr.toLowerCase() !== entity) {
            strictFail(parser, "Invalid character entity");
            return "&" + parser.entity + ";";
        }
        return String.fromCodePoint(num);
    }
    function beginWhiteSpace(parser, c) {
        if (c === "<") {
            parser.state = S.OPEN_WAKA;
            parser.startTagPosition = parser.position;
        } else if (!isWhitespace(c)) {
            // have to process this as a text node.
            // weird, but happens.
            strictFail(parser, "Non-whitespace before first tag.");
            parser.textNode = c;
            parser.state = S.TEXT;
        }
    }
    function charAt(chunk, i) {
        var result = "";
        if (i < chunk.length) {
            result = chunk.charAt(i);
        }
        return result;
    }
    function write(chunk) {
        var parser = this;
        if (this.error) {
            throw this.error;
        }
        if (parser.closed) {
            return error(parser, "Cannot write after close. Assign an onready handler.");
        }
        if (chunk === null) {
            return end(parser);
        }
        if (typeof chunk === "object") {
            chunk = chunk.toString();
        }
        var i = 0;
        var c = "";
        while(true){
            c = charAt(chunk, i++);
            parser.c = c;
            if (!c) {
                break;
            }
            if (parser.trackPosition) {
                parser.position++;
                if (c === "\n") {
                    parser.line++;
                    parser.column = 0;
                } else {
                    parser.column++;
                }
            }
            switch(parser.state){
                case S.BEGIN:
                    parser.state = S.BEGIN_WHITESPACE;
                    if (c === "\uFEFF") {
                        continue;
                    }
                    beginWhiteSpace(parser, c);
                    continue;
                case S.BEGIN_WHITESPACE:
                    beginWhiteSpace(parser, c);
                    continue;
                case S.TEXT:
                    if (parser.sawRoot && !parser.closedRoot) {
                        var starti = i - 1;
                        while(c && c !== "<" && c !== "&"){
                            c = charAt(chunk, i++);
                            if (c && parser.trackPosition) {
                                parser.position++;
                                if (c === "\n") {
                                    parser.line++;
                                    parser.column = 0;
                                } else {
                                    parser.column++;
                                }
                            }
                        }
                        parser.textNode += chunk.substring(starti, i - 1);
                    }
                    if (c === "<" && !(parser.sawRoot && parser.closedRoot && !parser.strict)) {
                        parser.state = S.OPEN_WAKA;
                        parser.startTagPosition = parser.position;
                    } else {
                        if (!isWhitespace(c) && (!parser.sawRoot || parser.closedRoot)) {
                            strictFail(parser, "Text data outside of root node.");
                        }
                        if (c === "&") {
                            parser.state = S.TEXT_ENTITY;
                        } else {
                            parser.textNode += c;
                        }
                    }
                    continue;
                case S.SCRIPT:
                    // only non-strict
                    if (c === "<") {
                        parser.state = S.SCRIPT_ENDING;
                    } else {
                        parser.script += c;
                    }
                    continue;
                case S.SCRIPT_ENDING:
                    if (c === "/") {
                        parser.state = S.CLOSE_TAG;
                    } else {
                        parser.script += "<" + c;
                        parser.state = S.SCRIPT;
                    }
                    continue;
                case S.OPEN_WAKA:
                    // either a /, ?, !, or text is coming next.
                    if (c === "!") {
                        parser.state = S.SGML_DECL;
                        parser.sgmlDecl = "";
                    } else if (isWhitespace(c)) {
                    // wait for it...
                    } else if (isMatch(nameStart, c)) {
                        parser.state = S.OPEN_TAG;
                        parser.tagName = c;
                    } else if (c === "/") {
                        parser.state = S.CLOSE_TAG;
                        parser.tagName = "";
                    } else if (c === "?") {
                        parser.state = S.PROC_INST;
                        parser.procInstName = parser.procInstBody = "";
                    } else {
                        strictFail(parser, "Unencoded <");
                        // if there was some whitespace, then add that in.
                        if (parser.startTagPosition + 1 < parser.position) {
                            var pad = parser.position - parser.startTagPosition;
                            c = new Array(pad).join(" ") + c;
                        }
                        parser.textNode += "<" + c;
                        parser.state = S.TEXT;
                    }
                    continue;
                case S.SGML_DECL:
                    if ((parser.sgmlDecl + c).toUpperCase() === CDATA) {
                        emitNode(parser, "onopencdata");
                        parser.state = S.CDATA;
                        parser.sgmlDecl = "";
                        parser.cdata = "";
                    } else if (parser.sgmlDecl + c === "--") {
                        parser.state = S.COMMENT;
                        parser.comment = "";
                        parser.sgmlDecl = "";
                    } else if ((parser.sgmlDecl + c).toUpperCase() === DOCTYPE) {
                        parser.state = S.DOCTYPE;
                        if (parser.doctype || parser.sawRoot) {
                            strictFail(parser, "Inappropriately located doctype declaration");
                        }
                        parser.doctype = "";
                        parser.sgmlDecl = "";
                    } else if (c === ">") {
                        emitNode(parser, "onsgmldeclaration", parser.sgmlDecl);
                        parser.sgmlDecl = "";
                        parser.state = S.TEXT;
                    } else if (isQuote(c)) {
                        parser.state = S.SGML_DECL_QUOTED;
                        parser.sgmlDecl += c;
                    } else {
                        parser.sgmlDecl += c;
                    }
                    continue;
                case S.SGML_DECL_QUOTED:
                    if (c === parser.q) {
                        parser.state = S.SGML_DECL;
                        parser.q = "";
                    }
                    parser.sgmlDecl += c;
                    continue;
                case S.DOCTYPE:
                    if (c === ">") {
                        parser.state = S.TEXT;
                        emitNode(parser, "ondoctype", parser.doctype);
                        parser.doctype = true; // just remember that we saw it.
                    } else {
                        parser.doctype += c;
                        if (c === "[") {
                            parser.state = S.DOCTYPE_DTD;
                        } else if (isQuote(c)) {
                            parser.state = S.DOCTYPE_QUOTED;
                            parser.q = c;
                        }
                    }
                    continue;
                case S.DOCTYPE_QUOTED:
                    parser.doctype += c;
                    if (c === parser.q) {
                        parser.q = "";
                        parser.state = S.DOCTYPE;
                    }
                    continue;
                case S.DOCTYPE_DTD:
                    parser.doctype += c;
                    if (c === "]") {
                        parser.state = S.DOCTYPE;
                    } else if (isQuote(c)) {
                        parser.state = S.DOCTYPE_DTD_QUOTED;
                        parser.q = c;
                    }
                    continue;
                case S.DOCTYPE_DTD_QUOTED:
                    parser.doctype += c;
                    if (c === parser.q) {
                        parser.state = S.DOCTYPE_DTD;
                        parser.q = "";
                    }
                    continue;
                case S.COMMENT:
                    if (c === "-") {
                        parser.state = S.COMMENT_ENDING;
                    } else {
                        parser.comment += c;
                    }
                    continue;
                case S.COMMENT_ENDING:
                    if (c === "-") {
                        parser.state = S.COMMENT_ENDED;
                        parser.comment = textopts(parser.opt, parser.comment);
                        if (parser.comment) {
                            emitNode(parser, "oncomment", parser.comment);
                        }
                        parser.comment = "";
                    } else {
                        parser.comment += "-" + c;
                        parser.state = S.COMMENT;
                    }
                    continue;
                case S.COMMENT_ENDED:
                    if (c !== ">") {
                        strictFail(parser, "Malformed comment");
                        // allow <!-- blah -- bloo --> in non-strict mode,
                        // which is a comment of " blah -- bloo "
                        parser.comment += "--" + c;
                        parser.state = S.COMMENT;
                    } else {
                        parser.state = S.TEXT;
                    }
                    continue;
                case S.CDATA:
                    if (c === "]") {
                        parser.state = S.CDATA_ENDING;
                    } else {
                        parser.cdata += c;
                    }
                    continue;
                case S.CDATA_ENDING:
                    if (c === "]") {
                        parser.state = S.CDATA_ENDING_2;
                    } else {
                        parser.cdata += "]" + c;
                        parser.state = S.CDATA;
                    }
                    continue;
                case S.CDATA_ENDING_2:
                    if (c === ">") {
                        if (parser.cdata) {
                            emitNode(parser, "oncdata", parser.cdata);
                        }
                        emitNode(parser, "onclosecdata");
                        parser.cdata = "";
                        parser.state = S.TEXT;
                    } else if (c === "]") {
                        parser.cdata += "]";
                    } else {
                        parser.cdata += "]]" + c;
                        parser.state = S.CDATA;
                    }
                    continue;
                case S.PROC_INST:
                    if (c === "?") {
                        parser.state = S.PROC_INST_ENDING;
                    } else if (isWhitespace(c)) {
                        parser.state = S.PROC_INST_BODY;
                    } else {
                        parser.procInstName += c;
                    }
                    continue;
                case S.PROC_INST_BODY:
                    if (!parser.procInstBody && isWhitespace(c)) {
                        continue;
                    } else if (c === "?") {
                        parser.state = S.PROC_INST_ENDING;
                    } else {
                        parser.procInstBody += c;
                    }
                    continue;
                case S.PROC_INST_ENDING:
                    if (c === ">") {
                        emitNode(parser, "onprocessinginstruction", {
                            name: parser.procInstName,
                            body: parser.procInstBody
                        });
                        parser.procInstName = parser.procInstBody = "";
                        parser.state = S.TEXT;
                    } else {
                        parser.procInstBody += "?" + c;
                        parser.state = S.PROC_INST_BODY;
                    }
                    continue;
                case S.OPEN_TAG:
                    if (isMatch(nameBody, c)) {
                        parser.tagName += c;
                    } else {
                        newTag(parser);
                        if (c === ">") {
                            openTag(parser);
                        } else if (c === "/") {
                            parser.state = S.OPEN_TAG_SLASH;
                        } else {
                            if (!isWhitespace(c)) {
                                strictFail(parser, "Invalid character in tag name");
                            }
                            parser.state = S.ATTRIB;
                        }
                    }
                    continue;
                case S.OPEN_TAG_SLASH:
                    if (c === ">") {
                        openTag(parser, true);
                        closeTag(parser);
                    } else {
                        strictFail(parser, "Forward-slash in opening tag not followed by >");
                        parser.state = S.ATTRIB;
                    }
                    continue;
                case S.ATTRIB:
                    // haven't read the attribute name yet.
                    if (isWhitespace(c)) {
                        continue;
                    } else if (c === ">") {
                        openTag(parser);
                    } else if (c === "/") {
                        parser.state = S.OPEN_TAG_SLASH;
                    } else if (isMatch(nameStart, c)) {
                        parser.attribName = c;
                        parser.attribValue = "";
                        parser.state = S.ATTRIB_NAME;
                    } else {
                        strictFail(parser, "Invalid attribute name");
                    }
                    continue;
                case S.ATTRIB_NAME:
                    if (c === "=") {
                        parser.state = S.ATTRIB_VALUE;
                    } else if (c === ">") {
                        strictFail(parser, "Attribute without value");
                        parser.attribValue = parser.attribName;
                        attrib(parser);
                        openTag(parser);
                    } else if (isWhitespace(c)) {
                        parser.state = S.ATTRIB_NAME_SAW_WHITE;
                    } else if (isMatch(nameBody, c)) {
                        parser.attribName += c;
                    } else {
                        strictFail(parser, "Invalid attribute name");
                    }
                    continue;
                case S.ATTRIB_NAME_SAW_WHITE:
                    if (c === "=") {
                        parser.state = S.ATTRIB_VALUE;
                    } else if (isWhitespace(c)) {
                        continue;
                    } else {
                        strictFail(parser, "Attribute without value");
                        parser.tag.attributes[parser.attribName] = "";
                        parser.attribValue = "";
                        emitNode(parser, "onattribute", {
                            name: parser.attribName,
                            value: ""
                        });
                        parser.attribName = "";
                        if (c === ">") {
                            openTag(parser);
                        } else if (isMatch(nameStart, c)) {
                            parser.attribName = c;
                            parser.state = S.ATTRIB_NAME;
                        } else {
                            strictFail(parser, "Invalid attribute name");
                            parser.state = S.ATTRIB;
                        }
                    }
                    continue;
                case S.ATTRIB_VALUE:
                    if (isWhitespace(c)) {
                        continue;
                    } else if (isQuote(c)) {
                        parser.q = c;
                        parser.state = S.ATTRIB_VALUE_QUOTED;
                    } else {
                        strictFail(parser, "Unquoted attribute value");
                        parser.state = S.ATTRIB_VALUE_UNQUOTED;
                        parser.attribValue = c;
                    }
                    continue;
                case S.ATTRIB_VALUE_QUOTED:
                    if (c !== parser.q) {
                        if (c === "&") {
                            parser.state = S.ATTRIB_VALUE_ENTITY_Q;
                        } else {
                            parser.attribValue += c;
                        }
                        continue;
                    }
                    attrib(parser);
                    parser.q = "";
                    parser.state = S.ATTRIB_VALUE_CLOSED;
                    continue;
                case S.ATTRIB_VALUE_CLOSED:
                    if (isWhitespace(c)) {
                        parser.state = S.ATTRIB;
                    } else if (c === ">") {
                        openTag(parser);
                    } else if (c === "/") {
                        parser.state = S.OPEN_TAG_SLASH;
                    } else if (isMatch(nameStart, c)) {
                        strictFail(parser, "No whitespace between attributes");
                        parser.attribName = c;
                        parser.attribValue = "";
                        parser.state = S.ATTRIB_NAME;
                    } else {
                        strictFail(parser, "Invalid attribute name");
                    }
                    continue;
                case S.ATTRIB_VALUE_UNQUOTED:
                    if (!isAttribEnd(c)) {
                        if (c === "&") {
                            parser.state = S.ATTRIB_VALUE_ENTITY_U;
                        } else {
                            parser.attribValue += c;
                        }
                        continue;
                    }
                    attrib(parser);
                    if (c === ">") {
                        openTag(parser);
                    } else {
                        parser.state = S.ATTRIB;
                    }
                    continue;
                case S.CLOSE_TAG:
                    if (!parser.tagName) {
                        if (isWhitespace(c)) {
                            continue;
                        } else if (notMatch(nameStart, c)) {
                            if (parser.script) {
                                parser.script += "</" + c;
                                parser.state = S.SCRIPT;
                            } else {
                                strictFail(parser, "Invalid tagname in closing tag.");
                            }
                        } else {
                            parser.tagName = c;
                        }
                    } else if (c === ">") {
                        closeTag(parser);
                    } else if (isMatch(nameBody, c)) {
                        parser.tagName += c;
                    } else if (parser.script) {
                        parser.script += "</" + parser.tagName;
                        parser.tagName = "";
                        parser.state = S.SCRIPT;
                    } else {
                        if (!isWhitespace(c)) {
                            strictFail(parser, "Invalid tagname in closing tag");
                        }
                        parser.state = S.CLOSE_TAG_SAW_WHITE;
                    }
                    continue;
                case S.CLOSE_TAG_SAW_WHITE:
                    if (isWhitespace(c)) {
                        continue;
                    }
                    if (c === ">") {
                        closeTag(parser);
                    } else {
                        strictFail(parser, "Invalid characters in closing tag");
                    }
                    continue;
                case S.TEXT_ENTITY:
                case S.ATTRIB_VALUE_ENTITY_Q:
                case S.ATTRIB_VALUE_ENTITY_U:
                    var returnState;
                    var buffer;
                    switch(parser.state){
                        case S.TEXT_ENTITY:
                            returnState = S.TEXT;
                            buffer = "textNode";
                            break;
                        case S.ATTRIB_VALUE_ENTITY_Q:
                            returnState = S.ATTRIB_VALUE_QUOTED;
                            buffer = "attribValue";
                            break;
                        case S.ATTRIB_VALUE_ENTITY_U:
                            returnState = S.ATTRIB_VALUE_UNQUOTED;
                            buffer = "attribValue";
                            break;
                    }
                    if (c === ";") {
                        if (parser.opt.unparsedEntities) {
                            var parsedEntity = parseEntity(parser);
                            parser.entity = "";
                            parser.state = returnState;
                            parser.write(parsedEntity);
                        } else {
                            parser[buffer] += parseEntity(parser);
                            parser.entity = "";
                            parser.state = returnState;
                        }
                    } else if (isMatch(parser.entity.length ? entityBody : entityStart, c)) {
                        parser.entity += c;
                    } else {
                        strictFail(parser, "Invalid character in entity name");
                        parser[buffer] += "&" + parser.entity + c;
                        parser.entity = "";
                        parser.state = returnState;
                    }
                    continue;
                default:
                    /* istanbul ignore next */ {
                        throw new Error(parser, "Unknown state: " + parser.state);
                    }
            }
        } // while
        if (parser.position >= parser.bufferCheckPosition) {
            checkBufferLength(parser);
        }
        return parser;
    }
    /*! http://mths.be/fromcodepoint v0.1.0 by @mathias */ /* istanbul ignore next */ if (!String.fromCodePoint) {
        (function() {
            var stringFromCharCode = String.fromCharCode;
            var floor = Math.floor;
            var fromCodePoint = function() {
                var MAX_SIZE = 0x4000;
                var codeUnits = [];
                var highSurrogate;
                var lowSurrogate;
                var index = -1;
                var length = arguments.length;
                if (!length) {
                    return "";
                }
                var result = "";
                while(++index < length){
                    var codePoint = Number(arguments[index]);
                    if (!isFinite(codePoint) || // `NaN`, `+Infinity`, or `-Infinity`
                    codePoint < 0 || // not a valid Unicode code point
                    codePoint > 0x10ffff || // not a valid Unicode code point
                    floor(codePoint) !== codePoint // not an integer
                    ) {
                        throw RangeError("Invalid code point: " + codePoint);
                    }
                    if (codePoint <= 0xffff) {
                        // BMP code point
                        codeUnits.push(codePoint);
                    } else {
                        // Astral code point; split in surrogate halves
                        // http://mathiasbynens.be/notes/javascript-encoding#surrogate-formulae
                        codePoint -= 0x10000;
                        highSurrogate = (codePoint >> 10) + 0xd800;
                        lowSurrogate = codePoint % 0x400 + 0xdc00;
                        codeUnits.push(highSurrogate, lowSurrogate);
                    }
                    if (index + 1 === length || codeUnits.length > MAX_SIZE) {
                        result += stringFromCharCode.apply(null, codeUnits);
                        codeUnits.length = 0;
                    }
                }
                return result;
            };
            /* istanbul ignore next */ if (Object.defineProperty) {
                Object.defineProperty(String, "fromCodePoint", {
                    value: fromCodePoint,
                    configurable: true,
                    writable: true
                });
            } else {
                String.fromCodePoint = fromCodePoint;
            }
        })();
    }
    return sax;
};
const sax = /** #__PURE__ */ initializeSax();
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/xml.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "XMLOutputParser": (()=>XMLOutputParser),
    "XML_FORMAT_INSTRUCTIONS": (()=>XML_FORMAT_INSTRUCTIONS),
    "parseXMLMarkdown": (()=>parseXMLMarkdown)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$transform$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/transform.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$json_patch$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/json_patch.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$sax$2d$js$2f$sax$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/sax-js/sax.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$duplex$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/utils/fast-json-patch/src/duplex.js [app-route] (ecmascript)");
;
;
;
const XML_FORMAT_INSTRUCTIONS = `The output should be formatted as a XML file.
1. Output should conform to the tags below. 
2. If tags are not given, make them on your own.
3. Remember to always open and close all the tags.

As an example, for the tags ["foo", "bar", "baz"]:
1. String "<foo>\n   <bar>\n      <baz></baz>\n   </bar>\n</foo>" is a well-formatted instance of the schema. 
2. String "<foo>\n   <bar>\n   </foo>" is a badly-formatted instance.
3. String "<foo>\n   <tag>\n   </tag>\n</foo>" is a badly-formatted instance.

Here are the output tags:
\`\`\`
{tags}
\`\`\``;
class XMLOutputParser extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$transform$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BaseCumulativeTransformOutputParser"] {
    constructor(fields){
        super(fields);
        Object.defineProperty(this, "tags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "lc_namespace", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: [
                "langchain_core",
                "output_parsers"
            ]
        });
        Object.defineProperty(this, "lc_serializable", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        this.tags = fields?.tags;
    }
    static lc_name() {
        return "XMLOutputParser";
    }
    _diff(prev, next) {
        if (!next) {
            return undefined;
        }
        if (!prev) {
            return [
                {
                    op: "replace",
                    path: "",
                    value: next
                }
            ];
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$fast$2d$json$2d$patch$2f$src$2f$duplex$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["compare"])(prev, next);
    }
    async parsePartialResult(generations) {
        return parseXMLMarkdown(generations[0].text);
    }
    async parse(text) {
        return parseXMLMarkdown(text);
    }
    getFormatInstructions() {
        const withTags = !!(this.tags && this.tags.length > 0);
        return withTags ? XML_FORMAT_INSTRUCTIONS.replace("{tags}", this.tags?.join(", ") ?? "") : XML_FORMAT_INSTRUCTIONS;
    }
}
const strip = (text)=>text.split("\n").map((line)=>line.replace(/^\s+/, "")).join("\n").trim();
const parseParsedResult = (input)=>{
    if (Object.keys(input).length === 0) {
        return {};
    }
    const result = {};
    if (input.children.length > 0) {
        result[input.name] = input.children.map(parseParsedResult);
        return result;
    } else {
        result[input.name] = input.text ?? undefined;
        return result;
    }
};
function parseXMLMarkdown(s) {
    const cleanedString = strip(s);
    const parser = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$utils$2f$sax$2d$js$2f$sax$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sax"].parser(true);
    let parsedResult = {};
    const elementStack = [];
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    parser.onopentag = (node)=>{
        const element = {
            name: node.name,
            attributes: node.attributes,
            children: [],
            text: "",
            isSelfClosing: node.isSelfClosing
        };
        if (elementStack.length > 0) {
            const parentElement = elementStack[elementStack.length - 1];
            parentElement.children.push(element);
        } else {
            parsedResult = element;
        }
        if (!node.isSelfClosing) {
            elementStack.push(element);
        }
    };
    parser.onclosetag = ()=>{
        if (elementStack.length > 0) {
            const lastElement = elementStack.pop();
            if (elementStack.length === 0 && lastElement) {
                parsedResult = lastElement;
            }
        }
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    parser.ontext = (text)=>{
        if (elementStack.length > 0) {
            const currentElement = elementStack[elementStack.length - 1];
            currentElement.text += text;
        }
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    parser.onattribute = (attr)=>{
        if (elementStack.length > 0) {
            const currentElement = elementStack[elementStack.length - 1];
            currentElement.attributes[attr.name] = attr.value;
        }
    };
    // Try to find XML string within triple backticks.
    const match = /```(xml)?(.*)```/s.exec(cleanedString);
    const xmlString = match ? match[2] : cleanedString;
    parser.write(xmlString).close();
    // Remove the XML declaration if present
    if (parsedResult && parsedResult.name === "?xml") {
        parsedResult = parsedResult.children[0];
    }
    return parseParsedResult(parsedResult);
}
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/index.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
;
;
;
;
;
;
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/index.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$base$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/base.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$bytes$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/bytes.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$list$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/list.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$string$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/string.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$structured$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/structured.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$transform$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/transform.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$json$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/json.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$xml$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/xml.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/index.js [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/output_parsers.js [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
;
}}),
"[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/output_parsers.js [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$dist$2f$output_parsers$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/dist/output_parsers/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$langchain$2b$core$40$0$2e$3$2e$30_openai$40$4$2e$79$2e$0_encoding$40$0$2e$1$2e$13_ws$40$8$2e$18$2e$0_bufferutil$40$4$2e$0$2e$9_utf$2d$8$2d$validate$40$5$2e$0$2e$10_$5f$zod$40$3$2e$24$2e$1_$2f$node_modules$2f40$langchain$2f$core$2f$output_parsers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1_/node_modules/@langchain/core/output_parsers.js [app-route] (ecmascript) <locals>");
}}),

};

//# sourceMappingURL=89241_%40langchain_core_edd3c2._.js.map
module.exports = {

"[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/lib/themes.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.attachTheme = void 0;
const bs58_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bs58@5.0.0/node_modules/bs58/index.js [app-rsc] (ecmascript)"));
const createObscureThemeId = (themeId)=>{
    return bs58_1.default.encode(Buffer.from(`theme|${themeId}`));
};
const attachTheme = (tiplink, themeId)=>{
    if (!themeId) {
        return tiplink;
    }
    const obscureThemeId = createObscureThemeId(themeId);
    tiplink.url.searchParams.append("t", obscureThemeId);
    tiplink.url.pathname = "/ti";
    return tiplink;
};
exports.attachTheme = attachTheme;
}}),
"[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/crypto.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.encodeUTF8 = exports.decodeUTF8 = exports.decryptDataUsingDH = exports.decryptMessage = exports.encryptMessage = exports.generateNonce = exports.decryptPrivateKey = exports.encryptPublicKey = exports.generatePublicPrivateKey = exports.decrypt = exports.encrypt = exports.generateKey = exports.generateRandomSalt = exports.DEFAULT_TIPLINK_KEYLENGTH = void 0;
const tweetnacl_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/tweetnacl@1.0.3/node_modules/tweetnacl/nacl-fast.js [app-rsc] (ecmascript)"));
const tweetnacl_util_1 = __turbopack_require__("[project]/node_modules/.pnpm/tweetnacl-util@0.15.1/node_modules/tweetnacl-util/nacl-util.js [app-rsc] (ecmascript)");
Object.defineProperty(exports, "decodeUTF8", {
    enumerable: true,
    get: function() {
        return tweetnacl_util_1.decodeUTF8;
    }
});
Object.defineProperty(exports, "encodeUTF8", {
    enumerable: true,
    get: function() {
        return tweetnacl_util_1.encodeUTF8;
    }
});
exports.DEFAULT_TIPLINK_KEYLENGTH = 12;
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
const crypto = crypto_1.webcrypto;
const bs58_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bs58@5.0.0/node_modules/bs58/index.js [app-rsc] (ecmascript)"));
/*
  Convert a string into an ArrayBuffer
  from https://developers.google.com/web/updates/2012/06/How-to-convert-ArrayBuffer-to-and-from-String
*/ function stringToArrayBuffer(str) {
    const buf = new ArrayBuffer(str.length);
    const bufView = new Uint8Array(buf);
    for(let i = 0, strLen = str.length; i < strLen; i++){
        bufView[i] = str.charCodeAt(i);
    }
    return buf;
}
// Crypto encrypting links in db and apikeys
const KEY_LENGTH_BYTES = 256;
const SALT_LENGTH_BYTES = 12;
const MODULUS_LENGTH = 4096;
const DIGEST_ALGO = "SHA-512";
const HASH_ALGO = "AES-GCM"; // Alternatives 'AES-CTR' 'AES-CBC' 'AES-GCM'
const HASH_ALGO_WTIH_PUBLIC_PRIVATE = "RSA-OAEP";
const EXPORT_HASH_ALGO = "A256GCM";
// const EXPORT_PUBLIC_PRIVATE_ALGO = "RSA-OAEP-512";
const EXPORT_FORMAT = "jwk";
const EXPORT_PUBLIC_FORMAT = "spki";
const EXPORT_PRIVATE_FORMAT = "pkcs8";
const generateRandomSalt = ()=>{
    return Buffer.from(crypto.getRandomValues(new Uint8Array(SALT_LENGTH_BYTES))).toString("hex");
};
exports.generateRandomSalt = generateRandomSalt;
const generateKey = ()=>__awaiter(void 0, void 0, void 0, function*() {
        const key = yield crypto.subtle.generateKey({
            name: HASH_ALGO,
            length: KEY_LENGTH_BYTES
        }, true, [
            "encrypt",
            "decrypt"
        ]);
        // @ts-ignore
        return exportKey(key);
    });
exports.generateKey = generateKey;
const exportKey = (key)=>__awaiter(void 0, void 0, void 0, function*() {
        // @ts-ignore
        const exportableKey = yield crypto.subtle.exportKey(EXPORT_FORMAT, key);
        // if (exportableKey.alg === EXPORT_HASH_ALGO) {
        if (exportableKey.k === undefined) {
            throw Error("Export Key Error");
        }
        return exportableKey.k;
    // }
    });
const importKey = (key)=>{
    const jwkKey = {
        alg: EXPORT_HASH_ALGO,
        k: key,
        ext: true,
        key_ops: [
            "encrypt",
            "decrypt"
        ],
        kty: "oct"
    };
    return crypto.subtle.importKey("jwk", jwkKey, {
        name: HASH_ALGO,
        length: KEY_LENGTH_BYTES
    }, true, [
        "encrypt",
        "decrypt"
    ]);
};
const encrypt = (data, key, salt)=>__awaiter(void 0, void 0, void 0, function*() {
        const ec = new TextEncoder();
        const iv = Uint8Array.from(Buffer.from(salt, "hex"));
        const encKey = yield importKey(key);
        const ciphertext = yield crypto.subtle.encrypt({
            name: HASH_ALGO,
            iv: iv
        }, encKey, ec.encode(data));
        return Buffer.from(ciphertext).toString("hex");
    });
exports.encrypt = encrypt;
const decrypt = (data, key, salt)=>__awaiter(void 0, void 0, void 0, function*() {
        const ciphertext = Uint8Array.from(Buffer.from(data, "hex"));
        const iv = Uint8Array.from(Buffer.from(salt, "hex"));
        const decKey = yield importKey(key);
        const dec = new TextDecoder();
        const plaintext = yield crypto.subtle.decrypt({
            name: HASH_ALGO,
            iv: iv
        }, decKey, ciphertext);
        return dec.decode(plaintext);
    });
exports.decrypt = decrypt;
const generatePublicPrivateKey = ()=>__awaiter(void 0, void 0, void 0, function*() {
        const { publicKey, privateKey } = yield crypto.subtle.generateKey({
            name: HASH_ALGO_WTIH_PUBLIC_PRIVATE,
            modulusLength: MODULUS_LENGTH,
            publicExponent: new Uint8Array([
                1,
                0,
                1
            ]),
            hash: DIGEST_ALGO
        }, true, [
            "encrypt",
            "decrypt"
        ]);
        return {
            // @ts-ignore
            publicKey: yield exportPublicKey(publicKey),
            // @ts-ignore
            privateKey: yield exportPrivateKey(privateKey)
        };
    });
exports.generatePublicPrivateKey = generatePublicPrivateKey;
const exportPublicKey = (publicKey)=>__awaiter(void 0, void 0, void 0, function*() {
        // @ts-ignore
        const exportableKey = yield crypto.subtle.exportKey(EXPORT_PUBLIC_FORMAT, publicKey);
        // TODO type check this?
        return btoa(// @ts-ignore
        String.fromCharCode.apply(null, new Uint8Array(exportableKey)));
    // return Buffer.from(exportableKey).toString('hex');
    });
const importPublicKey = (publicKey)=>__awaiter(void 0, void 0, void 0, function*() {
        // const arrBuf = Uint8Array.from(Buffer.from(publicKey, 'hex'));
        const arrBuf = stringToArrayBuffer(atob(publicKey));
        return crypto.subtle.importKey(EXPORT_PUBLIC_FORMAT, arrBuf, {
            name: HASH_ALGO_WTIH_PUBLIC_PRIVATE,
            // modulusLength: MODULUS_LENGTH,
            // publicExponent: new Uint8Array([1, 0, 1]),
            hash: DIGEST_ALGO
        }, true, [
            "encrypt"
        ]);
    });
const exportPrivateKey = (privateKey)=>__awaiter(void 0, void 0, void 0, function*() {
        // @ts-ignore
        const exportableKey = yield crypto.subtle.exportKey(EXPORT_PRIVATE_FORMAT, privateKey);
        // TODO type check this?
        return btoa(// @ts-ignore
        String.fromCharCode.apply(null, new Uint8Array(exportableKey)));
    // return Buffer.from(exportableKey).toString('hex');
    });
const importPrivateKey = (privateKey)=>__awaiter(void 0, void 0, void 0, function*() {
        const arrBuf = stringToArrayBuffer(atob(privateKey));
        return crypto.subtle.importKey(EXPORT_PRIVATE_FORMAT, arrBuf, {
            name: HASH_ALGO_WTIH_PUBLIC_PRIVATE,
            // modulusLength: MODULUS_LENGTH,
            // publicExponent: new Uint8Array([1, 0, 1]),
            hash: DIGEST_ALGO
        }, true, [
            "decrypt"
        ]);
    });
const encryptPublicKey = (data, publicKey)=>__awaiter(void 0, void 0, void 0, function*() {
        const ec = new TextEncoder();
        const encKey = yield importPublicKey(publicKey);
        const ciphertext = yield crypto.subtle.encrypt({
            name: HASH_ALGO_WTIH_PUBLIC_PRIVATE
        }, encKey, ec.encode(data));
        return Buffer.from(ciphertext).toString("hex");
    });
exports.encryptPublicKey = encryptPublicKey;
const decryptPrivateKey = (data, privateKey)=>__awaiter(void 0, void 0, void 0, function*() {
        const ciphertext = Uint8Array.from(Buffer.from(data, "hex"));
        const decKey = yield importPrivateKey(privateKey);
        const dec = new TextDecoder();
        const plaintext = yield crypto.subtle.decrypt({
            name: HASH_ALGO_WTIH_PUBLIC_PRIVATE
        }, decKey, ciphertext);
        return dec.decode(plaintext);
    });
exports.decryptPrivateKey = decryptPrivateKey;
const generateNonce = ()=>__awaiter(void 0, void 0, void 0, function*() {
        return Buffer.from(tweetnacl_1.default.randomBytes(24)).toString("hex");
    });
exports.generateNonce = generateNonce;
const encryptMessage = (keypair, nonce, message)=>__awaiter(void 0, void 0, void 0, function*() {
        const nonceArray = Uint8Array.from(Buffer.from(nonce, "hex"));
        return tweetnacl_1.default.secretbox((0, tweetnacl_util_1.decodeUTF8)(message), nonceArray, keypair.secretKey.slice(32));
    });
exports.encryptMessage = encryptMessage;
const decryptMessage = (keypair, nonce, encryptedMessage)=>__awaiter(void 0, void 0, void 0, function*() {
        const nonceArray = Uint8Array.from(Buffer.from(nonce, "hex"));
        const encryptedMessageArray = Uint8Array.from(Buffer.from(encryptedMessage, "hex"));
        // const encryptedMessageArray = stringToArrayBuffer(window.atob(encryptedMessage));
        const res = tweetnacl_1.default.secretbox.open(encryptedMessageArray, nonceArray, keypair.secretKey.slice(32));
        if (res === null) {
            return "";
        } else {
            return (0, tweetnacl_util_1.encodeUTF8)(res);
        }
    });
exports.decryptMessage = decryptMessage;
// encrypted using symmetric key encryption generated from a Diffie-Hellman key exchange
// https://en.wikipedia.org/wiki/Diffie%E2%80%93Hellman_key_exchange'
// export const encryptDataUsingDH = (
//   dataToEncrypt: { [key: string]: any },
//   recipientEncryptionPubKey: Uint8Array | string // bs58 encoded string or nacl box public key (not solana keypair)
// ) => {
//   // nacl box keypair (not solana wallet keypair)
//   const keypair = nacl.box.keyPair();
//   const nonce = nacl.randomBytes(24);
//   const dataBuffer = Buffer.from(JSON.stringify(dataToEncrypt));
//   const recipientPubKey =
//     typeof recipientEncryptionPubKey === "string"
//       ? bs58.decode(recipientEncryptionPubKey)
//       : recipientEncryptionPubKey;
//   const encryptedData = nacl.box(
//     dataBuffer,
//     nonce,
//     recipientPubKey,
//     keypair.secretKey
//   );
//   return {
//     nonceUint8Arr: nonce,
//     nonceBs58: bs58.encode(nonce),
//     encryptedDataUint8Arr: encryptedData,
//     encryptedDataBs58: bs58.encode(encryptedData),
//     encryptionKeypairToHold: keypair,
//   };
// };
const decryptDataUsingDH = (dataToDecrypt, nonce, senderEncryptionPubKey, encryptionKeypair)=>{
    const encryptedData = typeof dataToDecrypt === "string" ? bs58_1.default.decode(dataToDecrypt) : dataToDecrypt;
    const encryptionNonce = typeof nonce == "string" ? bs58_1.default.decode(nonce) : nonce;
    const senderPubKey = typeof senderEncryptionPubKey === "string" ? bs58_1.default.decode(senderEncryptionPubKey) : senderEncryptionPubKey;
    const decryptedData = tweetnacl_1.default.box.open(encryptedData, encryptionNonce, senderPubKey, encryptionKeypair.secretKey);
    if (!decryptedData) return;
    const decryptonDataJson = JSON.parse(Buffer.from(decryptedData).toString("utf8"));
    // json.parse returns "any" typed json so ok to silence eslint error
    // eslint-disable-next-line @typescript-eslint/no-unsafe-return
    return decryptonDataJson;
};
exports.decryptDataUsingDH = decryptDataUsingDH;
}}),
"[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/client.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Mint = exports.DataHost = exports.Dispenser = exports.Campaign = exports.TipLinkClient = exports.ON_CHAIN_SYMBOL_CHAR_LIMIT = exports.ON_CHAIN_NAME_CHAR_LIMIT = exports.decrypt = void 0;
const nanoid_1 = __turbopack_require__("[project]/node_modules/.pnpm/nanoid@3.3.8/node_modules/nanoid/index.cjs [app-rsc] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-rsc] (ecmascript)");
const index_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/index.js [app-rsc] (ecmascript)");
const themes_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/lib/themes.js [app-rsc] (ecmascript)");
const crypto_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/crypto.js [app-rsc] (ecmascript)");
Object.defineProperty(exports, "decrypt", {
    enumerable: true,
    get: function() {
        return crypto_1.decrypt;
    }
});
exports.ON_CHAIN_NAME_CHAR_LIMIT = 32;
exports.ON_CHAIN_SYMBOL_CHAR_LIMIT = 10;
const URL_BASE = index_1.TIPLINK_ORIGIN;
const API_URL_BASE = `${URL_BASE}/api`;
const STEP = 100;
// TODO harmonize constants with main
const FAUCET_ID_LENGTH = 12;
class TipLinkClient {
    constructor(apiKey, version = 1){
        this.apiKey = apiKey;
        this.version = version;
        this.campaigns = new CampaignActions({
            client: this
        });
        this.mints = new MintActions({
            client: this
        });
    }
    static init(apiKey, version = 1) {
        return __awaiter(this, void 0, void 0, function*() {
            const client = new TipLinkClient(apiKey, version);
            try {
                const apiKeyRes = yield client.fetch("api_key");
                client.id = apiKeyRes["account"]["id"];
                client.publicKey = apiKeyRes["account"]["public_key"];
            } catch (err) {
                throw Error("Api_key error: retriving account public_key encryption info");
            }
            return client;
        });
    }
    // TODO type return?
    fetch(endpoint, args = null, body = null, verb = "GET") {
        return __awaiter(this, void 0, void 0, function*() {
            const url = new URL(endpoint, `${API_URL_BASE}/v${this.version}/`);
            if (args !== null) {
                Object.entries(args).forEach(([key, value])=>{
                    url.searchParams.append(key, value);
                });
            }
            const params = {
                method: verb,
                headers: {
                    Authorization: `Bearer ${this.apiKey}`
                }
            };
            if (body !== null) {
                if (body instanceof FormData) {
                    params.body = body;
                } else {
                    // json body
                    params.headers["Content-Type"] = "application/json";
                    params.body = JSON.stringify(body);
                }
            }
            try {
                const result = yield fetch(url.toString(), params);
                return yield result.json();
            } catch (err) {
                console.error(err);
                // TODO how should we handle errors
                throw Error(`Api Fetch Error: ${verb} ${endpoint}`);
            }
        });
    }
}
exports.TipLinkClient = TipLinkClient;
class TipLinkApi {
    constructor(client){
        this.client = client;
    }
}
// TODO better typing with prisma across repo or should we just not include all event types?
var EventType;
(function(EventType) {
    EventType["CREATED"] = "CREATED";
    EventType["ACCESSED"] = "ACCESSED";
    EventType["CLAIMED"] = "CLAIMED";
    EventType["CLAIMED_BACK"] = "CLAIMED_BACK";
})(EventType || (EventType = {}));
var Rate;
(function(Rate) {
    Rate[Rate["DAILY"] = 0] = "DAILY";
    Rate[Rate["WEEKLY"] = 1] = "WEEKLY";
    Rate[Rate["MONTHLY"] = 2] = "MONTHLY";
    Rate[Rate["YEARLY"] = 3] = "YEARLY";
    Rate[Rate["FOREVER"] = 4] = "FOREVER";
    Rate[Rate["MILLISECOND"] = 5] = "MILLISECOND";
})(Rate || (Rate = {}));
class CampaignActions extends TipLinkApi {
    constructor(params){
        super(params.client);
    }
    create(params) {
        return __awaiter(this, void 0, void 0, function*() {
            const name = typeof params != "undefined" && typeof params.name != "undefined" ? params.name : "";
            const description = typeof params != "undefined" && typeof params.description != "undefined" ? params.description : "";
            const imageUrl = typeof params != "undefined" && typeof params.imageUrl != "undefined" ? params.imageUrl : "";
            const active = typeof params != "undefined" && typeof params.active != "undefined" ? params.active : true;
            const themeId = typeof params != "undefined" && typeof params.themeId != "undefined" ? params.themeId : null;
            const salt = (0, crypto_1.generateRandomSalt)();
            const ck = yield (0, crypto_1.generateKey)();
            const campaignData = {
                name: name,
                description: description,
                encryption_salt: salt,
                image_url: imageUrl,
                active: active,
                theme_id: themeId
            };
            const res = yield this.client.fetch("campaigns", null, campaignData, "POST");
            const campaign = new Campaign({
                client: this.client,
                id: res["id"],
                name: res["name"],
                description: res["description"],
                imageUrl: res["image_url"],
                active: res["active"],
                themeId: res["theme_id"]
            });
            if (typeof this.client.publicKey === "undefined") {
                // TODO should we handle this differently
                throw "Unable to do server handshake with encryption key";
            } else {
                const encryptedCampaignKey = yield (0, crypto_1.encryptPublicKey)(ck, this.client.publicKey);
                const keyData = {
                    campaign_id: campaign.id,
                    account_id: this.client.id,
                    is_owner: true,
                    encrypted_campaign_key: encryptedCampaignKey
                };
                yield this.client.fetch(`campaigns/${campaign.id}/campaign_account_joins`, null, keyData, "POST");
                if (salt !== res["encryption_salt"]) {
                    console.error("encryption salt mismatch");
                }
                campaign.encryptionKey = ck;
            }
            campaign.encryptionSalt = res["encryption_salt"];
            return campaign;
        });
    }
    find(params) {
        return __awaiter(this, void 0, void 0, function*() {
            const findParams = Object.assign(Object.assign({}, params), {
                limit: 1,
                sorting: "-created_at"
            });
            const res = (yield this.client.fetch("campaigns", findParams, null, "GET"))[0];
            const campaign = new Campaign({
                client: this.client,
                id: res["id"],
                name: res["name"],
                description: res["description"],
                imageUrl: res["image_url"],
                active: res["active"]
            });
            campaign.encryptionSalt = res["encryption_salt"];
            console.warn("unable to acquire decryption key");
            // const encryptedKeyRes = await this.client.fetch(`campaigns/${campaign.id}/campaign_account_joins`);
            // // TODO figure out how api keys will do key exchange / sharing to get privateKey
            // const decryptedCampaignKey = await decryptPrivateKey(
            // encryptedKeyRes.encrypted_campaign_key,
            // privateKey
            // );
            // campaign.encryptionKey = decryptedCampaignKey;
            return campaign;
        });
    }
    all(params) {
        return __awaiter(this, void 0, void 0, function*() {
            const filterParams = Object.assign({}, params);
            const campaignResults = yield this.client.fetch("campaigns", filterParams, null, "GET");
            const campaigns = campaignResults.map((res)=>{
                const campaign = new Campaign({
                    client: this.client,
                    id: res["id"],
                    name: res["name"],
                    description: res["description"],
                    imageUrl: res["image_url"],
                    active: res["active"]
                });
                campaign.encryptionSalt = res["encryption_salt"];
                console.warn("unable to acquire decryption key");
                // const encryptedKeyRes = await this.client.fetch(`campaigns/${campaign.id}/campaign_account_joins`);
                // // TODO figure out how api keys will do key exchange / sharing to get privateKey
                // const decryptedCampaignKey = await decryptPrivateKey(
                // encryptedKeyRes.encrypted_campaign_key,
                // privateKey
                // );
                // campaign.encryptionKey = decryptedCampaignKey;
                return campaign;
            });
            return campaigns;
        });
    }
}
class Campaign extends TipLinkApi {
    constructor(params){
        super(params.client);
        this.id = params.id;
        this.name = params.name;
        this.description = params.description;
        this.imageUrl = params.imageUrl;
        this.active = params.active;
        this.themeId = params.themeId;
        this.dispensers = new DispenserActions({
            client: this.client,
            campaign: this
        });
    }
    addEntries(tiplinks) {
        return __awaiter(this, void 0, void 0, function*() {
            const tiplinkToCampaignEntry = (tiplink)=>__awaiter(this, void 0, void 0, function*() {
                    if (!this.encryptionKey || !this.encryptionSalt) {
                        throw "No Encryption Key Set";
                    }
                    const encryptedLink = yield (0, crypto_1.encrypt)(tiplink.url.toString(), this.encryptionKey, this.encryptionSalt);
                    const publicKey = tiplink.keypair.publicKey.toString();
                    const result = {
                        public_key: publicKey,
                        encrypted_link: encryptedLink,
                        funding_txn: "funded"
                    };
                    return result;
                });
            while(tiplinks.length){
                const entries = yield Promise.all(tiplinks.splice(-1 * STEP).map(tiplinkToCampaignEntry));
                yield this.client.fetch(`campaigns/${this.id}/campaign_entries`, null, entries, "POST");
                const analytics = entries.map((entry)=>{
                    return {
                        event: "CREATED",
                        public_key: entry.public_key
                    };
                });
                yield this.client.fetch("analytics", null, analytics, "POST");
            }
            return true;
        });
    }
    hideEntries(tiplinks) {
        return __awaiter(this, void 0, void 0, function*() {
            const publicKeys = tiplinks.map((tp)=>tp instanceof index_1.TipLink ? tp.keypair.publicKey : tp);
            const entries = {
                publicKeys,
                funding_txn: ""
            };
            yield this.client.fetch(`campaigns/${this.id}/campaign_entries`, null, entries, "PUT");
            const analytics = publicKeys.map((pk)=>{
                return {
                    event: "FUNDING_FAILED",
                    public_key: pk
                };
            });
            yield this.client.fetch("analytics", null, analytics, "POST");
            return true;
        });
    }
    getEntries(params) {
        return __awaiter(this, void 0, void 0, function*() {
            const entryToTipLink = (entry)=>__awaiter(this, void 0, void 0, function*() {
                    if (typeof this.encryptionKey == "undefined" || typeof this.encryptionSalt == "undefined") {
                        console.warn("No Decryption Key: Unable to decrypt entries");
                        return null;
                    }
                    let link = "";
                    if (entry.encrypted_link !== null) {
                        link = yield (0, crypto_1.decrypt)(entry.encrypted_link, this.encryptionKey, this.encryptionSalt);
                        const tl = (0, themes_1.attachTheme)((yield index_1.TipLink.fromLink(link)), this.themeId);
                        return tl;
                    }
                    return null;
                });
            const resEntries = yield this.client.fetch(`campaigns/${this.id}/campaign_entries`, params);
            let entries = [];
            while(resEntries.length){
                const entry = yield Promise.all(resEntries.splice(-1 * STEP).map(entryToTipLink));
                entries = entries.concat(entry);
            }
            // TODO include analytics? and id give whole entry object?
            return entries;
        });
    }
    getAnalytic(publicKey) {
        return __awaiter(this, void 0, void 0, function*() {
            const analyticsRes = yield this.client.fetch(`campaigns/${this.id}/analytics`, {
                public_key: publicKey
            });
            let analytic = null;
            analyticsRes.forEach((res)=>{
                // TODO should we display most recent created_at in category?
                if (res.event == "CLAIMED" || res.event == "TRANSFERED" || res.event == "RECREATED" || res.event == "WITHDRAWN") {
                    analytic = {
                        public_key: new web3_js_1.PublicKey(res.public_key),
                        event: EventType.CLAIMED,
                        created_at: new Date(res.created_at)
                    };
                } else if (res.event == "CLAIMED_BACK" && (!analytic || analytic.event !== EventType.CLAIMED)) {
                    analytic = {
                        public_key: new web3_js_1.PublicKey(res.public_key),
                        event: EventType.CLAIMED_BACK,
                        created_at: new Date(res.created_at)
                    };
                } else if (res.event == "ACCESSED" && (!analytic || analytic.event !== EventType.CLAIMED && analytic.event !== EventType.CLAIMED_BACK)) {
                    analytic = {
                        public_key: new web3_js_1.PublicKey(res.public_key),
                        event: EventType.ACCESSED,
                        created_at: new Date(res.created_at)
                    };
                } else if (res.event == "CREATED" && (!analytic || analytic.event !== EventType.CLAIMED && analytic.event !== EventType.CLAIMED_BACK && analytic.event !== EventType.ACCESSED)) {
                    analytic = {
                        public_key: new web3_js_1.PublicKey(res.public_key),
                        event: EventType.CREATED,
                        created_at: new Date(res.created_at)
                    };
                }
            });
            return analytic;
        });
    }
    getAnalytics() {
        return __awaiter(this, void 0, void 0, function*() {
            // TODO clean up response here and type
            const analyticsRes = yield this.client.fetch(`campaigns/${this.id}/analytics_summary`);
            return analyticsRes;
        });
    }
    share(email, admin = false) {
        return __awaiter(this, void 0, void 0, function*() {
            const accounts = yield this.client.fetch(`accounts_public`, {
                torus_id: email
            });
            const account = accounts[0];
            if (!account) {
                console.warn("invalid email");
                return false;
            }
            const campaignAccounts = yield this.client.fetch(`campaigns/${this.id}/campaign_account_joins`, {
                account_id: account.id
            }, null, "GET");
            const joinEntry = campaignAccounts.find((csa)=>csa.account.torus_id === email);
            if (joinEntry) {
                console.warn("already shared with this email");
                if (joinEntry.is_owner === admin) {
                    return false;
                }
            }
            let encryptedCampaignKey = "";
            if (typeof this.encryptionKey === "undefined") {
                console.warn("encryptionKey not set: sharing view only");
            } else {
                encryptedCampaignKey = yield (0, crypto_1.encryptPublicKey)(this.encryptionKey, account.public_key);
            }
            const shareParams = {
                campaign_id: this.id,
                account_id: account.id,
                encrypted_campaign_key: encryptedCampaignKey,
                is_owner: admin
            };
            const shareResp = yield this.client.fetch(`campaigns/${this.id}/campaign_account_joins${joinEntry ? `/${joinEntry.id}` : ""}`, null, shareParams, joinEntry ? "PUT" : "POST");
            return !!shareResp;
        });
    }
}
exports.Campaign = Campaign;
class DispenserActions extends TipLinkApi {
    constructor(params){
        super(params.client);
        this.campaign = params.campaign;
    }
    create(params) {
        return __awaiter(this, void 0, void 0, function*() {
            const useCaptcha = typeof params != "undefined" && typeof params.useCaptcha != "undefined" ? params.useCaptcha : true;
            const useFingerprint = typeof params != "undefined" && typeof params.useFingerprint != "undefined" ? params.useFingerprint : true;
            const unlimitedClaims = typeof params != "undefined" && typeof params.unlimitedClaims != "undefined" ? params.unlimitedClaims : false;
            const active = typeof params != "undefined" && typeof params.active != "undefined" && params.active !== null ? params.active : true;
            const includedEntryIds = typeof params != "undefined" && typeof params.includedEntryIds != "undefined" && params.includedEntryIds !== null ? params.includedEntryIds : [];
            const excludedEntryIds = typeof params != "undefined" && typeof params.excludedEntryIds != "undefined" && params.excludedEntryIds !== null ? params.excludedEntryIds : [];
            const rateLimits = yield this.client.fetch(`campaigns/${this.campaign.id}/rate_limits`);
            yield Promise.all(rateLimits.map((rateLimit)=>__awaiter(this, void 0, void 0, function*() {
                    const deleteRateLimitRes = yield this.client.fetch(`campaigns/${this.campaign.id}/rate_limits/${rateLimit["id"]}`, null, null, "DELETE");
                    return deleteRateLimitRes;
                })));
            if (!unlimitedClaims) {
                const rateLimitData = {
                    rate: "FOREVER",
                    rate_multiple: 1,
                    claims: 1
                };
                yield this.client.fetch(`campaigns/${this.campaign.id}/rate_limits`, null, rateLimitData, "POST");
            }
            const faucetData = {
                active: active,
                name: "faucet",
                fingerprint: useFingerprint,
                recaptcha: useCaptcha
            };
            const faucet = yield this.client.fetch(`campaigns/${this.campaign.id}/faucet`, null, faucetData, "POST");
            const dispenser = new Dispenser({
                client: this.client,
                campaign: this.campaign,
                id: faucet["id"],
                urlSlug: faucet["url_slug"],
                useCaptcha: faucet["recaptcha"],
                useFingerprint: faucet["fingerprint"],
                unlimitedClaims: unlimitedClaims,
                active: faucet["active"]
            });
            const faucetEntryData = {
                all: includedEntryIds.length === 0,
                included_campaign_entry_ids: includedEntryIds,
                excluded_campaign_entry_ids: excludedEntryIds
            };
            yield this.client.fetch(`campaigns/${this.campaign.id}/faucet/${faucet.id}/faucet_entries`, null, faucetEntryData, "POST");
            return dispenser;
        });
    }
    find(params) {
        return __awaiter(this, void 0, void 0, function*() {
            const findParams = Object.assign(Object.assign({}, params), {
                limit: 1,
                sorting: "-created_at"
            });
            const faucet = (yield this.client.fetch(`campaigns/${this.campaign.id}/faucet`, findParams, null, "GET"))[0];
            // TODO determine unlimited claims properly
            const dispenser = new Dispenser({
                client: this.client,
                campaign: this.campaign,
                id: faucet["id"],
                urlSlug: faucet["url_slug"],
                useCaptcha: faucet["recaptcha"],
                useFingerprint: faucet["fingerprint"],
                unlimitedClaims: false,
                active: faucet["active"]
            });
            return dispenser;
        });
    }
    all(params) {
        return __awaiter(this, void 0, void 0, function*() {
            const filterParams = Object.assign({}, params);
            const faucets = yield this.client.fetch(`campaigns/${this.campaign.id}/faucet`, filterParams, null, "GET");
            // TODO determine unlimited claims properly
            const dispensers = faucets.map((faucet)=>{
                const dispenser = new Dispenser({
                    client: this.client,
                    campaign: this.campaign,
                    id: faucet["id"],
                    urlSlug: faucet["url_slug"],
                    useCaptcha: faucet["recaptcha"],
                    useFingerprint: faucet["fingerprint"],
                    unlimitedClaims: false,
                    active: faucet["active"]
                });
                return dispenser;
            });
            return dispensers;
        });
    }
}
class Dispenser extends TipLinkApi {
    constructor(params){
        super(params.client);
        this.campaign = params.campaign;
        this.urlSlug = params.urlSlug;
        this.useFingerprint = params.useFingerprint;
        this.unlimitedClaims = params.unlimitedClaims;
        this.useCaptcha = params.useCaptcha;
        this.active = params.active;
        this.id = params.id;
        this.url = this.getUrl();
    }
    getUrl() {
        if (typeof this.campaign.encryptionKey == "undefined") {
            throw "invalid dispenser no decryption key available";
        }
        const urlString = `${URL_BASE}/f/${this.campaign.id}-${this.urlSlug}#${this.campaign.encryptionKey}`;
        return new URL(urlString);
    }
    pause() {
        return __awaiter(this, void 0, void 0, function*() {
            const data = {
                active: false
            };
            const faucet = yield this.client.fetch(`campaigns/${this.campaign.id}/faucet/${this.id}`, null, data, "PUT");
            this.active = faucet.active;
            return true;
        });
    }
    resume() {
        return __awaiter(this, void 0, void 0, function*() {
            const data = {
                active: true
            };
            const faucet = yield this.client.fetch(`campaigns/${this.campaign.id}/faucet/${this.id}`, null, data, "PUT");
            this.active = faucet.active;
            return true;
        });
    }
    refresh() {
        return __awaiter(this, void 0, void 0, function*() {
            const data = {
                url_slug: (0, nanoid_1.nanoid)(FAUCET_ID_LENGTH)
            };
            const faucet = yield this.client.fetch(`campaigns/${this.campaign.id}/faucet/${this.id}`, null, data, "PUT");
            this.urlSlug = faucet["url_slug"];
            this.url = this.getUrl();
            return this.url;
        });
    }
    delete() {
        return __awaiter(this, void 0, void 0, function*() {
            yield this.client.fetch(`campaigns/${this.campaign.id}/faucet/${this.id}`, null, null, "DELETE");
            return true;
        });
    }
}
exports.Dispenser = Dispenser;
var DataHost;
(function(DataHost) {
    DataHost["Arweave"] = "arweave";
    DataHost["Shadow"] = "shadow";
})(DataHost = exports.DataHost || (exports.DataHost = {}));
const IMAGE_HOST_DEFAULT = DataHost.Arweave;
class MintActions extends TipLinkApi {
    constructor(params){
        super(params.client);
    }
    transformAttributes(attributes) {
        const newMintAttributes = [];
        if (Object.keys(attributes).length > 0) {
            Object.keys(attributes).forEach((key)=>{
                newMintAttributes.push({
                    trait_type: key,
                    value: attributes[key]
                });
            });
        }
        return newMintAttributes;
    }
    isValidUrl(urlString) {
        const url = new URL(urlString);
        return url.protocol === "https:" || url.protocol === "http:";
    }
    getFees(params) {
        return __awaiter(this, void 0, void 0, function*() {
            const costRequest = {
                metadata: {
                    name: params.mintName,
                    symbol: params.symbol,
                    creator: params.creatorPublicKey.toBase58(),
                    royalties: Number(params.royalties),
                    description: params.mintDescription,
                    attributes: this.transformAttributes(params.attributes || {}),
                    externalUrl: params.externalUrl,
                    image: params.mintImageUrl,
                    mimeType: "image/png"
                },
                imageSize: 0,
                supply: params.mintLimit,
                collectionMint: !!params.existingCollectionId,
                imageHost: params.dataHost || IMAGE_HOST_DEFAULT
            };
            const costData = (yield this.client.fetch("/api/dynamic_mint/calculate_campaign_costs", null, costRequest, "POST"))[0]; // TODO type this response?
            let total = 0;
            Object.keys(costData).forEach((costKey)=>total += costData[costKey].cost || 0);
            const destination = new web3_js_1.PublicKey(costData.publicKeyToFund);
            return {
                publicKey: destination,
                feeLamports: total * web3_js_1.LAMPORTS_PER_SOL
            };
        });
    }
    create(params) {
        return __awaiter(this, void 0, void 0, function*() {
            const formData = new FormData();
            const index = 0;
            if (params.mintName.length > exports.ON_CHAIN_NAME_CHAR_LIMIT) {
                throw Error("Mint Name too Long");
            } else if (params.symbol.length > exports.ON_CHAIN_SYMBOL_CHAR_LIMIT) {
                throw Error("Mint Symbol too Long");
            } else if (typeof params.royalties !== "undefined" && (params.royalties > 50 || params.royalties < 0)) {
                throw Error("Royalties must be between 0 and 50%");
            } else if (typeof params.externalUrl !== "undefined" && params.externalUrl !== "" && !this.isValidUrl(params.externalUrl)) {
                throw Error("Invalid external url");
            }
            if (!params.feeTransactionHash) {
                throw Error("Missing feeTransactionHash");
            }
            if (params.campaignName) {
                formData.append(`mint[${index}][campaignName]`, params.campaignName);
            }
            if (params.campaignDescription) {
                formData.append(`mint[${index}][campaignDescription]`, params.campaignDescription);
            }
            if (params.themeId) {
                formData.append(`mint[${index}][themeId]`, String(params.themeId));
            }
            if (params.mintName) {
                formData.append(`mint[${index}][name]`, params.mintName);
            }
            if (params.symbol) {
                formData.append(`mint[${index}][symbol]`, params.symbol);
            }
            if (params.mintDescription) {
                formData.append(`mint[${index}][description]`, params.mintDescription);
            }
            if (params.mintImageUrl) {
                formData.append(`mint[${index}][imageUrl]`, params.mintImageUrl);
            }
            if (params.dataHost) {
                formData.append(`mint[${index}][imageHost]`, params.dataHost || IMAGE_HOST_DEFAULT);
            }
            if (params.mintImageUrl) {
                formData.append(`mint[${index}][archiveImageUrl]`, params.mintImageUrl);
            }
            if (params.externalUrl) {
                formData.append(`mint[${index}][externalUrl]`, params.externalUrl);
            }
            if (params.existingCollectionId) {
                formData.append(`mint[${index}][collectionMint]`, params.existingCollectionId);
            }
            if (params.mintLimit.toString()) {
                formData.append(`mint[${index}][initialLimit]`, params.mintLimit.toString());
            }
            if (params.creatorPublicKey) {
                formData.append(`mint[${index}][creator]`, params.creatorPublicKey.toBase58() || "");
            }
            if (params.royalties) {
                formData.append(`mint[${index}][sellerFeeBasisPoints]`, JSON.stringify(Number(params.royalties) * 100));
            }
            if (params.royaltiesDestination) {
                formData.append(`mint[${index}][royaltiesDestination]`, params.royaltiesDestination.toBase58() || "");
            }
            if (params.attributes) {
                formData.append(`mint[${index}][attributes]`, JSON.stringify(this.transformAttributes(params.attributes)));
            }
            if (formData.get(`mint[${index}][campaignName]`) === null) {
                throw Error("campaignName is required");
            } else if (formData.get(`mint[${index}][name]`) === null) {
                throw Error("mintName is required");
            } else if (formData.get(`mint[${index}][archiveImageUrl]`) === null) {
                throw Error("imageUrl is required"); // TODO upload image too?
            } else if (formData.get(`mint[${index}][symbol]`) === null) {
                throw Error("symbol is required");
            } else if (formData.get(`mint[${index}][initialLimit]`) === null) {
                throw Error("mintLimit is required");
            }
            if (!params.feeTransactionHash) {
                throw Error("feeTransactionHash is required");
            }
            const stageResponse = (yield this.client.fetch("/api/dynamic_mint/stage_mint_campaign", null, formData, "POST"))[0];
            const feeTransactionHash = params.feeTransactionHash;
            const createResponse = (yield this.client.fetch("/api/dynamic_mint/create_mint_campaign", null, {
                campaignIds: [
                    stageResponse.campaign_id
                ],
                transactions: [
                    feeTransactionHash
                ]
            }, "POST"))[0]; // TODO type this response
            const mintParams = {
                client: this.client,
                id: Number(createResponse["id"]),
                campaign_id: createResponse["campaign_id"],
                mintName: createResponse["name"],
                symbol: createResponse["symbol"],
                mintDescription: createResponse["description"],
                campaignName: params.campaignName,
                collectionId: createResponse["collection_mint"],
                treeAddress: createResponse["tree_address"],
                jsonUri: createResponse["json_uri"],
                creatorPublicKey: new web3_js_1.PublicKey(createResponse["creator"]),
                attributes: createResponse["attributes"],
                mintLimit: Number(createResponse["mint_limit"]),
                collectionUri: createResponse["collection_uri"],
                imageUrl: createResponse["image"],
                dataHost: createResponse["imageHost"],
                externalUrl: createResponse["external_url"],
                royalties: createResponse["seller_fee_basis_points"],
                primaryUrlSlug: createResponse["primary_url_slug"],
                rotatingUrlSlug: createResponse["rotating_url_slug"],
                useRotating: createResponse["use_rotating"],
                // rotating_seed_key: createResponse["rotating_seed_key"],
                rotatingTimeInterval: Number(createResponse["rotating_time_interval"]),
                totpWindow: createResponse["totp_window"],
                userClaimLimit: createResponse["user_claim_limit"]
            };
            if (Object.prototype.hasOwnProperty.call(createResponse, "royalties_destination") && typeof createResponse["royalties_destination"] === "string") {
                mintParams["royaltiesDestination"] = new web3_js_1.PublicKey(createResponse["royalties_destination"]);
            }
            const mint = new Mint(mintParams);
            return mint;
        });
    }
    find(params) {
        return __awaiter(this, void 0, void 0, function*() {
            const res = yield this.client.fetch(`campaigns/${params.campaign_id}/mint/specs`, {
                campaign_id: params.campaign_id
            }, null, "GET")// TODO type this
            ;
            const mintParams = {
                client: this.client,
                id: Number(res["id"]),
                campaign_id: res["campaign_id"],
                mintName: res["name"],
                symbol: res["symbol"],
                mintDescription: res["description"],
                campaignName: res['name'],
                collectionId: res["collection_mint"],
                treeAddress: res["tree_address"],
                jsonUri: res["json_uri"],
                creatorPublicKey: new web3_js_1.PublicKey(res["creator"]),
                attributes: res["attributes"],
                mintLimit: Number(res["mint_limit"]),
                collectionUri: res["collection_uri"],
                imageUrl: res["image"],
                dataHost: res["imageHost"],
                externalUrl: res["external_url"],
                royalties: res["seller_fee_basis_points"],
                primaryUrlSlug: res["primary_url_slug"],
                rotatingUrlSlug: res["rotating_url_slug"],
                useRotating: res["use_rotating"],
                // rotating_seed_key: res["rotating_seed_key"],
                rotatingTimeInterval: Number(res["rotating_time_interval"]),
                totpWindow: res["totp_window"],
                userClaimLimit: res["user_claim_limit"]
            };
            if (Object.prototype.hasOwnProperty.call(res, "royalties_destination") && typeof res["royalties_destination"] === "string") {
                mintParams["royaltiesDestination"] = new web3_js_1.PublicKey(res["royalties_destination"]);
            }
            const mint = new Mint(mintParams);
            return mint;
        });
    }
}
class Mint extends TipLinkApi {
    constructor(params){
        super(params.client);
        this.id = params.id;
        this.campaign_id = params.campaign_id;
        this.mintName = params.mintName;
        this.mintDescription = params.mintDescription || "";
        this.campaignName = params.campaignName;
        this.imageUrl = params.imageUrl;
        this.externalUrl = params.externalUrl || "";
        this.dataHost = params.dataHost || IMAGE_HOST_DEFAULT;
        this.symbol = params.symbol;
        this.mintDescription = params.mintDescription || "";
        this.mintLimit = params.mintLimit;
        this.attributes = params.attributes || [];
        this.creatorPublicKey = params.creatorPublicKey;
        this.collectionId = params.collectionId;
        this.treeAddress = params.treeAddress;
        this.jsonUri = params.jsonUri;
        this.collectionUri = params.collectionUri;
        this.primaryUrlSlug = params.primaryUrlSlug;
        this.rotatingUrlSlug = params.rotatingUrlSlug;
        this.useRotating = params.useRotating;
        this.rotatingTimeInterval = params.rotatingTimeInterval;
        this.totpWindow = params.totpWindow;
        this.userClaimLimit = params.userClaimLimit;
        this.royaltiesDestination = params.royaltiesDestination;
        this.royalties = params.royalties;
    }
    // TODO how should we handle rotating urls
    getMintUrl() {
        return new URL(`${URL_BASE}/m/${this.primaryUrlSlug}`);
    }
    getAnalytics() {
        return __awaiter(this, void 0, void 0, function*() {
            // TODO clean up response here and type
            const analyticsRes = yield this.client.fetch(`campaigns/${this.campaign_id}/mint/analytics/summary`);
            return analyticsRes;
        });
    }
    getMintActivity(params) {
        return __awaiter(this, void 0, void 0, function*() {
            // TODO should this only work for non individual links?
            const activitiesRes = yield this.client.fetch(`campaigns/${this.campaign_id}/mint/activities`, {
                url_slug: params.urlSlug
            });
            if (Object.prototype.hasOwnProperty.call(activitiesRes, 'activities') && activitiesRes.activities.length > 0) {
                const activity = activitiesRes.activities[0];
                // @ts-ignore
                if (Object.prototype.hasOwnProperty.call(activity, 'mint')) {
                    return {
                        claim_txn: activity.mint.claim_txn,
                        timestamp: new Date(activity.mint.timestamp),
                        destination: new web3_js_1.PublicKey(activity.mint.destination)
                    };
                }
                return {
                    claim_txn: activity.claim_txn,
                    timestamp: new Date(activity.timestamp),
                    destination: new web3_js_1.PublicKey(activity.destination)
                };
            }
            return null;
        });
    }
    share(email, admin = false) {
        return __awaiter(this, void 0, void 0, function*() {
            const accounts = yield this.client.fetch(`accounts_public`, {
                torus_id: email
            });
            const account = accounts[0];
            if (!account) {
                console.warn("invalid email");
                return false;
            }
            const campaignAccounts = yield this.client.fetch(`campaigns/${this.campaign_id}/campaign_account_joins`, {
                account_id: account.id
            }, null, "GET");
            const joinEntry = campaignAccounts.find((csa)=>csa.account.torus_id === email);
            if (joinEntry) {
                console.warn("already shared with this email");
                if (joinEntry.is_owner === admin) {
                    return false;
                }
            }
            const shareParams = {
                campaign_id: this.campaign_id,
                account_id: account.id,
                encrypted_campaign_key: "",
                is_owner: admin
            };
            const shareResp = yield this.client.fetch(`campaigns/${this.campaign_id}/campaign_account_joins${joinEntry ? `/${joinEntry.id}` : ""}`, null, shareParams, joinEntry ? "PUT" : "POST");
            return !!shareResp;
        });
    }
}
exports.Mint = Mint;
}}),
"[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/anchor-generated/types/tiplink_escrow.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.IDL = void 0;
exports.IDL = {
    version: "0.1.0",
    name: "tiplink_escrow",
    instructions: [
        {
            name: "initializeLamport",
            accounts: [
                {
                    name: "depositor",
                    isMut: true,
                    isSigner: true
                },
                {
                    name: "pda",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "treasury",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "tiplink",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "systemProgram",
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: "amount",
                    type: "u64"
                },
                {
                    name: "escrowId",
                    type: "publicKey"
                }
            ]
        },
        {
            name: "withdrawLamport",
            accounts: [
                {
                    name: "authority",
                    isMut: true,
                    isSigner: true
                },
                {
                    name: "destination",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "pda",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "systemProgram",
                    isMut: false,
                    isSigner: false
                }
            ],
            args: []
        },
        {
            name: "initializeSpl",
            accounts: [
                {
                    name: "depositor",
                    isMut: true,
                    isSigner: true
                },
                {
                    name: "depositorTa",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "pda",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "pdaAta",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "treasury",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "tiplink",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "mint",
                    isMut: false,
                    isSigner: false
                },
                {
                    name: "tokenProgram",
                    isMut: false,
                    isSigner: false
                },
                {
                    name: "associatedTokenProgram",
                    isMut: false,
                    isSigner: false
                },
                {
                    name: "systemProgram",
                    isMut: false,
                    isSigner: false
                }
            ],
            args: [
                {
                    name: "amount",
                    type: "u64"
                },
                {
                    name: "escrowId",
                    type: "publicKey"
                }
            ]
        },
        {
            name: "withdrawSpl",
            accounts: [
                {
                    name: "authority",
                    isMut: true,
                    isSigner: true
                },
                {
                    name: "destination",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "destinationAta",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "pda",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "pdaAta",
                    isMut: true,
                    isSigner: false
                },
                {
                    name: "mint",
                    isMut: false,
                    isSigner: false
                },
                {
                    name: "tokenProgram",
                    isMut: false,
                    isSigner: false
                },
                {
                    name: "associatedTokenProgram",
                    isMut: false,
                    isSigner: false
                },
                {
                    name: "systemProgram",
                    isMut: false,
                    isSigner: false
                }
            ],
            args: []
        }
    ],
    accounts: [
        {
            name: "escrowLamports",
            type: {
                kind: "struct",
                fields: [
                    {
                        name: "bump",
                        type: "u8"
                    },
                    {
                        name: "escrowId",
                        type: "publicKey"
                    },
                    {
                        name: "depositor",
                        type: "publicKey"
                    },
                    {
                        name: "tiplink",
                        type: "publicKey"
                    },
                    {
                        name: "amount",
                        type: "u64"
                    }
                ]
            }
        },
        {
            name: "escrowSpl",
            type: {
                kind: "struct",
                fields: [
                    {
                        name: "bump",
                        type: "u8"
                    },
                    {
                        name: "escrowId",
                        type: "publicKey"
                    },
                    {
                        name: "depositor",
                        type: "publicKey"
                    },
                    {
                        name: "tiplink",
                        type: "publicKey"
                    },
                    {
                        name: "mint",
                        type: "publicKey"
                    },
                    {
                        name: "amount",
                        type: "u64"
                    }
                ]
            }
        }
    ],
    events: [
        {
            name: "DepositEvent",
            fields: [
                {
                    name: "pda",
                    type: "publicKey",
                    index: false
                },
                {
                    name: "depositor",
                    type: "publicKey",
                    index: false
                },
                {
                    name: "tiplink",
                    type: "publicKey",
                    index: false
                }
            ]
        },
        {
            name: "WithdrawEvent",
            fields: [
                {
                    name: "pda",
                    type: "publicKey",
                    index: false
                },
                {
                    name: "depositor",
                    type: "publicKey",
                    index: false
                },
                {
                    name: "tiplink",
                    type: "publicKey",
                    index: false
                }
            ]
        }
    ],
    errors: [
        {
            code: 6000,
            name: "WrongAuthority",
            msg: "Wrong authority."
        },
        {
            code: 6001,
            name: "InvalidPublicKey",
            msg: "Invalid public key."
        }
    ]
};
}}),
"[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/constants.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.INDEXER_URL_BASE = exports.PRIO_FEES_LAMPORTS = exports.DEPOSIT_URL_BASE = exports.PDA_SEED = exports.TREASURY_PUBLIC_KEY = exports.ESCROW_PROGRAM_ID = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-rsc] (ecmascript)");
exports.ESCROW_PROGRAM_ID = new web3_js_1.PublicKey("8TqqugH88U3fDEWeKHqBSxZKeqoRrXkdpy3ciX5GAruK");
exports.TREASURY_PUBLIC_KEY = new web3_js_1.PublicKey("BGZMcTjyTCbkRszC1CBpFpP9CbVh3Ah2ZhjzCsc9PsAr");
exports.PDA_SEED = "escrow";
const DEFAULT_DEPOSIT_URL_BASE = "https://tiplink-mailer.vercel.app/depositor-url";
exports.DEPOSIT_URL_BASE = process !== undefined && process.env !== undefined ? process.env.NEXT_PUBLIC_ESCROW_DEPOSITOR_URL_OVERRIDE || DEFAULT_DEPOSIT_URL_BASE : DEFAULT_DEPOSIT_URL_BASE;
exports.PRIO_FEES_LAMPORTS = 10000;
const DEFAULT_INDEXER_URL_BASE = "https://backend.tiplink.io";
exports.INDEXER_URL_BASE = process !== undefined && process.env !== undefined ? process.env.NEXT_PUBLIC_INDEXER_URL_OVERRIDE || DEFAULT_INDEXER_URL_BASE : DEFAULT_INDEXER_URL_BASE;
}}),
"[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/email.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.isEmailValid = exports.VERIFY_EMAIL_ENDPOINT = void 0;
const DEFAULT_VERIFY_EMAIL_ENDPOINT = "https://email-verify.tiplink.tech/verify-email";
exports.VERIFY_EMAIL_ENDPOINT = process !== undefined && process.env !== undefined ? process.env.NEXT_PUBLIC_VERIFY_EMAIL_ENDPOINT_OVERRIDE || DEFAULT_VERIFY_EMAIL_ENDPOINT : DEFAULT_VERIFY_EMAIL_ENDPOINT;
function isEmailValid(emailAddress) {
    return __awaiter(this, void 0, void 0, function*() {
        const res = yield fetch(exports.VERIFY_EMAIL_ENDPOINT, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                emailAddress
            })
        });
        if (!res.ok) {
            throw new Error(`HTTP error! Status: ${res.status}`);
        }
        const { validFormat, validSmtp, validMx } = yield res.json();
        return validFormat && validSmtp && validMx;
    });
}
exports.isEmailValid = isEmailValid;
}}),
"[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/enclave.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.mailEscrow = exports.mail = exports.getReceiverEmail = exports.createReceiverTipLink = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-rsc] (ecmascript)");
const email_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/email.js [app-rsc] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/constants.js [app-rsc] (ecmascript)");
const DEFAULT_ENCLAVE_ENDPOINT = "https://mailer.tiplink.io";
const ENCLAVE_ENDPOINT = process !== undefined && process.env !== undefined ? process.env.NEXT_PUBLIC_ENCLAVE_ENDPOINT_OVERRIDE || DEFAULT_ENCLAVE_ENDPOINT : DEFAULT_ENCLAVE_ENDPOINT;
/**
 * Asynchronously calls secure enclave to create a TipLink, store it with an associated email, and return its public key.
 *
 * @param apiKey - The API key to be used for the request.
 * @param email - The email address to be associated with the receiver tiplink.
 * @returns A promise that resolves to the PublicKey of the receiver tiplink.
 * @throws Throws an error if the HTTPS request fails with a non-ok status.
 */ function createReceiverTipLink(apiKey, email) {
    return __awaiter(this, void 0, void 0, function*() {
        if (!(yield (0, email_1.isEmailValid)(email))) {
            throw new Error("Invalid email address");
        }
        const endpoint = `${ENCLAVE_ENDPOINT}/api/v1/generated-tiplinks/create`;
        const res = yield fetch(endpoint, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "x-api-key": apiKey
            },
            body: JSON.stringify({
                email
            })
        });
        if (!res.ok) {
            throw new Error(`HTTP error, status: ${res.status}`);
        }
        const { data: { publicKey: publicKeyStr } } = yield res.json();
        return new web3_js_1.PublicKey(publicKeyStr);
    });
}
exports.createReceiverTipLink = createReceiverTipLink;
/**
 * Asynchronously calls secure enclave to retrieve the email associated with a receiver TipLink.
 *
 * @param apiKey - The API key to be used for the request.
 * @param publicKey - The public key of the TipLink for which to retrieve the associated email.
 * @returns A promise that resolves to the email address associated with the provided TipLink public key.
 * @throws Throws an error if the HTTPS request fails with a non-ok status.
 */ function getReceiverEmail(apiKey, publicKey) {
    return __awaiter(this, void 0, void 0, function*() {
        // We actually no longer hit the enclave here but we'll keep in this file
        // since the enclave manages this data.
        const endpoint = `${constants_1.INDEXER_URL_BASE}/api/v1/generated-tiplinks/${publicKey.toString()}/email`;
        const res = yield fetch(endpoint, {
            method: "GET",
            headers: {
                "x-api-key": apiKey
            }
        });
        if (!res.ok) {
            throw new Error(`HTTP error, status: ${res.status}`);
        }
        const { data: { email } } = yield res.json();
        return email;
    });
}
exports.getReceiverEmail = getReceiverEmail;
/**
 * @deprecated We are sunsetting this feature and will only be supporting
 * emailiing EscrowTipLinks. We recommend not using this feature.
 *
 * Asynchronously emails a TipLink.
 *
 * @param apiKey - The API key to be used for the request.
 * @param tipLink - The TipLink object to be sent.
 * @param toEmail - The email address of the recipient.
 * @param toName - Optional name of the recipient for the email.
 * @param replyEmail - Optional email address for the recipient to reply to.
 * @param replyName - Optional name of the sender for the email.
 * @param templateName - Optional name of the template to be used for the email.
 * @returns A promise that resolves when the email has been sent.
 * @throws Throws an error if the HTTP request fails with a non-ok status.
 */ function mail(apiKey, tipLink, toEmail, toName, replyEmail, replyName, templateName) {
    return __awaiter(this, void 0, void 0, function*() {
        if (!(yield (0, email_1.isEmailValid)(toEmail))) {
            throw new Error("Invalid email address");
        }
        const url = `${ENCLAVE_ENDPOINT}/api/v1/email/send`;
        const body = {
            toEmail: toEmail,
            toName,
            replyEmail,
            replyName,
            tiplinkUrl: tipLink.url.toString(),
            templateName
        };
        const res = yield fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "x-api-key": apiKey
            },
            body: JSON.stringify(body)
        });
        if (!res.ok) {
            throw new Error(`HTTP error, status: ${res.status}`);
        }
        console.log("TipLink sent!", res);
    });
}
exports.mail = mail;
/**
 * Asynchronously emails a deposited Escrow TipLink to a pre-defined recipient.
 */ function mailEscrow(args) {
    return __awaiter(this, void 0, void 0, function*() {
        // TODO: Require API key / ensure deposited
        const { apiKey, toName, replyEmail, replyName, templateName } = args;
        const { escrowTipLink } = args;
        let { toEmail, pda, receiverTipLink } = args;
        if (escrowTipLink) {
            toEmail = escrowTipLink.toEmail;
            pda = escrowTipLink.pda;
            receiverTipLink = escrowTipLink.receiverTipLink;
        }
        if (!(yield (0, email_1.isEmailValid)(toEmail))) {
            throw new Error("Invalid email address");
        }
        // Sanity check; error checking occurs in the enclave and on-chain program
        if (!toEmail || !pda || !receiverTipLink) {
            throw new Error("Improper escrow.");
        }
        const url = `${ENCLAVE_ENDPOINT}/api/v1/email/send/escrow`;
        const receiverUrlOverride = process !== undefined && process.env !== undefined ? process.env.NEXT_PUBLIC_ESCROW_RECEIVER_URL_OVERRIDE || undefined : undefined;
        const body = {
            toEmail,
            toName,
            replyEmail,
            replyName,
            pda: pda.toString(),
            tiplinkPublicKey: receiverTipLink.toString(),
            receiverUrlOverride,
            templateName
        };
        const res = yield fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "x-api-key": apiKey
            },
            body: JSON.stringify(body)
        });
        if (!res.ok) {
            throw new Error(`HTTP error, status: ${res.status}`);
        }
        console.log("Escrow TipLink sent!", res);
    });
}
exports.mailEscrow = mailEscrow;
}}),
"[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/EscrowTipLink.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.EscrowTipLink = exports.getEscrowReceiverTipLink = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-rsc] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.3.11_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-valida_ldh2i43nn7y4lzjfcagwkizap4/node_modules/@solana/spl-token/lib/cjs/index.js [app-rsc] (ecmascript)");
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-rsc] (ecmascript)");
const tiplink_escrow_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/anchor-generated/types/tiplink_escrow.js [app-rsc] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/constants.js [app-rsc] (ecmascript)");
const enclave_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/enclave.js [app-rsc] (ecmascript)");
function getEscrowReceiverTipLink(connection, pda) {
    return __awaiter(this, void 0, void 0, function*() {
        const escrowProgram = new anchor_1.Program(tiplink_escrow_1.IDL, constants_1.ESCROW_PROGRAM_ID, {
            connection
        } // Provider interface only requires a connection, not a wallet
        );
        let pdaAccount;
        // TODO: Implement better method of deciphering between lamport and SPL PDAs
        try {
            // First see if it's a lamport escrow
            pdaAccount = yield escrowProgram.account.escrowLamports.fetch(pda);
        } catch (_a) {
            try {
                // If not, see if it's a SPL escrow
                pdaAccount = yield escrowProgram.account.escrowSpl.fetch(pda);
            } catch (_b) {
                // No escrow exists for this PDA
                // TODO: Provide info on whether it was withdrawn or never existed
                return undefined;
            }
        }
        return pdaAccount.tiplink;
    });
}
exports.getEscrowReceiverTipLink = getEscrowReceiverTipLink;
/**
 * Represents an on-chain escrow that can be withdrawn by the original depositor or a TipLink, e-mailed to a recipient.
 * The depositor does not see the TipLink, enabling multi-sig. (Otherwise, one signer could unilaterally withdraw the funds to themselves.)
 *
 * @remarks EscrowTipLinks currently only support SOL and SPL assets.
 */ class EscrowTipLink {
    get depositorUrl() {
        // Sanity check; error checking occurs in the enclave and on-chain program
        if (!this.pda) {
            throw new Error("Attempted to get depositorUrl from a non-deposited escrow.");
        }
        const url = new URL(constants_1.DEPOSIT_URL_BASE);
        url.searchParams.append("pda", this.pda.toString());
        return url;
    }
    constructor(toEmail, receiverTipLink, amount, depositor, escrowId, pda, mint, depositorTa){
        this.toEmail = toEmail;
        this.receiverTipLink = receiverTipLink;
        this.amount = amount;
        this.depositor = depositor;
        this.escrowId = escrowId;
        this.pda = pda;
        this.mint = mint;
        this.depositorTa = depositorTa;
    }
    /**
     * Creates an EscrowTipLink instance to be deposited.
     *
     * @param depositorTa - Overrides for non-ATA cases
     */ static create(args) {
        return __awaiter(this, void 0, void 0, function*() {
            const { connection, amount, toEmail, depositor, mint, depositorTa, allowDepositorOffCurve } = args;
            let { receiverTipLink } = args;
            const { apiKey } = args;
            if (!receiverTipLink) {
                receiverTipLink = yield (0, enclave_1.createReceiverTipLink)(apiKey, toEmail);
            }
            const tiplinkEscrowProgram = new anchor_1.Program(tiplink_escrow_1.IDL, constants_1.ESCROW_PROGRAM_ID, {
                connection
            } // Provider interface only requires a connection, not a wallet
            );
            const escrowKeypair = web3_js_1.Keypair.generate();
            const escrowId = escrowKeypair.publicKey;
            const [pda] = web3_js_1.PublicKey.findProgramAddressSync([
                Buffer.from(constants_1.PDA_SEED),
                escrowId.toBuffer(),
                depositor.toBuffer()
            ], tiplinkEscrowProgram.programId);
            let dTa = depositorTa;
            if (!dTa && mint) {
                dTa = yield (0, spl_token_1.getAssociatedTokenAddress)(mint.address, depositor, !!allowDepositorOffCurve);
            }
            return new EscrowTipLink(toEmail, receiverTipLink, amount, depositor, escrowId, pda, mint, dTa);
        });
    }
    /**
     * Creates an EscrowTipLink instance from a deposited, on-chain escrow.
     *
     * To get data for withdrawn / closed escrows, use `parseEscrowIx`,
     * `parseEscrowTx`, or `getAllRecordedEscrowActions`, the last of which should be called
     * on backends and cached for performance.
     */ static get(args) {
        return __awaiter(this, void 0, void 0, function*() {
            const { connection, pda } = args;
            let { receiverEmail } = args;
            const { apiKey } = args;
            const escrowProgram = new anchor_1.Program(tiplink_escrow_1.IDL, constants_1.ESCROW_PROGRAM_ID, {
                connection
            } // Provider interface only requires a connection, not a wallet
            );
            let pdaAccount;
            let mint;
            // TODO: Implement better method of deciphering between lamport and SPL PDAs
            try {
                // First see if it's a lamport escrow
                pdaAccount = yield escrowProgram.account.escrowLamports.fetch(pda);
            } catch (_a) {
                try {
                    // If not, see if it's a SPL escrow
                    pdaAccount = yield escrowProgram.account.escrowSpl.fetch(pda);
                    const mintPublicKey = pdaAccount.mint;
                    mint = yield (0, spl_token_1.getMint)(connection, mintPublicKey);
                } catch (_b) {
                    // No escrow exists for this PDA
                    // TODO: Provide info on whether it was withdrawn or never existed
                    return undefined;
                }
            }
            const receiverTipLink = pdaAccount.tiplink;
            // Empty string can be passed in for withdraw without email
            if (receiverEmail === undefined) {
                receiverEmail = yield (0, enclave_1.getReceiverEmail)(apiKey, receiverTipLink);
            }
            // NOTE: We aren't able to deterministically get depositor TA from here
            // because it might have been overriden and not ATA. The chain history
            // has it if needed.
            return new EscrowTipLink(receiverEmail, receiverTipLink, pdaAccount.amount.toNumber(), pdaAccount.depositor, pdaAccount.escrowId, pda, mint);
        });
    }
    depositLamportTx(tiplinkEscrowProgram, escrowId, pda) {
        return __awaiter(this, void 0, void 0, function*() {
            const tx = yield tiplinkEscrowProgram.methods.initializeLamport(new anchor_1.BN(this.amount.toString()), escrowId).accounts({
                depositor: this.depositor,
                pda,
                treasury: constants_1.TREASURY_PUBLIC_KEY,
                tiplink: this.receiverTipLink
            }).transaction();
            return tx;
        });
    }
    depositSplTx(tiplinkEscrowProgram, escrowId, pda) {
        return __awaiter(this, void 0, void 0, function*() {
            // Sanity check; error checking occurs in the enclave and on-chain program
            if (!this.mint) {
                throw new Error("Attempted to deposit SPL without mint set");
            }
            if (!this.depositorTa) {
                throw new Error("Attempted to deposit SPL without depositorTa set");
            }
            const pdaAta = yield (0, spl_token_1.getAssociatedTokenAddress)(this.mint.address, pda, true);
            const tx = yield tiplinkEscrowProgram.methods.initializeSpl(new anchor_1.BN(this.amount.toString()), escrowId).accounts({
                depositor: this.depositor,
                depositorTa: this.depositorTa,
                pda,
                pdaAta,
                tiplink: this.receiverTipLink,
                treasury: constants_1.TREASURY_PUBLIC_KEY,
                mint: this.mint.address
            }).transaction();
            return tx;
        });
    }
    depositTx(connection) {
        return __awaiter(this, void 0, void 0, function*() {
            const tiplinkEscrowProgram = new anchor_1.Program(tiplink_escrow_1.IDL, constants_1.ESCROW_PROGRAM_ID, {
                connection
            } // Provider interface only requires a connection, not a wallet
            );
            const tx = this.mint ? yield this.depositSplTx(tiplinkEscrowProgram, this.escrowId, this.pda) : yield this.depositLamportTx(tiplinkEscrowProgram, this.escrowId, this.pda);
            return tx;
        });
    }
    withdrawLamportTx(tiplinkEscrowProgram, authority, dest) {
        return __awaiter(this, void 0, void 0, function*() {
            const tx = yield tiplinkEscrowProgram.methods.withdrawLamport().accounts({
                authority,
                destination: dest,
                pda: this.pda
            }).transaction();
            return tx;
        });
    }
    withdrawSplTx(tiplinkEscrowProgram, authority, dest, allowDestOffCurve = false) {
        return __awaiter(this, void 0, void 0, function*() {
            // Sanity check; error checking occurs in the enclave and on-chain program
            if (!this.mint) {
                throw new Error("Attempted to withdraw SPL without mint set");
            }
            // Recalculating to keep class state smaller
            const pdaAta = yield (0, spl_token_1.getAssociatedTokenAddress)(this.mint.address, this.pda, true);
            // TODO: Support non-ATA
            const destAta = yield (0, spl_token_1.getAssociatedTokenAddress)(this.mint.address, dest, allowDestOffCurve);
            const tx = yield tiplinkEscrowProgram.methods.withdrawSpl().accounts({
                authority,
                destination: dest,
                destinationAta: destAta,
                pda: this.pda,
                pdaAta,
                mint: this.mint.address
            }).transaction();
            return tx;
        });
    }
    /**
     * @param dest - The owner account, *not* the token account (if an SPL escrow)
     * @param allowDestOffCurve - Allow calculated ATA to be off-curve (if an SPL escrow)
     */ withdrawTx(connection, authority, dest, allowDestOffCurve = false) {
        return __awaiter(this, void 0, void 0, function*() {
            const tiplinkEscrowProgram = new anchor_1.Program(tiplink_escrow_1.IDL, constants_1.ESCROW_PROGRAM_ID, {
                connection
            } // Provider interface only requires a connection, not a wallet
            );
            if (this.mint) {
                return this.withdrawSplTx(tiplinkEscrowProgram, authority, dest, allowDestOffCurve);
            }
            return this.withdrawLamportTx(tiplinkEscrowProgram, authority, dest);
        });
    }
}
exports.EscrowTipLink = EscrowTipLink;
}}),
"[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/helpers.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.sleep = void 0;
function sleep(ms) {
    return new Promise((resolve)=>setTimeout(resolve, ms));
}
exports.sleep = sleep;
}}),
"[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/escrow-parsing.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
// This file is largely copied / shared with anchor program repo
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getRecordedEscrowActionsFromTx = exports.getRecordedEscrowActionsFromVault = exports.getAllRecordedEscrowActions = exports.parseEscrowTx = exports.parseEscrowIx = exports.deserializeRecordedEscrowActions = exports.serializeRecordedEscrowActions = exports.EscrowActionType = void 0;
__turbopack_require__("[project]/node_modules/.pnpm/dotenv@16.4.7/node_modules/dotenv/config.js [app-rsc] (ecmascript)");
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-rsc] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-rsc] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.3.11_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-valida_ldh2i43nn7y4lzjfcagwkizap4/node_modules/@solana/spl-token/lib/cjs/index.js [app-rsc] (ecmascript)");
const tiplink_escrow_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/anchor-generated/types/tiplink_escrow.js [app-rsc] (ecmascript)"); // This is different in anchor program repo
const helpers_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/helpers.js [app-rsc] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/constants.js [app-rsc] (ecmascript)");
var EscrowActionType;
(function(EscrowActionType) {
    EscrowActionType["DepositLamport"] = "DepositLamport";
    EscrowActionType["WithdrawLamport"] = "WithdrawLamport";
    EscrowActionType["DepositSpl"] = "DepositSpl";
    EscrowActionType["WithdrawSpl"] = "WithdrawSpl";
})(EscrowActionType = exports.EscrowActionType || (exports.EscrowActionType = {}));
function serializeRecordedEscrowActions(recordedActions) {
    return recordedActions.map((recordedAction)=>{
        let serializedAction;
        switch(recordedAction.action.type){
            case EscrowActionType.DepositLamport:
                serializedAction = Object.assign(Object.assign({}, recordedAction), {
                    action: Object.assign(Object.assign({}, recordedAction.action), {
                        pda: recordedAction.action.pda.toBase58(),
                        depositor: recordedAction.action.depositor.toBase58(),
                        receiverTipLink: recordedAction.action.receiverTipLink.toBase58()
                    })
                });
                break;
            case EscrowActionType.WithdrawLamport:
                serializedAction = Object.assign(Object.assign({}, recordedAction), {
                    action: Object.assign(Object.assign({}, recordedAction.action), {
                        pda: recordedAction.action.pda.toBase58(),
                        authority: recordedAction.action.authority.toBase58(),
                        destination: recordedAction.action.destination.toBase58()
                    })
                });
                break;
            case EscrowActionType.DepositSpl:
                serializedAction = Object.assign(Object.assign({}, recordedAction), {
                    action: Object.assign(Object.assign({}, recordedAction.action), {
                        pda: recordedAction.action.pda.toBase58(),
                        depositor: recordedAction.action.depositor.toBase58(),
                        receiverTipLink: recordedAction.action.receiverTipLink.toBase58(),
                        mint: recordedAction.action.mint.address.toBase58()
                    })
                });
                break;
            case EscrowActionType.WithdrawSpl:
                serializedAction = Object.assign(Object.assign({}, recordedAction), {
                    action: Object.assign(Object.assign({}, recordedAction.action), {
                        pda: recordedAction.action.pda.toBase58(),
                        authority: recordedAction.action.authority.toBase58(),
                        destination: recordedAction.action.destination.toBase58(),
                        mint: recordedAction.action.mint.address.toBase58()
                    })
                });
                break;
            default:
                throw new Error("Unknown action type");
        }
        return serializedAction;
    });
}
exports.serializeRecordedEscrowActions = serializeRecordedEscrowActions;
function deserializeRecordedEscrowActions(connection, serializedRecordedActions) {
    return __awaiter(this, void 0, void 0, function*() {
        return Promise.all(serializedRecordedActions.map((serializedRecordedAction)=>__awaiter(this, void 0, void 0, function*() {
                if (serializedRecordedAction.action.type === EscrowActionType.DepositLamport) {
                    return Object.assign(Object.assign({}, serializedRecordedAction), {
                        action: Object.assign(Object.assign({}, serializedRecordedAction.action), {
                            pda: new web3_js_1.PublicKey(serializedRecordedAction.action.pda),
                            depositor: new web3_js_1.PublicKey(serializedRecordedAction.action.depositor),
                            receiverTipLink: new web3_js_1.PublicKey(serializedRecordedAction.action.receiverTipLink)
                        })
                    });
                }
                if (serializedRecordedAction.action.type === EscrowActionType.WithdrawLamport) {
                    return Object.assign(Object.assign({}, serializedRecordedAction), {
                        action: Object.assign(Object.assign({}, serializedRecordedAction.action), {
                            pda: new web3_js_1.PublicKey(serializedRecordedAction.action.pda),
                            authority: new web3_js_1.PublicKey(serializedRecordedAction.action.authority),
                            destination: new web3_js_1.PublicKey(serializedRecordedAction.action.destination)
                        })
                    });
                }
                if (serializedRecordedAction.action.type === EscrowActionType.DepositSpl) {
                    // eslint-disable-next-line no-case-declarations
                    const mint = yield (0, spl_token_1.getMint)(connection, new web3_js_1.PublicKey(serializedRecordedAction.action.mint));
                    return Object.assign(Object.assign({}, serializedRecordedAction), {
                        action: Object.assign(Object.assign({}, serializedRecordedAction.action), {
                            pda: new web3_js_1.PublicKey(serializedRecordedAction.action.pda),
                            depositor: new web3_js_1.PublicKey(serializedRecordedAction.action.depositor),
                            receiverTipLink: new web3_js_1.PublicKey(serializedRecordedAction.action.receiverTipLink),
                            mint
                        })
                    });
                }
                if (serializedRecordedAction.action.type === EscrowActionType.WithdrawSpl) {
                    // eslint-disable-next-line no-case-declarations
                    const mint = yield (0, spl_token_1.getMint)(connection, new web3_js_1.PublicKey(serializedRecordedAction.action.mint));
                    return Object.assign(Object.assign({}, serializedRecordedAction), {
                        action: Object.assign(Object.assign({}, serializedRecordedAction.action), {
                            pda: new web3_js_1.PublicKey(serializedRecordedAction.action.pda),
                            authority: new web3_js_1.PublicKey(serializedRecordedAction.action.authority),
                            destination: new web3_js_1.PublicKey(serializedRecordedAction.action.destination),
                            mint
                        })
                    });
                }
                throw new Error("Unknown action type");
            })));
    });
}
exports.deserializeRecordedEscrowActions = deserializeRecordedEscrowActions;
function parseEscrowIx(connection, compIx, accountKeys) {
    return __awaiter(this, void 0, void 0, function*() {
        const coder = new anchor_1.BorshInstructionCoder(tiplink_escrow_1.IDL);
        let ix;
        // CompiledInstruction uses a base58 string
        if (typeof compIx.data === "string") {
            ix = coder.decode(compIx.data, "base58");
        // MessageCompiledInstruction uses a Uint8Array
        } else {
            ix = coder.decode(Buffer.from(compIx.data), "base58");
        }
        if (!ix) {
            return undefined;
        }
        let keyIndices;
        if ("accounts" in compIx) {
            keyIndices = compIx.accounts;
        } else {
            keyIndices = compIx.accountKeyIndexes;
        }
        // TODO: Get desired indices from IDL instead of magic numbers
        if (ix.name === "initializeLamport") {
            const { amount } = ix.data;
            return {
                type: EscrowActionType.DepositLamport,
                depositor: accountKeys[keyIndices[0]],
                pda: accountKeys[keyIndices[1]],
                receiverTipLink: accountKeys[keyIndices[3]],
                amount: amount.toNumber()
            };
        }
        if (ix.name === "withdrawLamport") {
            return {
                type: EscrowActionType.WithdrawLamport,
                authority: accountKeys[keyIndices[0]],
                destination: accountKeys[keyIndices[1]],
                pda: accountKeys[keyIndices[2]]
            };
        }
        if (ix.name === "initializeSpl") {
            const { amount } = ix.data;
            const mint = yield (0, spl_token_1.getMint)(connection, accountKeys[keyIndices[6]]);
            return {
                type: EscrowActionType.DepositSpl,
                depositor: accountKeys[keyIndices[0]],
                pda: accountKeys[keyIndices[2]],
                receiverTipLink: accountKeys[keyIndices[5]],
                amount: amount.toNumber(),
                mint
            };
        }
        if (ix.name === "withdrawSpl") {
            const mint = yield (0, spl_token_1.getMint)(connection, accountKeys[keyIndices[5]]);
            return {
                type: EscrowActionType.WithdrawSpl,
                authority: accountKeys[keyIndices[0]],
                destination: accountKeys[keyIndices[1]],
                pda: accountKeys[keyIndices[3]],
                mint
            };
        }
        throw new Error("Unknown escrow instruction");
    });
}
exports.parseEscrowIx = parseEscrowIx;
/**
 * @remarks Only use this on the backend for a custom parsing setup. Otherwise,
 * use `getRecordedEscrowActionsFromTx`
 */ function parseEscrowTx(connection, sig) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    return __awaiter(this, void 0, void 0, function*() {
        // Get transaction details
        const txRes = yield connection.getTransaction(sig, {
            maxSupportedTransactionVersion: 1
        });
        if (!txRes || ((_a = txRes.meta) === null || _a === void 0 ? void 0 : _a.err)) {
            return [];
        }
        // Get slot
        const { slot } = txRes;
        const { blockTime } = txRes;
        // Get account keys
        const accountKeys = txRes.transaction.message.staticAccountKeys;
        const writeLutKeys = (_d = (_c = (_b = txRes.meta) === null || _b === void 0 ? void 0 : _b.loadedAddresses) === null || _c === void 0 ? void 0 : _c.writable.map((str)=>new web3_js_1.PublicKey(str))) !== null && _d !== void 0 ? _d : [];
        const readLutKeys = (_g = (_f = (_e = txRes.meta) === null || _e === void 0 ? void 0 : _e.loadedAddresses) === null || _f === void 0 ? void 0 : _f.readonly.map((str)=>new web3_js_1.PublicKey(str))) !== null && _g !== void 0 ? _g : [];
        // Writeable addresses come first
        accountKeys.push(...writeLutKeys, ...readLutKeys);
        const { compiledInstructions: outerIxs } = txRes.transaction.message;
        // Parse outer instructions
        const recordedActions = yield Promise.all(outerIxs.map((ix, index)=>__awaiter(this, void 0, void 0, function*() {
                const action = yield parseEscrowIx(connection, ix, accountKeys);
                if (!action) {
                    return undefined;
                }
                return {
                    slot,
                    blockTime,
                    txSig: sig,
                    ixIndex: index,
                    action
                };
            })));
        // Parse inner instructions
        const compiledInnerIxs = ((_h = txRes.meta) === null || _h === void 0 ? void 0 : _h.innerInstructions) || [];
        const recordedInnerActions = yield Promise.all(compiledInnerIxs.map((compInnerIx)=>__awaiter(this, void 0, void 0, function*() {
                const innerActions = yield Promise.all(compInnerIx.instructions.map((innerIx, innerIndex)=>__awaiter(this, void 0, void 0, function*() {
                        const action = yield parseEscrowIx(connection, innerIx, accountKeys);
                        if (!action) {
                            return undefined;
                        }
                        return {
                            slot,
                            blockTime,
                            txSig: sig,
                            ixIndex: compInnerIx.index,
                            innerIxIndex: innerIndex,
                            action
                        };
                    })));
                return innerActions;
            })));
        // Combine outer and inner actions
        recordedActions.push(...recordedInnerActions.flat());
        // Filter undefined
        const filteredRecordedActions = recordedActions.filter((action)=>action !== undefined);
        return filteredRecordedActions;
    });
}
exports.parseEscrowTx = parseEscrowTx;
/**
 * @remarks Only use this on the backend for a custom parsing setup. Otherwise,
 * use `getRecordedEscrowActionsFromVault`
 * @param delay - Delay between RPC requests to avoid rate limiting
 */ function getAllRecordedEscrowActions(connection, pda, delayMs = 400) {
    return __awaiter(this, void 0, void 0, function*() {
        // Limit set to 1,000
        const totalSigInfos = [];
        let sigInfos = yield connection.getSignaturesForAddress(pda);
        while(sigInfos.length > 0){
            totalSigInfos.push(...sigInfos);
            // eslint-disable-next-line no-await-in-loop
            sigInfos = yield connection.getSignaturesForAddress(pda, {
                before: sigInfos[sigInfos.length - 1].signature
            });
        }
        const sigs = totalSigInfos.map((sigInfo)=>sigInfo.signature);
        const totalRecordedActions = [];
        for (const sig of sigs){
            // eslint-disable-next-line no-await-in-loop
            const recordedActions = yield parseEscrowTx(connection, sig);
            totalRecordedActions.push(...recordedActions);
            // eslint-disable-next-line no-await-in-loop
            yield (0, helpers_1.sleep)(delayMs);
        }
        // Sort by most recent
        totalRecordedActions.sort((a, b)=>{
            // Try slot first
            if (a.slot !== b.slot) {
                return b.slot - a.slot;
            }
            // If in the same transaction (unlikely), sort by index
            if (a.txSig !== b.txSig) {
                return b.ixIndex - a.ixIndex;
            }
            // If in the same index (unlikely), sort by inner index
            if (a.innerIxIndex !== undefined && b.innerIxIndex !== undefined) {
                return b.innerIxIndex - a.innerIxIndex;
            }
            // Otherwise (unlikely), just return 0
            // It may be possible to see the order of transactions in a block but this is
            // overkill
            return 0;
        });
        return totalRecordedActions;
    });
}
exports.getAllRecordedEscrowActions = getAllRecordedEscrowActions;
function getRecordedEscrowActionsFromVault(connection, pda) {
    return __awaiter(this, void 0, void 0, function*() {
        const res = yield fetch(`${constants_1.INDEXER_URL_BASE}/api/v1/escrow/${pda.toBase58()}`);
        const json = yield res.json();
        const { data } = json;
        const serializedRecordedActions = data.recordedEscrowActions;
        return deserializeRecordedEscrowActions(connection, serializedRecordedActions);
    });
}
exports.getRecordedEscrowActionsFromVault = getRecordedEscrowActionsFromVault;
function getRecordedEscrowActionsFromTx(connection, sig) {
    return __awaiter(this, void 0, void 0, function*() {
        const res = yield fetch(`${constants_1.INDEXER_URL_BASE}/api/v1/transaction/${sig}`);
        const json = yield res.json();
        const { data } = json;
        const serializedRecordedActions = data.recordedEscrowActions;
        return deserializeRecordedEscrowActions(connection, serializedRecordedActions);
    });
}
exports.getRecordedEscrowActionsFromTx = getRecordedEscrowActionsFromTx;
}}),
"[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/index.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getRecordedEscrowActionsFromTx = exports.getRecordedEscrowActionsFromVault = exports.deserializeRecordedEscrowActions = exports.serializeRecordedEscrowActions = exports.EscrowActionType = exports.getAllRecordedEscrowActions = exports.parseEscrowTx = exports.parseEscrowIx = exports.ESCROW_PROGRAM_ID = exports.PRIO_FEES_LAMPORTS = exports.getEscrowReceiverTipLink = exports.EscrowTipLink = void 0;
const EscrowTipLink_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/EscrowTipLink.js [app-rsc] (ecmascript)");
Object.defineProperty(exports, "EscrowTipLink", {
    enumerable: true,
    get: function() {
        return EscrowTipLink_1.EscrowTipLink;
    }
});
Object.defineProperty(exports, "getEscrowReceiverTipLink", {
    enumerable: true,
    get: function() {
        return EscrowTipLink_1.getEscrowReceiverTipLink;
    }
});
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/constants.js [app-rsc] (ecmascript)");
Object.defineProperty(exports, "PRIO_FEES_LAMPORTS", {
    enumerable: true,
    get: function() {
        return constants_1.PRIO_FEES_LAMPORTS;
    }
});
Object.defineProperty(exports, "ESCROW_PROGRAM_ID", {
    enumerable: true,
    get: function() {
        return constants_1.ESCROW_PROGRAM_ID;
    }
});
const escrow_parsing_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/escrow-parsing.js [app-rsc] (ecmascript)");
Object.defineProperty(exports, "parseEscrowIx", {
    enumerable: true,
    get: function() {
        return escrow_parsing_1.parseEscrowIx;
    }
});
Object.defineProperty(exports, "parseEscrowTx", {
    enumerable: true,
    get: function() {
        return escrow_parsing_1.parseEscrowTx;
    }
});
Object.defineProperty(exports, "getAllRecordedEscrowActions", {
    enumerable: true,
    get: function() {
        return escrow_parsing_1.getAllRecordedEscrowActions;
    }
});
Object.defineProperty(exports, "EscrowActionType", {
    enumerable: true,
    get: function() {
        return escrow_parsing_1.EscrowActionType;
    }
});
Object.defineProperty(exports, "serializeRecordedEscrowActions", {
    enumerable: true,
    get: function() {
        return escrow_parsing_1.serializeRecordedEscrowActions;
    }
});
Object.defineProperty(exports, "deserializeRecordedEscrowActions", {
    enumerable: true,
    get: function() {
        return escrow_parsing_1.deserializeRecordedEscrowActions;
    }
});
Object.defineProperty(exports, "getRecordedEscrowActionsFromVault", {
    enumerable: true,
    get: function() {
        return escrow_parsing_1.getRecordedEscrowActionsFromVault;
    }
});
Object.defineProperty(exports, "getRecordedEscrowActionsFromTx", {
    enumerable: true,
    get: function() {
        return escrow_parsing_1.getRecordedEscrowActionsFromTx;
    }
});
}}),
"[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/index.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
var _a;
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getReceiverEmail = exports.createReceiverTipLink = exports.mailEscrow = exports.mail = exports.getRecordedEscrowActionsFromTx = exports.getRecordedEscrowActionsFromVault = exports.deserializeRecordedEscrowActions = exports.serializeRecordedEscrowActions = exports.EscrowActionType = exports.getAllRecordedEscrowActions = exports.parseEscrowTx = exports.parseEscrowIx = exports.ESCROW_PROGRAM_ID = exports.PRIO_FEES_LAMPORTS = exports.getEscrowReceiverTipLink = exports.EscrowTipLink = exports.attachTheme = exports.TipLinkClient = exports.TipLink = exports.TIPLINK_ORIGIN = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-rsc] (ecmascript)");
const libsodium_wrappers_sumo_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/libsodium-wrappers-sumo@0.7.15/node_modules/libsodium-wrappers-sumo/dist/modules-sumo/libsodium-wrappers.js [app-rsc] (ecmascript)"));
const bs58_1 = __turbopack_require__("[project]/node_modules/.pnpm/bs58@5.0.0/node_modules/bs58/index.js [app-rsc] (ecmascript)");
const DEFAULT_TIPLINK_KEYLENGTH = 12;
const DEFAULT_HASHLESS_TIPLINK_KEYLENGTH = 16; // 16 bytes = 128 bits
const DEFAULT_ORIGIN = "https://tiplink.io";
exports.TIPLINK_ORIGIN = process !== undefined && process.env !== undefined ? (_a = process.env.TIPLINK_ORIGIN_OVERRIDE) !== null && _a !== void 0 ? _a : DEFAULT_ORIGIN : DEFAULT_ORIGIN;
const TIPLINK_PATH = "/i";
const VERSION_DELIMITER = "_";
const VALID_VERSIONS = new Set([
    0,
    1
]);
const getSodium = ()=>__awaiter(void 0, void 0, void 0, function*() {
        yield libsodium_wrappers_sumo_1.default.ready;
        return libsodium_wrappers_sumo_1.default;
    });
const kdf = (fullLength, pwShort, salt)=>__awaiter(void 0, void 0, void 0, function*() {
        const sodium = yield getSodium();
        return sodium.crypto_pwhash(fullLength, pwShort, salt, sodium.crypto_pwhash_OPSLIMIT_INTERACTIVE, sodium.crypto_pwhash_MEMLIMIT_INTERACTIVE, sodium.crypto_pwhash_ALG_DEFAULT);
    });
const randBuf = (l)=>__awaiter(void 0, void 0, void 0, function*() {
        const sodium = yield getSodium();
        return sodium.randombytes_buf(l);
    });
const kdfz = (fullLength, pwShort)=>__awaiter(void 0, void 0, void 0, function*() {
        const sodium = yield getSodium();
        const salt = new Uint8Array(sodium.crypto_pwhash_SALTBYTES);
        return yield kdf(fullLength, pwShort, salt);
    });
const pwToKeypair = (pw)=>__awaiter(void 0, void 0, void 0, function*() {
        const sodium = yield getSodium();
        const seed = yield kdfz(sodium.crypto_sign_SEEDBYTES, pw);
        return web3_js_1.Keypair.fromSeed(seed);
    });
const pwToKeypairV1 = (pw)=>__awaiter(void 0, void 0, void 0, function*() {
        const sodium = yield getSodium();
        const seed = sodium.pad(pw, sodium.crypto_sign_SEEDBYTES);
        return web3_js_1.Keypair.fromSeed(seed);
    });
class TipLink {
    constructor(url, keypair){
        this.url = url;
        this.keypair = keypair;
    }
    static create(version = 0) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!VALID_VERSIONS.has(version)) {
                throw Error("invalid version");
            }
            yield getSodium();
            if (version === 1) {
                const b = yield randBuf(DEFAULT_HASHLESS_TIPLINK_KEYLENGTH);
                const keypair = yield pwToKeypairV1(b);
                const hash = (0, bs58_1.encode)(b);
                const urlString = `${exports.TIPLINK_ORIGIN}${TIPLINK_PATH}#${VERSION_DELIMITER}${hash}`;
                // can't assign hash as it causes an error in React Native
                const link = new URL(urlString);
                const tiplink = new TipLink(link, keypair);
                return tiplink;
            } else {
                // version === 0
                const b = yield randBuf(DEFAULT_TIPLINK_KEYLENGTH);
                const keypair = yield pwToKeypair(b);
                const hash = (0, bs58_1.encode)(b);
                const urlString = `${exports.TIPLINK_ORIGIN}${TIPLINK_PATH}#${hash}`;
                // can't assign hash as it causes an error in React Native
                const link = new URL(urlString);
                const tiplink = new TipLink(link, keypair);
                return tiplink;
            }
        });
    }
    static fromUrl(url) {
        return __awaiter(this, void 0, void 0, function*() {
            let slug = url.hash.slice(1);
            let version = 0;
            if (slug.includes(VERSION_DELIMITER)) {
                const versionString = slug.split(VERSION_DELIMITER, 1)[0];
                if (versionString.length === 0) {
                    version = 1;
                // } else {
                // version = Number(versionString);
                }
                slug = slug.split(VERSION_DELIMITER).slice(1).join(VERSION_DELIMITER);
            }
            const pw = Uint8Array.from((0, bs58_1.decode)(slug));
            if (version === 1) {
                const keypair = yield pwToKeypairV1(pw);
                const tiplink = new TipLink(url, keypair);
                return tiplink;
            } else {
                const keypair = yield pwToKeypair(pw);
                const tiplink = new TipLink(url, keypair);
                return tiplink;
            }
        });
    }
    static fromLink(link) {
        return __awaiter(this, void 0, void 0, function*() {
            const url = new URL(link);
            return this.fromUrl(url);
        });
    }
}
exports.TipLink = TipLink;
const client_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/client.js [app-rsc] (ecmascript)");
Object.defineProperty(exports, "TipLinkClient", {
    enumerable: true,
    get: function() {
        return client_1.TipLinkClient;
    }
});
const themes_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/lib/themes.js [app-rsc] (ecmascript)");
Object.defineProperty(exports, "attachTheme", {
    enumerable: true,
    get: function() {
        return themes_1.attachTheme;
    }
});
const escrow_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/escrow/index.js [app-rsc] (ecmascript)");
Object.defineProperty(exports, "EscrowTipLink", {
    enumerable: true,
    get: function() {
        return escrow_1.EscrowTipLink;
    }
});
Object.defineProperty(exports, "getEscrowReceiverTipLink", {
    enumerable: true,
    get: function() {
        return escrow_1.getEscrowReceiverTipLink;
    }
});
Object.defineProperty(exports, "PRIO_FEES_LAMPORTS", {
    enumerable: true,
    get: function() {
        return escrow_1.PRIO_FEES_LAMPORTS;
    }
});
Object.defineProperty(exports, "ESCROW_PROGRAM_ID", {
    enumerable: true,
    get: function() {
        return escrow_1.ESCROW_PROGRAM_ID;
    }
});
Object.defineProperty(exports, "parseEscrowIx", {
    enumerable: true,
    get: function() {
        return escrow_1.parseEscrowIx;
    }
});
Object.defineProperty(exports, "parseEscrowTx", {
    enumerable: true,
    get: function() {
        return escrow_1.parseEscrowTx;
    }
});
Object.defineProperty(exports, "getAllRecordedEscrowActions", {
    enumerable: true,
    get: function() {
        return escrow_1.getAllRecordedEscrowActions;
    }
});
Object.defineProperty(exports, "EscrowActionType", {
    enumerable: true,
    get: function() {
        return escrow_1.EscrowActionType;
    }
});
Object.defineProperty(exports, "serializeRecordedEscrowActions", {
    enumerable: true,
    get: function() {
        return escrow_1.serializeRecordedEscrowActions;
    }
});
Object.defineProperty(exports, "deserializeRecordedEscrowActions", {
    enumerable: true,
    get: function() {
        return escrow_1.deserializeRecordedEscrowActions;
    }
});
Object.defineProperty(exports, "getRecordedEscrowActionsFromVault", {
    enumerable: true,
    get: function() {
        return escrow_1.getRecordedEscrowActionsFromVault;
    }
});
Object.defineProperty(exports, "getRecordedEscrowActionsFromTx", {
    enumerable: true,
    get: function() {
        return escrow_1.getRecordedEscrowActionsFromTx;
    }
});
const enclave_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/enclave.js [app-rsc] (ecmascript)");
Object.defineProperty(exports, "mail", {
    enumerable: true,
    get: function() {
        return enclave_1.mail;
    }
});
Object.defineProperty(exports, "mailEscrow", {
    enumerable: true,
    get: function() {
        return enclave_1.mailEscrow;
    }
});
Object.defineProperty(exports, "createReceiverTipLink", {
    enumerable: true,
    get: function() {
        return enclave_1.createReceiverTipLink;
    }
});
Object.defineProperty(exports, "getReceiverEmail", {
    enumerable: true,
    get: function() {
        return enclave_1.getReceiverEmail;
    }
});
}}),

};

//# sourceMappingURL=2a408_%40tiplink_api_dist_d9ecec._.js.map
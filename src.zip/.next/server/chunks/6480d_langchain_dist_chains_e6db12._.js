module.exports = {

"[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/dist/chains/llm_chain.js [app-route] (ecmascript, async loader)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__((__turbopack_import__) => {
    return Promise.all([
  "server/chunks/node_modules__pnpm_e1e330._.js",
  "server/chunks/89241_@langchain_core_dist_prompts_8acbad._.js"
].map((chunk) => __turbopack_load__(chunk))).then(() => {
        return __turbopack_import__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/dist/chains/llm_chain.js [app-route] (ecmascript)");
    });
});
}}),
"[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/dist/chains/sequential_chain.js [app-route] (ecmascript, async loader)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__((__turbopack_import__) => {
    return Promise.resolve().then(() => {
        return __turbopack_import__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/dist/chains/sequential_chain.js [app-route] (ecmascript)");
    });
});
}}),
"[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/dist/chains/combine_docs_chain.js [app-route] (ecmascript, async loader)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__((__turbopack_import__) => {
    return Promise.all([
  "server/chunks/node_modules__pnpm_bbf3d6._.js",
  "server/chunks/89241_@langchain_core_dist_prompts_5eab24._.js"
].map((chunk) => __turbopack_load__(chunk))).then(() => {
        return __turbopack_import__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/dist/chains/combine_docs_chain.js [app-route] (ecmascript)");
    });
});
}}),
"[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/dist/chains/vector_db_qa.js [app-route] (ecmascript, async loader)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__((__turbopack_import__) => {
    return Promise.all([
  "server/chunks/node_modules__pnpm_2acd4d._.js",
  "server/chunks/89241_@langchain_core_dist_prompts_e691dd._.js"
].map((chunk) => __turbopack_load__(chunk))).then(() => {
        return __turbopack_import__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/dist/chains/vector_db_qa.js [app-route] (ecmascript)");
    });
});
}}),
"[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/dist/chains/api/api_chain.js [app-route] (ecmascript, async loader)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__((__turbopack_import__) => {
    return Promise.all([
  "server/chunks/node_modules__pnpm_647b4b._.js",
  "server/chunks/89241_@langchain_core_dist_prompts_6e72f5._.js"
].map((chunk) => __turbopack_load__(chunk))).then(() => {
        return __turbopack_import__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/dist/chains/api/api_chain.js [app-route] (ecmascript)");
    });
});
}}),

};
module.exports = {

"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/Signer.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Signer = void 0;
class Signer {
    static verify(_pk, _message, _signature, _opts) {
        throw new Error("You must implement verify method on child");
    }
}
exports.Signer = Signer; //# sourceMappingURL=Signer.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SIG_CONFIG = exports.SignatureConfig = void 0;
var SignatureConfig;
(function(SignatureConfig) {
    SignatureConfig[SignatureConfig["ARWEAVE"] = 1] = "ARWEAVE";
    SignatureConfig[SignatureConfig["ED25519"] = 2] = "ED25519";
    SignatureConfig[SignatureConfig["ETHEREUM"] = 3] = "ETHEREUM";
    SignatureConfig[SignatureConfig["SOLANA"] = 4] = "SOLANA";
    SignatureConfig[SignatureConfig["INJECTEDAPTOS"] = 5] = "INJECTEDAPTOS";
    SignatureConfig[SignatureConfig["MULTIAPTOS"] = 6] = "MULTIAPTOS";
    SignatureConfig[SignatureConfig["TYPEDETHEREUM"] = 7] = "TYPEDETHEREUM";
})(SignatureConfig = exports.SignatureConfig || (exports.SignatureConfig = {}));
exports.SIG_CONFIG = {
    [SignatureConfig.ARWEAVE]: {
        sigLength: 512,
        pubLength: 512,
        sigName: "arweave"
    },
    [SignatureConfig.ED25519]: {
        sigLength: 64,
        pubLength: 32,
        sigName: "ed25519"
    },
    [SignatureConfig.ETHEREUM]: {
        sigLength: 65,
        pubLength: 65,
        sigName: "ethereum"
    },
    [SignatureConfig.SOLANA]: {
        sigLength: 64,
        pubLength: 32,
        sigName: "solana"
    },
    [SignatureConfig.INJECTEDAPTOS]: {
        sigLength: 64,
        pubLength: 32,
        sigName: "injectedAptos"
    },
    [SignatureConfig.MULTIAPTOS]: {
        sigLength: 64 * 32 + 4,
        pubLength: 32 * 32 + 1,
        sigName: "multiAptos"
    },
    [SignatureConfig.TYPEDETHEREUM]: {
        sigLength: 65,
        pubLength: 42,
        sigName: "typedEthereum"
    }
}; //# sourceMappingURL=constants.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/curve25519.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)");
const ed25519_1 = __turbopack_require__("[project]/node_modules/.pnpm/@noble+ed25519@1.7.3/node_modules/@noble/ed25519/lib/index.js [app-route] (ecmascript)");
class Curve25519 {
    get publicKey() {
        return this._publicKey;
    }
    constructor(_key, pk){
        this._key = _key;
        this.pk = pk;
        this.ownerLength = constants_1.SIG_CONFIG[2].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[2].sigLength;
        this.signatureType = 2;
    }
    get key() {
        throw new Error("You must implement `key`");
    }
    sign(message) {
        return (0, ed25519_1.sign)(Buffer.from(message), Buffer.from(this.key));
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            let p = pk;
            if (typeof pk === "string") p = base64url_1.default.toBuffer(pk);
            return (0, ed25519_1.verify)(Buffer.from(signature), Buffer.from(message), Buffer.from(p));
        });
    }
}
exports.default = Curve25519; //# sourceMappingURL=curve25519.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/deepHash.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = this && this.__asyncValues || function(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i);
    "TURBOPACK unreachable";
    function verb(n) {
        i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
                v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
        };
    }
    function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function(v) {
            resolve({
                value: v,
                done: d
            });
        }, reject);
    }
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.hashStream = exports.deepHashChunks = exports.deepHash = void 0;
// In TypeScript 3.7, could be written as a single type:
// `type DeepHashChunk = Uint8Array | DeepHashChunk[];`
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/nodeUtils.js [app-route] (ecmascript)");
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
function deepHash(data) {
    var _a, e_1, _b, _c;
    return __awaiter(this, void 0, void 0, function*() {
        if (typeof data[Symbol.asyncIterator] === "function") {
            const _data = data;
            const context = (0, crypto_1.createHash)("sha384");
            let length = 0;
            try {
                for(var _d = true, _data_1 = __asyncValues(_data), _data_1_1; _data_1_1 = yield _data_1.next(), _a = _data_1_1.done, !_a;){
                    _c = _data_1_1.value;
                    _d = false;
                    try {
                        const chunk = _c;
                        length += chunk.byteLength;
                        context.update(chunk);
                    } finally{
                        _d = true;
                    }
                }
            } catch (e_1_1) {
                e_1 = {
                    error: e_1_1
                };
            } finally{
                try {
                    if (!_d && !_a && (_b = _data_1.return)) yield _b.call(_data_1);
                } finally{
                    if (e_1) throw e_1.error;
                }
            }
            const tag = (0, utils_1.concatBuffers)([
                (0, utils_1.stringToBuffer)("blob"),
                (0, utils_1.stringToBuffer)(length.toString())
            ]);
            const taggedHash = (0, utils_1.concatBuffers)([
                (yield (0, utils_1.getCryptoDriver)().hash(tag, "SHA-384")),
                context.digest()
            ]);
            return yield (0, utils_1.getCryptoDriver)().hash(taggedHash, "SHA-384");
        } else if (Array.isArray(data)) {
            const tag = (0, utils_1.concatBuffers)([
                (0, utils_1.stringToBuffer)("list"),
                (0, utils_1.stringToBuffer)(data.length.toString())
            ]);
            return yield deepHashChunks(data, (yield (0, utils_1.getCryptoDriver)().hash(tag, "SHA-384")));
        }
        const _data = data;
        const tag = (0, utils_1.concatBuffers)([
            (0, utils_1.stringToBuffer)("blob"),
            (0, utils_1.stringToBuffer)(_data.byteLength.toString())
        ]);
        const taggedHash = (0, utils_1.concatBuffers)([
            (yield (0, utils_1.getCryptoDriver)().hash(tag, "SHA-384")),
            (yield (0, utils_1.getCryptoDriver)().hash(_data, "SHA-384"))
        ]);
        return yield (0, utils_1.getCryptoDriver)().hash(taggedHash, "SHA-384");
    });
}
exports.deepHash = deepHash;
function deepHashChunks(chunks, acc) {
    return __awaiter(this, void 0, void 0, function*() {
        if (chunks.length < 1) {
            return acc;
        }
        const hashPair = (0, utils_1.concatBuffers)([
            acc,
            (yield deepHash(chunks[0]))
        ]);
        const newAcc = yield (0, utils_1.getCryptoDriver)().hash(hashPair, "SHA-384");
        return yield deepHashChunks(chunks.slice(1), newAcc);
    });
}
exports.deepHashChunks = deepHashChunks;
function hashStream(stream) {
    var _a, stream_1, stream_1_1;
    var _b, e_2, _c, _d;
    return __awaiter(this, void 0, void 0, function*() {
        const context = (0, crypto_1.createHash)("sha384");
        try {
            for(_a = true, stream_1 = __asyncValues(stream); stream_1_1 = yield stream_1.next(), _b = stream_1_1.done, !_b;){
                _d = stream_1_1.value;
                _a = false;
                try {
                    const chunk = _d;
                    context.update(chunk);
                } finally{
                    _a = true;
                }
            }
        } catch (e_2_1) {
            e_2 = {
                error: e_2_1
            };
        } finally{
            try {
                if (!_a && !_b && (_c = stream_1.return)) yield _c.call(stream_1);
            } finally{
                if (e_2) throw e_2.error;
            }
        }
        return context.digest();
    });
}
exports.hashStream = hashStream;
exports.default = deepHash; //# sourceMappingURL=deepHash.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/nodeUtils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getCryptoDriver = exports.CryptoDriver = exports.Arweave = exports.deepHash = exports.Transaction = exports.concatBuffers = exports.stringToBuffer = void 0;
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
const node_driver_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/node-driver.js [app-route] (ecmascript)"));
// import CryptoInterface from "arweave/node/lib/crypto/crypto-interface";
var utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/utils.js [app-route] (ecmascript)");
Object.defineProperty(exports, "stringToBuffer", {
    enumerable: true,
    get: function() {
        return utils_1.stringToBuffer;
    }
});
Object.defineProperty(exports, "concatBuffers", {
    enumerable: true,
    get: function() {
        return utils_1.concatBuffers;
    }
});
var transaction_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/transaction.js [app-route] (ecmascript)");
Object.defineProperty(exports, "Transaction", {
    enumerable: true,
    get: function() {
        return __importDefault(transaction_1).default;
    }
});
var deepHash_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/deepHash.js [app-route] (ecmascript)");
Object.defineProperty(exports, "deepHash", {
    enumerable: true,
    get: function() {
        return deepHash_1.deepHash;
    }
});
var node_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/index.js [app-route] (ecmascript)");
Object.defineProperty(exports, "Arweave", {
    enumerable: true,
    get: function() {
        return __importDefault(node_1).default;
    }
});
// hack as ESM won't unpack .default CJS imports, so we do so dynamically
// eslint-disable-next-line @typescript-eslint/dot-notation
const driver = node_driver_1.default["default"] ? node_driver_1.default["default"] : node_driver_1.default;
class CryptoDriver extends driver {
    getPublicKey(jwk) {
        return (0, crypto_1.createPublicKey)({
            key: this.jwkToPem(jwk),
            type: "pkcs1",
            format: "pem"
        }).export({
            format: "pem",
            type: "pkcs1"
        }).toString();
    }
}
exports.CryptoDriver = CryptoDriver;
let driverInstance;
function getCryptoDriver() {
    return driverInstance !== null && driverInstance !== void 0 ? driverInstance : driverInstance = new CryptoDriver();
}
exports.getCryptoDriver = getCryptoDriver; //# sourceMappingURL=nodeUtils.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/Rsa4096Pss.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/nodeUtils.js [app-route] (ecmascript)");
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)");
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
class Rsa4096Pss {
    get publicKey() {
        return this._publicKey;
    }
    constructor(_key, pk){
        this._key = _key;
        this.pk = pk;
        this.signatureType = 1;
        this.ownerLength = constants_1.SIG_CONFIG[1].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[1].sigLength;
        if (!pk) {
            this.pk = (0, utils_1.getCryptoDriver)().getPublicKey(JSON.parse(_key));
        }
    }
    sign(message) {
        return (0, crypto_1.createSign)("sha256").update(message).sign({
            key: this._key,
            padding: crypto_1.constants.RSA_PKCS1_PSS_PADDING
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            return yield (0, utils_1.getCryptoDriver)().verify(Buffer.isBuffer(pk) ? base64url_1.default.encode(pk) : pk, message, signature);
        });
    }
}
exports.default = Rsa4096Pss; //# sourceMappingURL=Rsa4096Pss.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/ArweaveSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const Rsa4096Pss_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/Rsa4096Pss.js [app-route] (ecmascript)"));
const pem_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/crypto/pem.js [app-route] (ecmascript)");
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/nodeUtils.js [app-route] (ecmascript)");
class ArweaveSigner extends Rsa4096Pss_1.default {
    constructor(jwk){
        super((0, pem_1.jwkTopem)(jwk), jwk.n);
        this.jwk = jwk;
    }
    get publicKey() {
        if (!this.pk) throw new Error("ArweaveSigner - pk is undefined");
        return base64url_1.default.toBuffer(this.pk);
    }
    sign(message) {
        return (0, utils_1.getCryptoDriver)().sign(this.jwk, message);
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            return yield (0, utils_1.getCryptoDriver)().verify(pk, message, signature);
        });
    }
}
exports.default = ArweaveSigner; //# sourceMappingURL=ArweaveSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/injectedSolanaSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)");
const ed25519_1 = __turbopack_require__("[project]/node_modules/.pnpm/@noble+ed25519@1.7.3/node_modules/@noble/ed25519/lib/index.js [app-route] (ecmascript)");
class InjectedSolanaSigner {
    constructor(provider){
        this.ownerLength = constants_1.SIG_CONFIG[2].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[2].sigLength;
        this.signatureType = 2;
        this.provider = provider;
        if (!this.provider.publicKey) throw new Error("InjectedSolanaSigner - provider.publicKey is undefined");
        this._publicKey = this.provider.publicKey.toBuffer();
    }
    get publicKey() {
        return this._publicKey;
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!this.provider.signMessage) throw new Error("Selected Wallet does not support message signing");
            return yield this.provider.signMessage(message);
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            let p = pk;
            if (typeof pk === "string") p = base64url_1.default.toBuffer(pk);
            return (0, ed25519_1.verify)(Buffer.from(signature), Buffer.from(message), Buffer.from(p));
        });
    }
}
exports.default = InjectedSolanaSigner; //# sourceMappingURL=injectedSolanaSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/injectedEthereumSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.InjectedEthereumSigner = void 0;
const hash_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+hash@5.7.0/node_modules/@ethersproject/hash/lib.esm/index.js [app-route] (ecmascript)");
const signing_key_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+signing-key@5.7.0/node_modules/@ethersproject/signing-key/lib.esm/index.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)");
const bytes_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+bytes@5.7.0/node_modules/@ethersproject/bytes/lib.esm/index.js [app-route] (ecmascript)");
const transactions_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+transactions@5.7.0/node_modules/@ethersproject/transactions/lib.esm/index.js [app-route] (ecmascript)");
const wallet_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+wallet@5.7.0/node_modules/@ethersproject/wallet/lib.esm/index.js [app-route] (ecmascript)");
class InjectedEthereumSigner {
    constructor(provider){
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.ETHEREUM].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.ETHEREUM].sigLength;
        this.signatureType = constants_1.SignatureConfig.ETHEREUM;
        this.signer = provider.getSigner();
    }
    setPublicKey() {
        return __awaiter(this, void 0, void 0, function*() {
            const address = "sign this message to connect to Bundlr.Network";
            const signedMsg = yield this.signer.signMessage(address);
            const hash = yield (0, hash_1.hashMessage)(address);
            const recoveredKey = (0, signing_key_1.recoverPublicKey)((0, bytes_1.arrayify)(hash), signedMsg);
            this.publicKey = Buffer.from((0, bytes_1.arrayify)(recoveredKey));
        });
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!this.publicKey) {
                yield this.setPublicKey();
            }
            const sig = yield this.signer.signMessage(message);
            return Buffer.from(sig.slice(2), "hex");
        });
    }
    static verify(pk, message, signature) {
        const address = (0, transactions_1.computeAddress)(pk);
        return (0, wallet_1.verifyMessage)(message, signature) === address;
    }
}
exports.InjectedEthereumSigner = InjectedEthereumSigner;
exports.default = InjectedEthereumSigner; //# sourceMappingURL=injectedEthereumSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/SolanaSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const curve25519_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/curve25519.js [app-route] (ecmascript)"));
const bs58_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bs58@4.0.1/node_modules/bs58/index.js [app-route] (ecmascript)"));
class SolanaSigner extends curve25519_1.default {
    get publicKey() {
        return bs58_1.default.decode(this.pk);
    }
    get key() {
        return bs58_1.default.decode(this._key);
    }
    constructor(_key){
        const b = bs58_1.default.decode(_key);
        super(bs58_1.default.encode(b.subarray(0, 32)), bs58_1.default.encode(b.subarray(32, 64)));
    }
}
exports.default = SolanaSigner; //# sourceMappingURL=SolanaSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keccak256.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.exportForTesting = exports.keccak256 = void 0;
/* eslint-disable @typescript-eslint/explicit-function-return-type */ const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const buffer_1 = __turbopack_require__("[externals]/buffer [external] (buffer, cjs)");
const keccak_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/keccak@3.0.4/node_modules/keccak/index.js [app-route] (ecmascript)"));
function keccak256(value) {
    value = toBuffer(value);
    return (0, keccak_1.default)("keccak256").update(value).digest();
}
exports.keccak256 = keccak256;
function toBuffer(value) {
    if (!buffer_1.Buffer.isBuffer(value)) {
        if (Array.isArray(value)) {
            value = buffer_1.Buffer.from(value);
        } else if (typeof value === "string") {
            if (isHexString(value)) {
                value = buffer_1.Buffer.from(padToEven(stripHexPrefix(value)), "hex");
            } else {
                value = buffer_1.Buffer.from(value);
            }
        } else if (typeof value === "number") {
            value = intToBuffer(value);
        } else if (value === null || value === undefined) {
            value = buffer_1.Buffer.allocUnsafe(0);
        } else if (bn_js_1.default.isBN(value)) {
            value = value.toArrayLike(buffer_1.Buffer);
        } else if (value.toArray) {
            // converts a BN to a Buffer
            value = buffer_1.Buffer.from(value.toArray());
        } else {
            throw new Error("invalid type");
        }
    }
    return value;
}
function isHexString(value, length) {
    if (typeof value !== "string" || !value.match(/^0x[0-9A-Fa-f]*$/)) {
        return false;
    }
    if (length && value.length !== 2 + 2 * length) {
        return false;
    }
    return true;
}
function padToEven(value) {
    if (typeof value !== "string") {
        throw new Error(`while padding to even, value must be string, is currently ${typeof value}, while padToEven.`);
    }
    if (value.length % 2) {
        value = `0${value}`;
    }
    return value;
}
function stripHexPrefix(value) {
    if (typeof value !== "string") {
        return value;
    }
    return isHexPrefixed(value) ? value.slice(2) : value;
}
function isHexPrefixed(value) {
    if (typeof value !== "string") {
        throw new Error("value must be type 'string', is currently type " + typeof value + ", while checking isHexPrefixed.");
    }
    return value.startsWith("0x");
}
function intToBuffer(i) {
    const hex = intToHex(i);
    return buffer_1.Buffer.from(padToEven(hex.slice(2)), "hex");
}
function intToHex(i) {
    const hex = i.toString(16);
    return `0x${hex}`;
}
if ("TURBOPACK compile-time falsy", 0) {
    "TURBOPACK unreachable";
}
exports.default = keccak256;
exports.exportForTesting = {
    intToBuffer,
    intToHex,
    isHexPrefixed,
    stripHexPrefix,
    padToEven,
    isHexString,
    toBuffer
}; //# sourceMappingURL=keccak256.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/secp256k1.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const secp256k1_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/secp256k1@5.0.1/node_modules/secp256k1/index.js [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)");
const keccak256_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keccak256.js [app-route] (ecmascript)"));
class Secp256k1 {
    constructor(_key, pk){
        this._key = _key;
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.ETHEREUM].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.ETHEREUM].sigLength;
        this.signatureType = constants_1.SignatureConfig.ETHEREUM;
        this.pk = pk.toString("hex");
    }
    get publicKey() {
        throw new Error("You must implement `publicKey`");
    }
    get key() {
        return Buffer.from(this._key, "hex");
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            let p = pk;
            if (typeof pk === "string") p = base64url_1.default.toBuffer(pk);
            let verified = false;
            try {
                verified = secp256k1_1.default.ecdsaVerify(signature, (0, keccak256_1.default)(Buffer.from(message)), p);
            // eslint-disable-next-line no-empty
            } catch (e) {}
            return verified;
        });
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            return secp256k1_1.default.ecdsaSign((0, keccak256_1.default)(Buffer.from(message)), Buffer.from(this.key)).signature;
        });
    }
}
exports.default = Secp256k1; //# sourceMappingURL=secp256k1.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/ethereumSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const secp256k1_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/secp256k1.js [app-route] (ecmascript)"));
const secp256k1_2 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/secp256k1@5.0.1/node_modules/secp256k1/index.js [app-route] (ecmascript)"));
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const bytes_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+bytes@5.7.0/node_modules/@ethersproject/bytes/lib.esm/index.js [app-route] (ecmascript)");
const wallet_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+wallet@5.7.0/node_modules/@ethersproject/wallet/lib.esm/index.js [app-route] (ecmascript)");
const hash_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+hash@5.7.0/node_modules/@ethersproject/hash/lib.esm/index.js [app-route] (ecmascript)");
class EthereumSigner extends secp256k1_1.default {
    get publicKey() {
        return Buffer.from(this.pk, "hex");
    }
    constructor(key){
        if (key.startsWith("0x")) key = key.slice(2);
        const b = Buffer.from(key, "hex");
        const pub = secp256k1_2.default.publicKeyCreate(b, false);
        super(key, Buffer.from(pub));
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            const wallet = new wallet_1.Wallet(this._key);
            return wallet.signMessage(message).then((r)=>Buffer.from(r.slice(2), "hex"));
        // below doesn't work due to lacking correct v derivation.
        // return Buffer.from(joinSignature(Buffer.from(secp256k1.ecdsaSign(arrayify(hashMessage(message)), this.key).signature)).slice(2), "hex");
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            // const address = ethers.utils.computeAddress(pk);
            // return ethers.utils.verifyMessage(message, signature) === address;
            return secp256k1_2.default.ecdsaVerify(signature.length === 65 ? signature.slice(0, -1) : signature, (0, bytes_1.arrayify)((0, hash_1.hashMessage)(message)), typeof pk === "string" ? base64url_1.default.toBuffer(pk) : pk);
        });
    }
}
exports.default = EthereumSigner; //# sourceMappingURL=ethereumSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/PolygonSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const ethereumSigner_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/ethereumSigner.js [app-route] (ecmascript)"));
class PolygonSigner extends ethereumSigner_1.default {
}
exports.default = PolygonSigner; //# sourceMappingURL=PolygonSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/NearSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const SolanaSigner_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/SolanaSigner.js [app-route] (ecmascript)"));
class NearSigner extends SolanaSigner_1.default {
    constructor(_key){
        super(_key.replace("ed25519:", ""));
    }
}
exports.default = NearSigner; //# sourceMappingURL=NearSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/AlgorandSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const curve25519_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/curve25519.js [app-route] (ecmascript)"));
class AlgorandSigner extends curve25519_1.default {
    get publicKey() {
        return Buffer.from(this.pk);
    }
    get key() {
        return Buffer.from(this._key);
    }
    constructor(key, pk){
        super(key.subarray(0, 32), pk);
    }
}
exports.default = AlgorandSigner; //# sourceMappingURL=AlgorandSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/HexInjectedSolanaSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const injectedSolanaSigner_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/injectedSolanaSigner.js [app-route] (ecmascript)"));
class HexSolanaSigner extends injectedSolanaSigner_1.default {
    constructor(provider){
        super(provider);
        this.signatureType = 4; // for solana sig type
    }
    sign(message) {
        const _super = Object.create(null, {
            sign: {
                get: ()=>super.sign
            }
        });
        return __awaiter(this, void 0, void 0, function*() {
            return _super.sign.call(this, Buffer.from(Buffer.from(message).toString("hex")));
        });
    }
    static verify(pk, message, signature) {
        const _super = Object.create(null, {
            verify: {
                get: ()=>super.verify
            }
        });
        return __awaiter(this, void 0, void 0, function*() {
            return _super.verify.call(this, pk, Buffer.from(Buffer.from(message).toString("hex")), signature);
        });
    }
}
exports.default = HexSolanaSigner; //# sourceMappingURL=HexInjectedSolanaSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/HexSolanaSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const SolanaSigner_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/SolanaSigner.js [app-route] (ecmascript)"));
class HexSolanaSigner extends SolanaSigner_1.default {
    constructor(provider){
        super(provider);
        this.signatureType = 4; // for solana sig type
    }
    sign(message) {
        const _super = Object.create(null, {
            sign: {
                get: ()=>super.sign
            }
        });
        return __awaiter(this, void 0, void 0, function*() {
            return _super.sign.call(this, Buffer.from(Buffer.from(message).toString("hex")));
        });
    }
    static verify(pk, message, signature) {
        const _super = Object.create(null, {
            verify: {
                get: ()=>super.verify
            }
        });
        return __awaiter(this, void 0, void 0, function*() {
            return _super.verify.call(this, pk, Buffer.from(Buffer.from(message).toString("hex")), signature);
        });
    }
}
exports.default = HexSolanaSigner; //# sourceMappingURL=HexSolanaSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/AptosSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const curve25519_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/curve25519.js [app-route] (ecmascript)"));
class AptosSigner extends curve25519_1.default {
    constructor(privKey, pubKey){
        super(privKey, pubKey);
    }
    get publicKey() {
        return Buffer.from(this.pk.slice(2), "hex");
    }
    get key() {
        return Buffer.from(this._key.slice(2), "hex");
    }
}
exports.default = AptosSigner; //# sourceMappingURL=AptosSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/InjectedAptosSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const ed25519_1 = __turbopack_require__("[project]/node_modules/.pnpm/@noble+ed25519@1.7.3/node_modules/@noble/ed25519/lib/index.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)");
class InjectedAptosSigner {
    constructor(provider, publicKey){
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.INJECTEDAPTOS].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.INJECTEDAPTOS].sigLength;
        this.signatureType = constants_1.SignatureConfig.INJECTEDAPTOS;
        this.provider = provider;
        this._publicKey = publicKey;
    }
    get publicKey() {
        return this._publicKey;
    }
    /**
     * signMessage constructs a message and then signs it.
     * the format is "APTOS(\n)
     * message: <hexString>(\n)
     * nonce: bundlr"
     */ sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!this.provider.signMessage) throw new Error("Selected Wallet does not support message signing");
            const signingResponse = yield this.provider.signMessage({
                message: Buffer.from(message).toString("hex"),
                nonce: "bundlr"
            });
            const signature = signingResponse.signature;
            return typeof signature === "string" ? Buffer.from(signature, "hex") : signature.data.toUint8Array();
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            const p = pk;
            return (0, ed25519_1.verify)(Buffer.from(signature), Buffer.from(`APTOS\nmessage: ${Buffer.from(message).toString("hex")}\nnonce: bundlr`), Buffer.from(p));
        });
    }
}
exports.default = InjectedAptosSigner; //# sourceMappingURL=InjectedAptosSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/multiSignatureAptos.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const ed25519_1 = __turbopack_require__("[project]/node_modules/.pnpm/@noble+ed25519@1.7.3/node_modules/@noble/ed25519/lib/index.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)");
class MultiSignatureAptosSigner {
    constructor(publicKey, collectSignatures){
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.MULTIAPTOS].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.MULTIAPTOS].sigLength;
        this.signatureType = constants_1.SignatureConfig.MULTIAPTOS;
        this._publicKey = publicKey;
        this.collectSignatures = collectSignatures;
    }
    get publicKey() {
        return this._publicKey;
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            const { signatures, bitmap: bits } = yield this.collectSignatures(message);
            // Bits are read from left to right. e.g. 0b10000000 represents the first bit is set in one byte.
            // The decimal value of 0b10000000 is 128.
            const firstBitInByte = 128;
            const bitmap = new Uint8Array([
                0,
                0,
                0,
                0
            ]);
            // Check if duplicates exist in bits
            const dupCheckSet = new Set();
            bits.forEach((bit)=>{
                if (bit >= 32) {
                    throw new Error(`Invalid bit value ${bit}.`);
                }
                if (dupCheckSet.has(bit)) {
                    throw new Error("Duplicated bits detected.");
                }
                dupCheckSet.add(bit);
                const byteOffset = Math.floor(bit / 8);
                let byte = bitmap[byteOffset];
                byte |= firstBitInByte >> bit % 8;
                bitmap[byteOffset] = byte;
            });
            const signature = Buffer.alloc(this.signatureLength);
            let sigPos = 0;
            for(let i = 0; i < 32; i++){
                if (bits.includes(i)) {
                    signature.set(signatures[sigPos++], i * 64);
                }
            }
            signature.set(bitmap, this.signatureLength - 4);
            return signature;
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            const signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.MULTIAPTOS].sigLength;
            const bitmapPos = signatureLength - 4;
            const signatures = signature.slice(0, bitmapPos);
            const encodedBitmap = signature.slice(bitmapPos);
            let oneFalse = false;
            for(let i = 0; i < 32; i++){
                // check bitmap
                const bucket = Math.floor(i / 8);
                const bucketPos = i - bucket * 8;
                const sigIncluded = (encodedBitmap[bucket] & 128 >> bucketPos) !== 0;
                if (sigIncluded) {
                    const signature = signatures.slice(i * 64, (i + 1) * 64);
                    const pubkey = pk.slice(i * 32, (i + 1) * 32);
                    if (!(yield (0, ed25519_1.verify)(Buffer.from(signature), Buffer.from(message), Buffer.from(pubkey)))) oneFalse = true;
                }
            }
            return !oneFalse;
        });
    }
}
exports.default = MultiSignatureAptosSigner; //# sourceMappingURL=multiSignatureAptos.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/TypedEthereumSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DOMAIN = exports.MESSAGE = exports.types = exports.domain = void 0;
const wallet_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+wallet@5.7.0/node_modules/@ethersproject/wallet/lib.esm/index.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)");
const keccak256_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keccak256.js [app-route] (ecmascript)"));
const ethereumSigner_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/ethereumSigner.js [app-route] (ecmascript)"));
class TypedEthereumSigner extends ethereumSigner_1.default {
    constructor(key){
        super(key);
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.TYPEDETHEREUM].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.TYPEDETHEREUM].sigLength;
        this.signatureType = constants_1.SignatureConfig.TYPEDETHEREUM;
        this.address = "0x" + (0, keccak256_1.default)(super.publicKey.slice(1)).slice(-20).toString("hex");
        this.signer = new wallet_1.Wallet(key);
    }
    get publicKey() {
        return Buffer.from(this.address);
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            const signature = yield this.signer._signTypedData(exports.domain, exports.types, {
                address: this.address,
                "Transaction hash": message
            });
            return Buffer.from(signature.slice(2), "hex"); // trim leading 0x, convert to hex.
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            const address = pk.toString();
            const addr = (0, wallet_1.verifyTypedData)(exports.domain, exports.types, {
                address,
                "Transaction hash": message
            }, signature);
            return address.toLowerCase() === addr.toLowerCase();
        });
    }
}
exports.default = TypedEthereumSigner;
exports.domain = {
    name: "Bundlr",
    version: "1"
};
exports.types = {
    Bundlr: [
        {
            name: "Transaction hash",
            type: "bytes"
        },
        {
            name: "address",
            type: "address"
        }
    ]
};
exports.MESSAGE = "Bundlr(bytes Transaction hash, address address)";
exports.DOMAIN = "EIP712Domain(string name,string version)"; //# sourceMappingURL=TypedEthereumSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/InjectedTypedEthereumSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.InjectedTypedEthereumSigner = void 0;
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)");
const wallet_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+wallet@5.7.0/node_modules/@ethersproject/wallet/lib.esm/index.js [app-route] (ecmascript)");
const TypedEthereumSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/TypedEthereumSigner.js [app-route] (ecmascript)");
class InjectedTypedEthereumSigner {
    constructor(provider){
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.TYPEDETHEREUM].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.TYPEDETHEREUM].sigLength;
        this.signatureType = constants_1.SignatureConfig.TYPEDETHEREUM;
        this.signer = provider.getSigner();
    }
    ready() {
        return __awaiter(this, void 0, void 0, function*() {
            this.address = (yield this.signer.getAddress()).toString().toLowerCase();
            this.publicKey = Buffer.from(this.address); // pk *is* address
        });
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            const signature = yield this.signer._signTypedData(TypedEthereumSigner_1.domain, TypedEthereumSigner_1.types, {
                address: this.address,
                "Transaction hash": message
            });
            return Buffer.from(signature.slice(2), "hex"); // trim leading 0x, convert to hex.
        });
    }
    static verify(pk, message, signature) {
        const address = pk.toString();
        const addr = (0, wallet_1.verifyTypedData)(TypedEthereumSigner_1.domain, TypedEthereumSigner_1.types, {
            address,
            "Transaction hash": message
        }, signature);
        return address.toLowerCase() === addr.toLowerCase();
    }
}
exports.InjectedTypedEthereumSigner = InjectedTypedEthereumSigner;
exports.default = InjectedTypedEthereumSigner; //# sourceMappingURL=InjectedTypedEthereumSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/arconnectSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)");
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/nodeUtils.js [app-route] (ecmascript)");
class InjectedArweaveSigner {
    constructor(windowArweaveWallet, arweave){
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.ARWEAVE].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.ARWEAVE].sigLength;
        this.signatureType = constants_1.SignatureConfig.ARWEAVE;
        this.signer = windowArweaveWallet;
        this.arweave = arweave;
    }
    setPublicKey() {
        return __awaiter(this, void 0, void 0, function*() {
            const arOwner = yield this.signer.getActivePublicKey();
            this.publicKey = base64url_1.default.toBuffer(arOwner);
        });
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!this.publicKey) {
                yield this.setPublicKey();
            }
            const algorithm = {
                name: "RSA-PSS",
                saltLength: 32
            };
            const signature = yield this.signer.signature(message, algorithm);
            const buf = new Uint8Array(Object.values(signature).map((v)=>+v));
            return buf;
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            return yield (0, utils_1.getCryptoDriver)().verify(pk, message, signature);
        });
    }
}
exports.default = InjectedArweaveSigner; //# sourceMappingURL=arconnectSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ArconnectSigner = exports.TypedEthereumSigner = exports.MultiSignatureAptosSigner = exports.InjectedAptosSigner = exports.AptosSigner = exports.HexSolanaSigner = exports.HexInjectedSolanaSigner = exports.AlgorandSigner = exports.EthereumSigner = exports.NearSigner = exports.PolygonSigner = exports.SolanaSigner = exports.InjectedSolanaSigner = exports.ArweaveSigner = void 0;
var ArweaveSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/ArweaveSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "ArweaveSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(ArweaveSigner_1).default;
    }
});
var injectedSolanaSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/injectedSolanaSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "InjectedSolanaSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(injectedSolanaSigner_1).default;
    }
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/injectedEthereumSigner.js [app-route] (ecmascript)"), exports);
var SolanaSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/SolanaSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "SolanaSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(SolanaSigner_1).default;
    }
});
var PolygonSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/PolygonSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "PolygonSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(PolygonSigner_1).default;
    }
});
var NearSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/NearSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "NearSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(NearSigner_1).default;
    }
});
var ethereumSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/ethereumSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "EthereumSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(ethereumSigner_1).default;
    }
});
var AlgorandSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/AlgorandSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "AlgorandSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(AlgorandSigner_1).default;
    }
});
var HexInjectedSolanaSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/HexInjectedSolanaSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "HexInjectedSolanaSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(HexInjectedSolanaSigner_1).default;
    }
});
var HexSolanaSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/HexSolanaSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "HexSolanaSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(HexSolanaSigner_1).default;
    }
});
var AptosSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/AptosSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "AptosSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(AptosSigner_1).default;
    }
});
var InjectedAptosSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/InjectedAptosSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "InjectedAptosSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(InjectedAptosSigner_1).default;
    }
});
var multiSignatureAptos_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/multiSignatureAptos.js [app-route] (ecmascript)");
Object.defineProperty(exports, "MultiSignatureAptosSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(multiSignatureAptos_1).default;
    }
});
var TypedEthereumSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/TypedEthereumSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "TypedEthereumSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(TypedEthereumSigner_1).default;
    }
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/InjectedTypedEthereumSigner.js [app-route] (ecmascript)"), exports);
var arconnectSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/arconnectSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "ArconnectSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(arconnectSigner_1).default;
    }
}); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/constants.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.indexToType = void 0;
const curve25519_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/curve25519.js [app-route] (ecmascript)"));
const index_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/index.js [app-route] (ecmascript)");
exports.indexToType = {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    1: index_1.ArweaveSigner,
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    2: curve25519_1.default,
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    3: index_1.EthereumSigner,
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    4: index_1.HexInjectedSolanaSigner,
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    5: index_1.InjectedAptosSigner,
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    6: index_1.MultiSignatureAptosSigner,
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    7: index_1.TypedEthereumSigner
}; //# sourceMappingURL=constants.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.secp256k1 = exports.Rsa4096 = exports.Curve25519 = void 0;
var curve25519_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/curve25519.js [app-route] (ecmascript)");
Object.defineProperty(exports, "Curve25519", {
    enumerable: true,
    get: function() {
        return __importDefault(curve25519_1).default;
    }
});
var Rsa4096Pss_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/Rsa4096Pss.js [app-route] (ecmascript)");
Object.defineProperty(exports, "Rsa4096", {
    enumerable: true,
    get: function() {
        return __importDefault(Rsa4096Pss_1).default;
    }
});
var secp256k1_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/secp256k1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "secp256k1", {
    enumerable: true,
    get: function() {
        return __importDefault(secp256k1_1).default;
    }
}); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/Signer.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/constants.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keys/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/chains/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/keccak256.js [app-route] (ecmascript)"), exports); // TODO: just use ethers bundled ver
 //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/ar-data-base.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/nodeUtils.js [app-route] (ecmascript)");
function getSignatureData(item) {
    return __awaiter(this, void 0, void 0, function*() {
        return (0, utils_1.deepHash)([
            (0, utils_1.stringToBuffer)("dataitem"),
            (0, utils_1.stringToBuffer)("1"),
            (0, utils_1.stringToBuffer)(item.signatureType.toString()),
            item.rawOwner,
            item.rawTarget,
            item.rawAnchor,
            item.rawTags,
            item.rawData
        ]);
    });
}
exports.default = getSignatureData; //# sourceMappingURL=ar-data-base.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.byteArrayToLong = exports.longTo32ByteArray = exports.longTo16ByteArray = exports.shortTo2ByteArray = exports.longTo8ByteArray = exports.longToNByteArray = void 0;
function longToNByteArray(N, long) {
    const byteArray = new Uint8Array(N);
    if (long < 0) throw new Error("Array is unsigned, cannot represent -ve numbers");
    if (long > Math.pow(2, N * 8) - 1) throw new Error(`Number ${long} is too large for an array of ${N} bytes`);
    for(let index = 0; index < byteArray.length; index++){
        const byte = long & 0xff;
        byteArray[index] = byte;
        long = (long - byte) / 256;
    }
    return byteArray;
}
exports.longToNByteArray = longToNByteArray;
function longTo8ByteArray(long) {
    return longToNByteArray(8, long);
}
exports.longTo8ByteArray = longTo8ByteArray;
function shortTo2ByteArray(short) {
    return longToNByteArray(2, short);
}
exports.shortTo2ByteArray = shortTo2ByteArray;
function longTo16ByteArray(long) {
    return longToNByteArray(16, long);
}
exports.longTo16ByteArray = longTo16ByteArray;
function longTo32ByteArray(long) {
    return longToNByteArray(32, long);
}
exports.longTo32ByteArray = longTo32ByteArray;
function byteArrayToLong(byteArray) {
    let value = 0;
    for(let i = byteArray.length - 1; i >= 0; i--){
        value = value * 256 + byteArray[i];
    }
    return value;
}
exports.byteArrayToLong = byteArrayToLong; // this is bugged for comparing buffers
 // export function arraybufferEqual(buf1: Uint8Array, buf2: Uint8Array): boolean {
 //   const _buf1 = buf1.buffer;
 //   const _buf2 = buf2.buffer;
 //   if (_buf1 === _buf2) {
 //     return true;
 //   }
 //   if (_buf1.byteLength !== _buf2.byteLength) {
 //     return false;
 //   }
 //   const view1 = new DataView(_buf1);
 //   const view2 = new DataView(_buf2);
 //   let i = _buf1.byteLength;
 //   while (i--) {
 //     if (view1.getUint8(i) !== view2.getUint8(i)) {
 //       return false;
 //     }
 //   }
 //   return true;
 // }
 // // @ts-expect-error These variables are defined in extension environments
 // const isExtension = typeof browser !== "undefined" || typeof chrome !== "undefined";
 //# sourceMappingURL=utils.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/tags.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.deserializeTags = exports.serializeTags = exports.AVSCTap = void 0;
const DataItem_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/DataItem.js [app-route] (ecmascript)");
class AVSCTap {
    constructor(buf = Buffer.alloc(DataItem_1.MAX_TAG_BYTES), pos = 0){
        this.buf = buf;
        this.pos = pos;
    }
    writeTags(tags) {
        if (!Array.isArray(tags)) {
            throw new Error("input must be array");
        }
        const n = tags.length;
        let i;
        if (n) {
            this.writeLong(n);
            for(i = 0; i < n; i++){
                // for this use case, assume tags/strings.
                const tag = tags[i];
                if (typeof (tag === null || tag === void 0 ? void 0 : tag.name) !== "string" || typeof (tag === null || tag === void 0 ? void 0 : tag.value) !== "string") throw new Error(`Invalid tag format for ${tag}, expected {name:string, value: string}`);
                this.writeString(tag.name);
                this.writeString(tag.value);
            // this.itemsType._write(tap, val[i]);
            }
        }
        this.writeLong(0);
    }
    toBuffer() {
        const buffer = Buffer.alloc(this.pos);
        if (this.pos > this.buf.length) throw new Error(`Too many tag bytes (${this.pos} > ${this.buf.length})`);
        this.buf.copy(buffer, 0, 0, this.pos);
        return buffer;
    }
    writeLong(n) {
        const buf = this.buf;
        let f, m;
        if (n >= -1073741824 && n < 1073741824) {
            // Won't overflow, we can use integer arithmetic.
            m = n >= 0 ? n << 1 : ~n << 1 | 1;
            do {
                buf[this.pos] = m & 0x7f;
                m >>= 7;
            }while (m && (buf[this.pos++] |= 0x80))
        } else {
            // We have to use slower floating arithmetic.
            f = n >= 0 ? n * 2 : -n * 2 - 1;
            do {
                buf[this.pos] = f & 0x7f;
                f /= 128;
            }while (f >= 1 && (buf[this.pos++] |= 0x80))
        }
        this.pos++;
        this.buf = buf;
    }
    // for some reason using setters/getters with ++ doesn't work right.
    // set pos(newPos: number) {
    //   const d = newPos + 1 - this.buf.length;
    //   if (d > 0) this.buf = Buffer.concat([this.buf, Buffer.alloc(d)]);
    //   this._pos = newPos;
    // }
    // get pos(): number {
    //   return this._pos;
    // }
    // protected safeRead(position): number {
    //   return position > this.buf.length ? 0 : this.buf[position];
    // }
    // protected safeWrite(position, value): Buffer {
    //   if (position > this.buf.length) this.buf = Buffer.concat([this.buf, Buffer.alloc(1)]);
    //   this.buf[position] = value;
    //   return this.buf;
    // }
    writeString(s) {
        const len = Buffer.byteLength(s);
        const buf = this.buf;
        this.writeLong(len);
        let pos = this.pos;
        this.pos += len;
        if (this.pos > buf.length) {
            return;
        }
        if (len > 64) {
            // this._writeUtf8(s, len);
            this.buf.write(s, this.pos - len, len, "utf8");
        } else {
            let i, l, c1, c2;
            for(i = 0, l = len; i < l; i++){
                c1 = s.charCodeAt(i);
                if (c1 < 0x80) {
                    buf[pos++] = c1;
                } else if (c1 < 0x800) {
                    buf[pos++] = c1 >> 6 | 0xc0;
                    buf[pos++] = c1 & 0x3f | 0x80;
                } else if ((c1 & 0xfc00) === 0xd800 && ((c2 = s.charCodeAt(i + 1)) & 0xfc00) === 0xdc00) {
                    c1 = 0x10000 + ((c1 & 0x03ff) << 10) + (c2 & 0x03ff);
                    i++;
                    buf[pos++] = c1 >> 18 | 0xf0;
                    buf[pos++] = c1 >> 12 & 0x3f | 0x80;
                    buf[pos++] = c1 >> 6 & 0x3f | 0x80;
                    buf[pos++] = c1 & 0x3f | 0x80;
                } else {
                    buf[pos++] = c1 >> 12 | 0xe0;
                    buf[pos++] = c1 >> 6 & 0x3f | 0x80;
                    buf[pos++] = c1 & 0x3f | 0x80;
                }
            }
        }
        this.buf = buf;
    }
    readLong() {
        let n = 0;
        let k = 0;
        const buf = this.buf;
        let b, h, f, fk;
        do {
            b = buf[this.pos++];
            h = b & 0x80;
            n |= (b & 0x7f) << k;
            k += 7;
        }while (h && k < 28)
        if (h) {
            // Switch to float arithmetic, otherwise we might overflow.
            f = n;
            fk = 268435456; // 2 ** 28.
            do {
                b = buf[this.pos++];
                f += (b & 0x7f) * fk;
                fk *= 128;
            }while (b & 0x80)
            return (f % 2 ? -(f + 1) : f) / 2;
        }
        return n >> 1 ^ -(n & 1);
    }
    skipLong() {
        const buf = this.buf;
        while(buf[this.pos++] & 0x80){}
    }
    readTags() {
        // var items = this.itemsType;
        const val = [];
        let n;
        while(n = this.readLong()){
            if (n < 0) {
                n = -n;
                this.skipLong(); // Skip size.
            }
            while(n--){
                const name = this.readString();
                const value = this.readString();
                val.push(/* items._read(tap) */ {
                    name,
                    value
                });
            }
        }
        return val;
    }
    readString() {
        const len = this.readLong();
        const pos = this.pos;
        const buf = this.buf;
        this.pos += len;
        if (this.pos > buf.length) {
            // return undefined;
            throw new Error("TAP Position out of range");
        }
        return this.buf.slice(pos, pos + len).toString();
    }
}
exports.AVSCTap = AVSCTap;
function serializeTags(tags) {
    if ((tags === null || tags === void 0 ? void 0 : tags.length) === 0) {
        return Buffer.allocUnsafe(0);
    }
    const tap = new AVSCTap();
    tap.writeTags(tags);
    return tap.toBuffer();
}
exports.serializeTags = serializeTags;
function deserializeTags(tagsBuffer) {
    const tap = new AVSCTap(tagsBuffer);
    return tap.readTags();
}
exports.deserializeTags = deserializeTags; //# sourceMappingURL=tags.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/DataItem.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DataItem = exports.MAX_TAG_BYTES = exports.MIN_BINARY_SIZE = void 0;
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/utils.js [app-route] (ecmascript)");
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const buffer_1 = __turbopack_require__("[externals]/buffer [external] (buffer, cjs)");
const ar_data_bundle_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/ar-data-bundle.js [app-route] (ecmascript)");
const index_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/index.js [app-route] (ecmascript)");
const ar_data_base_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/ar-data-base.js [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)");
const utils_2 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/nodeUtils.js [app-route] (ecmascript)");
const tags_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/tags.js [app-route] (ecmascript)");
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
exports.MIN_BINARY_SIZE = 80;
exports.MAX_TAG_BYTES = 4096;
class DataItem {
    constructor(binary){
        this.binary = binary;
    }
    static isDataItem(obj) {
        return obj.binary !== undefined;
    }
    get signatureType() {
        const signatureTypeVal = (0, utils_1.byteArrayToLong)(this.binary.subarray(0, 2));
        if ((constants_1.SignatureConfig === null || constants_1.SignatureConfig === void 0 ? void 0 : constants_1.SignatureConfig[signatureTypeVal]) !== undefined) {
            return signatureTypeVal;
        }
        throw new Error("Unknown signature type: " + signatureTypeVal);
    }
    isValid() {
        return __awaiter(this, void 0, void 0, function*() {
            return DataItem.verify(this.binary);
        });
    }
    get id() {
        return base64url_1.default.encode(this.rawId);
    }
    set id(id) {
        this._id = base64url_1.default.toBuffer(id);
    }
    get rawId() {
        return (0, crypto_1.createHash)("sha256").update(this.rawSignature).digest();
    }
    set rawId(id) {
        this._id = id;
    }
    get rawSignature() {
        return this.binary.subarray(2, 2 + this.signatureLength);
    }
    get signature() {
        return base64url_1.default.encode(this.rawSignature);
    }
    set rawOwner(pubkey) {
        if (pubkey.byteLength != this.ownerLength) throw new Error(`Expected raw owner (pubkey) to be ${this.ownerLength} bytes, got ${pubkey.byteLength} bytes.`);
        this.binary.set(pubkey, 2 + this.signatureLength);
    }
    get rawOwner() {
        return this.binary.subarray(2 + this.signatureLength, 2 + this.signatureLength + this.ownerLength);
    }
    get signatureLength() {
        return constants_1.SIG_CONFIG[this.signatureType].sigLength;
    }
    get owner() {
        return base64url_1.default.encode(this.rawOwner);
    }
    get ownerLength() {
        return constants_1.SIG_CONFIG[this.signatureType].pubLength;
    }
    get rawTarget() {
        const targetStart = this.getTargetStart();
        const isPresent = this.binary[targetStart] == 1;
        return isPresent ? this.binary.subarray(targetStart + 1, targetStart + 33) : buffer_1.Buffer.alloc(0);
    }
    get target() {
        return base64url_1.default.encode(this.rawTarget);
    }
    get rawAnchor() {
        const anchorStart = this.getAnchorStart();
        const isPresent = this.binary[anchorStart] == 1;
        return isPresent ? this.binary.subarray(anchorStart + 1, anchorStart + 33) : buffer_1.Buffer.alloc(0);
    }
    get anchor() {
        return base64url_1.default.encode(this.rawAnchor); /* .toString(); */ 
    }
    get rawTags() {
        const tagsStart = this.getTagsStart();
        const tagsSize = (0, utils_1.byteArrayToLong)(this.binary.subarray(tagsStart + 8, tagsStart + 16));
        return this.binary.subarray(tagsStart + 16, tagsStart + 16 + tagsSize);
    }
    get tags() {
        const tagsStart = this.getTagsStart();
        const tagsCount = (0, utils_1.byteArrayToLong)(this.binary.subarray(tagsStart, tagsStart + 8));
        if (tagsCount == 0) {
            return [];
        }
        const tagsSize = (0, utils_1.byteArrayToLong)(this.binary.subarray(tagsStart + 8, tagsStart + 16));
        return (0, tags_1.deserializeTags)(buffer_1.Buffer.from(this.binary.subarray(tagsStart + 16, tagsStart + 16 + tagsSize)));
    }
    get tagsB64Url() {
        const _tags = this.tags;
        return _tags.map((t)=>({
                name: base64url_1.default.encode(t.name),
                value: base64url_1.default.encode(t.value)
            }));
    }
    getStartOfData() {
        const tagsStart = this.getTagsStart();
        const numberOfTagBytesArray = this.binary.subarray(tagsStart + 8, tagsStart + 16);
        const numberOfTagBytes = (0, utils_1.byteArrayToLong)(numberOfTagBytesArray);
        return tagsStart + 16 + numberOfTagBytes;
    }
    get rawData() {
        const tagsStart = this.getTagsStart();
        const numberOfTagBytesArray = this.binary.subarray(tagsStart + 8, tagsStart + 16);
        const numberOfTagBytes = (0, utils_1.byteArrayToLong)(numberOfTagBytesArray);
        const dataStart = tagsStart + 16 + numberOfTagBytes;
        return this.binary.subarray(dataStart, this.binary.length);
    }
    get data() {
        return base64url_1.default.encode(this.rawData);
    }
    /**
     * UNSAFE!!
     * DO NOT MUTATE THE BINARY ARRAY. THIS WILL CAUSE UNDEFINED BEHAVIOUR.
     */ getRaw() {
        return this.binary;
    }
    sign(signer) {
        return __awaiter(this, void 0, void 0, function*() {
            this._id = yield (0, ar_data_bundle_1.sign)(this, signer);
            return this.rawId;
        });
    }
    setSignature(signature) {
        return __awaiter(this, void 0, void 0, function*() {
            this.binary.set(signature, 2);
            this._id = buffer_1.Buffer.from((yield (0, utils_2.getCryptoDriver)().hash(signature)));
        });
    }
    isSigned() {
        var _a, _b;
        return ((_b = (_a = this._id) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0) > 0;
    }
    /**
     * Returns a JSON representation of a DataItem
     */ // eslint-disable-next-line @typescript-eslint/naming-convention
    toJSON() {
        return {
            signature: this.signature,
            owner: this.owner,
            target: this.target,
            tags: this.tags.map((t)=>({
                    name: base64url_1.default.encode(t.name),
                    value: base64url_1.default.encode(t.value)
                })),
            data: this.data
        };
    }
    /**
     * Verifies a `Buffer` and checks it fits the format of a DataItem
     *
     * A binary is valid iff:
     * - the tags are encoded correctly
     */ static verify(buffer) {
        return __awaiter(this, void 0, void 0, function*() {
            if (buffer.byteLength < exports.MIN_BINARY_SIZE) {
                return false;
            }
            const item = new DataItem(buffer);
            const sigType = item.signatureType;
            const tagsStart = item.getTagsStart();
            const numberOfTags = (0, utils_1.byteArrayToLong)(buffer.subarray(tagsStart, tagsStart + 8));
            const numberOfTagBytesArray = buffer.subarray(tagsStart + 8, tagsStart + 16);
            const numberOfTagBytes = (0, utils_1.byteArrayToLong)(numberOfTagBytesArray);
            if (numberOfTagBytes > exports.MAX_TAG_BYTES) return false;
            if (numberOfTags > 0) {
                try {
                    const tags = (0, tags_1.deserializeTags)(buffer_1.Buffer.from(buffer.subarray(tagsStart + 16, tagsStart + 16 + numberOfTagBytes)));
                    if (tags.length !== numberOfTags) {
                        return false;
                    }
                } catch (e) {
                    return false;
                }
            }
            // eslint-disable-next-line @typescript-eslint/naming-convention
            const Signer = index_1.indexToType[sigType];
            const signatureData = yield (0, ar_data_base_1.default)(item);
            return yield Signer.verify(item.rawOwner, signatureData, item.rawSignature);
        });
    }
    getSignatureData() {
        return __awaiter(this, void 0, void 0, function*() {
            return (0, ar_data_base_1.default)(this);
        });
    }
    /**
     * Returns the start byte of the tags section (number of tags)
     *
     * @private
     */ getTagsStart() {
        const targetStart = this.getTargetStart();
        const targetPresent = this.binary[targetStart] == 1;
        let tagsStart = targetStart + (targetPresent ? 33 : 1);
        const anchorPresent = this.binary[tagsStart] == 1;
        tagsStart += anchorPresent ? 33 : 1;
        return tagsStart;
    }
    /**
     * Returns the start byte of the tags section (number of tags)
     *
     * @private
     */ getTargetStart() {
        return 2 + this.signatureLength + this.ownerLength;
    }
    /**
     * Returns the start byte of the tags section (number of tags)
     *
     * @private
     */ getAnchorStart() {
        let anchorStart = this.getTargetStart() + 1;
        const targetPresent = this.binary[this.getTargetStart()] == 1;
        anchorStart += targetPresent ? 32 : 0;
        return anchorStart;
    }
}
exports.DataItem = DataItem;
exports.default = DataItem; //# sourceMappingURL=DataItem.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/Bundle.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Bundle = void 0;
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/utils.js [app-route] (ecmascript)");
const DataItem_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/DataItem.js [app-route] (ecmascript)"));
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
const HEADER_START = 32;
class Bundle {
    constructor(binary){
        this.binary = binary;
        this.length = this.getDataItemCount();
        this.items = this.getItems();
    }
    getRaw() {
        return this.binary;
    }
    /**
     * Get a DataItem by index (`number`) or by txId (`string`)
     * @param index
     */ get(index) {
        if (typeof index === "number") {
            if (index >= this.length) {
                throw new RangeError("Index out of range");
            }
            return this.getByIndex(index);
        } else {
            return this.getById(index);
        }
    }
    getSizes() {
        const ids = [];
        for(let i = HEADER_START; i < HEADER_START + 64 * this.length; i += 64){
            ids.push((0, utils_1.byteArrayToLong)(this.binary.subarray(i, i + 32)));
        }
        return ids;
    }
    getIds() {
        const ids = [];
        for(let i = HEADER_START; i < HEADER_START + 64 * this.length; i += 64){
            const bundleId = this.binary.subarray(i + 32, i + 64);
            if (bundleId.length === 0) {
                throw new Error("Invalid bundle, id specified in headers doesn't exist");
            }
            ids.push(base64url_1.default.encode(bundleId));
        }
        return ids;
    }
    getIdBy(index) {
        if (index > this.length - 1) {
            throw new RangeError("Index of bundle out of range");
        }
        const start = 64 + 64 * index;
        return base64url_1.default.encode(this.binary.subarray(start, start + 32));
    }
    toTransaction(attributes, arweave, jwk) {
        return __awaiter(this, void 0, void 0, function*() {
            const tx = yield arweave.createTransaction(Object.assign({
                data: this.binary
            }, attributes), jwk);
            tx.addTag("Bundle-Format", "binary");
            tx.addTag("Bundle-Version", "2.0.0");
            return tx;
        });
    }
    verify() {
        return __awaiter(this, void 0, void 0, function*() {
            for (const item of this.items){
                const valid = yield item.isValid();
                const expected = (0, base64url_1.default)((0, crypto_1.createHash)("sha256").update(item.rawSignature).digest());
                if (!(valid && item.id === expected)) {
                    return false;
                }
            }
            return true;
        });
    }
    getOffset(id) {
        let offset = 0;
        for(let i = HEADER_START; i < HEADER_START + 64 * this.length; i += 64){
            const _offset = (0, utils_1.byteArrayToLong)(this.binary.subarray(i, i + 32));
            offset += _offset;
            const _id = this.binary.subarray(i + 32, i + 64);
            if (Buffer.compare(_id, id) === 0) {
                return {
                    startOffset: offset,
                    size: _offset
                };
            }
        }
        return {
            startOffset: -1,
            size: -1
        };
    }
    // TODO: Test this
    /**
     * UNSAFE! Assumes index < length
     * @param index
     * @private
     */ getByIndex(index) {
        let offset = 0;
        const bundleStart = this.getBundleStart();
        let counter = 0;
        let _offset, _id;
        for(let i = HEADER_START; i < HEADER_START + 64 * this.length; i += 64){
            _offset = (0, utils_1.byteArrayToLong)(this.binary.subarray(i, i + 32));
            if (counter++ === index) {
                _id = this.binary.subarray(i + 32, i + 64);
                break;
            }
            offset += _offset;
        }
        const dataItemStart = bundleStart + offset;
        const slice = this.binary.subarray(dataItemStart, dataItemStart + _offset);
        const item = new DataItem_1.default(slice);
        item.rawId = _id;
        return item;
    }
    getById(id) {
        const _id = base64url_1.default.toBuffer(id);
        const offset = this.getOffset(_id);
        if (offset.startOffset === -1) {
            throw new Error("Transaction not found");
        }
        const bundleStart = this.getBundleStart();
        const dataItemStart = bundleStart + offset.startOffset;
        return new DataItem_1.default(this.binary.subarray(dataItemStart, dataItemStart + offset.size));
    }
    getDataItemCount() {
        return (0, utils_1.byteArrayToLong)(this.binary.subarray(0, 32));
    }
    getBundleStart() {
        return 32 + 64 * this.length;
    }
    getItems() {
        const items = new Array(this.length);
        let offset = 0;
        const bundleStart = this.getBundleStart();
        let counter = 0;
        for(let i = HEADER_START; i < HEADER_START + 64 * this.length; i += 64){
            const _offset = (0, utils_1.byteArrayToLong)(this.binary.subarray(i, i + 32));
            const _id = this.binary.subarray(i + 32, i + 64);
            if (_id.length === 0) {
                throw new Error("Invalid bundle, id specified in headers doesn't exist");
            }
            const dataItemStart = bundleStart + offset;
            const bytes = this.binary.subarray(dataItemStart, dataItemStart + _offset);
            offset += _offset;
            const item = new DataItem_1.default(bytes);
            item.rawId = _id;
            items[counter] = item;
            counter++;
        }
        return items;
    }
}
exports.Bundle = Bundle;
exports.default = Bundle; //# sourceMappingURL=Bundle.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/ar-data-bundle.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.sign = exports.getSignatureAndId = exports.bundleAndSignData = exports.unbundleData = void 0;
const ar_data_base_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/ar-data-base.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/utils.js [app-route] (ecmascript)");
const Bundle_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/Bundle.js [app-route] (ecmascript)"));
const utils_2 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/nodeUtils.js [app-route] (ecmascript)");
/**
 * Unbundles a transaction into an Array of DataItems.
 *
 * Takes either a json string or object. Will throw if given an invalid json
 * string but otherwise, it will return an empty array if
 *
 * a) the json object is the wrong format
 * b) the object contains no valid DataItems.
 *
 * It will verify all DataItems and discard ones that don't pass verification.
 *
 * @param txData
 */ function unbundleData(txData) {
    return new Bundle_1.default(txData);
}
exports.unbundleData = unbundleData;
/**
 * Verifies all data items and returns a json object with an items array.
 * Throws if any of the data items fail verification.
 *
 * @param dataItems
 * @param signer
 */ function bundleAndSignData(dataItems, signer) {
    return __awaiter(this, void 0, void 0, function*() {
        const headers = new Uint8Array(64 * dataItems.length);
        const binaries = yield Promise.all(dataItems.map((d, index)=>__awaiter(this, void 0, void 0, function*() {
                // Sign DataItem
                const id = d.isSigned() ? d.rawId : yield sign(d, signer);
                // Create header array
                const header = new Uint8Array(64);
                // Set offset
                header.set((0, utils_1.longTo32ByteArray)(d.getRaw().byteLength), 0);
                // Set id
                header.set(id, 32);
                // Add header to array of headers
                headers.set(header, 64 * index);
                // Convert to array for flattening
                return d.getRaw();
            }))).then((a)=>{
            return Buffer.concat(a);
        });
        const buffer = Buffer.concat([
            Buffer.from((0, utils_1.longTo32ByteArray)(dataItems.length)),
            Buffer.from(headers),
            binaries
        ]);
        return new Bundle_1.default(buffer);
    });
}
exports.bundleAndSignData = bundleAndSignData;
/**
 * Signs a single
 *
 * @param item
 * @param signer
 * @returns signings - signature and id in byte-arrays
 */ function getSignatureAndId(item, signer) {
    return __awaiter(this, void 0, void 0, function*() {
        const signatureData = yield (0, ar_data_base_1.default)(item);
        const signatureBytes = yield signer.sign(signatureData);
        const idBytes = yield (0, utils_2.getCryptoDriver)().hash(signatureBytes);
        return {
            signature: Buffer.from(signatureBytes),
            id: Buffer.from(idBytes)
        };
    });
}
exports.getSignatureAndId = getSignatureAndId;
/**
 * Signs and returns item id
 *
 * @param item
 * @param jwk
 */ function sign(item, signer) {
    return __awaiter(this, void 0, void 0, function*() {
        const { signature, id } = yield getSignatureAndId(item, signer);
        item.getRaw().set(signature, 2);
        return id;
    });
}
exports.sign = sign; //# sourceMappingURL=ar-data-bundle.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/ar-data-create.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createData = void 0;
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/utils.js [app-route] (ecmascript)");
const DataItem_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/DataItem.js [app-route] (ecmascript)"));
const tags_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/tags.js [app-route] (ecmascript)");
/**
 * This will create a single DataItem in binary format (Uint8Array)
 *
 * @param data
 * @param opts - Options involved in creating data items
 * @param signer
 */ function createData(data, signer, opts) {
    var _a, _b, _c, _d, _e, _f, _g;
    // TODO: Add asserts
    // Parse all values to a buffer and
    const _owner = signer.publicKey;
    const _target = (opts === null || opts === void 0 ? void 0 : opts.target) ? base64url_1.default.toBuffer(opts.target) : null;
    const target_length = 1 + ((_a = _target === null || _target === void 0 ? void 0 : _target.byteLength) !== null && _a !== void 0 ? _a : 0);
    const _anchor = (opts === null || opts === void 0 ? void 0 : opts.anchor) ? Buffer.from(opts.anchor) : null;
    const anchor_length = 1 + ((_b = _anchor === null || _anchor === void 0 ? void 0 : _anchor.byteLength) !== null && _b !== void 0 ? _b : 0);
    const _tags = ((_d = (_c = opts === null || opts === void 0 ? void 0 : opts.tags) === null || _c === void 0 ? void 0 : _c.length) !== null && _d !== void 0 ? _d : 0) > 0 ? (0, tags_1.serializeTags)(opts === null || opts === void 0 ? void 0 : opts.tags) : null;
    const tags_length = 16 + (_tags ? _tags.byteLength : 0);
    const _data = typeof data === "string" ? Buffer.from(data) : Buffer.from(data);
    const data_length = _data.byteLength;
    // See [https://github.com/joshbenaron/arweave-standards/blob/ans104/ans/ANS-104.md#13-dataitem-format]
    const length = 2 + signer.signatureLength + signer.ownerLength + target_length + anchor_length + tags_length + data_length;
    // Create array with set length
    const bytes = Buffer.alloc(length);
    bytes.set((0, utils_1.shortTo2ByteArray)(signer.signatureType), 0);
    // Push bytes for `signature`
    bytes.set(new Uint8Array(signer.signatureLength).fill(0), 2);
    // // Push bytes for `id`
    // bytes.set(EMPTY_ARRAY, 32);
    // Push bytes for `owner`
    if (_owner.byteLength !== signer.ownerLength) throw new Error(`Owner must be ${signer.ownerLength} bytes, but was incorrectly ${_owner.byteLength}`);
    bytes.set(_owner, 2 + signer.signatureLength);
    const position = 2 + signer.signatureLength + signer.ownerLength;
    // Push `presence byte` and push `target` if present
    // 64 + OWNER_LENGTH
    bytes[position] = _target ? 1 : 0;
    if (_target) {
        if (_target.byteLength !== 32) throw new Error(`Target must be 32 bytes but was incorrectly ${_target.byteLength}`);
        bytes.set(_target, position + 1);
    }
    // Push `presence byte` and push `anchor` if present
    // 64 + OWNER_LENGTH
    const anchor_start = position + target_length;
    let tags_start = anchor_start + 1;
    bytes[anchor_start] = _anchor ? 1 : 0;
    if (_anchor) {
        tags_start += _anchor.byteLength;
        if (_anchor.byteLength !== 32) throw new Error("Anchor must be 32 bytes");
        bytes.set(_anchor, anchor_start + 1);
    }
    bytes.set((0, utils_1.longTo8ByteArray)((_f = (_e = opts === null || opts === void 0 ? void 0 : opts.tags) === null || _e === void 0 ? void 0 : _e.length) !== null && _f !== void 0 ? _f : 0), tags_start);
    const bytesCount = (0, utils_1.longTo8ByteArray)((_g = _tags === null || _tags === void 0 ? void 0 : _tags.byteLength) !== null && _g !== void 0 ? _g : 0);
    bytes.set(bytesCount, tags_start + 8);
    if (_tags) {
        bytes.set(_tags, tags_start + 16);
    }
    const data_start = tags_start + tags_length;
    bytes.set(_data, data_start);
    return new DataItem_1.default(bytes);
}
exports.createData = createData; //# sourceMappingURL=ar-data-create.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/BundleInterface.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
}); //# sourceMappingURL=BundleInterface.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/BundleItem.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BundleItem = void 0;
class BundleItem {
    static verify(..._) {
        return __awaiter(this, void 0, void 0, function*() {
            throw new Error("You must implement `verify`");
        });
    }
}
exports.BundleItem = BundleItem; //# sourceMappingURL=BundleItem.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/error.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
class BundleError extends Error {
    constructor(message){
        super(message);
        this.name = "BundleError";
    }
}
exports.default = BundleError; //# sourceMappingURL=error.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/interface-jwk.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
}); //# sourceMappingURL=interface-jwk.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/ar-data-base.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/ar-data-bundle.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/ar-data-create.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/Bundle.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/BundleInterface.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/BundleItem.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/DataItem.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/error.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/interface-jwk.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/tags.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/utils.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/nodeUtils.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/stream/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = this && this.__asyncValues || function(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i);
    "TURBOPACK unreachable";
    function verb(n) {
        i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
                v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
        };
    }
    function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function(v) {
            resolve({
                value: v,
                done: d
            });
        }, reject);
    }
};
var __await = this && this.__await || function(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
};
var __asyncGenerator = this && this.__asyncGenerator || function(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i;
    "TURBOPACK unreachable";
    function verb(n) {
        if (g[n]) i[n] = function(v) {
            return new Promise(function(a, b) {
                q.push([
                    n,
                    v,
                    a,
                    b
                ]) > 1 || resume(n, v);
            });
        };
    }
    function resume(n, v) {
        try {
            step(g[n](v));
        } catch (e) {
            settle(q[0][3], e);
        }
    }
    function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
        resume("next", value);
    }
    function reject(value) {
        resume("throw", value);
    }
    function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.streamExportForTesting = exports.streamSigner = exports.processStream = void 0;
const stream_1 = __turbopack_require__("[externals]/stream [external] (stream, cjs)");
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/utils.js [app-route] (ecmascript)");
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/constants.js [app-route] (ecmascript)");
const index_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/index.js [app-route] (ecmascript)");
const constants_2 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)");
const utils_2 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/nodeUtils.js [app-route] (ecmascript)");
const deepHash_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/deepHash.js [app-route] (ecmascript)");
const tags_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/tags.js [app-route] (ecmascript)");
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
function processStream(stream) {
    return __awaiter(this, void 0, void 0, function*() {
        const reader = getReader(stream);
        let bytes = (yield reader.next()).value;
        bytes = yield readBytes(reader, bytes, 32);
        const itemCount = (0, utils_1.byteArrayToLong)(bytes.subarray(0, 32));
        bytes = bytes.subarray(32);
        const headersLength = 64 * itemCount;
        bytes = yield readBytes(reader, bytes, headersLength);
        const headers = new Array(itemCount);
        for(let i = 0; i < headersLength; i += 64){
            headers[i / 64] = [
                (0, utils_1.byteArrayToLong)(bytes.subarray(i, i + 32)),
                (0, base64url_1.default)(Buffer.from(bytes.subarray(i + 32, i + 64)))
            ];
        }
        bytes = bytes.subarray(headersLength);
        let offsetSum = 32 + headersLength;
        const items = [];
        for (const [length, id] of headers){
            bytes = yield readBytes(reader, bytes, index_1.MIN_BINARY_SIZE);
            // Get sig type
            bytes = yield readBytes(reader, bytes, 2);
            const signatureType = (0, utils_1.byteArrayToLong)(bytes.subarray(0, 2));
            bytes = bytes.subarray(2);
            const { sigLength, pubLength, sigName } = constants_2.SIG_CONFIG[signatureType];
            // Get sig
            bytes = yield readBytes(reader, bytes, sigLength);
            const signature = bytes.subarray(0, sigLength);
            bytes = bytes.subarray(sigLength);
            // Get owner
            bytes = yield readBytes(reader, bytes, pubLength);
            const owner = bytes.subarray(0, pubLength);
            bytes = bytes.subarray(pubLength);
            // Get target
            bytes = yield readBytes(reader, bytes, 1);
            const targetPresent = bytes[0] === 1;
            if (targetPresent) bytes = yield readBytes(reader, bytes, 33);
            const target = targetPresent ? bytes.subarray(1, 33) : Buffer.allocUnsafe(0);
            bytes = bytes.subarray(targetPresent ? 33 : 1);
            // Get anchor
            bytes = yield readBytes(reader, bytes, 1);
            const anchorPresent = bytes[0] === 1;
            if (anchorPresent) bytes = yield readBytes(reader, bytes, 33);
            const anchor = anchorPresent ? bytes.subarray(1, 33) : Buffer.allocUnsafe(0);
            bytes = bytes.subarray(anchorPresent ? 33 : 1);
            // Get tags
            bytes = yield readBytes(reader, bytes, 8);
            const tagsLength = (0, utils_1.byteArrayToLong)(bytes.subarray(0, 8));
            bytes = bytes.subarray(8);
            bytes = yield readBytes(reader, bytes, 8);
            const tagsBytesLength = (0, utils_1.byteArrayToLong)(bytes.subarray(0, 8));
            bytes = bytes.subarray(8);
            bytes = yield readBytes(reader, bytes, tagsBytesLength);
            const tagsBytes = bytes.subarray(0, tagsBytesLength);
            const tags = tagsLength !== 0 && tagsBytesLength !== 0 ? (0, tags_1.deserializeTags)(Buffer.from(tagsBytes)) : [];
            if (tags.length !== tagsLength) throw new Error("Tags lengths don't match");
            bytes = bytes.subarray(tagsBytesLength);
            const transform = new stream_1.Transform();
            transform._transform = function(chunk, _, done) {
                this.push(chunk);
                done();
            };
            // Verify signature
            const signatureData = (0, deepHash_1.deepHash)([
                (0, utils_2.stringToBuffer)("dataitem"),
                (0, utils_2.stringToBuffer)("1"),
                (0, utils_2.stringToBuffer)(signatureType.toString()),
                owner,
                target,
                anchor,
                tagsBytes,
                transform
            ]);
            // Get offset of data start and length of data
            const dataOffset = 2 + sigLength + pubLength + (targetPresent ? 33 : 1) + (anchorPresent ? 33 : 1) + 16 + tagsBytesLength;
            const dataSize = length - dataOffset;
            if (bytes.byteLength > dataSize) {
                transform.write(bytes.subarray(0, dataSize));
                bytes = bytes.subarray(dataSize);
            } else {
                let skipped = bytes.byteLength;
                transform.write(bytes);
                while(dataSize > skipped){
                    bytes = (yield reader.next()).value;
                    if (!bytes) {
                        throw new Error(`Not enough data bytes  expected: ${dataSize} received: ${skipped}`);
                    }
                    skipped += bytes.byteLength;
                    if (skipped > dataSize) transform.write(bytes.subarray(0, bytes.byteLength - (skipped - dataSize)));
                    else transform.write(bytes);
                }
                bytes = bytes.subarray(bytes.byteLength - (skipped - dataSize));
            }
            transform.end();
            // Check id
            if (id !== (0, base64url_1.default)((0, crypto_1.createHash)("sha256").update(signature).digest())) throw new Error("ID doesn't match signature");
            const Signer = constants_1.indexToType[signatureType];
            if (!(yield Signer.verify(owner, (yield signatureData), signature))) throw new Error("Invalid signature");
            items.push({
                id,
                sigName,
                signature: (0, base64url_1.default)(Buffer.from(signature)),
                target: (0, base64url_1.default)(Buffer.from(target)),
                anchor: (0, base64url_1.default)(Buffer.from(anchor)),
                owner: (0, base64url_1.default)(Buffer.from(owner)),
                tags,
                dataOffset: offsetSum + dataOffset,
                dataSize
            });
            offsetSum += dataOffset + dataSize;
        }
        return items;
    });
}
exports.processStream = processStream;
/**
 * Signs a stream (requires two instances/read passes)
 * @param s1 Stream to sign - same as s2
 * @param s2 Stream to sign - same as s1
 * @param signer Signer to use to sign the stream
 * @param opts Optional options to apply to the stream (same as DataItem)
 */ function streamSigner(s1, s2, signer, opts) {
    return __awaiter(this, void 0, void 0, function*() {
        const header = (0, index_1.createData)("", signer, opts);
        const output = new stream_1.PassThrough();
        const parts = [
            (0, utils_2.stringToBuffer)("dataitem"),
            (0, utils_2.stringToBuffer)("1"),
            (0, utils_2.stringToBuffer)(header.signatureType.toString()),
            header.rawOwner,
            header.rawTarget,
            header.rawAnchor,
            header.rawTags,
            s1
        ];
        const hash = yield (0, deepHash_1.deepHash)(parts);
        const sigBytes = Buffer.from((yield signer.sign(hash)));
        header.setSignature(sigBytes);
        output.write(header.getRaw());
        return s2.pipe(output);
    });
}
exports.streamSigner = streamSigner;
function readBytes(reader, buffer, length) {
    return __awaiter(this, void 0, void 0, function*() {
        if (buffer.byteLength >= length) return buffer;
        const { done, value } = yield reader.next();
        if (done && !value) throw new Error("Invalid buffer");
        return readBytes(reader, Buffer.concat([
            Buffer.from(buffer),
            Buffer.from(value)
        ]), length);
    });
}
function getReader(s) {
    return __asyncGenerator(this, arguments, function* getReader_1() {
        var _a, e_1, _b, _c;
        try {
            for(var _d = true, s_1 = __asyncValues(s), s_1_1; s_1_1 = yield __await(s_1.next()), _a = s_1_1.done, !_a;){
                _c = s_1_1.value;
                _d = false;
                try {
                    const chunk = _c;
                    yield yield __await(chunk);
                } finally{
                    _d = true;
                }
            }
        } catch (e_1_1) {
            e_1 = {
                error: e_1_1
            };
        } finally{
            try {
                if (!_d && !_a && (_b = s_1.return)) yield __await(_b.call(s_1));
            } finally{
                if (e_1) throw e_1.error;
            }
        }
    });
}
exports.default = processStream;
exports.streamExportForTesting = {
    readBytes,
    getReader
}; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/FileDataItem.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.FileDataItem = void 0;
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const fs_1 = __turbopack_require__("[externals]/fs [external] (fs, cjs)");
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/utils.js [app-route] (ecmascript)");
const index_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/index.js [app-route] (ecmascript)");
const utils_2 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/nodeUtils.js [app-route] (ecmascript)");
const index_2 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/signing/index.js [app-route] (ecmascript)");
const axios_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/axios@1.7.9/node_modules/axios/dist/node/axios.cjs [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/constants.js [app-route] (ecmascript)");
const util_1 = __turbopack_require__("[externals]/util [external] (util, cjs)");
const tags_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/tags.js [app-route] (ecmascript)");
const read = (0, util_1.promisify)(fs_1.read);
const write = (0, util_1.promisify)(fs_1.write);
class FileDataItem {
    signatureLength() {
        var _a;
        return __awaiter(this, void 0, void 0, function*() {
            const type = yield this.signatureType();
            const length = (_a = constants_1.SIG_CONFIG[type]) === null || _a === void 0 ? void 0 : _a.sigLength;
            if (!length) throw new Error("Signature type not supported");
            return length;
        });
    }
    ownerLength() {
        var _a;
        return __awaiter(this, void 0, void 0, function*() {
            const length = (_a = constants_1.SIG_CONFIG[yield this.signatureType()]) === null || _a === void 0 ? void 0 : _a.pubLength;
            if (!length) throw new Error("Signature type not supported");
            return length;
        });
    }
    constructor(filename, id){
        this.filename = filename;
        this._id = id;
    }
    get id() {
        if (!this._id) throw new Error("FileDataItem - ID is undefined");
        return base64url_1.default.encode(this._id);
    }
    get rawId() {
        if (this._id) {
            return this._id;
        }
        throw new Error("ID is not set");
    }
    set rawId(id) {
        this._id = id;
    }
    static isDataItem(obj) {
        // return obj?.filename ? typeof obj.filename === "string" : false;
        return obj instanceof FileDataItem;
    }
    static verify(filename) {
        return __awaiter(this, void 0, void 0, function*() {
            const handle = yield fs_1.promises.open(filename, "r");
            const item = new FileDataItem(filename);
            const sigType = yield item.signatureType();
            const tagsStart = yield item.getTagsStart();
            const numberOfTags = yield read(handle.fd, Buffer.allocUnsafe(8), 0, 8, tagsStart).then((r)=>(0, utils_1.byteArrayToLong)(r.buffer));
            const numberOfTagsBytes = yield read(handle.fd, Buffer.allocUnsafe(8), 0, 8, tagsStart + 8).then((r)=>(0, utils_1.byteArrayToLong)(r.buffer));
            if (numberOfTagsBytes > index_1.MAX_TAG_BYTES) {
                yield handle.close();
                return false;
            }
            const tagsBytes = yield read(handle.fd, Buffer.allocUnsafe(numberOfTagsBytes), 0, numberOfTagsBytes, tagsStart + 16).then((r)=>r.buffer);
            if (numberOfTags > 0) {
                try {
                    (0, tags_1.deserializeTags)(tagsBytes);
                } catch (e) {
                    yield handle.close();
                    return false;
                }
            }
            const Signer = index_2.indexToType[sigType];
            const owner = yield item.rawOwner();
            const signatureData = yield (0, index_1.deepHash)([
                (0, utils_2.stringToBuffer)("dataitem"),
                (0, utils_2.stringToBuffer)("1"),
                (0, utils_2.stringToBuffer)(sigType.toString()),
                owner,
                (yield item.rawTarget()),
                (yield item.rawAnchor()),
                (yield item.rawTags()),
                (0, fs_1.createReadStream)(filename, {
                    start: yield item.dataStart()
                })
            ]);
            const sig = yield item.rawSignature();
            if (!(yield Signer.verify(owner, signatureData, sig))) {
                yield handle.close();
                return false;
            }
            yield handle.close();
            return true;
        });
    }
    isValid() {
        return FileDataItem.verify(this.filename);
    }
    isSigned() {
        return this._id !== undefined;
    }
    size() {
        return __awaiter(this, void 0, void 0, function*() {
            return yield fs_1.promises.stat(this.filename).then((r)=>r.size);
        });
    }
    signatureType() {
        return __awaiter(this, void 0, void 0, function*() {
            const handle = yield fs_1.promises.open(this.filename, "r");
            const buffer = yield read(handle.fd, Buffer.allocUnsafe(2), 0, 2, 0).then((r)=>r.buffer);
            yield handle.close();
            return (0, utils_1.byteArrayToLong)(buffer);
        });
    }
    rawSignature() {
        return __awaiter(this, void 0, void 0, function*() {
            const handle = yield fs_1.promises.open(this.filename, "r");
            const length = yield this.signatureLength();
            const buffer = yield read(handle.fd, Buffer.alloc(length), 0, length, 2).then((r)=>r.buffer);
            yield handle.close();
            return buffer;
        });
    }
    signature() {
        return __awaiter(this, void 0, void 0, function*() {
            return base64url_1.default.encode((yield this.rawSignature()));
        });
    }
    rawOwner() {
        return __awaiter(this, void 0, void 0, function*() {
            const handle = yield fs_1.promises.open(this.filename, "r");
            const length = yield this.ownerLength();
            const buffer = yield read(handle.fd, Buffer.allocUnsafe(length), 0, length, 2 + (yield this.signatureLength())).then((r)=>r.buffer);
            yield handle.close();
            return buffer;
        });
    }
    owner() {
        return __awaiter(this, void 0, void 0, function*() {
            return base64url_1.default.encode((yield this.rawOwner()));
        });
    }
    rawTarget() {
        return __awaiter(this, void 0, void 0, function*() {
            const handle = yield fs_1.promises.open(this.filename, "r");
            const targetStart = yield this.getTargetStart();
            const targetPresentBuffer = yield read(handle.fd, Buffer.allocUnsafe(1), 0, 1, targetStart).then((r)=>r.buffer);
            const targetPresent = targetPresentBuffer[0] === 1;
            if (targetPresent) {
                const targetBuffer = yield read(handle.fd, Buffer.allocUnsafe(32), 0, 32, targetStart + 1).then((r)=>r.buffer);
                yield handle.close();
                return targetBuffer;
            }
            yield handle.close();
            return Buffer.allocUnsafe(0);
        });
    }
    target() {
        return __awaiter(this, void 0, void 0, function*() {
            return base64url_1.default.encode((yield this.rawTarget()));
        });
    }
    getTargetStart() {
        return __awaiter(this, void 0, void 0, function*() {
            return 2 + (yield this.signatureLength()) + (yield this.ownerLength());
        });
    }
    rawAnchor() {
        return __awaiter(this, void 0, void 0, function*() {
            const [anchorPresent, anchorStart] = yield this.anchorStart();
            if (anchorPresent) {
                const handle = yield fs_1.promises.open(this.filename, "r");
                const anchorBuffer = yield read(handle.fd, Buffer.allocUnsafe(32), 0, 32, anchorStart + 1).then((r)=>r.buffer);
                yield handle.close();
                return anchorBuffer;
            }
            return Buffer.allocUnsafe(0);
        });
    }
    anchor() {
        return __awaiter(this, void 0, void 0, function*() {
            return base64url_1.default.encode((yield this.rawAnchor()));
        });
    }
    rawTags() {
        return __awaiter(this, void 0, void 0, function*() {
            const handle = yield fs_1.promises.open(this.filename, "r");
            const tagsStart = yield this.getTagsStart();
            const numberOfTagsBuffer = yield read(handle.fd, Buffer.allocUnsafe(8), 0, 8, tagsStart).then((r)=>r.buffer);
            const numberOfTags = (0, utils_1.byteArrayToLong)(numberOfTagsBuffer);
            if (numberOfTags === 0) {
                yield handle.close();
                return Buffer.allocUnsafe(0);
            }
            const numberOfTagsBytesBuffer = yield read(handle.fd, Buffer.allocUnsafe(8), 0, 8, tagsStart + 8).then((r)=>r.buffer);
            const numberOfTagsBytes = (0, utils_1.byteArrayToLong)(numberOfTagsBytesBuffer);
            if (numberOfTagsBytes > index_1.MAX_TAG_BYTES) {
                yield handle.close();
                throw new Error("Tags too large");
            }
            const tagsBytes = yield read(handle.fd, Buffer.allocUnsafe(numberOfTagsBytes), 0, numberOfTagsBytes, tagsStart + 16).then((r)=>r.buffer);
            yield handle.close();
            return tagsBytes;
        });
    }
    tags() {
        return __awaiter(this, void 0, void 0, function*() {
            const tagsBytes = yield this.rawTags();
            if (tagsBytes.byteLength === 0) return [];
            return (0, tags_1.deserializeTags)(tagsBytes);
        });
    }
    rawData() {
        return __awaiter(this, void 0, void 0, function*() {
            const dataStart = yield this.dataStart();
            const size = yield this.size();
            const dataSize = size - dataStart;
            if (dataSize === 0) {
                return Buffer.allocUnsafe(0);
            }
            const handle = yield fs_1.promises.open(this.filename, "r");
            const dataBuffer = yield read(handle.fd, Buffer.allocUnsafe(dataSize), 0, dataSize, dataStart).then((r)=>r.buffer);
            yield handle.close();
            return dataBuffer;
        });
    }
    data() {
        return __awaiter(this, void 0, void 0, function*() {
            return base64url_1.default.encode((yield this.rawData()));
        });
    }
    sign(signer) {
        return __awaiter(this, void 0, void 0, function*() {
            const dataStart = yield this.dataStart();
            const signatureData = yield (0, index_1.deepHash)([
                (0, utils_2.stringToBuffer)("dataitem"),
                (0, utils_2.stringToBuffer)("1"),
                (0, utils_2.stringToBuffer)((yield this.signatureType()).toString()),
                (yield this.rawOwner()),
                (yield this.rawTarget()),
                (yield this.rawAnchor()),
                (yield this.rawTags()),
                (0, fs_1.createReadStream)(this.filename, {
                    start: dataStart
                })
            ]);
            const signatureBytes = yield signer.sign(signatureData);
            const idBytes = yield (0, utils_2.getCryptoDriver)().hash(signatureBytes);
            const handle = yield fs_1.promises.open(this.filename, "r+");
            yield write(handle.fd, signatureBytes, 0, (yield this.signatureLength()), 2);
            this.rawId = Buffer.from(idBytes);
            yield handle.close();
            return Buffer.from(idBytes);
        });
    }
    /**
     * @deprecated Since version 0.3.0. Will be deleted in version 0.4.0. Use @bundlr-network/client package instead to interact with Bundlr
     */ sendToBundler(bundler) {
        return __awaiter(this, void 0, void 0, function*() {
            const headers = {
                "Content-Type": "application/octet-stream"
            };
            if (!this.isSigned()) throw new Error("You must sign before sending to bundler");
            const response = yield axios_1.default.post(`${bundler}/tx`, (0, fs_1.createReadStream)(this.filename), {
                headers,
                timeout: 100000,
                maxBodyLength: Infinity,
                validateStatus: (status)=>status > 200 && status < 300 || status !== 402
            });
            if (response.status === 402) throw new Error("Not enough funds to send data");
            return response;
        });
    }
    getTagsStart() {
        return __awaiter(this, void 0, void 0, function*() {
            const [anchorPresent, anchorStart] = yield this.anchorStart();
            let tagsStart = anchorStart;
            tagsStart += anchorPresent ? 33 : 1;
            return tagsStart;
        });
    }
    dataStart() {
        return __awaiter(this, void 0, void 0, function*() {
            const handle = yield fs_1.promises.open(this.filename, "r");
            const tagsStart = yield this.getTagsStart();
            const numberOfTagsBytesBuffer = yield read(handle.fd, Buffer.allocUnsafe(8), 0, 8, tagsStart + 8).then((r)=>r.buffer);
            const numberOfTagsBytes = (0, utils_1.byteArrayToLong)(numberOfTagsBytesBuffer);
            yield handle.close();
            return tagsStart + 16 + numberOfTagsBytes;
        });
    }
    anchorStart() {
        return __awaiter(this, void 0, void 0, function*() {
            const targetStart = yield this.getTargetStart();
            const handle = yield fs_1.promises.open(this.filename, "r");
            const targetPresentBuffer = yield read(handle.fd, Buffer.allocUnsafe(1), 0, 1, targetStart).then((r)=>r.buffer);
            const targetPresent = targetPresentBuffer[0] === 1;
            const anchorStart = targetStart + (targetPresent ? 33 : 1);
            const anchorPresentBuffer = yield read(handle.fd, Buffer.allocUnsafe(1), 0, 1, anchorStart).then((r)=>r.buffer);
            const anchorPresent = anchorPresentBuffer[0] === 1;
            yield handle.close();
            return [
                anchorPresent,
                anchorStart
            ];
        });
    }
}
exports.FileDataItem = FileDataItem;
exports.default = FileDataItem; //# sourceMappingURL=FileDataItem.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/FileBundle.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = this && this.__asyncValues || function(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i);
    "TURBOPACK unreachable";
    function verb(n) {
        i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
                v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
        };
    }
    function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function(v) {
            resolve({
                value: v,
                done: d
            });
        }, reject);
    }
};
var __await = this && this.__await || function(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
};
var __asyncGenerator = this && this.__asyncGenerator || function(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i;
    "TURBOPACK unreachable";
    function verb(n) {
        if (g[n]) i[n] = function(v) {
            return new Promise(function(a, b) {
                q.push([
                    n,
                    v,
                    a,
                    b
                ]) > 1 || resume(n, v);
            });
        };
    }
    function resume(n, v) {
        try {
            step(g[n](v));
        } catch (e) {
            settle(q[0][3], e);
        }
    }
    function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
        resume("next", value);
    }
    function reject(value) {
        resume("throw", value);
    }
    function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.FileBundle = void 0;
const FileDataItem_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/FileDataItem.js [app-route] (ecmascript)"));
const fs_1 = __turbopack_require__("[externals]/fs [external] (fs, cjs)");
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/utils.js [app-route] (ecmascript)");
const fs_2 = __turbopack_require__("[externals]/fs [external] (fs, cjs)");
const multistream_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/multistream@4.1.0/node_modules/multistream/index.js [app-route] (ecmascript)"));
const util_1 = __turbopack_require__("[externals]/util [external] (util, cjs)");
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const promises_1 = __turbopack_require__("[externals]/stream/promises [external] (stream/promises, cjs)");
const path_1 = __turbopack_require__("[externals]/path [external] (path, cjs)");
// import { Readable } from 'stream';
// import { createTransactionAsync } from 'arweave-stream';
// import { pipeline } from 'stream/promises';
const read = (0, util_1.promisify)(fs_2.read);
class FileBundle {
    constructor(headerFile, txs){
        this.headerFile = headerFile;
        this.txs = txs;
    }
    static fromDir(dir) {
        return __awaiter(this, void 0, void 0, function*() {
            const txs = [];
            for (const p of yield fs_1.promises.readdir(dir)){
                const fullPath = (0, path_1.resolve)(dir, p);
                // if it's an item (not a dir,not the header file, actually exists in FS) add to txs array
                if (p !== "header" && (yield fs_1.promises.stat(fullPath).then((e)=>!e.isDirectory()).catch((_)=>false))) txs.push(fullPath);
            }
            return new FileBundle(dir + "/header", txs);
        });
    }
    length() {
        return __awaiter(this, void 0, void 0, function*() {
            const handle = yield fs_1.promises.open(this.headerFile, "r");
            const lengthBuffer = yield read(handle.fd, Buffer.allocUnsafe(32), 0, 32, 0).then((r)=>r.buffer);
            yield handle.close();
            return (0, utils_1.byteArrayToLong)(lengthBuffer);
        });
    }
    get items() {
        return this.itemsGenerator();
    }
    get(index) {
        return __awaiter(this, void 0, void 0, function*() {
            if (typeof index === "number") {
                if (index > (yield this.length())) {
                    throw new RangeError("Index out of range");
                }
                return this.getByIndex(index);
            } else {
                return this.getById(index);
            }
        });
    }
    getIds() {
        var _a, e_1, _b, _c;
        return __awaiter(this, void 0, void 0, function*() {
            const ids = new Array((yield this.length()));
            let count = 0;
            try {
                for(var _d = true, _e = __asyncValues(this.getHeaders()), _f; _f = yield _e.next(), _a = _f.done, !_a;){
                    _c = _f.value;
                    _d = false;
                    try {
                        const { id } = _c;
                        ids[count] = id;
                        count++;
                    } finally{
                        _d = true;
                    }
                }
            } catch (e_1_1) {
                e_1 = {
                    error: e_1_1
                };
            } finally{
                try {
                    if (!_d && !_a && (_b = _e.return)) yield _b.call(_e);
                } finally{
                    if (e_1) throw e_1.error;
                }
            }
            return ids;
        });
    }
    getRaw() {
        var _a, e_2, _b, _c;
        return __awaiter(this, void 0, void 0, function*() {
            const streams = [
                (0, fs_1.createReadStream)(this.headerFile),
                ...this.txs.map((t)=>(0, fs_1.createReadStream)(t))
            ];
            const stream = multistream_1.default.obj(streams);
            let buff = Buffer.allocUnsafe(0);
            try {
                for(var _d = true, stream_1 = __asyncValues(stream), stream_1_1; stream_1_1 = yield stream_1.next(), _a = stream_1_1.done, !_a;){
                    _c = stream_1_1.value;
                    _d = false;
                    try {
                        const chunk = _c;
                        buff = Buffer.concat([
                            buff,
                            Buffer.from(chunk)
                        ]);
                    } finally{
                        _d = true;
                    }
                }
            } catch (e_2_1) {
                e_2 = {
                    error: e_2_1
                };
            } finally{
                try {
                    if (!_d && !_a && (_b = stream_1.return)) yield _b.call(stream_1);
                } finally{
                    if (e_2) throw e_2.error;
                }
            }
            return buff;
        });
    }
    toTransaction(attributes, arweave, jwk) {
        return __awaiter(this, void 0, void 0, function*() {
            const streams = [
                (0, fs_1.createReadStream)(this.headerFile),
                ...this.txs.map((t)=>(0, fs_1.createReadStream)(t))
            ];
            const stream = multistream_1.default.obj(streams);
            const tx = yield (0, promises_1.pipeline)(stream, arweave.stream.createTransactionAsync(attributes, jwk));
            tx.addTag("Bundle-Format", "binary");
            tx.addTag("Bundle-Version", "2.0.0");
            return tx;
        });
    }
    signAndSubmit(arweave, jwk, tags = []) {
        return __awaiter(this, void 0, void 0, function*() {
            const tx = yield this.toTransaction({}, arweave, jwk);
            // tx.addTag("Bundle-Format", "binary");
            // tx.addTag("Bundle-Version", "2.0.0");
            for (const { name, value } of tags){
                tx.addTag(name, value);
            }
            yield arweave.transactions.sign(tx, jwk);
            const streams2 = [
                (0, fs_1.createReadStream)(this.headerFile),
                ...this.txs.map((t)=>(0, fs_1.createReadStream)(t))
            ];
            const stream2 = multistream_1.default.obj(streams2);
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            yield (0, promises_1.pipeline)(stream2, arweave.stream.uploadTransactionAsync(tx, true));
            return tx;
        });
    }
    getHeaders() {
        return __asyncGenerator(this, arguments, function* getHeaders_1() {
            const handle = yield __await(fs_1.promises.open(this.headerFile, "r"));
            for(let i = 32; i < 32 + 64 * (yield __await(this.length())); i += 64){
                yield yield __await({
                    offset: (0, utils_1.byteArrayToLong)((yield __await(read(handle.fd, Buffer.allocUnsafe(32), 0, 32, i).then((r)=>r.buffer)))),
                    id: yield __await(read(handle.fd, Buffer.allocUnsafe(32), 0, 32, i + 32).then((r)=>base64url_1.default.encode(r.buffer)))
                });
            }
            yield __await(handle.close());
        });
    }
    itemsGenerator() {
        return __asyncGenerator(this, arguments, function* itemsGenerator_1() {
            var _a, e_3, _b, _c;
            let counter = 0;
            try {
                for(var _d = true, _e = __asyncValues(this.getHeaders()), _f; _f = yield __await(_e.next()), _a = _f.done, !_a;){
                    _c = _f.value;
                    _d = false;
                    try {
                        const { id } = _c;
                        yield yield __await(new FileDataItem_1.default(this.txs[counter], base64url_1.default.toBuffer(id)));
                        counter++;
                    } finally{
                        _d = true;
                    }
                }
            } catch (e_3_1) {
                e_3 = {
                    error: e_3_1
                };
            } finally{
                try {
                    if (!_d && !_a && (_b = _e.return)) yield __await(_b.call(_e));
                } finally{
                    if (e_3) throw e_3.error;
                }
            }
        });
    }
    getById(txId) {
        var _a, e_4, _b, _c;
        return __awaiter(this, void 0, void 0, function*() {
            let counter = 0;
            try {
                for(var _d = true, _e = __asyncValues(this.getHeaders()), _f; _f = yield _e.next(), _a = _f.done, !_a;){
                    _c = _f.value;
                    _d = false;
                    try {
                        const { id } = _c;
                        if (id === txId) return new FileDataItem_1.default(this.txs[counter], base64url_1.default.toBuffer(id));
                        counter++;
                    } finally{
                        _d = true;
                    }
                }
            } catch (e_4_1) {
                e_4 = {
                    error: e_4_1
                };
            } finally{
                try {
                    if (!_d && !_a && (_b = _e.return)) yield _b.call(_e);
                } finally{
                    if (e_4) throw e_4.error;
                }
            }
            throw new Error("Can't find by id");
        });
    }
    getByIndex(index) {
        var _a, e_5, _b, _c;
        return __awaiter(this, void 0, void 0, function*() {
            let count = 0;
            try {
                for(var _d = true, _e = __asyncValues(this.getHeaders()), _f; _f = yield _e.next(), _a = _f.done, !_a;){
                    _c = _f.value;
                    _d = false;
                    try {
                        const { id } = _c;
                        if (count === index) {
                            return new FileDataItem_1.default(this.txs[count], base64url_1.default.toBuffer(id));
                        }
                        count++;
                    } finally{
                        _d = true;
                    }
                }
            } catch (e_5_1) {
                e_5 = {
                    error: e_5_1
                };
            } finally{
                try {
                    if (!_d && !_a && (_b = _e.return)) yield _b.call(_e);
                } finally{
                    if (e_5) throw e_5.error;
                }
            }
            throw new Error("Can't find by index");
        });
    }
}
exports.FileBundle = FileBundle;
exports.default = FileBundle; //# sourceMappingURL=FileBundle.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/bundleData.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.bundleAndSignData = void 0;
const tmp_promise_1 = __turbopack_require__("[project]/node_modules/.pnpm/tmp-promise@3.0.3/node_modules/tmp-promise/index.js [app-route] (ecmascript)");
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/utils.js [app-route] (ecmascript)");
const FileBundle_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/FileBundle.js [app-route] (ecmascript)"));
const fs_1 = __turbopack_require__("[externals]/fs [external] (fs, cjs)");
function bundleAndSignData(dataItems, signer, dir) {
    return __awaiter(this, void 0, void 0, function*() {
        const headerFile = yield (0, tmp_promise_1.file)({
            dir
        });
        const headerStream = (0, fs_1.createWriteStream)(headerFile.path);
        const files = new Array(dataItems.length);
        headerStream.write((0, utils_1.longTo32ByteArray)(dataItems.length));
        for (const [index, item] of dataItems.entries()){
            const dataItem = item;
            if (!dataItem.isSigned()) {
                yield dataItem.sign(signer);
            }
            files[index] = dataItem.filename;
            headerStream.write(Buffer.concat([
                Buffer.from((0, utils_1.longTo32ByteArray)((yield dataItem.size()))),
                dataItem.rawId
            ]));
        }
        yield new Promise((resolve)=>headerStream.end(resolve));
        headerStream.close();
        return new FileBundle_1.default(headerFile.path, files);
    });
}
exports.bundleAndSignData = bundleAndSignData; //# sourceMappingURL=bundleData.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/createData.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createData = void 0;
const FileDataItem_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/FileDataItem.js [app-route] (ecmascript)"));
const tmp_promise_1 = __turbopack_require__("[project]/node_modules/.pnpm/tmp-promise@3.0.3/node_modules/tmp-promise/index.js [app-route] (ecmascript)");
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/utils.js [app-route] (ecmascript)");
const tags_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/tags.js [app-route] (ecmascript)");
const promises_1 = __turbopack_require__("[externals]/stream/promises [external] (stream/promises, cjs)");
const fs_1 = __turbopack_require__("[externals]/fs [external] (fs, cjs)");
function createData(data, signer, opts) {
    var _a, _b, _c, _d, _e;
    return __awaiter(this, void 0, void 0, function*() {
        const filename = yield (0, tmp_promise_1.tmpName)();
        const stream = (0, fs_1.createWriteStream)(filename);
        // TODO: Add asserts
        // Parse all values to a buffer and
        const _owner = signer.publicKey;
        const _target = (opts === null || opts === void 0 ? void 0 : opts.target) ? base64url_1.default.toBuffer(opts.target) : null;
        const _anchor = (opts === null || opts === void 0 ? void 0 : opts.anchor) ? Buffer.from(opts.anchor) : null;
        // @ts-expect-error undefined opts.tags already has a guard
        const _tags = ((_b = (_a = opts === null || opts === void 0 ? void 0 : opts.tags) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0) > 0 ? (0, tags_1.serializeTags)(opts.tags) : null;
        stream.write((0, utils_1.shortTo2ByteArray)(signer.signatureType));
        // Signature
        stream.write(new Uint8Array(signer.signatureLength).fill(0));
        if (_owner.byteLength !== signer.ownerLength) new Error(`Owner must be ${signer.ownerLength} bytes`);
        stream.write(_owner);
        stream.write(_target ? singleItemBuffer(1) : singleItemBuffer(0));
        if (_target) {
            if (_target.byteLength !== 32) throw new Error("Target must be 32 bytes");
            stream.write(_target);
        }
        stream.write(_anchor ? singleItemBuffer(1) : singleItemBuffer(0));
        if (_anchor) {
            if (_anchor.byteLength !== 32) throw new Error("Anchor must be 32 bytes");
            stream.write(_anchor);
        }
        // TODO: Shall I manually add 8 bytes?
        // TODO: Finish this
        stream.write((0, utils_1.longTo8ByteArray)((_d = (_c = opts === null || opts === void 0 ? void 0 : opts.tags) === null || _c === void 0 ? void 0 : _c.length) !== null && _d !== void 0 ? _d : 0));
        const bytesCount = (0, utils_1.longTo8ByteArray)((_e = _tags === null || _tags === void 0 ? void 0 : _tags.byteLength) !== null && _e !== void 0 ? _e : 0);
        stream.write(bytesCount);
        if (_tags) {
            stream.write(_tags);
        }
        if (typeof data[Symbol.asyncIterator] === "function") {
            yield (0, promises_1.pipeline)(data, stream);
        } else {
            stream.write(Buffer.from(data));
        }
        yield new Promise((resolve)=>{
            stream.end(resolve);
        });
        return new FileDataItem_1.default(filename);
    });
}
exports.createData = createData;
function singleItemBuffer(i) {
    return Buffer.from([
        i
    ]);
} //# sourceMappingURL=createData.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/file.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __await = this && this.__await || function(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
};
var __asyncGenerator = this && this.__asyncGenerator || function(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i;
    "TURBOPACK unreachable";
    function verb(n) {
        if (g[n]) i[n] = function(v) {
            return new Promise(function(a, b) {
                q.push([
                    n,
                    v,
                    a,
                    b
                ]) > 1 || resume(n, v);
            });
        };
    }
    function resume(n, v) {
        try {
            step(g[n](v));
        } catch (e) {
            settle(q[0][3], e);
        }
    }
    function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
        resume("next", value);
    }
    function reject(value) {
        resume("throw", value);
    }
    function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.fileExportForTesting = exports.signedFileStream = exports.getTags = exports.getAnchor = exports.getTarget = exports.getOwner = exports.getSignature = exports.getId = exports.getHeaders = exports.getHeaderAt = exports.numberOfItems = exports.fileToJson = void 0;
const fs_1 = __turbopack_require__("[externals]/fs [external] (fs, cjs)");
const util_1 = __turbopack_require__("[externals]/util [external] (util, cjs)");
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/utils.js [app-route] (ecmascript)");
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const index_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/stream/index.js [app-route] (ecmascript)");
const tags_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/tags.js [app-route] (ecmascript)");
const read = (0, util_1.promisify)(fs_1.read);
const fileToFd = (f)=>__awaiter(void 0, void 0, void 0, function*() {
        return typeof f === "string" ? yield fs_1.promises.open(f, "r") : f;
    });
function fileToJson(filename) {
    return __awaiter(this, void 0, void 0, function*() {
        const handle = yield fs_1.promises.open(filename, "r");
        const fd = handle.fd;
        let tagsStart = 512 + 512 + 2;
        const targetPresent = yield read(fd, Buffer.alloc(1), 1024, 64, null).then((value)=>value.buffer[0] == 1);
        tagsStart += targetPresent ? 32 : 0;
        const anchorPresentByte = targetPresent ? 1057 : 1025;
        const anchorPresent = yield read(fd, Buffer.alloc(1), anchorPresentByte, 64, null).then((value)=>value.buffer[0] == 1);
        tagsStart += anchorPresent ? 32 : 0;
        const numberOfTags = (0, utils_1.byteArrayToLong)((yield read(fd, Buffer.alloc(8), tagsStart, 8, 0).then((value)=>value.buffer)));
        let tags = [];
        if (numberOfTags > 0) {
            const numberOfTagBytesArray = yield read(fd, Buffer.alloc(8), tagsStart + 8, 8, 0).then((value)=>value.buffer);
            const numberOfTagBytes = (0, utils_1.byteArrayToLong)(numberOfTagBytesArray);
            const tagBytes = yield read(fd, Buffer.alloc(8), tagsStart + 16, numberOfTagBytes, 0).then((value)=>value.buffer);
            tags = (0, tags_1.deserializeTags)(tagBytes);
        }
        const id = filename;
        const owner = "";
        const target = "";
        const data_size = 0;
        const fee = 0;
        const signature = "";
        yield handle.close();
        return {
            id,
            owner,
            tags,
            target,
            data_size,
            fee,
            signature
        };
    });
}
exports.fileToJson = fileToJson;
function numberOfItems(file) {
    return __awaiter(this, void 0, void 0, function*() {
        const fd = yield fileToFd(file);
        const headerBuffer = yield read(fd.fd, Buffer.allocUnsafe(32), 0, 32, 0).then((v)=>v.buffer);
        yield fd.close();
        return (0, utils_1.byteArrayToLong)(headerBuffer);
    });
}
exports.numberOfItems = numberOfItems;
function getHeaderAt(file, index) {
    return __awaiter(this, void 0, void 0, function*() {
        const fd = yield fileToFd(file);
        const headerBuffer = yield read(fd.fd, Buffer.alloc(64), 0, 64, 32 + 64 * index).then((v)=>v.buffer);
        yield fd.close();
        return {
            offset: (0, utils_1.byteArrayToLong)(headerBuffer.subarray(0, 32)),
            id: base64url_1.default.encode(headerBuffer.subarray(32, 64))
        };
    });
}
exports.getHeaderAt = getHeaderAt;
function getHeaders(file) {
    return __asyncGenerator(this, arguments, function* getHeaders_1() {
        const count = yield __await(numberOfItems(file));
        for(let i = 0; i < count; i++){
            yield yield __await(getHeaderAt(file, i));
        }
    });
}
exports.getHeaders = getHeaders;
function getId(file, options) {
    var _a;
    return __awaiter(this, void 0, void 0, function*() {
        const fd = yield fileToFd(file);
        const offset = (_a = options === null || options === void 0 ? void 0 : options.offset) !== null && _a !== void 0 ? _a : 0;
        const buffer = yield read(fd.fd, Buffer.allocUnsafe(512), offset, 512, null).then((r)=>r.buffer);
        yield fd.close();
        return buffer;
    });
}
exports.getId = getId;
function getSignature(file, options) {
    var _a;
    return __awaiter(this, void 0, void 0, function*() {
        const fd = yield fileToFd(file);
        const offset = (_a = options === null || options === void 0 ? void 0 : options.offset) !== null && _a !== void 0 ? _a : 0;
        const buffer = yield read(fd.fd, Buffer.allocUnsafe(512), offset, 512, null).then((r)=>r.buffer);
        yield fd.close();
        return buffer;
    });
}
exports.getSignature = getSignature;
function getOwner(file, options) {
    var _a;
    return __awaiter(this, void 0, void 0, function*() {
        const fd = yield fileToFd(file);
        const offset = (_a = options === null || options === void 0 ? void 0 : options.offset) !== null && _a !== void 0 ? _a : 0;
        const buffer = yield read(fd.fd, Buffer.allocUnsafe(512), offset + 512, 512, null).then((r)=>r.buffer);
        yield fd.close();
        return base64url_1.default.encode(buffer);
    });
}
exports.getOwner = getOwner;
function getTarget(file, options) {
    var _a;
    return __awaiter(this, void 0, void 0, function*() {
        const fd = yield fileToFd(file);
        const offset = (_a = options === null || options === void 0 ? void 0 : options.offset) !== null && _a !== void 0 ? _a : 0;
        const targetStart = offset + 1024;
        const targetPresent = yield read(fd.fd, Buffer.allocUnsafe(1), targetStart, 1, null).then((value)=>value.buffer[0] == 1);
        if (!targetPresent) {
            yield fd.close();
            return undefined;
        }
        const buffer = yield read(fd.fd, Buffer.allocUnsafe(32), targetStart + 1, 32, null).then((r)=>r.buffer);
        yield fd.close();
        return base64url_1.default.encode(buffer);
    });
}
exports.getTarget = getTarget;
function getAnchor(file, options) {
    var _a;
    return __awaiter(this, void 0, void 0, function*() {
        const fd = yield fileToFd(file);
        const offset = (_a = options === null || options === void 0 ? void 0 : options.offset) !== null && _a !== void 0 ? _a : 0;
        const targetPresent = yield read(fd.fd, Buffer.allocUnsafe(1), 1024, 1, null).then((value)=>value.buffer[0] == 1);
        let anchorStart = offset + 1025;
        if (targetPresent) {
            anchorStart += 32;
        }
        const anchorPresent = yield read(fd.fd, Buffer.allocUnsafe(1), anchorStart, 1, null).then((value)=>value.buffer[0] == 1);
        if (!anchorPresent) {
            yield fd.close();
            return undefined;
        }
        const buffer = yield read(fd.fd, Buffer.allocUnsafe(32), anchorStart + 1, 32, null).then((r)=>r.buffer);
        yield fd.close();
        return base64url_1.default.encode(buffer);
    });
}
exports.getAnchor = getAnchor;
function getTags(file, options) {
    var _a, _b;
    return __awaiter(this, void 0, void 0, function*() {
        const fd = yield fileToFd(file);
        const offset = (_a = options === null || options === void 0 ? void 0 : options.offset) !== null && _a !== void 0 ? _a : 0;
        let tagsStart = 512 + 512 + 2 + ((_b = options === null || options === void 0 ? void 0 : options.offset) !== null && _b !== void 0 ? _b : 0);
        const targetPresent = yield read(fd.fd, Buffer.allocUnsafe(1), 0, 1, offset + 1024).then((value)=>value.buffer[0] == 1);
        tagsStart += targetPresent ? 32 : 0;
        const anchorPresentByte = offset + (targetPresent ? 1057 : 1025);
        const anchorPresent = yield read(fd.fd, Buffer.allocUnsafe(1), 0, 1, anchorPresentByte).then((value)=>value.buffer[0] == 1);
        tagsStart += anchorPresent ? 32 : 0;
        const numberOfTags = (0, utils_1.byteArrayToLong)((yield read(fd.fd, Buffer.allocUnsafe(8), 0, 8, tagsStart).then((value)=>value.buffer)));
        if (numberOfTags == 0) {
            yield fd.close();
            return [];
        }
        const numberOfTagBytesArray = yield read(fd.fd, Buffer.allocUnsafe(8), 0, 8, tagsStart + 8).then((value)=>value.buffer);
        const numberOfTagBytes = (0, utils_1.byteArrayToLong)(numberOfTagBytesArray);
        const tagBytes = yield read(fd.fd, Buffer.allocUnsafe(numberOfTagBytes), 0, numberOfTagBytes, tagsStart + 16).then((value)=>value.buffer);
        yield fd.close();
        return (0, tags_1.deserializeTags)(tagBytes);
    });
}
exports.getTags = getTags;
function signedFileStream(path, signer, opts) {
    return __awaiter(this, void 0, void 0, function*() {
        return (0, index_1.streamSigner)((0, fs_1.createReadStream)(path), (0, fs_1.createReadStream)(path), signer, opts);
    });
}
exports.signedFileStream = signedFileStream;
exports.fileExportForTesting = {
    fileToFd
}; //# sourceMappingURL=file.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/bundleData.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/createData.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/file.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/FileBundle.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/FileDataItem.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.file = void 0;
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/stream/index.js [app-route] (ecmascript)"), exports);
exports.file = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/node/cjs/src/file/index.js [app-route] (ecmascript)")); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/Signer.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Signer = void 0;
class Signer {
    static verify(_pk, _message, _signature, _opts) {
        throw new Error("You must implement verify method on child");
    }
}
exports.Signer = Signer; //# sourceMappingURL=Signer.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SIG_CONFIG = exports.SignatureConfig = void 0;
var SignatureConfig;
(function(SignatureConfig) {
    SignatureConfig[SignatureConfig["ARWEAVE"] = 1] = "ARWEAVE";
    SignatureConfig[SignatureConfig["ED25519"] = 2] = "ED25519";
    SignatureConfig[SignatureConfig["ETHEREUM"] = 3] = "ETHEREUM";
    SignatureConfig[SignatureConfig["SOLANA"] = 4] = "SOLANA";
    SignatureConfig[SignatureConfig["INJECTEDAPTOS"] = 5] = "INJECTEDAPTOS";
    SignatureConfig[SignatureConfig["MULTIAPTOS"] = 6] = "MULTIAPTOS";
    SignatureConfig[SignatureConfig["TYPEDETHEREUM"] = 7] = "TYPEDETHEREUM";
})(SignatureConfig = exports.SignatureConfig || (exports.SignatureConfig = {}));
exports.SIG_CONFIG = {
    [SignatureConfig.ARWEAVE]: {
        sigLength: 512,
        pubLength: 512,
        sigName: "arweave"
    },
    [SignatureConfig.ED25519]: {
        sigLength: 64,
        pubLength: 32,
        sigName: "ed25519"
    },
    [SignatureConfig.ETHEREUM]: {
        sigLength: 65,
        pubLength: 65,
        sigName: "ethereum"
    },
    [SignatureConfig.SOLANA]: {
        sigLength: 64,
        pubLength: 32,
        sigName: "solana"
    },
    [SignatureConfig.INJECTEDAPTOS]: {
        sigLength: 64,
        pubLength: 32,
        sigName: "injectedAptos"
    },
    [SignatureConfig.MULTIAPTOS]: {
        sigLength: 64 * 32 + 4,
        pubLength: 32 * 32 + 1,
        sigName: "multiAptos"
    },
    [SignatureConfig.TYPEDETHEREUM]: {
        sigLength: 65,
        pubLength: 42,
        sigName: "typedEthereum"
    }
}; //# sourceMappingURL=constants.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/curve25519.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)");
const ed25519_1 = __turbopack_require__("[project]/node_modules/.pnpm/@noble+ed25519@1.7.3/node_modules/@noble/ed25519/lib/index.js [app-route] (ecmascript)");
class Curve25519 {
    get publicKey() {
        return this._publicKey;
    }
    constructor(_key, pk){
        this._key = _key;
        this.pk = pk;
        this.ownerLength = constants_1.SIG_CONFIG[2].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[2].sigLength;
        this.signatureType = 2;
    }
    get key() {
        throw new Error("You must implement `key`");
    }
    sign(message) {
        return (0, ed25519_1.sign)(Buffer.from(message), Buffer.from(this.key));
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            let p = pk;
            if (typeof pk === "string") p = base64url_1.default.toBuffer(pk);
            return (0, ed25519_1.verify)(Buffer.from(signature), Buffer.from(message), Buffer.from(p));
        });
    }
}
exports.default = Curve25519; //# sourceMappingURL=curve25519.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/deepHash.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = this && this.__asyncValues || function(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i);
    "TURBOPACK unreachable";
    function verb(n) {
        i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
                v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
        };
    }
    function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function(v) {
            resolve({
                value: v,
                done: d
            });
        }, reject);
    }
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.hashStream = exports.deepHashChunks = exports.deepHash = void 0;
// In TypeScript 3.7, could be written as a single type:
// `type DeepHashChunk = Uint8Array | DeepHashChunk[];`
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/nodeUtils.js [app-route] (ecmascript)");
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
function deepHash(data) {
    var _a, e_1, _b, _c;
    return __awaiter(this, void 0, void 0, function*() {
        if (typeof data[Symbol.asyncIterator] === "function") {
            const _data = data;
            const context = (0, crypto_1.createHash)("sha384");
            let length = 0;
            try {
                for(var _d = true, _data_1 = __asyncValues(_data), _data_1_1; _data_1_1 = yield _data_1.next(), _a = _data_1_1.done, !_a;){
                    _c = _data_1_1.value;
                    _d = false;
                    try {
                        const chunk = _c;
                        length += chunk.byteLength;
                        context.update(chunk);
                    } finally{
                        _d = true;
                    }
                }
            } catch (e_1_1) {
                e_1 = {
                    error: e_1_1
                };
            } finally{
                try {
                    if (!_d && !_a && (_b = _data_1.return)) yield _b.call(_data_1);
                } finally{
                    if (e_1) throw e_1.error;
                }
            }
            const tag = (0, utils_1.concatBuffers)([
                (0, utils_1.stringToBuffer)("blob"),
                (0, utils_1.stringToBuffer)(length.toString())
            ]);
            const taggedHash = (0, utils_1.concatBuffers)([
                (yield (0, utils_1.getCryptoDriver)().hash(tag, "SHA-384")),
                context.digest()
            ]);
            return yield (0, utils_1.getCryptoDriver)().hash(taggedHash, "SHA-384");
        } else if (Array.isArray(data)) {
            const tag = (0, utils_1.concatBuffers)([
                (0, utils_1.stringToBuffer)("list"),
                (0, utils_1.stringToBuffer)(data.length.toString())
            ]);
            return yield deepHashChunks(data, (yield (0, utils_1.getCryptoDriver)().hash(tag, "SHA-384")));
        }
        const _data = data;
        const tag = (0, utils_1.concatBuffers)([
            (0, utils_1.stringToBuffer)("blob"),
            (0, utils_1.stringToBuffer)(_data.byteLength.toString())
        ]);
        const taggedHash = (0, utils_1.concatBuffers)([
            (yield (0, utils_1.getCryptoDriver)().hash(tag, "SHA-384")),
            (yield (0, utils_1.getCryptoDriver)().hash(_data, "SHA-384"))
        ]);
        return yield (0, utils_1.getCryptoDriver)().hash(taggedHash, "SHA-384");
    });
}
exports.deepHash = deepHash;
function deepHashChunks(chunks, acc) {
    return __awaiter(this, void 0, void 0, function*() {
        if (chunks.length < 1) {
            return acc;
        }
        const hashPair = (0, utils_1.concatBuffers)([
            acc,
            (yield deepHash(chunks[0]))
        ]);
        const newAcc = yield (0, utils_1.getCryptoDriver)().hash(hashPair, "SHA-384");
        return yield deepHashChunks(chunks.slice(1), newAcc);
    });
}
exports.deepHashChunks = deepHashChunks;
function hashStream(stream) {
    var _a, stream_1, stream_1_1;
    var _b, e_2, _c, _d;
    return __awaiter(this, void 0, void 0, function*() {
        const context = (0, crypto_1.createHash)("sha384");
        try {
            for(_a = true, stream_1 = __asyncValues(stream); stream_1_1 = yield stream_1.next(), _b = stream_1_1.done, !_b;){
                _d = stream_1_1.value;
                _a = false;
                try {
                    const chunk = _d;
                    context.update(chunk);
                } finally{
                    _a = true;
                }
            }
        } catch (e_2_1) {
            e_2 = {
                error: e_2_1
            };
        } finally{
            try {
                if (!_a && !_b && (_c = stream_1.return)) yield _c.call(stream_1);
            } finally{
                if (e_2) throw e_2.error;
            }
        }
        return context.digest();
    });
}
exports.hashStream = hashStream;
exports.default = deepHash; //# sourceMappingURL=deepHash.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/nodeUtils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getCryptoDriver = exports.CryptoDriver = exports.Arweave = exports.deepHash = exports.Transaction = exports.concatBuffers = exports.stringToBuffer = void 0;
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
const node_driver_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/node-driver.js [app-route] (ecmascript)"));
// import CryptoInterface from "arweave/node/lib/crypto/crypto-interface";
var utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/utils.js [app-route] (ecmascript)");
Object.defineProperty(exports, "stringToBuffer", {
    enumerable: true,
    get: function() {
        return utils_1.stringToBuffer;
    }
});
Object.defineProperty(exports, "concatBuffers", {
    enumerable: true,
    get: function() {
        return utils_1.concatBuffers;
    }
});
var transaction_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/transaction.js [app-route] (ecmascript)");
Object.defineProperty(exports, "Transaction", {
    enumerable: true,
    get: function() {
        return __importDefault(transaction_1).default;
    }
});
var deepHash_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/deepHash.js [app-route] (ecmascript)");
Object.defineProperty(exports, "deepHash", {
    enumerable: true,
    get: function() {
        return deepHash_1.deepHash;
    }
});
var node_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/index.js [app-route] (ecmascript)");
Object.defineProperty(exports, "Arweave", {
    enumerable: true,
    get: function() {
        return __importDefault(node_1).default;
    }
});
// hack as ESM won't unpack .default CJS imports, so we do so dynamically
// eslint-disable-next-line @typescript-eslint/dot-notation
const driver = node_driver_1.default["default"] ? node_driver_1.default["default"] : node_driver_1.default;
class CryptoDriver extends driver {
    getPublicKey(jwk) {
        return (0, crypto_1.createPublicKey)({
            key: this.jwkToPem(jwk),
            type: "pkcs1",
            format: "pem"
        }).export({
            format: "pem",
            type: "pkcs1"
        }).toString();
    }
}
exports.CryptoDriver = CryptoDriver;
let driverInstance;
function getCryptoDriver() {
    return driverInstance !== null && driverInstance !== void 0 ? driverInstance : driverInstance = new CryptoDriver();
}
exports.getCryptoDriver = getCryptoDriver; //# sourceMappingURL=nodeUtils.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/Rsa4096Pss.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/nodeUtils.js [app-route] (ecmascript)");
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)");
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
class Rsa4096Pss {
    get publicKey() {
        return this._publicKey;
    }
    constructor(_key, pk){
        this._key = _key;
        this.pk = pk;
        this.signatureType = 1;
        this.ownerLength = constants_1.SIG_CONFIG[1].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[1].sigLength;
        if (!pk) {
            this.pk = (0, utils_1.getCryptoDriver)().getPublicKey(JSON.parse(_key));
        }
    }
    sign(message) {
        return (0, crypto_1.createSign)("sha256").update(message).sign({
            key: this._key,
            padding: crypto_1.constants.RSA_PKCS1_PSS_PADDING
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            return yield (0, utils_1.getCryptoDriver)().verify(Buffer.isBuffer(pk) ? base64url_1.default.encode(pk) : pk, message, signature);
        });
    }
}
exports.default = Rsa4096Pss; //# sourceMappingURL=Rsa4096Pss.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/ArweaveSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const Rsa4096Pss_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/Rsa4096Pss.js [app-route] (ecmascript)"));
const pem_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/crypto/pem.js [app-route] (ecmascript)");
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/nodeUtils.js [app-route] (ecmascript)");
class ArweaveSigner extends Rsa4096Pss_1.default {
    constructor(jwk){
        super((0, pem_1.jwkTopem)(jwk), jwk.n);
        this.jwk = jwk;
    }
    get publicKey() {
        if (!this.pk) throw new Error("ArweaveSigner - pk is undefined");
        return base64url_1.default.toBuffer(this.pk);
    }
    sign(message) {
        return (0, utils_1.getCryptoDriver)().sign(this.jwk, message);
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            return yield (0, utils_1.getCryptoDriver)().verify(pk, message, signature);
        });
    }
}
exports.default = ArweaveSigner; //# sourceMappingURL=ArweaveSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/injectedSolanaSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)");
const ed25519_1 = __turbopack_require__("[project]/node_modules/.pnpm/@noble+ed25519@1.7.3/node_modules/@noble/ed25519/lib/index.js [app-route] (ecmascript)");
class InjectedSolanaSigner {
    constructor(provider){
        this.ownerLength = constants_1.SIG_CONFIG[2].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[2].sigLength;
        this.signatureType = 2;
        this.provider = provider;
        if (!this.provider.publicKey) throw new Error("InjectedSolanaSigner - provider.publicKey is undefined");
        this._publicKey = this.provider.publicKey.toBuffer();
    }
    get publicKey() {
        return this._publicKey;
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!this.provider.signMessage) throw new Error("Selected Wallet does not support message signing");
            return yield this.provider.signMessage(message);
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            let p = pk;
            if (typeof pk === "string") p = base64url_1.default.toBuffer(pk);
            return (0, ed25519_1.verify)(Buffer.from(signature), Buffer.from(message), Buffer.from(p));
        });
    }
}
exports.default = InjectedSolanaSigner; //# sourceMappingURL=injectedSolanaSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/injectedEthereumSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.InjectedEthereumSigner = void 0;
const hash_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+hash@5.7.0/node_modules/@ethersproject/hash/lib.esm/index.js [app-route] (ecmascript)");
const signing_key_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+signing-key@5.7.0/node_modules/@ethersproject/signing-key/lib.esm/index.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)");
const bytes_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+bytes@5.7.0/node_modules/@ethersproject/bytes/lib.esm/index.js [app-route] (ecmascript)");
const transactions_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+transactions@5.7.0/node_modules/@ethersproject/transactions/lib.esm/index.js [app-route] (ecmascript)");
const wallet_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+wallet@5.7.0/node_modules/@ethersproject/wallet/lib.esm/index.js [app-route] (ecmascript)");
class InjectedEthereumSigner {
    constructor(provider){
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.ETHEREUM].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.ETHEREUM].sigLength;
        this.signatureType = constants_1.SignatureConfig.ETHEREUM;
        this.signer = provider.getSigner();
    }
    setPublicKey() {
        return __awaiter(this, void 0, void 0, function*() {
            const address = "sign this message to connect to Bundlr.Network";
            const signedMsg = yield this.signer.signMessage(address);
            const hash = yield (0, hash_1.hashMessage)(address);
            const recoveredKey = (0, signing_key_1.recoverPublicKey)((0, bytes_1.arrayify)(hash), signedMsg);
            this.publicKey = Buffer.from((0, bytes_1.arrayify)(recoveredKey));
        });
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!this.publicKey) {
                yield this.setPublicKey();
            }
            const sig = yield this.signer.signMessage(message);
            return Buffer.from(sig.slice(2), "hex");
        });
    }
    static verify(pk, message, signature) {
        const address = (0, transactions_1.computeAddress)(pk);
        return (0, wallet_1.verifyMessage)(message, signature) === address;
    }
}
exports.InjectedEthereumSigner = InjectedEthereumSigner;
exports.default = InjectedEthereumSigner; //# sourceMappingURL=injectedEthereumSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/SolanaSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const curve25519_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/curve25519.js [app-route] (ecmascript)"));
const bs58_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bs58@4.0.1/node_modules/bs58/index.js [app-route] (ecmascript)"));
class SolanaSigner extends curve25519_1.default {
    get publicKey() {
        return bs58_1.default.decode(this.pk);
    }
    get key() {
        return bs58_1.default.decode(this._key);
    }
    constructor(_key){
        const b = bs58_1.default.decode(_key);
        super(bs58_1.default.encode(b.subarray(0, 32)), bs58_1.default.encode(b.subarray(32, 64)));
    }
}
exports.default = SolanaSigner; //# sourceMappingURL=SolanaSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keccak256.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.exportForTesting = exports.keccak256 = void 0;
/* eslint-disable @typescript-eslint/explicit-function-return-type */ const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const buffer_1 = __turbopack_require__("[externals]/buffer [external] (buffer, cjs)");
const keccak_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/keccak@3.0.4/node_modules/keccak/index.js [app-route] (ecmascript)"));
function keccak256(value) {
    value = toBuffer(value);
    return (0, keccak_1.default)("keccak256").update(value).digest();
}
exports.keccak256 = keccak256;
function toBuffer(value) {
    if (!buffer_1.Buffer.isBuffer(value)) {
        if (Array.isArray(value)) {
            value = buffer_1.Buffer.from(value);
        } else if (typeof value === "string") {
            if (isHexString(value)) {
                value = buffer_1.Buffer.from(padToEven(stripHexPrefix(value)), "hex");
            } else {
                value = buffer_1.Buffer.from(value);
            }
        } else if (typeof value === "number") {
            value = intToBuffer(value);
        } else if (value === null || value === undefined) {
            value = buffer_1.Buffer.allocUnsafe(0);
        } else if (bn_js_1.default.isBN(value)) {
            value = value.toArrayLike(buffer_1.Buffer);
        } else if (value.toArray) {
            // converts a BN to a Buffer
            value = buffer_1.Buffer.from(value.toArray());
        } else {
            throw new Error("invalid type");
        }
    }
    return value;
}
function isHexString(value, length) {
    if (typeof value !== "string" || !value.match(/^0x[0-9A-Fa-f]*$/)) {
        return false;
    }
    if (length && value.length !== 2 + 2 * length) {
        return false;
    }
    return true;
}
function padToEven(value) {
    if (typeof value !== "string") {
        throw new Error(`while padding to even, value must be string, is currently ${typeof value}, while padToEven.`);
    }
    if (value.length % 2) {
        value = `0${value}`;
    }
    return value;
}
function stripHexPrefix(value) {
    if (typeof value !== "string") {
        return value;
    }
    return isHexPrefixed(value) ? value.slice(2) : value;
}
function isHexPrefixed(value) {
    if (typeof value !== "string") {
        throw new Error("value must be type 'string', is currently type " + typeof value + ", while checking isHexPrefixed.");
    }
    return value.startsWith("0x");
}
function intToBuffer(i) {
    const hex = intToHex(i);
    return buffer_1.Buffer.from(padToEven(hex.slice(2)), "hex");
}
function intToHex(i) {
    const hex = i.toString(16);
    return `0x${hex}`;
}
if ("TURBOPACK compile-time falsy", 0) {
    "TURBOPACK unreachable";
}
exports.default = keccak256;
exports.exportForTesting = {
    intToBuffer,
    intToHex,
    isHexPrefixed,
    stripHexPrefix,
    padToEven,
    isHexString,
    toBuffer
}; //# sourceMappingURL=keccak256.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/secp256k1.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const secp256k1_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/secp256k1@5.0.1/node_modules/secp256k1/index.js [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)");
const keccak256_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keccak256.js [app-route] (ecmascript)"));
class Secp256k1 {
    constructor(_key, pk){
        this._key = _key;
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.ETHEREUM].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.ETHEREUM].sigLength;
        this.signatureType = constants_1.SignatureConfig.ETHEREUM;
        this.pk = pk.toString("hex");
    }
    get publicKey() {
        throw new Error("You must implement `publicKey`");
    }
    get key() {
        return Buffer.from(this._key, "hex");
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            let p = pk;
            if (typeof pk === "string") p = base64url_1.default.toBuffer(pk);
            let verified = false;
            try {
                verified = secp256k1_1.default.ecdsaVerify(signature, (0, keccak256_1.default)(Buffer.from(message)), p);
            // eslint-disable-next-line no-empty
            } catch (e) {}
            return verified;
        });
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            return secp256k1_1.default.ecdsaSign((0, keccak256_1.default)(Buffer.from(message)), Buffer.from(this.key)).signature;
        });
    }
}
exports.default = Secp256k1; //# sourceMappingURL=secp256k1.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/ethereumSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const secp256k1_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/secp256k1.js [app-route] (ecmascript)"));
const secp256k1_2 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/secp256k1@5.0.1/node_modules/secp256k1/index.js [app-route] (ecmascript)"));
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const bytes_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+bytes@5.7.0/node_modules/@ethersproject/bytes/lib.esm/index.js [app-route] (ecmascript)");
const wallet_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+wallet@5.7.0/node_modules/@ethersproject/wallet/lib.esm/index.js [app-route] (ecmascript)");
const hash_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+hash@5.7.0/node_modules/@ethersproject/hash/lib.esm/index.js [app-route] (ecmascript)");
class EthereumSigner extends secp256k1_1.default {
    get publicKey() {
        return Buffer.from(this.pk, "hex");
    }
    constructor(key){
        if (key.startsWith("0x")) key = key.slice(2);
        const b = Buffer.from(key, "hex");
        const pub = secp256k1_2.default.publicKeyCreate(b, false);
        super(key, Buffer.from(pub));
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            const wallet = new wallet_1.Wallet(this._key);
            return wallet.signMessage(message).then((r)=>Buffer.from(r.slice(2), "hex"));
        // below doesn't work due to lacking correct v derivation.
        // return Buffer.from(joinSignature(Buffer.from(secp256k1.ecdsaSign(arrayify(hashMessage(message)), this.key).signature)).slice(2), "hex");
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            // const address = ethers.utils.computeAddress(pk);
            // return ethers.utils.verifyMessage(message, signature) === address;
            return secp256k1_2.default.ecdsaVerify(signature.length === 65 ? signature.slice(0, -1) : signature, (0, bytes_1.arrayify)((0, hash_1.hashMessage)(message)), typeof pk === "string" ? base64url_1.default.toBuffer(pk) : pk);
        });
    }
}
exports.default = EthereumSigner; //# sourceMappingURL=ethereumSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/PolygonSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const ethereumSigner_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/ethereumSigner.js [app-route] (ecmascript)"));
class PolygonSigner extends ethereumSigner_1.default {
}
exports.default = PolygonSigner; //# sourceMappingURL=PolygonSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/NearSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const SolanaSigner_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/SolanaSigner.js [app-route] (ecmascript)"));
class NearSigner extends SolanaSigner_1.default {
    constructor(_key){
        super(_key.replace("ed25519:", ""));
    }
}
exports.default = NearSigner; //# sourceMappingURL=NearSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/AlgorandSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const curve25519_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/curve25519.js [app-route] (ecmascript)"));
class AlgorandSigner extends curve25519_1.default {
    get publicKey() {
        return Buffer.from(this.pk);
    }
    get key() {
        return Buffer.from(this._key);
    }
    constructor(key, pk){
        super(key.subarray(0, 32), pk);
    }
}
exports.default = AlgorandSigner; //# sourceMappingURL=AlgorandSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/HexInjectedSolanaSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const injectedSolanaSigner_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/injectedSolanaSigner.js [app-route] (ecmascript)"));
class HexSolanaSigner extends injectedSolanaSigner_1.default {
    constructor(provider){
        super(provider);
        this.signatureType = 4; // for solana sig type
    }
    sign(message) {
        const _super = Object.create(null, {
            sign: {
                get: ()=>super.sign
            }
        });
        return __awaiter(this, void 0, void 0, function*() {
            return _super.sign.call(this, Buffer.from(Buffer.from(message).toString("hex")));
        });
    }
    static verify(pk, message, signature) {
        const _super = Object.create(null, {
            verify: {
                get: ()=>super.verify
            }
        });
        return __awaiter(this, void 0, void 0, function*() {
            return _super.verify.call(this, pk, Buffer.from(Buffer.from(message).toString("hex")), signature);
        });
    }
}
exports.default = HexSolanaSigner; //# sourceMappingURL=HexInjectedSolanaSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/HexSolanaSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const SolanaSigner_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/SolanaSigner.js [app-route] (ecmascript)"));
class HexSolanaSigner extends SolanaSigner_1.default {
    constructor(provider){
        super(provider);
        this.signatureType = 4; // for solana sig type
    }
    sign(message) {
        const _super = Object.create(null, {
            sign: {
                get: ()=>super.sign
            }
        });
        return __awaiter(this, void 0, void 0, function*() {
            return _super.sign.call(this, Buffer.from(Buffer.from(message).toString("hex")));
        });
    }
    static verify(pk, message, signature) {
        const _super = Object.create(null, {
            verify: {
                get: ()=>super.verify
            }
        });
        return __awaiter(this, void 0, void 0, function*() {
            return _super.verify.call(this, pk, Buffer.from(Buffer.from(message).toString("hex")), signature);
        });
    }
}
exports.default = HexSolanaSigner; //# sourceMappingURL=HexSolanaSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/AptosSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const curve25519_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/curve25519.js [app-route] (ecmascript)"));
class AptosSigner extends curve25519_1.default {
    constructor(privKey, pubKey){
        super(privKey, pubKey);
    }
    get publicKey() {
        return Buffer.from(this.pk.slice(2), "hex");
    }
    get key() {
        return Buffer.from(this._key.slice(2), "hex");
    }
}
exports.default = AptosSigner; //# sourceMappingURL=AptosSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/InjectedAptosSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const ed25519_1 = __turbopack_require__("[project]/node_modules/.pnpm/@noble+ed25519@1.7.3/node_modules/@noble/ed25519/lib/index.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)");
class InjectedAptosSigner {
    constructor(provider, publicKey){
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.INJECTEDAPTOS].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.INJECTEDAPTOS].sigLength;
        this.signatureType = constants_1.SignatureConfig.INJECTEDAPTOS;
        this.provider = provider;
        this._publicKey = publicKey;
    }
    get publicKey() {
        return this._publicKey;
    }
    /**
     * signMessage constructs a message and then signs it.
     * the format is "APTOS(\n)
     * message: <hexString>(\n)
     * nonce: bundlr"
     */ sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!this.provider.signMessage) throw new Error("Selected Wallet does not support message signing");
            const signingResponse = yield this.provider.signMessage({
                message: Buffer.from(message).toString("hex"),
                nonce: "bundlr"
            });
            const signature = signingResponse.signature;
            return typeof signature === "string" ? Buffer.from(signature, "hex") : signature.data.toUint8Array();
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            const p = pk;
            return (0, ed25519_1.verify)(Buffer.from(signature), Buffer.from(`APTOS\nmessage: ${Buffer.from(message).toString("hex")}\nnonce: bundlr`), Buffer.from(p));
        });
    }
}
exports.default = InjectedAptosSigner; //# sourceMappingURL=InjectedAptosSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/multiSignatureAptos.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const ed25519_1 = __turbopack_require__("[project]/node_modules/.pnpm/@noble+ed25519@1.7.3/node_modules/@noble/ed25519/lib/index.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)");
class MultiSignatureAptosSigner {
    constructor(publicKey, collectSignatures){
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.MULTIAPTOS].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.MULTIAPTOS].sigLength;
        this.signatureType = constants_1.SignatureConfig.MULTIAPTOS;
        this._publicKey = publicKey;
        this.collectSignatures = collectSignatures;
    }
    get publicKey() {
        return this._publicKey;
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            const { signatures, bitmap: bits } = yield this.collectSignatures(message);
            // Bits are read from left to right. e.g. 0b10000000 represents the first bit is set in one byte.
            // The decimal value of 0b10000000 is 128.
            const firstBitInByte = 128;
            const bitmap = new Uint8Array([
                0,
                0,
                0,
                0
            ]);
            // Check if duplicates exist in bits
            const dupCheckSet = new Set();
            bits.forEach((bit)=>{
                if (bit >= 32) {
                    throw new Error(`Invalid bit value ${bit}.`);
                }
                if (dupCheckSet.has(bit)) {
                    throw new Error("Duplicated bits detected.");
                }
                dupCheckSet.add(bit);
                const byteOffset = Math.floor(bit / 8);
                let byte = bitmap[byteOffset];
                byte |= firstBitInByte >> bit % 8;
                bitmap[byteOffset] = byte;
            });
            const signature = Buffer.alloc(this.signatureLength);
            let sigPos = 0;
            for(let i = 0; i < 32; i++){
                if (bits.includes(i)) {
                    signature.set(signatures[sigPos++], i * 64);
                }
            }
            signature.set(bitmap, this.signatureLength - 4);
            return signature;
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            const signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.MULTIAPTOS].sigLength;
            const bitmapPos = signatureLength - 4;
            const signatures = signature.slice(0, bitmapPos);
            const encodedBitmap = signature.slice(bitmapPos);
            let oneFalse = false;
            for(let i = 0; i < 32; i++){
                // check bitmap
                const bucket = Math.floor(i / 8);
                const bucketPos = i - bucket * 8;
                const sigIncluded = (encodedBitmap[bucket] & 128 >> bucketPos) !== 0;
                if (sigIncluded) {
                    const signature = signatures.slice(i * 64, (i + 1) * 64);
                    const pubkey = pk.slice(i * 32, (i + 1) * 32);
                    if (!(yield (0, ed25519_1.verify)(Buffer.from(signature), Buffer.from(message), Buffer.from(pubkey)))) oneFalse = true;
                }
            }
            return !oneFalse;
        });
    }
}
exports.default = MultiSignatureAptosSigner; //# sourceMappingURL=multiSignatureAptos.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/TypedEthereumSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DOMAIN = exports.MESSAGE = exports.types = exports.domain = void 0;
const wallet_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+wallet@5.7.0/node_modules/@ethersproject/wallet/lib.esm/index.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)");
const keccak256_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keccak256.js [app-route] (ecmascript)"));
const ethereumSigner_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/ethereumSigner.js [app-route] (ecmascript)"));
class TypedEthereumSigner extends ethereumSigner_1.default {
    constructor(key){
        super(key);
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.TYPEDETHEREUM].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.TYPEDETHEREUM].sigLength;
        this.signatureType = constants_1.SignatureConfig.TYPEDETHEREUM;
        this.address = "0x" + (0, keccak256_1.default)(super.publicKey.slice(1)).slice(-20).toString("hex");
        this.signer = new wallet_1.Wallet(key);
    }
    get publicKey() {
        return Buffer.from(this.address);
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            const signature = yield this.signer._signTypedData(exports.domain, exports.types, {
                address: this.address,
                "Transaction hash": message
            });
            return Buffer.from(signature.slice(2), "hex"); // trim leading 0x, convert to hex.
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            const address = pk.toString();
            const addr = (0, wallet_1.verifyTypedData)(exports.domain, exports.types, {
                address,
                "Transaction hash": message
            }, signature);
            return address.toLowerCase() === addr.toLowerCase();
        });
    }
}
exports.default = TypedEthereumSigner;
exports.domain = {
    name: "Bundlr",
    version: "1"
};
exports.types = {
    Bundlr: [
        {
            name: "Transaction hash",
            type: "bytes"
        },
        {
            name: "address",
            type: "address"
        }
    ]
};
exports.MESSAGE = "Bundlr(bytes Transaction hash, address address)";
exports.DOMAIN = "EIP712Domain(string name,string version)"; //# sourceMappingURL=TypedEthereumSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/InjectedTypedEthereumSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.InjectedTypedEthereumSigner = void 0;
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)");
const wallet_1 = __turbopack_require__("[project]/node_modules/.pnpm/@ethersproject+wallet@5.7.0/node_modules/@ethersproject/wallet/lib.esm/index.js [app-route] (ecmascript)");
const TypedEthereumSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/TypedEthereumSigner.js [app-route] (ecmascript)");
class InjectedTypedEthereumSigner {
    constructor(provider){
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.TYPEDETHEREUM].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.TYPEDETHEREUM].sigLength;
        this.signatureType = constants_1.SignatureConfig.TYPEDETHEREUM;
        this.signer = provider.getSigner();
    }
    ready() {
        return __awaiter(this, void 0, void 0, function*() {
            this.address = (yield this.signer.getAddress()).toString().toLowerCase();
            this.publicKey = Buffer.from(this.address); // pk *is* address
        });
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            const signature = yield this.signer._signTypedData(TypedEthereumSigner_1.domain, TypedEthereumSigner_1.types, {
                address: this.address,
                "Transaction hash": message
            });
            return Buffer.from(signature.slice(2), "hex"); // trim leading 0x, convert to hex.
        });
    }
    static verify(pk, message, signature) {
        const address = pk.toString();
        const addr = (0, wallet_1.verifyTypedData)(TypedEthereumSigner_1.domain, TypedEthereumSigner_1.types, {
            address,
            "Transaction hash": message
        }, signature);
        return address.toLowerCase() === addr.toLowerCase();
    }
}
exports.InjectedTypedEthereumSigner = InjectedTypedEthereumSigner;
exports.default = InjectedTypedEthereumSigner; //# sourceMappingURL=InjectedTypedEthereumSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/arconnectSigner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)");
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/nodeUtils.js [app-route] (ecmascript)");
class InjectedArweaveSigner {
    constructor(windowArweaveWallet, arweave){
        this.ownerLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.ARWEAVE].pubLength;
        this.signatureLength = constants_1.SIG_CONFIG[constants_1.SignatureConfig.ARWEAVE].sigLength;
        this.signatureType = constants_1.SignatureConfig.ARWEAVE;
        this.signer = windowArweaveWallet;
        this.arweave = arweave;
    }
    setPublicKey() {
        return __awaiter(this, void 0, void 0, function*() {
            const arOwner = yield this.signer.getActivePublicKey();
            this.publicKey = base64url_1.default.toBuffer(arOwner);
        });
    }
    sign(message) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!this.publicKey) {
                yield this.setPublicKey();
            }
            const algorithm = {
                name: "RSA-PSS",
                saltLength: 32
            };
            const signature = yield this.signer.signature(message, algorithm);
            const buf = new Uint8Array(Object.values(signature).map((v)=>+v));
            return buf;
        });
    }
    static verify(pk, message, signature) {
        return __awaiter(this, void 0, void 0, function*() {
            return yield (0, utils_1.getCryptoDriver)().verify(pk, message, signature);
        });
    }
}
exports.default = InjectedArweaveSigner; //# sourceMappingURL=arconnectSigner.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ArconnectSigner = exports.TypedEthereumSigner = exports.MultiSignatureAptosSigner = exports.InjectedAptosSigner = exports.AptosSigner = exports.HexSolanaSigner = exports.HexInjectedSolanaSigner = exports.AlgorandSigner = exports.EthereumSigner = exports.NearSigner = exports.PolygonSigner = exports.SolanaSigner = exports.InjectedSolanaSigner = exports.ArweaveSigner = void 0;
var ArweaveSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/ArweaveSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "ArweaveSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(ArweaveSigner_1).default;
    }
});
var injectedSolanaSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/injectedSolanaSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "InjectedSolanaSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(injectedSolanaSigner_1).default;
    }
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/injectedEthereumSigner.js [app-route] (ecmascript)"), exports);
var SolanaSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/SolanaSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "SolanaSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(SolanaSigner_1).default;
    }
});
var PolygonSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/PolygonSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "PolygonSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(PolygonSigner_1).default;
    }
});
var NearSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/NearSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "NearSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(NearSigner_1).default;
    }
});
var ethereumSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/ethereumSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "EthereumSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(ethereumSigner_1).default;
    }
});
var AlgorandSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/AlgorandSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "AlgorandSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(AlgorandSigner_1).default;
    }
});
var HexInjectedSolanaSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/HexInjectedSolanaSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "HexInjectedSolanaSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(HexInjectedSolanaSigner_1).default;
    }
});
var HexSolanaSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/HexSolanaSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "HexSolanaSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(HexSolanaSigner_1).default;
    }
});
var AptosSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/AptosSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "AptosSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(AptosSigner_1).default;
    }
});
var InjectedAptosSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/InjectedAptosSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "InjectedAptosSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(InjectedAptosSigner_1).default;
    }
});
var multiSignatureAptos_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/multiSignatureAptos.js [app-route] (ecmascript)");
Object.defineProperty(exports, "MultiSignatureAptosSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(multiSignatureAptos_1).default;
    }
});
var TypedEthereumSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/TypedEthereumSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "TypedEthereumSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(TypedEthereumSigner_1).default;
    }
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/InjectedTypedEthereumSigner.js [app-route] (ecmascript)"), exports);
var arconnectSigner_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/arconnectSigner.js [app-route] (ecmascript)");
Object.defineProperty(exports, "ArconnectSigner", {
    enumerable: true,
    get: function() {
        return __importDefault(arconnectSigner_1).default;
    }
}); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/constants.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.indexToType = void 0;
const curve25519_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/curve25519.js [app-route] (ecmascript)"));
const index_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/index.js [app-route] (ecmascript)");
exports.indexToType = {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    1: index_1.ArweaveSigner,
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    2: curve25519_1.default,
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    3: index_1.EthereumSigner,
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    4: index_1.HexInjectedSolanaSigner,
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    5: index_1.InjectedAptosSigner,
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    6: index_1.MultiSignatureAptosSigner,
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-expect-error
    7: index_1.TypedEthereumSigner
}; //# sourceMappingURL=constants.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.secp256k1 = exports.Rsa4096 = exports.Curve25519 = void 0;
var curve25519_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/curve25519.js [app-route] (ecmascript)");
Object.defineProperty(exports, "Curve25519", {
    enumerable: true,
    get: function() {
        return __importDefault(curve25519_1).default;
    }
});
var Rsa4096Pss_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/Rsa4096Pss.js [app-route] (ecmascript)");
Object.defineProperty(exports, "Rsa4096", {
    enumerable: true,
    get: function() {
        return __importDefault(Rsa4096Pss_1).default;
    }
});
var secp256k1_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/secp256k1.js [app-route] (ecmascript)");
Object.defineProperty(exports, "secp256k1", {
    enumerable: true,
    get: function() {
        return __importDefault(secp256k1_1).default;
    }
}); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/Signer.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/constants.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keys/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/chains/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/keccak256.js [app-route] (ecmascript)"), exports); // TODO: just use ethers bundled ver
 //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/ar-data-base.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/nodeUtils.js [app-route] (ecmascript)");
function getSignatureData(item) {
    return __awaiter(this, void 0, void 0, function*() {
        return (0, utils_1.deepHash)([
            (0, utils_1.stringToBuffer)("dataitem"),
            (0, utils_1.stringToBuffer)("1"),
            (0, utils_1.stringToBuffer)(item.signatureType.toString()),
            item.rawOwner,
            item.rawTarget,
            item.rawAnchor,
            item.rawTags,
            item.rawData
        ]);
    });
}
exports.default = getSignatureData; //# sourceMappingURL=ar-data-base.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.byteArrayToLong = exports.longTo32ByteArray = exports.longTo16ByteArray = exports.shortTo2ByteArray = exports.longTo8ByteArray = exports.longToNByteArray = void 0;
function longToNByteArray(N, long) {
    const byteArray = new Uint8Array(N);
    if (long < 0) throw new Error("Array is unsigned, cannot represent -ve numbers");
    if (long > Math.pow(2, N * 8) - 1) throw new Error(`Number ${long} is too large for an array of ${N} bytes`);
    for(let index = 0; index < byteArray.length; index++){
        const byte = long & 0xff;
        byteArray[index] = byte;
        long = (long - byte) / 256;
    }
    return byteArray;
}
exports.longToNByteArray = longToNByteArray;
function longTo8ByteArray(long) {
    return longToNByteArray(8, long);
}
exports.longTo8ByteArray = longTo8ByteArray;
function shortTo2ByteArray(short) {
    return longToNByteArray(2, short);
}
exports.shortTo2ByteArray = shortTo2ByteArray;
function longTo16ByteArray(long) {
    return longToNByteArray(16, long);
}
exports.longTo16ByteArray = longTo16ByteArray;
function longTo32ByteArray(long) {
    return longToNByteArray(32, long);
}
exports.longTo32ByteArray = longTo32ByteArray;
function byteArrayToLong(byteArray) {
    let value = 0;
    for(let i = byteArray.length - 1; i >= 0; i--){
        value = value * 256 + byteArray[i];
    }
    return value;
}
exports.byteArrayToLong = byteArrayToLong; // this is bugged for comparing buffers
 // export function arraybufferEqual(buf1: Uint8Array, buf2: Uint8Array): boolean {
 //   const _buf1 = buf1.buffer;
 //   const _buf2 = buf2.buffer;
 //   if (_buf1 === _buf2) {
 //     return true;
 //   }
 //   if (_buf1.byteLength !== _buf2.byteLength) {
 //     return false;
 //   }
 //   const view1 = new DataView(_buf1);
 //   const view2 = new DataView(_buf2);
 //   let i = _buf1.byteLength;
 //   while (i--) {
 //     if (view1.getUint8(i) !== view2.getUint8(i)) {
 //       return false;
 //     }
 //   }
 //   return true;
 // }
 // // @ts-expect-error These variables are defined in extension environments
 // const isExtension = typeof browser !== "undefined" || typeof chrome !== "undefined";
 //# sourceMappingURL=utils.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/tags.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.deserializeTags = exports.serializeTags = exports.AVSCTap = void 0;
const DataItem_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/DataItem.js [app-route] (ecmascript)");
class AVSCTap {
    constructor(buf = Buffer.alloc(DataItem_1.MAX_TAG_BYTES), pos = 0){
        this.buf = buf;
        this.pos = pos;
    }
    writeTags(tags) {
        if (!Array.isArray(tags)) {
            throw new Error("input must be array");
        }
        const n = tags.length;
        let i;
        if (n) {
            this.writeLong(n);
            for(i = 0; i < n; i++){
                // for this use case, assume tags/strings.
                const tag = tags[i];
                if (typeof (tag === null || tag === void 0 ? void 0 : tag.name) !== "string" || typeof (tag === null || tag === void 0 ? void 0 : tag.value) !== "string") throw new Error(`Invalid tag format for ${tag}, expected {name:string, value: string}`);
                this.writeString(tag.name);
                this.writeString(tag.value);
            // this.itemsType._write(tap, val[i]);
            }
        }
        this.writeLong(0);
    }
    toBuffer() {
        const buffer = Buffer.alloc(this.pos);
        if (this.pos > this.buf.length) throw new Error(`Too many tag bytes (${this.pos} > ${this.buf.length})`);
        this.buf.copy(buffer, 0, 0, this.pos);
        return buffer;
    }
    writeLong(n) {
        const buf = this.buf;
        let f, m;
        if (n >= -1073741824 && n < 1073741824) {
            // Won't overflow, we can use integer arithmetic.
            m = n >= 0 ? n << 1 : ~n << 1 | 1;
            do {
                buf[this.pos] = m & 0x7f;
                m >>= 7;
            }while (m && (buf[this.pos++] |= 0x80))
        } else {
            // We have to use slower floating arithmetic.
            f = n >= 0 ? n * 2 : -n * 2 - 1;
            do {
                buf[this.pos] = f & 0x7f;
                f /= 128;
            }while (f >= 1 && (buf[this.pos++] |= 0x80))
        }
        this.pos++;
        this.buf = buf;
    }
    // for some reason using setters/getters with ++ doesn't work right.
    // set pos(newPos: number) {
    //   const d = newPos + 1 - this.buf.length;
    //   if (d > 0) this.buf = Buffer.concat([this.buf, Buffer.alloc(d)]);
    //   this._pos = newPos;
    // }
    // get pos(): number {
    //   return this._pos;
    // }
    // protected safeRead(position): number {
    //   return position > this.buf.length ? 0 : this.buf[position];
    // }
    // protected safeWrite(position, value): Buffer {
    //   if (position > this.buf.length) this.buf = Buffer.concat([this.buf, Buffer.alloc(1)]);
    //   this.buf[position] = value;
    //   return this.buf;
    // }
    writeString(s) {
        const len = Buffer.byteLength(s);
        const buf = this.buf;
        this.writeLong(len);
        let pos = this.pos;
        this.pos += len;
        if (this.pos > buf.length) {
            return;
        }
        if (len > 64) {
            // this._writeUtf8(s, len);
            this.buf.write(s, this.pos - len, len, "utf8");
        } else {
            let i, l, c1, c2;
            for(i = 0, l = len; i < l; i++){
                c1 = s.charCodeAt(i);
                if (c1 < 0x80) {
                    buf[pos++] = c1;
                } else if (c1 < 0x800) {
                    buf[pos++] = c1 >> 6 | 0xc0;
                    buf[pos++] = c1 & 0x3f | 0x80;
                } else if ((c1 & 0xfc00) === 0xd800 && ((c2 = s.charCodeAt(i + 1)) & 0xfc00) === 0xdc00) {
                    c1 = 0x10000 + ((c1 & 0x03ff) << 10) + (c2 & 0x03ff);
                    i++;
                    buf[pos++] = c1 >> 18 | 0xf0;
                    buf[pos++] = c1 >> 12 & 0x3f | 0x80;
                    buf[pos++] = c1 >> 6 & 0x3f | 0x80;
                    buf[pos++] = c1 & 0x3f | 0x80;
                } else {
                    buf[pos++] = c1 >> 12 | 0xe0;
                    buf[pos++] = c1 >> 6 & 0x3f | 0x80;
                    buf[pos++] = c1 & 0x3f | 0x80;
                }
            }
        }
        this.buf = buf;
    }
    readLong() {
        let n = 0;
        let k = 0;
        const buf = this.buf;
        let b, h, f, fk;
        do {
            b = buf[this.pos++];
            h = b & 0x80;
            n |= (b & 0x7f) << k;
            k += 7;
        }while (h && k < 28)
        if (h) {
            // Switch to float arithmetic, otherwise we might overflow.
            f = n;
            fk = 268435456; // 2 ** 28.
            do {
                b = buf[this.pos++];
                f += (b & 0x7f) * fk;
                fk *= 128;
            }while (b & 0x80)
            return (f % 2 ? -(f + 1) : f) / 2;
        }
        return n >> 1 ^ -(n & 1);
    }
    skipLong() {
        const buf = this.buf;
        while(buf[this.pos++] & 0x80){}
    }
    readTags() {
        // var items = this.itemsType;
        const val = [];
        let n;
        while(n = this.readLong()){
            if (n < 0) {
                n = -n;
                this.skipLong(); // Skip size.
            }
            while(n--){
                const name = this.readString();
                const value = this.readString();
                val.push(/* items._read(tap) */ {
                    name,
                    value
                });
            }
        }
        return val;
    }
    readString() {
        const len = this.readLong();
        const pos = this.pos;
        const buf = this.buf;
        this.pos += len;
        if (this.pos > buf.length) {
            // return undefined;
            throw new Error("TAP Position out of range");
        }
        return this.buf.slice(pos, pos + len).toString();
    }
}
exports.AVSCTap = AVSCTap;
function serializeTags(tags) {
    if ((tags === null || tags === void 0 ? void 0 : tags.length) === 0) {
        return Buffer.allocUnsafe(0);
    }
    const tap = new AVSCTap();
    tap.writeTags(tags);
    return tap.toBuffer();
}
exports.serializeTags = serializeTags;
function deserializeTags(tagsBuffer) {
    const tap = new AVSCTap(tagsBuffer);
    return tap.readTags();
}
exports.deserializeTags = deserializeTags; //# sourceMappingURL=tags.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/DataItem.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DataItem = exports.MAX_TAG_BYTES = exports.MIN_BINARY_SIZE = void 0;
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/utils.js [app-route] (ecmascript)");
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const buffer_1 = __turbopack_require__("[externals]/buffer [external] (buffer, cjs)");
const ar_data_bundle_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/ar-data-bundle.js [app-route] (ecmascript)");
const index_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/index.js [app-route] (ecmascript)");
const ar_data_base_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/ar-data-base.js [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)");
const utils_2 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/nodeUtils.js [app-route] (ecmascript)");
const tags_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/tags.js [app-route] (ecmascript)");
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
exports.MIN_BINARY_SIZE = 80;
exports.MAX_TAG_BYTES = 4096;
class DataItem {
    constructor(binary){
        this.binary = binary;
    }
    static isDataItem(obj) {
        return obj.binary !== undefined;
    }
    get signatureType() {
        const signatureTypeVal = (0, utils_1.byteArrayToLong)(this.binary.subarray(0, 2));
        if ((constants_1.SignatureConfig === null || constants_1.SignatureConfig === void 0 ? void 0 : constants_1.SignatureConfig[signatureTypeVal]) !== undefined) {
            return signatureTypeVal;
        }
        throw new Error("Unknown signature type: " + signatureTypeVal);
    }
    isValid() {
        return __awaiter(this, void 0, void 0, function*() {
            return DataItem.verify(this.binary);
        });
    }
    get id() {
        return base64url_1.default.encode(this.rawId);
    }
    set id(id) {
        this._id = base64url_1.default.toBuffer(id);
    }
    get rawId() {
        return (0, crypto_1.createHash)("sha256").update(this.rawSignature).digest();
    }
    set rawId(id) {
        this._id = id;
    }
    get rawSignature() {
        return this.binary.subarray(2, 2 + this.signatureLength);
    }
    get signature() {
        return base64url_1.default.encode(this.rawSignature);
    }
    set rawOwner(pubkey) {
        if (pubkey.byteLength != this.ownerLength) throw new Error(`Expected raw owner (pubkey) to be ${this.ownerLength} bytes, got ${pubkey.byteLength} bytes.`);
        this.binary.set(pubkey, 2 + this.signatureLength);
    }
    get rawOwner() {
        return this.binary.subarray(2 + this.signatureLength, 2 + this.signatureLength + this.ownerLength);
    }
    get signatureLength() {
        return constants_1.SIG_CONFIG[this.signatureType].sigLength;
    }
    get owner() {
        return base64url_1.default.encode(this.rawOwner);
    }
    get ownerLength() {
        return constants_1.SIG_CONFIG[this.signatureType].pubLength;
    }
    get rawTarget() {
        const targetStart = this.getTargetStart();
        const isPresent = this.binary[targetStart] == 1;
        return isPresent ? this.binary.subarray(targetStart + 1, targetStart + 33) : buffer_1.Buffer.alloc(0);
    }
    get target() {
        return base64url_1.default.encode(this.rawTarget);
    }
    get rawAnchor() {
        const anchorStart = this.getAnchorStart();
        const isPresent = this.binary[anchorStart] == 1;
        return isPresent ? this.binary.subarray(anchorStart + 1, anchorStart + 33) : buffer_1.Buffer.alloc(0);
    }
    get anchor() {
        return base64url_1.default.encode(this.rawAnchor); /* .toString(); */ 
    }
    get rawTags() {
        const tagsStart = this.getTagsStart();
        const tagsSize = (0, utils_1.byteArrayToLong)(this.binary.subarray(tagsStart + 8, tagsStart + 16));
        return this.binary.subarray(tagsStart + 16, tagsStart + 16 + tagsSize);
    }
    get tags() {
        const tagsStart = this.getTagsStart();
        const tagsCount = (0, utils_1.byteArrayToLong)(this.binary.subarray(tagsStart, tagsStart + 8));
        if (tagsCount == 0) {
            return [];
        }
        const tagsSize = (0, utils_1.byteArrayToLong)(this.binary.subarray(tagsStart + 8, tagsStart + 16));
        return (0, tags_1.deserializeTags)(buffer_1.Buffer.from(this.binary.subarray(tagsStart + 16, tagsStart + 16 + tagsSize)));
    }
    get tagsB64Url() {
        const _tags = this.tags;
        return _tags.map((t)=>({
                name: base64url_1.default.encode(t.name),
                value: base64url_1.default.encode(t.value)
            }));
    }
    getStartOfData() {
        const tagsStart = this.getTagsStart();
        const numberOfTagBytesArray = this.binary.subarray(tagsStart + 8, tagsStart + 16);
        const numberOfTagBytes = (0, utils_1.byteArrayToLong)(numberOfTagBytesArray);
        return tagsStart + 16 + numberOfTagBytes;
    }
    get rawData() {
        const tagsStart = this.getTagsStart();
        const numberOfTagBytesArray = this.binary.subarray(tagsStart + 8, tagsStart + 16);
        const numberOfTagBytes = (0, utils_1.byteArrayToLong)(numberOfTagBytesArray);
        const dataStart = tagsStart + 16 + numberOfTagBytes;
        return this.binary.subarray(dataStart, this.binary.length);
    }
    get data() {
        return base64url_1.default.encode(this.rawData);
    }
    /**
     * UNSAFE!!
     * DO NOT MUTATE THE BINARY ARRAY. THIS WILL CAUSE UNDEFINED BEHAVIOUR.
     */ getRaw() {
        return this.binary;
    }
    sign(signer) {
        return __awaiter(this, void 0, void 0, function*() {
            this._id = yield (0, ar_data_bundle_1.sign)(this, signer);
            return this.rawId;
        });
    }
    setSignature(signature) {
        return __awaiter(this, void 0, void 0, function*() {
            this.binary.set(signature, 2);
            this._id = buffer_1.Buffer.from((yield (0, utils_2.getCryptoDriver)().hash(signature)));
        });
    }
    isSigned() {
        var _a, _b;
        return ((_b = (_a = this._id) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0) > 0;
    }
    /**
     * Returns a JSON representation of a DataItem
     */ // eslint-disable-next-line @typescript-eslint/naming-convention
    toJSON() {
        return {
            signature: this.signature,
            owner: this.owner,
            target: this.target,
            tags: this.tags.map((t)=>({
                    name: base64url_1.default.encode(t.name),
                    value: base64url_1.default.encode(t.value)
                })),
            data: this.data
        };
    }
    /**
     * Verifies a `Buffer` and checks it fits the format of a DataItem
     *
     * A binary is valid iff:
     * - the tags are encoded correctly
     */ static verify(buffer) {
        return __awaiter(this, void 0, void 0, function*() {
            if (buffer.byteLength < exports.MIN_BINARY_SIZE) {
                return false;
            }
            const item = new DataItem(buffer);
            const sigType = item.signatureType;
            const tagsStart = item.getTagsStart();
            const numberOfTags = (0, utils_1.byteArrayToLong)(buffer.subarray(tagsStart, tagsStart + 8));
            const numberOfTagBytesArray = buffer.subarray(tagsStart + 8, tagsStart + 16);
            const numberOfTagBytes = (0, utils_1.byteArrayToLong)(numberOfTagBytesArray);
            if (numberOfTagBytes > exports.MAX_TAG_BYTES) return false;
            if (numberOfTags > 0) {
                try {
                    const tags = (0, tags_1.deserializeTags)(buffer_1.Buffer.from(buffer.subarray(tagsStart + 16, tagsStart + 16 + numberOfTagBytes)));
                    if (tags.length !== numberOfTags) {
                        return false;
                    }
                } catch (e) {
                    return false;
                }
            }
            // eslint-disable-next-line @typescript-eslint/naming-convention
            const Signer = index_1.indexToType[sigType];
            const signatureData = yield (0, ar_data_base_1.default)(item);
            return yield Signer.verify(item.rawOwner, signatureData, item.rawSignature);
        });
    }
    getSignatureData() {
        return __awaiter(this, void 0, void 0, function*() {
            return (0, ar_data_base_1.default)(this);
        });
    }
    /**
     * Returns the start byte of the tags section (number of tags)
     *
     * @private
     */ getTagsStart() {
        const targetStart = this.getTargetStart();
        const targetPresent = this.binary[targetStart] == 1;
        let tagsStart = targetStart + (targetPresent ? 33 : 1);
        const anchorPresent = this.binary[tagsStart] == 1;
        tagsStart += anchorPresent ? 33 : 1;
        return tagsStart;
    }
    /**
     * Returns the start byte of the tags section (number of tags)
     *
     * @private
     */ getTargetStart() {
        return 2 + this.signatureLength + this.ownerLength;
    }
    /**
     * Returns the start byte of the tags section (number of tags)
     *
     * @private
     */ getAnchorStart() {
        let anchorStart = this.getTargetStart() + 1;
        const targetPresent = this.binary[this.getTargetStart()] == 1;
        anchorStart += targetPresent ? 32 : 0;
        return anchorStart;
    }
}
exports.DataItem = DataItem;
exports.default = DataItem; //# sourceMappingURL=DataItem.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/Bundle.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Bundle = void 0;
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/utils.js [app-route] (ecmascript)");
const DataItem_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/DataItem.js [app-route] (ecmascript)"));
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
const HEADER_START = 32;
class Bundle {
    constructor(binary){
        this.binary = binary;
        this.length = this.getDataItemCount();
        this.items = this.getItems();
    }
    getRaw() {
        return this.binary;
    }
    /**
     * Get a DataItem by index (`number`) or by txId (`string`)
     * @param index
     */ get(index) {
        if (typeof index === "number") {
            if (index >= this.length) {
                throw new RangeError("Index out of range");
            }
            return this.getByIndex(index);
        } else {
            return this.getById(index);
        }
    }
    getSizes() {
        const ids = [];
        for(let i = HEADER_START; i < HEADER_START + 64 * this.length; i += 64){
            ids.push((0, utils_1.byteArrayToLong)(this.binary.subarray(i, i + 32)));
        }
        return ids;
    }
    getIds() {
        const ids = [];
        for(let i = HEADER_START; i < HEADER_START + 64 * this.length; i += 64){
            const bundleId = this.binary.subarray(i + 32, i + 64);
            if (bundleId.length === 0) {
                throw new Error("Invalid bundle, id specified in headers doesn't exist");
            }
            ids.push(base64url_1.default.encode(bundleId));
        }
        return ids;
    }
    getIdBy(index) {
        if (index > this.length - 1) {
            throw new RangeError("Index of bundle out of range");
        }
        const start = 64 + 64 * index;
        return base64url_1.default.encode(this.binary.subarray(start, start + 32));
    }
    toTransaction(attributes, arweave, jwk) {
        return __awaiter(this, void 0, void 0, function*() {
            const tx = yield arweave.createTransaction(Object.assign({
                data: this.binary
            }, attributes), jwk);
            tx.addTag("Bundle-Format", "binary");
            tx.addTag("Bundle-Version", "2.0.0");
            return tx;
        });
    }
    verify() {
        return __awaiter(this, void 0, void 0, function*() {
            for (const item of this.items){
                const valid = yield item.isValid();
                const expected = (0, base64url_1.default)((0, crypto_1.createHash)("sha256").update(item.rawSignature).digest());
                if (!(valid && item.id === expected)) {
                    return false;
                }
            }
            return true;
        });
    }
    getOffset(id) {
        let offset = 0;
        for(let i = HEADER_START; i < HEADER_START + 64 * this.length; i += 64){
            const _offset = (0, utils_1.byteArrayToLong)(this.binary.subarray(i, i + 32));
            offset += _offset;
            const _id = this.binary.subarray(i + 32, i + 64);
            if (Buffer.compare(_id, id) === 0) {
                return {
                    startOffset: offset,
                    size: _offset
                };
            }
        }
        return {
            startOffset: -1,
            size: -1
        };
    }
    // TODO: Test this
    /**
     * UNSAFE! Assumes index < length
     * @param index
     * @private
     */ getByIndex(index) {
        let offset = 0;
        const bundleStart = this.getBundleStart();
        let counter = 0;
        let _offset, _id;
        for(let i = HEADER_START; i < HEADER_START + 64 * this.length; i += 64){
            _offset = (0, utils_1.byteArrayToLong)(this.binary.subarray(i, i + 32));
            if (counter++ === index) {
                _id = this.binary.subarray(i + 32, i + 64);
                break;
            }
            offset += _offset;
        }
        const dataItemStart = bundleStart + offset;
        const slice = this.binary.subarray(dataItemStart, dataItemStart + _offset);
        const item = new DataItem_1.default(slice);
        item.rawId = _id;
        return item;
    }
    getById(id) {
        const _id = base64url_1.default.toBuffer(id);
        const offset = this.getOffset(_id);
        if (offset.startOffset === -1) {
            throw new Error("Transaction not found");
        }
        const bundleStart = this.getBundleStart();
        const dataItemStart = bundleStart + offset.startOffset;
        return new DataItem_1.default(this.binary.subarray(dataItemStart, dataItemStart + offset.size));
    }
    getDataItemCount() {
        return (0, utils_1.byteArrayToLong)(this.binary.subarray(0, 32));
    }
    getBundleStart() {
        return 32 + 64 * this.length;
    }
    getItems() {
        const items = new Array(this.length);
        let offset = 0;
        const bundleStart = this.getBundleStart();
        let counter = 0;
        for(let i = HEADER_START; i < HEADER_START + 64 * this.length; i += 64){
            const _offset = (0, utils_1.byteArrayToLong)(this.binary.subarray(i, i + 32));
            const _id = this.binary.subarray(i + 32, i + 64);
            if (_id.length === 0) {
                throw new Error("Invalid bundle, id specified in headers doesn't exist");
            }
            const dataItemStart = bundleStart + offset;
            const bytes = this.binary.subarray(dataItemStart, dataItemStart + _offset);
            offset += _offset;
            const item = new DataItem_1.default(bytes);
            item.rawId = _id;
            items[counter] = item;
            counter++;
        }
        return items;
    }
}
exports.Bundle = Bundle;
exports.default = Bundle; //# sourceMappingURL=Bundle.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/ar-data-bundle.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.sign = exports.getSignatureAndId = exports.bundleAndSignData = exports.unbundleData = void 0;
const ar_data_base_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/ar-data-base.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/utils.js [app-route] (ecmascript)");
const Bundle_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/Bundle.js [app-route] (ecmascript)"));
const utils_2 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/nodeUtils.js [app-route] (ecmascript)");
/**
 * Unbundles a transaction into an Array of DataItems.
 *
 * Takes either a json string or object. Will throw if given an invalid json
 * string but otherwise, it will return an empty array if
 *
 * a) the json object is the wrong format
 * b) the object contains no valid DataItems.
 *
 * It will verify all DataItems and discard ones that don't pass verification.
 *
 * @param txData
 */ function unbundleData(txData) {
    return new Bundle_1.default(txData);
}
exports.unbundleData = unbundleData;
/**
 * Verifies all data items and returns a json object with an items array.
 * Throws if any of the data items fail verification.
 *
 * @param dataItems
 * @param signer
 */ function bundleAndSignData(dataItems, signer) {
    return __awaiter(this, void 0, void 0, function*() {
        const headers = new Uint8Array(64 * dataItems.length);
        const binaries = yield Promise.all(dataItems.map((d, index)=>__awaiter(this, void 0, void 0, function*() {
                // Sign DataItem
                const id = d.isSigned() ? d.rawId : yield sign(d, signer);
                // Create header array
                const header = new Uint8Array(64);
                // Set offset
                header.set((0, utils_1.longTo32ByteArray)(d.getRaw().byteLength), 0);
                // Set id
                header.set(id, 32);
                // Add header to array of headers
                headers.set(header, 64 * index);
                // Convert to array for flattening
                return d.getRaw();
            }))).then((a)=>{
            return Buffer.concat(a);
        });
        const buffer = Buffer.concat([
            Buffer.from((0, utils_1.longTo32ByteArray)(dataItems.length)),
            Buffer.from(headers),
            binaries
        ]);
        return new Bundle_1.default(buffer);
    });
}
exports.bundleAndSignData = bundleAndSignData;
/**
 * Signs a single
 *
 * @param item
 * @param signer
 * @returns signings - signature and id in byte-arrays
 */ function getSignatureAndId(item, signer) {
    return __awaiter(this, void 0, void 0, function*() {
        const signatureData = yield (0, ar_data_base_1.default)(item);
        const signatureBytes = yield signer.sign(signatureData);
        const idBytes = yield (0, utils_2.getCryptoDriver)().hash(signatureBytes);
        return {
            signature: Buffer.from(signatureBytes),
            id: Buffer.from(idBytes)
        };
    });
}
exports.getSignatureAndId = getSignatureAndId;
/**
 * Signs and returns item id
 *
 * @param item
 * @param jwk
 */ function sign(item, signer) {
    return __awaiter(this, void 0, void 0, function*() {
        const { signature, id } = yield getSignatureAndId(item, signer);
        item.getRaw().set(signature, 2);
        return id;
    });
}
exports.sign = sign; //# sourceMappingURL=ar-data-bundle.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/ar-data-create.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createData = void 0;
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/utils.js [app-route] (ecmascript)");
const DataItem_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/DataItem.js [app-route] (ecmascript)"));
const tags_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/tags.js [app-route] (ecmascript)");
/**
 * This will create a single DataItem in binary format (Uint8Array)
 *
 * @param data
 * @param opts - Options involved in creating data items
 * @param signer
 */ function createData(data, signer, opts) {
    var _a, _b, _c, _d, _e, _f, _g;
    // TODO: Add asserts
    // Parse all values to a buffer and
    const _owner = signer.publicKey;
    const _target = (opts === null || opts === void 0 ? void 0 : opts.target) ? base64url_1.default.toBuffer(opts.target) : null;
    const target_length = 1 + ((_a = _target === null || _target === void 0 ? void 0 : _target.byteLength) !== null && _a !== void 0 ? _a : 0);
    const _anchor = (opts === null || opts === void 0 ? void 0 : opts.anchor) ? Buffer.from(opts.anchor) : null;
    const anchor_length = 1 + ((_b = _anchor === null || _anchor === void 0 ? void 0 : _anchor.byteLength) !== null && _b !== void 0 ? _b : 0);
    const _tags = ((_d = (_c = opts === null || opts === void 0 ? void 0 : opts.tags) === null || _c === void 0 ? void 0 : _c.length) !== null && _d !== void 0 ? _d : 0) > 0 ? (0, tags_1.serializeTags)(opts === null || opts === void 0 ? void 0 : opts.tags) : null;
    const tags_length = 16 + (_tags ? _tags.byteLength : 0);
    const _data = typeof data === "string" ? Buffer.from(data) : Buffer.from(data);
    const data_length = _data.byteLength;
    // See [https://github.com/joshbenaron/arweave-standards/blob/ans104/ans/ANS-104.md#13-dataitem-format]
    const length = 2 + signer.signatureLength + signer.ownerLength + target_length + anchor_length + tags_length + data_length;
    // Create array with set length
    const bytes = Buffer.alloc(length);
    bytes.set((0, utils_1.shortTo2ByteArray)(signer.signatureType), 0);
    // Push bytes for `signature`
    bytes.set(new Uint8Array(signer.signatureLength).fill(0), 2);
    // // Push bytes for `id`
    // bytes.set(EMPTY_ARRAY, 32);
    // Push bytes for `owner`
    if (_owner.byteLength !== signer.ownerLength) throw new Error(`Owner must be ${signer.ownerLength} bytes, but was incorrectly ${_owner.byteLength}`);
    bytes.set(_owner, 2 + signer.signatureLength);
    const position = 2 + signer.signatureLength + signer.ownerLength;
    // Push `presence byte` and push `target` if present
    // 64 + OWNER_LENGTH
    bytes[position] = _target ? 1 : 0;
    if (_target) {
        if (_target.byteLength !== 32) throw new Error(`Target must be 32 bytes but was incorrectly ${_target.byteLength}`);
        bytes.set(_target, position + 1);
    }
    // Push `presence byte` and push `anchor` if present
    // 64 + OWNER_LENGTH
    const anchor_start = position + target_length;
    let tags_start = anchor_start + 1;
    bytes[anchor_start] = _anchor ? 1 : 0;
    if (_anchor) {
        tags_start += _anchor.byteLength;
        if (_anchor.byteLength !== 32) throw new Error("Anchor must be 32 bytes");
        bytes.set(_anchor, anchor_start + 1);
    }
    bytes.set((0, utils_1.longTo8ByteArray)((_f = (_e = opts === null || opts === void 0 ? void 0 : opts.tags) === null || _e === void 0 ? void 0 : _e.length) !== null && _f !== void 0 ? _f : 0), tags_start);
    const bytesCount = (0, utils_1.longTo8ByteArray)((_g = _tags === null || _tags === void 0 ? void 0 : _tags.byteLength) !== null && _g !== void 0 ? _g : 0);
    bytes.set(bytesCount, tags_start + 8);
    if (_tags) {
        bytes.set(_tags, tags_start + 16);
    }
    const data_start = tags_start + tags_length;
    bytes.set(_data, data_start);
    return new DataItem_1.default(bytes);
}
exports.createData = createData; //# sourceMappingURL=ar-data-create.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/BundleInterface.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
}); //# sourceMappingURL=BundleInterface.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/BundleItem.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BundleItem = void 0;
class BundleItem {
    static verify(..._) {
        return __awaiter(this, void 0, void 0, function*() {
            throw new Error("You must implement `verify`");
        });
    }
}
exports.BundleItem = BundleItem; //# sourceMappingURL=BundleItem.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/error.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
class BundleError extends Error {
    constructor(message){
        super(message);
        this.name = "BundleError";
    }
}
exports.default = BundleError; //# sourceMappingURL=error.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/interface-jwk.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
}); //# sourceMappingURL=interface-jwk.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/ar-data-base.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/ar-data-bundle.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/ar-data-create.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/Bundle.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/BundleInterface.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/BundleItem.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/DataItem.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/error.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/interface-jwk.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/tags.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/utils.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/nodeUtils.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/stream/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = this && this.__asyncValues || function(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i);
    "TURBOPACK unreachable";
    function verb(n) {
        i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
                v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
        };
    }
    function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function(v) {
            resolve({
                value: v,
                done: d
            });
        }, reject);
    }
};
var __await = this && this.__await || function(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
};
var __asyncGenerator = this && this.__asyncGenerator || function(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i;
    "TURBOPACK unreachable";
    function verb(n) {
        if (g[n]) i[n] = function(v) {
            return new Promise(function(a, b) {
                q.push([
                    n,
                    v,
                    a,
                    b
                ]) > 1 || resume(n, v);
            });
        };
    }
    function resume(n, v) {
        try {
            step(g[n](v));
        } catch (e) {
            settle(q[0][3], e);
        }
    }
    function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
        resume("next", value);
    }
    function reject(value) {
        resume("throw", value);
    }
    function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.streamExportForTesting = exports.streamSigner = exports.processStream = void 0;
const stream_1 = __turbopack_require__("[externals]/stream [external] (stream, cjs)");
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/utils.js [app-route] (ecmascript)");
const base64url_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/base64url@3.0.1/node_modules/base64url/index.js [app-route] (ecmascript)"));
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/signing/constants.js [app-route] (ecmascript)");
const index_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/index.js [app-route] (ecmascript)");
const constants_2 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/constants.js [app-route] (ecmascript)");
const utils_2 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/nodeUtils.js [app-route] (ecmascript)");
const deepHash_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/deepHash.js [app-route] (ecmascript)");
const tags_1 = __turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/tags.js [app-route] (ecmascript)");
const crypto_1 = __turbopack_require__("[externals]/crypto [external] (crypto, cjs)");
function processStream(stream) {
    return __awaiter(this, void 0, void 0, function*() {
        const reader = getReader(stream);
        let bytes = (yield reader.next()).value;
        bytes = yield readBytes(reader, bytes, 32);
        const itemCount = (0, utils_1.byteArrayToLong)(bytes.subarray(0, 32));
        bytes = bytes.subarray(32);
        const headersLength = 64 * itemCount;
        bytes = yield readBytes(reader, bytes, headersLength);
        const headers = new Array(itemCount);
        for(let i = 0; i < headersLength; i += 64){
            headers[i / 64] = [
                (0, utils_1.byteArrayToLong)(bytes.subarray(i, i + 32)),
                (0, base64url_1.default)(Buffer.from(bytes.subarray(i + 32, i + 64)))
            ];
        }
        bytes = bytes.subarray(headersLength);
        let offsetSum = 32 + headersLength;
        const items = [];
        for (const [length, id] of headers){
            bytes = yield readBytes(reader, bytes, index_1.MIN_BINARY_SIZE);
            // Get sig type
            bytes = yield readBytes(reader, bytes, 2);
            const signatureType = (0, utils_1.byteArrayToLong)(bytes.subarray(0, 2));
            bytes = bytes.subarray(2);
            const { sigLength, pubLength, sigName } = constants_2.SIG_CONFIG[signatureType];
            // Get sig
            bytes = yield readBytes(reader, bytes, sigLength);
            const signature = bytes.subarray(0, sigLength);
            bytes = bytes.subarray(sigLength);
            // Get owner
            bytes = yield readBytes(reader, bytes, pubLength);
            const owner = bytes.subarray(0, pubLength);
            bytes = bytes.subarray(pubLength);
            // Get target
            bytes = yield readBytes(reader, bytes, 1);
            const targetPresent = bytes[0] === 1;
            if (targetPresent) bytes = yield readBytes(reader, bytes, 33);
            const target = targetPresent ? bytes.subarray(1, 33) : Buffer.allocUnsafe(0);
            bytes = bytes.subarray(targetPresent ? 33 : 1);
            // Get anchor
            bytes = yield readBytes(reader, bytes, 1);
            const anchorPresent = bytes[0] === 1;
            if (anchorPresent) bytes = yield readBytes(reader, bytes, 33);
            const anchor = anchorPresent ? bytes.subarray(1, 33) : Buffer.allocUnsafe(0);
            bytes = bytes.subarray(anchorPresent ? 33 : 1);
            // Get tags
            bytes = yield readBytes(reader, bytes, 8);
            const tagsLength = (0, utils_1.byteArrayToLong)(bytes.subarray(0, 8));
            bytes = bytes.subarray(8);
            bytes = yield readBytes(reader, bytes, 8);
            const tagsBytesLength = (0, utils_1.byteArrayToLong)(bytes.subarray(0, 8));
            bytes = bytes.subarray(8);
            bytes = yield readBytes(reader, bytes, tagsBytesLength);
            const tagsBytes = bytes.subarray(0, tagsBytesLength);
            const tags = tagsLength !== 0 && tagsBytesLength !== 0 ? (0, tags_1.deserializeTags)(Buffer.from(tagsBytes)) : [];
            if (tags.length !== tagsLength) throw new Error("Tags lengths don't match");
            bytes = bytes.subarray(tagsBytesLength);
            const transform = new stream_1.Transform();
            transform._transform = function(chunk, _, done) {
                this.push(chunk);
                done();
            };
            // Verify signature
            const signatureData = (0, deepHash_1.deepHash)([
                (0, utils_2.stringToBuffer)("dataitem"),
                (0, utils_2.stringToBuffer)("1"),
                (0, utils_2.stringToBuffer)(signatureType.toString()),
                owner,
                target,
                anchor,
                tagsBytes,
                transform
            ]);
            // Get offset of data start and length of data
            const dataOffset = 2 + sigLength + pubLength + (targetPresent ? 33 : 1) + (anchorPresent ? 33 : 1) + 16 + tagsBytesLength;
            const dataSize = length - dataOffset;
            if (bytes.byteLength > dataSize) {
                transform.write(bytes.subarray(0, dataSize));
                bytes = bytes.subarray(dataSize);
            } else {
                let skipped = bytes.byteLength;
                transform.write(bytes);
                while(dataSize > skipped){
                    bytes = (yield reader.next()).value;
                    if (!bytes) {
                        throw new Error(`Not enough data bytes  expected: ${dataSize} received: ${skipped}`);
                    }
                    skipped += bytes.byteLength;
                    if (skipped > dataSize) transform.write(bytes.subarray(0, bytes.byteLength - (skipped - dataSize)));
                    else transform.write(bytes);
                }
                bytes = bytes.subarray(bytes.byteLength - (skipped - dataSize));
            }
            transform.end();
            // Check id
            if (id !== (0, base64url_1.default)((0, crypto_1.createHash)("sha256").update(signature).digest())) throw new Error("ID doesn't match signature");
            const Signer = constants_1.indexToType[signatureType];
            if (!(yield Signer.verify(owner, (yield signatureData), signature))) throw new Error("Invalid signature");
            items.push({
                id,
                sigName,
                signature: (0, base64url_1.default)(Buffer.from(signature)),
                target: (0, base64url_1.default)(Buffer.from(target)),
                anchor: (0, base64url_1.default)(Buffer.from(anchor)),
                owner: (0, base64url_1.default)(Buffer.from(owner)),
                tags,
                dataOffset: offsetSum + dataOffset,
                dataSize
            });
            offsetSum += dataOffset + dataSize;
        }
        return items;
    });
}
exports.processStream = processStream;
/**
 * Signs a stream (requires two instances/read passes)
 * @param s1 Stream to sign - same as s2
 * @param s2 Stream to sign - same as s1
 * @param signer Signer to use to sign the stream
 * @param opts Optional options to apply to the stream (same as DataItem)
 */ function streamSigner(s1, s2, signer, opts) {
    return __awaiter(this, void 0, void 0, function*() {
        const header = (0, index_1.createData)("", signer, opts);
        const output = new stream_1.PassThrough();
        const parts = [
            (0, utils_2.stringToBuffer)("dataitem"),
            (0, utils_2.stringToBuffer)("1"),
            (0, utils_2.stringToBuffer)(header.signatureType.toString()),
            header.rawOwner,
            header.rawTarget,
            header.rawAnchor,
            header.rawTags,
            s1
        ];
        const hash = yield (0, deepHash_1.deepHash)(parts);
        const sigBytes = Buffer.from((yield signer.sign(hash)));
        header.setSignature(sigBytes);
        output.write(header.getRaw());
        return s2.pipe(output);
    });
}
exports.streamSigner = streamSigner;
function readBytes(reader, buffer, length) {
    return __awaiter(this, void 0, void 0, function*() {
        if (buffer.byteLength >= length) return buffer;
        const { done, value } = yield reader.next();
        if (done && !value) throw new Error("Invalid buffer");
        return readBytes(reader, Buffer.concat([
            Buffer.from(buffer),
            Buffer.from(value)
        ]), length);
    });
}
function getReader(s) {
    return __asyncGenerator(this, arguments, function* getReader_1() {
        var _a, e_1, _b, _c;
        try {
            for(var _d = true, s_1 = __asyncValues(s), s_1_1; s_1_1 = yield __await(s_1.next()), _a = s_1_1.done, !_a;){
                _c = s_1_1.value;
                _d = false;
                try {
                    const chunk = _c;
                    yield yield __await(chunk);
                } finally{
                    _d = true;
                }
            }
        } catch (e_1_1) {
            e_1 = {
                error: e_1_1
            };
        } finally{
            try {
                if (!_d && !_a && (_b = s_1.return)) yield __await(_b.call(s_1));
            } finally{
                if (e_1) throw e_1.error;
            }
        }
    });
}
exports.default = processStream;
exports.streamExportForTesting = {
    readBytes,
    getReader
}; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/webIndex.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
var _a;
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.arbundles = void 0;
const arbundlesSrc = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/index.js [app-route] (ecmascript)"));
const stream = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/stream/index.js [app-route] (ecmascript)"));
const expObj = Object.assign(Object.assign({}, arbundlesSrc), {
    stream
});
(_a = globalThis.arbundles) !== null && _a !== void 0 ? _a : globalThis.arbundles = expObj;
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/arbundles@0.11.2_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/arbundles/build/web/cjs/src/stream/index.js [app-route] (ecmascript)"), exports);
exports.default = expObj;
exports.arbundles = expObj; //# sourceMappingURL=webIndex.js.map
}}),

};

//# sourceMappingURL=8cbf6_arbundles_build_77ebe9._.js.map
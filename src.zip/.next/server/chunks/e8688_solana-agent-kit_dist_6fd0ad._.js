module.exports = {

"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/constants/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.JUP_REFERRAL_ADDRESS = exports.JUP_API = exports.DEFAULT_OPTIONS = exports.TOKENS = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
/**
 * Common token addresses used across the toolkit
 */ exports.TOKENS = {
    USDC: new web3_js_1.PublicKey("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"),
    USDT: new web3_js_1.PublicKey("Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"),
    USDS: new web3_js_1.PublicKey("USDSwr9ApdHk5bvJKMjzff41FfuX8bSxdKcR81vTwcA"),
    SOL: new web3_js_1.PublicKey("So11111111111111111111111111111111111111112"),
    jitoSOL: new web3_js_1.PublicKey("J1toso1uCk3RLmjorhTtrVwY9HJ7X8V9yYac6Y7kGCPn"),
    bSOL: new web3_js_1.PublicKey("bSo13r4TkiE4KumL71LsHTPpL2euBYLFx6h9HP3piy1"),
    mSOL: new web3_js_1.PublicKey("mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So"),
    BONK: new web3_js_1.PublicKey("DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263")
};
/**
 * Default configuration options
 * @property {number} SLIPPAGE_BPS - Default slippage tolerance in basis points (300 = 3%)
 * @property {number} TOKEN_DECIMALS - Default number of decimals for new tokens
 * @property {number} LEVERAGE_BPS - Default leverage for trading PERP
 */ exports.DEFAULT_OPTIONS = {
    SLIPPAGE_BPS: 300,
    TOKEN_DECIMALS: 9,
    RERERRAL_FEE: 200,
    LEVERAGE_BPS: 50000
};
/**
 * Jupiter API URL
 */ exports.JUP_API = "https://quote-api.jup.ag/v6";
exports.JUP_REFERRAL_ADDRESS = "REFER4ZgmyYx9c6He5XfaTMiGfdLwRnkV4RPp9t9iF3"; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/AdrenaClient.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/constants/index.js [app-route] (ecmascript)");
class AdrenaClient {
    constructor(program, mainPool, cortex, custodies){
        this.program = program;
        this.mainPool = mainPool;
        this.cortex = cortex;
        this.custodies = custodies;
    }
    static async load(agent) {
        throw new Error("Not implemented");
    // const program = new Program<Adrena>(
    //   ADRENA_IDL,
    //   AdrenaClient.programId,
    //   new AnchorProvider(agent.connection, new NodeWallet(agent.wallet), {
    //     commitment: "processed",
    //     skipPreflight: true,
    //   }),
    // );
    // const [cortex, mainPool] = await Promise.all([
    //   program.account.cortex.fetch(AdrenaClient.cortex),
    //   program.account.pool.fetch(AdrenaClient.mainPool),
    // ]);
    // const custodiesAddresses = mainPool.custodies.filter(
    //   (custody) => !custody.equals(PublicKey.default),
    // );
    // const custodies =
    //   await program.account.custody.fetchMultiple(custodiesAddresses);
    // if (!custodies.length || custodies.some((c) => c === null)) {
    //   throw new Error("Custodies not found");
    // }
    // return new AdrenaClient(
    //   program,
    //   mainPool,
    //   cortex,
    //   (custodies as Custody[]).map((c, i) => ({
    //     ...c,
    //     pubkey: custodiesAddresses[i],
    //   })),
    // );
    }
    static findCustodyAddress(mint) {
        return web3_js_1.PublicKey.findProgramAddressSync([
            Buffer.from("custody"),
            AdrenaClient.mainPool.toBuffer(),
            mint.toBuffer()
        ], AdrenaClient.programId)[0];
    }
    static findCustodyTokenAccountAddress(mint) {
        return web3_js_1.PublicKey.findProgramAddressSync([
            Buffer.from("custody_token_account"),
            AdrenaClient.mainPool.toBuffer(),
            mint.toBuffer()
        ], AdrenaClient.programId)[0];
    }
    static findPositionAddress(owner, custody, side) {
        return web3_js_1.PublicKey.findProgramAddressSync([
            Buffer.from("position"),
            owner.toBuffer(),
            AdrenaClient.mainPool.toBuffer(),
            custody.toBuffer(),
            Buffer.from([
                {
                    long: 1,
                    short: 2
                }[side]
            ])
        ], AdrenaClient.programId)[0];
    }
    static getStakingPda(stakedTokenMint) {
        return web3_js_1.PublicKey.findProgramAddressSync([
            Buffer.from("staking"),
            stakedTokenMint.toBuffer()
        ], AdrenaClient.programId)[0];
    }
    static findATAAddressSync(wallet, mint) {
        return web3_js_1.PublicKey.findProgramAddressSync([
            wallet.toBuffer(),
            spl_token_1.TOKEN_PROGRAM_ID.toBuffer(),
            mint.toBuffer()
        ], spl_token_1.ASSOCIATED_TOKEN_PROGRAM_ID)[0];
    }
    getCustodyByMint(mint) {
        const custody = this.custodies.find((custody)=>custody.mint.equals(mint));
        if (!custody) {
            throw new Error(`Cannot find custody for mint ${mint.toBase58()}`);
        }
        return custody;
    }
    static getUserProfilePda(wallet) {
        return web3_js_1.PublicKey.findProgramAddressSync([
            Buffer.from("user_profile"),
            wallet.toBuffer()
        ], AdrenaClient.programId)[0];
    }
    static getStakingRewardTokenVaultPda(stakingPda) {
        return web3_js_1.PublicKey.findProgramAddressSync([
            Buffer.from("staking_reward_token_vault"),
            stakingPda.toBuffer()
        ], AdrenaClient.programId)[0];
    }
    static async isAccountInitialized(connection, address) {
        return !!await connection.getAccountInfo(address);
    }
    static createATAInstruction({ ataAddress, mint, owner, payer = owner }) {
        return (0, spl_token_1.createAssociatedTokenAccountInstruction)(payer, ataAddress, owner, mint);
    }
}
AdrenaClient.programId = new web3_js_1.PublicKey("13gDzEXCdocbj8iAiqrScGo47NiSuYENGsRqi3SEAwet");
AdrenaClient.mainPool = new web3_js_1.PublicKey("4bQRutgDJs6vuh6ZcWaPVXiQaBzbHketjbCDjL4oRN34");
AdrenaClient.cortex = web3_js_1.PublicKey.findProgramAddressSync([
    Buffer.from("cortex")
], AdrenaClient.programId)[0];
AdrenaClient.lpTokenMint = web3_js_1.PublicKey.findProgramAddressSync([
    Buffer.from("lp_token_mint"),
    AdrenaClient.mainPool.toBuffer()
], AdrenaClient.programId)[0];
AdrenaClient.lmTokenMint = web3_js_1.PublicKey.findProgramAddressSync([
    Buffer.from("lm_token_mint")
], AdrenaClient.programId)[0];
AdrenaClient.lmStaking = AdrenaClient.getStakingPda(AdrenaClient.lmTokenMint);
AdrenaClient.lpStaking = AdrenaClient.getStakingPda(AdrenaClient.lpTokenMint);
AdrenaClient.transferAuthority = web3_js_1.PublicKey.findProgramAddressSync([
    Buffer.from("transfer_authority")
], AdrenaClient.programId)[0];
AdrenaClient.stakingRewardTokenMint = constants_1.TOKENS.USDC;
AdrenaClient.lmStakingRewardTokenVault = AdrenaClient.getStakingRewardTokenVaultPda(AdrenaClient.lmStaking);
AdrenaClient.lpStakingRewardTokenVault = AdrenaClient.getStakingRewardTokenVaultPda(AdrenaClient.lpStaking);
exports.default = AdrenaClient; //# sourceMappingURL=AdrenaClient.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/send_tx.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getComputeBudgetInstructions = getComputeBudgetInstructions;
exports.sendTx = sendTx;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const web3_js_2 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const bs58_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bs58@6.0.0/node_modules/bs58/src/cjs/index.cjs [app-route] (ecmascript)"));
const feeTiers = {
    min: 0.01,
    mid: 0.5,
    max: 0.95
};
/**
 * Get priority fees for the current block
 * @param connection - Solana RPC connection
 * @returns Priority fees statistics and instructions for different fee levels
 */ async function getComputeBudgetInstructions(agent, instructions, feeTier) {
    const { blockhash, lastValidBlockHeight } = await agent.connection.getLatestBlockhash();
    const messageV0 = new web3_js_1.TransactionMessage({
        payerKey: agent.wallet_address,
        recentBlockhash: blockhash,
        instructions: instructions
    }).compileToV0Message();
    const transaction = new web3_js_1.VersionedTransaction(messageV0);
    const simulatedTx = agent.connection.simulateTransaction(transaction);
    const estimatedComputeUnits = (await simulatedTx).value.unitsConsumed;
    const safeComputeUnits = Math.ceil(estimatedComputeUnits ? Math.max(estimatedComputeUnits + 100000, estimatedComputeUnits * 1.2) : 200000);
    const computeBudgetLimitInstruction = web3_js_2.ComputeBudgetProgram.setComputeUnitLimit({
        units: safeComputeUnits
    });
    let priorityFee;
    if (agent.config.HELIUS_API_KEY) {
        // Create and set up a legacy transaction for Helius fee estimation
        const legacyTransaction = new web3_js_1.Transaction();
        legacyTransaction.recentBlockhash = blockhash;
        legacyTransaction.lastValidBlockHeight = lastValidBlockHeight;
        legacyTransaction.feePayer = agent.wallet_address;
        // Add the compute budget instruction and original instructions
        legacyTransaction.add(computeBudgetLimitInstruction, ...instructions);
        // Sign the transaction
        const signedTx = await agent.wallet.signTransaction(legacyTransaction);
        // Use Helius API for priority fee calculation
        const response = await fetch(`https://mainnet.helius-rpc.com/?api-key=${agent.config.HELIUS_API_KEY}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                jsonrpc: "2.0",
                id: "1",
                method: "getPriorityFeeEstimate",
                params: [
                    {
                        transaction: bs58_1.default.encode(signedTx.serialize()),
                        options: {
                            recommended: true
                        }
                    }
                ]
            })
        });
        const data = await response.json();
        if (data.error) {
            throw new Error("Error fetching priority fee from Helius API");
        }
        priorityFee = Math.floor(data.result.priorityFeeEstimate * 1.2);
    } else {
        // Use default implementation for priority fee calculation
        priorityFee = await agent.connection.getRecentPrioritizationFees().then((fees)=>fees.sort((a, b)=>a.prioritizationFee - b.prioritizationFee)[Math.floor(fees.length * feeTiers[feeTier])].prioritizationFee);
    }
    const computeBudgetPriorityFeeInstructions = web3_js_2.ComputeBudgetProgram.setComputeUnitPrice({
        microLamports: priorityFee
    });
    return {
        blockhash,
        computeBudgetLimitInstruction,
        computeBudgetPriorityFeeInstructions
    };
}
/**
 * Send a transaction with priority fees
 * @param agent - SolanaAgentKit instance
 * @param tx - Transaction to send
 * @returns Transaction ID
 */ async function sendTx(agent, instructions, otherKeypairs, lookupTables = []) {
    const ixComputeBudget = await getComputeBudgetInstructions(agent, instructions, "mid");
    const allInstructions = [
        ixComputeBudget.computeBudgetLimitInstruction,
        ixComputeBudget.computeBudgetPriorityFeeInstructions,
        ...instructions
    ];
    const messageV0 = new web3_js_1.TransactionMessage({
        payerKey: agent.wallet_address,
        recentBlockhash: ixComputeBudget.blockhash,
        instructions: allInstructions
    }).compileToV0Message(lookupTables);
    const transaction = new web3_js_1.VersionedTransaction(messageV0);
    const signedTx = await agent.wallet.signTransaction(transaction);
    if (otherKeypairs) {
        signedTx.sign(otherKeypairs);
    }
    try {
        const timeout = 60000;
        const startTime = Date.now();
        let txtSig;
        while(Date.now() - startTime < timeout){
            try {
                txtSig = await agent.connection.sendRawTransaction(signedTx.serialize(), {
                    skipPreflight: true
                });
                return await pollTransactionConfirmation(txtSig, agent);
            } catch (error) {
                continue;
            }
        }
    } catch (error) {
        throw new Error(`Error sending smart transaction: ${error}`);
    }
    throw new Error(`Unknown error sending smart transaction`);
}
async function pollTransactionConfirmation(txtSig, agent) {
    // 4 second timeout
    const timeout = 4000;
    // 2 second retry interval
    const interval = 2000;
    let elapsed = 0;
    return new Promise((resolve, reject)=>{
        const intervalId = setInterval(async ()=>{
            elapsed += interval;
            if (elapsed >= timeout) {
                clearInterval(intervalId);
                reject(new Error(`Transaction ${txtSig}'s confirmation timed out`));
            }
            const status = await agent.connection.getSignatureStatuses([
                txtSig
            ]);
            if (status?.value[0]?.confirmationStatus === "confirmed") {
                clearInterval(intervalId);
                resolve(txtSig);
            }
        }, interval);
    });
} //# sourceMappingURL=send_tx.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/adrena/adrena_perp_trading.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.closePerpTradeShort = closePerpTradeShort;
exports.closePerpTradeLong = closePerpTradeLong;
exports.openPerpTradeLong = openPerpTradeLong;
exports.openPerpTradeShort = openPerpTradeShort;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/constants/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const AdrenaClient_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/AdrenaClient.js [app-route] (ecmascript)"));
const send_tx_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/send_tx.js [app-route] (ecmascript)");
const PRICE_DECIMALS = 10;
const ADRENA_PROGRAM_ID = new web3_js_1.PublicKey("13gDzEXCdocbj8iAiqrScGo47NiSuYENGsRqi3SEAwet");
// i.e percentage = -2 (for -2%)
// i.e percentage = 5 (for 5%)
function applySlippage(nb, percentage) {
    const negative = percentage < 0 ? true : false;
    // Do x10_000 so percentage can be up to 4 decimals
    const percentageBN = new anchor_1.BN((negative ? percentage * -1 : percentage) * 10000);
    const delta = nb.mul(percentageBN).divRound(new anchor_1.BN(10000 * 100));
    return negative ? nb.sub(delta) : nb.add(delta);
}
/**
 * Close short trade on Adrena
 * @returns Transaction signature
 */ async function closePerpTradeShort({ agent, price, tradeMint }) {
    const client = await AdrenaClient_1.default.load(agent);
    const owner = agent.wallet.publicKey;
    const custody = client.getCustodyByMint(tradeMint);
    const collateralCustody = client.getCustodyByMint(constants_1.TOKENS.USDC);
    const stakingRewardTokenCustodyAccount = client.getCustodyByMint(AdrenaClient_1.default.stakingRewardTokenMint);
    const stakingRewardTokenCustodyTokenAccount = AdrenaClient_1.default.findCustodyTokenAccountAddress(AdrenaClient_1.default.stakingRewardTokenMint);
    const position = AdrenaClient_1.default.findPositionAddress(owner, custody.pubkey, "long");
    const userProfilePda = AdrenaClient_1.default.getUserProfilePda(owner);
    const userProfile = await client.program.account.userProfile.fetchNullable(userProfilePda);
    const receivingAccount = AdrenaClient_1.default.findATAAddressSync(owner, collateralCustody.mint);
    const preInstructions = [];
    const collateralCustodyOracle = collateralCustody.oracle;
    const collateralCustodyTokenAccount = AdrenaClient_1.default.findCustodyTokenAccountAddress(collateralCustody.mint);
    if (!await AdrenaClient_1.default.isAccountInitialized(agent.connection, receivingAccount)) {
        preInstructions.push(AdrenaClient_1.default.createATAInstruction({
            ataAddress: receivingAccount,
            mint: collateralCustody.mint,
            owner
        }));
    }
    const instruction = await client.program.methods.closePositionShort({
        price: new anchor_1.BN(price * 10 ** PRICE_DECIMALS)
    }).accountsStrict({
        owner,
        receivingAccount,
        transferAuthority: AdrenaClient_1.default.transferAuthority,
        pool: AdrenaClient_1.default.mainPool,
        position: position,
        custody: custody.pubkey,
        custodyTradeOracle: custody.tradeOracle,
        tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
        lmStaking: AdrenaClient_1.default.lmStaking,
        lpStaking: AdrenaClient_1.default.lpStaking,
        cortex: AdrenaClient_1.default.cortex,
        stakingRewardTokenCustody: stakingRewardTokenCustodyAccount.pubkey,
        stakingRewardTokenCustodyOracle: stakingRewardTokenCustodyAccount.oracle,
        stakingRewardTokenCustodyTokenAccount,
        lmStakingRewardTokenVault: AdrenaClient_1.default.lmStakingRewardTokenVault,
        lpStakingRewardTokenVault: AdrenaClient_1.default.lpStakingRewardTokenVault,
        lpTokenMint: AdrenaClient_1.default.lpTokenMint,
        protocolFeeRecipient: client.cortex.protocolFeeRecipient,
        adrenaProgram: AdrenaClient_1.default.programId,
        userProfile: userProfile ? userProfilePda : null,
        caller: owner,
        collateralCustody: collateralCustody.pubkey,
        collateralCustodyOracle,
        collateralCustodyTokenAccount
    }).instruction();
    return (0, send_tx_1.sendTx)(agent, [
        ...preInstructions,
        instruction
    ]);
}
/**
 * Close long trade on Adrena
 * @returns Transaction signature
 */ async function closePerpTradeLong({ agent, price, tradeMint }) {
    const client = await AdrenaClient_1.default.load(agent);
    const owner = agent.wallet.publicKey;
    const custody = client.getCustodyByMint(tradeMint);
    const custodyTokenAccount = AdrenaClient_1.default.findCustodyTokenAccountAddress(tradeMint);
    const stakingRewardTokenCustodyAccount = client.getCustodyByMint(AdrenaClient_1.default.stakingRewardTokenMint);
    const stakingRewardTokenCustodyTokenAccount = AdrenaClient_1.default.findCustodyTokenAccountAddress(AdrenaClient_1.default.stakingRewardTokenMint);
    const position = AdrenaClient_1.default.findPositionAddress(owner, custody.pubkey, "long");
    const userProfilePda = AdrenaClient_1.default.getUserProfilePda(owner);
    const userProfile = await client.program.account.userProfile.fetchNullable(userProfilePda);
    const receivingAccount = AdrenaClient_1.default.findATAAddressSync(owner, custody.mint);
    const preInstructions = [];
    if (!await AdrenaClient_1.default.isAccountInitialized(agent.connection, receivingAccount)) {
        preInstructions.push(AdrenaClient_1.default.createATAInstruction({
            ataAddress: receivingAccount,
            mint: custody.mint,
            owner
        }));
    }
    const instruction = await client.program.methods.closePositionLong({
        price: new anchor_1.BN(price * 10 ** PRICE_DECIMALS)
    }).accountsStrict({
        owner,
        receivingAccount,
        transferAuthority: AdrenaClient_1.default.transferAuthority,
        pool: AdrenaClient_1.default.mainPool,
        position: position,
        custody: custody.pubkey,
        custodyTokenAccount,
        custodyOracle: custody.oracle,
        custodyTradeOracle: custody.tradeOracle,
        tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
        lmStaking: AdrenaClient_1.default.lmStaking,
        lpStaking: AdrenaClient_1.default.lpStaking,
        cortex: AdrenaClient_1.default.cortex,
        stakingRewardTokenCustody: stakingRewardTokenCustodyAccount.pubkey,
        stakingRewardTokenCustodyOracle: stakingRewardTokenCustodyAccount.oracle,
        stakingRewardTokenCustodyTokenAccount,
        lmStakingRewardTokenVault: AdrenaClient_1.default.lmStakingRewardTokenVault,
        lpStakingRewardTokenVault: AdrenaClient_1.default.lpStakingRewardTokenVault,
        lpTokenMint: AdrenaClient_1.default.lpTokenMint,
        protocolFeeRecipient: client.cortex.protocolFeeRecipient,
        adrenaProgram: AdrenaClient_1.default.programId,
        userProfile: userProfile ? userProfilePda : null,
        caller: owner
    }).instruction();
    return (0, send_tx_1.sendTx)(agent, [
        ...preInstructions,
        instruction
    ]);
}
/**
 * Open long trade on Adrena
 *
 * Note: provide the same token as collateralMint and as tradeMint to avoid swap
 * @returns Transaction signature
 */ async function openPerpTradeLong({ agent, price, collateralAmount, collateralMint = constants_1.TOKENS.jitoSOL, leverage = constants_1.DEFAULT_OPTIONS.LEVERAGE_BPS, tradeMint = constants_1.TOKENS.jitoSOL, slippage = 0.3 }) {
    const client = await AdrenaClient_1.default.load(agent);
    const owner = agent.wallet.publicKey;
    const collateralAccount = AdrenaClient_1.default.findATAAddressSync(owner, tradeMint);
    const fundingAccount = AdrenaClient_1.default.findATAAddressSync(owner, collateralMint);
    const receivingCustody = AdrenaClient_1.default.findCustodyAddress(collateralMint);
    const receivingCustodyOracle = client.getCustodyByMint(collateralMint).oracle;
    const receivingCustodyTokenAccount = AdrenaClient_1.default.findCustodyTokenAccountAddress(collateralMint);
    // Principal custody is the custody of the targeted token
    // i.e open a 1 ETH long position, principal custody is ETH
    const principalCustody = AdrenaClient_1.default.findCustodyAddress(tradeMint);
    const principalCustodyAccount = client.getCustodyByMint(tradeMint);
    const principalCustodyOracle = principalCustodyAccount.oracle;
    const principalCustodyTradeOracle = principalCustodyAccount.tradeOracle;
    const principalCustodyTokenAccount = AdrenaClient_1.default.findCustodyTokenAccountAddress(tradeMint);
    const stakingRewardTokenCustodyAccount = client.getCustodyByMint(AdrenaClient_1.default.stakingRewardTokenMint);
    const stakingRewardTokenCustodyTokenAccount = AdrenaClient_1.default.findCustodyTokenAccountAddress(AdrenaClient_1.default.stakingRewardTokenMint);
    const position = AdrenaClient_1.default.findPositionAddress(owner, principalCustody, "long");
    const userProfilePda = AdrenaClient_1.default.getUserProfilePda(owner);
    const userProfile = await client.program.account.userProfile.fetchNullable(userProfilePda);
    const priceWithSlippage = applySlippage(new anchor_1.BN(price * 10 ** PRICE_DECIMALS), slippage);
    const scaledCollateralAmount = new anchor_1.BN(collateralAmount * Math.pow(10, client.getCustodyByMint(collateralMint).decimals));
    const preInstructions = [];
    if (!await AdrenaClient_1.default.isAccountInitialized(agent.connection, collateralAccount)) {
        preInstructions.push(AdrenaClient_1.default.createATAInstruction({
            ataAddress: collateralAccount,
            mint: tradeMint,
            owner
        }));
    }
    const instruction = await client.program.methods.openOrIncreasePositionWithSwapLong({
        price: priceWithSlippage,
        collateral: scaledCollateralAmount,
        leverage,
        referrer: null
    }).accountsStrict({
        owner,
        payer: owner,
        fundingAccount,
        collateralAccount,
        receivingCustody,
        receivingCustodyOracle,
        receivingCustodyTokenAccount,
        principalCustody,
        principalCustodyOracle,
        principalCustodyTradeOracle,
        principalCustodyTokenAccount,
        transferAuthority: AdrenaClient_1.default.transferAuthority,
        cortex: AdrenaClient_1.default.cortex,
        lmStaking: AdrenaClient_1.default.lmStaking,
        lpStaking: AdrenaClient_1.default.lpStaking,
        pool: AdrenaClient_1.default.mainPool,
        position,
        stakingRewardTokenCustody: stakingRewardTokenCustodyAccount.pubkey,
        stakingRewardTokenCustodyOracle: stakingRewardTokenCustodyAccount.oracle,
        stakingRewardTokenCustodyTokenAccount,
        lmStakingRewardTokenVault: AdrenaClient_1.default.lmStakingRewardTokenVault,
        lpStakingRewardTokenVault: AdrenaClient_1.default.lpStakingRewardTokenVault,
        lpTokenMint: AdrenaClient_1.default.lpTokenMint,
        userProfile: userProfile ? userProfilePda : null,
        protocolFeeRecipient: client.cortex.protocolFeeRecipient,
        systemProgram: web3_js_1.SystemProgram.programId,
        tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
        adrenaProgram: ADRENA_PROGRAM_ID
    }).instruction();
    return (0, send_tx_1.sendTx)(agent, [
        ...preInstructions,
        instruction
    ]);
}
/**
 * Open short trade on Adrena
 *
 * Note: provide USDC as collateralMint to avoid swap
 * @returns Transaction signature
 */ async function openPerpTradeShort({ agent, price, collateralAmount, collateralMint = constants_1.TOKENS.USDC, leverage = constants_1.DEFAULT_OPTIONS.LEVERAGE_BPS, tradeMint = constants_1.TOKENS.jitoSOL, slippage = 0.3 }) {
    const client = await AdrenaClient_1.default.load(agent);
    const owner = agent.wallet.publicKey;
    const collateralAccount = AdrenaClient_1.default.findATAAddressSync(owner, tradeMint);
    const fundingAccount = AdrenaClient_1.default.findATAAddressSync(owner, collateralMint);
    const receivingCustody = AdrenaClient_1.default.findCustodyAddress(collateralMint);
    const receivingCustodyOracle = client.getCustodyByMint(collateralMint).oracle;
    const receivingCustodyTokenAccount = AdrenaClient_1.default.findCustodyTokenAccountAddress(collateralMint);
    // Principal custody is the custody of the targeted token
    // i.e open a 1 BTC short position, principal custody is BTC
    const principalCustody = AdrenaClient_1.default.findCustodyAddress(tradeMint);
    const principalCustodyAccount = client.getCustodyByMint(tradeMint);
    const principalCustodyTradeOracle = principalCustodyAccount.tradeOracle;
    const principalCustodyTokenAccount = AdrenaClient_1.default.findCustodyTokenAccountAddress(tradeMint);
    const usdcAta = AdrenaClient_1.default.findATAAddressSync(owner, constants_1.TOKENS.USDC);
    const preInstructions = [];
    if (!await AdrenaClient_1.default.isAccountInitialized(agent.connection, usdcAta)) {
        preInstructions.push(AdrenaClient_1.default.createATAInstruction({
            ataAddress: usdcAta,
            mint: constants_1.TOKENS.USDC,
            owner
        }));
    }
    // Custody used to provide collateral when opening the position
    // Should be a stable token, by default, use USDC
    const instructionCollateralMint = constants_1.TOKENS.USDC;
    const collateralCustody = AdrenaClient_1.default.findCustodyAddress(instructionCollateralMint);
    const collateralCustodyOracle = client.getCustodyByMint(instructionCollateralMint).oracle;
    const collateralCustodyTokenAccount = AdrenaClient_1.default.findCustodyTokenAccountAddress(instructionCollateralMint);
    const stakingRewardTokenCustodyAccount = client.getCustodyByMint(AdrenaClient_1.default.stakingRewardTokenMint);
    const stakingRewardTokenCustodyTokenAccount = AdrenaClient_1.default.findCustodyTokenAccountAddress(AdrenaClient_1.default.stakingRewardTokenMint);
    const position = AdrenaClient_1.default.findPositionAddress(owner, principalCustody, "long");
    const userProfilePda = AdrenaClient_1.default.getUserProfilePda(owner);
    const userProfile = await client.program.account.userProfile.fetchNullable(userProfilePda);
    const priceWithSlippage = applySlippage(new anchor_1.BN(price * 10 ** PRICE_DECIMALS), slippage);
    const scaledCollateralAmount = new anchor_1.BN(collateralAmount * Math.pow(10, client.getCustodyByMint(collateralMint).decimals));
    const instruction = await client.program.methods.openOrIncreasePositionWithSwapShort({
        price: priceWithSlippage,
        collateral: scaledCollateralAmount,
        leverage,
        referrer: null
    }).accountsStrict({
        owner,
        payer: owner,
        fundingAccount,
        collateralAccount,
        receivingCustody,
        receivingCustodyOracle,
        receivingCustodyTokenAccount,
        principalCustody,
        principalCustodyTradeOracle,
        principalCustodyTokenAccount,
        collateralCustody,
        collateralCustodyOracle,
        collateralCustodyTokenAccount,
        transferAuthority: AdrenaClient_1.default.transferAuthority,
        cortex: AdrenaClient_1.default.cortex,
        lmStaking: AdrenaClient_1.default.lmStaking,
        lpStaking: AdrenaClient_1.default.lpStaking,
        pool: AdrenaClient_1.default.mainPool,
        position,
        stakingRewardTokenCustody: stakingRewardTokenCustodyAccount.pubkey,
        stakingRewardTokenCustodyOracle: stakingRewardTokenCustodyAccount.oracle,
        stakingRewardTokenCustodyTokenAccount,
        lmStakingRewardTokenVault: AdrenaClient_1.default.lmStakingRewardTokenVault,
        lpStakingRewardTokenVault: AdrenaClient_1.default.lpStakingRewardTokenVault,
        lpTokenMint: AdrenaClient_1.default.lpTokenMint,
        userProfile: userProfile ? userProfilePda : null,
        protocolFeeRecipient: client.cortex.protocolFeeRecipient,
        systemProgram: web3_js_1.SystemProgram.programId,
        tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
        adrenaProgram: ADRENA_PROGRAM_ID
    }).instruction();
    return (0, send_tx_1.sendTx)(agent, [
        ...preInstructions,
        instruction
    ]);
} //# sourceMappingURL=adrena_perp_trading.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/adrena/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/adrena/adrena_perp_trading.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/alldomains/get_all_domains_tlds.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getAllDomainsTLDs = getAllDomainsTLDs;
const tldparser_1 = __turbopack_require__("[project]/node_modules/.pnpm/@onsol+tldparser@0.6.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate_gpe3kfa7fi22ikssprkfwti5im/node_modules/@onsol/tldparser/dist/cjs/index.js [app-route] (ecmascript)");
/**
 * Get all active top-level domains (TLDs) in the AllDomains Name Service
 * @param agent SolanaAgentKit instance
 * @returns Array of active TLD strings
 */ async function getAllDomainsTLDs(agent) {
    try {
        const tlds = await (0, tldparser_1.getAllTld)(agent.connection);
        return tlds.map((tld)=>String(tld.tld));
    } catch (error) {
        throw new Error(`Failed to fetch TLDs: ${error.message}`);
    }
} //# sourceMappingURL=get_all_domains_tlds.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sns/get_all_registered_all_domains.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getAllRegisteredAllDomains = getAllRegisteredAllDomains;
const spl_name_service_1 = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/index.cjs [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const get_all_domains_tlds_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/alldomains/get_all_domains_tlds.js [app-route] (ecmascript)");
/**
 * Get all registered domains across all TLDs
 * @param agent SolanaAgentKit instance
 * @returns Array of all registered domain names with their TLDs
 */ async function getAllRegisteredAllDomains(agent) {
    try {
        // First get all TLDs
        const tlds = await (0, get_all_domains_tlds_1.getAllDomainsTLDs)(agent);
        const allDomains = [];
        // For each TLD, fetch all registered domains
        for (const tld of tlds){
            const domains = await (0, spl_name_service_1.getAllDomains)(agent.connection, new web3_js_1.PublicKey("namesLPneVptA9Z5rqUDD9tMTWEJwofgaYwp8cawRkX"));
            // Add domains with TLD suffix
            domains.forEach((domain)=>{
                allDomains.push(`${domain}.${tld}`);
            });
        }
        return allDomains;
    } catch (error) {
        throw new Error(`Failed to fetch all registered domains: ${error.message}`);
    }
} //# sourceMappingURL=get_all_registered_all_domains.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sns/get_main_all_domains_domain.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getMainAllDomainsDomain = getMainAllDomainsDomain;
const spl_name_service_1 = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/index.cjs [app-route] (ecmascript)");
/**
 * Get the user's main/favorite domain for a SolanaAgentKit instance
 * @param agent SolanaAgentKit instance
 * @param owner Owner's public key
 * @returns Promise resolving to the main domain name or null if not found
 */ async function getMainAllDomainsDomain(agent, owner) {
    let mainDomain = null;
    try {
        mainDomain = await (0, spl_name_service_1.getFavoriteDomain)(agent.connection, owner);
        return mainDomain.stale ? null : mainDomain.reverse;
    } catch (error) {
        console.error(error);
        return null;
    }
} //# sourceMappingURL=get_main_all_domains_domain.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sns/get_primary_domain.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getPrimaryDomain = getPrimaryDomain;
const spl_name_service_1 = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/index.cjs [app-route] (ecmascript)");
/**
 * Retrieves the primary .sol domain associated with a given Solana public key.
 *
 * This function queries the Bonfida SPL Name Service to get the primary .sol domain for
 * a specified Solana public key. If the primary domain is stale or an error occurs during
 * the resolution, it throws an error.
 *
 * @param agent SolanaAgentKit instance
 * @param account The Solana public key for which to retrieve the primary domain
 * @returns A promise that resolves to the primary .sol domain as a string
 * @throws Error if the domain is stale or if the domain resolution fails
 */ async function getPrimaryDomain(agent, account) {
    try {
        const { reverse, stale } = await (0, spl_name_service_1.getPrimaryDomain)(agent.connection, account);
        if (stale) {
            throw new Error(`Primary domain is stale for account: ${account.toBase58()}`);
        }
        return reverse;
    } catch (error) {
        console.error(error);
        throw new Error(`Failed to get primary domain for account: ${account.toBase58()}`);
    }
} //# sourceMappingURL=get_primary_domain.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sns/register_domain.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.registerDomain = registerDomain;
const spl_name_service_1 = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/index.cjs [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/constants/index.js [app-route] (ecmascript)");
/**
 * Register a .sol domain name using Bonfida Name Service
 * @param agent SolanaAgentKit instance
 * @param name Domain name to register (without .sol)
 * @param spaceKB Space allocation in KB (max 10KB)
 * @returns Transaction signature
 */ async function registerDomain(agent, name, spaceKB = 1) {
    try {
        // Validate space size
        if (spaceKB > 10) {
            throw new Error("Maximum domain size is 10KB");
        }
        // Convert KB to bytes
        const space = spaceKB * 1000;
        const buyerTokenAccount = await (0, spl_token_1.getAssociatedTokenAddressSync)(agent.wallet_address, constants_1.TOKENS.USDC);
        // Create registration instruction
        const instruction = await (0, spl_name_service_1.registerDomainNameV2)(agent.connection, name, space, agent.wallet_address, buyerTokenAccount);
        // Create and sign transaction
        const transaction = new web3_js_1.Transaction().add(...instruction);
        transaction.recentBlockhash = (await agent.connection.getLatestBlockhash()).blockhash;
        transaction.feePayer = agent.wallet_address;
        // Sign and send transaction
        const signature = await agent.connection.sendTransaction(transaction, [
            agent.wallet
        ]);
        return signature;
    } catch (error) {
        throw new Error(`Domain registration failed: ${error.message}`);
    }
} //# sourceMappingURL=register_domain.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sns/resolve_sol_domain.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.resolveSolDomain = resolveSolDomain;
const spl_name_service_1 = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/index.cjs [app-route] (ecmascript)");
/**
 * Resolves a .sol domain to a Solana PublicKey.
 *
 * This function uses the Bonfida SPL Name Service to resolve a given .sol domain
 * to the corresponding Solana PublicKey. The domain can be provided with or without
 * the .sol suffix.
 *
 * @param agent SolanaAgentKit instance
 * @param domain The .sol domain to resolve. This can be provided with or without the .sol TLD suffix
 * @returns A promise that resolves to the corresponding Solana PublicKey
 * @throws Error if the domain resolution fails
 */ async function resolveSolDomain(agent, domain) {
    if (!domain || typeof domain !== "string") {
        throw new Error("Invalid domain. Expected a non-empty string.");
    }
    try {
        return await (0, spl_name_service_1.resolve)(agent.connection, domain);
    } catch (error) {
        console.error(error);
        throw new Error(`Failed to resolve domain: ${domain}`);
    }
} //# sourceMappingURL=resolve_sol_domain.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sns/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sns/get_all_registered_all_domains.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sns/get_main_all_domains_domain.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sns/get_primary_domain.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sns/register_domain.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sns/resolve_sol_domain.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/dexscreener/get_token_data.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getTokenDataByAddress = getTokenDataByAddress;
exports.getTokenAddressFromTicker = getTokenAddressFromTicker;
exports.getTokenDataByTicker = getTokenDataByTicker;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
async function getTokenDataByAddress(mint) {
    try {
        if (!mint) {
            throw new Error("Mint address is required");
        }
        const response = await fetch(`https://tokens.jup.ag/token/${mint}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });
        const token = await response.json();
        return token;
    } catch (error) {
        throw new Error(`Error fetching token data: ${error.message}`);
    }
}
async function getTokenAddressFromTicker(ticker) {
    try {
        const response = await fetch(`https://api.dexscreener.com/latest/dex/search?q=${ticker}`);
        const data = await response.json();
        if (!data.pairs || data.pairs.length === 0) {
            return null;
        }
        // Filter for Solana pairs only and sort by FDV
        let solanaPairs = data.pairs.filter((pair)=>pair.chainId === "solana").sort((a, b)=>(b.fdv || 0) - (a.fdv || 0));
        solanaPairs = solanaPairs.filter((pair)=>pair.baseToken.symbol.toLowerCase() === ticker.toLowerCase());
        // Return the address of the highest FDV Solana pair
        return solanaPairs[0].baseToken.address;
    } catch (error) {
        console.error("Error fetching token address from DexScreener:", error);
        return null;
    }
}
async function getTokenDataByTicker(ticker) {
    const address = await getTokenAddressFromTicker(ticker);
    if (!address) {
        throw new Error(`Token address not found for ticker: ${ticker}`);
    }
    return getTokenDataByAddress(new web3_js_1.PublicKey(address));
} //# sourceMappingURL=get_token_data.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/dexscreener/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/dexscreener/get_token_data.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/alldomains/get_owned_all_domains.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getOwnedAllDomains = getOwnedAllDomains;
const tldparser_1 = __turbopack_require__("[project]/node_modules/.pnpm/@onsol+tldparser@0.6.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate_gpe3kfa7fi22ikssprkfwti5im/node_modules/@onsol/tldparser/dist/cjs/index.js [app-route] (ecmascript)");
/**
 * Get all domains owned domains for a specific TLD for the agent's wallet
 * @param agent SolanaAgentKit instance
 * @param owner - PublicKey of the owner
 * @returns Promise resolving to an array of owned domains or an empty array if none are found
 */ async function getOwnedAllDomains(agent, owner) {
    try {
        const domains = await new tldparser_1.TldParser(agent.connection).getParsedAllUserDomains(owner);
        return domains.map((domain)=>domain.domain);
    } catch (error) {
        throw new Error(`Failed to fetch owned domains: ${error.message}`);
    }
} //# sourceMappingURL=get_owned_all_domains.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/alldomains/get_owned_domains_for_tld.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getOwnedDomainsForTLD = getOwnedDomainsForTLD;
const tldparser_1 = __turbopack_require__("[project]/node_modules/.pnpm/@onsol+tldparser@0.6.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate_gpe3kfa7fi22ikssprkfwti5im/node_modules/@onsol/tldparser/dist/cjs/index.js [app-route] (ecmascript)");
/**
 * Get all domains owned by an address for a specific TLD
 * @param agent SolanaAgentKit instance
 * @param tld Top-level domain (e.g., "sol")
 * @returns Promise resolving to an array of owned domain names for the specified TLD or an empty array if none are found
 */ async function getOwnedDomainsForTLD(agent, tld) {
    try {
        const domains = await new tldparser_1.TldParser(agent.connection).getParsedAllUserDomainsFromTld(agent.wallet_address, tld);
        return domains.map((domain)=>domain.domain);
    } catch (error) {
        throw new Error(`Failed to fetch domains for TLD: ${error.message}`);
    }
} //# sourceMappingURL=get_owned_domains_for_tld.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/alldomains/resolve_domain.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.resolveAllDomains = resolveAllDomains;
const tldparser_1 = __turbopack_require__("[project]/node_modules/.pnpm/@onsol+tldparser@0.6.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate_gpe3kfa7fi22ikssprkfwti5im/node_modules/@onsol/tldparser/dist/cjs/index.js [app-route] (ecmascript)");
/**
 * Resolve all domains for a given agent and domain
 * @param agent SolanaAgentKit instance
 * @param domain Domain name to resolve
 * @returns Promise resolving to the domain or undefined if not found
 */ async function resolveAllDomains(agent, domain) {
    try {
        const tld = await new tldparser_1.TldParser(agent.connection).getOwnerFromDomainTld(domain);
        return tld;
    } catch (error) {
        if (error.message.includes("Cannot read properties of undefined (reading 'owner')")) {
            return undefined;
        }
        throw new Error(`Domain resolution failed: ${error.message}`);
    }
} //# sourceMappingURL=resolve_domain.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/alldomains/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/alldomains/get_all_domains_tlds.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/alldomains/get_owned_all_domains.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/alldomains/get_owned_domains_for_tld.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/alldomains/resolve_domain.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/flash/flash_open_trade.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.flashOpenTrade = flashOpenTrade;
const flash_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/index.js [app-route] (ecmascript)");
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
/**
 * Opens a new position on Flash.Trade
 * @param agent SolanaAgentKit instance
 * @param params Trade parameters
 * @returns Transaction signature
 */ async function flashOpenTrade(agent, params) {
    throw new Error("Not implemented");
// try {
//   const { token, side, collateralUsd, leverage } = params;
//   // Get market ID from token and side using marketTokenMap
//   const tokenMarkets = marketTokenMap[token];
//   if (!tokenMarkets) {
//     throw new Error(`Token ${token} not supported for trading`);
//   }
//   const sideEntry = tokenMarkets[side];
//   if (!sideEntry) {
//     throw new Error(`${side} side not available for ${token}`);
//   }
//   const market = sideEntry.marketID;
//   // Validate market data using marketSdkInfo
//   const marketData = marketSdkInfo[market];
//   if (!marketData) {
//     throw new Error(`Invalid market configuration for ${token}/${side}`);
//   }
//   // Get token information
//   const [targetSymbol, collateralSymbol] = marketData.tokenPair.split("/");
//   const targetToken = ALL_TOKENS.find((t) => t.symbol === targetSymbol);
//   const collateralToken = ALL_TOKENS.find(
//     (t) => t.symbol === collateralSymbol,
//   );
//   if (!targetToken || !collateralToken) {
//     throw new Error(`Token not found for pair ${marketData.tokenPair}`);
//   }
//   // Fetch oracle prices
//   const [targetPrice, collateralPrice] = await Promise.all([
//     fetchOraclePrice(targetSymbol),
//     fetchOraclePrice(collateralSymbol),
//   ]);
//   // Initialize pool configuration and perpClient
//   const poolConfig = PoolConfig.fromIdsByName(
//     marketData.pool,
//     "mainnet-beta",
//   );
//   const perpClient = createPerpClient(agent.connection, agent.wallet);
//   // Calculate position parameters
//   const leverageBN = new BN(leverage);
//   const collateralTokenPrice = convertPriceToNumber(collateralPrice.price);
//   const collateralAmount = calculateCollateralAmount(
//     collateralUsd,
//     collateralTokenPrice,
//     collateralToken.decimals,
//   );
//   // Get custody accounts
//   const { targetCustody, collateralCustody } = await fetchCustodyAccounts(
//     perpClient,
//     poolConfig,
//     targetSymbol,
//     collateralSymbol,
//   );
//   // Calculate position size
//   const positionSize = calculatePositionSize(
//     perpClient,
//     collateralAmount,
//     leverageBN,
//     targetToken,
//     collateralToken,
//     side,
//     targetPrice.price,
//     collateralPrice.price,
//     targetCustody,
//     collateralCustody,
//   );
//   // Get NFT trading account info
//   const tradingAccounts = await getNftTradingAccountInfo(
//     agent.wallet_address,
//     perpClient,
//     poolConfig,
//     collateralSymbol,
//   );
//   if (
//     !tradingAccounts.nftTradingAccountPk ||
//     !tradingAccounts.nftReferralAccountPK
//   ) {
//     throw new Error("Required NFT trading accounts not found");
//   }
//   // Prepare transaction
//   const slippageBps = new BN(1000);
//   const priceWithSlippage = perpClient.getPriceAfterSlippage(
//     true,
//     slippageBps,
//     targetPrice.price,
//     side === "long" ? Side.Long : Side.Short,
//   );
//   // Build and send transaction
//   const { instructions, additionalSigners } = await perpClient.openPosition(
//     targetSymbol,
//     collateralSymbol,
//     priceWithSlippage,
//     collateralAmount,
//     positionSize,
//     side === "long" ? Side.Long : Side.Short,
//     poolConfig,
//     get_flash_privilege(agent),
//     tradingAccounts.nftTradingAccountPk,
//     tradingAccounts.nftReferralAccountPK,
//     tradingAccounts.nftOwnerRebateTokenAccountPk!,
//     false,
//   );
//   const computeBudgetIx = ComputeBudgetProgram.setComputeUnitLimit({
//     units: OPEN_POSITION_CU,
//   });
//   return await perpClient.sendTransaction(
//     [computeBudgetIx, ...instructions],
//     {
//       additionalSigners: additionalSigners,
//       alts: perpClient.addressLookupTables,
//       prioritizationFee: 5000000,
//     },
//   );
// } catch (error) {
//   throw new Error(`Flash trade failed: ${error}`);
// }
}
// Helper functions
function convertPriceToNumber(oraclePrice) {
    const price = parseInt(oraclePrice.price.toString("hex"), 16);
    const exponent = parseInt(oraclePrice.exponent.toString("hex"), 16);
    return price * Math.pow(10, exponent);
}
function calculateCollateralAmount(usdAmount, tokenPrice, decimals) {
    return new anchor_1.BN(usdAmount / tokenPrice * Math.pow(10, decimals));
}
async function fetchCustodyAccounts(perpClient, poolConfig, targetSymbol, collateralSymbol) {
    const targetConfig = poolConfig.custodies.find((c)=>c.symbol === targetSymbol);
    const collateralConfig = poolConfig.custodies.find((c)=>c.symbol === collateralSymbol);
    if (!targetConfig || !collateralConfig) {
        throw new Error("Custody configuration not found");
    }
    const accounts = await perpClient.provider.connection.getMultipleAccountsInfo([
        targetConfig.custodyAccount,
        collateralConfig.custodyAccount
    ]);
    if (!accounts[0] || !accounts[1]) {
        throw new Error("Failed to fetch custody accounts");
    }
    return {
        targetCustody: flash_sdk_1.CustodyAccount.from(targetConfig.custodyAccount, perpClient.program.coder.accounts.decode("custody", accounts[0].data)),
        collateralCustody: flash_sdk_1.CustodyAccount.from(collateralConfig.custodyAccount, perpClient.program.coder.accounts.decode("custody", accounts[1].data))
    };
}
function calculatePositionSize(perpClient, collateralAmount, leverage, targetToken, collateralToken, side, targetPrice, collateralPrice, targetCustody, collateralCustody) {
    return perpClient.getSizeAmountFromLeverageAndCollateral(collateralAmount, leverage.toString(), targetToken, collateralToken, side === "long" ? flash_sdk_1.Side.Long : flash_sdk_1.Side.Short, targetPrice, targetPrice, targetCustody, collateralPrice, collateralPrice, collateralCustody);
} //# sourceMappingURL=flash_open_trade.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/flash/flash_close_trade.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.flashCloseTrade = flashCloseTrade;
/**
 * Closes an existing position on Flash.Trade
 * @param agent SolanaAgentKit instance
 * @param params Trade parameters
 * @returns Transaction signature
 */ async function flashCloseTrade(agent, params) {
    throw new Error("Not implemented");
// try {
//   const { token, side } = params;
//   // Get market ID from token and side using marketTokenMap
//   const tokenMarkets = marketTokenMap[token];
//   if (!tokenMarkets) {
//     throw new Error(`Token ${token} not supported for trading`);
//   }
//   const sideEntry = tokenMarkets[side];
//   if (!sideEntry) {
//     throw new Error(`${side} side not available for ${token}`);
//   }
//   const market = sideEntry.marketID;
//   // Validate market data using marketSdkInfo
//   const marketData = marketSdkInfo[market];
//   if (!marketData) {
//     throw new Error(`Invalid market configuration for ${token}/${side}`);
//   }
//   // Get token information
//   const [targetSymbol, collateralSymbol] = marketData.tokenPair.split("/");
//   // Fetch oracle prices
//   const [targetPrice] = await Promise.all([
//     fetchOraclePrice(targetSymbol),
//     fetchOraclePrice(collateralSymbol),
//   ]);
//   // Initialize pool configuration and perpClient
//   const poolConfig = PoolConfig.fromIdsByName(
//     marketData.pool,
//     "mainnet-beta",
//   );
//   const perpClient = createPerpClient(agent.connection, agent.wallet);
//   // Calculate price after slippage
//   const slippageBpsBN = new BN(100); // 1% slippage
//   const sideEnum = side === "long" ? Side.Long : Side.Short;
//   const priceWithSlippage = perpClient.getPriceAfterSlippage(
//     false, // isEntry = false for closing position
//     slippageBpsBN,
//     targetPrice.price,
//     sideEnum,
//   );
//   // Get NFT trading account info
//   const tradingAccounts = await getNftTradingAccountInfo(
//     agent.wallet_address,
//     perpClient,
//     poolConfig,
//     collateralSymbol,
//   );
//   if (
//     !tradingAccounts.nftTradingAccountPk ||
//     !tradingAccounts.nftReferralAccountPK ||
//     !tradingAccounts.nftOwnerRebateTokenAccountPk
//   ) {
//     throw new Error("Required NFT trading accounts not found");
//   }
//   // Build and send transaction
//   const { instructions, additionalSigners } = await perpClient.closePosition(
//     targetSymbol,
//     collateralSymbol,
//     priceWithSlippage,
//     sideEnum,
//     poolConfig,
//     get_flash_privilege(agent),
//     tradingAccounts.nftTradingAccountPk,
//     tradingAccounts.nftReferralAccountPK,
//     tradingAccounts.nftOwnerRebateTokenAccountPk,
//   );
//   const computeBudgetIx = ComputeBudgetProgram.setComputeUnitLimit({
//     units: CLOSE_POSITION_CU,
//   });
//   return await perpClient.sendTransaction(
//     [computeBudgetIx, ...instructions],
//     {
//       additionalSigners: additionalSigners,
//       alts: perpClient.addressLookupTables,
//       prioritizationFee: 5000000,
//     },
//   );
// } catch (error) {
//   throw new Error(`Flash trade close failed: ${error}`);
// }
} //# sourceMappingURL=flash_close_trade.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/flash/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/flash/flash_open_trade.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/flash/flash_close_trade.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/gibwork/create_gibwork_task.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.create_gibwork_task = create_gibwork_task;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
/**
 * Create an new task on Gibwork
 * @param agent SolanaAgentKit instance
 * @param title Title of the task
 * @param content Description of the task
 * @param requirements Requirements to complete the task
 * @param tags List of tags associated with the task
 * @param payer Payer address for the task (default: agent wallet address)
 * @param tokenMintAddress Token mint address for payment
 * @param tokenAmount Payment amount for the task
 * @returns Object containing task creation transaction and generated taskId
 */ async function create_gibwork_task(agent, title, content, requirements, tags, tokenMintAddress, tokenAmount, payer) {
    try {
        const apiResponse = await fetch("https://api2.gib.work/tasks/public/transaction", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                title: title,
                content: content,
                requirements: requirements,
                tags: tags,
                payer: payer?.toBase58() || agent.wallet.publicKey.toBase58(),
                token: {
                    mintAddress: tokenMintAddress.toBase58(),
                    amount: tokenAmount
                }
            })
        });
        const responseData = await apiResponse.json();
        if (!responseData.taskId && !responseData.serializedTransaction) {
            throw new Error(`${responseData.message}`);
        }
        const serializedTransaction = Buffer.from(responseData.serializedTransaction, "base64");
        const tx = web3_js_1.VersionedTransaction.deserialize(serializedTransaction);
        const signedTx = await agent.wallet.signTransaction(tx);
        const signature = await agent.connection.sendTransaction(signedTx, {
            preflightCommitment: "confirmed",
            maxRetries: 3
        });
        const latestBlockhash = await agent.connection.getLatestBlockhash();
        await agent.connection.confirmTransaction({
            signature,
            blockhash: latestBlockhash.blockhash,
            lastValidBlockHeight: latestBlockhash.lastValidBlockHeight
        });
        return {
            status: "success",
            taskId: responseData.taskId,
            signature: signature
        };
    } catch (err) {
        throw new Error(`${err.message}`);
    }
} //# sourceMappingURL=create_gibwork_task.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/gibwork/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/gibwork/create_gibwork_task.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/jupiter/fetch_price.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.fetchPrice = fetchPrice;
/**
 * Fetch the price of a given token quoted in USDC using Jupiter API
 * @param tokenId The token mint address
 * @returns The price of the token quoted in USDC
 */ async function fetchPrice(tokenId) {
    try {
        const response = await fetch(`https://api.jup.ag/price/v2?ids=${tokenId}`);
        if (!response.ok) {
            throw new Error(`Failed to fetch price: ${response.statusText}`);
        }
        const data = await response.json();
        const price = data.data[tokenId.toBase58()]?.price;
        if (!price) {
            throw new Error("Price data not available for the given token.");
        }
        return price;
    } catch (error) {
        throw new Error(`Price fetch failed: ${error.message}`);
    }
} //# sourceMappingURL=fetch_price.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/jupiter/stake_with_jup.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.stakeWithJup = stakeWithJup;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
/**
 * Stake SOL with Jup validator
 * @param agent SolanaAgentKit instance
 * @param amount Amount of SOL to stake
 * @returns Transaction signature
 */ async function stakeWithJup(agent, amount) {
    try {
        const res = await fetch(`https://worker.jup.ag/blinks/swap/So11111111111111111111111111111111111111112/jupSoLaHXQiZZTSfEWMTRRgpnyFm8f6sZdosWBjx93v/${amount}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                account: agent.wallet.publicKey.toBase58()
            })
        });
        const data = await res.json();
        const txn = web3_js_1.VersionedTransaction.deserialize(Buffer.from(data.transaction, "base64"));
        const { blockhash } = await agent.connection.getLatestBlockhash();
        txn.message.recentBlockhash = blockhash;
        // Sign and send transaction
        txn.sign([
            agent.wallet
        ]);
        const signature = await agent.connection.sendTransaction(txn, {
            preflightCommitment: "confirmed",
            maxRetries: 3
        });
        const latestBlockhash = await agent.connection.getLatestBlockhash();
        await agent.connection.confirmTransaction({
            signature,
            blockhash: latestBlockhash.blockhash,
            lastValidBlockHeight: latestBlockhash.lastValidBlockHeight
        });
        return signature;
    } catch (error) {
        console.error(error);
        throw new Error(`jupSOL staking failed: ${error.message}`);
    }
} //# sourceMappingURL=stake_with_jup.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/jupiter/trade.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.trade = trade;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/constants/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const send_tx_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/send_tx.js [app-route] (ecmascript)");
/**
 * Swap tokens using Jupiter Exchange
 * @param agent SolanaAgentKit instance
 * @param outputMint Target token mint address
 * @param inputAmount Amount to swap (in token decimals)
 * @param inputMint Source token mint address (defaults to USDC)
 * @param slippageBps Slippage tolerance in basis points (default: 300 = 3%)
 * @returns Transaction signature
 */ async function trade(agent, outputMint, inputAmount, inputMint = constants_1.TOKENS.USDC, slippageBps = constants_1.DEFAULT_OPTIONS.SLIPPAGE_BPS) {
    try {
        // Check if input token is native SOL
        const isNativeSol = inputMint.equals(constants_1.TOKENS.SOL);
        // For native SOL, we use LAMPORTS_PER_SOL, otherwise fetch mint info
        const inputDecimals = isNativeSol ? 9 // SOL always has 9 decimals
         : (await (0, spl_token_1.getMint)(agent.connection, inputMint)).decimals;
        // Calculate the correct amount based on actual decimals
        const scaledAmount = inputAmount * Math.pow(10, inputDecimals);
        const quoteResponse = await (await fetch(`${constants_1.JUP_API}/quote?` + `inputMint=${isNativeSol ? constants_1.TOKENS.SOL.toString() : inputMint.toString()}` + `&outputMint=${outputMint.toString()}` + `&amount=${scaledAmount}` + `&slippageBps=${slippageBps}` + `&onlyDirectRoutes=true` + `&maxAccounts=40` + `${agent.config.JUPITER_FEE_BPS ? `&platformFeeBps=${agent.config.JUPITER_FEE_BPS}` : ""}`)).json();
        // Get serialized transaction
        let feeAccount;
        if (agent.config.JUPITER_REFERRAL_ACCOUNT) {
            [feeAccount] = web3_js_1.PublicKey.findProgramAddressSync([
                Buffer.from("referral_ata"),
                new web3_js_1.PublicKey(agent.config.JUPITER_REFERRAL_ACCOUNT).toBuffer(),
                constants_1.TOKENS.SOL.toBuffer()
            ], new web3_js_1.PublicKey(constants_1.JUP_REFERRAL_ADDRESS));
        }
        const instructions = await (await fetch("https://quote-api.jup.ag/v6/swap-instructions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                // quoteResponse from /quote or /swap api
                quoteResponse,
                userPublicKey: agent.wallet.publicKey.toBase58()
            })
        })).json();
        // Deserialize transaction
        if (instructions.error) {
            throw new Error("Failed to get swap instructions: " + instructions.error);
        }
        const { tokenLedgerInstruction, computeBudgetInstructions, setupInstructions, swapInstruction: swapInstructionPayload, cleanupInstruction, addressLookupTableAddresses } = instructions;
        const deserializeInstruction = (instruction)=>{
            return new web3_js_1.TransactionInstruction({
                programId: new web3_js_1.PublicKey(instruction.programId),
                keys: instruction.accounts.map((key)=>({
                        pubkey: new web3_js_1.PublicKey(key.pubkey),
                        isSigner: key.isSigner,
                        isWritable: key.isWritable
                    })),
                data: Buffer.from(instruction.data, "base64")
            });
        };
        const getAddressLookupTableAccounts = async (keys)=>{
            const addressLookupTableAccountInfos = await agent.connection.getMultipleAccountsInfo(keys.map((key)=>new web3_js_1.PublicKey(key)));
            return addressLookupTableAccountInfos.reduce((acc, accountInfo, index)=>{
                const addressLookupTableAddress = keys[index];
                if (accountInfo) {
                    const addressLookupTableAccount = new web3_js_1.AddressLookupTableAccount({
                        key: new web3_js_1.PublicKey(addressLookupTableAddress),
                        state: web3_js_1.AddressLookupTableAccount.deserialize(accountInfo.data)
                    });
                    acc.push(addressLookupTableAccount);
                }
                return acc;
            }, new Array());
        };
        const addressLookupTableAccounts = [];
        addressLookupTableAccounts.push(...await getAddressLookupTableAccounts(addressLookupTableAddresses));
        const signature = await (0, send_tx_1.sendTx)(agent, [
            ...setupInstructions.map(deserializeInstruction),
            deserializeInstruction(swapInstructionPayload),
            deserializeInstruction(cleanupInstruction)
        ], undefined, addressLookupTableAccounts);
        return signature;
    } catch (error) {
        throw new Error(`Swap failed: ${error.message}`);
    }
} //# sourceMappingURL=trade.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/jupiter/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/jupiter/fetch_price.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/jupiter/stake_with_jup.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/jupiter/trade.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/lulo/lend.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.lendAsset = lendAsset;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
/**
 * Lend tokens for yields using Lulo
 * @param agent SolanaAgentKit instance
 * @param amount Amount of USDC to lend
 * @returns Transaction signature
 */ async function lendAsset(agent, amount) {
    try {
        const response = await fetch(`https://blink.lulo.fi/actions?amount=${amount}&symbol=USDC`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                account: agent.wallet.publicKey.toBase58()
            })
        });
        const data = await response.json();
        // Deserialize the transaction
        const luloTxn = web3_js_1.VersionedTransaction.deserialize(Buffer.from(data.transaction, "base64"));
        // Get a recent blockhash and set it
        const { blockhash } = await agent.connection.getLatestBlockhash();
        luloTxn.message.recentBlockhash = blockhash;
        // Sign and send transaction
        luloTxn.sign([
            agent.wallet
        ]);
        const signature = await agent.connection.sendTransaction(luloTxn, {
            preflightCommitment: "confirmed",
            maxRetries: 3
        });
        // Wait for confirmation using the latest strategy
        const latestBlockhash = await agent.connection.getLatestBlockhash();
        await agent.connection.confirmTransaction({
            signature,
            blockhash: latestBlockhash.blockhash,
            lastValidBlockHeight: latestBlockhash.lastValidBlockHeight
        });
        return signature;
    } catch (error) {
        throw new Error(`Lending failed: ${error.message}`);
    }
} //# sourceMappingURL=lend.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/lulo/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/lulo/lend.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/manifest/manifest_trade.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.manifestCreateMarket = manifestCreateMarket;
exports.limitOrder = limitOrder;
exports.cancelAllOrders = cancelAllOrders;
exports.withdrawAll = withdrawAll;
exports.generateOrdersfromPattern = generateOrdersfromPattern;
exports.batchOrder = batchOrder;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const manifest_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@cks-systems+manifest-sdk@0.1.59_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_qo2b3cb4mlwh4hxn3pybbzuqze/node_modules/@cks-systems/manifest-sdk/dist/cjs/index.js [app-route] (ecmascript)");
async function manifestCreateMarket(agent, baseMint, quoteMint) {
    const marketKeypair = web3_js_1.Keypair.generate();
    const FIXED_MANIFEST_HEADER_SIZE = 256;
    const createAccountIx = web3_js_1.SystemProgram.createAccount({
        fromPubkey: agent.wallet.publicKey,
        newAccountPubkey: marketKeypair.publicKey,
        space: FIXED_MANIFEST_HEADER_SIZE,
        lamports: await agent.connection.getMinimumBalanceForRentExemption(FIXED_MANIFEST_HEADER_SIZE),
        programId: new web3_js_1.PublicKey("MNFSTqtC93rEfYHB6hF82sKdZpUDFWkViLByLd1k1Ms")
    });
    const createMarketIx = manifest_sdk_1.ManifestClient["createMarketIx"](agent.wallet.publicKey, baseMint, quoteMint, marketKeypair.publicKey);
    const tx = new web3_js_1.Transaction();
    tx.add(createAccountIx);
    tx.add(createMarketIx);
    const signature = await (0, web3_js_1.sendAndConfirmTransaction)(agent.connection, tx, [
        agent.wallet,
        marketKeypair
    ]);
    return [
        signature,
        marketKeypair.publicKey.toBase58()
    ];
}
/**
 * Place limit orders using Manifest
 * @param agent SolanaAgentKit instance
 * @param marketId Public key for the manifest market
 * @param quantity Amount to trade in tokens
 * @param side Buy or Sell
 * @param price Price in tokens ie. SOL/USDC
 * @returns Transaction signature
 */ async function limitOrder(agent, marketId, quantity, side, price) {
    throw new Error("Not implemented");
// try {
//   const mfxClient = await ManifestClient.getClientForMarket(
//     agent.connection,
//     marketId,
//     agent.wallet,
//   );
//   const orderParams: WrapperPlaceOrderParamsExternal = {
//     numBaseTokens: quantity,
//     tokenPrice: price,
//     isBid: side === "Buy",
//     lastValidSlot: 0,
//     orderType: OrderType.Limit,
//     clientOrderId: Number(Math.random() * 1000),
//   };
//   const depositPlaceOrderIx: TransactionInstruction[] =
//     await mfxClient.placeOrderWithRequiredDepositIx(
//       agent.wallet.publicKey,
//       orderParams,
//     );
//   const signature = await sendAndConfirmTransaction(
//     agent.connection,
//     new Transaction().add(...depositPlaceOrderIx),
//     [agent.wallet],
//   );
//   return signature;
// } catch (error: any) {
//   throw new Error(`Limit Order failed: ${error.message}`);
// }
}
/**
 * Cancels all orders from Manifest
 * @param agent SolanaAgentKit instance
 * @param marketId Public key for the manifest market
 * @returns Transaction signature
 */ async function cancelAllOrders(agent, marketId) {
    throw new Error("Not implemented");
// try {
//   const mfxClient = await ManifestClient.getClientForMarket(
//     agent.connection,
//     marketId,
//     agent.wallet,
//   );
//   const cancelAllOrdersIx = await mfxClient.cancelAllIx();
//   const signature = await sendAndConfirmTransaction(
//     agent.connection,
//     new Transaction().add(cancelAllOrdersIx),
//     [agent.wallet],
//   );
//   return signature;
// } catch (error: any) {
//   throw new Error(`Cancel all orders failed: ${error.message}`);
// }
}
/**
 * Withdraws all funds from Manifest
 * @param agent SolanaAgentKit instance
 * @param marketId Public key for the manifest market
 * @returns Transaction signature
 */ async function withdrawAll(agent, marketId) {
    throw new Error("Not implemented");
// try {
//   const mfxClient = await ManifestClient.getClientForMarket(
//     agent.connection,
//     marketId,
//     agent.wallet,
//   );
//   const withdrawAllIx = await mfxClient.withdrawAllIx();
//   const signature = await sendAndConfirmTransaction(
//     agent.connection,
//     new Transaction().add(...withdrawAllIx),
//     [agent.wallet],
//   );
//   return signature;
// } catch (error: any) {
//   throw new Error(`Withdraw all failed: ${error.message}`);
// }
}
/**
 * Generates an array of orders based on the specified pattern
 */ function generateOrdersfromPattern(pattern) {
    const orders = [];
    // Random number of orders if not specified, max of 8
    const numOrders = pattern.numberOfOrders || Math.ceil(Math.random() * 8);
    // Calculate price points
    const prices = [];
    if (pattern.priceRange) {
        const { min, max } = pattern.priceRange;
        if (min && max) {
            // Generate evenly spaced prices
            for(let i = 0; i < numOrders; i++){
                if (pattern.spacing?.type === "percentage") {
                    const factor = 1 + pattern.spacing.value / 100;
                    prices.push(min * Math.pow(factor, i));
                } else {
                    const step = (max - min) / (numOrders - 1);
                    prices.push(min + step * i);
                }
            }
        } else if (min) {
            // Generate prices starting from min with specified spacing
            for(let i = 0; i < numOrders; i++){
                if (pattern.spacing?.type === "percentage") {
                    const factor = 1 + pattern.spacing.value / 100;
                    prices.push(min * Math.pow(factor, i));
                } else {
                    prices.push(min + (pattern.spacing?.value || 0.01) * i);
                }
            }
        }
    }
    // Calculate quantities
    let quantities = [];
    if (pattern.totalQuantity) {
        const individualQty = pattern.totalQuantity / numOrders;
        quantities = Array(numOrders).fill(individualQty);
    } else if (pattern.individualQuantity) {
        quantities = Array(numOrders).fill(pattern.individualQuantity);
    }
    // Generate orders
    for(let i = 0; i < numOrders; i++){
        orders.push({
            side: pattern.side,
            price: prices[i],
            quantity: quantities[i]
        });
    }
    return orders;
}
/**
 * Validates that sell orders are not priced below buy orders
 * @param orders Array of order parameters to validate
 * @throws Error if orders are crossed
 */ function validateNoCrossedOrders(orders) {
    // Find lowest sell and highest buy prices
    let lowestSell = Number.MAX_SAFE_INTEGER;
    let highestBuy = 0;
    orders.forEach((order)=>{
        if (order.side === "Sell" && order.price < lowestSell) {
            lowestSell = order.price;
        }
        if (order.side === "Buy" && order.price > highestBuy) {
            highestBuy = order.price;
        }
    });
    // Check if orders cross
    if (lowestSell <= highestBuy) {
        throw new Error(`Invalid order prices: Sell order at ${lowestSell} is lower than or equal to Buy order at ${highestBuy}. Orders cannot cross.`);
    }
}
/**
 * Place batch orders using Manifest
 * @param agent SolanaAgentKit instance
 * @param marketId Public key for the manifest market
 * @param quantity Amount to trade in tokens
 * @param side Buy or Sell
 * @param price Price in tokens ie. SOL/USDC
 * @returns Transaction signature
 */ async function batchOrder(agent, marketId, orders) {
    throw new Error("Not implemented");
// try {
//   validateNoCrossedOrders(orders);
//   const mfxClient = await ManifestClient.getClientForMarket(
//     agent.connection,
//     marketId,
//     agent.wallet,
//   );
//   const placeParams: WrapperPlaceOrderParamsExternal[] = orders.map(
//     (order) => ({
//       numBaseTokens: order.quantity,
//       tokenPrice: order.price,
//       isBid: order.side === "Buy",
//       lastValidSlot: 0,
//       orderType: OrderType.Limit,
//       clientOrderId: Number(Math.random() * 10000),
//     }),
//   );
//   const batchOrderIx: TransactionInstruction = await mfxClient.batchUpdateIx(
//     placeParams,
//     [],
//     true,
//   );
//   const signature = await sendAndConfirmTransaction(
//     agent.connection,
//     new Transaction().add(batchOrderIx),
//     [agent.wallet],
//   );
//   return signature;
// } catch (error: any) {
//   throw new Error(`Batch Order failed: ${error.message}`);
// }
} //# sourceMappingURL=manifest_trade.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/manifest/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/manifest/manifest_trade.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/get_tps.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getTPS = getTPS;
async function getTPS(agent) {
    const perfSamples = await agent.connection.getRecentPerformanceSamples();
    if (!perfSamples.length || !perfSamples[0]?.numTransactions || !perfSamples[0]?.samplePeriodSecs) {
        throw new Error("No performance samples available");
    }
    const tps = perfSamples[0].numTransactions / perfSamples[0].samplePeriodSecs;
    return tps;
} //# sourceMappingURL=get_tps.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/request_faucet_funds.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.request_faucet_funds = request_faucet_funds;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
/**
 * Request SOL from the Solana faucet (devnet/testnet only)
 * @param agent - SolanaAgentKit instance
 * @returns Transaction signature
 * @throws Error if the request fails or times out
 */ async function request_faucet_funds(agent) {
    const tx = await agent.connection.requestAirdrop(agent.wallet_address, 5 * web3_js_1.LAMPORTS_PER_SOL);
    const latestBlockHash = await agent.connection.getLatestBlockhash();
    await agent.connection.confirmTransaction({
        signature: tx,
        blockhash: latestBlockHash.blockhash,
        lastValidBlockHeight: latestBlockHash.lastValidBlockHeight
    });
    return tx;
} //# sourceMappingURL=request_faucet_funds.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/close_empty_token_accounts.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.closeEmptyTokenAccounts = closeEmptyTokenAccounts;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
/**
 * Close Empty SPL Token accounts of the agent
 * @param agent SolanaAgentKit instance
 * @returns transaction signature and total number of accounts closed
 */ async function closeEmptyTokenAccounts(agent) {
    try {
        const spl_token = await create_close_instruction(agent, spl_token_1.TOKEN_PROGRAM_ID);
        const token_2022 = await create_close_instruction(agent, spl_token_1.TOKEN_2022_PROGRAM_ID);
        const transaction = new web3_js_1.Transaction();
        const MAX_INSTRUCTIONS = 40; // 40 instructions can be processed in a single transaction without failing
        spl_token.slice(0, Math.min(MAX_INSTRUCTIONS, spl_token.length)).forEach((instruction)=>transaction.add(instruction));
        token_2022.slice(0, Math.max(0, MAX_INSTRUCTIONS - spl_token.length)).forEach((instruction)=>transaction.add(instruction));
        const size = spl_token.length + token_2022.length;
        if (size === 0) {
            return {
                signature: "",
                size: 0
            };
        }
        const signature = await agent.connection.sendTransaction(transaction, [
            agent.wallet
        ]);
        return {
            signature,
            size
        };
    } catch (error) {
        throw new Error(`Error closing empty token accounts: ${error}`);
    }
}
/**
 * creates the close instuctions of a spl token account
 * @param agnet SolanaAgentKit instance
 * @param token_program Token Program Id
 * @returns close instuction array
 */ async function create_close_instruction(agent, token_program) {
    const instructions = [];
    const ata_accounts = await agent.connection.getTokenAccountsByOwner(agent.wallet_address, {
        programId: token_program
    }, "confirmed");
    const tokens = ata_accounts.value;
    const accountExceptions = [
        "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
    ];
    for(let i = 0; i < tokens.length; i++){
        const token_data = spl_token_1.AccountLayout.decode(tokens[i].account.data);
        if (token_data.amount === BigInt(0) && !accountExceptions.includes(token_data.mint.toString())) {
            const closeInstruction = (0, spl_token_1.createCloseAccountInstruction)(ata_accounts.value[i].pubkey, agent.wallet_address, agent.wallet_address, [], token_program);
            instructions.push(closeInstruction);
        }
    }
    return instructions;
} //# sourceMappingURL=close_empty_token_accounts.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/transfer.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.transfer = transfer;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const web3_js_2 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const send_tx_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/send_tx.js [app-route] (ecmascript)");
/**
 * Transfer SOL or SPL tokens to a recipient
 * @param agent SolanaAgentKit instance
 * @param to Recipient's public key
 * @param amount Amount to transfer
 * @param mint Optional mint address for SPL tokens
 * @returns Transaction signature
 */ async function transfer(agent, to, amount, mint) {
    try {
        let tx;
        if (!mint) {
            // Transfer native SOL
            const transaction = new web3_js_1.Transaction().add(web3_js_1.SystemProgram.transfer({
                fromPubkey: agent.wallet_address,
                toPubkey: to,
                lamports: amount * web3_js_2.LAMPORTS_PER_SOL
            }));
            tx = await (0, send_tx_1.sendTx)(agent, transaction.instructions);
        } else {
            const transaction = new web3_js_1.Transaction();
            // Transfer SPL token
            const fromAta = await (0, spl_token_1.getAssociatedTokenAddress)(mint, agent.wallet_address);
            const toAta = await (0, spl_token_1.getAssociatedTokenAddress)(mint, to);
            try {
                const toAtaAcc = await (0, spl_token_1.getAccount)(agent.connection, toAta);
            } catch  {
                transaction.add((0, spl_token_1.createAssociatedTokenAccountInstruction)(agent.wallet_address, toAta, to, mint));
            }
            // Get mint info to determine decimals
            const mintInfo = await (0, spl_token_1.getMint)(agent.connection, mint);
            const adjustedAmount = amount * Math.pow(10, mintInfo.decimals);
            transaction.add((0, spl_token_1.createTransferInstruction)(fromAta, toAta, agent.wallet_address, adjustedAmount));
            tx = await (0, send_tx_1.sendTx)(agent, transaction.instructions);
        }
        return tx;
    } catch (error) {
        throw new Error(`Transfer failed: ${error.message}`);
    }
} //# sourceMappingURL=transfer.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/get_balance.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.get_balance = get_balance;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
/**
 * Get the balance of SOL or an SPL token for the agent's wallet
 * @param agent - SolanaAgentKit instance
 * @param token_address - Optional SPL token mint address. If not provided, returns SOL balance
 * @returns Promise resolving to the balance as a number (in UI units) or null if account doesn't exist
 */ async function get_balance(agent, token_address) {
    if (!token_address) {
        return await agent.connection.getBalance(agent.wallet_address) / web3_js_1.LAMPORTS_PER_SOL;
    }
    const token_account = await agent.connection.getTokenAccountBalance(token_address);
    return token_account.value.uiAmount || 0;
} //# sourceMappingURL=get_balance.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/get_balance_other.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.get_balance_other = get_balance_other;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
/**
 * Get the balance of SOL or an SPL token for the specified wallet address (other than the agent's wallet)
 * @param agent - SolanaAgentKit instance
 * @param wallet_address - Public key of the wallet to check balance for
 * @param token_address - Optional SPL token mint address. If not provided, returns SOL balance
 * @returns Promise resolving to the balance as a number (in UI units) or 0 if account doesn't exist
 */ async function get_balance_other(agent, wallet_address, token_address) {
    try {
        if (!token_address) {
            return await agent.connection.getBalance(wallet_address) / web3_js_1.LAMPORTS_PER_SOL;
        }
        const tokenAccounts = await agent.connection.getTokenAccountsByOwner(wallet_address, {
            mint: token_address
        });
        if (tokenAccounts.value.length === 0) {
            console.warn(`No token accounts found for wallet ${wallet_address.toString()} and token ${token_address.toString()}`);
            return 0;
        }
        const tokenAccount = await agent.connection.getParsedAccountInfo(tokenAccounts.value[0].pubkey);
        const tokenData = tokenAccount.value?.data;
        return tokenData.parsed?.info?.tokenAmount?.uiAmount || 0;
    } catch (error) {
        throw new Error(`Error fetching on-chain balance for ${token_address?.toString()}: ${error}`);
    }
} //# sourceMappingURL=get_balance_other.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/get_tps.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/request_faucet_funds.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/close_empty_token_accounts.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/transfer.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/get_balance.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/get_balance_other.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/agent/create_image.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.create_image = create_image;
const openai_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4.0.9_utf-8-validate@5.0.10__zod@3.24.1/node_modules/openai/index.js [app-route] (ecmascript)"));
/**
 * Generate an image using OpenAI's DALL-E
 * @param agent SolanaAgentKit instance
 * @param prompt Text description of the image to generate
 * @param size Image size ('256x256', '512x512', or '1024x1024') (default: '1024x1024')
 * @param n Number of images to generate (default: 1)
 * @returns Object containing the generated image URLs
 */ async function create_image(agent, prompt, size = "1024x1024", n = 1) {
    try {
        if (!agent.config.OPENAI_API_KEY) {
            throw new Error("OpenAI API key not found in agent configuration");
        }
        const openai = new openai_1.default({
            apiKey: agent.config.OPENAI_API_KEY
        });
        const response = await openai.images.generate({
            prompt,
            n,
            size
        });
        return {
            images: response.data.map((img)=>img.url)
        };
    } catch (error) {
        throw new Error(`Image generation failed: ${error.message}`);
    }
} //# sourceMappingURL=create_image.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/agent/get_wallet_address.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.get_wallet_address = get_wallet_address;
/**
 * Get the agents wallet address
 * @param agent - SolanaAgentKit instance
 * @returns string
 */ function get_wallet_address(agent) {
    return agent.wallet_address.toBase58();
} //# sourceMappingURL=get_wallet_address.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/agent/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/agent/create_image.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/agent/get_wallet_address.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/metaplex/deploy_collection.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.deploy_collection = deploy_collection;
/**
 * Deploy a new NFT collection
 * @param agent SolanaAgentKit instance
 * @param options Collection options including name, URI, royalties, and creators
 * @returns Object containing collection address and metadata
 */ async function deploy_collection(agent, options) {
    throw new Error("Not implemented");
// try {
//   // Initialize Umi
//   const umi = createUmi(agent.connection.rpcEndpoint).use(mplCore());
//   umi.use(keypairIdentity(fromWeb3JsKeypair(agent.wallet)));
//   // Generate collection signer
//   const collectionSigner = generateSigner(umi);
//   // Format creators if provided
//   const formattedCreators = options.creators?.map((creator) => ({
//     address: publicKey(creator.address),
//     percentage: creator.percentage,
//   })) || [
//     {
//       address: publicKey(agent.wallet_address.toString()),
//       percentage: 100,
//     },
//   ];
//   // Create collection
//   const tx = await createCollection(umi, {
//     collection: collectionSigner,
//     name: options.name,
//     uri: options.uri,
//     plugins: [
//       {
//         type: "Royalties",
//         basisPoints: options.royaltyBasisPoints || 500, // Default 5%
//         creators: formattedCreators,
//         ruleSet: ruleSet("None"), // Compatibility rule set
//       },
//     ],
//   }).sendAndConfirm(umi);
//   return {
//     collectionAddress: toWeb3JsPublicKey(collectionSigner.publicKey),
//     signature: tx.signature,
//   };
// } catch (error: any) {
//   throw new Error(`Collection deployment failed: ${error.message}`);
// }
} //# sourceMappingURL=deploy_collection.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/metaplex/mint_nft.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.mintCollectionNFT = mintCollectionNFT;
/**
 * Mint a new NFT as part of an existing collection
 * @param agent SolanaAgentKit instance
 * @param collectionMint Address of the collection's master NFT
 * @param metadata NFT metadata object
 * @param recipient Optional recipient address (defaults to wallet address)
 * @returns Object containing NFT mint address and token account
 */ async function mintCollectionNFT(agent, collectionMint, metadata, recipient) {
    throw new Error("Not implemented");
// try {
//   // Create UMI instance from agent
//   const umi = createUmi(agent.connection.rpcEndpoint).use(mplCore());
//   umi.use(keypairIdentity(fromWeb3JsKeypair(agent.wallet)));
//   // Convert collection mint to UMI format
//   const umiCollectionMint = fromWeb3JsPublicKey(collectionMint);
//   // Fetch the existing collection
//   const collection = await fetchCollection(umi, umiCollectionMint);
//   // Generate a new signer for the NFT
//   const assetSigner = generateSigner(umi);
//   // Create the NFT in the collection
//   await create(umi, {
//     asset: assetSigner,
//     collection: collection,
//     name: metadata.name,
//     uri: metadata.uri,
//     owner: fromWeb3JsPublicKey(recipient ?? agent.wallet.publicKey),
//   }).sendAndConfirm(umi);
//   return {
//     mint: toWeb3JsPublicKey(assetSigner.publicKey),
//     // Note: Token account is now handled automatically by the create instruction
//     metadata: toWeb3JsPublicKey(assetSigner.publicKey),
//   };
// } catch (error: any) {
//   throw new Error(`Collection NFT minting failed: ${error.message}`);
// }
} //# sourceMappingURL=mint_nft.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/metaplex/deploy_token.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.deploy_token = deploy_token;
/**
 * Deploy a new SPL token
 * @param agent SolanaAgentKit instance
 * @param name Name of the token
 * @param uri URI for the token metadata
 * @param symbol Symbol of the token
 * @param decimals Number of decimals for the token (default: 9)
 * @param initialSupply Initial supply to mint (optional)
 * @returns Object containing token mint address and initial account (if supply was minted)
 */ async function deploy_token(agent, name, uri, symbol, decimals = 9, initialSupply) {
    throw new Error("Not implemented");
// try {
//   // Create UMI instance from agent
//   const umi = createUmi(agent.connection.rpcEndpoint).use(mplToolbox());
//   umi.use(keypairIdentity(fromWeb3JsKeypair(agent.wallet)));
//   // Create new token mint
//   const mint = generateSigner(umi);
//   let builder = createFungible(umi, {
//     name,
//     uri,
//     symbol,
//     sellerFeeBasisPoints: {
//       basisPoints: 0n,
//       identifier: "%",
//       decimals: 2,
//     },
//     decimals,
//     mint,
//   });
//   if (initialSupply) {
//     builder = builder.add(
//       mintV1(umi, {
//         mint: mint.publicKey,
//         tokenStandard: TokenStandard.Fungible,
//         tokenOwner: fromWeb3JsPublicKey(agent.wallet_address),
//         amount: initialSupply * Math.pow(10, decimals),
//       }),
//     );
//   }
//   builder.sendAndConfirm(umi, { confirm: { commitment: "finalized" } });
//   return {
//     mint: toWeb3JsPublicKey(mint.publicKey),
//   };
// } catch (error: any) {
//   throw new Error(`Token deployment failed: ${error.message}`);
// }
} //# sourceMappingURL=deploy_token.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/metaplex/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/metaplex/deploy_collection.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/metaplex/mint_nft.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/metaplex/deploy_token.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/openbook/openbook_create_market.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.openbookCreateMarket = openbookCreateMarket;
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const raydium_sdk_v2_1 = __turbopack_require__("[project]/node_modules/.pnpm/@raydium-io+raydium-sdk-v2@0.1.95-alpha_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttexte_nzw4x65j67xheihs4ylzii5y6u/node_modules/@raydium-io/raydium-sdk-v2/lib/index.mjs [app-route] (ecmascript)");
async function openbookCreateMarket(agent, baseMint, quoteMint, lotSize = 1, tickSize = 0.01) {
    const raydium = await raydium_sdk_v2_1.Raydium.load({
        owner: agent.wallet.publicKey,
        connection: agent.connection
    });
    const baseMintInfo = await agent.connection.getAccountInfo(baseMint);
    const quoteMintInfo = await agent.connection.getAccountInfo(quoteMint);
    if (baseMintInfo?.owner.toString() !== spl_token_1.TOKEN_PROGRAM_ID.toBase58() || quoteMintInfo?.owner.toString() !== spl_token_1.TOKEN_PROGRAM_ID.toBase58()) {
        throw new Error("openbook market only support TOKEN_PROGRAM_ID mints, if you want to create pool with token-2022, please create raydium cpmm pool instead");
    }
    const { execute } = await raydium.marketV2.create({
        baseInfo: {
            mint: baseMint,
            decimals: spl_token_1.MintLayout.decode(baseMintInfo.data).decimals
        },
        quoteInfo: {
            mint: quoteMint,
            decimals: spl_token_1.MintLayout.decode(quoteMintInfo.data).decimals
        },
        lotSize,
        tickSize,
        dexProgramId: raydium_sdk_v2_1.OPEN_BOOK_PROGRAM,
        txVersion: raydium_sdk_v2_1.TxVersion.V0
    });
    const { txIds } = await execute({
        sequentially: true
    });
    return txIds;
} //# sourceMappingURL=openbook_create_market.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/openbook/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/openbook/openbook_create_market.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/orca_close_position.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.orcaClosePosition = orcaClosePosition;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const whirlpools_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const send_tx_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/send_tx.js [app-route] (ecmascript)");
/**
 * # Closes a Liquidity Position in an Orca Whirlpool
 *
 * This function closes an existing liquidity position in a specified Orca Whirlpool. The user provides
 * the position's mint address.
 *
 * ## Parameters
 * - `agent`: The `SolanaAgentKit` instance representing the wallet and connection details.
 * - `positionMintAddress`: The mint address of the liquidity position to close.
 *
 * ## Returns
 * A `Promise` that resolves to a `string` containing the transaction ID of the transaction
 *
 * ## Notes
 * - The function uses Orca’s SDK to interact with the specified Whirlpool and close the liquidity position.
 * - A maximum slippage of 1% is assumed for liquidity provision during the position closing.
 * - The function automatically fetches the associated Whirlpool address and position details using the provided mint address.
 *
 * ## Throws
 * An error will be thrown if:
 * - The specified position mint address is invalid or inaccessible.
 * - The transaction fails to send.
 * - Any required position or Whirlpool data cannot be fetched.
 *
 * @param agent - The `SolanaAgentKit` instance representing the wallet and connection.
 * @param positionMintAddress - The mint address of the liquidity position to close.
 * @returns A promise resolving to the transaction ID (`string`).
 */ async function orcaClosePosition(agent, positionMintAddress) {
    try {
        const wallet = agent.getAnchorWallet();
        const ctx = whirlpools_sdk_1.WhirlpoolContext.from(agent.connection, wallet, whirlpools_sdk_1.ORCA_WHIRLPOOL_PROGRAM_ID);
        const client = (0, whirlpools_sdk_1.buildWhirlpoolClient)(ctx);
        const positionAddress = whirlpools_sdk_1.PDAUtil.getPosition(whirlpools_sdk_1.ORCA_WHIRLPOOL_PROGRAM_ID, positionMintAddress);
        const position = await client.getPosition(positionAddress.publicKey);
        const whirlpoolAddress = position.getData().whirlpool;
        const whirlpool = await client.getPool(whirlpoolAddress);
        const txBuilder = await whirlpool.closePosition(positionAddress.publicKey, common_sdk_1.Percentage.fromFraction(1, 100));
        const txPayload = await txBuilder[0].build();
        const txPayloadDecompiled = web3_js_1.TransactionMessage.decompile(txPayload.transaction.message);
        const instructions = txPayloadDecompiled.instructions;
        const signers = txPayload.signers;
        const txId = await (0, send_tx_1.sendTx)(agent, instructions, signers);
        return txId;
    } catch (error) {
        throw new Error(`${error}`);
    }
} //# sourceMappingURL=orca_close_position.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/orca_create_single_sided_liquidity_pool.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.FEE_TIERS = void 0;
exports.orcaCreateSingleSidedLiquidityPool = orcaCreateSingleSidedLiquidityPool;
const whirlpools_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const instructions_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/instructions/index.js [app-route] (ecmascript)");
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const decimal_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)");
const send_tx_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/send_tx.js [app-route] (ecmascript)");
/**
 * Maps fee tier bps to their corresponding tick spacing values in the Orca Whirlpool protocol.
 *
 * @remarks
 * Fee tiers determine the percentage of fees collected on swaps, while tick spacing affects
 * the granularity of price ranges for liquidity positions.
 *
 * For more details, refer to:
 * - [Whirlpool Fees](https://orca-so.github.io/whirlpools/Architecture%20Overview/Whirlpool%20Fees)
 * - [Whirlpool Parameters](https://orca-so.github.io/whirlpools/Architecture%20Overview/Whirlpool%20Parameters)
 *
 * @example
 * const tickSpacing = FEE_TIERS[1]; // returns 1
 */ exports.FEE_TIERS = {
    1: 1,
    2: 2,
    4: 4,
    5: 8,
    16: 16,
    30: 64,
    65: 96,
    100: 128,
    200: 256
};
/**
 * # Creates a single-sided liquidity pool.
 *
 * This function initializes a new Whirlpool (liquidity pool) on Orca and seeds it with liquidity from a single token.
 *
 * ## Example Usage:
 * You created a new token called SHARK, and you want to set the initial price to 0.001 USDC.
 * You set `depositTokenMint` to SHARK's mint address and `otherTokenMint` to USDC's mint address.
 * You can minimize price impact for buyers in a few ways:
 * 1. Increase the amount of tokens you deposit
 * 2. Set the initial price very low
 * 3. Set the maximum price closer to the initial price
 *
 * ### Note for experts:
 * The Wrhirlpool program initializes the Whirlpool with the in a specific order. This might not be
 * the order you expect, so the function checks the order and adjusts the inverts the prices. This means that
 * on-chain the Whirlpool might be configured as USDC/SHARK instead of SHARK/USDC, and the on-chain price will
 * be 1/`initialPrice`. This will not affect the price of the token as you intended it to be.
 *
 * @param agent - The `SolanaAgentKit` instance representing the wallet and connection details.
 * @param depositTokenAmount - The amount of the deposit token to deposit in the pool.
 * @param depositTokenMint - The mint address of the token being deposited into the pool, eg. SHARK.
 * @param otherTokenMint - The mint address of the other token in the pool, eg. USDC.
 * @param initialPrice - The initial price of the deposit token in terms of the other token.
 * @param maxPrice - The maximum price at which liquidity is added.
 * @param feeTier - The fee tier bps for the pool, determining tick spacing and fee collection rates.
 *
 * @returns A promise that resolves to a transaction ID (`string`) of the transaction creating the pool.
 *
 * @throws Will throw an error if:
 * - Mint accounts for the tokens cannot be fetched.
 * - Prices are out of bounds.
 *
 * @remarks
 * This function is designed for single-sided deposits where users only contribute one type of token,
 * and the function manages mint order and necessary calculations.
 */ async function orcaCreateSingleSidedLiquidityPool(agent, depositTokenAmount, depositTokenMint, otherTokenMint, initialPrice, maxPrice, feeTierBps) {
    try {
        let whirlpoolsConfigAddress;
        if (agent.connection.rpcEndpoint.includes("mainnet")) {
            whirlpoolsConfigAddress = new web3_js_1.PublicKey("2LecshUwdy9xi7meFgHtFJQNSKk4KdTrcpvaB56dP2NQ");
        } else if (agent.connection.rpcEndpoint.includes("devnet")) {
            whirlpoolsConfigAddress = new web3_js_1.PublicKey("FcrweFY1G9HJAHG5inkGB6pKg1HZ6x9UC2WioAfWrGkR");
        } else {
            throw new Error("Unsupported network");
        }
        const wallet = agent.getAnchorWallet();
        const ctx = whirlpools_sdk_1.WhirlpoolContext.from(agent.connection, wallet, whirlpools_sdk_1.ORCA_WHIRLPOOL_PROGRAM_ID);
        const fetcher = ctx.fetcher;
        const correctTokenOrder = whirlpools_sdk_1.PoolUtil.orderMints(otherTokenMint, depositTokenMint).map((addr)=>addr.toString());
        const isCorrectMintOrder = correctTokenOrder[0] === depositTokenMint.toString();
        let mintA, mintB;
        if (isCorrectMintOrder) {
            [mintA, mintB] = [
                depositTokenMint,
                otherTokenMint
            ];
        } else {
            [mintA, mintB] = [
                otherTokenMint,
                depositTokenMint
            ];
            initialPrice = new decimal_js_1.Decimal(1 / initialPrice.toNumber());
            maxPrice = new decimal_js_1.Decimal(1 / maxPrice.toNumber());
        }
        const mintAAccount = await fetcher.getMintInfo(mintA);
        const mintBAccount = await fetcher.getMintInfo(mintB);
        if (mintAAccount === null || mintBAccount === null) {
            throw Error("Mint account not found");
        }
        const tickSpacing = exports.FEE_TIERS[feeTierBps];
        const tickIndex = whirlpools_sdk_1.PriceMath.priceToTickIndex(initialPrice, mintAAccount.decimals, mintBAccount.decimals);
        const initialTick = whirlpools_sdk_1.TickUtil.getInitializableTickIndex(tickIndex, tickSpacing);
        const tokenExtensionCtx = {
            ...whirlpools_sdk_1.NO_TOKEN_EXTENSION_CONTEXT,
            tokenMintWithProgramA: mintAAccount,
            tokenMintWithProgramB: mintBAccount
        };
        const feeTierKey = whirlpools_sdk_1.PDAUtil.getFeeTier(whirlpools_sdk_1.ORCA_WHIRLPOOL_PROGRAM_ID, whirlpoolsConfigAddress, tickSpacing).publicKey;
        const initSqrtPrice = whirlpools_sdk_1.PriceMath.tickIndexToSqrtPriceX64(initialTick);
        const tokenVaultAKeypair = web3_js_1.Keypair.generate();
        const tokenVaultBKeypair = web3_js_1.Keypair.generate();
        const whirlpoolPda = whirlpools_sdk_1.PDAUtil.getWhirlpool(whirlpools_sdk_1.ORCA_WHIRLPOOL_PROGRAM_ID, whirlpoolsConfigAddress, mintA, mintB, exports.FEE_TIERS[feeTierBps]);
        const tokenBadgeA = whirlpools_sdk_1.PDAUtil.getTokenBadge(whirlpools_sdk_1.ORCA_WHIRLPOOL_PROGRAM_ID, whirlpoolsConfigAddress, mintA).publicKey;
        const tokenBadgeB = whirlpools_sdk_1.PDAUtil.getTokenBadge(whirlpools_sdk_1.ORCA_WHIRLPOOL_PROGRAM_ID, whirlpoolsConfigAddress, mintB).publicKey;
        const baseParamsPool = {
            initSqrtPrice,
            whirlpoolsConfig: whirlpoolsConfigAddress,
            whirlpoolPda,
            tokenMintA: mintA,
            tokenMintB: mintB,
            tokenVaultAKeypair,
            tokenVaultBKeypair,
            feeTierKey,
            tickSpacing: tickSpacing,
            funder: wallet.publicKey
        };
        const initPoolIx = !whirlpools_sdk_1.TokenExtensionUtil.isV2IxRequiredPool(tokenExtensionCtx) ? whirlpools_sdk_1.WhirlpoolIx.initializePoolIx(ctx.program, baseParamsPool) : whirlpools_sdk_1.WhirlpoolIx.initializePoolV2Ix(ctx.program, {
            ...baseParamsPool,
            tokenProgramA: tokenExtensionCtx.tokenMintWithProgramA.tokenProgram,
            tokenProgramB: tokenExtensionCtx.tokenMintWithProgramB.tokenProgram,
            tokenBadgeA,
            tokenBadgeB
        });
        const initialTickArrayStartTick = whirlpools_sdk_1.TickUtil.getStartTickIndex(initialTick, tickSpacing);
        const initialTickArrayPda = whirlpools_sdk_1.PDAUtil.getTickArray(ctx.program.programId, whirlpoolPda.publicKey, initialTickArrayStartTick);
        const txBuilder = new common_sdk_1.TransactionBuilder(ctx.provider.connection, ctx.provider.wallet, ctx.txBuilderOpts);
        txBuilder.addInstruction(initPoolIx);
        txBuilder.addInstruction((0, instructions_1.initTickArrayIx)(ctx.program, {
            startTick: initialTickArrayStartTick,
            tickArrayPda: initialTickArrayPda,
            whirlpool: whirlpoolPda.publicKey,
            funder: wallet.publicKey
        }));
        let tickLowerIndex, tickUpperIndex;
        if (isCorrectMintOrder) {
            tickLowerIndex = initialTick;
            tickUpperIndex = whirlpools_sdk_1.PriceMath.priceToTickIndex(maxPrice, mintAAccount.decimals, mintBAccount.decimals);
        } else {
            tickLowerIndex = whirlpools_sdk_1.PriceMath.priceToTickIndex(maxPrice, mintAAccount.decimals, mintBAccount.decimals);
            tickUpperIndex = initialTick;
        }
        const tickLowerInitializableIndex = whirlpools_sdk_1.TickUtil.getInitializableTickIndex(tickLowerIndex, tickSpacing);
        const tickUpperInitializableIndex = whirlpools_sdk_1.TickUtil.getInitializableTickIndex(tickUpperIndex, tickSpacing);
        if (!whirlpools_sdk_1.TickUtil.checkTickInBounds(tickLowerInitializableIndex) || !whirlpools_sdk_1.TickUtil.checkTickInBounds(tickUpperInitializableIndex)) {
            throw Error("Prices out of bounds");
        }
        depositTokenAmount = isCorrectMintOrder ? depositTokenAmount * Math.pow(10, mintAAccount.decimals) : depositTokenAmount * Math.pow(10, mintBAccount.decimals);
        const increasLiquidityQuoteParam = {
            inputTokenAmount: new anchor_1.BN(depositTokenAmount),
            inputTokenMint: depositTokenMint,
            tokenMintA: mintA,
            tokenMintB: mintB,
            tickCurrentIndex: initialTick,
            sqrtPrice: initSqrtPrice,
            tickLowerIndex: tickLowerInitializableIndex,
            tickUpperIndex: tickUpperInitializableIndex,
            tokenExtensionCtx: tokenExtensionCtx,
            slippageTolerance: common_sdk_1.Percentage.fromFraction(0, 100)
        };
        const liquidityInput = (0, whirlpools_sdk_1.increaseLiquidityQuoteByInputTokenWithParams)(increasLiquidityQuoteParam);
        const { liquidityAmount: liquidity, tokenMaxA, tokenMaxB } = liquidityInput;
        const positionMintKeypair = web3_js_1.Keypair.generate();
        const positionMintPubkey = positionMintKeypair.publicKey;
        const positionPda = whirlpools_sdk_1.PDAUtil.getPosition(whirlpools_sdk_1.ORCA_WHIRLPOOL_PROGRAM_ID, positionMintPubkey);
        const positionTokenAccountAddress = (0, spl_token_1.getAssociatedTokenAddressSync)(positionMintPubkey, wallet.publicKey, ctx.accountResolverOpts.allowPDAOwnerAddress, spl_token_1.TOKEN_2022_PROGRAM_ID);
        const params = {
            funder: wallet.publicKey,
            owner: wallet.publicKey,
            positionPda,
            positionTokenAccount: positionTokenAccountAddress,
            whirlpool: whirlpoolPda.publicKey,
            tickLowerIndex: tickLowerInitializableIndex,
            tickUpperIndex: tickUpperInitializableIndex
        };
        const positionIx = (0, instructions_1.openPositionWithTokenExtensionsIx)(ctx.program, {
            ...params,
            positionMint: positionMintPubkey,
            withTokenMetadataExtension: true
        });
        txBuilder.addInstruction(positionIx);
        txBuilder.addSigner(positionMintKeypair);
        const [ataA, ataB] = await (0, common_sdk_1.resolveOrCreateATAs)(ctx.connection, wallet.publicKey, [
            {
                tokenMint: mintA,
                wrappedSolAmountIn: tokenMaxA
            },
            {
                tokenMint: mintB,
                wrappedSolAmountIn: tokenMaxB
            }
        ], ()=>ctx.fetcher.getAccountRentExempt(), wallet.publicKey, undefined, ctx.accountResolverOpts.allowPDAOwnerAddress, "ata");
        const { address: tokenOwnerAccountA, ...tokenOwnerAccountAIx } = ataA;
        const { address: tokenOwnerAccountB, ...tokenOwnerAccountBIx } = ataB;
        txBuilder.addInstruction(tokenOwnerAccountAIx);
        txBuilder.addInstruction(tokenOwnerAccountBIx);
        const tickArrayLowerStartIndex = whirlpools_sdk_1.TickUtil.getStartTickIndex(tickLowerInitializableIndex, tickSpacing);
        const tickArrayUpperStartIndex = whirlpools_sdk_1.TickUtil.getStartTickIndex(tickUpperInitializableIndex, tickSpacing);
        const tickArrayLowerPda = whirlpools_sdk_1.PDAUtil.getTickArray(ctx.program.programId, whirlpoolPda.publicKey, tickArrayLowerStartIndex);
        const tickArrayUpperPda = whirlpools_sdk_1.PDAUtil.getTickArray(ctx.program.programId, whirlpoolPda.publicKey, tickArrayUpperStartIndex);
        if (tickArrayUpperStartIndex !== tickArrayLowerStartIndex) {
            if (isCorrectMintOrder) {
                txBuilder.addInstruction((0, instructions_1.initTickArrayIx)(ctx.program, {
                    startTick: tickArrayUpperStartIndex,
                    tickArrayPda: tickArrayUpperPda,
                    whirlpool: whirlpoolPda.publicKey,
                    funder: wallet.publicKey
                }));
            } else {
                txBuilder.addInstruction((0, instructions_1.initTickArrayIx)(ctx.program, {
                    startTick: tickArrayLowerStartIndex,
                    tickArrayPda: tickArrayLowerPda,
                    whirlpool: whirlpoolPda.publicKey,
                    funder: wallet.publicKey
                }));
            }
        }
        const baseParamsLiquidity = {
            liquidityAmount: liquidity,
            tokenMaxA,
            tokenMaxB,
            whirlpool: whirlpoolPda.publicKey,
            positionAuthority: wallet.publicKey,
            position: positionPda.publicKey,
            positionTokenAccount: positionTokenAccountAddress,
            tokenOwnerAccountA,
            tokenOwnerAccountB,
            tokenVaultA: tokenVaultAKeypair.publicKey,
            tokenVaultB: tokenVaultBKeypair.publicKey,
            tickArrayLower: tickArrayLowerPda.publicKey,
            tickArrayUpper: tickArrayUpperPda.publicKey
        };
        const liquidityIx = !whirlpools_sdk_1.TokenExtensionUtil.isV2IxRequiredPool(tokenExtensionCtx) ? (0, instructions_1.increaseLiquidityIx)(ctx.program, baseParamsLiquidity) : (0, instructions_1.increaseLiquidityV2Ix)(ctx.program, {
            ...baseParamsLiquidity,
            tokenMintA: mintA,
            tokenMintB: mintB,
            tokenProgramA: tokenExtensionCtx.tokenMintWithProgramA.tokenProgram,
            tokenProgramB: tokenExtensionCtx.tokenMintWithProgramB.tokenProgram
        });
        txBuilder.addInstruction(liquidityIx);
        const txPayload = await txBuilder.build();
        const instructions = web3_js_1.TransactionMessage.decompile(txPayload.transaction.message).instructions;
        const txId = await (0, send_tx_1.sendTx)(agent, instructions, [
            positionMintKeypair,
            tokenVaultAKeypair,
            tokenVaultBKeypair
        ]);
        return txId;
    } catch (error) {
        throw new Error(`Failed to send transaction: ${JSON.stringify(error)}`);
    }
} //# sourceMappingURL=orca_create_single_sided_liquidity_pool.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/orca_create_clmm.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.orcaCreateCLMM = orcaCreateCLMM;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const whirlpools_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const decimal_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)");
const orca_create_single_sided_liquidity_pool_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/orca_create_single_sided_liquidity_pool.js [app-route] (ecmascript)");
const send_tx_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/send_tx.js [app-route] (ecmascript)");
/**
 * # Creates a CLMM Pool (Concentrated Liquidity Market Maker Pool).
 *
 * This function initializes a new Whirlpool (CLMM Pool) on Orca. It only sets up the pool and does not seed it with liquidity.
 *
 * ## Example Usage:
 * Suppose you want to create a CLMM pool with two tokens, SHARK and USDC, and set the initial price of SHARK to 0.001 USDC.
 * You would call this function with `mintA` as SHARK's mint address and `mintB` as USDC's mint address. The pool is created
 * with the specified fee tier and tick spacing associated with that fee tier.
 *
 * ### Note for Experts:
 * The Whirlpool program determines the token mint order, which might not match your expectation. This function
 * adjusts the input order as needed and inverts the initial price accordingly.
 *
 * @param agent - The `SolanaAgentKit` instance representing the wallet and connection details.
 * @param mintDeploy - The mint of the token you want to deploy (e.g., SHARK).
 * @param mintPair - The mint of the token you want to pair the deployed mint with (e.g., USDC).
 * @param initialPrice - The initial price of `mintDeploy` in terms of `mintPair`.
 * @param feeTier - The fee tier bps for the pool, determining tick spacing and fee collection rates.
 *
 * @returns A promise that resolves to a transaction ID (`string`) of the transaction creating the pool.
 *
 * @throws Will throw an error if:
 * - Mint accounts for the tokens cannot be fetched.
 * - The network is unsupported.
 *
 * @remarks
 * This function only initializes the CLMM pool and does not add liquidity. For adding liquidity, you can use
 * a separate function after the pool is successfully created.
 * ```
 */ async function orcaCreateCLMM(agent, mintDeploy, mintPair, initialPrice, feeTier) {
    try {
        let whirlpoolsConfigAddress;
        if (agent.connection.rpcEndpoint.includes("mainnet")) {
            whirlpoolsConfigAddress = new web3_js_1.PublicKey("2LecshUwdy9xi7meFgHtFJQNSKk4KdTrcpvaB56dP2NQ");
        } else if (agent.connection.rpcEndpoint.includes("devnet")) {
            whirlpoolsConfigAddress = new web3_js_1.PublicKey("FcrweFY1G9HJAHG5inkGB6pKg1HZ6x9UC2WioAfWrGkR");
        } else {
            throw new Error("Unsupported network");
        }
        const wallet = agent.getAnchorWallet();
        const ctx = whirlpools_sdk_1.WhirlpoolContext.from(agent.connection, wallet, whirlpools_sdk_1.ORCA_WHIRLPOOL_PROGRAM_ID);
        const fetcher = ctx.fetcher;
        const client = (0, whirlpools_sdk_1.buildWhirlpoolClient)(ctx);
        const correctTokenOrder = whirlpools_sdk_1.PoolUtil.orderMints(mintDeploy, mintPair).map((addr)=>addr.toString());
        const isCorrectMintOrder = correctTokenOrder[0] === mintDeploy.toString();
        let mintA;
        let mintB;
        if (!isCorrectMintOrder) {
            [mintA, mintB] = [
                mintPair,
                mintDeploy
            ];
            initialPrice = new decimal_js_1.Decimal(1 / initialPrice.toNumber());
        } else {
            [mintA, mintB] = [
                mintDeploy,
                mintPair
            ];
        }
        const mintAAccount = await fetcher.getMintInfo(mintA);
        const mintBAccount = await fetcher.getMintInfo(mintB);
        if (mintAAccount === null || mintBAccount === null) {
            throw Error("Mint account not found");
        }
        const tickSpacing = orca_create_single_sided_liquidity_pool_1.FEE_TIERS[feeTier];
        const initialTick = whirlpools_sdk_1.PriceMath.priceToInitializableTickIndex(initialPrice, mintAAccount.decimals, mintBAccount.decimals, tickSpacing);
        const { poolKey, tx: txBuilder } = await client.createPool(whirlpoolsConfigAddress, mintA, mintB, tickSpacing, initialTick, wallet.publicKey);
        const txPayload = await txBuilder.build();
        const txPayloadDecompiled = web3_js_1.TransactionMessage.decompile(txPayload.transaction.message);
        const instructions = txPayloadDecompiled.instructions;
        const txId = await (0, send_tx_1.sendTx)(agent, instructions, txPayload.signers);
        return JSON.stringify({
            transactionId: txId,
            whirlpoolAddress: poolKey.toString()
        });
    } catch (error) {
        throw new Error(`${error}`);
    }
} //# sourceMappingURL=orca_create_clmm.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/orca_fetch_positions.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.orcaFetchPositions = orcaFetchPositions;
const whirlpools_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
/**
 * # Fetches Liquidity Position Data in Orca Whirlpools
 *
 * Fetches data for all liquidity positions owned by the provided wallet, including:
 * - Whirlpool address.
 * - Whether the position is in range.
 * - Distance from the center price to the current price in basis points.
 *
 * ## Parameters
 * - `agent`: The `SolanaAgentKit` instance representing the wallet and connection.
 *
 * ## Returns
 * A JSON string with an object mapping position mint addresses to position details:
 * ```json
 * {
 *   "positionMintAddress1": {
 *     "whirlpoolAddress": "whirlpoolAddress1",
 *     "positionInRange": true,
 *     "distanceFromCenterBps": 250
 *   }
 * }
 * ```
 *
 * ## Throws
 * - If positions cannot be fetched or processed.
 * - If the position mint address is invalid.
 *
 * @param agent - The `SolanaAgentKit` instance.
 * @returns A JSON string with position data.
 */ async function orcaFetchPositions(agent) {
    try {
        const wallet = agent.getAnchorWallet();
        const ctx = whirlpools_sdk_1.WhirlpoolContext.from(agent.connection, wallet, whirlpools_sdk_1.ORCA_WHIRLPOOL_PROGRAM_ID);
        const client = (0, whirlpools_sdk_1.buildWhirlpoolClient)(ctx);
        const positions = await (0, whirlpools_sdk_1.getAllPositionAccountsByOwner)({
            ctx,
            owner: agent.wallet.publicKey
        });
        const positionDatas = [
            ...positions.positions.entries(),
            ...positions.positionsWithTokenExtensions.entries()
        ];
        const result = {};
        for (const [, positionData] of positionDatas){
            const positionMintAddress = positionData.positionMint;
            const whirlpoolAddress = positionData.whirlpool;
            const whirlpool = await client.getPool(whirlpoolAddress);
            const whirlpoolData = whirlpool.getData();
            const sqrtPrice = whirlpoolData.sqrtPrice;
            const currentTick = whirlpoolData.tickCurrentIndex;
            const mintA = whirlpool.getTokenAInfo();
            const mintB = whirlpool.getTokenBInfo();
            const currentPrice = whirlpools_sdk_1.PriceMath.sqrtPriceX64ToPrice(sqrtPrice, mintA.decimals, mintB.decimals);
            const lowerTick = positionData.tickLowerIndex;
            const upperTick = positionData.tickUpperIndex;
            const lowerPrice = whirlpools_sdk_1.PriceMath.tickIndexToPrice(lowerTick, mintA.decimals, mintB.decimals);
            const upperPrice = whirlpools_sdk_1.PriceMath.tickIndexToPrice(upperTick, mintA.decimals, mintB.decimals);
            const centerPosition = lowerPrice.add(upperPrice).div(2);
            const positionInRange = currentTick > lowerTick && currentTick < upperTick ? true : false;
            const distanceFromCenterBps = Math.ceil(currentPrice.sub(centerPosition).abs().div(centerPosition).mul(10000).toNumber());
            result[positionMintAddress.toString()] = {
                whirlpoolAddress: whirlpoolAddress.toString(),
                positionInRange,
                distanceFromCenterBps
            };
        }
        return JSON.stringify(result);
    } catch (error) {
        throw new Error(`${error}`);
    }
} //# sourceMappingURL=orca_fetch_positions.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/orca_open_centered_position_with_liquidity.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.orcaOpenCenteredPositionWithLiquidity = orcaOpenCenteredPositionWithLiquidity;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const whirlpools_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const send_tx_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/send_tx.js [app-route] (ecmascript)");
/**
 * # Opens a Centered Liquidity Position in an Orca Whirlpool
 *
 * This function opens a centered liquidity position in a specified Orca Whirlpool. The user defines
 * a basis point (bps) offset from the current price of the pool to set the lower and upper bounds of the position.
 * The user also specifies the token mint and the amount to deposit. The required amount of the other token
 * is calculated automatically.
 *
 * ## Parameters
 * - `agent`: The `SolanaAgentKit` instance representing the wallet and connection details.
 * - `whirlpoolAddress`: The address of the Orca Whirlpool where the position will be opened.
 * - `priceOffsetBps`: The basis point (bps) offset (on one side) from the current price fo the pool. For example,
 *   500 bps (5%) creates a range from 95% to 105% of the current pool price.
 * - `inputTokenMint`: The mint address of the token being deposited (e.g., USDC or another token).
 * - `inputAmount`: The amount of the input token to deposit, specified as a `Decimal` value.
 *
 * ## Returns
 * A `Promise` that resolves to the transaction ID (`string`) of the transaction that opens the position.
 *
 * ## Notes
 * - The `priceOffsetBps` specifies the range symmetrically around the current price.
 * - The specified `inputTokenMint` determines which token is deposited directly. The function calculates
 *   the required amount of the other token based on the specified price range.
 * - This function supports Orca's token extensions for managing tokens with special behaviors.
 * - The function assumes a maximum slippage of 1% for liquidity provision.
 *
 * ## Throws
 * An error will be thrown if:
 * - The specified Whirlpool address is invalid or inaccessible.
 * - The transaction fails to send.
 * - Any required mint information cannot be fetched.
 *
 * @param agent - The `SolanaAgentKit` instance representing the wallet and connection.
 * @param whirlpoolAddress - The address of the Orca Whirlpool.
 * @param priceOffsetBps - The basis point offset (one side) from the current pool price.
 * @param inputTokenMint - The mint address of the token to deposit.
 * @param inputAmount - The amount of the input token to deposit.
 * @returns A promise resolving to the transaction ID (`string`).
 */ async function orcaOpenCenteredPositionWithLiquidity(agent, whirlpoolAddress, priceOffsetBps, inputTokenMint, inputAmount) {
    try {
        const wallet = agent.getAnchorWallet();
        const ctx = whirlpools_sdk_1.WhirlpoolContext.from(agent.connection, wallet, whirlpools_sdk_1.ORCA_WHIRLPOOL_PROGRAM_ID);
        const client = (0, whirlpools_sdk_1.buildWhirlpoolClient)(ctx);
        const whirlpool = await client.getPool(whirlpoolAddress);
        const whirlpoolData = whirlpool.getData();
        const mintInfoA = whirlpool.getTokenAInfo();
        const mintInfoB = whirlpool.getTokenBInfo();
        const price = whirlpools_sdk_1.PriceMath.sqrtPriceX64ToPrice(whirlpoolData.sqrtPrice, mintInfoA.decimals, mintInfoB.decimals);
        const lowerPrice = price.mul(1 - priceOffsetBps / 10000);
        const upperPrice = price.mul(1 + priceOffsetBps / 10000);
        const lowerTick = whirlpools_sdk_1.PriceMath.priceToInitializableTickIndex(lowerPrice, mintInfoA.decimals, mintInfoB.decimals, whirlpoolData.tickSpacing);
        const upperTick = whirlpools_sdk_1.PriceMath.priceToInitializableTickIndex(upperPrice, mintInfoA.decimals, mintInfoB.decimals, whirlpoolData.tickSpacing);
        const txBuilderTickArrays = await whirlpool.initTickArrayForTicks([
            lowerTick,
            upperTick
        ]);
        let instructions = [];
        let signers = [];
        if (txBuilderTickArrays !== null) {
            const txPayloadTickArrays = await txBuilderTickArrays.build();
            const txPayloadTickArraysDecompiled = web3_js_1.TransactionMessage.decompile(txPayloadTickArrays.transaction.message);
            const instructionsTickArrays = txPayloadTickArraysDecompiled.instructions;
            instructions = instructions.concat(instructionsTickArrays);
            signers = signers.concat(txPayloadTickArrays.signers);
        }
        const tokenExtensionCtx = {
            ...whirlpools_sdk_1.NO_TOKEN_EXTENSION_CONTEXT,
            tokenMintWithProgramA: mintInfoA,
            tokenMintWithProgramB: mintInfoB
        };
        const increaseLiquiditQuote = (0, whirlpools_sdk_1.increaseLiquidityQuoteByInputToken)(inputTokenMint, inputAmount, lowerTick, upperTick, common_sdk_1.Percentage.fromFraction(1, 100), whirlpool, tokenExtensionCtx);
        const { positionMint, tx: txBuilder } = await whirlpool.openPositionWithMetadata(lowerTick, upperTick, increaseLiquiditQuote, undefined, undefined, undefined, spl_token_1.TOKEN_2022_PROGRAM_ID);
        const txPayload = await txBuilder.build();
        const txPayloadDecompiled = web3_js_1.TransactionMessage.decompile(txPayload.transaction.message);
        instructions = instructions.concat(txPayloadDecompiled.instructions);
        signers = signers.concat(txPayload.signers);
        const txId = await (0, send_tx_1.sendTx)(agent, instructions, signers);
        return JSON.stringify({
            transactionId: txId,
            positionMint: positionMint.toString()
        });
    } catch (error) {
        throw new Error(`${error}`);
    }
} //# sourceMappingURL=orca_open_centered_position_with_liquidity.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/orca_open_single_sided_position.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.orcaOpenSingleSidedPosition = orcaOpenSingleSidedPosition;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const whirlpools_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+whirlpools-sdk@0.13.13_@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf_ljsdposo56h4j6nxj6azd4gik4/node_modules/@orca-so/whirlpools-sdk/dist/index.js [app-route] (ecmascript)");
const common_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@orca-so+common-sdk@0.6.4_@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_enc_nhlfe2dn76qvf7mvqnn7dx5vge/node_modules/@orca-so/common-sdk/dist/index.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const send_tx_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/send_tx.js [app-route] (ecmascript)");
/**
 * # Opens a Single-Sided Liquidity Position in an Orca Whirlpool
 *
 * This function opens a single-sided liquidity position in a specified Orca Whirlpool. The user specifies
 * a basis point (bps) offset from the current price for the lower bound and a width (bps) for the range width.
 * The required amount of the other token is calculated automatically.
 *
 * ## Parameters
 * - `agent`: The `SolanaAgentKit` instance representing the wallet and connection details.
 * - `whirlpoolAddress`: The address of the Orca Whirlpool where the position will be opened.
 * - `distanceFromCurrentPriceBps`: The basis point offset from the current price for the lower bound.
 * - `widthBps`: The width of the range as a percentage increment from the lower bound.
 * - `inputTokenMint`: The mint address of the token being deposited (e.g., USDC or another token).
 * - `inputAmount`: The amount of the input token to deposit, specified as a `Decimal` value.
 *
 * ## Returns
 * A `Promise` that resolves to the transaction ID (`string`) of the transaction that opens the position.
 *
 * ## Notes
 * - The `distanceFromCurrentPriceBps` specifies the starting point of the range.
 * - The `widthBps` determines the range size from the lower bound.
 * - The specified `inputTokenMint` determines which token is deposited directly.
 *
 * @param agent - The `SolanaAgentKit` instance representing the wallet and connection.
 * @param whirlpoolAddress - The address of the Orca Whirlpool.
 * @param distanceFromCurrentPriceBps - The basis point offset from the current price for the lower bound.
 * @param widthBps - The width of the range as a percentage increment from the lower bound.
 * @param inputTokenMint - The mint address of the token to deposit.
 * @param inputAmount - The amount of the input token to deposit.
 * @returns A promise resolving to the transaction ID (`string`).
 */ async function orcaOpenSingleSidedPosition(agent, whirlpoolAddress, distanceFromCurrentPriceBps, widthBps, inputTokenMint, inputAmount) {
    try {
        const wallet = agent.getAnchorWallet();
        const ctx = whirlpools_sdk_1.WhirlpoolContext.from(agent.connection, wallet, whirlpools_sdk_1.ORCA_WHIRLPOOL_PROGRAM_ID);
        const client = (0, whirlpools_sdk_1.buildWhirlpoolClient)(ctx);
        const whirlpool = await client.getPool(whirlpoolAddress);
        const whirlpoolData = whirlpool.getData();
        const mintInfoA = whirlpool.getTokenAInfo();
        const mintInfoB = whirlpool.getTokenBInfo();
        const price = whirlpools_sdk_1.PriceMath.sqrtPriceX64ToPrice(whirlpoolData.sqrtPrice, mintInfoA.decimals, mintInfoB.decimals);
        const isTokenA = inputTokenMint.equals(mintInfoA.mint);
        let lowerBoundPrice;
        let upperBoundPrice;
        let lowerTick;
        let upperTick;
        if (isTokenA) {
            lowerBoundPrice = price.mul(1 + distanceFromCurrentPriceBps / 10000);
            upperBoundPrice = lowerBoundPrice.mul(1 + widthBps / 10000);
            upperTick = whirlpools_sdk_1.PriceMath.priceToInitializableTickIndex(upperBoundPrice, mintInfoA.decimals, mintInfoB.decimals, whirlpoolData.tickSpacing);
            lowerTick = whirlpools_sdk_1.PriceMath.priceToInitializableTickIndex(lowerBoundPrice, mintInfoA.decimals, mintInfoB.decimals, whirlpoolData.tickSpacing);
        } else {
            lowerBoundPrice = price.mul(1 - distanceFromCurrentPriceBps / 10000);
            upperBoundPrice = lowerBoundPrice.mul(1 - widthBps / 10000);
            lowerTick = whirlpools_sdk_1.PriceMath.priceToInitializableTickIndex(upperBoundPrice, mintInfoA.decimals, mintInfoB.decimals, whirlpoolData.tickSpacing);
            upperTick = whirlpools_sdk_1.PriceMath.priceToInitializableTickIndex(lowerBoundPrice, mintInfoA.decimals, mintInfoB.decimals, whirlpoolData.tickSpacing);
        }
        const txBuilderTickArrays = await whirlpool.initTickArrayForTicks([
            lowerTick,
            upperTick
        ]);
        let instructions = [];
        let signers = [];
        if (txBuilderTickArrays !== null) {
            const txPayloadTickArrays = await txBuilderTickArrays.build();
            const txPayloadTickArraysDecompiled = web3_js_1.TransactionMessage.decompile(txPayloadTickArrays.transaction.message);
            instructions = instructions.concat(txPayloadTickArraysDecompiled.instructions);
            signers = signers.concat(txPayloadTickArrays.signers);
        }
        const tokenExtensionCtx = {
            ...whirlpools_sdk_1.NO_TOKEN_EXTENSION_CONTEXT,
            tokenMintWithProgramA: mintInfoA,
            tokenMintWithProgramB: mintInfoB
        };
        const increaseLiquiditQuote = (0, whirlpools_sdk_1.increaseLiquidityQuoteByInputToken)(inputTokenMint, inputAmount, lowerTick, upperTick, common_sdk_1.Percentage.fromFraction(1, 100), whirlpool, tokenExtensionCtx);
        const { positionMint, tx: txBuilder } = await whirlpool.openPositionWithMetadata(lowerTick, upperTick, increaseLiquiditQuote, undefined, undefined, undefined, spl_token_1.TOKEN_2022_PROGRAM_ID);
        const txPayload = await txBuilder.build();
        const txPayloadDecompiled = web3_js_1.TransactionMessage.decompile(txPayload.transaction.message);
        instructions = instructions.concat(txPayloadDecompiled.instructions);
        signers = signers.concat(txPayload.signers);
        const txId = await (0, send_tx_1.sendTx)(agent, instructions, signers);
        return JSON.stringify({
            transactionIds: txId,
            positionMint: positionMint.toString()
        });
    } catch (error) {
        throw new Error(`${error}`);
    }
} //# sourceMappingURL=orca_open_single_sided_position.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/orca_close_position.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/orca_create_clmm.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/orca_create_single_sided_liquidity_pool.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/orca_fetch_positions.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/orca_open_centered_position_with_liquidity.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/orca_open_single_sided_position.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/pumpfun/launch_pumpfun_token.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.launchPumpFunToken = launchPumpFunToken;
// src/tools/launch_pumpfun_token.ts
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
async function uploadMetadata(tokenName, tokenTicker, description, imageUrl, options) {
    // Create metadata object
    const formData = new URLSearchParams();
    formData.append("name", tokenName);
    formData.append("symbol", tokenTicker);
    formData.append("description", description);
    formData.append("showName", "true");
    if (options?.twitter) {
        formData.append("twitter", options.twitter);
    }
    if (options?.telegram) {
        formData.append("telegram", options.telegram);
    }
    if (options?.website) {
        formData.append("website", options.website);
    }
    const imageResponse = await fetch(imageUrl);
    const imageBlob = await imageResponse.blob();
    const files = {
        file: new File([
            imageBlob
        ], "token_image.png", {
            type: "image/png"
        })
    };
    // Create form data with both metadata and file
    const finalFormData = new FormData();
    // Add all metadata fields
    for (const [key, value] of formData.entries()){
        finalFormData.append(key, value);
    }
    // Add file if exists
    if (files?.file) {
        finalFormData.append("file", files.file);
    }
    const metadataResponse = await fetch("https://pump.fun/api/ipfs", {
        method: "POST",
        body: finalFormData
    });
    if (!metadataResponse.ok) {
        throw new Error(`Metadata upload failed: ${metadataResponse.statusText}`);
    }
    return await metadataResponse.json();
}
async function createTokenTransaction(agent, mintKeypair, metadataResponse, options) {
    const payload = {
        publicKey: agent.wallet_address.toBase58(),
        action: "create",
        tokenMetadata: {
            name: metadataResponse.metadata.name,
            symbol: metadataResponse.metadata.symbol,
            uri: metadataResponse.metadataUri
        },
        mint: mintKeypair.publicKey.toBase58(),
        denominatedInSol: "true",
        amount: options?.initialLiquiditySOL || 0.0001,
        slippage: options?.slippageBps || 5,
        priorityFee: options?.priorityFee || 0.00005,
        pool: "pump"
    };
    const response = await fetch("https://pumpportal.fun/api/trade-local", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
    });
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Transaction creation failed: ${response.status} - ${errorText}`);
    }
    return response;
}
async function signAndSendTransaction(kit, tx, mintKeypair) {
    try {
        // Get the latest blockhash
        const { blockhash, lastValidBlockHeight } = await kit.connection.getLatestBlockhash();
        // Update transaction with latest blockhash
        tx.message.recentBlockhash = blockhash;
        // Sign the transaction
        const signedTx = await kit.wallet.signTransaction(tx);
        signedTx.sign([
            mintKeypair
        ]);
        // Send and confirm transaction with options
        const signature = await kit.connection.sendTransaction(signedTx, {
            skipPreflight: false,
            preflightCommitment: "confirmed",
            maxRetries: 5
        });
        // Wait for confirmation
        const confirmation = await kit.connection.confirmTransaction({
            signature,
            blockhash,
            lastValidBlockHeight
        });
        if (confirmation.value.err) {
            throw new Error(`Transaction failed: ${confirmation.value.err}`);
        }
        return signature;
    } catch (error) {
        console.error("Transaction send error:", error);
        if (error instanceof Error && "logs" in error) {
            console.error("Transaction logs:", error.logs);
        }
        throw error;
    }
}
/**
 * Launch a token on Pump.fun
 * @param agent - SolanaAgentKit instance
 * @param tokenName - Name of the token
 * @param tokenTicker - Ticker of the token
 * @param description - Description of the token
 * @param imageUrl - URL of the token image
 * @param options - Optional token options (twitter, telegram, website, initialLiquiditySOL, slippageBps, priorityFee)
 * @returns - Signature of the transaction, mint address and metadata URI, if successful, else error
 */ async function launchPumpFunToken(agent, tokenName, tokenTicker, description, imageUrl, options) {
    try {
        const mintKeypair = web3_js_1.Keypair.generate();
        const metadataResponse = await uploadMetadata(tokenName, tokenTicker, description, imageUrl, options);
        const response = await createTokenTransaction(agent, mintKeypair, metadataResponse, options);
        const transactionData = await response.arrayBuffer();
        const tx = web3_js_1.VersionedTransaction.deserialize(new Uint8Array(transactionData));
        const signature = await signAndSendTransaction(agent, tx, mintKeypair);
        return {
            signature,
            mint: mintKeypair.publicKey.toBase58(),
            metadataUri: metadataResponse.metadataUri
        };
    } catch (error) {
        console.error("Error in launchpumpfuntoken:", error);
        if (error instanceof Error && "logs" in error) {
            console.error("Transaction logs:", error.logs);
        }
        throw error;
    }
} //# sourceMappingURL=launch_pumpfun_token.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/pumpfun/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/pumpfun/launch_pumpfun_token.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/pyth/pyth_fetch_price.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.fetchPythPriceFeedID = fetchPythPriceFeedID;
exports.fetchPythPrice = fetchPythPrice;
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
/**
 * Fetch the price feed ID for a given token symbol from Pyth
 * @param tokenSymbol Token symbol
 * @returns Price feed ID
 */ async function fetchPythPriceFeedID(tokenSymbol) {
    try {
        const stableHermesServiceUrl = "https://hermes.pyth.network";
        const response = await fetch(`${stableHermesServiceUrl}/v2/price_feeds?query=${tokenSymbol}&asset_type=crypto`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        if (data.length === 0) {
            throw new Error(`No price feed found for ${tokenSymbol}`);
        }
        if (data.length > 1) {
            const filteredData = data.filter((item)=>item.attributes.base.toLowerCase() === tokenSymbol.toLowerCase());
            if (filteredData.length === 0) {
                throw new Error(`No price feed found for ${tokenSymbol}`);
            }
            return filteredData[0].id;
        }
        return data[0].id;
    } catch (error) {
        throw new Error(`Fetching price feed ID from Pyth failed: ${error.message}`);
    }
}
/**
 * Fetch the price of a given price feed from Pyth
 * @param priceFeedID Price feed ID
 * @returns Latest price value from feed
 *
 * You can find priceFeedIDs here: https://www.pyth.network/developers/price-feed-ids#stable
 */ async function fetchPythPrice(feedID) {
    try {
        const stableHermesServiceUrl = "https://hermes.pyth.network";
        const response = await fetch(`${stableHermesServiceUrl}/v2/updates/price/latest?ids[]=${feedID}`);
        const data = await response.json();
        const parsedData = data.parsed;
        if (parsedData.length === 0) {
            throw new Error(`No price data found for ${feedID}`);
        }
        const price = new bn_js_1.default(parsedData[0].price.price);
        const exponent = parsedData[0].price.expo;
        if (exponent < 0) {
            const adjustedPrice = price.mul(new bn_js_1.default(100));
            const divisor = new bn_js_1.default(10).pow(new bn_js_1.default(-exponent));
            const scaledPrice = adjustedPrice.div(divisor);
            const priceStr = scaledPrice.toString();
            const formattedPrice = `${priceStr.slice(0, -2)}.${priceStr.slice(-2)}`;
            return formattedPrice.startsWith(".") ? `0${formattedPrice}` : formattedPrice;
        }
        const scaledPrice = price.div(new bn_js_1.default(10).pow(new bn_js_1.default(exponent)));
        return scaledPrice.toString();
    } catch (error) {
        throw new Error(`Fetching price from Pyth failed: ${error.message}`);
    }
} //# sourceMappingURL=pyth_fetch_price.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/pyth/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/pyth/pyth_fetch_price.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/raydium/raydium_create_ammV4.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.raydiumCreateAmmV4 = raydiumCreateAmmV4;
const raydium_sdk_v2_1 = __turbopack_require__("[project]/node_modules/.pnpm/@raydium-io+raydium-sdk-v2@0.1.95-alpha_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttexte_nzw4x65j67xheihs4ylzii5y6u/node_modules/@raydium-io/raydium-sdk-v2/lib/index.mjs [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
async function raydiumCreateAmmV4(agent, marketId, baseAmount, quoteAmount, startTime) {
    const raydium = await raydium_sdk_v2_1.Raydium.load({
        owner: agent.wallet.publicKey,
        connection: agent.connection
    });
    const marketBufferInfo = await agent.connection.getAccountInfo(new web3_js_1.PublicKey(marketId));
    const { baseMint, quoteMint } = raydium_sdk_v2_1.MARKET_STATE_LAYOUT_V3.decode(marketBufferInfo.data);
    const baseMintInfo = await agent.connection.getAccountInfo(baseMint);
    const quoteMintInfo = await agent.connection.getAccountInfo(quoteMint);
    if (baseMintInfo?.owner.toString() !== spl_token_1.TOKEN_PROGRAM_ID.toBase58() || quoteMintInfo?.owner.toString() !== spl_token_1.TOKEN_PROGRAM_ID.toBase58()) {
        throw new Error("amm pools with openbook market only support TOKEN_PROGRAM_ID mints, if you want to create pool with token-2022, please create cpmm pool instead");
    }
    if (baseAmount.mul(quoteAmount).lte(new bn_js_1.default(1).mul(new bn_js_1.default(10 ** spl_token_1.MintLayout.decode(baseMintInfo.data).decimals)).pow(new bn_js_1.default(2)))) {
        throw new Error("initial liquidity too low, try adding more baseAmount/quoteAmount");
    }
    const { execute } = await raydium.liquidity.createPoolV4({
        programId: raydium_sdk_v2_1.AMM_V4,
        marketInfo: {
            marketId,
            programId: raydium_sdk_v2_1.OPEN_BOOK_PROGRAM
        },
        baseMintInfo: {
            mint: baseMint,
            decimals: spl_token_1.MintLayout.decode(baseMintInfo.data).decimals
        },
        quoteMintInfo: {
            mint: quoteMint,
            decimals: spl_token_1.MintLayout.decode(quoteMintInfo.data).decimals
        },
        baseAmount,
        quoteAmount,
        startTime,
        ownerInfo: {
            useSOLBalance: true
        },
        associatedOnly: false,
        txVersion: raydium_sdk_v2_1.TxVersion.V0,
        feeDestinationId: raydium_sdk_v2_1.FEE_DESTINATION_ID
    });
    const { txId } = await execute({
        sendAndConfirm: true
    });
    return txId;
} //# sourceMappingURL=raydium_create_ammV4.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/raydium/raydium_create_clmm.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.raydiumCreateClmm = raydiumCreateClmm;
const raydium_sdk_v2_1 = __turbopack_require__("[project]/node_modules/.pnpm/@raydium-io+raydium-sdk-v2@0.1.95-alpha_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttexte_nzw4x65j67xheihs4ylzii5y6u/node_modules/@raydium-io/raydium-sdk-v2/lib/index.mjs [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
async function raydiumCreateClmm(agent, mint1, mint2, configId, initialPrice, startTime) {
    const raydium = await raydium_sdk_v2_1.Raydium.load({
        owner: agent.wallet.publicKey,
        connection: agent.connection
    });
    const [mintInfo1, mintInfo2] = await agent.connection.getMultipleAccountsInfo([
        mint1,
        mint2
    ]);
    if (mintInfo1 === null || mintInfo2 === null) {
        throw Error("fetch mint info error");
    }
    const mintDecodeInfo1 = spl_token_1.MintLayout.decode(mintInfo1.data);
    const mintDecodeInfo2 = spl_token_1.MintLayout.decode(mintInfo2.data);
    const mintFormatInfo1 = {
        chainId: 101,
        address: mint1.toString(),
        programId: mintInfo1.owner.toString(),
        logoURI: "",
        symbol: "",
        name: "",
        decimals: mintDecodeInfo1.decimals,
        tags: [],
        extensions: {}
    };
    const mintFormatInfo2 = {
        chainId: 101,
        address: mint2.toString(),
        programId: mintInfo2.owner.toString(),
        logoURI: "",
        symbol: "",
        name: "",
        decimals: mintDecodeInfo2.decimals,
        tags: [],
        extensions: {}
    };
    const { execute } = await raydium.clmm.createPool({
        programId: raydium_sdk_v2_1.CLMM_PROGRAM_ID,
        // programId: DEVNET_PROGRAM_ID.CLMM,
        mint1: mintFormatInfo1,
        mint2: mintFormatInfo2,
        // @ts-expect-error sdk bug
        ammConfig: {
            id: configId
        },
        initialPrice,
        startTime,
        txVersion: raydium_sdk_v2_1.TxVersion.V0
    });
    const { txId } = await execute({
        sendAndConfirm: true
    });
    return txId;
} //# sourceMappingURL=raydium_create_clmm.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/raydium/raydium_create_cpmm.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.raydiumCreateCpmm = raydiumCreateCpmm;
const raydium_sdk_v2_1 = __turbopack_require__("[project]/node_modules/.pnpm/@raydium-io+raydium-sdk-v2@0.1.95-alpha_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttexte_nzw4x65j67xheihs4ylzii5y6u/node_modules/@raydium-io/raydium-sdk-v2/lib/index.mjs [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
async function raydiumCreateCpmm(agent, mintA, mintB, configId, mintAAmount, mintBAmount, startTime) {
    const raydium = await raydium_sdk_v2_1.Raydium.load({
        owner: agent.wallet.publicKey,
        connection: agent.connection
    });
    const [mintInfoA, mintInfoB] = await agent.connection.getMultipleAccountsInfo([
        mintA,
        mintB
    ]);
    if (mintInfoA === null || mintInfoB === null) {
        throw Error("fetch mint info error");
    }
    const mintDecodeInfoA = spl_token_1.MintLayout.decode(mintInfoA.data);
    const mintDecodeInfoB = spl_token_1.MintLayout.decode(mintInfoB.data);
    const mintFormatInfoA = {
        chainId: 101,
        address: mintA.toString(),
        programId: mintInfoA.owner.toString(),
        logoURI: "",
        symbol: "",
        name: "",
        decimals: mintDecodeInfoA.decimals,
        tags: [],
        extensions: {}
    };
    const mintFormatInfoB = {
        chainId: 101,
        address: mintB.toString(),
        programId: mintInfoB.owner.toString(),
        logoURI: "",
        symbol: "",
        name: "",
        decimals: mintDecodeInfoB.decimals,
        tags: [],
        extensions: {}
    };
    const { execute } = await raydium.cpmm.createPool({
        programId: raydium_sdk_v2_1.CREATE_CPMM_POOL_PROGRAM,
        poolFeeAccount: raydium_sdk_v2_1.CREATE_CPMM_POOL_FEE_ACC,
        mintA: mintFormatInfoA,
        mintB: mintFormatInfoB,
        mintAAmount,
        mintBAmount,
        startTime,
        //@ts-expect-error sdk bug
        feeConfig: {
            id: configId.toString()
        },
        associatedOnly: false,
        ownerInfo: {
            useSOLBalance: true
        },
        txVersion: raydium_sdk_v2_1.TxVersion.V0
    });
    const { txId } = await execute({
        sendAndConfirm: true
    });
    return txId;
} //# sourceMappingURL=raydium_create_cpmm.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/raydium/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/raydium/raydium_create_ammV4.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/raydium/raydium_create_clmm.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/raydium/raydium_create_cpmm.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/rugcheck/rugcheck.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.fetchTokenReportSummary = fetchTokenReportSummary;
exports.fetchTokenDetailedReport = fetchTokenDetailedReport;
const BASE_URL = "https://api.rugcheck.xyz/v1";
/**
 * Fetches a summary report for a specific token.
 * @async
 * @param {string} mint - The mint address of the token.
 * @returns {Promise<TokenCheck>} The token summary report.
 * @throws {Error} If the API call fails.
 */ async function fetchTokenReportSummary(mint) {
    try {
        const response = await fetch(`${BASE_URL}/tokens/${mint}/report/summary`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`Error fetching report summary for token ${mint}:`, error.message);
        throw new Error(`Failed to fetch report summary for token ${mint}.`);
    }
}
/**
 * Fetches a detailed report for a specific token.
 * @async
 * @param {string} mint - The mint address of the token.
 * @returns {Promise<TokenCheck>} The detailed token report.
 * @throws {Error} If the API call fails.
 */ async function fetchTokenDetailedReport(mint) {
    try {
        const response = await fetch(`${BASE_URL}/tokens/${mint}/report`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`Error fetching detailed report for token ${mint}:`, error.message);
        throw new Error(`Failed to fetch detailed report for token ${mint}.`);
    }
} //# sourceMappingURL=rugcheck.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/rugcheck/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/rugcheck/rugcheck.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sendarcade/rock_paper_scissor.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.rock_paper_scissor = rock_paper_scissor;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
async function rock_paper_scissor(agent, amount, choice) {
    try {
        const res = await fetch(`https://rps.sendarcade.fun/api/actions/bot?amount=${amount}&choice=${choice}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                account: agent.wallet.publicKey.toBase58()
            })
        });
        const data = await res.json();
        if (data.transaction) {
            const txn = web3_js_1.Transaction.from(Buffer.from(data.transaction, "base64"));
            txn.sign(agent.wallet);
            txn.recentBlockhash = (await agent.connection.getLatestBlockhash()).blockhash;
            const sig = await (0, web3_js_1.sendAndConfirmTransaction)(agent.connection, txn, [
                agent.wallet
            ], {
                commitment: "confirmed"
            });
            const href = data.links?.next?.href;
            return await outcome(agent, sig, href);
        } else {
            return "failed";
        }
    } catch (error) {
        console.error(error);
        throw new Error(`RPS game failed: ${error.message}`);
    }
}
async function outcome(agent, sig, href) {
    try {
        const res = await fetch("https://rps.sendarcade.fun" + href, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                account: agent.wallet.publicKey.toBase58(),
                signature: sig
            })
        });
        const data = await res.json();
        const title = data.title;
        if (title.startsWith("You lost")) {
            return title;
        }
        const next_href = data.links?.actions?.[0]?.href;
        return title + "\n" + await won(agent, next_href);
    } catch (error) {
        console.error(error);
        throw new Error(`RPS outcome failed: ${error.message}`);
    }
}
async function won(agent, href) {
    try {
        const res = await fetch("https://rps.sendarcade.fun" + href, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                account: agent.wallet.publicKey.toBase58()
            })
        });
        const data = await res.json();
        if (data.transaction) {
            const txn = web3_js_1.Transaction.from(Buffer.from(data.transaction, "base64"));
            txn.partialSign(agent.wallet);
            await agent.connection.sendRawTransaction(txn.serialize(), {
                preflightCommitment: "confirmed"
            });
        } else {
            return "Failed to claim prize.";
        }
        const next_href = data.links?.next?.href;
        return await postWin(agent, next_href);
    } catch (error) {
        console.error(error);
        throw new Error(`RPS outcome failed: ${error.message}`);
    }
}
async function postWin(agent, href) {
    try {
        const res = await fetch("https://rps.sendarcade.fun" + href, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                account: agent.wallet.publicKey.toBase58()
            })
        });
        const data = await res.json();
        const title = data.title;
        return "Prize claimed Successfully" + "\n" + title;
    } catch (error) {
        console.error(error);
        throw new Error(`RPS outcome failed: ${error.message}`);
    }
} //# sourceMappingURL=rock_paper_scissor.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sendarcade/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sendarcade/rock_paper_scissor.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solayer/stake_with_solayer.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.stakeWithSolayer = stakeWithSolayer;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
/**
 * Stake SOL with Solayer
 * @param agent SolanaAgentKit instance
 * @param amount Amount of SOL to stake
 * @returns Transaction signature
 */ async function stakeWithSolayer(agent, amount) {
    try {
        const response = await fetch(`https://app.solayer.org/api/action/restake/ssol?amount=${amount}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                account: agent.wallet.publicKey.toBase58()
            })
        });
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || "Staking request failed");
        }
        const data = await response.json();
        // Deserialize and prepare transaction
        const txn = web3_js_1.VersionedTransaction.deserialize(Buffer.from(data.transaction, "base64"));
        // Update blockhash
        const { blockhash } = await agent.connection.getLatestBlockhash();
        txn.message.recentBlockhash = blockhash;
        // Sign and send transaction
        txn.sign([
            agent.wallet
        ]);
        const signature = await agent.connection.sendTransaction(txn, {
            preflightCommitment: "confirmed",
            maxRetries: 3
        });
        // Wait for confirmation
        const latestBlockhash = await agent.connection.getLatestBlockhash();
        await agent.connection.confirmTransaction({
            signature,
            blockhash: latestBlockhash.blockhash,
            lastValidBlockHeight: latestBlockhash.lastValidBlockHeight
        });
        return signature;
    } catch (error) {
        console.error(error);
        throw new Error(`Solayer sSOL staking failed: ${error.message}`);
    }
} //# sourceMappingURL=stake_with_solayer.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solayer/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solayer/stake_with_solayer.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/tensor/tensor_trade.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.listNFTForSale = listNFTForSale;
exports.cancelListing = cancelListing;
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const bn_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)");
const tensorswap_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/index.js [app-route] (ecmascript)");
async function listNFTForSale(agent, nftMint, price) {
    try {
        if (!web3_js_1.PublicKey.isOnCurve(nftMint)) {
            throw new Error("Invalid NFT mint address");
        }
        const mintInfo = await agent.connection.getAccountInfo(nftMint);
        if (!mintInfo) {
            throw new Error(`NFT mint ${nftMint.toString()} does not exist`);
        }
        const ata = await (0, spl_token_1.getAssociatedTokenAddress)(nftMint, agent.wallet_address);
        try {
            const tokenAccount = await (0, spl_token_1.getAccount)(agent.connection, ata);
            if (!tokenAccount || tokenAccount.amount <= 0) {
                throw new Error(`You don't own this NFT (${nftMint.toString()})`);
            }
        } catch (error) {
            console.error(error);
            throw new Error(`No token account found for mint ${nftMint.toString()}. Make sure you own this NFT.`);
        }
        const provider = new anchor_1.AnchorProvider(agent.connection, agent.getAnchorWallet(), anchor_1.AnchorProvider.defaultOptions());
        const tensorSwapSdk = new tensorswap_sdk_1.TensorSwapSDK({
            provider
        });
        const priceInLamports = new bn_js_1.BN(price * 1e9);
        const nftSource = await (0, spl_token_1.getAssociatedTokenAddress)(nftMint, agent.wallet_address);
        const { tx } = await tensorSwapSdk.list({
            nftMint,
            nftSource,
            owner: agent.wallet_address,
            price: priceInLamports,
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
            payer: agent.wallet_address
        });
        const transaction = new web3_js_1.Transaction();
        transaction.add(...tx.ixs);
        return await agent.connection.sendTransaction(transaction, [
            agent.wallet,
            ...tx.extraSigners
        ]);
    } catch (error) {
        console.error("Full error details:", error);
        throw error;
    }
}
async function cancelListing(agent, nftMint) {
    const provider = new anchor_1.AnchorProvider(agent.connection, agent.getAnchorWallet(), anchor_1.AnchorProvider.defaultOptions());
    const tensorSwapSdk = new tensorswap_sdk_1.TensorSwapSDK({
        provider
    });
    const nftDest = await (0, spl_token_1.getAssociatedTokenAddress)(nftMint, agent.wallet_address, false, spl_token_1.TOKEN_PROGRAM_ID);
    const { tx } = await tensorSwapSdk.delist({
        nftMint,
        nftDest,
        owner: agent.wallet_address,
        tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
        payer: agent.wallet_address,
        authData: null
    });
    const transaction = new web3_js_1.Transaction();
    transaction.add(...tx.ixs);
    return await agent.connection.sendTransaction(transaction, [
        agent.wallet,
        ...tx.extraSigners
    ]);
} //# sourceMappingURL=tensor_trade.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/tensor/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/tensor/tensor_trade.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/3land/create_3land_collectible.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createCollection = createCollection;
exports.createSingle = createSingle;
const listings_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/@3land+listings-sdk@0.0.4_@types+node@20.17.14_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.1_hcq54orvwwwhxfa45fjs36zq7a/node_modules/@3land/listings-sdk/dist/library/implementation/storeImplementation.js [app-route] (ecmascript)");
/**
 * Create a collection on 3Land
 * @param optionsWithBase58 represents the privateKey of the wallet - can be an array of numbers, Uint8Array or base58 string
 * @param collectionOpts represents the options for the collection creation
 * @returns
 */ async function createCollection(optionsWithBase58, collectionOpts) {
    try {
        const collection = await (0, listings_sdk_1.createCollectionImp)(optionsWithBase58, collectionOpts);
        return collection;
    } catch (error) {
        throw new Error(`Collection creation failed: ${error.message}`);
    }
}
/**
 * Create a single edition on 3Land
 * @param optionsWithBase58 represents the privateKey of the wallet - can be an array of numbers, Uint8Array or base58 string
 * @param collectionAccount represents the account for the nft collection
 * @param createItemOptions the options for the creation of the single NFT listing
 * @returns
 */ async function createSingle(optionsWithBase58, collectionAccount, createItemOptions, isMainnet) {
    try {
        const landStore = isMainnet ? "AmQNs2kgw4LvS9sm6yE9JJ4Hs3JpVu65eyx9pxMG2xA" : "GyPCu89S63P9NcCQAtuSJesiefhhgpGWrNVJs4bF2cSK";
        const singleEditionTx = await (0, listings_sdk_1.createSingleImp)(optionsWithBase58, landStore, collectionAccount, createItemOptions);
        return singleEditionTx;
    } catch (error) {
        throw new Error(`Single edition creation failed: ${error.message}`);
    }
} //# sourceMappingURL=create_3land_collectible.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/3land/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/3land/create_3land_collectible.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/tiplink/create_tiplinks.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.create_TipLink = create_TipLink;
const api_1 = __turbopack_require__("[project]/node_modules/.pnpm/@tiplink+api@0.3.1_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22__3opykffvi4spsr3bh3dyd32zmq/node_modules/@tiplink/api/dist/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const MINIMUM_SOL_BALANCE = 0.003 * web3_js_1.LAMPORTS_PER_SOL;
async function create_TipLink(agent, amount, splmintAddress) {
    try {
        const tiplink = await api_1.TipLink.create();
        if (!splmintAddress) {
            const transaction = new web3_js_1.Transaction();
            transaction.add(web3_js_1.SystemProgram.transfer({
                fromPubkey: agent.wallet_address,
                toPubkey: tiplink.keypair.publicKey,
                lamports: amount * web3_js_1.LAMPORTS_PER_SOL
            }));
            const signature = await (0, web3_js_1.sendAndConfirmTransaction)(agent.connection, transaction, [
                agent.wallet
            ], {
                commitment: "confirmed"
            });
            return {
                url: tiplink.url.toString(),
                signature
            };
        } else {
            const fromAta = await (0, spl_token_1.getAssociatedTokenAddress)(splmintAddress, agent.wallet_address);
            const toAta = await (0, spl_token_1.getAssociatedTokenAddress)(splmintAddress, tiplink.keypair.publicKey);
            const mintInfo = await (0, spl_token_1.getMint)(agent.connection, splmintAddress);
            const adjustedAmount = amount * Math.pow(10, mintInfo.decimals);
            const transaction = new web3_js_1.Transaction();
            transaction.add(web3_js_1.ComputeBudgetProgram.setComputeUnitPrice({
                microLamports: 5000
            }));
            transaction.add(web3_js_1.SystemProgram.transfer({
                fromPubkey: agent.wallet_address,
                toPubkey: tiplink.keypair.publicKey,
                lamports: MINIMUM_SOL_BALANCE
            }));
            transaction.add((0, spl_token_1.createAssociatedTokenAccountInstruction)(agent.wallet_address, toAta, tiplink.keypair.publicKey, splmintAddress));
            transaction.add((0, spl_token_1.createTransferInstruction)(fromAta, toAta, agent.wallet_address, adjustedAmount));
            const signature = await (0, web3_js_1.sendAndConfirmTransaction)(agent.connection, transaction, [
                agent.wallet
            ], {
                commitment: "confirmed"
            });
            return {
                url: tiplink.url.toString(),
                signature
            };
        }
    } catch (error) {
        console.error("Error creating TipLink or sending funds:", error.message);
        throw new Error(`Failed to create TipLink: ${error.message}`);
    }
} //# sourceMappingURL=create_tiplinks.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/tiplink/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/tiplink/create_tiplinks.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/lightprotocol/send_compressed_airdrop.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getAirdropCostEstimate = void 0;
exports.sendCompressedAirdrop = sendCompressedAirdrop;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const compressed_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@lightprotocol+compressed-token@0.17.1_@lightprotocol+stateless.js@0.17.1_bufferutil@4.0.9_en_kcqx4jzy4fty336jna4n64bp34/node_modules/@lightprotocol/compressed-token/dist/cjs/node/index.cjs [app-route] (ecmascript)");
const stateless_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@lightprotocol+stateless.js@0.17.1_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@lightprotocol/stateless.js/dist/cjs/node/index.cjs [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
// arbitrary
const MAX_AIRDROP_RECIPIENTS = 1000;
const MAX_CONCURRENT_TXS = 30;
/**
 * Estimate the cost of an airdrop in lamports.
 * @param numberOfRecipients      Number of recipients
 * @param priorityFeeInLamports   Priority fee in lamports
 * @returns                       Estimated cost in lamports
 */ const getAirdropCostEstimate = (numberOfRecipients, priorityFeeInLamports)=>{
    const baseFee = 5000;
    const perRecipientCompressedStateFee = 300;
    const txsNeeded = Math.ceil(numberOfRecipients / 15);
    const totalPriorityFees = txsNeeded * (baseFee + priorityFeeInLamports);
    return perRecipientCompressedStateFee * numberOfRecipients + totalPriorityFees;
};
exports.getAirdropCostEstimate = getAirdropCostEstimate;
/**
 * Send airdrop with ZK Compressed Tokens.
 * @param agent             Agent
 * @param mintAddress       SPL Mint address
 * @param amount            Amount to send per recipient
 * @param decimals          Decimals of the token
 * @param recipients        Recipient wallet addresses (no ATAs)
 * @param priorityFeeInLamports   Priority fee in lamports
 * @param shouldLog         Whether to log progress to stdout. Defaults to false.
 */ async function sendCompressedAirdrop(agent, mintAddress, amount, decimals, recipients, priorityFeeInLamports, shouldLog = false) {
    if (recipients.length > MAX_AIRDROP_RECIPIENTS) {
        throw new Error(`Max airdrop can be ${MAX_AIRDROP_RECIPIENTS} recipients at a time. For more scale, use open source ZK Compression airdrop tools such as https://github.com/helius-labs/airship.`);
    }
    const url = agent.connection.rpcEndpoint;
    if (url.includes("devnet")) {
        throw new Error("Devnet is not supported for airdrop. Please use mainnet.");
    }
    if (!url.includes("helius")) {
        console.warn("Warning: Must use RPC with ZK Compression support. Double check with your RPC provider if in doubt.");
    }
    try {
        await (0, spl_token_1.getOrCreateAssociatedTokenAccount)(agent.connection, agent.wallet, mintAddress, agent.wallet.publicKey);
    } catch (error) {
        console.error(error);
        throw new Error("Source token account not found and failed to create it. Please add funds to your wallet and try again.");
    }
    try {
        await (0, compressed_token_1.createTokenPool)(agent.connection, agent.wallet, mintAddress);
    } catch (error) {
        if (error.message.includes("already in use")) {
        // skip
        } else {
            throw error;
        }
    }
    return await processAll(agent, amount * 10 ** decimals, mintAddress, recipients, priorityFeeInLamports, shouldLog);
}
async function processAll(agent, amount, mint, recipients, priorityFeeInLamports, shouldLog) {
    const mintAddress = mint;
    const payer = agent.wallet;
    const sourceTokenAccount = await (0, spl_token_1.getOrCreateAssociatedTokenAccount)(agent.connection, agent.wallet, mintAddress, agent.wallet.publicKey);
    const maxRecipientsPerInstruction = 5;
    const maxIxs = 3; // empirically determined (as of 12/15/2024)
    const lookupTableAddress = new web3_js_1.PublicKey("9NYFyEqPkyXUhkerbGHXUXkvb4qpzeEdHuGpgbgpH1NJ");
    const lookupTableAccount = (await agent.connection.getAddressLookupTable(lookupTableAddress)).value;
    const batches = [];
    for(let i = 0; i < recipients.length; i += maxRecipientsPerInstruction * maxIxs){
        batches.push(recipients.slice(i, i + maxRecipientsPerInstruction * maxIxs));
    }
    const instructionSets = await Promise.all(batches.map(async (recipientBatch)=>{
        const instructions = [
            web3_js_1.ComputeBudgetProgram.setComputeUnitLimit({
                units: 500000
            }),
            web3_js_1.ComputeBudgetProgram.setComputeUnitPrice({
                microLamports: (0, stateless_js_1.calculateComputeUnitPrice)(priorityFeeInLamports, 500000)
            })
        ];
        const compressIxPromises = [];
        for(let i = 0; i < recipientBatch.length; i += maxRecipientsPerInstruction){
            const batch = recipientBatch.slice(i, i + maxRecipientsPerInstruction);
            compressIxPromises.push(compressed_token_1.CompressedTokenProgram.compress({
                payer: payer.publicKey,
                owner: payer.publicKey,
                source: sourceTokenAccount.address,
                toAddress: batch,
                amount: batch.map(()=>amount),
                mint: mintAddress
            }));
        }
        const compressIxs = await Promise.all(compressIxPromises);
        return [
            ...instructions,
            ...compressIxs
        ];
    }));
    const url = agent.connection.rpcEndpoint;
    const rpc = (0, stateless_js_1.createRpc)(url, url, url);
    const results = [];
    const confirmedCount = 0;
    const totalBatches = instructionSets.length;
    const renderProgressBar = (current, total)=>{
        const percentage = Math.floor(current / total * 100);
        const filled = Math.floor(percentage / 100 * 20);
        const empty = 20 - filled;
        const bar = "█".repeat(filled) + "░".repeat(empty);
        return `Airdropped to ${Math.min(current * 15, recipients.length)}/${recipients.length} recipients [${bar}] ${percentage}%`;
    };
    const log = (message)=>{
        if (shouldLog && typeof process !== "undefined" && process.stdout) {
            process.stdout.write(message);
        }
    };
    throw new Error("Not implemented");
// for (let i = 0; i < instructionSets.length; i += MAX_CONCURRENT_TXS) {
//   const batchPromises = instructionSets
//     .slice(i, i + MAX_CONCURRENT_TXS)
//     .map((instructions, idx) =>
//       sendTransactionWithRetry(
//         rpc,
//         instructions,
//         payer,
//         lookupTableAccount,
//         i + idx,
//       ).then((signature) => {
//         confirmedCount++;
//         log("\r" + renderProgressBar(confirmedCount, totalBatches));
//         return signature;
//       }),
//     );
//   const batchResults = await Promise.allSettled(batchPromises);
//   results.push(...batchResults);
// }
// log("\n");
// const failures = results
//   .filter((r) => r.status === "rejected")
//   .map((r, idx) => ({
//     index: idx,
//     error: (r as PromiseRejectedResult).reason,
//   }));
// if (failures.length > 0) {
//   throw new Error(
//     `Failed to process ${failures.length} batches: ${failures
//       .map((f) => f.error)
//       .join(", ")}`,
//   );
// }
// return results.map((r) => (r as PromiseFulfilledResult<string>).value);
}
async function sendTransactionWithRetry(connection, instructions, payer, lookupTableAccount, batchIndex) {
    const MAX_RETRIES = 3;
    const INITIAL_BACKOFF = 500; // ms
    for(let attempt = 0; attempt < MAX_RETRIES; attempt++){
        try {
            const { blockhash } = await connection.getLatestBlockhash();
            const tx = (0, stateless_js_1.buildAndSignTx)(instructions, payer, blockhash, [], [
                lookupTableAccount
            ]);
            const signature = await (0, stateless_js_1.sendAndConfirmTx)(connection, tx);
            return signature;
        } catch (error) {
            const isRetryable = error.message?.includes("blockhash not found") || error.message?.includes("timeout") || error.message?.includes("rate limit") || error.message?.includes("too many requests");
            if (!isRetryable || attempt === MAX_RETRIES - 1) {
                throw new Error(`Batch ${batchIndex} failed after ${attempt + 1} attempts: ${error.message}`);
            }
            const backoff = INITIAL_BACKOFF * Math.pow(2, attempt) * (0.5 + Math.random());
            await (0, stateless_js_1.sleep)(backoff);
        }
    }
    throw new Error("Unreachable");
} //# sourceMappingURL=send_compressed_airdrop.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/lightprotocol/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/lightprotocol/send_compressed_airdrop.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/create_multisig.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.create_squads_multisig = create_squads_multisig;
const multisig = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@sqds+multisig@2.1.3_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.2_pyafvhsgaceq257yyhnbil6sc4/node_modules/@sqds/multisig/lib/index.js [app-route] (ecmascript)"));
/**
 * Creates a new Squads multisig account.
 *
 * @param agent - The SolanaAgentKit instance containing the connection and wallet information.
 * @param creator - The public key of the creator who will be a member of the multisig.
 * @returns A promise that resolves to the transaction ID of the multisig creation transaction.
 *
 * @throws Will throw an error if the transaction fails.
 */ async function create_squads_multisig(agent, creator) {
    const connection = agent.connection;
    const createKey = agent.wallet; // can be any keypair, using the agent wallet as only one multisig is required
    const [multisigPda] = multisig.getMultisigPda({
        createKey: createKey.publicKey
    });
    const programConfigPda = multisig.getProgramConfigPda({})[0];
    const programConfig = await multisig.accounts.ProgramConfig.fromAccountAddress(connection, programConfigPda);
    const configTreasury = programConfig.treasury;
    const tx = multisig.transactions.multisigCreateV2({
        blockhash: (await connection.getLatestBlockhash()).blockhash,
        treasury: configTreasury,
        createKey: createKey.publicKey,
        creator: agent.wallet.publicKey,
        multisigPda,
        configAuthority: null,
        timeLock: 0,
        threshold: 2,
        rentCollector: null,
        members: [
            {
                key: agent.wallet.publicKey,
                permissions: multisig.types.Permissions.all()
            },
            {
                key: creator,
                permissions: multisig.types.Permissions.all()
            }
        ]
    });
    tx.sign([
        agent.wallet,
        createKey
    ]);
    const txId = connection.sendRawTransaction(tx.serialize());
    return txId;
} //# sourceMappingURL=create_multisig.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/create_proposal.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.multisig_create_proposal = multisig_create_proposal;
const multisig = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@sqds+multisig@2.1.3_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.2_pyafvhsgaceq257yyhnbil6sc4/node_modules/@sqds/multisig/lib/index.js [app-route] (ecmascript)"));
const { Multisig } = multisig.accounts;
/**
 * Creates a proposal for a multisig transaction.
 *
 * @param {SolanaAgentKit} agent - The Solana agent kit instance.
 * @param {number | bigint} [transactionIndex] - Optional transaction index. If not provided, the current transaction index will be used.
 * @returns {Promise<string>} - The transaction ID of the created proposal.
 * @throws {Error} - Throws an error if the proposal creation fails.
 */ async function multisig_create_proposal(agent, transactionIndex) {
    try {
        const createKey = agent.wallet;
        const [multisigPda] = multisig.getMultisigPda({
            createKey: createKey.publicKey
        });
        const multisigInfo = await Multisig.fromAccountAddress(agent.connection, multisigPda);
        const currentTransactionIndex = Number(multisigInfo.transactionIndex);
        if (!transactionIndex) {
            transactionIndex = BigInt(currentTransactionIndex);
        } else if (typeof transactionIndex !== "bigint") {
            transactionIndex = BigInt(transactionIndex);
        }
        const multisigTx = multisig.transactions.proposalCreate({
            blockhash: (await agent.connection.getLatestBlockhash()).blockhash,
            feePayer: agent.wallet_address,
            multisigPda,
            transactionIndex,
            creator: agent.wallet_address
        });
        multisigTx.sign([
            agent.wallet
        ]);
        const tx = await agent.connection.sendRawTransaction(multisigTx.serialize());
        return tx;
    } catch (error) {
        throw new Error(`Transfer failed: ${error}`);
    }
} //# sourceMappingURL=create_proposal.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/approve_proposal.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.multisig_approve_proposal = multisig_approve_proposal;
const multisig = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@sqds+multisig@2.1.3_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.2_pyafvhsgaceq257yyhnbil6sc4/node_modules/@sqds/multisig/lib/index.js [app-route] (ecmascript)"));
const { Multisig } = multisig.accounts;
/**
 * Approves a proposal in a Solana multisig wallet.
 *
 * @param {SolanaAgentKit} agent - The Solana agent kit instance.
 * @param {number | bigint} [transactionIndex] - The index of the transaction to approve. If not provided, the current transaction index will be used.
 * @returns {Promise<string>} - A promise that resolves to the transaction ID of the approved proposal.
 * @throws {Error} - Throws an error if the approval process fails.
 */ async function multisig_approve_proposal(agent, transactionIndex) {
    try {
        const createKey = agent.wallet;
        const [multisigPda] = multisig.getMultisigPda({
            createKey: createKey.publicKey
        });
        const multisigInfo = await Multisig.fromAccountAddress(agent.connection, multisigPda);
        const currentTransactionIndex = Number(multisigInfo.transactionIndex);
        if (!transactionIndex) {
            transactionIndex = BigInt(currentTransactionIndex);
        } else if (typeof transactionIndex !== "bigint") {
            transactionIndex = BigInt(transactionIndex);
        }
        // const [proposalPda, proposalBump] = multisig.getProposalPda({
        //   multisigPda,
        //   transactionIndex,
        // });
        const multisigTx = multisig.transactions.proposalApprove({
            blockhash: (await agent.connection.getLatestBlockhash()).blockhash,
            feePayer: agent.wallet.publicKey,
            multisigPda,
            transactionIndex: transactionIndex,
            member: agent.wallet.publicKey
        });
        multisigTx.sign([
            agent.wallet
        ]);
        const tx = await agent.connection.sendRawTransaction(multisigTx.serialize());
        return tx;
    } catch (error) {
        throw new Error(`Transfer failed: ${error}`);
    }
} //# sourceMappingURL=approve_proposal.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/deposit_to_treasury.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.multisig_deposit_to_treasury = multisig_deposit_to_treasury;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const web3_js_2 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const multisig = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@sqds+multisig@2.1.3_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.2_pyafvhsgaceq257yyhnbil6sc4/node_modules/@sqds/multisig/lib/index.js [app-route] (ecmascript)"));
/**
 * Transfer SOL or SPL tokens to a multisig vault.
 * @param agent SolanaAgentKit instance
 * @param amount Amount to transfer
 * @param vaultIndex Optional vault index, default is 0
 * @param mint Optional mint address for SPL tokens
 * @returns Transaction signature
 */ async function multisig_deposit_to_treasury(agent, amount, vaultIndex, mint) {
    try {
        let tx;
        if (!vaultIndex) {
            vaultIndex = 0;
        }
        const createKey = agent.wallet;
        const [multisigPda] = multisig.getMultisigPda({
            createKey: createKey.publicKey
        });
        const [vaultPda] = multisig.getVaultPda({
            multisigPda,
            index: vaultIndex
        });
        const to = vaultPda;
        if (!mint) {
            // Transfer native SOL
            const transaction = new web3_js_1.Transaction().add(web3_js_1.SystemProgram.transfer({
                fromPubkey: agent.wallet_address,
                toPubkey: to,
                lamports: amount * web3_js_2.LAMPORTS_PER_SOL
            }));
            tx = await agent.connection.sendTransaction(transaction, [
                agent.wallet
            ]);
        } else {
            // Transfer SPL token
            const fromAta = await (0, spl_token_1.getAssociatedTokenAddress)(mint, agent.wallet_address);
            const transaction = new web3_js_1.Transaction();
            const toAta = await (0, spl_token_1.getAssociatedTokenAddress)(mint, to, true);
            const toTokenAccountInfo = await agent.connection.getAccountInfo(toAta);
            // Create associated token account if it doesn't exist
            if (!toTokenAccountInfo) {
                transaction.add((0, spl_token_1.createAssociatedTokenAccountInstruction)(agent.wallet_address, toAta, to, mint));
            }
            // Get mint info to determine decimals
            const mintInfo = await (0, spl_token_1.getMint)(agent.connection, mint);
            const adjustedAmount = amount * Math.pow(10, mintInfo.decimals);
            transaction.add((0, spl_token_1.createTransferInstruction)(fromAta, toAta, agent.wallet_address, adjustedAmount));
            tx = await agent.connection.sendTransaction(transaction, [
                agent.wallet
            ]);
        }
        return tx;
    } catch (error) {
        throw new Error(`Transfer failed: ${error}`);
    }
} //# sourceMappingURL=deposit_to_treasury.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/execute_proposal.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.multisig_execute_proposal = multisig_execute_proposal;
const multisig = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@sqds+multisig@2.1.3_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.2_pyafvhsgaceq257yyhnbil6sc4/node_modules/@sqds/multisig/lib/index.js [app-route] (ecmascript)"));
const { Multisig } = multisig.accounts;
/**
 * Executes a transaction on the Solana blockchain using the provided agent.
 *
 * @param {SolanaAgentKit} agent - The Solana agent kit instance containing the wallet and connection.
 * @param {number | bigint} [transactionIndex] - Optional transaction index to execute. If not provided, the current transaction index from the multisig account will be used.
 * @returns {Promise<string>} - A promise that resolves to the transaction signature string.
 * @throws {Error} - Throws an error if the transaction execution fails.
 */ async function multisig_execute_proposal(agent, transactionIndex) {
    try {
        const createKey = agent.wallet;
        const [multisigPda] = multisig.getMultisigPda({
            createKey: createKey.publicKey
        });
        const multisigInfo = await Multisig.fromAccountAddress(agent.connection, multisigPda);
        const currentTransactionIndex = Number(multisigInfo.transactionIndex);
        if (!transactionIndex) {
            transactionIndex = BigInt(currentTransactionIndex);
        } else if (typeof transactionIndex !== "bigint") {
            transactionIndex = BigInt(transactionIndex);
        }
        const multisigTx = await multisig.transactions.vaultTransactionExecute({
            connection: agent.connection,
            blockhash: (await agent.connection.getLatestBlockhash()).blockhash,
            feePayer: agent.wallet.publicKey,
            multisigPda,
            transactionIndex,
            member: agent.wallet.publicKey
        });
        multisigTx.sign([
            agent.wallet
        ]);
        const tx = await agent.connection.sendRawTransaction(multisigTx.serialize());
        return tx;
    } catch (error) {
        throw new Error(`Transfer failed: ${error}`);
    }
} //# sourceMappingURL=execute_proposal.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/reject_proposal.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.multisig_reject_proposal = multisig_reject_proposal;
const multisig = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@sqds+multisig@2.1.3_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.2_pyafvhsgaceq257yyhnbil6sc4/node_modules/@sqds/multisig/lib/index.js [app-route] (ecmascript)"));
const { Multisig } = multisig.accounts;
/**
 * Rejects a proposal in a Solana multisig setup.
 *
 * @param agent - The SolanaAgentKit instance containing the wallet and connection.
 * @param transactionIndex - Optional. The index of the transaction to reject. If not provided, the current transaction index will be used.
 * @returns A promise that resolves to the transaction ID of the rejection transaction.
 * @throws Will throw an error if the transaction fails.
 */ async function multisig_reject_proposal(agent, transactionIndex) {
    try {
        const createKey = agent.wallet;
        const [multisigPda] = multisig.getMultisigPda({
            createKey: createKey.publicKey
        });
        const multisigInfo = await Multisig.fromAccountAddress(agent.connection, multisigPda);
        const currentTransactionIndex = Number(multisigInfo.transactionIndex);
        if (!transactionIndex) {
            transactionIndex = BigInt(currentTransactionIndex);
        } else if (typeof transactionIndex !== "bigint") {
            transactionIndex = BigInt(transactionIndex);
        }
        // const [proposalPda, proposalBump] = multisig.getProposalPda({
        //   multisigPda,
        //   transactionIndex,
        // });
        const multisigTx = multisig.transactions.proposalReject({
            blockhash: (await agent.connection.getLatestBlockhash()).blockhash,
            feePayer: agent.wallet.publicKey,
            multisigPda,
            transactionIndex: transactionIndex,
            member: agent.wallet.publicKey
        });
        multisigTx.sign([
            agent.wallet
        ]);
        const tx = await agent.connection.sendRawTransaction(multisigTx.serialize());
        return tx;
    } catch (error) {
        throw new Error(`Transfer failed: ${error}`);
    }
} //# sourceMappingURL=reject_proposal.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/transfer_from_treasury.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function() {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o) {
            var ar = [];
            for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
            for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
    };
}();
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.multisig_transfer_from_treasury = multisig_transfer_from_treasury;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const web3_js_2 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const multisig = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@sqds+multisig@2.1.3_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.2_pyafvhsgaceq257yyhnbil6sc4/node_modules/@sqds/multisig/lib/index.js [app-route] (ecmascript)"));
const { Multisig } = multisig.accounts;
/**
 * Transfer SOL or SPL tokens to a recipient from a multisig vault.
 * @param agent - SolanaAgentKit instance.
 * @param amount - Amount to transfer.
 * @param to - Recipient's public key.
 * @param vaultIndex - Optional vault index, default is 0.
 * @param mint - Optional mint address for SPL tokens.
 * @returns Transaction signature.
 */ async function multisig_transfer_from_treasury(agent, amount, to, vaultIndex = 0, mint) {
    try {
        let transferInstruction;
        const createKey = agent.wallet;
        const [multisigPda] = multisig.getMultisigPda({
            createKey: createKey.publicKey
        });
        const multisigInfo = await Multisig.fromAccountAddress(agent.connection, multisigPda);
        const currentTransactionIndex = Number(multisigInfo.transactionIndex);
        const transactionIndex = BigInt(currentTransactionIndex + 1);
        const [vaultPda] = multisig.getVaultPda({
            multisigPda,
            index: vaultIndex
        });
        if (!mint) {
            // Transfer native SOL
            transferInstruction = web3_js_1.SystemProgram.transfer({
                fromPubkey: agent.wallet_address,
                toPubkey: to,
                lamports: amount * web3_js_2.LAMPORTS_PER_SOL
            });
        } else {
            // Transfer SPL token
            const fromAta = await (0, spl_token_1.getAssociatedTokenAddress)(mint, vaultPda, true);
            const toAta = await (0, spl_token_1.getAssociatedTokenAddress)(mint, to, true);
            const mintInfo = await (0, spl_token_1.getMint)(agent.connection, mint);
            const adjustedAmount = amount * Math.pow(10, mintInfo.decimals);
            transferInstruction = (0, spl_token_1.createTransferInstruction)(fromAta, toAta, agent.wallet_address, adjustedAmount);
        }
        const transferMessage = new web3_js_1.TransactionMessage({
            payerKey: vaultPda,
            recentBlockhash: (await agent.connection.getLatestBlockhash()).blockhash,
            instructions: [
                transferInstruction
            ]
        });
        const multisigTx = multisig.transactions.vaultTransactionCreate({
            blockhash: (await agent.connection.getLatestBlockhash()).blockhash,
            feePayer: agent.wallet_address,
            multisigPda,
            transactionIndex,
            creator: agent.wallet_address,
            vaultIndex: 0,
            ephemeralSigners: 0,
            transactionMessage: transferMessage
        });
        multisigTx.sign([
            agent.wallet
        ]);
        const tx = await agent.connection.sendRawTransaction(multisigTx.serialize());
        return tx;
    } catch (error) {
        throw new Error(`Transfer failed: ${error}`);
    }
} //# sourceMappingURL=transfer_from_treasury.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/create_multisig.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/create_proposal.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/approve_proposal.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/deposit_to_treasury.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/execute_proposal.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/reject_proposal.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/transfer_from_treasury.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/get_assets_by_owner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getAssetsByOwner = getAssetsByOwner;
/**
 * Fetch assets by owner using the Helius Digital Asset Standard (DAS) API
 * @param agent SolanaAgentKit instance
 * @param ownerPublicKey Owner's Solana wallet PublicKey
 * @param limit Number of assets to retrieve per request
 * @returns Assets owned by the specified address
 */ async function getAssetsByOwner(agent, ownerPublicKey, limit) {
    try {
        const apiKey = agent.config.HELIUS_API_KEY;
        if (!apiKey) {
            throw new Error("HELIUS_API_KEY not found in environment variables");
        }
        const url = `https://mainnet.helius-rpc.com/?api-key=${apiKey}`;
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                jsonrpc: "2.0",
                id: "get-assets",
                method: "getAssetsByOwner",
                params: {
                    ownerAddress: ownerPublicKey.toString(),
                    page: 3,
                    limit: limit,
                    displayOptions: {
                        showFungible: true
                    }
                }
            })
        });
        if (!response.ok) {
            throw new Error(`Failed to fetch: ${response.status} - ${response.statusText}`);
        }
        const data = await response.json();
        return data.result.items;
    } catch (error) {
        console.error("Error retrieving assets: ", error.message);
        throw new Error(`Assets retrieval failed: ${error.message}`);
    }
} //# sourceMappingURL=get_assets_by_owner.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/helius_transaction_parsing.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.parseTransaction = parseTransaction;
/**
 * Parse a Solana transaction using the Helius Enhanced Transactions API
 * @param agent SolanaAgentKit instance
 * @param transactionId The transaction ID to parse
 * @returns Parsed transaction data
 */ async function parseTransaction(agent, transactionId) {
    try {
        const apiKey = agent.config.HELIUS_API_KEY;
        if (!apiKey) {
            throw new Error("HELIUS_API_KEY not found in environment variables");
        }
        const url = `https://api.helius.xyz/v0/transactions/?api-key=${apiKey}`;
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                transactions: [
                    transactionId
                ]
            })
        });
        if (!response.ok) {
            throw new Error(`Failed to fetch: ${response.status} - ${response.statusText}`);
        }
        const data = await response.json();
        return data;
    } catch (error) {
        console.error("Error parsing transaction: ", error.message);
        throw new Error(`Transaction parsing failed: ${error.message}`);
    }
} //# sourceMappingURL=helius_transaction_parsing.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/helius_webhooks.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.create_HeliusWebhook = create_HeliusWebhook;
exports.getHeliusWebhook = getHeliusWebhook;
exports.deleteHeliusWebhook = deleteHeliusWebhook;
async function create_HeliusWebhook(agent, accountAddresses, webhookURL) {
    try {
        const response = await fetch(`https://api.helius.xyz/v0/webhooks?api-key=${agent.config.HELIUS_API_KEY}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                webhookURL,
                transactionTypes: [
                    "Any"
                ],
                accountAddresses,
                webhookType: "enhanced",
                txnStatus: "all"
            })
        });
        const data = await response.json();
        return {
            webhookURL: data.webhookURL,
            webhookID: data.webhookID
        };
    } catch (error) {
        throw new Error(`Failed to create Webhook: ${error.message}`);
    }
}
/**
 * Retrieves a Helius Webhook by ID, returning only the specified fields.
 *
 * @param agent     - An instance of SolanaAgentKit (with .config.HELIUS_API_KEY)
 * @param webhookID - The unique ID of the webhook to retrieve
 *
 * @returns A HeliusWebhook object containing { wallet, webhookURL, transactionTypes, accountAddresses, webhookType }
 */ async function getHeliusWebhook(agent, webhookID) {
    try {
        const apiKey = agent.config.HELIUS_API_KEY;
        if (!apiKey) {
            throw new Error("HELIUS_API_KEY is missing in agent.config");
        }
        const response = await fetch(`https://api.helius.xyz/v0/webhooks/${webhookID}?api-key=${apiKey}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });
        if (!response.ok) {
            throw new Error(`Failed to fetch webhook with ID ${webhookID}. ` + `Status Code: ${response.status}`);
        }
        const data = await response.json();
        return {
            wallet: data.wallet,
            webhookURL: data.webhookURL,
            transactionTypes: data.transactionTypes,
            accountAddresses: data.accountAddresses,
            webhookType: data.webhookType
        };
    } catch (error) {
        throw new Error(`Failed to get webhook by ID: ${error.message}`);
    }
}
/**
 * Deletes a Helius Webhook by its ID.
 *
 * @param agent     - An instance of SolanaAgentKit (with .config.HELIUS_API_KEY)
 * @param webhookID - The unique ID of the webhook to delete
 *
 * @returns The response body from the Helius API (which may contain status or other info)
 */ async function deleteHeliusWebhook(agent, webhookID) {
    try {
        const apiKey = agent.config.HELIUS_API_KEY;
        if (!apiKey) {
            throw new Error("Missing Helius API key in agent.config.HELIUS_API_KEY");
        }
        const url = `https://api.helius.xyz/v0/webhooks/${webhookID}?api-key=${apiKey}`;
        const response = await fetch(url, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        });
        if (!response.ok) {
            throw new Error(`Failed to delete webhook: ${response.status} ${response.statusText}`);
        }
        if (response.status === 204) {
            return {
                message: "Webhook deleted successfully (no content returned)"
            };
        }
        const contentLength = response.headers.get("Content-Length");
        if (contentLength === "0" || !contentLength) {
            return {
                message: "Webhook deleted successfully (empty body)"
            };
        }
        // Otherwise, parse as JSON
        const data = await response.json();
        return data;
    } catch (error) {
        console.error("Error deleting Helius Webhook:", error.message);
        throw new Error(`Failed to delete Helius Webhook: ${error.message}`);
    }
} //# sourceMappingURL=helius_webhooks.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/send_transaction_with_priority.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.sendTransactionWithPriorityFee = sendTransactionWithPriorityFee;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const bs58_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bs58@6.0.0/node_modules/bs58/src/cjs/index.cjs [app-route] (ecmascript)"));
/**
 * Sends a transaction with an estimated priority fee using the provided SolanaAgentKit.
 *
 * @param agent         An instance of SolanaAgentKit containing connection, wallet, etc.
 * @param priorityLevel The priority level (e.g., "Min", "Low", "Medium", "High", "VeryHigh", or "UnsafeMax").
 * @param amount        The amount of SOL to send (in SOL, not lamports).
 * @param to            The recipient's PublicKey.
 * @returns             The transaction signature (string) once confirmed along with the fee used.
 */ async function sendTransactionWithPriorityFee(agent, priorityLevel, amount, to, splmintAddress) {
    try {
        if (!splmintAddress) {
            const transaction = new web3_js_1.Transaction();
            const { blockhash, lastValidBlockHeight } = await agent.connection.getLatestBlockhash();
            transaction.recentBlockhash = blockhash;
            transaction.lastValidBlockHeight = lastValidBlockHeight;
            transaction.feePayer = agent.wallet_address;
            const transferIx = web3_js_1.SystemProgram.transfer({
                fromPubkey: agent.wallet_address,
                toPubkey: to,
                lamports: amount * web3_js_1.LAMPORTS_PER_SOL
            });
            transaction.add(transferIx);
            const signedTx = await agent.wallet.signTransaction(transaction);
            const response = await fetch(`https://mainnet.helius-rpc.com/?api-key=${agent.config.HELIUS_API_KEY}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    jsonrpc: "2.0",
                    id: "1",
                    method: "getPriorityFeeEstimate",
                    params: [
                        {
                            transaction: bs58_1.default.encode(signedTx.serialize()),
                            options: {
                                priorityLevel: priorityLevel
                            }
                        }
                    ]
                })
            });
            const data = await response.json();
            if (data.error) {
                throw new Error("Error fetching priority fee:");
            }
            const feeEstimate = data.result.priorityFeeEstimate;
            // Set the priority fee if applicable
            const computePriceIx = web3_js_1.ComputeBudgetProgram.setComputeUnitPrice({
                microLamports: feeEstimate
            });
            transaction.add(computePriceIx);
            // Send the transaction and confirm
            const txSignature = await (0, web3_js_1.sendAndConfirmTransaction)(agent.connection, transaction, [
                agent.wallet
            ]);
            return {
                transactionId: txSignature,
                fee: feeEstimate
            };
        } else {
            const fromAta = await (0, spl_token_1.getAssociatedTokenAddress)(splmintAddress, agent.wallet_address);
            const toAta = await (0, spl_token_1.getAssociatedTokenAddress)(splmintAddress, to);
            const mintInfo = await (0, spl_token_1.getMint)(agent.connection, splmintAddress);
            const adjustedAmount = amount * Math.pow(10, mintInfo.decimals);
            const transaction = new web3_js_1.Transaction();
            const { blockhash, lastValidBlockHeight } = await agent.connection.getLatestBlockhash();
            transaction.recentBlockhash = blockhash;
            transaction.lastValidBlockHeight = lastValidBlockHeight;
            transaction.feePayer = agent.wallet_address;
            const response = await fetch(`https://mainnet.helius-rpc.com/?api-key=${agent.config.HELIUS_API_KEY}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    jsonrpc: "2.0",
                    id: "1",
                    method: "getPriorityFeeEstimate",
                    params: [
                        {
                            transaction: bs58_1.default.encode(transaction.serialize()),
                            options: {
                                priorityLevel: priorityLevel
                            }
                        }
                    ]
                })
            });
            const data = await response.json();
            if (data.error) {
                throw new Error("Error fetching priority fee:");
            }
            const feeEstimate = data.result.priorityFeeEstimate;
            transaction.add(web3_js_1.ComputeBudgetProgram.setComputeUnitPrice({
                microLamports: feeEstimate
            }));
            transaction.add((0, spl_token_1.createAssociatedTokenAccountInstruction)(agent.wallet_address, toAta, to, splmintAddress));
            transaction.add((0, spl_token_1.createTransferInstruction)(fromAta, toAta, agent.wallet_address, adjustedAmount));
            const txSignature = await (0, web3_js_1.sendAndConfirmTransaction)(agent.connection, transaction, [
                agent.wallet
            ]);
            return {
                transactionId: txSignature,
                fee: feeEstimate
            };
        }
    } catch (error) {
        throw new Error(`Failed to process transaction: ${error.message}`);
    }
} //# sourceMappingURL=send_transaction_with_priority.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/get_assets_by_owner.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/helius_transaction_parsing.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/helius_webhooks.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/send_transaction_with_priority.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/adrena/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sns/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/dexscreener/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/alldomains/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/flash/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/gibwork/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/jupiter/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/lulo/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/manifest/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/agent/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/metaplex/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/openbook/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/pumpfun/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/pyth/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/raydium/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/rugcheck/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/sendarcade/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solayer/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/tensor/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/3land/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/tiplink/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/lightprotocol/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/squads/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/index.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/agent/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaAgentKit = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const constants_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/constants/index.js [app-route] (ecmascript)");
/**
 * Main class for interacting with Solana blockchain
 * Provides a unified interface for token operations, NFT management, trading and more
 *
 * @class SolanaAgentKit
 * @property {Connection} connection - Solana RPC connection
 * @property {WalletAdapter} wallet - Wallet that implements WalletAdapter for signing transactions
 * @property {PublicKey} wallet_address - Public key of the wallet
 * @property {Config} config - Configuration object
 */ class SolanaAgentKit {
    constructor(wallet, rpc_url, configOrKey){
        this.connection = new web3_js_1.Connection(rpc_url || "https://api.mainnet-beta.solana.com");
        this.wallet = wallet;
        this.wallet_address = this.wallet.publicKey;
        // Handle both old and new patterns
        if (typeof configOrKey === "string" || configOrKey === null) {
            this.config = {
                OPENAI_API_KEY: configOrKey || ""
            };
        } else {
            this.config = configOrKey;
        }
    }
    getAnchorWallet() {
        const adapter = this.wallet;
        return {
            publicKey: adapter.publicKey,
            signTransaction: adapter.signTransaction.bind(adapter),
            signAllTransactions: adapter.signAllTransactions.bind(adapter),
            payer: adapter
        };
    }
    // Tool methods
    async requestFaucetFunds() {
        return (0, tools_1.request_faucet_funds)(this);
    }
    async deployToken(name, uri, symbol, decimals = constants_1.DEFAULT_OPTIONS.TOKEN_DECIMALS, initialSupply) {
        return (0, tools_1.deploy_token)(this, name, uri, symbol, decimals, initialSupply);
    }
    async deployCollection(options) {
        return (0, tools_1.deploy_collection)(this, options);
    }
    async getBalance(token_address) {
        return (0, tools_1.get_balance)(this, token_address);
    }
    async getBalanceOther(walletAddress, tokenAddress) {
        return (0, tools_1.get_balance_other)(this, walletAddress, tokenAddress);
    }
    async mintNFT(collectionMint, metadata, recipient) {
        return (0, tools_1.mintCollectionNFT)(this, collectionMint, metadata, recipient);
    }
    async transfer(to, amount, mint) {
        return (0, tools_1.transfer)(this, to, amount, mint);
    }
    async registerDomain(name, spaceKB) {
        return (0, tools_1.registerDomain)(this, name, spaceKB);
    }
    async resolveSolDomain(domain) {
        return (0, tools_1.resolveSolDomain)(this, domain);
    }
    async getPrimaryDomain(account) {
        return (0, tools_1.getPrimaryDomain)(this, account);
    }
    async trade(outputMint, inputAmount, inputMint, slippageBps = constants_1.DEFAULT_OPTIONS.SLIPPAGE_BPS) {
        return (0, tools_1.trade)(this, outputMint, inputAmount, inputMint, slippageBps);
    }
    async limitOrder(marketId, quantity, side, price) {
        return (0, tools_1.limitOrder)(this, marketId, quantity, side, price);
    }
    async batchOrder(marketId, orders) {
        return (0, tools_1.batchOrder)(this, marketId, orders);
    }
    async cancelAllOrders(marketId) {
        return (0, tools_1.cancelAllOrders)(this, marketId);
    }
    async withdrawAll(marketId) {
        return (0, tools_1.withdrawAll)(this, marketId);
    }
    async openPerpTradeLong(args) {
        return (0, tools_1.openPerpTradeLong)({
            agent: this,
            ...args
        });
    }
    async openPerpTradeShort(args) {
        return (0, tools_1.openPerpTradeShort)({
            agent: this,
            ...args
        });
    }
    async closePerpTradeShort(args) {
        return (0, tools_1.closePerpTradeShort)({
            agent: this,
            ...args
        });
    }
    async closePerpTradeLong(args) {
        return (0, tools_1.closePerpTradeLong)({
            agent: this,
            ...args
        });
    }
    async lendAssets(amount) {
        return (0, tools_1.lendAsset)(this, amount);
    }
    async getTPS() {
        return (0, tools_1.getTPS)(this);
    }
    async getTokenDataByAddress(mint) {
        return (0, tools_1.getTokenDataByAddress)(new web3_js_1.PublicKey(mint));
    }
    async getTokenDataByTicker(ticker) {
        return (0, tools_1.getTokenDataByTicker)(ticker);
    }
    async fetchTokenPrice(mint) {
        return (0, tools_1.fetchPrice)(new web3_js_1.PublicKey(mint));
    }
    async launchPumpFunToken(tokenName, tokenTicker, description, imageUrl, options) {
        return (0, tools_1.launchPumpFunToken)(this, tokenName, tokenTicker, description, imageUrl, options);
    }
    async stake(amount) {
        return (0, tools_1.stakeWithJup)(this, amount);
    }
    async restake(amount) {
        return (0, tools_1.stakeWithSolayer)(this, amount);
    }
    async sendCompressedAirdrop(mintAddress, amount, decimals, recipients, priorityFeeInLamports, shouldLog) {
        return await (0, tools_1.sendCompressedAirdrop)(this, new web3_js_1.PublicKey(mintAddress), amount, decimals, recipients.map((recipient)=>new web3_js_1.PublicKey(recipient)), priorityFeeInLamports, shouldLog);
    }
    async orcaClosePosition(positionMintAddress) {
        return (0, tools_1.orcaClosePosition)(this, positionMintAddress);
    }
    async orcaCreateCLMM(mintDeploy, mintPair, initialPrice, feeTier) {
        return (0, tools_1.orcaCreateCLMM)(this, mintDeploy, mintPair, initialPrice, feeTier);
    }
    async orcaCreateSingleSidedLiquidityPool(depositTokenAmount, depositTokenMint, otherTokenMint, initialPrice, maxPrice, feeTier) {
        return (0, tools_1.orcaCreateSingleSidedLiquidityPool)(this, depositTokenAmount, depositTokenMint, otherTokenMint, initialPrice, maxPrice, feeTier);
    }
    async orcaFetchPositions() {
        return (0, tools_1.orcaFetchPositions)(this);
    }
    async orcaOpenCenteredPositionWithLiquidity(whirlpoolAddress, priceOffsetBps, inputTokenMint, inputAmount) {
        return (0, tools_1.orcaOpenCenteredPositionWithLiquidity)(this, whirlpoolAddress, priceOffsetBps, inputTokenMint, inputAmount);
    }
    async orcaOpenSingleSidedPosition(whirlpoolAddress, distanceFromCurrentPriceBps, widthBps, inputTokenMint, inputAmount) {
        return (0, tools_1.orcaOpenSingleSidedPosition)(this, whirlpoolAddress, distanceFromCurrentPriceBps, widthBps, inputTokenMint, inputAmount);
    }
    async resolveAllDomains(domain) {
        return (0, tools_1.resolveAllDomains)(this, domain);
    }
    async getOwnedAllDomains(owner) {
        return (0, tools_1.getOwnedAllDomains)(this, owner);
    }
    async getOwnedDomainsForTLD(tld) {
        return (0, tools_1.getOwnedDomainsForTLD)(this, tld);
    }
    async getAllDomainsTLDs() {
        return (0, tools_1.getAllDomainsTLDs)(this);
    }
    async getAllRegisteredAllDomains() {
        return (0, tools_1.getAllRegisteredAllDomains)(this);
    }
    async getMainAllDomainsDomain(owner) {
        return (0, tools_1.getMainAllDomainsDomain)(this, owner);
    }
    async raydiumCreateAmmV4(marketId, baseAmount, quoteAmount, startTime) {
        return (0, tools_1.raydiumCreateAmmV4)(this, marketId, baseAmount, quoteAmount, startTime);
    }
    async raydiumCreateClmm(mint1, mint2, configId, initialPrice, startTime) {
        return (0, tools_1.raydiumCreateClmm)(this, mint1, mint2, configId, initialPrice, startTime);
    }
    async raydiumCreateCpmm(mint1, mint2, configId, mintAAmount, mintBAmount, startTime) {
        return (0, tools_1.raydiumCreateCpmm)(this, mint1, mint2, configId, mintAAmount, mintBAmount, startTime);
    }
    async openbookCreateMarket(baseMint, quoteMint, lotSize = 1, tickSize = 0.01) {
        return (0, tools_1.openbookCreateMarket)(this, baseMint, quoteMint, lotSize, tickSize);
    }
    async manifestCreateMarket(baseMint, quoteMint) {
        return (0, tools_1.manifestCreateMarket)(this, baseMint, quoteMint);
    }
    async getPythPriceFeedID(tokenSymbol) {
        return (0, tools_1.fetchPythPriceFeedID)(tokenSymbol);
    }
    async getPythPrice(priceFeedID) {
        return (0, tools_1.fetchPythPrice)(priceFeedID);
    }
    async createGibworkTask(title, content, requirements, tags, tokenMintAddress, tokenAmount, payer) {
        return (0, tools_1.create_gibwork_task)(this, title, content, requirements, tags, new web3_js_1.PublicKey(tokenMintAddress), tokenAmount, payer ? new web3_js_1.PublicKey(payer) : undefined);
    }
    async rockPaperScissors(amount, choice) {
        return (0, tools_1.rock_paper_scissor)(this, amount, choice);
    }
    async createTiplink(amount, splmintAddress) {
        return (0, tools_1.create_TipLink)(this, amount, splmintAddress);
    }
    async tensorListNFT(nftMint, price) {
        return (0, tools_1.listNFTForSale)(this, nftMint, price);
    }
    async tensorCancelListing(nftMint) {
        return (0, tools_1.cancelListing)(this, nftMint);
    }
    async closeEmptyTokenAccounts() {
        return (0, tools_1.closeEmptyTokenAccounts)(this);
    }
    async fetchTokenReportSummary(mint) {
        return (0, tools_1.fetchTokenReportSummary)(mint);
    }
    async fetchTokenDetailedReport(mint) {
        return (0, tools_1.fetchTokenDetailedReport)(mint);
    }
    /**
     * Opens a new trading position on Flash.Trade
     * @param params Flash trade parameters including market, side, collateral, leverage, and pool name
     * @returns Transaction signature
     */ async flashOpenTrade(params) {
        return (0, tools_1.flashOpenTrade)(this, params);
    }
    /**
     * Closes an existing trading position on Flash.Trade
     * @param params Flash trade close parameters
     * @returns Transaction signature
     */ async flashCloseTrade(params) {
        return (0, tools_1.flashCloseTrade)(this, params);
    }
    async heliusParseTransactions(transactionId) {
        return (0, tools_1.parseTransaction)(this, transactionId);
    }
    async getAllAssetsbyOwner(owner, limit) {
        return (0, tools_1.getAssetsByOwner)(this, owner, limit);
    }
    async create3LandCollection(optionsWithBase58, collectionOpts) {
        const tx = await (0, tools_1.createCollection)(optionsWithBase58, collectionOpts);
        return `Transaction: ${tx}`;
    }
    async create3LandNft(optionsWithBase58, collectionAccount, createItemOptions, isMainnet) {
        const tx = await (0, tools_1.createSingle)(optionsWithBase58, collectionAccount, createItemOptions, isMainnet);
        return `Transaction: ${tx}`;
    }
    async sendTranctionWithPriority(priorityLevel, amount, to, splmintAddress) {
        return (0, tools_1.sendTransactionWithPriorityFee)(this, priorityLevel, amount, to, splmintAddress);
    }
    async createSquadsMultisig(creator) {
        return (0, tools_1.create_squads_multisig)(this, creator);
    }
    async depositToMultisig(amount, vaultIndex = 0, mint) {
        return (0, tools_1.multisig_deposit_to_treasury)(this, amount, vaultIndex, mint);
    }
    async transferFromMultisig(amount, to, vaultIndex = 0, mint) {
        return (0, tools_1.multisig_transfer_from_treasury)(this, amount, to, vaultIndex, mint);
    }
    async createMultisigProposal(transactionIndex) {
        return (0, tools_1.multisig_create_proposal)(this, transactionIndex);
    }
    async approveMultisigProposal(transactionIndex) {
        return (0, tools_1.multisig_approve_proposal)(this, transactionIndex);
    }
    async rejectMultisigProposal(transactionIndex) {
        return (0, tools_1.multisig_reject_proposal)(this, transactionIndex);
    }
    async executeMultisigTransaction(transactionIndex) {
        return (0, tools_1.multisig_execute_proposal)(this, transactionIndex);
    }
    async CreateWebhook(accountAddresses, webhookURL) {
        return (0, tools_1.create_HeliusWebhook)(this, accountAddresses, webhookURL);
    }
    async getWebhook(id) {
        return (0, tools_1.getHeliusWebhook)(this, id);
    }
    async deleteWebhook(webhookID) {
        return (0, tools_1.deleteHeliusWebhook)(this, webhookID);
    }
}
exports.SolanaAgentKit = SolanaAgentKit; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/adrena/open_trade.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaPerpOpenTradeTool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaPerpOpenTradeTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_open_perp_trade";
        this.description = `This tool can be used to open perpetuals trade ( It uses Adrena Protocol ).

  Inputs ( input is a JSON string ):
  collateralAmount: number, eg 1 or 0.01 (required)
  collateralMint: string, eg "J1toso1uCk3RLmjorhTtrVwY9HJ7X8V9yYac6Y7kGCPn" or "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v" etc. (optional)
  tradeMint: string, eg "J1toso1uCk3RLmjorhTtrVwY9HJ7X8V9yYac6Y7kGCPn", "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263" etc. (optional)
  leverage: number, eg 50000 = x5, 100000 = x10, 1000000 = x100 (optional)
  price?: number, eg 100 (optional)
  slippage?: number, eg 0.3 (optional)
  side: string, eg: "long" or "short"`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            const tx = parsedInput.side === "long" ? await this.solanaKit.openPerpTradeLong({
                price: parsedInput.price,
                collateralAmount: parsedInput.collateralAmount,
                collateralMint: new web3_js_1.PublicKey(parsedInput.collateralMint),
                leverage: parsedInput.leverage,
                tradeMint: new web3_js_1.PublicKey(parsedInput.tradeMint),
                slippage: parsedInput.slippage
            }) : await this.solanaKit.openPerpTradeLong({
                price: parsedInput.price,
                collateralAmount: parsedInput.collateralAmount,
                collateralMint: new web3_js_1.PublicKey(parsedInput.collateralMint),
                leverage: parsedInput.leverage,
                tradeMint: new web3_js_1.PublicKey(parsedInput.tradeMint),
                slippage: parsedInput.slippage
            });
            return JSON.stringify({
                status: "success",
                message: "Perpetual trade opened successfully",
                transaction: tx,
                price: parsedInput.price,
                collateralAmount: parsedInput.collateralAmount,
                collateralMint: new web3_js_1.PublicKey(parsedInput.collateralMint),
                leverage: parsedInput.leverage,
                tradeMint: new web3_js_1.PublicKey(parsedInput.tradeMint),
                slippage: parsedInput.slippage,
                side: parsedInput.side
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaPerpOpenTradeTool = SolanaPerpOpenTradeTool; //# sourceMappingURL=open_trade.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/adrena/close_trade.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaPerpCloseTradeTool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaPerpCloseTradeTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_close_perp_trade";
        this.description = `This tool can be used to close perpetuals trade ( It uses Adrena Protocol ).

  Inputs ( input is a JSON string ):
  tradeMint: string, eg "J1toso1uCk3RLmjorhTtrVwY9HJ7X8V9yYac6Y7kGCPn", "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263" etc. (optional)
  price?: number, eg 100 (optional)
  side: string, eg: "long" or "short"`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            const tx = parsedInput.side === "long" ? await this.solanaKit.closePerpTradeLong({
                price: parsedInput.price,
                tradeMint: new web3_js_1.PublicKey(parsedInput.tradeMint)
            }) : await this.solanaKit.closePerpTradeShort({
                price: parsedInput.price,
                tradeMint: new web3_js_1.PublicKey(parsedInput.tradeMint)
            });
            return JSON.stringify({
                status: "success",
                message: "Perpetual trade closed successfully",
                transaction: tx,
                price: parsedInput.price,
                tradeMint: new web3_js_1.PublicKey(parsedInput.tradeMint),
                side: parsedInput.side
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaPerpCloseTradeTool = SolanaPerpCloseTradeTool; //# sourceMappingURL=close_trade.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/adrena/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/adrena/open_trade.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/adrena/close_trade.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/alldomains/resolve_all_domains.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaResolveAllDomainsTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaResolveAllDomainsTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_resolve_all_domains";
        this.description = `Resolve domain names to a public key for ALL domain types EXCEPT .sol domains.
  Use this for domains like .blink, .bonk, etc.
  DO NOT use this for .sol domains (use solana_resolve_domain instead).

  Input:
  domain: string, eg "mydomain.blink" or "mydomain.bonk" (required)`;
    }
    async _call(input) {
        try {
            const owner = await this.solanaKit.resolveAllDomains(input);
            if (!owner) {
                return JSON.stringify({
                    status: "error",
                    message: "Domain not found",
                    code: "DOMAIN_NOT_FOUND"
                });
            }
            return JSON.stringify({
                status: "success",
                message: "Domain resolved successfully",
                owner: owner?.toString()
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "DOMAIN_RESOLUTION_ERROR"
            });
        }
    }
}
exports.SolanaResolveAllDomainsTool = SolanaResolveAllDomainsTool; //# sourceMappingURL=resolve_all_domains.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/alldomains/owned_domains.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaGetOwnedDomains = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaGetOwnedDomains extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_get_owned_domains";
        this.description = `Get all domains owned by a specific wallet address.

  Inputs:
  owner: string, eg "4Be9CvxqHW6BYiRAxW9Q3xu1ycTMWaL5z8NX4HR3ha7t" (required)`;
    }
    async _call(input) {
        try {
            const ownerPubkey = new web3_js_1.PublicKey(input.trim());
            const domains = await this.solanaKit.getOwnedAllDomains(ownerPubkey);
            return JSON.stringify({
                status: "success",
                message: "Owned domains fetched successfully",
                domains
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "FETCH_OWNED_DOMAINS_ERROR"
            });
        }
    }
}
exports.SolanaGetOwnedDomains = SolanaGetOwnedDomains; //# sourceMappingURL=owned_domains.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/alldomains/tld_domains.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaGetOwnedTldDomains = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaGetOwnedTldDomains extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_get_owned_tld_domains";
        this.description = `Get all domains owned by the agent's wallet for a specific TLD.

  Inputs:
  tld: string, eg "bonk" (required)`;
    }
    async _call(input) {
        try {
            const domains = await this.solanaKit.getOwnedDomainsForTLD(input);
            return JSON.stringify({
                status: "success",
                message: "TLD domains fetched successfully",
                domains
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "FETCH_TLD_DOMAINS_ERROR"
            });
        }
    }
}
exports.SolanaGetOwnedTldDomains = SolanaGetOwnedTldDomains; //# sourceMappingURL=tld_domains.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/alldomains/get_all_tld.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaGetAllTlds = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaGetAllTlds extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_get_all_tlds";
        this.description = `Get all active top-level domains (TLDs) in the AllDomains Name Service`;
    }
    async _call() {
        try {
            const tlds = await this.solanaKit.getAllDomainsTLDs();
            return JSON.stringify({
                status: "success",
                message: "TLDs fetched successfully",
                tlds
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "FETCH_TLDS_ERROR"
            });
        }
    }
}
exports.SolanaGetAllTlds = SolanaGetAllTlds; //# sourceMappingURL=get_all_tld.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/alldomains/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/alldomains/resolve_all_domains.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/alldomains/owned_domains.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/alldomains/tld_domains.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/alldomains/get_all_tld.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/dexscreener/token_data_ticker.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaTokenDataByTickerTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaTokenDataByTickerTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_token_data_by_ticker";
        this.description = `Get the token data for a given token ticker

  Inputs: ticker is required.
  ticker: string, eg "USDC" (required)`;
    }
    async _call(input) {
        try {
            const ticker = input.trim();
            const tokenData = await this.solanaKit.getTokenDataByTicker(ticker);
            return JSON.stringify({
                status: "success",
                tokenData
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaTokenDataByTickerTool = SolanaTokenDataByTickerTool; //# sourceMappingURL=token_data_ticker.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/dexscreener/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/dexscreener/token_data_ticker.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/flashUtils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.marketTokenMap = exports.marketSdkInfo = exports.fetchOraclePrice = exports.PriceStatus = exports.CLOSE_POSITION_CU = exports.OPEN_POSITION_CU = exports.ALL_CUSTODIES = exports.ALL_TOKENS = exports.POOL_CONFIGS = void 0;
exports.getNftTradingAccountInfo = getNftTradingAccountInfo;
exports.createPerpClient = createPerpClient;
exports.get_flash_privilege = get_flash_privilege;
const hermes_client_1 = __turbopack_require__("[project]/node_modules/.pnpm/@pythnetwork+hermes-client@1.3.0_axios@1.7.9/node_modules/@pythnetwork/hermes-client/lib/HermesClient.js [app-route] (ecmascript)");
const flash_sdk_1 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/index.js [app-route] (ecmascript)");
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const flash_sdk_2 = __turbopack_require__("[project]/node_modules/.pnpm/flash-sdk@2.25.8_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdecoder@1.0.22_ty_vj3t46chzeevxccaft5x3rtaxe/node_modules/flash-sdk/dist/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const spl_token_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/cjs/index.js [app-route] (ecmascript)");
const POOL_NAMES = [
    "Crypto.1",
    "Virtual.1",
    "Governance.1",
    "Community.1",
    "Community.2",
    "Community.3"
];
const DEFAULT_CLUSTER = "mainnet-beta";
exports.POOL_CONFIGS = POOL_NAMES.map((f)=>flash_sdk_2.PoolConfig.fromIdsByName(f, DEFAULT_CLUSTER));
const DUPLICATE_TOKENS = exports.POOL_CONFIGS.map((f)=>f.tokens).flat();
const tokenMap = new Map();
for (const token of DUPLICATE_TOKENS){
    tokenMap.set(token.symbol, token);
}
exports.ALL_TOKENS = Array.from(tokenMap.values());
exports.ALL_CUSTODIES = exports.POOL_CONFIGS.map((f)=>f.custodies).flat();
const PROGRAM_ID = exports.POOL_CONFIGS[0].programId;
// CU for trade instructions
exports.OPEN_POSITION_CU = 150000;
exports.CLOSE_POSITION_CU = 180000;
const HERMES_URL = "https://hermes.pyth.network"; // Replace with the actual Hermes URL if different
// Create a map of symbol to Pyth price ID
const PRICE_FEED_IDS = exports.ALL_TOKENS.reduce((acc, token)=>{
    acc[token.symbol] = token.pythPriceId;
    return acc;
}, {});
const hermesClient = new hermes_client_1.HermesClient(HERMES_URL, {});
var PriceStatus;
(function(PriceStatus) {
    PriceStatus[PriceStatus["Trading"] = 0] = "Trading";
    PriceStatus[PriceStatus["Unknown"] = 1] = "Unknown";
    PriceStatus[PriceStatus["Halted"] = 2] = "Halted";
    PriceStatus[PriceStatus["Auction"] = 3] = "Auction";
})(PriceStatus || (exports.PriceStatus = PriceStatus = {}));
const fetchOraclePrice = async (symbol)=>{
    const priceFeedId = PRICE_FEED_IDS[symbol];
    if (!priceFeedId) {
        throw new Error(`Price feed ID not found for symbol: ${symbol}`);
    }
    try {
        const hermesPriceFeed = await hermesClient.getPriceFeeds({
            query: symbol,
            filter: "crypto"
        });
        if (!hermesPriceFeed || hermesPriceFeed.length === 0) {
            throw new Error(`No price feed received for ${symbol}`);
        }
        const hemrmesPriceUdpate = await hermesClient.getLatestPriceUpdates([
            priceFeedId
        ], {
            encoding: "hex",
            parsed: true
        });
        if (!hemrmesPriceUdpate.parsed) {
            throw new Error(`No price feed received for ${symbol}`);
        }
        const hermesEma = hemrmesPriceUdpate.parsed[0].ema_price;
        const hermesPrice = hemrmesPriceUdpate.parsed[0].price;
        const hermesPriceOracle = new flash_sdk_1.OraclePrice({
            price: new anchor_1.BN(hermesPrice.price),
            exponent: new anchor_1.BN(hermesPrice.expo),
            confidence: new anchor_1.BN(hermesPrice.conf),
            timestamp: new anchor_1.BN(hermesPrice.publish_time)
        });
        const hermesEmaOracle = new flash_sdk_1.OraclePrice({
            price: new anchor_1.BN(hermesEma.price),
            exponent: new anchor_1.BN(hermesEma.expo),
            confidence: new anchor_1.BN(hermesEma.conf),
            timestamp: new anchor_1.BN(hermesEma.publish_time)
        });
        const token = exports.ALL_TOKENS.find((t)=>t.pythPriceId === priceFeedId);
        if (!token) {
            throw new Error(`Token not found for price feed ID: ${priceFeedId}`);
        }
        const status = !token.isVirtual ? PriceStatus.Trading : PriceStatus.Unknown;
        const pythPriceEntry = {
            price: hermesPriceOracle,
            emaPrice: hermesEmaOracle,
            isStale: false,
            status: status
        };
        return pythPriceEntry;
    } catch (error) {
        console.error(`Error in fetchOraclePrice for ${symbol}:`, error);
        throw error;
    }
};
exports.fetchOraclePrice = fetchOraclePrice;
const marketSdkInfo = {};
exports.marketSdkInfo = marketSdkInfo;
// Loop through POOL_CONFIGS to process each market
exports.POOL_CONFIGS.forEach((poolConfig)=>{
    poolConfig.markets.forEach((market)=>{
        const targetToken = exports.ALL_TOKENS.find((token)=>token.mintKey.toString() === market.targetMint.toString());
        // Find collateral token by matching mintKey
        const collateralToken = exports.ALL_TOKENS.find((token)=>token.mintKey.toString() === market.collateralMint.toString());
        if (targetToken?.symbol && collateralToken?.symbol) {
            marketSdkInfo[market.marketAccount.toString()] = {
                tokenPair: `${targetToken.symbol}/${collateralToken.symbol}`,
                token: targetToken.symbol,
                side: Object.keys(market.side)[0],
                pool: poolConfig.poolName
            };
        }
    });
});
const marketTokenMap = {};
exports.marketTokenMap = marketTokenMap;
// Convert marketSdkInfo into marketTokenMap
Object.entries(marketSdkInfo).forEach(([marketID, info])=>{
    if (!marketTokenMap[info.token]) {
        marketTokenMap[info.token] = {};
    }
    marketTokenMap[info.token][info.side.toLowerCase()] = {
        marketID
    };
});
async function getNftTradingAccountInfo(userPublicKey, perpClient, poolConfig, collateralCustodySymbol) {
    const getNFTReferralAccountPK = (publicKey)=>{
        return web3_js_1.PublicKey.findProgramAddressSync([
            Buffer.from("referral"),
            publicKey.toBuffer()
        ], PROGRAM_ID)[0];
    };
    const nftReferralAccountPK = getNFTReferralAccountPK(userPublicKey);
    const nftReferralAccountInfo = await perpClient.provider.connection.getAccountInfo(nftReferralAccountPK);
    let nftTradingAccountPk = null;
    let nftOwnerRebateTokenAccountPk = null;
    if (nftReferralAccountInfo) {
        const nftReferralAccountData = perpClient.program.coder.accounts.decode("referral", nftReferralAccountInfo.data);
        nftTradingAccountPk = nftReferralAccountData.refererTradingAccount;
        if (nftTradingAccountPk) {
            const nftTradingAccountInfo = await perpClient.provider.connection.getAccountInfo(nftTradingAccountPk);
            if (nftTradingAccountInfo) {
                const nftTradingAccount = perpClient.program.coder.accounts.decode("trading", nftTradingAccountInfo.data);
                nftOwnerRebateTokenAccountPk = (0, spl_token_1.getAssociatedTokenAddressSync)(poolConfig.getTokenFromSymbol(collateralCustodySymbol).mintKey, nftTradingAccount.owner);
                // Check if the account exists
                const accountExists = await perpClient.provider.connection.getAccountInfo(nftOwnerRebateTokenAccountPk);
                if (!accountExists) {
                    console.error("NFT owner rebate token account does not exist and may need to be created");
                }
            }
        }
    }
    return {
        nftReferralAccountPK,
        nftTradingAccountPk,
        nftOwnerRebateTokenAccountPk
    };
}
/**
 * Creates a new PerpetualsClient instance with the given connection and wallet
 * @param connection Solana connection
 * @param wallet Solana wallet
 * @returns PerpetualsClient instance
 */ function createPerpClient(connection, wallet) {
    const provider = new anchor_1.AnchorProvider(connection, new anchor_1.Wallet(wallet), {
        commitment: "confirmed",
        preflightCommitment: "confirmed",
        skipPreflight: true
    });
    return new flash_sdk_2.PerpetualsClient(provider, exports.POOL_CONFIGS[0].programId, exports.POOL_CONFIGS[0].perpComposibilityProgramId, exports.POOL_CONFIGS[0].fbNftRewardProgramId, exports.POOL_CONFIGS[0].rewardDistributionProgram.programId, {});
}
function get_flash_privilege(agent) {
    const FLASH_PRIVILEGE = agent.config.FLASH_PRIVILEGE || "None";
    switch(FLASH_PRIVILEGE.toLowerCase()){
        case "referral":
            return flash_sdk_2.Privilege.Referral;
        case "nft":
            return flash_sdk_2.Privilege.NFT;
        default:
            return flash_sdk_2.Privilege.None;
    }
} //# sourceMappingURL=flashUtils.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/flash/flash_open.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaFlashOpenTrade = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
const flashUtils_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/flashUtils.js [app-route] (ecmascript)");
class SolanaFlashOpenTrade extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_flash_open_trade";
        this.description = `This tool can be used to open a new leveraged trading position on Flash.Trade exchange.

  Inputs ( input is a JSON string ):
  token: string, eg "SOL", "BTC", "ETH" (required)
  type: string, eg "long", "short" (required) 
  collateral: number, eg 10, 100, 1000 (required) 
  leverage: number, eg 5, 10, 20 (required)
  
  Example prompt is Open a 20x leveraged trade for SOL on long side using flash trade with 500 USD as collateral`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            // Validate input parameters
            if (!parsedInput.token) {
                throw new Error("Token is required, received: " + parsedInput.token);
            }
            if (!Object.keys(flashUtils_1.marketTokenMap).includes(parsedInput.token)) {
                throw new Error("Token must be one of " + Object.keys(flashUtils_1.marketTokenMap).join(", ") + ", received: " + parsedInput.token + "\n" + "Please check https://beast.flash.trade/ for the list of supported tokens");
            }
            if (![
                "long",
                "short"
            ].includes(parsedInput.type)) {
                throw new Error('Type must be either "long" or "short", received: ' + parsedInput.type);
            }
            if (!parsedInput.collateral || parsedInput.collateral <= 0) {
                throw new Error("Collateral amount must be positive, received: " + parsedInput.collateral);
            }
            if (!parsedInput.leverage || parsedInput.leverage <= 0) {
                throw new Error("Leverage must be positive, received: " + parsedInput.leverage);
            }
            const tx = await this.solanaKit.flashOpenTrade({
                token: parsedInput.token,
                side: parsedInput.type,
                collateralUsd: parsedInput.collateral,
                leverage: parsedInput.leverage
            });
            return JSON.stringify({
                status: "success",
                message: "Flash trade position opened successfully",
                transaction: tx,
                token: parsedInput.token,
                side: parsedInput.type,
                collateral: parsedInput.collateral,
                leverage: parsedInput.leverage
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaFlashOpenTrade = SolanaFlashOpenTrade; //# sourceMappingURL=flash_open.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/flash/flash_close.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaFlashCloseTrade = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaFlashCloseTrade extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_flash_close_trade";
        this.description = `Close an existing leveraged trading position on Flash.Trade exchange.

  Inputs ( input is a JSON string ):
  token: string, eg "SOL", "BTC", "ETH" (required)
  side: string, eg "long", "short" (required)
  
  Example prompt is Close a 20x leveraged trade for SOL on long side`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            // Validate input parameters
            if (!parsedInput.token) {
                throw new Error("Token is required");
            }
            if (![
                "SOL",
                "BTC",
                "ETH"
            ].includes(parsedInput.token)) {
                throw new Error('Token must be one of ["SOL", "BTC", "ETH"]');
            }
            if (![
                "long",
                "short"
            ].includes(parsedInput.side)) {
                throw new Error('Side must be either "long" or "short"');
            }
            const tx = await this.solanaKit.flashCloseTrade({
                token: parsedInput.token,
                side: parsedInput.side
            });
            return JSON.stringify({
                status: "success",
                message: "Flash trade position closed successfully",
                transaction: tx,
                token: parsedInput.token,
                side: parsedInput.side
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaFlashCloseTrade = SolanaFlashCloseTrade; //# sourceMappingURL=flash_close.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/flash/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/flash/flash_open.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/flash/flash_close.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/gibwork/create_task.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaCreateGibworkTask = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaCreateGibworkTask extends tools_1.Tool {
    constructor(solanaSdk){
        super();
        this.solanaSdk = solanaSdk;
        this.name = "create_gibwork_task";
        this.description = `Create a task on Gibwork.

  Inputs (input is a JSON string):
  title: string, title of the task (required)
  content: string, description of the task (required)
  requirements: string, requirements to complete the task (required)
  tags: string[], list of tags associated with the task (required)
  payer: string, payer address (optional, defaults to agent wallet)
  tokenMintAddress: string, the mint address of the token, e.g., "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN" (required)
  amount: number, payment amount (required)
  `;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            const taskData = await this.solanaSdk.createGibworkTask(parsedInput.title, parsedInput.content, parsedInput.requirements, parsedInput.tags, parsedInput.tokenMintAddress, parsedInput.amount, parsedInput.payer);
            const response = {
                status: "success",
                taskId: taskData.taskId,
                signature: taskData.signature
            };
            return JSON.stringify(response);
        } catch (err) {
            return JSON.stringify({
                status: "error",
                message: err.message,
                code: err.code || "CREATE_TASK_ERROR"
            });
        }
    }
}
exports.SolanaCreateGibworkTask = SolanaCreateGibworkTask; //# sourceMappingURL=create_task.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/gibwork/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/gibwork/create_task.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/jupiter/fetch_price.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaFetchPriceTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
/**
 * Tool to fetch the price of a token in USDC
 */ class SolanaFetchPriceTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_fetch_price";
        this.description = `Fetch the price of a given token in USDC.

  Inputs:
  - tokenId: string, the mint address of the token, e.g., "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN"`;
    }
    async _call(input) {
        try {
            const price = await this.solanaKit.fetchTokenPrice(input.trim());
            return JSON.stringify({
                status: "success",
                tokenId: input.trim(),
                priceInUSDC: price
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaFetchPriceTool = SolanaFetchPriceTool; //# sourceMappingURL=fetch_price.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/jupiter/token_data.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaTokenDataTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaTokenDataTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_token_data";
        this.description = `Get the token data for a given token mint address

  Inputs: mintAddress is required.
  mintAddress: string, eg "So11111111111111111111111111111111111111112" (required)`;
    }
    async _call(input) {
        try {
            const parsedInput = input.trim();
            const tokenData = await this.solanaKit.getTokenDataByAddress(parsedInput);
            return JSON.stringify({
                status: "success",
                tokenData
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaTokenDataTool = SolanaTokenDataTool; //# sourceMappingURL=token_data.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/jupiter/trade.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaTradeTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
class SolanaTradeTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_trade";
        this.description = `This tool can be used to swap tokens to another token ( It uses Jupiter Exchange ).

  Inputs ( input is a JSON string ):
  outputMint: string, eg "So11111111111111111111111111111111111111112" or "SENDdRQtYMWaQrBroBrJ2Q53fgVuq95CV9UPGEvpCxa" (required)
  inputAmount: number, eg 1 or 0.01 (required)
  inputMint?: string, eg "So11111111111111111111111111111111111111112" (optional)
  slippageBps?: number, eg 100 (optional)`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            const tx = await this.solanaKit.trade(new web3_js_1.PublicKey(parsedInput.outputMint), parsedInput.inputAmount, parsedInput.inputMint ? new web3_js_1.PublicKey(parsedInput.inputMint) : new web3_js_1.PublicKey("So11111111111111111111111111111111111111112"), parsedInput.slippageBps);
            return JSON.stringify({
                status: "success",
                message: "Trade executed successfully",
                transaction: tx,
                inputAmount: parsedInput.inputAmount,
                inputToken: parsedInput.inputMint || "SOL",
                outputToken: parsedInput.outputMint
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaTradeTool = SolanaTradeTool; //# sourceMappingURL=trade.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/jupiter/stake.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaStakeTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaStakeTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_stake";
        this.description = `This tool can be used to stake your SOL (Solana), also called as SOL staking or liquid staking.

  Inputs ( input is a JSON string ):
  amount: number, eg 1 or 0.01 (required)`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input) || Number(input);
            const tx = await this.solanaKit.stake(parsedInput.amount);
            return JSON.stringify({
                status: "success",
                message: "Staked successfully",
                transaction: tx,
                amount: parsedInput.amount
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaStakeTool = SolanaStakeTool; //# sourceMappingURL=stake.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/jupiter/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/jupiter/fetch_price.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/jupiter/token_data.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/jupiter/trade.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/jupiter/stake.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/lulo/lend_asset.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaLendAssetTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaLendAssetTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_lend_asset";
        this.description = `Lend idle USDC for yield using Lulo. ( only USDC is supported )

  Inputs (input is a json string):
  amount: number, eg 1, 0.01 (required)`;
    }
    async _call(input) {
        try {
            const amount = JSON.parse(input).amount || input;
            const tx = await this.solanaKit.lendAssets(amount);
            return JSON.stringify({
                status: "success",
                message: "Asset lent successfully",
                transaction: tx,
                amount
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaLendAssetTool = SolanaLendAssetTool; //# sourceMappingURL=lend_asset.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/lulo/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/lulo/lend_asset.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/manifest/manifest_market.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaManifestCreateMarket = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaManifestCreateMarket extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_manifest_create_market";
        this.description = `Manifest market

  Inputs (input is a json string):
  baseMint: string (required)
  quoteMint: string (required)
  `;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const tx = await this.solanaKit.manifestCreateMarket(new web3_js_1.PublicKey(inputFormat.baseMint), new web3_js_1.PublicKey(inputFormat.quoteMint));
            return JSON.stringify({
                status: "success",
                message: "Create manifest market successfully",
                transaction: tx[0],
                marketId: tx[1]
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaManifestCreateMarket = SolanaManifestCreateMarket; //# sourceMappingURL=manifest_market.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/manifest/batch_order.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaBatchOrderTool = void 0;
const manifest_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/manifest/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaBatchOrderTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_batch_order";
        this.description = `Places multiple limit orders in one transaction using Manifest. Submit orders either as a list or pattern:

  1. List format:
  {
    "marketId": "ENhU8LsaR7vDD2G1CsWcsuSGNrih9Cv5WZEk7q9kPapQ",
    "orders": [
      { "quantity": 1, "side": "Buy", "price": 200 },
      { "quantity": 0.5, "side": "Sell", "price": 205 }
    ]
  }

  2. Pattern format:
  {
    "marketId": "ENhU8LsaR7vDD2G1CsWcsuSGNrih9Cv5WZEk7q9kPapQ",
    "pattern": {
      "side": "Buy",
      "totalQuantity": 100,
      "priceRange": { "max": 1.0 },
      "spacing": { "type": "percentage", "value": 1 },
      "numberOfOrders": 5
    }
  }

  Examples:
  - "Place 5 buy orders totaling 100 tokens, 1% apart below $1"
  - "Create 3 sell orders of 10 tokens each between $50-$55"
  - "Place buy orders worth 50 tokens, $0.10 spacing from $0.80"

  Important: All orders must be in one transaction. Combine buy and sell orders into a single pattern or list. Never break the orders down to individual buy or sell orders.`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            let ordersToPlace = [];
            if (!parsedInput.marketId) {
                throw new Error("Market ID is required");
            }
            if (parsedInput.pattern) {
                ordersToPlace = (0, manifest_1.generateOrdersfromPattern)(parsedInput.pattern);
            } else if (Array.isArray(parsedInput.orders)) {
                ordersToPlace = parsedInput.orders;
            } else {
                throw new Error("Either pattern or orders array is required");
            }
            if (ordersToPlace.length === 0) {
                throw new Error("No orders generated or provided");
            }
            ordersToPlace.forEach((order, index)=>{
                if (!order.quantity || !order.side || !order.price) {
                    throw new Error(`Invalid order at index ${index}: quantity, side, and price are required`);
                }
                if (order.side !== "Buy" && order.side !== "Sell") {
                    throw new Error(`Invalid side at index ${index}: must be "Buy" or "Sell"`);
                }
            });
            const tx = await this.solanaKit.batchOrder(new web3_js_1.PublicKey(parsedInput.marketId), parsedInput.orders);
            return JSON.stringify({
                status: "success",
                message: "Batch order executed successfully",
                transaction: tx,
                marketId: parsedInput.marketId,
                orders: parsedInput.orders
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaBatchOrderTool = SolanaBatchOrderTool; //# sourceMappingURL=batch_order.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/manifest/cancel_orders.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaCancelAllOrdersTool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaCancelAllOrdersTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_cancel_all_orders";
        this.description = `This tool can be used to cancel all orders from a Manifest market.

  Input ( input is a JSON string ):
  marketId: string, eg "ENhU8LsaR7vDD2G1CsWcsuSGNrih9Cv5WZEk7q9kPapQ" for SOL/USDC (required)`;
    }
    async _call(input) {
        try {
            const marketId = new web3_js_1.PublicKey(input.trim());
            const tx = await this.solanaKit.cancelAllOrders(marketId);
            return JSON.stringify({
                status: "success",
                message: "Cancel orders successfully",
                transaction: tx,
                marketId
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaCancelAllOrdersTool = SolanaCancelAllOrdersTool; //# sourceMappingURL=cancel_orders.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/manifest/limit_order.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaLimitOrderTool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaLimitOrderTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_limit_order";
        this.description = `This tool can be used to place limit orders using Manifest.

  Do not allow users to place multiple orders with this instruction, use solana_batch_order instead.

  Inputs ( input is a JSON string ):
  marketId: PublicKey, eg "ENhU8LsaR7vDD2G1CsWcsuSGNrih9Cv5WZEk7q9kPapQ" for SOL/USDC (required)
  quantity: number, eg 1 or 0.01 (required)
  side: string, eg "Buy" or "Sell" (required)
  price: number, in tokens eg 200 for SOL/USDC (required)`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            const tx = await this.solanaKit.limitOrder(new web3_js_1.PublicKey(parsedInput.marketId), parsedInput.quantity, parsedInput.side, parsedInput.price);
            return JSON.stringify({
                status: "success",
                message: "Trade executed successfully",
                transaction: tx,
                marketId: parsedInput.marketId,
                quantity: parsedInput.quantity,
                side: parsedInput.side,
                price: parsedInput.price
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaLimitOrderTool = SolanaLimitOrderTool; //# sourceMappingURL=limit_order.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/manifest/withdraw.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaWithdrawAllTool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaWithdrawAllTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_withdraw_all";
        this.description = `This tool can be used to withdraw all funds from a Manifest market.

  Input ( input is a JSON string ):
  marketId: string, eg "ENhU8LsaR7vDD2G1CsWcsuSGNrih9Cv5WZEk7q9kPapQ" for SOL/USDC (required)`;
    }
    async _call(input) {
        try {
            const marketId = new web3_js_1.PublicKey(input.trim());
            const tx = await this.solanaKit.withdrawAll(marketId);
            return JSON.stringify({
                status: "success",
                message: "Withdrew successfully",
                transaction: tx,
                marketId
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaWithdrawAllTool = SolanaWithdrawAllTool; //# sourceMappingURL=withdraw.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/manifest/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/manifest/manifest_market.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/manifest/batch_order.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/manifest/cancel_orders.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/manifest/limit_order.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/manifest/withdraw.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/get_tps.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaTPSCalculatorTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaTPSCalculatorTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_get_tps";
        this.description = "Get the current TPS of the Solana network";
    }
    async _call(_input) {
        try {
            const tps = await this.solanaKit.getTPS();
            return `Solana (mainnet-beta) current transactions per second: ${tps}`;
        } catch (error) {
            return `Error fetching TPS: ${error.message}`;
        }
    }
}
exports.SolanaTPSCalculatorTool = SolanaTPSCalculatorTool; //# sourceMappingURL=get_tps.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/request_funds.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaRequestFundsTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaRequestFundsTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_request_funds";
        this.description = "Request SOL from Solana faucet (devnet/testnet only)";
    }
    async _call(_input) {
        try {
            await this.solanaKit.requestFaucetFunds();
            return JSON.stringify({
                status: "success",
                message: "Successfully requested faucet funds",
                network: this.solanaKit.connection.rpcEndpoint.split("/")[2]
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaRequestFundsTool = SolanaRequestFundsTool; //# sourceMappingURL=request_funds.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/balance.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaBalanceTool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaBalanceTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_balance";
        this.description = `Get the balance of a Solana wallet or token account.

  If you want to get the balance of your wallet, you don't need to provide the tokenAddress.
  If no tokenAddress is provided, the balance will be in SOL.

  Inputs ( input is a JSON string ):
  tokenAddress: string, eg "So11111111111111111111111111111111111111112" (optional)`;
    }
    async _call(input) {
        try {
            const tokenAddress = input ? new web3_js_1.PublicKey(input) : undefined;
            const balance = await this.solanaKit.getBalance(tokenAddress);
            return JSON.stringify({
                status: "success",
                balance,
                token: input || "SOL"
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaBalanceTool = SolanaBalanceTool; //# sourceMappingURL=balance.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/balance_other.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaBalanceOtherTool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaBalanceOtherTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_balance_other";
        this.description = `Get the balance of a Solana wallet or token account which is different from the agent's wallet.

  If no tokenAddress is provided, the SOL balance of the wallet will be returned.

  Inputs ( input is a JSON string ):
  walletAddress: string, eg "GDEkQF7UMr7RLv1KQKMtm8E2w3iafxJLtyXu3HVQZnME" (required)
  tokenAddress: string, eg "SENDdRQtYMWaQrBroBrJ2Q53fgVuq95CV9UPGEvpCxa" (optional)`;
    }
    async _call(input) {
        try {
            const { walletAddress, tokenAddress } = JSON.parse(input);
            const tokenPubKey = tokenAddress ? new web3_js_1.PublicKey(tokenAddress) : undefined;
            const balance = await this.solanaKit.getBalanceOther(new web3_js_1.PublicKey(walletAddress), tokenPubKey);
            return JSON.stringify({
                status: "success",
                balance,
                wallet: walletAddress,
                token: tokenAddress || "SOL"
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaBalanceOtherTool = SolanaBalanceOtherTool; //# sourceMappingURL=balance_other.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/close_empty_accounts.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaCloseEmptyTokenAccounts = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaCloseEmptyTokenAccounts extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "close_empty_token_accounts";
        this.description = `Close all empty spl-token accounts and reclaim the rent`;
    }
    async _call() {
        try {
            const { signature, size } = await this.solanaKit.closeEmptyTokenAccounts();
            return JSON.stringify({
                status: "success",
                message: `${size} accounts closed successfully. ${size === 48 ? "48 accounts can be closed in a single transaction try again to close more accounts" : ""}`,
                signature
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaCloseEmptyTokenAccounts = SolanaCloseEmptyTokenAccounts; //# sourceMappingURL=close_empty_accounts.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/transfer.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaTransferTool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaTransferTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_transfer";
        this.description = `Transfer tokens or SOL to another address ( also called as wallet address ).

  Inputs ( input is a JSON string ):
  to: string, eg "8x2dR8Mpzuz2YqyZyZjUbYWKSWesBo5jMx2Q9Y86udVk" (required)
  amount: number, eg 1 (required)
  mint?: string, eg "So11111111111111111111111111111111111111112" or "SENDdRQtYMWaQrBroBrJ2Q53fgVuq95CV9UPGEvpCxa" (optional)`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            const recipient = new web3_js_1.PublicKey(parsedInput.to);
            const mintAddress = parsedInput.mint ? new web3_js_1.PublicKey(parsedInput.mint) : undefined;
            const tx = await this.solanaKit.transfer(recipient, parsedInput.amount, mintAddress);
            return JSON.stringify({
                status: "success",
                message: "Transfer completed successfully",
                amount: parsedInput.amount,
                recipient: parsedInput.to,
                token: parsedInput.mint || "SOL",
                transaction: tx
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaTransferTool = SolanaTransferTool; //# sourceMappingURL=transfer.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/get_tps.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/request_funds.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/balance.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/balance_other.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/close_empty_accounts.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/transfer.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/agent/create_image.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaCreateImageTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
const agent_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/agent/index.js [app-route] (ecmascript)");
class SolanaCreateImageTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_create_image";
        this.description = "Create an image using OpenAI's DALL-E. Input should be a string prompt for the image.";
    }
    validateInput(input) {
        if (typeof input !== "string" || input.trim().length === 0) {
            throw new Error("Input must be a non-empty string prompt");
        }
    }
    async _call(input) {
        try {
            this.validateInput(input);
            const result = await (0, agent_1.create_image)(this.solanaKit, input.trim());
            return JSON.stringify({
                status: "success",
                message: "Image created successfully",
                ...result
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaCreateImageTool = SolanaCreateImageTool; //# sourceMappingURL=create_image.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/agent/wallet_address.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaGetWalletAddressTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaGetWalletAddressTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_get_wallet_address";
        this.description = `Get the wallet address of the agent`;
    }
    async _call(_input) {
        return this.solanaKit.wallet_address.toString();
    }
}
exports.SolanaGetWalletAddressTool = SolanaGetWalletAddressTool; //# sourceMappingURL=wallet_address.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/agent/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/agent/create_image.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/agent/wallet_address.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/metaplex/deploy_collection.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaDeployCollectionTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaDeployCollectionTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_deploy_collection";
        this.description = `Deploy a new NFT collection on Solana blockchain.

  Inputs (input is a JSON string):
  name: string, eg "My Collection" (required)
  uri: string, eg "https://example.com/collection.json" (required)
  royaltyBasisPoints?: number, eg 500 for 5% (optional)`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            const result = await this.solanaKit.deployCollection(parsedInput);
            return JSON.stringify({
                status: "success",
                message: "Collection deployed successfully",
                collectionAddress: result.collectionAddress.toString(),
                name: parsedInput.name
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaDeployCollectionTool = SolanaDeployCollectionTool; //# sourceMappingURL=deploy_collection.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/metaplex/mint_nft.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaMintNFTTool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaMintNFTTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_mint_nft";
        this.description = `Mint a new NFT in a collection on Solana blockchain.

    Inputs (input is a JSON string):
    collectionMint: string, eg "J1S9H3QjnRtBbbuD4HjPV6RpRhwuk4zKbxsnCHuTgh9w" (required) - The address of the collection to mint into
    name: string, eg "My NFT" (required)
    uri: string, eg "https://example.com/nft.json" (required)
    recipient?: string, eg "9aUn5swQzUTRanaaTwmszxiv89cvFwUCjEBv1vZCoT1u" (optional) - The wallet to receive the NFT, defaults to agent's wallet which is ${this.solanaKit.wallet_address.toString()}`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            const result = await this.solanaKit.mintNFT(new web3_js_1.PublicKey(parsedInput.collectionMint), {
                name: parsedInput.name,
                uri: parsedInput.uri
            }, parsedInput.recipient ? new web3_js_1.PublicKey(parsedInput.recipient) : this.solanaKit.wallet_address);
            return JSON.stringify({
                status: "success",
                message: "NFT minted successfully",
                mintAddress: result.mint.toString(),
                metadata: {
                    name: parsedInput.name,
                    symbol: parsedInput.symbol,
                    uri: parsedInput.uri
                },
                recipient: parsedInput.recipient || result.mint.toString()
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaMintNFTTool = SolanaMintNFTTool; //# sourceMappingURL=mint_nft.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/metaplex/deploy_token.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaDeployTokenTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaDeployTokenTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_deploy_token";
        this.description = `Deploy a new token on Solana blockchain.

  Inputs (input is a JSON string):
  name: string, eg "My Token" (required)
  uri: string, eg "https://example.com/token.json" (required)
  symbol: string, eg "MTK" (required)
  decimals?: number, eg 9 (optional, defaults to 9)
  initialSupply?: number, eg 1000000 (optional)`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            const result = await this.solanaKit.deployToken(parsedInput.name, parsedInput.uri, parsedInput.symbol, parsedInput.decimals, parsedInput.initialSupply);
            return JSON.stringify({
                status: "success",
                message: "Token deployed successfully",
                mintAddress: result.mint.toString(),
                decimals: parsedInput.decimals || 9
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaDeployTokenTool = SolanaDeployTokenTool; //# sourceMappingURL=deploy_token.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/metaplex/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/metaplex/deploy_collection.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/metaplex/mint_nft.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/metaplex/deploy_token.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/openbook/openbook_market.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaOpenbookCreateMarket = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaOpenbookCreateMarket extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_openbook_create_market";
        this.description = `Openbook marketId, required for ammv4

  Inputs (input is a json string):
  baseMint: string (required)
  quoteMint: string (required)
  lotSize: number (required)
  tickSize: number (required)
  `;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const tx = await this.solanaKit.openbookCreateMarket(new web3_js_1.PublicKey(inputFormat.baseMint), new web3_js_1.PublicKey(inputFormat.quoteMint), inputFormat.lotSize, inputFormat.tickSize);
            return JSON.stringify({
                status: "success",
                message: "Openbook market created successfully",
                transaction: tx
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaOpenbookCreateMarket = SolanaOpenbookCreateMarket; //# sourceMappingURL=openbook_market.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/openbook/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/openbook/openbook_market.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/orca_clmm.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaOrcaCreateCLMM = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const decimal_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)");
const orca_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaOrcaCreateCLMM extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "orca_create_clmm";
        this.description = `Create a Concentrated Liquidity Market Maker (CLMM) pool on Orca, the most efficient and capital-optimized CLMM on Solana. This function initializes a CLMM pool but does not add liquidity. You can add liquidity later using a centered position or a single-sided position.

  Inputs (JSON string):
  - mintDeploy: string, the mint of the token you want to deploy (required).
  - mintPair: string, The mint of the token you want to pair the deployed mint with (required).
  - initialPrice: number, initial price of mintA in terms of mintB, e.g., 0.001 (required).
  - feeTier: number, fee tier in bps. Options: 1, 2, 4, 5, 16, 30, 65, 100, 200 (required).`;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const mintA = new web3_js_1.PublicKey(inputFormat.mintDeploy);
            const mintB = new web3_js_1.PublicKey(inputFormat.mintPair);
            const initialPrice = new decimal_js_1.Decimal(inputFormat.initialPrice);
            const feeTier = inputFormat.feeTier;
            if (!feeTier || !(feeTier in orca_1.FEE_TIERS)) {
                throw new Error(`Invalid feeTier. Available options: ${Object.keys(orca_1.FEE_TIERS).join(", ")}`);
            }
            const txId = await this.solanaKit.orcaCreateCLMM(mintA, mintB, initialPrice, feeTier);
            return JSON.stringify({
                status: "success",
                message: "CLMM pool created successfully. Note: No liquidity was added.",
                transaction: txId
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaOrcaCreateCLMM = SolanaOrcaCreateCLMM; //# sourceMappingURL=orca_clmm.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/orca_single_sided_pool.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaOrcaCreateSingleSideLiquidityPool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const decimal_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)");
const orca_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/orca/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaOrcaCreateSingleSideLiquidityPool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "orca_create_single_sided_liquidity_pool";
        this.description = `Create a single-sided liquidity pool on Orca, the most efficient and capital-optimized CLMM platform on Solana.

  This function initializes a single-sided liquidity pool, ideal for community driven project, fair launches, and fundraising. Minimize price impact by setting a narrow price range.

  Inputs (JSON string):
  - depositTokenAmount: number, in units of the deposit token including decimals, e.g., 1000000000 (required).
  - depositTokenMint: string, mint address of the deposit token, e.g., "DepositTokenMintAddress" (required).
  - otherTokenMint: string, mint address of the other token, e.g., "OtherTokenMintAddress" (required).
  - initialPrice: number, initial price of the deposit token in terms of the other token, e.g., 0.001 (required).
  - maxPrice: number, maximum price at which liquidity is added, e.g., 5.0 (required).
  - feeTier: number, fee tier for the pool in bps. Options: 1, 2, 4, 5, 16, 30, 65, 100, 200 (required).`;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const depositTokenAmount = inputFormat.depositTokenAmount;
            const depositTokenMint = new web3_js_1.PublicKey(inputFormat.depositTokenMint);
            const otherTokenMint = new web3_js_1.PublicKey(inputFormat.otherTokenMint);
            const initialPrice = new decimal_js_1.Decimal(inputFormat.initialPrice);
            const maxPrice = new decimal_js_1.Decimal(inputFormat.maxPrice);
            const feeTier = inputFormat.feeTier;
            if (!feeTier || !(feeTier in orca_1.FEE_TIERS)) {
                throw new Error(`Invalid feeTier. Available options: ${Object.keys(orca_1.FEE_TIERS).join(", ")}`);
            }
            const txId = await this.solanaKit.orcaCreateSingleSidedLiquidityPool(depositTokenAmount, depositTokenMint, otherTokenMint, initialPrice, maxPrice, feeTier);
            return JSON.stringify({
                status: "success",
                message: "Single-sided Whirlpool created successfully",
                transaction: txId
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaOrcaCreateSingleSideLiquidityPool = SolanaOrcaCreateSingleSideLiquidityPool; //# sourceMappingURL=orca_single_sided_pool.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/orca_position.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaClosePosition = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaClosePosition extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "orca_close_position";
        this.description = `Closes an existing liquidity position in an Orca Whirlpool. This function fetches the position
  details using the provided mint address and closes the position with a 1% slippage.

  Inputs (JSON string):
  - positionMintAddress: string, the address of the position mint that represents the liquidity position.`;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const positionMintAddress = new web3_js_1.PublicKey(inputFormat.positionMintAddress);
            const txId = await this.solanaKit.orcaClosePosition(positionMintAddress);
            return JSON.stringify({
                status: "success",
                message: "Liquidity position closed successfully.",
                transaction: txId
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaClosePosition = SolanaClosePosition; //# sourceMappingURL=orca_position.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/orca_fetch_positions.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaOrcaFetchPositions = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaOrcaFetchPositions extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "orca_fetch_positions";
        this.description = `Fetch all the liquidity positions in an Orca Whirlpool by owner. Returns an object with positiont mint addresses as keys and position status details as values.`;
    }
    async _call() {
        try {
            const txId = await this.solanaKit.orcaFetchPositions();
            return JSON.stringify({
                status: "success",
                message: "Liquidity positions fetched.",
                transaction: txId
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaOrcaFetchPositions = SolanaOrcaFetchPositions; //# sourceMappingURL=orca_fetch_positions.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/orca_centered_position.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaOrcaOpenCenteredPosition = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const decimal_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaOrcaOpenCenteredPosition extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "orca_open_centered_position_with_liquidity";
        this.description = `Add liquidity to a CLMM by opening a centered position in an Orca Whirlpool, the most efficient liquidity pool on Solana.

  Inputs (JSON string):
  - whirlpoolAddress: string, address of the Orca Whirlpool (required).
  - priceOffsetBps: number, bps offset (one side) from the current pool price, e.g., 500 for 5% (required).
  - inputTokenMint: string, mint address of the deposit token (required).
  - inputAmount: number, amount of the deposit token, e.g., 100.0 (required).`;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const whirlpoolAddress = new web3_js_1.PublicKey(inputFormat.whirlpoolAddress);
            const priceOffsetBps = parseInt(inputFormat.priceOffsetBps, 10);
            const inputTokenMint = new web3_js_1.PublicKey(inputFormat.inputTokenMint);
            const inputAmount = new decimal_js_1.Decimal(inputFormat.inputAmount);
            if (priceOffsetBps < 0) {
                throw new Error("Invalid distanceFromCurrentPriceBps. It must be equal or greater than 0.");
            }
            const txId = await this.solanaKit.orcaOpenCenteredPositionWithLiquidity(whirlpoolAddress, priceOffsetBps, inputTokenMint, inputAmount);
            return JSON.stringify({
                status: "success",
                message: "Centered liquidity position opened successfully.",
                transaction: txId
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaOrcaOpenCenteredPosition = SolanaOrcaOpenCenteredPosition; //# sourceMappingURL=orca_centered_position.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/orca_single_sided_position.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaOrcaOpenSingleSidedPosition = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const decimal_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaOrcaOpenSingleSidedPosition extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "orca_open_single_sided_position";
        this.description = `Add liquidity to a CLMM by opening a single-sided position in an Orca Whirlpool, the most efficient liquidity pool on Solana.

  Inputs (JSON string):
  - whirlpoolAddress: string, address of the Orca Whirlpool (required).
  - distanceFromCurrentPriceBps: number, distance in basis points from the current price for the position (required).
  - widthBps: number, width of the position in basis points (required).
  - inputTokenMint: string, mint address of the deposit token (required).
  - inputAmount: number, amount of the deposit token, e.g., 100.0 (required).`;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const whirlpoolAddress = new web3_js_1.PublicKey(inputFormat.whirlpoolAddress);
            const distanceFromCurrentPriceBps = inputFormat.distanceFromCurrentPriceBps;
            const widthBps = inputFormat.widthBps;
            const inputTokenMint = new web3_js_1.PublicKey(inputFormat.inputTokenMint);
            const inputAmount = new decimal_js_1.Decimal(inputFormat.inputAmount);
            if (distanceFromCurrentPriceBps < 0 || widthBps < 0) {
                throw new Error("Invalid distanceFromCurrentPriceBps or width. It must be equal or greater than 0.");
            }
            const txId = await this.solanaKit.orcaOpenSingleSidedPosition(whirlpoolAddress, distanceFromCurrentPriceBps, widthBps, inputTokenMint, inputAmount);
            return JSON.stringify({
                status: "success",
                message: "Single-sided liquidity position opened successfully.",
                transaction: txId
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaOrcaOpenSingleSidedPosition = SolanaOrcaOpenSingleSidedPosition; //# sourceMappingURL=orca_single_sided_position.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/orca_clmm.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/orca_single_sided_pool.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/orca_position.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/orca_fetch_positions.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/orca_centered_position.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/orca_single_sided_position.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/pumpfun/launch_pumpfun_token.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaPumpfunTokenLaunchTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaPumpfunTokenLaunchTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_launch_pumpfun_token";
        this.description = `This tool can be used to launch a token on Pump.fun,
   do not use this tool for any other purpose, or for creating SPL tokens.
   If the user asks you to chose the parameters, you should generate valid values.
   For generating the image, you can use the solana_create_image tool.

   Inputs:
   tokenName: string, eg "PumpFun Token",
   tokenTicker: string, eg "PUMP",
   description: string, eg "PumpFun Token is a token on the Solana blockchain",
   imageUrl: string, eg "https://i.imgur.com/UFm07Np_d.png`;
    }
    validateInput(input) {
        if (!input.tokenName || typeof input.tokenName !== "string") {
            throw new Error("tokenName is required and must be a string");
        }
        if (!input.tokenTicker || typeof input.tokenTicker !== "string") {
            throw new Error("tokenTicker is required and must be a string");
        }
        if (!input.description || typeof input.description !== "string") {
            throw new Error("description is required and must be a string");
        }
        if (!input.imageUrl || typeof input.imageUrl !== "string") {
            throw new Error("imageUrl is required and must be a string");
        }
        if (input.initialLiquiditySOL !== undefined && typeof input.initialLiquiditySOL !== "number") {
            throw new Error("initialLiquiditySOL must be a number when provided");
        }
    }
    async _call(input) {
        try {
            // Parse and normalize input
            input = input.trim();
            const parsedInput = JSON.parse(input);
            this.validateInput(parsedInput);
            // Launch token with validated input
            await this.solanaKit.launchPumpFunToken(parsedInput.tokenName, parsedInput.tokenTicker, parsedInput.description, parsedInput.imageUrl, {
                twitter: parsedInput.twitter,
                telegram: parsedInput.telegram,
                website: parsedInput.website,
                initialLiquiditySOL: parsedInput.initialLiquiditySOL
            });
            return JSON.stringify({
                status: "success",
                message: "Token launched successfully on Pump.fun",
                tokenName: parsedInput.tokenName,
                tokenTicker: parsedInput.tokenTicker
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaPumpfunTokenLaunchTool = SolanaPumpfunTokenLaunchTool; //# sourceMappingURL=launch_pumpfun_token.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/pumpfun/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/pumpfun/launch_pumpfun_token.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/pyth/pyth_price.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaPythFetchPrice = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaPythFetchPrice extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_pyth_fetch_price";
        this.description = `Fetch the price of a given price feed from Pyth's Hermes service

  Inputs:
  tokenSymbol: string, e.g., BTC for bitcoin`;
    }
    async _call(input) {
        try {
            const priceFeedID = await this.solanaKit.getPythPriceFeedID(input);
            const price = await this.solanaKit.getPythPrice(priceFeedID);
            const response = {
                status: "success",
                tokenSymbol: input,
                priceFeedID,
                price
            };
            return JSON.stringify(response);
        } catch (error) {
            const response = {
                status: "error",
                tokenSymbol: input,
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            };
            return JSON.stringify(response);
        }
    }
}
exports.SolanaPythFetchPrice = SolanaPythFetchPrice; //# sourceMappingURL=pyth_price.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/pyth/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/pyth/pyth_price.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/raydium/raydium_amm.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaRaydiumCreateAmmV4 = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaRaydiumCreateAmmV4 extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "raydium_create_ammV4";
        this.description = `Raydium's Legacy AMM that requires an OpenBook marketID

  Inputs (input is a json string):
  marketId: string (required)
  baseAmount: number(int), eg: 111111 (required)
  quoteAmount: number(int), eg: 111111 (required)
  startTime: number(seconds), eg: now number or zero (required)
  `;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const tx = await this.solanaKit.raydiumCreateAmmV4(new web3_js_1.PublicKey(inputFormat.marketId), new anchor_1.BN(inputFormat.baseAmount), new anchor_1.BN(inputFormat.quoteAmount), new anchor_1.BN(inputFormat.startTime));
            return JSON.stringify({
                status: "success",
                message: "Raydium amm v4 pool created successfully",
                transaction: tx
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaRaydiumCreateAmmV4 = SolanaRaydiumCreateAmmV4; //# sourceMappingURL=raydium_amm.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/raydium/raydium_clmm.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaRaydiumCreateClmm = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const decimal_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaRaydiumCreateClmm extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "raydium_create_clmm";
        this.description = `Concentrated liquidity market maker, custom liquidity ranges, increased capital efficiency

  Inputs (input is a json string):
  mint1: string (required)
  mint2: string (required)
  configId: string (required) stores pool info, id, index, protocolFeeRate, tradeFeeRate, tickSpacing, fundFeeRate
  initialPrice: number, eg: 123.12 (required)
  startTime: number(seconds), eg: now number or zero (required)
  `;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const tx = await this.solanaKit.raydiumCreateClmm(new web3_js_1.PublicKey(inputFormat.mint1), new web3_js_1.PublicKey(inputFormat.mint2), new web3_js_1.PublicKey(inputFormat.configId), new decimal_js_1.Decimal(inputFormat.initialPrice), new anchor_1.BN(inputFormat.startTime));
            return JSON.stringify({
                status: "success",
                message: "Raydium clmm pool created successfully",
                transaction: tx
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaRaydiumCreateClmm = SolanaRaydiumCreateClmm; //# sourceMappingURL=raydium_clmm.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/raydium/raydium_cpmm.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaRaydiumCreateCpmm = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const anchor_1 = __turbopack_require__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.29.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaRaydiumCreateCpmm extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "raydium_create_cpmm";
        this.description = `Raydium's newest CPMM, does not require marketID, supports Token 2022 standard

  Inputs (input is a json string):
  mint1: string (required)
  mint2: string (required)
  configId: string (required), stores pool info, index, protocolFeeRate, tradeFeeRate, fundFeeRate, createPoolFee
  mintAAmount: number(int), eg: 1111 (required)
  mintBAmount: number(int), eg: 2222 (required)
  startTime: number(seconds), eg: now number or zero (required)
  `;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const tx = await this.solanaKit.raydiumCreateCpmm(new web3_js_1.PublicKey(inputFormat.mint1), new web3_js_1.PublicKey(inputFormat.mint2), new web3_js_1.PublicKey(inputFormat.configId), new anchor_1.BN(inputFormat.mintAAmount), new anchor_1.BN(inputFormat.mintBAmount), new anchor_1.BN(inputFormat.startTime));
            return JSON.stringify({
                status: "success",
                message: "Raydium cpmm pool created successfully",
                transaction: tx
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaRaydiumCreateCpmm = SolanaRaydiumCreateCpmm; //# sourceMappingURL=raydium_cpmm.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/raydium/types.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
}); //# sourceMappingURL=types.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/raydium/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/raydium/raydium_amm.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/raydium/raydium_clmm.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/raydium/raydium_cpmm.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/raydium/types.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/rugcheck/token_report_summary.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaFetchTokenReportSummaryTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaFetchTokenReportSummaryTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_fetch_token_report_summary";
        this.description = `Fetches a summary report for a specific token from RugCheck.
  Inputs:
  - mint: string, the mint address of the token, e.g., "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN" (required).`;
    }
    async _call(input) {
        try {
            const mint = input.trim();
            const report = await this.solanaKit.fetchTokenReportSummary(mint);
            return JSON.stringify({
                status: "success",
                message: "Token report summary fetched successfully",
                report
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "FETCH_TOKEN_REPORT_SUMMARY_ERROR"
            });
        }
    }
}
exports.SolanaFetchTokenReportSummaryTool = SolanaFetchTokenReportSummaryTool; //# sourceMappingURL=token_report_summary.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/rugcheck/token_report_detailed.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaFetchTokenDetailedReportTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaFetchTokenDetailedReportTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_fetch_token_detailed_report";
        this.description = `Fetches a detailed report for a specific token from RugCheck.
  Inputs:
  - mint: string, the mint address of the token, e.g., "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN" (required).`;
    }
    async _call(input) {
        try {
            const mint = input.trim();
            const detailedReport = await this.solanaKit.fetchTokenDetailedReport(mint);
            return JSON.stringify({
                status: "success",
                message: "Detailed token report fetched successfully",
                report: detailedReport
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "FETCH_TOKEN_DETAILED_REPORT_ERROR"
            });
        }
    }
}
exports.SolanaFetchTokenDetailedReportTool = SolanaFetchTokenDetailedReportTool; //# sourceMappingURL=token_report_detailed.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/rugcheck/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/rugcheck/token_report_summary.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/rugcheck/token_report_detailed.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sendarcade/rock_paper_scissors.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaRockPaperScissorsTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaRockPaperScissorsTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "rock_paper_scissors";
        this.description = `Play rock paper scissors to win SEND coins.

  Inputs (input is a JSON string):
  choice: string, either "rock", "paper", or "scissors" (required)
  amount: number, amount of SOL to play with - must be 0.1, 0.01, or 0.005 SOL (required)`;
    }
    validateInput(input) {
        if (input.choice !== undefined) {
            throw new Error("choice is required.");
        }
        if (input.amount !== undefined && (typeof input.spaceKB !== "number" || input.spaceKB <= 0)) {
            throw new Error("amount must be a positive number when provided");
        }
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            this.validateInput(parsedInput);
            const result = await this.solanaKit.rockPaperScissors(Number(parsedInput['"amount"']), parsedInput['"choice"'].replace(/^"|"$/g, ""));
            return JSON.stringify({
                status: "success",
                message: result
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaRockPaperScissorsTool = SolanaRockPaperScissorsTool; //# sourceMappingURL=rock_paper_scissors.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sendarcade/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sendarcade/rock_paper_scissors.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solayer/restake.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaRestakeTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaRestakeTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_restake";
        this.description = `This tool can be used to restake your SOL on Solayer to receive Solayer SOL (sSOL) as a Liquid Staking Token (LST).

  Inputs:
  amount: number, eg 1 or 0.01 (required)`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input) || Number(input);
            const tx = await this.solanaKit.restake(parsedInput.amount);
            return JSON.stringify({
                status: "success",
                message: "Staked successfully",
                transaction: tx,
                amount: parsedInput.amount
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaRestakeTool = SolanaRestakeTool; //# sourceMappingURL=restake.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solayer/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solayer/restake.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/tensor/list_nft.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaListNFTForSaleTool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaListNFTForSaleTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_list_nft_for_sale";
        this.description = `List an NFT for sale on Tensor Trade.

  Inputs (input is a JSON string):
  nftMint: string, the mint address of the NFT (required)
  price: number, price in SOL (required)`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            // Validate NFT ownership first
            const nftAccount = await this.solanaKit.connection.getTokenAccountsByOwner(this.solanaKit.wallet_address, {
                mint: new web3_js_1.PublicKey(parsedInput.nftMint)
            });
            if (nftAccount.value.length === 0) {
                return JSON.stringify({
                    status: "error",
                    message: "NFT not found in wallet. Please make sure you own this NFT.",
                    code: "NFT_NOT_FOUND"
                });
            }
            const tx = await this.solanaKit.tensorListNFT(new web3_js_1.PublicKey(parsedInput.nftMint), parsedInput.price);
            return JSON.stringify({
                status: "success",
                message: "NFT listed for sale successfully",
                transaction: tx,
                price: parsedInput.price,
                nftMint: parsedInput.nftMint
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaListNFTForSaleTool = SolanaListNFTForSaleTool; //# sourceMappingURL=list_nft.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/tensor/cancel_listing.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaCancelNFTListingTool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaCancelNFTListingTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_cancel_nft_listing";
        this.description = `Cancel an NFT listing on Tensor Trade.

  Inputs (input is a JSON string):
  nftMint: string, the mint address of the NFT (required)`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            const tx = await this.solanaKit.tensorCancelListing(new web3_js_1.PublicKey(parsedInput.nftMint));
            return JSON.stringify({
                status: "success",
                message: "NFT listing cancelled successfully",
                transaction: tx,
                nftMint: parsedInput.nftMint
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaCancelNFTListingTool = SolanaCancelNFTListingTool; //# sourceMappingURL=cancel_listing.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/tensor/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/tensor/list_nft.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/tensor/cancel_listing.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/3land/create_single.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Solana3LandCreateSingle = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class Solana3LandCreateSingle extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "3land_minting_tool";
        this.description = `Creates an NFT and lists it on 3.land's website

  Inputs:
  privateKey (required): represents the privateKey of the wallet - can be an array of numbers, Uint8Array or base58 string
  collectionAccount (optional): represents the account for the nft collection
  itemName (required): the name of the NFT
  sellerFee (required): the fee of the seller
  itemAmount (required): the amount of the NFTs that can be minted
  itemDescription (required): the description of the NFT
  traits (required): the traits of the NFT [{trait_type: string, value: string}]
  price (required): the price of the item, if is 0 the listing will be free
  mainImageUrl (required): the main image of the NFT
  coverImageUrl (optional): the cover image of the NFT
  splHash (optional): the hash of the spl token, if not provided listing will be in $SOL
  isMainnet (required): defines is the tx takes places in mainnet
  `;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const privateKey = inputFormat.privateKey;
            const isMainnet = inputFormat.isMainnet;
            const optionsWithBase58 = {
                ...privateKey && {
                    privateKey
                },
                ...isMainnet && {
                    isMainnet
                }
            };
            const collectionAccount = inputFormat.collectionAccount;
            const itemName = inputFormat?.itemName;
            const sellerFee = inputFormat?.sellerFee;
            const itemAmount = inputFormat?.itemAmount;
            const itemSymbol = inputFormat?.itemSymbol;
            const itemDescription = inputFormat?.itemDescription;
            const traits = inputFormat?.traits;
            const price = inputFormat?.price;
            const mainImageUrl = inputFormat?.mainImageUrl;
            const coverImageUrl = inputFormat?.coverImageUrl;
            const splHash = inputFormat?.splHash;
            const createItemOptions = {
                ...itemName && {
                    itemName
                },
                ...sellerFee && {
                    sellerFee
                },
                ...itemAmount && {
                    itemAmount
                },
                ...itemSymbol && {
                    itemSymbol
                },
                ...itemDescription && {
                    itemDescription
                },
                ...traits && {
                    traits
                },
                ...price && {
                    price
                },
                ...mainImageUrl && {
                    mainImageUrl
                },
                ...coverImageUrl && {
                    coverImageUrl
                },
                ...splHash && {
                    splHash
                }
            };
            if (!collectionAccount) {
                throw new Error("Collection account is required");
            }
            const tx = await this.solanaKit.create3LandNft(optionsWithBase58, collectionAccount, createItemOptions, isMainnet);
            return JSON.stringify({
                status: "success",
                message: `Created listing successfully ${tx}`,
                transaction: tx
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.Solana3LandCreateSingle = Solana3LandCreateSingle; //# sourceMappingURL=create_single.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/3land/create_collection.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Solana3LandCreateCollection = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class Solana3LandCreateCollection extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "3land_minting_tool";
        this.description = `Creates an NFT Collection that you can visit on 3.land's website (3.land/collection/{collectionAccount})
  
  Inputs:
  privateKey (required): represents the privateKey of the wallet - can be an array of numbers, Uint8Array or base58 string
  isMainnet (required): defines is the tx takes places in mainnet
  collectionSymbol (required): the symbol of the collection
  collectionName (required): the name of the collection
  collectionDescription (required): the description of the collection
  mainImageUrl (required): the image of the collection
  coverImageUrl (optional): the cover image of the collection
  `;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const privateKey = inputFormat.privateKey;
            const isMainnet = inputFormat.isMainnet;
            const optionsWithBase58 = {
                ...privateKey && {
                    privateKey
                },
                ...isMainnet && {
                    isMainnet
                }
            };
            const collectionSymbol = inputFormat?.collectionSymbol;
            const collectionName = inputFormat?.collectionName;
            const collectionDescription = inputFormat?.collectionDescription;
            const mainImageUrl = inputFormat?.mainImageUrl;
            const coverImageUrl = inputFormat?.coverImageUrl;
            const collectionOpts = {
                ...collectionSymbol && {
                    collectionSymbol
                },
                ...collectionName && {
                    collectionName
                },
                ...collectionDescription && {
                    collectionDescription
                },
                ...mainImageUrl && {
                    mainImageUrl
                },
                ...coverImageUrl && {
                    coverImageUrl
                }
            };
            const tx = await this.solanaKit.create3LandCollection(optionsWithBase58, collectionOpts);
            return JSON.stringify({
                status: "success",
                message: `Created Collection successfully ${tx}`,
                transaction: tx
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.Solana3LandCreateCollection = Solana3LandCreateCollection; //# sourceMappingURL=create_collection.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/3land/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/3land/create_single.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/3land/create_collection.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/tiplink/tiplink.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaTipLinkTool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaTipLinkTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_tiplink";
        this.description = `Create a TipLink for transferring SOL or SPL tokens.
  Input is a JSON string with:
  - amount: number (required) - Amount to transfer
  - splmintAddress: string (optional) - SPL token mint address`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            if (!parsedInput.amount) {
                throw new Error("Amount is required");
            }
            const amount = parseFloat(parsedInput.amount);
            const splmintAddress = parsedInput.splmintAddress ? new web3_js_1.PublicKey(parsedInput.splmintAddress) : undefined;
            const { url, signature } = await this.solanaKit.createTiplink(amount, splmintAddress);
            return JSON.stringify({
                status: "success",
                url,
                signature,
                amount,
                tokenType: splmintAddress ? "SPL" : "SOL",
                message: `TipLink created successfully`
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaTipLinkTool = SolanaTipLinkTool; //# sourceMappingURL=tiplink.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/tiplink/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/tiplink/tiplink.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sns/register_domain.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaRegisterDomainTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaRegisterDomainTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_register_domain";
        this.description = `Register a .sol domain name for your wallet.

  Inputs:
  name: string, eg "pumpfun.sol" (required)
  spaceKB: number, eg 1 (optional, default is 1)
  `;
    }
    validateInput(input) {
        if (!input.name || typeof input.name !== "string") {
            throw new Error("name is required and must be a string");
        }
        if (input.spaceKB !== undefined && (typeof input.spaceKB !== "number" || input.spaceKB <= 0)) {
            throw new Error("spaceKB must be a positive number when provided");
        }
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            this.validateInput(parsedInput);
            const tx = await this.solanaKit.registerDomain(parsedInput.name, parsedInput.spaceKB || 1);
            return JSON.stringify({
                status: "success",
                message: "Domain registered successfully",
                transaction: tx,
                domain: `${parsedInput.name}.sol`,
                spaceKB: parsedInput.spaceKB || 1
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaRegisterDomainTool = SolanaRegisterDomainTool; //# sourceMappingURL=register_domain.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sns/resolve_domain.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaResolveDomainTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaResolveDomainTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_resolve_domain";
        this.description = `Resolve ONLY .sol domain names to a Solana PublicKey.
  This tool is exclusively for .sol domains.
  DO NOT use this for other domain types like .blink, .bonk, etc.

  Inputs:
  domain: string, eg "pumpfun.sol" (required)
  `;
    }
    async _call(input) {
        try {
            const domain = input.trim();
            const publicKey = await this.solanaKit.resolveSolDomain(domain);
            return JSON.stringify({
                status: "success",
                message: "Domain resolved successfully",
                publicKey: publicKey.toBase58()
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaResolveDomainTool = SolanaResolveDomainTool; //# sourceMappingURL=resolve_domain.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sns/get_domain.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaGetDomainTool = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaGetDomainTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_get_domain";
        this.description = `Retrieve the .sol domain associated for a given account address.

  Inputs:
  account: string, eg "4Be9CvxqHW6BYiRAxW9Q3xu1ycTMWaL5z8NX4HR3ha7t" (required)
  `;
    }
    async _call(input) {
        try {
            const account = new web3_js_1.PublicKey(input.trim());
            const domain = await this.solanaKit.getPrimaryDomain(account);
            return JSON.stringify({
                status: "success",
                message: "Primary domain retrieved successfully",
                domain
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaGetDomainTool = SolanaGetDomainTool; //# sourceMappingURL=get_domain.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sns/main_domain.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaGetMainDomain = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaGetMainDomain extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_get_main_domain";
        this.description = `Get the main/favorite domain for a given wallet address.

  Inputs:
  owner: string, eg "4Be9CvxqHW6BYiRAxW9Q3xu1ycTMWaL5z8NX4HR3ha7t" (required)`;
    }
    async _call(input) {
        try {
            const ownerPubkey = new web3_js_1.PublicKey(input.trim());
            const mainDomain = await this.solanaKit.getMainAllDomainsDomain(ownerPubkey);
            return JSON.stringify({
                status: "success",
                message: "Main domain fetched successfully",
                domain: mainDomain
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "FETCH_MAIN_DOMAIN_ERROR"
            });
        }
    }
}
exports.SolanaGetMainDomain = SolanaGetMainDomain; //# sourceMappingURL=main_domain.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sns/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sns/register_domain.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sns/resolve_domain.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sns/get_domain.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sns/main_domain.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/lightprotocol/compressed_airdrop.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaCompressedAirdropTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaCompressedAirdropTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_compressed_airdrop";
        this.description = `Airdrop SPL tokens with ZK Compression (also called as airdropping tokens)

  Inputs (input is a JSON string):
  mintAddress: string, the mint address of the token, e.g., "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN" (required)
  amount: number, the amount of tokens to airdrop per recipient, e.g., 42 (required)
  decimals: number, the decimals of the token, e.g., 6 (required)
  recipients: string[], the recipient addresses, e.g., ["1nc1nerator11111111111111111111111111111111"] (required)
  priorityFeeInLamports: number, the priority fee in lamports. Default is 30_000. (optional)
  shouldLog: boolean, whether to log progress to stdout. Default is false. (optional)`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            const txs = await this.solanaKit.sendCompressedAirdrop(parsedInput.mintAddress, parsedInput.amount, parsedInput.decimals, parsedInput.recipients, parsedInput.priorityFeeInLamports || 30000, parsedInput.shouldLog || false);
            return JSON.stringify({
                status: "success",
                message: `Airdropped ${parsedInput.amount} tokens to ${parsedInput.recipients.length} recipients.`,
                transactionHashes: txs
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaCompressedAirdropTool = SolanaCompressedAirdropTool; //# sourceMappingURL=compressed_airdrop.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/lightprotocol/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/lightprotocol/compressed_airdrop.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/approve_proposal.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaApproveProposal2by2Multisig = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaApproveProposal2by2Multisig extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "approve_proposal_2by2_multisig";
        this.description = `Approve a proposal to transfer funds from a 2-of-2 multisig account on Solana with the user and the agent, where both approvals will be required to run the transactions.
  
  If proposalIndex is not provided, the latest index will automatically be fetched and used.

  Inputs (JSON string):
  - proposalIndex: number, the index of the proposal (optional).`;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const proposalIndex = inputFormat.proposalIndex ?? undefined;
            const tx = await this.solanaKit.approveMultisigProposal(proposalIndex);
            return JSON.stringify({
                status: "success",
                message: "Proposal approved successfully",
                transaction: tx,
                proposalIndex: proposalIndex.toString()
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "APPROVE_PROPOSAL_2BY2_MULTISIG_ERROR"
            });
        }
    }
}
exports.SolanaApproveProposal2by2Multisig = SolanaApproveProposal2by2Multisig; //# sourceMappingURL=approve_proposal.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/create_multisig.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaCreate2by2Multisig = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
class SolanaCreate2by2Multisig extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "create_2by2_multisig";
        this.description = `Create a 2-of-2 multisig account on Solana with the user and the agent, where both approvals will be required to run the transactions.
  
  Note: For one AI agent, only one 2-by-2 multisig can be created as it is pair-wise.

  Inputs (JSON string):
  - creator: string, the public key of the creator (required).`;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const creator = new web3_js_1.PublicKey(inputFormat.creator);
            const multisig = await this.solanaKit.createSquadsMultisig(creator);
            return JSON.stringify({
                status: "success",
                message: "2-by-2 multisig account created successfully",
                multisig
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "CREATE_2BY2_MULTISIG_ERROR"
            });
        }
    }
}
exports.SolanaCreate2by2Multisig = SolanaCreate2by2Multisig; //# sourceMappingURL=create_multisig.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/create_proposal.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaCreateProposal2by2Multisig = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaCreateProposal2by2Multisig extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "create_proposal_2by2_multisig";
        this.description = `Create a proposal to transfer funds from a 2-of-2 multisig account on Solana with the user and the agent, where both approvals will be required to run the transactions.
  
  If transactionIndex is not provided, the latest index will automatically be fetched and used.

  Inputs (JSON string):
  - transactionIndex: number, the index of the transaction (optional).`;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const transactionIndex = inputFormat.transactionIndex ?? undefined;
            const tx = await this.solanaKit.createMultisigProposal(transactionIndex);
            return JSON.stringify({
                status: "success",
                message: "Proposal created successfully",
                transaction: tx,
                transactionIndex: transactionIndex?.toString()
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "CREATE_PROPOSAL_2BY2_MULTISIG_ERROR"
            });
        }
    }
}
exports.SolanaCreateProposal2by2Multisig = SolanaCreateProposal2by2Multisig; //# sourceMappingURL=create_proposal.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/deposit_to_multisig.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaDepositTo2by2Multisig = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
const decimal_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)"));
class SolanaDepositTo2by2Multisig extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "deposit_to_2by2_multisig";
        this.description = `Deposit funds to a 2-of-2 multisig account on Solana with the user and the agent, where both approvals will be required to run the transactions.

  Inputs (JSON string):
  - amount: number, the amount to deposit in SOL (required).`;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const amount = new decimal_js_1.default(inputFormat.amount);
            const tx = await this.solanaKit.depositToMultisig(amount.toNumber());
            return JSON.stringify({
                status: "success",
                message: "Funds deposited to 2-by-2 multisig account successfully",
                transaction: tx,
                amount: amount.toString()
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "DEPOSIT_TO_2BY2_MULTISIG_ERROR"
            });
        }
    }
}
exports.SolanaDepositTo2by2Multisig = SolanaDepositTo2by2Multisig; //# sourceMappingURL=deposit_to_multisig.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/execute_proposal.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaExecuteProposal2by2Multisig = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaExecuteProposal2by2Multisig extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "execute_proposal_2by2_multisig";
        this.description = `Execute a proposal/transaction to transfer funds from a 2-of-2 multisig account on Solana with the user and the agent, where both approvals will be required to run the transactions.
  
  If proposalIndex is not provided, the latest index will automatically be fetched and used.

  Inputs (JSON string):
  - proposalIndex: number, the index of the proposal (optional).`;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const proposalIndex = inputFormat.proposalIndex ?? undefined;
            const tx = await this.solanaKit.executeMultisigTransaction(proposalIndex);
            return JSON.stringify({
                status: "success",
                message: "Proposal executed successfully",
                transaction: tx,
                proposalIndex: proposalIndex.toString()
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "EXECUTE_PROPOSAL_2BY2_MULTISIG_ERROR"
            });
        }
    }
}
exports.SolanaExecuteProposal2by2Multisig = SolanaExecuteProposal2by2Multisig; //# sourceMappingURL=execute_proposal.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/reject_proposal.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaRejectProposal2by2Multisig = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaRejectProposal2by2Multisig extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "reject_proposal_2by2_multisig";
        this.description = `Reject a proposal to transfer funds from a 2-of-2 multisig account on Solana with the user and the agent, where both approvals will be required to run the transactions.
  
  If proposalIndex is not provided, the latest index will automatically be fetched and used.

  Inputs (JSON string):
  - proposalIndex: number, the index of the proposal (optional).`;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const proposalIndex = inputFormat.proposalIndex ?? undefined;
            const tx = await this.solanaKit.rejectMultisigProposal(proposalIndex);
            return JSON.stringify({
                status: "success",
                message: "Proposal rejected successfully",
                transaction: tx,
                proposalIndex: proposalIndex.toString()
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "REJECT_PROPOSAL_2BY2_MULTISIG_ERROR"
            });
        }
    }
}
exports.SolanaRejectProposal2by2Multisig = SolanaRejectProposal2by2Multisig; //# sourceMappingURL=reject_proposal.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/transfer_from_multisig.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaTransferFrom2by2Multisig = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const decimal_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)"));
class SolanaTransferFrom2by2Multisig extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "transfer_from_2by2_multisig";
        this.description = `Create a transaction to transfer funds from a 2-of-2 multisig account on Solana with the user and the agent, where both approvals will be required to run the transactions.

  Inputs (JSON string):
  - amount: number, the amount to transfer in SOL (required).
  - recipient: string, the public key of the recipient (required).`;
    }
    async _call(input) {
        try {
            const inputFormat = JSON.parse(input);
            const amount = new decimal_js_1.default(inputFormat.amount);
            const recipient = new web3_js_1.PublicKey(inputFormat.recipient);
            const tx = await this.solanaKit.transferFromMultisig(amount.toNumber(), recipient);
            return JSON.stringify({
                status: "success",
                message: "Transaction added to 2-by-2 multisig account successfully",
                transaction: tx,
                amount: amount.toString(),
                recipient: recipient.toString()
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "TRANSFER_FROM_2BY2_MULTISIG_ERROR"
            });
        }
    }
}
exports.SolanaTransferFrom2by2Multisig = SolanaTransferFrom2by2Multisig; //# sourceMappingURL=transfer_from_multisig.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/approve_proposal.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/create_multisig.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/create_proposal.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/deposit_to_multisig.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/execute_proposal.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/reject_proposal.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/transfer_from_multisig.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/create_webhook.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaHeliusWebhookTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaHeliusWebhookTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "create_helius_webhook";
        this.description = `Creates a Helius Webhook that listens to specified account addresses.
    Inputs (input is a JSON string):
    accountAddresses: string[] | string, 
      e.g. ["BVdNLvyG2DNiWAXBE9qAmc4MTQXymd5Bzfo9xrQSUzVP","Eo2ciguhMLmcTWXELuEQPdu7DWZt67LHXb2rdHZUbot7"]
      or "BVdNLvyG2DNiWAXBE9qAmc4MTQXymd5Bzfo9xrQSUzVP,Eo2ciguhMLmcTWXELuEQPdu7DWZt67LHXb2rdHZUbot7"
    webhookURL: string, e.g. "https://TestServer.test.repl.co/webhooks"`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            let accountAddresses = [];
            if (!parsedInput.accountAddresses) {
                throw new Error('Missing "accountAddresses" property in input JSON.');
            }
            if (Array.isArray(parsedInput.accountAddresses)) {
                accountAddresses = parsedInput.accountAddresses.map((addr)=>addr.trim());
            } else if (typeof parsedInput.accountAddresses === "string") {
                accountAddresses = parsedInput.accountAddresses.split(",").map((addr)=>addr.trim());
            } else {
                throw new Error('Invalid type for "accountAddresses". Expected array or comma-separated string.');
            }
            const webhookURL = parsedInput.webhookURL;
            if (!webhookURL) {
                throw new Error('Invalid input. Expected a "webhookURL" property in the JSON.');
            }
            const result = await this.solanaKit.CreateWebhook(accountAddresses, webhookURL);
            // Return success in JSON
            return JSON.stringify({
                status: "success",
                message: "Helius Webhook created successfully",
                webhookURL: result.webhookURL,
                webhookID: result.webhookID
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaHeliusWebhookTool = SolanaHeliusWebhookTool; //# sourceMappingURL=create_webhook.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/delete_webhook.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaDeleteHeliusWebhookTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaDeleteHeliusWebhookTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "delete_helius_webhook";
        this.description = `Deletes a Helius Webhook by its ID.
  Inputs (input is a JSON string):
    webhookID: string, e.g. "1ed4244d-a591-4854-ac31-cc28d40b8255"`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            const webhookID = parsedInput.webhookID;
            if (!webhookID || typeof webhookID !== "string") {
                throw new Error('Invalid input. Expected a "webhookID" property in the JSON.');
            }
            const result = await this.solanaKit.deleteWebhook(webhookID);
            return JSON.stringify({
                status: "success",
                message: "Helius Webhook deleted successfully",
                data: result
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaDeleteHeliusWebhookTool = SolanaDeleteHeliusWebhookTool; //# sourceMappingURL=delete_webhook.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/get_all_assets.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaGetAllAssetsByOwner = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
class SolanaGetAllAssetsByOwner extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_get_all_assets_by_owner";
        this.description = `Get all assets owned by a specific wallet address.
    Inputs:
    - owner: string, the wallet address of the owner, e.g., "4Be9CvxqHW6BYiRAxW9Q3xu1ycTMWaL5z8NX4HR3ha7t" (required)
    - limit: number, the maximum number of assets to retrieve (optional)`;
    }
    async _call(input) {
        try {
            const { owner, limit } = JSON.parse(input);
            const ownerPubkey = new web3_js_1.PublicKey(owner);
            const assets = await this.solanaKit.getAllAssetsbyOwner(ownerPubkey, limit);
            return JSON.stringify({
                status: "success",
                message: "Assets retrieved successfully",
                assets: assets
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaGetAllAssetsByOwner = SolanaGetAllAssetsByOwner; //# sourceMappingURL=get_all_assets.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/get_webhook.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaGetHeliusWebhookTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaGetHeliusWebhookTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "get_helius_webhook";
        this.description = `Retrieves a Helius Webhook by its ID.
  Inputs (input is a JSON string):
    webhookID: string, e.g. "1ed4244d-a591-4854-ac31-cc28d40b8255"`;
    }
    async _call(input) {
        try {
            const parsedInput = JSON.parse(input);
            const webhookID = parsedInput.webhookID;
            if (!webhookID || typeof webhookID !== "string") {
                throw new Error('Invalid input. Expected a "webhookID" property in the JSON.');
            }
            const result = await this.solanaKit.getWebhook(webhookID);
            return JSON.stringify({
                status: "success",
                message: "Helius Webhook retrieved successfully",
                wallet: result.wallet,
                webhookURL: result.webhookURL,
                transactionTypes: result.transactionTypes,
                accountAddresses: result.accountAddresses,
                webhookType: result.webhookType
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaGetHeliusWebhookTool = SolanaGetHeliusWebhookTool; //# sourceMappingURL=get_webhook.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/parse_transaction.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaParseTransactionHeliusTool = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
class SolanaParseTransactionHeliusTool extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_parse_transaction_helius";
        this.description = `Parse a Solana transaction using Helius API.
    Inputs:
    - transactionId: string, the ID of the transaction to parse, e.g., "5h3k...9d2k" (required).`;
    }
    async _call(input) {
        try {
            const transactionId = input.trim();
            const parsedTransaction = await this.solanaKit.heliusParseTransactions(transactionId);
            return JSON.stringify({
                status: "success",
                message: "transaction parsed successfully",
                transaction: parsedTransaction
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "NOt able to Parse transaction"
            });
        }
    }
}
exports.SolanaParseTransactionHeliusTool = SolanaParseTransactionHeliusTool; //# sourceMappingURL=parse_transaction.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/send_transaction_priority.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SolanaSendTransactionWithPriorityFee = void 0;
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/langchain@0.3.11_@langchain+core@0.3.30_openai@4.79.0_encoding@0.1.13_ws@8.18.0_bufferutil@4._usitgcf3v2qtzzlqdgezmqxnvy/node_modules/langchain/tools.cjs [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
class SolanaSendTransactionWithPriorityFee extends tools_1.Tool {
    constructor(solanaKit){
        super();
        this.solanaKit = solanaKit;
        this.name = "solana_send_transaction_with_priority_fee";
        this.description = `Sends a Solana transaction with a user-defined priority fee.
    **Inputs (JSON-encoded string)**:
    - priorityLevel: string — the priority level ("NONE", "Min", "Low", "Medium", "High", "VeryHigh", or "UnsafeMax")
    - amount: number — the amount of SOL to send
    - to: string — the recipient's wallet address (public key in base58);`;
    }
    async _call(input) {
        try {
            const { priorityLevel, amount, to, splmintAddress } = JSON.parse(input);
            const validPriorityLevels = [
                "NONE",
                "Min",
                "Low",
                "Medium",
                "High",
                "VeryHigh",
                "UnsafeMax"
            ];
            if (!validPriorityLevels.includes(priorityLevel)) {
                throw new Error(`Invalid priority level. Must be one of: ${validPriorityLevels.join(", ")}. Received: ${priorityLevel}`);
            }
            if (!amount || !to) {
                throw new Error(`Missing required fields. Received: priorityLevel=${priorityLevel}, amount=${amount}, to=${to}`);
            }
            const toPubkey = new web3_js_1.PublicKey(to);
            const priorityFeeTx = await this.solanaKit.sendTranctionWithPriority(priorityLevel, amount, toPubkey, splmintAddress);
            return JSON.stringify({
                status: "success",
                message: "Transaction sent successfully",
                priorityFeeTx
            });
        } catch (error) {
            return JSON.stringify({
                status: "error",
                message: error.message,
                code: error.code || "UNKNOWN_ERROR"
            });
        }
    }
}
exports.SolanaSendTransactionWithPriorityFee = SolanaSendTransactionWithPriorityFee; //# sourceMappingURL=send_transaction_priority.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/create_webhook.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/delete_webhook.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/get_all_assets.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/get_webhook.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/parse_transaction.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/send_transaction_priority.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createSolanaTools = createSolanaTools;
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/adrena/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/alldomains/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/dexscreener/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/alldomains/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/flash/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/gibwork/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/jupiter/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/lulo/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/manifest/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solana/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/agent/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/metaplex/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/openbook/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/orca/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/pumpfun/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/pyth/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/raydium/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/rugcheck/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sendarcade/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/solayer/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/tensor/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/3land/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/tiplink/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/sns/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/lightprotocol/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/squads/index.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/helius/index.js [app-route] (ecmascript)"), exports);
const index_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/index.js [app-route] (ecmascript)");
function createSolanaTools(solanaKit) {
    return [
        new index_1.SolanaBalanceTool(solanaKit),
        new index_1.SolanaBalanceOtherTool(solanaKit),
        new index_1.SolanaTransferTool(solanaKit),
        new index_1.SolanaDeployTokenTool(solanaKit),
        new index_1.SolanaDeployCollectionTool(solanaKit),
        new index_1.SolanaMintNFTTool(solanaKit),
        new index_1.SolanaTradeTool(solanaKit),
        new index_1.SolanaRequestFundsTool(solanaKit),
        new index_1.SolanaRegisterDomainTool(solanaKit),
        new index_1.SolanaGetWalletAddressTool(solanaKit),
        new index_1.SolanaPumpfunTokenLaunchTool(solanaKit),
        new index_1.SolanaCreateImageTool(solanaKit),
        new index_1.SolanaLendAssetTool(solanaKit),
        new index_1.SolanaTPSCalculatorTool(solanaKit),
        new index_1.SolanaStakeTool(solanaKit),
        new index_1.SolanaRestakeTool(solanaKit),
        new index_1.SolanaFetchPriceTool(solanaKit),
        new index_1.SolanaGetDomainTool(solanaKit),
        new index_1.SolanaTokenDataTool(solanaKit),
        new index_1.SolanaTokenDataByTickerTool(solanaKit),
        new index_1.SolanaCompressedAirdropTool(solanaKit),
        new index_1.SolanaRaydiumCreateAmmV4(solanaKit),
        new index_1.SolanaRaydiumCreateClmm(solanaKit),
        new index_1.SolanaRaydiumCreateCpmm(solanaKit),
        new index_1.SolanaOpenbookCreateMarket(solanaKit),
        new index_1.SolanaManifestCreateMarket(solanaKit),
        new index_1.SolanaLimitOrderTool(solanaKit),
        new index_1.SolanaBatchOrderTool(solanaKit),
        new index_1.SolanaCancelAllOrdersTool(solanaKit),
        new index_1.SolanaWithdrawAllTool(solanaKit),
        new index_1.SolanaClosePosition(solanaKit),
        new index_1.SolanaOrcaCreateCLMM(solanaKit),
        new index_1.SolanaOrcaCreateSingleSideLiquidityPool(solanaKit),
        new index_1.SolanaOrcaFetchPositions(solanaKit),
        new index_1.SolanaOrcaOpenCenteredPosition(solanaKit),
        new index_1.SolanaOrcaOpenSingleSidedPosition(solanaKit),
        new index_1.SolanaPythFetchPrice(solanaKit),
        new index_1.SolanaResolveDomainTool(solanaKit),
        new index_1.SolanaGetOwnedDomains(solanaKit),
        new index_1.SolanaGetOwnedTldDomains(solanaKit),
        new index_1.SolanaGetAllTlds(solanaKit),
        new index_1.SolanaGetMainDomain(solanaKit),
        new index_1.SolanaResolveAllDomainsTool(solanaKit),
        new index_1.SolanaCreateGibworkTask(solanaKit),
        new index_1.SolanaRockPaperScissorsTool(solanaKit),
        new index_1.SolanaTipLinkTool(solanaKit),
        new index_1.SolanaListNFTForSaleTool(solanaKit),
        new index_1.SolanaCancelNFTListingTool(solanaKit),
        new index_1.SolanaCloseEmptyTokenAccounts(solanaKit),
        new index_1.SolanaFetchTokenReportSummaryTool(solanaKit),
        new index_1.SolanaFetchTokenDetailedReportTool(solanaKit),
        new index_1.Solana3LandCreateSingle(solanaKit),
        new index_1.Solana3LandCreateCollection(solanaKit),
        new index_1.SolanaPerpOpenTradeTool(solanaKit),
        new index_1.SolanaPerpCloseTradeTool(solanaKit),
        new index_1.SolanaFlashOpenTrade(solanaKit),
        new index_1.SolanaFlashCloseTrade(solanaKit),
        new index_1.SolanaCreate2by2Multisig(solanaKit),
        new index_1.SolanaCreateProposal2by2Multisig(solanaKit),
        new index_1.SolanaApproveProposal2by2Multisig(solanaKit),
        new index_1.SolanaRejectProposal2by2Multisig(solanaKit),
        new index_1.SolanaExecuteProposal2by2Multisig(solanaKit),
        new index_1.SolanaDepositTo2by2Multisig(solanaKit),
        new index_1.SolanaTransferFrom2by2Multisig(solanaKit),
        new index_1.SolanaSendTransactionWithPriorityFee(solanaKit),
        new index_1.SolanaHeliusWebhookTool(solanaKit),
        new index_1.SolanaGetHeliusWebhookTool(solanaKit),
        new index_1.SolanaDeleteHeliusWebhookTool(solanaKit),
        new index_1.SolanaParseTransactionHeliusTool(solanaKit),
        new index_1.SolanaGetAllAssetsByOwner(solanaKit),
        new index_1.Solana3LandCreateSingle(solanaKit),
        new index_1.SolanaSendTransactionWithPriorityFee(solanaKit),
        new index_1.SolanaHeliusWebhookTool(solanaKit),
        new index_1.SolanaGetHeliusWebhookTool(solanaKit),
        new index_1.SolanaDeleteHeliusWebhookTool(solanaKit)
    ];
} //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/metaplex/deployToken.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const deployTokenAction = {
    name: "DEPLOY_TOKEN",
    similes: [
        "create token",
        "launch token",
        "deploy new token",
        "create new token",
        "mint token"
    ],
    description: "Deploy a new SPL token on the Solana blockchain with specified parameters",
    examples: [
        [
            {
                input: {
                    name: "My Token",
                    uri: "https://example.com/token.json",
                    symbol: "MTK",
                    decimals: 9,
                    initialSupply: 1000000
                },
                output: {
                    mint: "7nE9GvcwsqzYxmJLSrYmSB1V1YoJWVK1KWzAcWAzjXkN",
                    status: "success",
                    message: "Token deployed successfully"
                },
                explanation: "Deploy a token with initial supply and metadata"
            }
        ],
        [
            {
                input: {
                    name: "Basic Token",
                    uri: "https://example.com/basic.json",
                    symbol: "BASIC"
                },
                output: {
                    mint: "8nE9GvcwsqzYxmJLSrYmSB1V1YoJWVK1KWzAcWAzjXkM",
                    status: "success",
                    message: "Token deployed successfully"
                },
                explanation: "Deploy a basic token with minimal parameters"
            }
        ]
    ],
    schema: zod_1.z.object({
        name: zod_1.z.string().min(1, "Name is required"),
        uri: zod_1.z.string().url("URI must be a valid URL"),
        symbol: zod_1.z.string().min(1, "Symbol is required"),
        decimals: zod_1.z.number().optional(),
        initialSupply: zod_1.z.number().optional()
    }),
    handler: async (agent, input)=>{
        try {
            const result = await (0, tools_1.deploy_token)(agent, input.name, input.uri, input.symbol, input.decimals, input.initialSupply);
            return {
                mint: result.mint.toString(),
                status: "success",
                message: "Token deployed successfully"
            };
        } catch (error) {
            return {
                status: "error",
                message: `Token deployment failed: ${error.message}`
            };
        }
    }
};
exports.default = deployTokenAction; //# sourceMappingURL=deployToken.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/solana/balance.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const balanceAction = {
    name: "BALANCE_ACTION",
    similes: [
        "check balance",
        "get wallet balance",
        "view balance",
        "show balance",
        "check token balance"
    ],
    description: `Get the balance of a Solana wallet or token account.
  If you want to get the balance of your wallet, you don't need to provide the tokenAddress.
  If no tokenAddress is provided, the balance will be in SOL.`,
    examples: [
        [
            {
                input: {},
                output: {
                    status: "success",
                    balance: "100",
                    token: "SOL"
                },
                explanation: "Get SOL balance of the wallet"
            }
        ],
        [
            {
                input: {
                    tokenAddress: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
                },
                output: {
                    status: "success",
                    balance: "1000",
                    token: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
                },
                explanation: "Get USDC token balance"
            }
        ]
    ],
    schema: zod_1.z.object({
        tokenAddress: zod_1.z.string().optional()
    }),
    handler: async (agent, input)=>{
        const balance = await (0, tools_1.get_balance)(agent, input.tokenAddress && new web3_js_1.PublicKey(input.tokenAddress));
        return {
            status: "success",
            balance: balance,
            token: input.tokenAddress || "SOL"
        };
    }
};
exports.default = balanceAction; //# sourceMappingURL=balance.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/solana/transfer.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const transferAction = {
    name: "TRANSFER",
    similes: [
        "send tokens",
        "transfer funds",
        "send money",
        "send sol",
        "transfer tokens"
    ],
    description: `Transfer tokens or SOL to another address (also called as wallet address).`,
    examples: [
        [
            {
                input: {
                    to: "8x2dR8Mpzuz2YqyZyZjUbYWKSWesBo5jMx2Q9Y86udVk",
                    amount: 1
                },
                output: {
                    status: "success",
                    message: "Transfer completed successfully",
                    amount: 1,
                    recipient: "8x2dR8Mpzuz2YqyZyZjUbYWKSWesBo5jMx2Q9Y86udVk",
                    token: "SOL",
                    transaction: "5UfgJ5vVZxUxefDGqzqkVLHzHxVTyYH9StYyHKgvHYmXJgqJKxEqy9k4Rz9LpXrHF9kUZB7"
                },
                explanation: "Transfer 1 SOL to the recipient address"
            }
        ],
        [
            {
                input: {
                    to: "8x2dR8Mpzuz2YqyZyZjUbYWKSWesBo5jMx2Q9Y86udVk",
                    amount: 100,
                    mint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
                },
                output: {
                    status: "success",
                    message: "Transfer completed successfully",
                    amount: 100,
                    recipient: "8x2dR8Mpzuz2YqyZyZjUbYWKSWesBo5jMx2Q9Y86udVk",
                    token: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
                    transaction: "4VfgJ5vVZxUxefDGqzqkVLHzHxVTyYH9StYyHKgvHYmXJgqJKxEqy9k4Rz9LpXrHF9kUZB7"
                },
                explanation: "Transfer 100 USDC tokens to the recipient address"
            }
        ]
    ],
    schema: zod_1.z.object({
        to: zod_1.z.string().min(32, "Invalid Solana address"),
        amount: zod_1.z.number().positive("Amount must be positive"),
        mint: zod_1.z.string().optional()
    }),
    handler: async (agent, input)=>{
        const recipient = new web3_js_1.PublicKey(input.to);
        const mintAddress = input.mint ? new web3_js_1.PublicKey(input.mint) : undefined;
        const tx = await (0, tools_1.transfer)(agent, recipient, input.amount, mintAddress);
        return {
            status: "success",
            message: "Transfer completed successfully",
            amount: input.amount,
            recipient: input.to,
            token: input.mint || "SOL",
            transaction: tx
        };
    }
};
exports.default = transferAction; //# sourceMappingURL=transfer.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/metaplex/deployCollection.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const metaplex_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/metaplex/index.js [app-route] (ecmascript)");
const deployCollectionAction = {
    name: "DEPLOY_COLLECTION",
    similes: [
        "create collection",
        "launch collection",
        "deploy nft collection",
        "create nft collection",
        "mint collection"
    ],
    description: `Deploy a new NFT collection on Solana blockchain.`,
    examples: [
        [
            {
                input: {
                    name: "My Collection",
                    uri: "https://example.com/collection.json",
                    royaltyBasisPoints: 500
                },
                output: {
                    status: "success",
                    message: "Collection deployed successfully",
                    collectionAddress: "7nE9GvcwsqzYxmJLSrYmSB1V1YoJWVK1KWzAcWAzjXkN",
                    name: "My Collection"
                },
                explanation: "Deploy an NFT collection with 5% royalty"
            }
        ],
        [
            {
                input: {
                    name: "Basic Collection",
                    uri: "https://example.com/basic.json"
                },
                output: {
                    status: "success",
                    message: "Collection deployed successfully",
                    collectionAddress: "8nE9GvcwsqzYxmJLSrYmSB1V1YoJWVK1KWzAcWAzjXkM",
                    name: "Basic Collection"
                },
                explanation: "Deploy a basic NFT collection without royalties"
            }
        ]
    ],
    schema: zod_1.z.object({
        name: zod_1.z.string().min(1, "Name is required"),
        uri: zod_1.z.string().url("URI must be a valid URL"),
        royaltyBasisPoints: zod_1.z.number().min(0).max(10000).optional()
    }),
    handler: async (agent, input)=>{
        const options = {
            name: input.name,
            uri: input.uri,
            royaltyBasisPoints: input.royaltyBasisPoints
        };
        const result = await (0, metaplex_1.deploy_collection)(agent, options);
        return {
            status: "success",
            message: "Collection deployed successfully",
            collectionAddress: result.collectionAddress.toString(),
            name: input.name
        };
    }
};
exports.default = deployCollectionAction; //# sourceMappingURL=deployCollection.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/metaplex/mintNFT.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const metaplex_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/metaplex/index.js [app-route] (ecmascript)");
const mintNFTAction = {
    name: "MINT_NFT",
    similes: [
        "mint nft",
        "create nft",
        "mint token",
        "create token",
        "add nft to collection"
    ],
    description: `Mint a new NFT in a collection on Solana blockchain.`,
    examples: [
        [
            {
                input: {
                    collectionMint: "J1S9H3QjnRtBbbuD4HjPV6RpRhwuk4zKbxsnCHuTgh9w",
                    name: "My NFT",
                    uri: "https://example.com/nft.json"
                },
                output: {
                    status: "success",
                    message: "NFT minted successfully",
                    mintAddress: "7nE9GvcwsqzYxmJLSrYmSB1V1YoJWVK1KWzAcWAzjXkN",
                    metadata: {
                        name: "My NFT",
                        uri: "https://example.com/nft.json"
                    },
                    recipient: "7nE9GvcwsqzYxmJLSrYmSB1V1YoJWVK1KWzAcWAzjXkN"
                },
                explanation: "Mint an NFT to the default wallet"
            }
        ],
        [
            {
                input: {
                    collectionMint: "J1S9H3QjnRtBbbuD4HjPV6RpRhwuk4zKbxsnCHuTgh9w",
                    name: "Gift NFT",
                    uri: "https://example.com/gift.json",
                    recipient: "9aUn5swQzUTRanaaTwmszxiv89cvFwUCjEBv1vZCoT1u"
                },
                output: {
                    status: "success",
                    message: "NFT minted successfully",
                    mintAddress: "8nE9GvcwsqzYxmJLSrYmSB1V1YoJWVK1KWzAcWAzjXkM",
                    metadata: {
                        name: "Gift NFT",
                        uri: "https://example.com/gift.json"
                    },
                    recipient: "9aUn5swQzUTRanaaTwmszxiv89cvFwUCjEBv1vZCoT1u"
                },
                explanation: "Mint an NFT to a specific recipient"
            }
        ]
    ],
    schema: zod_1.z.object({
        collectionMint: zod_1.z.string().min(32, "Invalid collection mint address"),
        name: zod_1.z.string().min(1, "Name is required"),
        uri: zod_1.z.string().url("URI must be a valid URL"),
        recipient: zod_1.z.string().min(32, "Invalid recipient address")
    }),
    handler: async (agent, input)=>{
        const result = await (0, metaplex_1.mintCollectionNFT)(agent, new web3_js_1.PublicKey(input.collectionMint), {
            name: input.name,
            uri: input.uri
        }, input.recipient ? new web3_js_1.PublicKey(input.recipient) : undefined);
        return {
            status: "success",
            message: "NFT minted successfully",
            mintAddress: result.mint.toString(),
            metadata: {
                name: input.name,
                uri: input.uri
            },
            recipient: input.recipient || result.mint.toString()
        };
    }
};
exports.default = mintNFTAction; //# sourceMappingURL=mintNFT.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/jupiter/trade.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const tradeAction = {
    name: "TRADE",
    similes: [
        "swap tokens",
        "exchange tokens",
        "trade tokens",
        "convert tokens",
        "swap sol"
    ],
    description: `This tool can be used to swap tokens to another token (It uses Jupiter Exchange).`,
    examples: [
        [
            {
                input: {
                    outputMint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
                    inputAmount: 1
                },
                output: {
                    status: "success",
                    message: "Trade executed successfully",
                    transaction: "5UfgJ5vVZxUxefDGqzqkVLHzHxVTyYH9StYyHKgvHYmXJgqJKxEqy9k4Rz9LpXrHF9kUZB7",
                    inputAmount: 1,
                    inputToken: "SOL",
                    outputToken: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
                },
                explanation: "Swap 1 SOL for USDC"
            }
        ],
        [
            {
                input: {
                    outputMint: "So11111111111111111111111111111111111111112",
                    inputAmount: 100,
                    inputMint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
                    slippageBps: 100
                },
                output: {
                    status: "success",
                    message: "Trade executed successfully",
                    transaction: "4VfgJ5vVZxUxefDGqzqkVLHzHxVTyYH9StYyHKgvHYmXJgqJKxEqy9k4Rz9LpXrHF9kUZB7",
                    inputAmount: 100,
                    inputToken: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
                    outputToken: "So11111111111111111111111111111111111111112"
                },
                explanation: "Swap 100 USDC for SOL with 1% slippage"
            }
        ]
    ],
    schema: zod_1.z.object({
        outputMint: zod_1.z.string().min(32, "Invalid output mint address"),
        inputAmount: zod_1.z.number().positive("Input amount must be positive"),
        inputMint: zod_1.z.string().min(32, "Invalid input mint address").optional(),
        slippageBps: zod_1.z.number().min(0).max(10000).optional()
    }),
    handler: async (agent, input)=>{
        const tx = await (0, tools_1.trade)(agent, new web3_js_1.PublicKey(input.outputMint), input.inputAmount, input.inputMint ? new web3_js_1.PublicKey(input.inputMint) : new web3_js_1.PublicKey("So11111111111111111111111111111111111111112"), input.slippageBps);
        return {
            status: "success",
            message: "Trade executed successfully",
            transaction: tx,
            inputAmount: input.inputAmount,
            inputToken: input.inputMint || "SOL",
            outputToken: input.outputMint
        };
    }
};
exports.default = tradeAction; //# sourceMappingURL=trade.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/solana/requestFunds.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const solana_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/index.js [app-route] (ecmascript)");
const requestFundsAction = {
    name: "REQUEST_FUNDS",
    similes: [
        "request sol",
        "get test sol",
        "use faucet",
        "request test tokens",
        "get devnet sol"
    ],
    description: "Request SOL from Solana faucet (devnet/testnet only)",
    examples: [
        [
            {
                input: {},
                output: {
                    status: "success",
                    message: "Successfully requested faucet funds",
                    network: "devnet.solana.com"
                },
                explanation: "Request SOL from the devnet faucet"
            }
        ]
    ],
    schema: zod_1.z.object({}),
    handler: async (agent, _input)=>{
        await (0, solana_1.request_faucet_funds)(agent);
        return {
            status: "success",
            message: "Successfully requested faucet funds",
            network: agent.connection.rpcEndpoint.split("/")[2]
        };
    }
};
exports.default = requestFundsAction; //# sourceMappingURL=requestFunds.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/sns/registerDomain.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const registerDomainAction = {
    name: "REGISTER_DOMAIN",
    similes: [
        "register domain",
        "buy domain",
        "get domain name",
        "register .sol",
        "purchase domain",
        "domain registration"
    ],
    description: "Register a .sol domain name using Bonfida Name Service",
    examples: [
        [
            {
                input: {
                    name: "mydomain",
                    spaceKB: 1
                },
                output: {
                    status: "success",
                    signature: "2ZE7Rz...",
                    message: "Successfully registered mydomain.sol"
                },
                explanation: "Register a new .sol domain with 1KB storage space"
            }
        ]
    ],
    schema: zod_1.z.object({
        name: zod_1.z.string().min(1).describe("Domain name to register (without .sol)"),
        spaceKB: zod_1.z.number().min(1).max(10).default(1).describe("Space allocation in KB (max 10KB)")
    }),
    handler: async (agent, input)=>{
        try {
            const name = input.name;
            const spaceKB = input.spaceKB || 1;
            const signature = await (0, tools_1.registerDomain)(agent, name, spaceKB);
            return {
                status: "success",
                signature,
                message: `Successfully registered ${name}.sol`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Domain registration failed: ${error.message}`
            };
        }
    }
};
exports.default = registerDomainAction; //# sourceMappingURL=registerDomain.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/jupiter/getTokenData.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const getTokenDataAction = {
    name: "GET_TOKEN_DATA",
    similes: [
        "get token info",
        "token details",
        "lookup token",
        "find token",
        "token data"
    ],
    description: "Get token data from either a token address or ticker symbol",
    examples: [
        [
            {
                input: {
                    address: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
                },
                output: {
                    status: "success",
                    token: {
                        name: "USD Coin",
                        symbol: "USDC",
                        address: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
                        decimals: 6
                    }
                },
                explanation: "Get token data using the token's address"
            }
        ],
        [
            {
                input: {
                    ticker: "SOL"
                },
                output: {
                    status: "success",
                    token: {
                        name: "Wrapped SOL",
                        symbol: "SOL",
                        address: "So11111111111111111111111111111111111111112",
                        decimals: 9
                    }
                },
                explanation: "Get token data using the token's ticker symbol"
            }
        ]
    ],
    schema: zod_1.z.object({
        address: zod_1.z.string().optional().describe("The token's mint address"),
        ticker: zod_1.z.string().optional().describe("The token's ticker symbol")
    }).refine((data)=>data.address || data.ticker, {
        message: "Either address or ticker must be provided"
    }),
    handler: async (agent, input)=>{
        try {
            let tokenData;
            if (input.address) {
                tokenData = await (0, tools_1.getTokenDataByAddress)(new web3_js_1.PublicKey(input.address));
            } else if (input.ticker) {
                const address = await (0, tools_1.getTokenAddressFromTicker)(input.ticker);
                if (address) {
                    tokenData = await (0, tools_1.getTokenDataByAddress)(new web3_js_1.PublicKey(address));
                }
            }
            if (!tokenData) {
                return {
                    status: "error",
                    message: "Token not found or not verified"
                };
            }
            return {
                status: "success",
                token: {
                    name: tokenData.name,
                    symbol: tokenData.symbol,
                    address: tokenData.address,
                    decimals: tokenData.decimals,
                    logoURI: tokenData.logoURI
                }
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to get token data: ${error.message}`
            };
        }
    }
};
exports.default = getTokenDataAction; //# sourceMappingURL=getTokenData.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/solana/getTPS.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const solana_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/solana/index.js [app-route] (ecmascript)");
const getTPSAction = {
    name: "GET_TPS",
    similes: [
        "get transactions per second",
        "check network speed",
        "network performance",
        "transaction throughput",
        "network tps"
    ],
    description: "Get the current transactions per second (TPS) of the Solana network",
    examples: [
        [
            {
                input: {},
                output: {
                    status: "success",
                    tps: 3500,
                    message: "Current network TPS: 3500"
                },
                explanation: "Get the current TPS of the Solana network"
            }
        ]
    ],
    schema: zod_1.z.object({}),
    handler: async (agent, _input)=>{
        try {
            const response = await (0, solana_1.getTPS)(agent);
            return {
                status: "success",
                response,
                message: `Current network TPS: ${response}`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to get TPS: ${error.message}`
            };
        }
    }
};
exports.default = getTPSAction; //# sourceMappingURL=getTPS.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/jupiter/fetchPrice.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const jupiter_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/jupiter/index.js [app-route] (ecmascript)");
const fetchPriceAction = {
    name: "FETCH_PRICE",
    similes: [
        "get token price",
        "check price",
        "token value",
        "price check",
        "get price in usd"
    ],
    description: "Fetch the current price of a Solana token in USDC using Jupiter API",
    examples: [
        [
            {
                input: {
                    tokenAddress: "So11111111111111111111111111111111111111112"
                },
                output: {
                    status: "success",
                    price: "23.45",
                    message: "Current price: $23.45 USDC"
                },
                explanation: "Get the current price of SOL token in USDC"
            }
        ]
    ],
    schema: zod_1.z.object({
        tokenAddress: zod_1.z.string().describe("The mint address of the token to fetch the price for")
    }),
    handler: async (agent, input)=>{
        try {
            const tokenId = new web3_js_1.PublicKey(input.tokenAddress);
            const price = await (0, jupiter_1.fetchPrice)(tokenId);
            return {
                status: "success",
                price,
                message: `Current price: $${price} USDC`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to fetch price: ${error.message}`
            };
        }
    }
};
exports.default = fetchPriceAction; //# sourceMappingURL=fetchPrice.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/jupiter/stakeWithJup.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const stakeWithJupAction = {
    name: "STAKE_WITH_JUPITER",
    similes: [
        "stake sol",
        "stake with jupiter",
        "jup staking",
        "stake with jup",
        "liquid staking",
        "get jupsol"
    ],
    description: "Stake SOL tokens with Jupiter's liquid staking protocol to receive jupSOL",
    examples: [
        [
            {
                input: {
                    amount: 1.5
                },
                output: {
                    status: "success",
                    signature: "5KtPn3...",
                    message: "Successfully staked 1.5 SOL for jupSOL"
                },
                explanation: "Stake 1.5 SOL to receive jupSOL tokens"
            }
        ]
    ],
    schema: zod_1.z.object({
        amount: zod_1.z.number().positive().describe("Amount of SOL to stake")
    }),
    handler: async (agent, input)=>{
        try {
            const amount = input.amount;
            const res = await (0, tools_1.stakeWithJup)(agent, amount);
            return {
                status: "success",
                res,
                message: `Successfully staked ${amount} SOL for jupSOL`
            };
        } catch (error) {
            return {
                status: "error",
                message: `jupSOL staking failed: ${error.message}`
            };
        }
    }
};
exports.default = stakeWithJupAction; //# sourceMappingURL=stakeWithJup.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/solayer/stakeWithSolayer.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const stakeWithSolayerAction = {
    name: "STAKE_WITH_SOLAYER",
    similes: [
        "stake sol",
        "solayer sol",
        "ssol",
        "stake with solayer",
        "solayer restaking",
        "solayer staking",
        "stake with sol",
        "liquid staking solayer",
        "get solayer sol",
        "solayer sol restaking",
        "solayer sol staking"
    ],
    description: "Stake native SOL with Solayer's restaking protocol to receive Solayer SOL (sSOL)",
    examples: [
        [
            {
                input: {
                    amount: 1.0
                },
                output: {
                    status: "success",
                    signature: "3FgHn9...",
                    message: "Successfully staked 1.0 SOL for Solayer SOL (sSOL)"
                },
                explanation: "Stake 1.0 SOL to receive Solayer SOL (sSOL)"
            }
        ]
    ],
    schema: zod_1.z.object({
        amount: zod_1.z.number().positive().describe("Amount of SOL to stake")
    }),
    handler: async (agent, input)=>{
        try {
            const amount = input.amount;
            const res = await (0, tools_1.stakeWithSolayer)(agent, amount);
            return {
                status: "success",
                res,
                message: `Successfully staked ${amount} SOL for Solayer SOL (sSOL)`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Solayer staking failed: ${error.message}`
            };
        }
    }
};
exports.default = stakeWithSolayerAction; //# sourceMappingURL=stakeWithSolayer.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/lulo/lendAsset.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const lulo_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/lulo/index.js [app-route] (ecmascript)");
const lendAssetAction = {
    name: "LEND_ASSET",
    similes: [
        "lend usdc",
        "deposit for yield",
        "earn yield",
        "lend with lulo",
        "deposit usdc",
        "lending"
    ],
    description: "Lend USDC tokens to earn yield using Lulo protocol",
    examples: [
        [
            {
                input: {
                    amount: 100
                },
                output: {
                    status: "success",
                    signature: "4xKpN2...",
                    message: "Successfully lent 100 USDC"
                },
                explanation: "Lend 100 USDC to earn yield on Lulo"
            }
        ]
    ],
    schema: zod_1.z.object({
        amount: zod_1.z.number().positive().describe("Amount of USDC to lend")
    }),
    handler: async (agent, input)=>{
        try {
            const amount = input.amount;
            const response = await (0, lulo_1.lendAsset)(agent, amount);
            return {
                status: "success",
                signature: response,
                message: `Successfully lent ${amount} USDC`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Lending failed: ${error.message}`
            };
        }
    }
};
exports.default = lendAssetAction; //# sourceMappingURL=lendAsset.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/gibwork/createGibworkTask.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const gibwork_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/gibwork/index.js [app-route] (ecmascript)");
const createGibworkTaskAction = {
    name: "CREATE_GIBWORK_TASK",
    similes: [
        "create task",
        "post job",
        "create gig",
        "post task",
        "create work",
        "new task on gibwork"
    ],
    description: "Create a new task on the Gibwork platform with payment in SPL tokens",
    examples: [
        [
            {
                input: {
                    title: "Build a Solana dApp",
                    content: "Create a simple Solana dApp with React frontend",
                    requirements: "Experience with Rust and React",
                    tags: [
                        "solana",
                        "rust",
                        "react"
                    ],
                    tokenMintAddress: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
                    tokenAmount: 100
                },
                output: {
                    status: "success",
                    taskId: "task_123",
                    signature: "3YKpM1...",
                    message: "Successfully created task: Build a Solana dApp"
                },
                explanation: "Create a new task on Gibwork with 100 USDC payment"
            }
        ]
    ],
    schema: zod_1.z.object({
        title: zod_1.z.string().min(1).describe("Title of the task"),
        content: zod_1.z.string().min(1).describe("Description of the task"),
        requirements: zod_1.z.string().min(1).describe("Requirements to complete the task"),
        tags: zod_1.z.array(zod_1.z.string()).min(1).describe("List of tags associated with the task"),
        tokenMintAddress: zod_1.z.string().describe("Token mint address for payment"),
        tokenAmount: zod_1.z.number().positive().describe("Payment amount for the task"),
        payer: zod_1.z.string().optional().describe("Optional payer address (defaults to wallet address)")
    }),
    handler: async (agent, input)=>{
        try {
            const responseData = await (0, gibwork_1.create_gibwork_task)(agent, input.title, input.content, input.requirements, input.tags, new web3_js_1.PublicKey(input.tokenMintAddress), input.tokenAmount, input.payer ? new web3_js_1.PublicKey(input.payer) : undefined);
            return {
                status: "success",
                taskId: responseData.taskId,
                signature: responseData.signature,
                message: `Successfully created task: ${input.title}`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to create task: ${error.message}`
            };
        }
    }
};
exports.default = createGibworkTaskAction; //# sourceMappingURL=createGibworkTask.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/sns/resolveSolDomain.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const resolveSolDomainAction = {
    name: "RESOLVE_SOL_DOMAIN",
    similes: [
        "resolve sol domain",
        "lookup sol domain",
        "get sol domain owner",
        "check sol domain",
        "find sol domain owner",
        "resolve .sol"
    ],
    description: "Resolve a .sol domain to its corresponding Solana wallet address using Bonfida Name Service",
    examples: [
        [
            {
                input: {
                    domain: "vitalik.sol"
                },
                output: {
                    status: "success",
                    owner: "7nxQB...",
                    message: "Successfully resolved vitalik.sol"
                },
                explanation: "Resolve a .sol domain to get the owner's wallet address"
            }
        ]
    ],
    schema: zod_1.z.object({
        domain: zod_1.z.string().min(1).describe("The .sol domain to resolve (with or without .sol suffix)")
    }),
    handler: async (agent, input)=>{
        try {
            const domain = input.domain;
            const res = await (0, tools_1.resolveSolDomain)(agent, domain);
            return {
                status: "success",
                owner: res.toString(),
                message: `Successfully resolved ${res}`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to resolve domain: ${error.message}`
            };
        }
    }
};
exports.default = resolveSolDomainAction; //# sourceMappingURL=resolveSolDomain.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/pyth/pythFetchPrice.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const pythFetchPriceAction = {
    name: "PYTH_FETCH_PRICE",
    similes: [
        "get pyth price",
        "check pyth price",
        "pyth oracle price",
        "fetch from pyth",
        "pyth price feed",
        "oracle price"
    ],
    description: "Fetch the current price from a Pyth oracle price feed",
    examples: [
        [
            {
                input: {
                    tokenSymbol: "SOL"
                },
                output: {
                    status: "success",
                    price: "23.45",
                    message: "Current price: $23.45"
                },
                explanation: "Get the current SOL/USD price from Pyth oracle"
            }
        ]
    ],
    schema: zod_1.z.object({
        tokenSymbol: zod_1.z.string().min(1).describe("The token symbol to fetch the price for")
    }),
    handler: async (_agent, input)=>{
        try {
            const priceFeedId = await (0, tools_1.fetchPythPriceFeedID)(input.tokenSymbol);
            const priceStr = await (0, tools_1.fetchPythPrice)(priceFeedId);
            return {
                status: "success",
                price: priceStr,
                message: `Current price: $${priceStr}`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to fetch price from Pyth: ${error.message}`
            };
        }
    }
};
exports.default = pythFetchPriceAction; //# sourceMappingURL=pythFetchPrice.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/alldomains/getOwnedDomainsForTLD.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const getOwnedDomainsForTLDAction = {
    name: "GET_OWNED_DOMAINS_FOR_TLD",
    similes: [
        "list owned domains for tld",
        "get my domains for extension",
        "fetch wallet domains by tld",
        "get owned names by extension",
        "list my domains by tld",
        "get address domains for tld"
    ],
    description: "Get all domains owned by a specific wallet address for a given top-level domain (TLD)",
    examples: [
        [
            {
                input: {
                    tld: "sol"
                },
                output: {
                    status: "success",
                    domains: [
                        "solana.sol",
                        "wallet.sol",
                        "user.sol"
                    ],
                    total: 3,
                    message: "Successfully retrieved owned domains for .sol"
                },
                explanation: "Get all .sol domain names owned by a specific wallet address"
            }
        ]
    ],
    schema: zod_1.z.object({
        tld: zod_1.z.string().min(1).describe("The top-level domain to filter by (e.g., 'sol', 'abc')")
    }),
    handler: async (agent, input)=>{
        try {
            const tld = input.tld.toLowerCase();
            // Get owned domains for TLD
            const domains = await (0, tools_1.getOwnedDomainsForTLD)(agent, tld);
            return {
                status: "success",
                domains,
                total: domains.length,
                message: `Successfully retrieved ${domains.length} owned domain${domains.length === 1 ? "" : "s"} for .${tld}`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to get owned domains: ${error.message}`
            };
        }
    }
};
exports.default = getOwnedDomainsForTLDAction; //# sourceMappingURL=getOwnedDomainsForTLD.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/sns/getPrimaryDomain.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const getPrimaryDomainAction = {
    name: "GET_PRIMARY_DOMAIN",
    similes: [
        "get primary domain",
        "lookup primary domain",
        "check primary domain",
        "find primary domain",
        "get main domain",
        "primary sol domain"
    ],
    description: "Get the primary .sol domain associated with a Solana wallet address",
    examples: [
        [
            {
                input: {
                    account: "7nxQB..."
                },
                output: {
                    status: "success",
                    domain: "vitalik.sol",
                    message: "Primary domain: vitalik.sol"
                },
                explanation: "Get the primary .sol domain for a wallet address"
            }
        ]
    ],
    schema: zod_1.z.object({
        account: zod_1.z.string().min(1).describe("The Solana wallet address to lookup")
    }),
    handler: async (agent, input)=>{
        try {
            const account = new web3_js_1.PublicKey(input.account);
            const response = await (0, tools_1.getPrimaryDomain)(agent, account);
            return {
                status: "success",
                domain: response,
                message: `Primary domain: ${response}`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to get primary domain: ${error.message}`
            };
        }
    }
};
exports.default = getPrimaryDomainAction; //# sourceMappingURL=getPrimaryDomain.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/alldomains/getAllDomainsTLDs.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const getAllDomainsTLDsAction = {
    name: "GET_ALL_TLDS",
    similes: [
        "list domain tlds",
        "get domain extensions",
        "fetch domain tlds",
        "get top level domains",
        "list available tlds",
        "get domain suffixes"
    ],
    description: "Get a list of all available top-level domains (TLDs) for Solana domains",
    examples: [
        [
            {
                input: {},
                output: {
                    status: "success",
                    tlds: [
                        ".sol",
                        ".abc",
                        ".backpack",
                        ".bonk"
                    ],
                    message: "Successfully retrieved all domain TLDs"
                },
                explanation: "Get a list of all available TLDs that can be used for Solana domains"
            }
        ]
    ],
    schema: zod_1.z.object({}),
    handler: async (agent)=>{
        try {
            // Get all domain TLDs
            const tlds = await (0, tools_1.getAllDomainsTLDs)(agent);
            return {
                status: "success",
                tlds,
                message: "Successfully retrieved all domain TLDs"
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to get domain TLDs: ${error.message}`
            };
        }
    }
};
exports.default = getAllDomainsTLDsAction; //# sourceMappingURL=getAllDomainsTLDs.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/alldomains/getOwnedAllDomains.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const getOwnedAllDomainsAction = {
    name: "GET_OWNED_ALL_DOMAINS",
    similes: [
        "list owned domains",
        "get my domains",
        "fetch wallet domains",
        "get owned names",
        "list my domains",
        "get address domains"
    ],
    description: "Get all domains owned by a specific wallet address across all TLDs",
    examples: [
        [
            {
                input: {
                    address: "7nxQB..."
                },
                output: {
                    status: "success",
                    domains: [
                        "solana.sol",
                        "wallet.abc",
                        "user.backpack"
                    ],
                    total: 3,
                    message: "Successfully retrieved owned domains"
                },
                explanation: "Get all domain names owned by a specific wallet address"
            }
        ]
    ],
    schema: zod_1.z.object({
        address: zod_1.z.string().min(1).describe("The wallet address to get owned domains for")
    }),
    handler: async (agent, input)=>{
        try {
            const address = new web3_js_1.PublicKey(input.address);
            // Get owned domains
            const domains = await (0, tools_1.getOwnedAllDomains)(agent, address);
            return {
                status: "success",
                domains,
                total: domains.length,
                message: `Successfully retrieved ${domains.length} owned domain${domains.length === 1 ? "" : "s"}`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to get owned domains: ${error.message}`
            };
        }
    }
};
exports.default = getOwnedAllDomainsAction; //# sourceMappingURL=getOwnedAllDomains.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/agent/createImage.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const agent_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/agent/index.js [app-route] (ecmascript)");
const createImageAction = {
    name: "CREATE_IMAGE",
    similes: [
        "generate image",
        "create artwork",
        "make image",
        "generate artwork",
        "create picture",
        "generate picture"
    ],
    description: "Create an AI-generated image based on a text prompt using OpenAI's DALL-E models",
    examples: [
        [
            {
                input: {
                    prompt: "A beautiful sunset over a mountain landscape",
                    model: "dall-e-3",
                    size: "1024x1024",
                    quality: "standard",
                    style: "natural"
                },
                output: {
                    status: "success",
                    imageUrl: "https://example.com/image.png",
                    message: "Successfully generated image"
                },
                explanation: "Generate an image of a sunset landscape using DALL-E 3"
            }
        ]
    ],
    schema: zod_1.z.object({
        prompt: zod_1.z.string().min(1).max(1000).describe("The text description of the image to generate"),
        model: zod_1.z.enum([
            "dall-e-3"
        ]).default("dall-e-3").describe("The AI model to use for generation"),
        size: zod_1.z.enum([
            "256x256",
            "512x512",
            "1024x1024",
            "1792x1024",
            "1024x1792"
        ]).default("1024x1024").describe("The size of the generated image"),
        quality: zod_1.z.enum([
            "standard",
            "hd"
        ]).default("standard").describe("The quality level of the generated image"),
        style: zod_1.z.enum([
            "natural",
            "vivid"
        ]).default("natural").describe("The style of the generated image")
    }),
    handler: async (agent, input)=>{
        try {
            if (!agent.config.OPENAI_API_KEY) {
                return {
                    status: "error",
                    message: "OpenAI API key not found in agent configuration"
                };
            }
            const { prompt, model, size } = input;
            const response = await (0, agent_1.create_image)(agent, prompt, model, size);
            return {
                status: "success",
                imageUrl: response.images[0].url,
                message: "Successfully generated image"
            };
        } catch (error) {
            // Handle specific OpenAI error types
            if (error.response) {
                const { status, data } = error.response;
                if (status === 429) {
                    return {
                        status: "error",
                        message: "Rate limit exceeded. Please try again later."
                    };
                }
                return {
                    status: "error",
                    message: `OpenAI API error: ${data.error?.message || error.message}`
                };
            }
            return {
                status: "error",
                message: `Failed to generate image: ${error.message}`
            };
        }
    }
};
exports.default = createImageAction; //# sourceMappingURL=createImage.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/sns/getMainAllDomainsDomain.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const getMainAllDomainsDomainAction = {
    name: "GET_MAIN_ALL_DOMAINS_DOMAIN",
    similes: [
        "get main domain",
        "fetch primary domain",
        "get default domain",
        "get main address name",
        "get primary name",
        "get main domain name"
    ],
    description: "Get the main domain associated with a wallet address",
    examples: [
        [
            {
                input: {
                    address: "7nxQB..."
                },
                output: {
                    status: "success",
                    domain: "solana.sol",
                    message: "Successfully retrieved main domain"
                },
                explanation: "Get the main domain name for a given wallet address"
            }
        ]
    ],
    schema: zod_1.z.object({
        address: zod_1.z.string().min(1).describe("The wallet address to get the main domain for")
    }),
    handler: async (agent, input)=>{
        try {
            const mainDomain = await (0, tools_1.getMainAllDomainsDomain)(agent, new web3_js_1.PublicKey(input.address));
            if (!mainDomain) {
                return {
                    status: "error",
                    message: "No main domain found for this address"
                };
            }
            return {
                status: "success",
                domain: mainDomain,
                message: "Successfully retrieved main domain"
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to get main domain: ${error.message}`
            };
        }
    }
};
exports.default = getMainAllDomainsDomainAction; //# sourceMappingURL=getMainAllDomainsDomain.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/sns/getAllRegisteredAllDomains.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const getAllRegisteredAllDomainsAction = {
    name: "GET_ALL_REGISTERED_ALL_DOMAINS",
    similes: [
        "list registered domains",
        "get all domains",
        "fetch registered domains",
        "get domain list",
        "list active domains",
        "get registered names"
    ],
    description: "Get a list of all registered domains across all TLDs",
    examples: [
        [
            {
                input: {
                    limit: 100,
                    offset: 0
                },
                output: {
                    status: "success",
                    domains: [
                        "solana.sol",
                        "bonk.abc",
                        "wallet.backpack"
                    ],
                    total: 3,
                    message: "Successfully retrieved registered domains"
                },
                explanation: "Get the first 100 registered domains across all TLDs"
            }
        ]
    ],
    schema: zod_1.z.object({
        limit: zod_1.z.number().positive().max(1000).default(100).describe("Maximum number of domains to return"),
        offset: zod_1.z.number().nonnegative().default(0).describe("Number of domains to skip")
    }),
    handler: async (agent, input)=>{
        try {
            const limit = input.limit || 100;
            const offset = input.offset || 0;
            // Get all registered domains
            const domains = await (0, tools_1.getAllRegisteredAllDomains)(agent);
            return {
                status: "success",
                domains: domains.slice(offset, offset + limit),
                total: domains.length,
                message: "Successfully retrieved registered domains"
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to get registered domains: ${error.message}`
            };
        }
    }
};
exports.default = getAllRegisteredAllDomainsAction; //# sourceMappingURL=getAllRegisteredAllDomains.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/raydium/raydiumCreateCpmm.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const raydiumCreateCpmmAction = {
    name: "RAYDIUM_CREATE_CPMM",
    similes: [
        "create raydium pool",
        "setup raydium liquidity pool",
        "initialize raydium amm",
        "create constant product market maker",
        "setup raydium cpmm",
        "create raydium trading pair"
    ],
    description: "Create a new Constant Product Market Maker (CPMM) pool on Raydium",
    examples: [
        [
            {
                input: {
                    baseMint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
                    quoteMint: "So11111111111111111111111111111111111111112",
                    baseAmount: 1000,
                    quoteAmount: 10,
                    startTime: 1672531200
                },
                output: {
                    status: "success",
                    signature: "2ZE7Rz...",
                    poolId: "7nxQB...",
                    message: "Successfully created Raydium CPMM pool"
                },
                explanation: "Create a USDC-SOL pool with initial liquidity of 1000 USDC and 10 SOL"
            }
        ]
    ],
    schema: zod_1.z.object({
        baseMint: zod_1.z.string().min(1).describe("The base token mint address"),
        quoteMint: zod_1.z.string().min(1).describe("The quote token mint address"),
        baseAmount: zod_1.z.number().positive().describe("Initial base token amount to provide as liquidity"),
        quoteAmount: zod_1.z.number().positive().describe("Initial quote token amount to provide as liquidity"),
        startTime: zod_1.z.number().positive().describe("Unix timestamp when trading should start")
    }),
    handler: async (agent, input)=>{
        try {
            const mintA = new web3_js_1.PublicKey(input.baseMint);
            const mintB = new web3_js_1.PublicKey(input.quoteMint);
            const configId = new web3_js_1.PublicKey(input.configId);
            const mintAAmount = new bn_js_1.default(input.baseAmount);
            const mintBAmount = new bn_js_1.default(input.quoteAmount);
            const startTime = new bn_js_1.default(input.startTime);
            const txId = await (0, tools_1.raydiumCreateCpmm)(agent, mintA, mintB, configId, mintAAmount, mintBAmount, startTime);
            return {
                status: "success",
                signature: txId,
                message: "Successfully created Raydium CPMM pool"
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to create CPMM pool: ${error.message}`
            };
        }
    }
};
exports.default = raydiumCreateCpmmAction; //# sourceMappingURL=raydiumCreateCpmm.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/raydium/raydiumCreateAmmV4.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const raydiumCreateAmmV4Action = {
    name: "RAYDIUM_CREATE_AMM_V4",
    similes: [
        "create raydium v4 pool",
        "setup raydium v4 liquidity pool",
        "initialize raydium v4 amm",
        "create raydium v4 market maker",
        "setup raydium v4 pool",
        "create raydium v4 trading pair"
    ],
    description: "Create a new AMM V4 pool on Raydium with advanced features and improved efficiency",
    examples: [
        [
            {
                input: {
                    baseMint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
                    quoteMint: "So11111111111111111111111111111111111111112",
                    baseAmount: 1000,
                    quoteAmount: 10,
                    startPrice: 100,
                    openTime: 1672531200
                },
                output: {
                    status: "success",
                    signature: "2ZE7Rz...",
                    poolId: "7nxQB...",
                    message: "Successfully created Raydium AMM V4 pool"
                },
                explanation: "Create a USDC-SOL V4 pool with initial liquidity and price"
            }
        ]
    ],
    schema: zod_1.z.object({
        baseMint: zod_1.z.string().min(1).describe("The base token mint address"),
        quoteMint: zod_1.z.string().min(1).describe("The quote token mint address"),
        baseAmount: zod_1.z.number().positive().describe("Initial base token amount to provide as liquidity"),
        quoteAmount: zod_1.z.number().positive().describe("Initial quote token amount to provide as liquidity"),
        startPrice: zod_1.z.number().positive().describe("Initial price of quote token in base token units"),
        openTime: zod_1.z.number().positive().describe("Unix timestamp when trading should start")
    }),
    handler: async (agent, input)=>{
        try {
            const marketId = new web3_js_1.PublicKey(input.marketId);
            const baseAmount = new bn_js_1.default(input.baseAmount);
            const quoteAmount = new bn_js_1.default(input.quoteAmount);
            const startTime = new bn_js_1.default(input.startTime);
            const txId = await (0, tools_1.raydiumCreateAmmV4)(agent, marketId, baseAmount, quoteAmount, startTime);
            return {
                status: "success",
                signature: txId,
                message: "Successfully created Raydium AMM V4 pool"
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to create AMM V4 pool: ${error.message}`
            };
        }
    }
};
exports.default = raydiumCreateAmmV4Action; //# sourceMappingURL=raydiumCreateAmmV4.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/orca/createOrcaSingleSidedWhirlpool.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const decimal_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/decimal.js@10.4.3/node_modules/decimal.js/decimal.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
// Fee tiers mapping from the original tool
const FEE_TIERS = {
    0.01: 1,
    0.02: 2,
    0.04: 4,
    0.05: 8,
    0.16: 16,
    0.3: 64,
    0.65: 96,
    1.0: 128,
    2.0: 256
};
const createOrcaSingleSidedWhirlpoolAction = {
    name: "CREATE_ORCA_SINGLE_SIDED_WHIRLPOOL",
    similes: [
        "create orca whirlpool",
        "setup orca single sided pool",
        "initialize orca whirlpool",
        "create orca concentrated pool",
        "setup orca concentrated liquidity",
        "create orca trading pair"
    ],
    description: "Create a new single-sided whirlpool on Orca with concentrated liquidity",
    examples: [
        [
            {
                input: {
                    depositTokenAmount: "1000000000000",
                    depositTokenMint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
                    otherTokenMint: "So11111111111111111111111111111111111111112",
                    initialPrice: "0.001",
                    maxPrice: "5.0",
                    feeTier: 0.3
                },
                output: {
                    status: "success",
                    signature: "2ZE7Rz...",
                    message: "Successfully created Orca single-sided whirlpool"
                },
                explanation: "Create a USDC/SOL whirlpool with 1M USDC initial liquidity"
            }
        ]
    ],
    schema: zod_1.z.object({
        depositTokenAmount: zod_1.z.string().min(1).describe("The amount of deposit token to provide as liquidity (including decimals)"),
        depositTokenMint: zod_1.z.string().min(1).describe("The mint address of the token being deposited"),
        otherTokenMint: zod_1.z.string().min(1).describe("The mint address of the other token in the pool"),
        initialPrice: zod_1.z.string().min(1).describe("Initial price of deposit token in terms of the other token"),
        maxPrice: zod_1.z.string().min(1).describe("Maximum price at which liquidity is added"),
        feeTier: zod_1.z.number().refine((val)=>val in FEE_TIERS, "Invalid fee tier").describe("Fee tier percentage for the pool (e.g., 0.3 for 0.3%)")
    }),
    handler: async (agent, input)=>{
        try {
            const depositTokenAmount = Number(input.depositTokenAmount);
            const depositTokenMint = new web3_js_1.PublicKey(input.depositTokenMint);
            const otherTokenMint = new web3_js_1.PublicKey(input.otherTokenMint);
            const initialPrice = new decimal_js_1.Decimal(input.initialPrice);
            const maxPrice = new decimal_js_1.Decimal(input.maxPrice);
            const feeTier = input.feeTier;
            // Create the whirlpool
            const signature = await (0, tools_1.orcaCreateSingleSidedLiquidityPool)(agent, depositTokenAmount, depositTokenMint, otherTokenMint, initialPrice, maxPrice, feeTier);
            return {
                status: "success",
                signature,
                message: "Successfully created Orca single-sided whirlpool"
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to create whirlpool: ${error.message}`
            };
        }
    }
};
exports.default = createOrcaSingleSidedWhirlpoolAction; //# sourceMappingURL=createOrcaSingleSidedWhirlpool.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/pumpfun/launchPumpfunToken.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const launchPumpfunTokenAction = {
    name: "LAUNCH_PUMPFUN_TOKEN",
    similes: [
        "create pumpfun token",
        "launch token on pumpfun",
        "deploy pumpfun token",
        "create meme token",
        "launch memecoin",
        "create pump token"
    ],
    description: "Launch a new token on Pump.fun with customizable metadata and initial liquidity",
    examples: [
        [
            {
                input: {
                    tokenName: "Sample Token",
                    tokenTicker: "SMPL",
                    description: "A sample token for demonstration",
                    imageUrl: "https://example.com/token.png",
                    twitter: "@sampletoken",
                    telegram: "t.me/sampletoken",
                    website: "https://sampletoken.com",
                    initialLiquiditySOL: 0.1,
                    slippageBps: 10,
                    priorityFee: 0.0001
                },
                output: {
                    status: "success",
                    signature: "2ZE7Rz...",
                    mint: "7nxQB...",
                    metadataUri: "https://arweave.net/...",
                    message: "Successfully launched token on Pump.fun"
                },
                explanation: "Launch a new token with custom metadata and 0.1 SOL initial liquidity"
            }
        ]
    ],
    schema: zod_1.z.object({
        tokenName: zod_1.z.string().min(1).max(32).describe("Name of the token"),
        tokenTicker: zod_1.z.string().min(2).max(10).describe("Ticker symbol of the token"),
        description: zod_1.z.string().min(1).max(1000).describe("Description of the token"),
        imageUrl: zod_1.z.string().url().describe("URL of the token image"),
        twitter: zod_1.z.string().optional().describe("Twitter handle (optional)"),
        telegram: zod_1.z.string().optional().describe("Telegram group link (optional)"),
        website: zod_1.z.string().url().optional().describe("Website URL (optional)"),
        initialLiquiditySOL: zod_1.z.number().min(0.0001).default(0.0001).describe("Initial liquidity in SOL"),
        slippageBps: zod_1.z.number().min(1).max(1000).default(5).describe("Slippage tolerance in basis points"),
        priorityFee: zod_1.z.number().min(0.00001).default(0.00005).describe("Priority fee in SOL")
    }),
    handler: async (agent, input)=>{
        try {
            const { tokenName, tokenTicker, description, imageUrl } = input;
            const result = await (0, tools_1.launchPumpFunToken)(agent, tokenName, tokenTicker, description, imageUrl, input);
            return {
                status: "success",
                signature: result.signature,
                mint: result.mint,
                metadataUri: result.metadataUri,
                message: "Successfully launched token on Pump.fun"
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to launch token: ${error.message}`
            };
        }
    }
};
exports.default = launchPumpfunTokenAction; //# sourceMappingURL=launchPumpfunToken.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/agent/getWalletAddress.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const agent_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/agent/index.js [app-route] (ecmascript)");
const getWalletAddressAction = {
    name: "GET_WALLET_ADDRESS",
    similes: [
        "wallet address",
        "address",
        "wallet"
    ],
    description: "Get wallet address of the agent",
    examples: [
        [
            {
                input: {},
                output: {
                    status: "success",
                    address: "0x1234567890abcdef"
                },
                explanation: "The agent's wallet address is 0x1234567890abcdef"
            }
        ]
    ],
    schema: zod_1.z.object({}),
    handler: async (agent)=>({
            status: "success",
            address: (0, agent_1.get_wallet_address)(agent)
        })
};
exports.default = getWalletAddressAction; //# sourceMappingURL=getWalletAddress.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/flash/flashOpenTrade.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const flash_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/flash/index.js [app-route] (ecmascript)");
const flashOpenTradeAction = {
    name: "FLASH_OPEN_TRADE",
    similes: [
        "open trade",
        "open leveraged trade",
        "start trading position",
        "open position",
        "long position",
        "short position",
        "leverage trade",
        "margin trade"
    ],
    description: "Open a leveraged trading position on Flash.Trade protocol",
    examples: [
        [
            {
                input: {
                    token: "SOL",
                    side: "long",
                    collateralUsd: 100,
                    leverage: 5
                },
                output: {
                    status: "success",
                    signature: "4xKpN2...",
                    message: "Successfully opened 5x long position on SOL with $100 collateral"
                },
                explanation: "Open a 5x leveraged long position on SOL using $100 as collateral"
            }
        ]
    ],
    schema: zod_1.z.object({
        token: zod_1.z.string().describe("Token symbol to trade (e.g. SOL, ETH)"),
        side: zod_1.z.enum([
            "long",
            "short"
        ]).describe("Trading direction - long or short"),
        collateralUsd: zod_1.z.number().positive().describe("Amount of collateral in USD"),
        leverage: zod_1.z.number().positive().describe("Leverage multiplier for the trade")
    }),
    handler: async (agent, input)=>{
        try {
            const params = {
                token: input.token,
                side: input.side,
                collateralUsd: input.collateralUsd,
                leverage: input.leverage
            };
            const response = await (0, flash_1.flashOpenTrade)(agent, params);
            return {
                status: "success",
                signature: response,
                message: `Successfully opened ${params.leverage}x ${params.side} position on ${params.token} with $${params.collateralUsd} collateral`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Flash trade failed: ${error.message}`
            };
        }
    }
};
exports.default = flashOpenTradeAction; //# sourceMappingURL=flashOpenTrade.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/flash/flashCloseTrade.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const flash_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/flash/index.js [app-route] (ecmascript)");
const flashCloseTradeAction = {
    name: "FLASH_CLOSE_TRADE",
    similes: [
        "close trade",
        "close leveraged trade",
        "exit position",
        "close position",
        "exit trade",
        "close long",
        "close short",
        "take profit",
        "stop loss"
    ],
    description: "Close an existing leveraged trading position on Flash.Trade protocol",
    examples: [
        [
            {
                input: {
                    token: "SOL",
                    side: "long"
                },
                output: {
                    status: "success",
                    signature: "4xKpN2...",
                    message: "Successfully closed long position on SOL"
                },
                explanation: "Close an existing long position on SOL"
            }
        ]
    ],
    schema: zod_1.z.object({
        token: zod_1.z.string().describe("Token symbol of the position to close (e.g. SOL, ETH)"),
        side: zod_1.z.enum([
            "long",
            "short"
        ]).describe("Position side to close - long or short")
    }),
    handler: async (agent, input)=>{
        try {
            const params = {
                token: input.token,
                side: input.side
            };
            const response = await (0, flash_1.flashCloseTrade)(agent, params);
            return {
                status: "success",
                signature: response,
                message: `Successfully closed ${params.side} position on ${params.token}`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Flash trade close failed: ${error.message}`
            };
        }
    }
};
exports.default = flashCloseTradeAction; //# sourceMappingURL=flashCloseTrade.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/createMultisig.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const createMultisigAction = {
    name: "CREATE_MULTISIG_ACTION",
    similes: [
        "create multisig",
        "create squads multisig",
        "create 2-by-2 multisig",
        "create 2-of-2 multisig",
        "create 2-of-2 multisig account",
        "create 2-of-2 multisig account on Solana"
    ],
    description: `Create a 2-of-2 multisig account on Solana using Squads with the user and the agent, where both approvals will be required to run the transactions.
  
  Note: For one AI agent, only one 2-by-2 multisig can be created as it is pair-wise.`,
    examples: [
        [
            {
                input: {
                    creator: "7nE9GvcwsqzYxmJLSrYmSB1V1YoJWVK1KWzAcWAzjXkN"
                },
                output: {
                    status: "success",
                    message: "2-by-2 multisig account created successfully",
                    signature: "4xKpN2..."
                },
                explanation: "Create a 2-of-2 multisig account on Solana"
            }
        ]
    ],
    schema: zod_1.z.object({
        creator: zod_1.z.string()
    }),
    handler: async (agent, input)=>{
        const multisig = await (0, tools_1.create_squads_multisig)(agent, new web3_js_1.PublicKey(input.creator));
        return {
            status: "success",
            message: "2-by-2 multisig account created successfully",
            signature: multisig
        };
    }
};
exports.default = createMultisigAction; //# sourceMappingURL=createMultisig.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/approveMultisigProposal.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const approveMultisigProposalAction = {
    name: "APPROVE_MULTISIG_PROPOSAL_ACTION",
    similes: [
        "approve proposal",
        "approve proposal to transfer funds",
        "approve proposal to transfer funds from 2-of-2 multisig",
        "approve proposal to transfer funds from 2-of-2 multisig account",
        "approve proposal to transfer funds from 2-of-2 multisig account on Solana"
    ],
    description: `Approve a proposal to transfer funds from a 2-of-2 multisig account on Solana with the user and the agent, where both approvals will be required to run the transactions.
  
  Note: For one AI agent, only one 2-by-2 multisig can be created as it is pair-wise.`,
    examples: [
        [
            {
                input: {
                    transactionIndex: 0
                },
                output: {
                    status: "success",
                    message: "Proposal approved successfully",
                    transaction: "4xKpN2...",
                    transactionIndex: "0"
                },
                explanation: "Approve a proposal to transfer 1 SOL from 2-of-2 multisig account on Solana"
            }
        ]
    ],
    schema: zod_1.z.object({
        transactionIndex: zod_1.z.number().optional()
    }),
    handler: async (agent, input)=>{
        const tx = await (0, tools_1.multisig_approve_proposal)(agent, input.transactionIndex);
        return {
            status: "success",
            message: "Proposal approved successfully",
            transaction: tx,
            transactionIndex: input.transactionIndex.toString()
        };
    }
};
exports.default = approveMultisigProposalAction; //# sourceMappingURL=approveMultisigProposal.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/createMultisigProposal.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const createMultisigProposalAction = {
    name: "CREATE_MULTISIG_PROPOSAL_ACTION",
    similes: [
        "create proposal",
        "create proposal to transfer funds",
        "create proposal to transfer funds from 2-of-2 multisig",
        "create proposal to transfer funds from 2-of-2 multisig account",
        "create proposal to transfer funds from 2-of-2 multisig account on Solana"
    ],
    description: `Create a proposal to transfer funds from a 2-of-2 multisig account on Solana with the user and the agent, where both approvals will be required to run the transactions.
  
  If transactionIndex is not provided, the latest index will automatically be fetched and used.`,
    examples: [
        [
            {
                input: {
                    transactionIndex: 0
                },
                output: {
                    status: "success",
                    message: "Proposal created successfully",
                    transaction: "4xKpN2...",
                    transactionIndex: "0"
                },
                explanation: "Create a proposal to transfer 1 SOL from 2-of-2 multisig account on Solana"
            }
        ]
    ],
    schema: zod_1.z.object({
        transactionIndex: zod_1.z.number().optional()
    }),
    handler: async (agent, input)=>{
        const transactionIndex = input.transactionIndex !== undefined ? Number(input.transactionIndex) : undefined;
        const multisig = await (0, tools_1.multisig_create_proposal)(agent, transactionIndex);
        return {
            status: "success",
            message: "Proposal created successfully",
            transaction: multisig,
            transactionIndex: transactionIndex
        };
    }
};
exports.default = createMultisigProposalAction; //# sourceMappingURL=createMultisigProposal.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/depositToMultisigTreasury.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const depositToMultisigAction = {
    name: "DEPOSIT_TO_MULTISIG_ACTION",
    similes: [
        "deposit to multisig",
        "deposit to squads multisig",
        "deposit to 2-of-2 multisig account",
        "deposit to 2-of-2 multisig account on Solana",
        "deposit SOL to 2-of-2 multisig",
        "deposit SPL tokens to 2-of-2 multisig"
    ],
    description: `Deposit funds to a 2-of-2 multisig account on Solana with the user and the agent, where both approvals will be required to run the transactions.`,
    examples: [
        [
            {
                input: {
                    amount: 1
                },
                output: {
                    status: "success",
                    message: "Funds deposited to 2-by-2 multisig account successfully",
                    signature: "4xKpN2..."
                },
                explanation: "Deposit 1 SOL to 2-of-2 multisig account on Solana"
            }
        ]
    ],
    schema: zod_1.z.object({
        amount: zod_1.z.number().min(0, "Amount must be greater than 0")
    }),
    handler: async (agent, input)=>{
        const multisig = await (0, tools_1.multisig_deposit_to_treasury)(agent, input.amount);
        return {
            status: "success",
            message: "Funds deposited to 2-by-2 multisig account successfully",
            signature: multisig
        };
    }
};
exports.default = depositToMultisigAction; //# sourceMappingURL=depositToMultisigTreasury.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/executeMultisigProposal.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const executeMultisigProposalAction = {
    name: "EXECUTE_MULTISIG_PROPOSAL_ACTION",
    similes: [
        "execute proposal",
        "execute proposal to transfer funds",
        "execute proposal to transfer funds from 2-of-2 multisig",
        "execute proposal to transfer funds from 2-of-2 multisig account",
        "execute proposal to transfer funds from 2-of-2 multisig account on Solana"
    ],
    description: `Execute a proposal to transfer funds from a 2-of-2 multisig account on Solana with the user and the agent, where both approvals will be required to run the transactions.`,
    examples: [
        [
            {
                input: {
                    proposalIndex: 0
                },
                output: {
                    status: "success",
                    message: "Proposal executed successfully",
                    transaction: "4xKpN2...",
                    proposalIndex: "0"
                },
                explanation: "Execute a proposal to transfer 1 SOL from 2-of-2 multisig account on Solana"
            }
        ]
    ],
    schema: zod_1.z.object({
        proposalIndex: zod_1.z.number().optional()
    }),
    handler: async (agent, input)=>{
        const proposalIndex = input.proposalIndex !== undefined ? Number(input.proposalIndex) : undefined;
        const multisig = await (0, tools_1.multisig_execute_proposal)(agent, proposalIndex);
        return {
            status: "success",
            message: "Proposal executed successfully",
            transaction: multisig,
            proposalIndex
        };
    }
};
exports.default = executeMultisigProposalAction; //# sourceMappingURL=executeMultisigProposal.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/rejectMultisigProposal.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const rejectMultisigProposalAction = {
    name: "REJECT_MULTISIG_PROPOSAL_ACTION",
    similes: [
        "reject proposal",
        "reject proposal to transfer funds",
        "reject proposal to transfer funds from 2-of-2 multisig",
        "reject proposal to transfer funds from 2-of-2 multisig account",
        "reject proposal to transfer funds from 2-of-2 multisig account on Solana"
    ],
    description: `Reject a proposal to transfer funds from a 2-of-2 multisig account on Solana with the user and the agent, where both approvals will be required to run the transactions.`,
    examples: [
        [
            {
                input: {
                    proposalIndex: 0
                },
                output: {
                    status: "success",
                    message: "Proposal rejected successfully",
                    transaction: "4xKpN2...",
                    proposalIndex: "0"
                },
                explanation: "Reject a proposal to transfer 1 SOL from 2-of-2 multisig account on Solana"
            }
        ]
    ],
    schema: zod_1.z.object({
        proposalIndex: zod_1.z.number().optional()
    }),
    handler: async (agent, input)=>{
        const proposalIndex = input.proposalIndex !== undefined ? Number(input.proposalIndex) : undefined;
        const tx = await (0, tools_1.multisig_reject_proposal)(agent, proposalIndex);
        return {
            status: "success",
            message: "Proposal rejected successfully",
            transaction: tx,
            proposalIndex
        };
    }
};
exports.default = rejectMultisigProposalAction; //# sourceMappingURL=rejectMultisigProposal.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/transferFromMultisigTreasury.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const tools_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const transferFromMultisigAction = {
    name: "TRANSFER_FROM_MULTISIG_ACTION",
    similes: [
        "transfer from multisig",
        "transfer from squads multisig",
        "transfer SOL from 2-by-2 multisig",
        "transfer from 2-of-2 multisig account",
        "transfer from 2-of-2 multisig account on Solana"
    ],
    description: `Create a transaction to transfer funds from a 2-of-2 multisig account on Solana using Squads with the user and the agent, where both approvals will be required to run the transactions.`,
    examples: [
        [
            {
                input: {
                    amount: 1,
                    recipient: "7nE9GvcwsqzYxmJLSrYmSB1V1YoJWVK1KWzAcWAzjXkN"
                },
                output: {
                    status: "success",
                    message: "Transaction added to 2-by-2 multisig account successfully",
                    transaction: "4xKpN2...",
                    amount: "1",
                    recipient: "7nE9GvcwsqzYxmJLSrYmSB1V1YoJWVK1KWzAcWAzjXkN"
                },
                explanation: "Transfer 1 SOL from 2-of-2 multisig account on Solana"
            }
        ]
    ],
    schema: zod_1.z.object({
        amount: zod_1.z.number().min(0, "Amount must be greater than 0"),
        recipient: zod_1.z.string()
    }),
    handler: async (agent, input)=>{
        const multisig = await (0, tools_1.multisig_transfer_from_treasury)(agent, input.amount, new web3_js_1.PublicKey(input.recipient));
        return {
            status: "success",
            message: "Transaction added to 2-by-2 multisig account successfully",
            transaction: multisig,
            amount: input.amount,
            recipient: input.recipient
        };
    }
};
exports.default = transferFromMultisigAction; //# sourceMappingURL=transferFromMultisigTreasury.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/helius/createWebhook.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const helius_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/index.js [app-route] (ecmascript)");
const createWebhookAction = {
    name: "CREATE_HELIOUS_WEBHOOK",
    similes: [
        "setup webhook",
        "register webhook",
        "initiate webhook"
    ],
    description: "Creates a new webhook in the Helius system to monitor transactions for specified account addresses",
    examples: [
        [
            {
                input: {
                    accountAddresses: [
                        "BVdNLvyG2DNiWAXBE9qAmc4MTQXymd5Bzfo9xrQSUzVP",
                        "Eo2ciguhMLmcTWXELuEQPdu7DWZt67LHXb2rdHZUbot7"
                    ],
                    webhookURL: "https://yourdomain.com/webhook"
                },
                output: {
                    status: "success",
                    webhookURL: "https://yourdomain.com/webhook",
                    webhookID: "webhook_123",
                    message: "Webhook created successfully."
                },
                explanation: "Creates a Webhook to send live notifications on the given Url with the wallet Addresses."
            }
        ]
    ],
    schema: zod_1.z.object({
        accountAddresses: zod_1.z.array(zod_1.z.string()).min(1).describe("List of Solana account public keys to monitor"),
        webhookURL: zod_1.z.string().url().describe("The URL where Helius will send webhook notifications")
    }),
    handler: async (agent, input)=>{
        const response = await (0, helius_1.create_HeliusWebhook)(agent, input.accountAddresses, input.webhookURL);
        return {
            status: "success",
            ...response,
            message: "Webhook created successfully."
        };
    }
};
exports.default = createWebhookAction; //# sourceMappingURL=createWebhook.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/helius/deleteWebhook.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const helius_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/index.js [app-route] (ecmascript)");
const deleteWebhookAction = {
    name: "DELETE_HELIOUS_WEBHOOK",
    similes: [
        "remove webhook",
        "unregister webhook",
        "delete webhook"
    ],
    description: "Deletes a Helius webhook by its unique ID",
    examples: [
        [
            {
                input: {
                    webhookID: "webhook_123"
                },
                output: {
                    status: "success",
                    message: "Webhook deleted successfully."
                },
                explanation: "Permanently removes a Helius webhook."
            }
        ]
    ],
    schema: zod_1.z.object({
        webhookID: zod_1.z.string().min(1).describe("The unique identifier of the Helius webhook to delete")
    }),
    handler: async (agent, input)=>{
        const result = await (0, helius_1.deleteHeliusWebhook)(agent, input.webhookID);
        return {
            status: "success",
            message: result.message || "Webhook deleted successfully."
        };
    }
};
exports.default = deleteWebhookAction; //# sourceMappingURL=deleteWebhook.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/helius/getAssetsbyOwner.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const helius_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/index.js [app-route] (ecmascript)");
const getAssetsByOwnerAction = {
    name: "FETCH_ASSETS_BY_OWNER",
    similes: [
        "fetch assets",
        "get assets",
        "retrieve assets",
        "list assets",
        "assets by owner"
    ],
    description: "Fetch assets owned by a specific Solana wallet address using the Helius Digital Asset Standard API",
    examples: [
        [
            {
                input: {
                    ownerPublicKey: "4Pf8q3mHGLdkoc1M8xWZwW5q32gYmdhwC2gJ8K9EAGDX",
                    limit: 10
                },
                output: {
                    status: "success",
                    assets: [
                        {
                            name: "Helius NFT #1",
                            type: "NFT",
                            owner: "4Pf8q3mHGLdkoc1M8xWZwW5q32gYmdhwC2gJ8K9EAGDX"
                        },
                        {
                            name: "Helius Token #10",
                            type: "Token",
                            owner: "4Pf8q3mHGLdkoc1M8xWZwW5q32gYmdhwC2gJ8K9EAGDX"
                        }
                    ],
                    message: "Successfully fetched assets for the wallet address"
                },
                explanation: "Fetches a list of assets from the for the given wallet address with a limit of 10 items."
            }
        ]
    ],
    schema: zod_1.z.object({
        ownerPublicKey: zod_1.z.string().describe("Owner's Solana wallet PublicKey"),
        limit: zod_1.z.number().positive().describe("Number of assets to retrieve per request")
    }),
    handler: async (agent, input)=>{
        try {
            const assets = await (0, helius_1.getAssetsByOwner)(agent, new web3_js_1.PublicKey(input.ownerPublicKey), input.limit);
            return {
                status: "success",
                assets: assets,
                message: `Successfully fetched assets for the wallet address: ${input.ownerPublicKey}`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to fetch assets: ${error.message}`
            };
        }
    }
};
exports.default = getAssetsByOwnerAction; //# sourceMappingURL=getAssetsbyOwner.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/helius/getWebhook.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const helius_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/index.js [app-route] (ecmascript)");
const getWebhookAction = {
    name: "GET_HELIOUS_WEBHOOK",
    similes: [
        "fetch webhook details",
        "retrieve webhook",
        "get webhook info"
    ],
    description: "Retrieves details of a Helius webhook by its unique ID",
    examples: [
        [
            {
                input: {
                    webhookID: "webhook_123"
                },
                output: {
                    status: "success",
                    wallet: "WalletPublicKey",
                    webhookURL: "https://yourdomain.com/webhook",
                    transactionTypes: [
                        "Any"
                    ],
                    accountAddresses: [
                        "SomePublicKey",
                        "AnotherPublicKey"
                    ],
                    webhookType: "enhanced",
                    message: "Webhook details retrieved successfully."
                },
                explanation: "Retrieves detailed information about an existing Helius webhook, including the wallet address it monitors, the types of transactions it tracks, and the specific webhook URL."
            }
        ]
    ],
    schema: zod_1.z.object({
        webhookID: zod_1.z.string().min(1).describe("The unique identifier of the Helius webhook to retrieve")
    }),
    handler: async (agent, input)=>{
        const webhookDetails = await (0, helius_1.getHeliusWebhook)(agent, input.webhookID);
        return {
            status: "success",
            ...webhookDetails,
            message: "Webhook details retrieved successfully."
        };
    }
};
exports.default = getWebhookAction; //# sourceMappingURL=getWebhook.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/helius/parseTransaction.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const helius_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/index.js [app-route] (ecmascript)");
const parseSolanaTransactionAction = {
    name: "PARSE_SOLANA_TRANSACTION",
    similes: [
        "parse transaction",
        "analyze transaction",
        "inspect transaction",
        "decode transaction"
    ],
    description: "Parse a Solana transaction to retrieve detailed information using the Helius Enhanced Transactions API",
    examples: [
        [
            {
                input: {
                    transactionId: "4zZVvbgzcriyjAeEiK1w7CeDCt7gYThUCZat3ULTNerzKHF4WLfRG2YUjbRovfFJ639TAyARB4oyRDcLVUvrakq7"
                },
                output: {
                    status: "success",
                    transaction: {
                        details: "Transaction details...",
                        involvedAccounts: [
                            "Account1",
                            "Account2"
                        ],
                        executedOperations: [
                            {
                                operation: "Transfer",
                                amount: "1000 SOL"
                            }
                        ]
                    },
                    message: "Successfully parsed transaction: 4zZVvbgzcriyjAeEiK1w7CeDCt7gYThUCZat3ULTNerzKHF4WLfRG2YUjbRovfFJ639TAyARB4oyRDcLVUvrakq7"
                },
                explanation: "Parse a Transaction to transform it into human readable format."
            }
        ]
    ],
    schema: zod_1.z.object({
        transactionId: zod_1.z.string().min(1).describe("The Solana transaction ID to parse")
    }),
    handler: async (agent, input)=>{
        try {
            const parsedTransactionData = await (0, helius_1.parseTransaction)(agent, input.transactionId);
            return {
                status: "success",
                transaction: parsedTransactionData,
                message: `Successfully parsed transaction: ${input.transactionId}`
            };
        } catch (error) {
            return {
                status: "error",
                message: `Failed to parse transaction: ${error.message}`
            };
        }
    }
};
exports.default = parseSolanaTransactionAction; //# sourceMappingURL=parseTransaction.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/helius/sendTransactionWithPriority.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const zod_1 = __turbopack_require__("[project]/node_modules/.pnpm/zod@3.24.1/node_modules/zod/lib/index.js [app-route] (ecmascript)");
const helius_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/tools/helius/index.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const sendTransactionWithPriorityFeeAction = {
    name: "SEND_TRANSACTION_WITH_PRIORITY_FEE",
    similes: [
        "send SOL with fee",
        "transfer tokens with priority",
        "execute priority transaction"
    ],
    description: "Sends SOL or SPL tokens from a wallet with an estimated priority fee, ensuring faster processing on the Solana network.",
    examples: [
        [
            {
                input: {
                    priorityLevel: "High",
                    amount: 2,
                    to: "BVdNLvyG2DNiWAXBE9qAmc4MTQXymd5Bzfo9xrQSUzVP",
                    splmintAddress: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
                },
                output: {
                    status: "success",
                    transactionId: "5Xgq9xVABhwXpNStWpfqxS6Vm5Eau91pjfeHNwJbRgis",
                    fee: 5000,
                    message: "Transaction sent with priority fee successfully."
                },
                explanation: "Sends 2 USDC to BVdNLvyG2DNiWAXBE9qAmc4MTQXymd5Bzfo9xrQSUzVP with High priority fee option."
            }
        ]
    ],
    schema: zod_1.z.object({
        priorityLevel: zod_1.z.enum([
            "Min",
            "Low",
            "Medium",
            "High",
            "VeryHigh",
            "UnsafeMax"
        ]).describe("Priority level to determine the urgency of the transaction."),
        amount: zod_1.z.number().positive().describe("Amount of SOL or SPL tokens to send."),
        to: zod_1.z.string().describe("Recipient's PublicKey."),
        splmintAddress: zod_1.z.string().optional().describe("Optional SPL token address, if transferring tokens other than SOL.")
    }),
    handler: async (agent, input)=>{
        const { priorityLevel, amount, to, splmintAddress } = input;
        const toPublicKey = new web3_js_1.PublicKey(to);
        const splmintPublicKey = splmintAddress ? new web3_js_1.PublicKey(splmintAddress) : undefined;
        const result = await (0, helius_1.sendTransactionWithPriorityFee)(agent, priorityLevel, amount, toPublicKey, splmintPublicKey);
        return {
            status: "success",
            transactionId: result.transactionId,
            fee: result.fee,
            message: "Transaction sent with priority fee successfully."
        };
    }
};
exports.default = sendTransactionWithPriorityFeeAction; //# sourceMappingURL=sendTransactionWithPriority.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ACTIONS = void 0;
const deployToken_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/metaplex/deployToken.js [app-route] (ecmascript)"));
const balance_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/solana/balance.js [app-route] (ecmascript)"));
const transfer_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/solana/transfer.js [app-route] (ecmascript)"));
const deployCollection_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/metaplex/deployCollection.js [app-route] (ecmascript)"));
const mintNFT_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/metaplex/mintNFT.js [app-route] (ecmascript)"));
const trade_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/jupiter/trade.js [app-route] (ecmascript)"));
const requestFunds_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/solana/requestFunds.js [app-route] (ecmascript)"));
const registerDomain_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/sns/registerDomain.js [app-route] (ecmascript)"));
const getTokenData_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/jupiter/getTokenData.js [app-route] (ecmascript)"));
const getTPS_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/solana/getTPS.js [app-route] (ecmascript)"));
const fetchPrice_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/jupiter/fetchPrice.js [app-route] (ecmascript)"));
const stakeWithJup_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/jupiter/stakeWithJup.js [app-route] (ecmascript)"));
const stakeWithSolayer_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/solayer/stakeWithSolayer.js [app-route] (ecmascript)"));
const registerDomain_2 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/sns/registerDomain.js [app-route] (ecmascript)"));
const lendAsset_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/lulo/lendAsset.js [app-route] (ecmascript)"));
const createGibworkTask_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/gibwork/createGibworkTask.js [app-route] (ecmascript)"));
const resolveSolDomain_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/sns/resolveSolDomain.js [app-route] (ecmascript)"));
const pythFetchPrice_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/pyth/pythFetchPrice.js [app-route] (ecmascript)"));
const getOwnedDomainsForTLD_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/alldomains/getOwnedDomainsForTLD.js [app-route] (ecmascript)"));
const getPrimaryDomain_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/sns/getPrimaryDomain.js [app-route] (ecmascript)"));
const getAllDomainsTLDs_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/alldomains/getAllDomainsTLDs.js [app-route] (ecmascript)"));
const getOwnedAllDomains_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/alldomains/getOwnedAllDomains.js [app-route] (ecmascript)"));
const createImage_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/agent/createImage.js [app-route] (ecmascript)"));
const getMainAllDomainsDomain_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/sns/getMainAllDomainsDomain.js [app-route] (ecmascript)"));
const getAllRegisteredAllDomains_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/sns/getAllRegisteredAllDomains.js [app-route] (ecmascript)"));
const raydiumCreateCpmm_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/raydium/raydiumCreateCpmm.js [app-route] (ecmascript)"));
const raydiumCreateAmmV4_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/raydium/raydiumCreateAmmV4.js [app-route] (ecmascript)"));
const createOrcaSingleSidedWhirlpool_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/orca/createOrcaSingleSidedWhirlpool.js [app-route] (ecmascript)"));
const launchPumpfunToken_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/pumpfun/launchPumpfunToken.js [app-route] (ecmascript)"));
const getWalletAddress_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/agent/getWalletAddress.js [app-route] (ecmascript)"));
const flashOpenTrade_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/flash/flashOpenTrade.js [app-route] (ecmascript)"));
const flashCloseTrade_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/flash/flashCloseTrade.js [app-route] (ecmascript)"));
const createMultisig_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/createMultisig.js [app-route] (ecmascript)"));
const approveMultisigProposal_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/approveMultisigProposal.js [app-route] (ecmascript)"));
const createMultisigProposal_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/createMultisigProposal.js [app-route] (ecmascript)"));
const depositToMultisigTreasury_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/depositToMultisigTreasury.js [app-route] (ecmascript)"));
const executeMultisigProposal_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/executeMultisigProposal.js [app-route] (ecmascript)"));
const rejectMultisigProposal_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/rejectMultisigProposal.js [app-route] (ecmascript)"));
const transferFromMultisigTreasury_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/squads/transferFromMultisigTreasury.js [app-route] (ecmascript)"));
const createWebhook_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/helius/createWebhook.js [app-route] (ecmascript)"));
const deleteWebhook_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/helius/deleteWebhook.js [app-route] (ecmascript)"));
const getAssetsbyOwner_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/helius/getAssetsbyOwner.js [app-route] (ecmascript)"));
const getWebhook_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/helius/getWebhook.js [app-route] (ecmascript)"));
const parseTransaction_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/helius/parseTransaction.js [app-route] (ecmascript)"));
const sendTransactionWithPriority_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/helius/sendTransactionWithPriority.js [app-route] (ecmascript)"));
exports.ACTIONS = {
    WALLET_ADDRESS_ACTION: getWalletAddress_1.default,
    DEPLOY_TOKEN_ACTION: deployToken_1.default,
    BALANCE_ACTION: balance_1.default,
    TRANSFER_ACTION: transfer_1.default,
    DEPLOY_COLLECTION_ACTION: deployCollection_1.default,
    MINT_NFT_ACTION: mintNFT_1.default,
    TRADE_ACTION: trade_1.default,
    REQUEST_FUNDS_ACTION: requestFunds_1.default,
    RESOLVE_DOMAIN_ACTION: registerDomain_1.default,
    GET_TOKEN_DATA_ACTION: getTokenData_1.default,
    GET_TPS_ACTION: getTPS_1.default,
    FETCH_PRICE_ACTION: fetchPrice_1.default,
    STAKE_WITH_JUP_ACTION: stakeWithJup_1.default,
    STAKE_WITH_SOLAYER_ACTION: stakeWithSolayer_1.default,
    REGISTER_DOMAIN_ACTION: registerDomain_2.default,
    LEND_ASSET_ACTION: lendAsset_1.default,
    CREATE_GIBWORK_TASK_ACTION: createGibworkTask_1.default,
    RESOLVE_SOL_DOMAIN_ACTION: resolveSolDomain_1.default,
    PYTH_FETCH_PRICE_ACTION: pythFetchPrice_1.default,
    GET_OWNED_DOMAINS_FOR_TLD_ACTION: getOwnedDomainsForTLD_1.default,
    GET_PRIMARY_DOMAIN_ACTION: getPrimaryDomain_1.default,
    GET_ALL_DOMAINS_TLDS_ACTION: getAllDomainsTLDs_1.default,
    GET_OWNED_ALL_DOMAINS_ACTION: getOwnedAllDomains_1.default,
    CREATE_IMAGE_ACTION: createImage_1.default,
    GET_MAIN_ALL_DOMAINS_DOMAIN_ACTION: getMainAllDomainsDomain_1.default,
    GET_ALL_REGISTERED_ALL_DOMAINS_ACTION: getAllRegisteredAllDomains_1.default,
    RAYDIUM_CREATE_CPMM_ACTION: raydiumCreateCpmm_1.default,
    RAYDIUM_CREATE_AMM_V4_ACTION: raydiumCreateAmmV4_1.default,
    CREATE_ORCA_SINGLE_SIDED_WHIRLPOOL_ACTION: createOrcaSingleSidedWhirlpool_1.default,
    LAUNCH_PUMPFUN_TOKEN_ACTION: launchPumpfunToken_1.default,
    FLASH_OPEN_TRADE_ACTION: flashOpenTrade_1.default,
    FLASH_CLOSE_TRADE_ACTION: flashCloseTrade_1.default,
    CREATE_MULTISIG_ACTION: createMultisig_1.default,
    DEPOSIT_TO_MULTISIG_ACTION: depositToMultisigTreasury_1.default,
    TRANSFER_FROM_MULTISIG_ACTION: transferFromMultisigTreasury_1.default,
    CREATE_MULTISIG_PROPOSAL_ACTION: createMultisigProposal_1.default,
    APPROVE_MULTISIG_PROPOSAL_ACTION: approveMultisigProposal_1.default,
    REJECT_MULTISIG_PROPOSAL_ACTION: rejectMultisigProposal_1.default,
    EXECUTE_MULTISIG_PROPOSAL_ACTION: executeMultisigProposal_1.default,
    CREATE_WEBHOOK_ACTION: createWebhook_1.default,
    DELETE_WEBHOOK_ACTION: deleteWebhook_1.default,
    GET_ASSETS_BY_OWNER_ACTION: getAssetsbyOwner_1.default,
    GET_WEBHOOK_ACTION: getWebhook_1.default,
    PARSE_TRANSACTION_ACTION: parseTransaction_1.default,
    SEND_TRANSACTION_WITH_PRIORITY_ACTION: sendTransactionWithPriority_1.default
}; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/actionExecutor.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.findAction = findAction;
exports.executeAction = executeAction;
exports.getActionExamples = getActionExamples;
const actions_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/index.js [app-route] (ecmascript)");
/**
 * Find an action by its name or one of its similes
 */ function findAction(query) {
    const normalizedQuery = query.toLowerCase().trim();
    return Object.values(actions_1.ACTIONS).find((action)=>action.name.toLowerCase() === normalizedQuery || action.similes.some((simile)=>simile.toLowerCase() === normalizedQuery));
}
/**
 * Execute an action with the given input
 */ async function executeAction(action, agent, input) {
    try {
        // Validate input using Zod schema
        const validatedInput = action.schema.parse(input);
        // Execute the action with validated input
        const result = await action.handler(agent, validatedInput);
        return {
            status: "success",
            ...result
        };
    } catch (error) {
        // Handle Zod validation errors specially
        if (error.errors) {
            return {
                status: "error",
                message: "Validation error",
                details: error.errors,
                code: "VALIDATION_ERROR"
            };
        }
        return {
            status: "error",
            message: error.message,
            code: error.code || "EXECUTION_ERROR"
        };
    }
}
/**
 * Get examples for an action
 */ function getActionExamples(action) {
    return action.examples.flat().map((example)=>{
        return `Input: ${JSON.stringify(example.input, null, 2)}
Output: ${JSON.stringify(example.output, null, 2)}
Explanation: ${example.explanation}
---`;
    }).join("\n");
} //# sourceMappingURL=actionExecutor.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/vercel-ai/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createSolanaTools = createSolanaTools;
const ai_1 = __turbopack_require__("[project]/node_modules/.pnpm/ai@4.1.0_react@19.0.0_zod@3.24.1/node_modules/ai/dist/index.js [app-route] (ecmascript)");
const actionExecutor_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/actionExecutor.js [app-route] (ecmascript)");
const actions_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/index.js [app-route] (ecmascript)");
function createSolanaTools(solanaAgentKit) {
    const tools = {};
    const actionKeys = Object.keys(actions_1.ACTIONS);
    for (const key of actionKeys){
        const action = actions_1.ACTIONS[key];
        tools[key] = (0, ai_1.tool)({
            // @ts-expect-error Value matches type however TS still shows error
            id: action.name,
            description: action.description,
            parameters: action.schema,
            execute: async (params)=>await (0, actionExecutor_1.executeAction)(action, solanaAgentKit, params)
        });
    }
    return tools;
} //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/types/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
}); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/wallet/EmbeddedWallet.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseWallet = void 0;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const bs58_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bs58@6.0.0/node_modules/bs58/src/cjs/index.cjs [app-route] (ecmascript)"));
class BaseWallet extends web3_js_1.Keypair {
    constructor(privateKey){
        super();
        try {
            const keypair = typeof privateKey === "string" ? web3_js_1.Keypair.fromSecretKey(bs58_1.default.decode(privateKey)) : privateKey;
            Object.assign(this, keypair);
        } catch (error) {
            throw new Error(`Failed to initialize wallet: ${error instanceof Error ? error.message : "Unknown error"}`);
        }
    }
    async signTransaction(transaction) {
        try {
            if (transaction instanceof web3_js_1.Transaction) {
                transaction.partialSign(this);
            } else if (transaction instanceof web3_js_1.VersionedTransaction) {
                transaction.sign([
                    this
                ]);
            }
            return transaction;
        } catch (error) {
            throw new Error(`Failed to sign transaction: ${error instanceof Error ? error.message : "Unknown error"}`);
        }
    }
    async signAllTransactions(transactions) {
        try {
            return transactions.map((tx)=>{
                if (tx instanceof web3_js_1.Transaction) {
                    tx.partialSign(this);
                } else if (tx instanceof web3_js_1.VersionedTransaction) {
                    tx.sign([
                        this
                    ]);
                }
                return tx;
            });
        } catch (error) {
            throw new Error(`Failed to sign transactions: ${error instanceof Error ? error.message : "Unknown error"}`);
        }
    }
}
exports.BaseWallet = BaseWallet; //# sourceMappingURL=EmbeddedWallet.js.map
}}),
"[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ACTIONS = exports.createVercelAITools = exports.createSolanaTools = exports.SolanaAgentKit = void 0;
const agent_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/agent/index.js [app-route] (ecmascript)");
Object.defineProperty(exports, "SolanaAgentKit", {
    enumerable: true,
    get: function() {
        return agent_1.SolanaAgentKit;
    }
});
const langchain_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/langchain/index.js [app-route] (ecmascript)");
Object.defineProperty(exports, "createSolanaTools", {
    enumerable: true,
    get: function() {
        return langchain_1.createSolanaTools;
    }
});
const vercel_ai_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/vercel-ai/index.js [app-route] (ecmascript)");
Object.defineProperty(exports, "createVercelAITools", {
    enumerable: true,
    get: function() {
        return vercel_ai_1.createSolanaTools;
    }
});
// Optional: Export types that users might need
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/types/index.js [app-route] (ecmascript)"), exports);
// Export action system
var actions_1 = __turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/actions/index.js [app-route] (ecmascript)");
Object.defineProperty(exports, "ACTIONS", {
    enumerable: true,
    get: function() {
        return actions_1.ACTIONS;
    }
});
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/utils/actionExecutor.js [app-route] (ecmascript)"), exports);
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/solana-agent-kit@https+++codeload.github.com+slimeonmyhead+solana-agent-kit+tar.gz+c571e8b59e_2kpvunuw5b22pmdc6y3y5o5wwi/node_modules/solana-agent-kit/dist/wallet/EmbeddedWallet.js [app-route] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),

};

//# sourceMappingURL=e8688_solana-agent-kit_dist_6fd0ad._.js.map
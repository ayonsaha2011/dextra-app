module.exports = {

"[project]/node_modules/.pnpm/@aptos-labs+ts-sdk@1.33.1/node_modules/@aptos-labs/ts-sdk/dist/common/chunk-F43XVDYJ.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
var i = Object.defineProperty;
var u = Object.getOwnPropertyDescriptor;
var m = (e, n, t, r)=>{
    for(var o = r > 1 ? void 0 : r ? u(n, t) : n, s = e.length - 1, a; s >= 0; s--)(a = e[s]) && (o = (r ? a(n, t, o) : a(o)) || o);
    return r && o && i(n, t, o), o;
};
var _jsbase64 = __turbopack_require__("[project]/node_modules/.pnpm/js-base64@3.7.7/node_modules/js-base64/base64.js [app-route] (ecmascript)");
async function p(e) {
    return new Promise((n)=>{
        setTimeout(n, e);
    });
}
function f(e) {
    return e instanceof Error ? e.message : String(e);
}
var _ = ()=>Math.floor(Date.now() / 1e3);
function S(e) {
    let n = new Date(e * 1e3);
    return n.setMinutes(0), n.setSeconds(0), n.setMilliseconds(0), Math.floor(n.getTime() / 1e3);
}
function x(e) {
    let n = e.replace(/-/g, "+").replace(/_/g, "/"), t = n + "==".substring(0, (3 - n.length % 3) % 3);
    return _jsbase64.decode.call(void 0, t);
}
var h = (e, n)=>e * 10 ** n, y = exports.h = (e, n)=>e / 10 ** n, c = (e)=>{
    let n = "";
    for(let t = 2; t < e.length; t += 2)n += String.fromCharCode(parseInt(e.substring(t, t + 2), 16));
    return n;
}, b = exports.i = (e)=>{
    let { account_address: n, module_name: t, struct_name: r } = e, o = c(t), s = c(r);
    return `${n}::${o}::${s}`;
}, M = exports.j = (e)=>typeof e == "object" && !Array.isArray(e) && e !== null && "account_address" in e && "module_name" in e && "struct_name" in e && typeof e.account_address == "string" && typeof e.module_name == "string" && typeof e.struct_name == "string";
exports.a = m;
exports.b = p;
exports.c = f;
exports.d = _;
exports.e = S;
exports.f = x;
exports.g = h;
exports.h = y;
exports.i = b;
exports.j = M; //# sourceMappingURL=chunk-F43XVDYJ.js.map
}}),
"[project]/node_modules/.pnpm/@aptos-labs+ts-sdk@1.33.1/node_modules/@aptos-labs/ts-sdk/dist/common/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) {
        return obj;
    } else {
        var newObj = {};
        if (obj != null) {
            for(var key in obj){
                if (Object.prototype.hasOwnProperty.call(obj, key)) {
                    newObj[key] = obj[key];
                }
            }
        }
        newObj.default = obj;
        return newObj;
    }
}
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function _nullishCoalesce(lhs, rhsFn) {
    if (lhs != null) {
        return lhs;
    } else {
        return rhsFn();
    }
}
function _optionalChain(ops) {
    let lastAccessLHS = undefined;
    let value = ops[0];
    let i = 1;
    while(i < ops.length){
        const op = ops[i];
        const fn = ops[i + 1];
        i += 2;
        if ((op === 'optionalAccess' || op === 'optionalCall') && value == null) {
            return undefined;
        }
        if (op === 'access' || op === 'optionalAccess') {
            lastAccessLHS = value;
            value = fn(value);
        } else if (op === 'call' || op === 'optionalCall') {
            value = fn((...args)=>value.call(lastAccessLHS, ...args));
            lastAccessLHS = undefined;
        }
    }
    return value;
}
function _optionalChainDelete(ops) {
    const result = _optionalChain(ops);
    return result == null ? true : result;
}
var _chunkF43XVDYJjs = __turbopack_require__("[project]/node_modules/.pnpm/@aptos-labs+ts-sdk@1.33.1/node_modules/@aptos-labs/ts-sdk/dist/common/chunk-F43XVDYJ.js [app-route] (ecmascript)");
var Nr = 255, Fr = 65535, Ue = 4294967295, ot = 18446744073709551615n, Zt = 340282366920938463463374607431768211455n, Gr = 115792089237316195423570985008687907853269984665640564039457584007913129639935n;
var N = class {
    constructor(e){
        this.buffer = new ArrayBuffer(e.length), new Uint8Array(this.buffer).set(e, 0), this.offset = 0;
    }
    read(e) {
        if (this.offset + e > this.buffer.byteLength) throw new Error("Reached to the end of buffer");
        let t = this.buffer.slice(this.offset, this.offset + e);
        return this.offset += e, t;
    }
    remaining() {
        return this.buffer.byteLength - this.offset;
    }
    deserializeStr() {
        let e = this.deserializeBytes();
        return new TextDecoder().decode(e);
    }
    deserializeOptionStr() {
        return this.deserializeOption("string");
    }
    deserializeOption(e, t) {
        if (this.deserializeBool()) {
            if (e === "string") return this.deserializeStr();
            if (e === "bytes") return this.deserializeBytes();
            if (e === "fixedBytes") {
                if (t === void 0) throw new Error("Fixed bytes length not provided");
                return this.deserializeFixedBytes(t);
            }
            return this.deserialize(e);
        }
    }
    deserializeBytes() {
        let e = this.deserializeUleb128AsU32();
        return new Uint8Array(this.read(e));
    }
    deserializeFixedBytes(e) {
        return new Uint8Array(this.read(e));
    }
    deserializeBool() {
        let e = new Uint8Array(this.read(1))[0];
        if (e !== 1 && e !== 0) throw new Error("Invalid boolean value");
        return e === 1;
    }
    deserializeU8() {
        return new DataView(this.read(1)).getUint8(0);
    }
    deserializeU16() {
        return new DataView(this.read(2)).getUint16(0, !0);
    }
    deserializeU32() {
        return new DataView(this.read(4)).getUint32(0, !0);
    }
    deserializeU64() {
        let e = this.deserializeU32(), t = this.deserializeU32();
        return BigInt(BigInt(t) << BigInt(32) | BigInt(e));
    }
    deserializeU128() {
        let e = this.deserializeU64(), t = this.deserializeU64();
        return BigInt(t << BigInt(64) | e);
    }
    deserializeU256() {
        let e = this.deserializeU128(), t = this.deserializeU128();
        return BigInt(t << BigInt(128) | e);
    }
    deserializeUleb128AsU32() {
        let e = BigInt(0), t = 0;
        for(; e < Ue;){
            let n = this.deserializeU8();
            if (e |= BigInt(n & 127) << BigInt(t), !(n & 128)) break;
            t += 7;
        }
        if (e > Ue) throw new Error("Overflow while parsing uleb128-encoded uint32 value");
        return Number(e);
    }
    deserialize(e) {
        return e.deserialize(this);
    }
    deserializeVector(e) {
        let t = this.deserializeUleb128AsU32(), n = new Array;
        for(let i = 0; i < t; i += 1)n.push(this.deserialize(e));
        return n;
    }
};
var _utils = __turbopack_require__("[project]/node_modules/.pnpm/@noble+hashes@1.7.0/node_modules/@noble/hashes/utils.js [app-route] (ecmascript)");
var Q = class extends Error {
    constructor(e, t){
        super(e), this.invalidReason = t;
    }
};
var Ra = ((n)=>(n.TOO_SHORT = "too_short", n.INVALID_LENGTH = "invalid_length", n.INVALID_HEX_CHARS = "invalid_hex_chars", n))(Ra || {}), g = exports.Hex = class r {
    constructor(e){
        this.data = e;
    }
    toUint8Array() {
        return this.data;
    }
    toStringWithoutPrefix() {
        return _utils.bytesToHex.call(void 0, this.data);
    }
    toString() {
        return `0x${this.toStringWithoutPrefix()}`;
    }
    static fromHexString(e) {
        let t = e;
        if (t.startsWith("0x") && (t = t.slice(2)), t.length === 0) throw new Q("Hex string is too short, must be at least 1 char long, excluding the optional leading 0x.", "too_short");
        if (t.length % 2 !== 0) throw new Q("Hex string must be an even number of hex characters.", "invalid_length");
        try {
            return new r(_utils.hexToBytes.call(void 0, t));
        } catch (n) {
            throw new Q(`Hex string contains invalid hex characters: ${_optionalChain([
                n,
                'optionalAccess',
                (_2)=>_2.message
            ])}`, "invalid_hex_chars");
        }
    }
    static fromHexInput(e) {
        return e instanceof Uint8Array ? new r(e) : r.fromHexString(e);
    }
    static hexInputToUint8Array(e) {
        return e instanceof Uint8Array ? e : r.fromHexString(e).toUint8Array();
    }
    static hexInputToString(e) {
        return r.fromHexInput(e).toString();
    }
    static hexInputToStringWithoutPrefix(e) {
        return r.fromHexInput(e).toStringWithoutPrefix();
    }
    static isValid(e) {
        try {
            return r.fromHexString(e), {
                valid: !0
            };
        } catch (t) {
            return {
                valid: !1,
                invalidReason: _optionalChain([
                    t,
                    'optionalAccess',
                    (_3)=>_3.invalidReason
                ]),
                invalidReasonMessage: _optionalChain([
                    t,
                    'optionalAccess',
                    (_4)=>_4.message
                ])
            };
        }
    }
    equals(e) {
        return this.data.length !== e.data.length ? !1 : this.data.every((t, n)=>t === e.data[n]);
    }
}, Ki = exports.hexToAsciiString = (r)=>new TextDecoder().decode(g.fromHexInput(r).toUint8Array());
var l = class {
    bcsToBytes() {
        let e = new q;
        return this.serialize(e), e.toUint8Array();
    }
    bcsToHex() {
        let e = this.bcsToBytes();
        return g.fromHexInput(e);
    }
    toStringWithoutPrefix() {
        return this.bcsToHex().toStringWithoutPrefix();
    }
    toString() {
        return `0x${this.toStringWithoutPrefix()}`;
    }
}, q = exports.Serializer = class {
    constructor(e = 64){
        if (e <= 0) throw new Error("Length needs to be greater than 0");
        this.buffer = new ArrayBuffer(e), this.offset = 0;
    }
    ensureBufferWillHandleSize(e) {
        for(; this.buffer.byteLength < this.offset + e;){
            let t = new ArrayBuffer(this.buffer.byteLength * 2);
            new Uint8Array(t).set(new Uint8Array(this.buffer)), this.buffer = t;
        }
    }
    appendToBuffer(e) {
        this.ensureBufferWillHandleSize(e.length), new Uint8Array(this.buffer, this.offset).set(e), this.offset += e.length;
    }
    serializeWithFunction(e, t, n) {
        this.ensureBufferWillHandleSize(t);
        let i = new DataView(this.buffer, this.offset);
        e.apply(i, [
            0,
            n,
            !0
        ]), this.offset += t;
    }
    serializeStr(e) {
        let t = new TextEncoder;
        this.serializeBytes(t.encode(e));
    }
    serializeBytes(e) {
        this.serializeU32AsUleb128(e.length), this.appendToBuffer(e);
    }
    serializeFixedBytes(e) {
        this.appendToBuffer(e);
    }
    serializeBool(e) {
        On(e);
        let t = e ? 1 : 0;
        this.appendToBuffer(new Uint8Array([
            t
        ]));
    }
    serializeU8(e) {
        this.appendToBuffer(new Uint8Array([
            e
        ]));
    }
    serializeU16(e) {
        this.serializeWithFunction(DataView.prototype.setUint16, 2, e);
    }
    serializeU32(e) {
        this.serializeWithFunction(DataView.prototype.setUint32, 4, e);
    }
    serializeU64(e) {
        let t = BigInt(e) & BigInt(Ue), n = BigInt(e) >> BigInt(32);
        this.serializeU32(Number(t)), this.serializeU32(Number(n));
    }
    serializeU128(e) {
        let t = BigInt(e) & ot, n = BigInt(e) >> BigInt(64);
        this.serializeU64(t), this.serializeU64(n);
    }
    serializeU256(e) {
        let t = BigInt(e) & Zt, n = BigInt(e) >> BigInt(128);
        this.serializeU128(t), this.serializeU128(n);
    }
    serializeU32AsUleb128(e) {
        let t = e, n = [];
        for(; t >>> 7;)n.push(t & 127 | 128), t >>>= 7;
        n.push(t), this.appendToBuffer(new Uint8Array(n));
    }
    toUint8Array() {
        return new Uint8Array(this.buffer).slice(0, this.offset);
    }
    serialize(e) {
        e.serialize(this);
    }
    serializeVector(e) {
        this.serializeU32AsUleb128(e.length), e.forEach((t)=>{
            t.serialize(this);
        });
    }
    serializeOption(e, t) {
        let n = e !== void 0;
        this.serializeBool(n), n && (typeof e == "string" ? this.serializeStr(e) : e instanceof Uint8Array ? t !== void 0 ? this.serializeFixedBytes(e) : this.serializeBytes(e) : e.serialize(this));
    }
    serializeOptionStr(e) {
        e === void 0 ? this.serializeU32AsUleb128(0) : (this.serializeU32AsUleb128(1), this.serializeStr(e));
    }
};
_chunkF43XVDYJjs.a.call(void 0, [
    st(0, Nr)
], q.prototype, "serializeU8", 1), _chunkF43XVDYJjs.a.call(void 0, [
    st(0, Fr)
], q.prototype, "serializeU16", 1), _chunkF43XVDYJjs.a.call(void 0, [
    st(0, Ue)
], q.prototype, "serializeU32", 1), _chunkF43XVDYJjs.a.call(void 0, [
    st(BigInt(0), ot)
], q.prototype, "serializeU64", 1), _chunkF43XVDYJjs.a.call(void 0, [
    st(BigInt(0), Zt)
], q.prototype, "serializeU128", 1), _chunkF43XVDYJjs.a.call(void 0, [
    st(BigInt(0), Gr)
], q.prototype, "serializeU256", 1), _chunkF43XVDYJjs.a.call(void 0, [
    st(0, Ue)
], q.prototype, "serializeU32AsUleb128", 1);
function On(r) {
    if (typeof r != "boolean") throw new Error(`${r} is not a boolean value`);
}
var Ua = (r, e, t)=>`${r} is out of range: [${e}, ${t}]`;
function We(r, e, t) {
    let n = BigInt(r);
    if (n > BigInt(t) || n < BigInt(e)) throw new Error(Ua(r, e, t));
}
function st(r, e) {
    return (t, n, i)=>{
        let o = i.value;
        return i.value = function(a) {
            return We(a, r, e), o.apply(this, [
                a
            ]);
        }, i;
    };
}
var at = class r extends l {
    constructor(e){
        super(), this.value = g.fromHexInput(e).toUint8Array();
    }
    serialize(e) {
        e.serializeFixedBytes(this.value);
    }
    serializeForEntryFunction(e) {
        e.serialize(this);
    }
    serializeForScriptFunction(e) {
        e.serialize(this);
    }
    static deserialize(e, t) {
        let n = e.deserializeFixedBytes(t);
        return new r(n);
    }
};
var Br = class r extends l {
    constructor(e){
        super(), this.value = new at(e);
    }
    serialize(e) {
        e.serialize(this.value);
    }
    serializeForEntryFunction(e) {
        e.serializeU32AsUleb128(this.value.value.length), e.serialize(this);
    }
    static deserialize(e, t) {
        let n = at.deserialize(e, t);
        return new r(n.value);
    }
};
var Mr = ((i)=>(i.JSON = "application/json", i.BCS = "application/x-bcs", i.BCS_SIGNED_TRANSACTION = "application/x.aptos.signed_transaction+bcs", i.BCS_VIEW_FUNCTION = "application/x.aptos.view_function+bcs", i))(Mr || {}), ki = exports.TypeTagVariants = ((y)=>(y[y.Bool = 0] = "Bool", y[y.U8 = 1] = "U8", y[y.U64 = 2] = "U64", y[y.U128 = 3] = "U128", y[y.Address = 4] = "Address", y[y.Signer = 5] = "Signer", y[y.Vector = 6] = "Vector", y[y.Struct = 7] = "Struct", y[y.U16 = 8] = "U16", y[y.U32 = 9] = "U32", y[y.U256 = 10] = "U256", y[y.Reference = 254] = "Reference", y[y.Generic = 255] = "Generic", y))(ki || {}), er = exports.ScriptTransactionArgumentVariants = ((d)=>(d[d.U8 = 0] = "U8", d[d.U64 = 1] = "U64", d[d.U128 = 2] = "U128", d[d.Address = 3] = "Address", d[d.U8Vector = 4] = "U8Vector", d[d.Bool = 5] = "Bool", d[d.U16 = 6] = "U16", d[d.U32 = 7] = "U32", d[d.U256 = 8] = "U256", d[d.Serialized = 9] = "Serialized", d))(er || {}), Oi = exports.TransactionPayloadVariants = ((n)=>(n[n.Script = 0] = "Script", n[n.EntryFunction = 2] = "EntryFunction", n[n.Multisig = 3] = "Multisig", n))(Oi || {}), Di = exports.TransactionVariants = ((t)=>(t[t.MultiAgentTransaction = 0] = "MultiAgentTransaction", t[t.FeePayerTransaction = 1] = "FeePayerTransaction", t))(Di || {}), zi = exports.TransactionAuthenticatorVariant = ((o)=>(o[o.Ed25519 = 0] = "Ed25519", o[o.MultiEd25519 = 1] = "MultiEd25519", o[o.MultiAgent = 2] = "MultiAgent", o[o.FeePayer = 3] = "FeePayer", o[o.SingleSender = 4] = "SingleSender", o))(zi || {}), Ni = exports.AccountAuthenticatorVariant = ((o)=>(o[o.Ed25519 = 0] = "Ed25519", o[o.MultiEd25519 = 1] = "MultiEd25519", o[o.SingleKey = 2] = "SingleKey", o[o.MultiKey = 3] = "MultiKey", o[o.NoAccountAuthenticator = 4] = "NoAccountAuthenticator", o))(Ni || {}), Vr = exports.PrivateKeyVariants = ((t)=>(t.Ed25519 = "ed25519", t.Secp256k1 = "secp256k1", t))(Vr || {}), Lr = exports.AnyPublicKeyVariant = ((i)=>(i[i.Ed25519 = 0] = "Ed25519", i[i.Secp256k1 = 1] = "Secp256k1", i[i.Keyless = 3] = "Keyless", i[i.FederatedKeyless = 4] = "FederatedKeyless", i))(Lr || {}), Fi = exports.AnySignatureVariant = ((n)=>(n[n.Ed25519 = 0] = "Ed25519", n[n.Secp256k1 = 1] = "Secp256k1", n[n.Keyless = 3] = "Keyless", n))(Fi || {}), Dn = exports.EphemeralPublicKeyVariant = ((e)=>(e[e.Ed25519 = 0] = "Ed25519", e))(Dn || {}), Gi = exports.EphemeralSignatureVariant = ((e)=>(e[e.Ed25519 = 0] = "Ed25519", e))(Gi || {}), zn = exports.EphemeralCertificateVariant = ((e)=>(e[e.ZkProof = 0] = "ZkProof", e))(zn || {}), Nn = exports.ZkpVariant = ((e)=>(e[e.Groth16 = 0] = "Groth16", e))(Nn || {}), Fn = exports.TransactionResponseType = ((a)=>(a.Pending = "pending_transaction", a.User = "user_transaction", a.Genesis = "genesis_transaction", a.BlockMetadata = "block_metadata_transaction", a.StateCheckpoint = "state_checkpoint_transaction", a.Validator = "validator_transaction", a.BlockEpilogue = "block_epilogue_transaction", a))(Fn || {});
function Zu(r) {
    return r.type === "pending_transaction";
}
function ep(r) {
    return r.type === "user_transaction";
}
function tp(r) {
    return r.type === "genesis_transaction";
}
function rp(r) {
    return r.type === "block_metadata_transaction";
}
function np(r) {
    return r.type === "state_checkpoint_transaction";
}
function ip(r) {
    return r.type === "validator_transaction";
}
function op(r) {
    return r.type === "block_epilogue_transaction";
}
function sp(r) {
    return "signature" in r && r.signature === "ed25519_signature";
}
function ap(r) {
    return "signature" in r && r.signature === "secp256k1_ecdsa_signature";
}
function cp(r) {
    return r.type === "multi_agent_signature";
}
function up(r) {
    return r.type === "fee_payer_signature";
}
function pp(r) {
    return r.type === "multi_ed25519_signature";
}
var Ka = ((n)=>(n.PRIVATE = "private", n.PUBLIC = "public", n.FRIEND = "friend", n))(Ka || {}), Bi = exports.MoveAbility = ((i)=>(i.STORE = "store", i.DROP = "drop", i.KEY = "key", i.COPY = "copy", i))(Bi || {}), ka = exports.RoleType = ((t)=>(t.VALIDATOR = "validator", t.FULL_NODE = "full_node", t))(ka || {}), he = exports.SigningScheme = ((i)=>(i[i.Ed25519 = 0] = "Ed25519", i[i.MultiEd25519 = 1] = "MultiEd25519", i[i.SingleKey = 2] = "SingleKey", i[i.MultiKey = 3] = "MultiKey", i))(he || {}), Gn = exports.SigningSchemeInput = ((t)=>(t[t.Ed25519 = 0] = "Ed25519", t[t.Secp256k1Ecdsa = 2] = "Secp256k1Ecdsa", t))(Gn || {}), Mi = exports.DeriveScheme = ((o)=>(o[o.DeriveAuid = 251] = "DeriveAuid", o[o.DeriveObjectAddressFromObject = 252] = "DeriveObjectAddressFromObject", o[o.DeriveObjectAddressFromGuid = 253] = "DeriveObjectAddressFromGuid", o[o.DeriveObjectAddressFromSeed = 254] = "DeriveObjectAddressFromSeed", o[o.DeriveResourceAccountAddress = 255] = "DeriveResourceAccountAddress", o))(Mi || {});
var U = class r extends l {
    constructor(e){
        super(), On(e), this.value = e;
    }
    serialize(e) {
        e.serializeBool(this.value);
    }
    serializeForEntryFunction(e) {
        let t = this.bcsToBytes();
        e.serializeBytes(t);
    }
    serializeForScriptFunction(e) {
        e.serializeU32AsUleb128(5), e.serialize(this);
    }
    deserialize(e) {
        return new de(e.deserializeU256());
    }
    static deserialize(e) {
        return new r(e.deserializeBool());
    }
}, j = exports.U8 = class r extends l {
    constructor(e){
        super(), We(e, 0, Nr), this.value = e;
    }
    serialize(e) {
        e.serializeU8(this.value);
    }
    serializeForEntryFunction(e) {
        let t = this.bcsToBytes();
        e.serializeBytes(t);
    }
    serializeForScriptFunction(e) {
        e.serializeU32AsUleb128(0), e.serialize(this);
    }
    static deserialize(e) {
        return new r(e.deserializeU8());
    }
}, Te = exports.U16 = class r extends l {
    constructor(e){
        super(), We(e, 0, Fr), this.value = e;
    }
    serialize(e) {
        e.serializeU16(this.value);
    }
    serializeForEntryFunction(e) {
        let t = this.bcsToBytes();
        e.serializeBytes(t);
    }
    serializeForScriptFunction(e) {
        e.serializeU32AsUleb128(6), e.serialize(this);
    }
    static deserialize(e) {
        return new r(e.deserializeU16());
    }
}, be = exports.U32 = class r extends l {
    constructor(e){
        super(), We(e, 0, Ue), this.value = e;
    }
    serialize(e) {
        e.serializeU32(this.value);
    }
    serializeForEntryFunction(e) {
        let t = this.bcsToBytes();
        e.serializeBytes(t);
    }
    serializeForScriptFunction(e) {
        e.serializeU32AsUleb128(7), e.serialize(this);
    }
    static deserialize(e) {
        return new r(e.deserializeU32());
    }
}, $ = exports.U64 = class r extends l {
    constructor(e){
        super(), We(e, BigInt(0), ot), this.value = BigInt(e);
    }
    serialize(e) {
        e.serializeU64(this.value);
    }
    serializeForEntryFunction(e) {
        let t = this.bcsToBytes();
        e.serializeBytes(t);
    }
    serializeForScriptFunction(e) {
        e.serializeU32AsUleb128(1), e.serialize(this);
    }
    static deserialize(e) {
        return new r(e.deserializeU64());
    }
}, we = exports.U128 = class r extends l {
    constructor(e){
        super(), We(e, BigInt(0), Zt), this.value = BigInt(e);
    }
    serialize(e) {
        e.serializeU128(this.value);
    }
    serializeForEntryFunction(e) {
        let t = this.bcsToBytes();
        e.serializeBytes(t);
    }
    serializeForScriptFunction(e) {
        e.serializeU32AsUleb128(2), e.serialize(this);
    }
    static deserialize(e) {
        return new r(e.deserializeU128());
    }
}, de = exports.U256 = class r extends l {
    constructor(e){
        super(), We(e, BigInt(0), Gr), this.value = BigInt(e);
    }
    serialize(e) {
        e.serializeU256(this.value);
    }
    serializeForEntryFunction(e) {
        let t = this.bcsToBytes();
        e.serializeBytes(t);
    }
    serializeForScriptFunction(e) {
        e.serializeU32AsUleb128(8), e.serialize(this);
    }
    static deserialize(e) {
        return new r(e.deserializeU256());
    }
};
var b = class r extends l {
    constructor(e){
        super(), this.values = e;
    }
    serializeForEntryFunction(e) {
        let t = this.bcsToBytes();
        e.serializeBytes(t);
    }
    serializeForScriptFunction(e) {
        if (this.values[0] !== void 0 && !(this.values[0] instanceof j)) {
            new tr(this.bcsToBytes()).serializeForScriptFunction(e);
            return;
        }
        e.serializeU32AsUleb128(4), e.serialize(this);
    }
    static U8(e) {
        let t;
        if (Array.isArray(e) && e.length === 0) t = [];
        else if (Array.isArray(e) && typeof e[0] == "number") t = e;
        else if (typeof e == "string") {
            let n = g.fromHexInput(e);
            t = Array.from(n.toUint8Array());
        } else if (e instanceof Uint8Array) t = Array.from(e);
        else throw new Error("Invalid input type, must be an number[], Uint8Array, or hex string");
        return new r(t.map((n)=>new j(n)));
    }
    static U16(e) {
        return new r(e.map((t)=>new Te(t)));
    }
    static U32(e) {
        return new r(e.map((t)=>new be(t)));
    }
    static U64(e) {
        return new r(e.map((t)=>new $(t)));
    }
    static U128(e) {
        return new r(e.map((t)=>new we(t)));
    }
    static U256(e) {
        return new r(e.map((t)=>new de(t)));
    }
    static Bool(e) {
        return new r(e.map((t)=>new U(t)));
    }
    static MoveString(e) {
        return new r(e.map((t)=>new S(t)));
    }
    serialize(e) {
        e.serializeVector(this.values);
    }
    static deserialize(e, t) {
        let n = e.deserializeUleb128AsU32(), i = new Array;
        for(let o = 0; o < n; o += 1)i.push(t.deserialize(e));
        return new r(i);
    }
}, tr = exports.Serialized = class r extends l {
    constructor(e){
        super(), this.value = g.fromHexInput(e).toUint8Array();
    }
    serialize(e) {
        e.serializeBytes(this.value);
    }
    serializeForEntryFunction(e) {
        this.serialize(e);
    }
    serializeForScriptFunction(e) {
        e.serializeU32AsUleb128(9), this.serialize(e);
    }
    static deserialize(e) {
        return new r(e.deserializeBytes());
    }
    toMoveVector(e) {
        let t = new N(this.bcsToBytes());
        t.deserializeUleb128AsU32();
        let n = t.deserializeVector(e);
        return new b(n);
    }
}, S = exports.MoveString = class r extends l {
    constructor(e){
        super(), this.value = e;
    }
    serialize(e) {
        e.serializeStr(this.value);
    }
    serializeForEntryFunction(e) {
        let t = this.bcsToBytes();
        e.serializeBytes(t);
    }
    serializeForScriptFunction(e) {
        let n = new TextEncoder().encode(this.value);
        b.U8(n).serializeForScriptFunction(e);
    }
    static deserialize(e) {
        return new r(e.deserializeStr());
    }
}, J = exports.MoveOption = class r extends l {
    constructor(e){
        super(), typeof e < "u" && e !== null ? this.vec = new b([
            e
        ]) : this.vec = new b([]), [this.value] = this.vec.values;
    }
    serializeForEntryFunction(e) {
        let t = this.bcsToBytes();
        e.serializeBytes(t);
    }
    unwrap() {
        if (this.isSome()) return this.vec.values[0];
        throw new Error("Called unwrap on a MoveOption with no value");
    }
    isSome() {
        return this.vec.values.length === 1;
    }
    serialize(e) {
        this.vec.serialize(e);
    }
    static U8(e) {
        return new r(e != null ? new j(e) : void 0);
    }
    static U16(e) {
        return new r(e != null ? new Te(e) : void 0);
    }
    static U32(e) {
        return new r(e != null ? new be(e) : void 0);
    }
    static U64(e) {
        return new r(e != null ? new $(e) : void 0);
    }
    static U128(e) {
        return new r(e != null ? new we(e) : void 0);
    }
    static U256(e) {
        return new r(e != null ? new de(e) : void 0);
    }
    static Bool(e) {
        return new r(e != null ? new U(e) : void 0);
    }
    static MoveString(e) {
        return new r(e != null ? new S(e) : void 0);
    }
    static deserialize(e, t) {
        let n = b.deserialize(e, t);
        return new r(n.values[0]);
    }
};
var _ed25519 = __turbopack_require__("[project]/node_modules/.pnpm/@noble+curves@1.8.0/node_modules/@noble/curves/ed25519.js [app-route] (ecmascript)");
var _sha3 = __turbopack_require__("[project]/node_modules/.pnpm/@noble+hashes@1.7.0/node_modules/@noble/hashes/sha3.js [app-route] (ecmascript)");
var Da = ((c)=>(c.INCORRECT_NUMBER_OF_BYTES = "incorrect_number_of_bytes", c.INVALID_HEX_CHARS = "invalid_hex_chars", c.TOO_SHORT = "too_short", c.TOO_LONG = "too_long", c.LEADING_ZERO_X_REQUIRED = "leading_zero_x_required", c.LONG_FORM_REQUIRED_UNLESS_SPECIAL = "long_form_required_unless_special", c.INVALID_PADDING_ZEROES = "INVALID_PADDING_ZEROES", c.INVALID_PADDING_STRICTNESS = "INVALID_PADDING_STRICTNESS", c))(Da || {}), E = class E extends l {
    constructor(e){
        if (super(), e.length !== E.LENGTH) throw new Q("AccountAddress data should be exactly 32 bytes long", "incorrect_number_of_bytes");
        this.data = e;
    }
    isSpecial() {
        return this.data.slice(0, this.data.length - 1).every((e)=>e === 0) && this.data[this.data.length - 1] < 16;
    }
    toString() {
        return `0x${this.toStringWithoutPrefix()}`;
    }
    toStringWithoutPrefix() {
        let e = _utils.bytesToHex.call(void 0, this.data);
        return this.isSpecial() && (e = e[e.length - 1]), e;
    }
    toStringLong() {
        return `0x${this.toStringLongWithoutPrefix()}`;
    }
    toStringLongWithoutPrefix() {
        return _utils.bytesToHex.call(void 0, this.data);
    }
    toUint8Array() {
        return this.data;
    }
    serialize(e) {
        e.serializeFixedBytes(this.data);
    }
    serializeForEntryFunction(e) {
        let t = this.bcsToBytes();
        e.serializeBytes(t);
    }
    serializeForScriptFunction(e) {
        e.serializeU32AsUleb128(3), e.serialize(this);
    }
    static deserialize(e) {
        let t = e.deserializeFixedBytes(E.LENGTH);
        return new E(t);
    }
    static fromStringStrict(e) {
        if (!e.startsWith("0x")) throw new Q("Hex string must start with a leading 0x.", "leading_zero_x_required");
        let t = E.fromString(e);
        if (e.length !== E.LONG_STRING_LENGTH + 2) if (t.isSpecial()) {
            if (e.length !== 3) throw new Q(`The given hex string ${e} is a special address not in LONG form, it must be 0x0 to 0xf without padding zeroes.`, "INVALID_PADDING_ZEROES");
        } else throw new Q(`The given hex string ${e} is not a special address, it must be represented as 0x + 64 chars.`, "long_form_required_unless_special");
        return t;
    }
    static fromString(e, { maxMissingChars: t = 4 } = {}) {
        let n = e;
        if (e.startsWith("0x") && (n = e.slice(2)), n.length === 0) throw new Q("Hex string is too short, must be 1 to 64 chars long, excluding the leading 0x.", "too_short");
        if (n.length > 64) throw new Q("Hex string is too long, must be 1 to 64 chars long, excluding the leading 0x.", "too_long");
        if (t > 63 || t < 0) throw new Q(`maxMissingChars must be between or equal to 0 and 63. Received ${t}`, "INVALID_PADDING_STRICTNESS");
        let i;
        try {
            i = _utils.hexToBytes.call(void 0, n.padStart(64, "0"));
        } catch (s) {
            throw new Q(`Hex characters are invalid: ${_optionalChain([
                s,
                'optionalAccess',
                (_5)=>_5.message
            ])}`, "invalid_hex_chars");
        }
        let o = new E(i);
        if (n.length < 64 - t && !o.isSpecial()) throw new Q(`Hex string is too short, must be ${64 - t} to 64 chars long, excluding the leading 0x. You may need to fix 
the addresss by padding it with 0s before passing it to \`fromString\` (e.g. <addressString>.padStart(64, '0')). 
Received ${e}`, "too_short");
        return o;
    }
    static from(e, { maxMissingChars: t = 4 } = {}) {
        return typeof e == "string" ? E.fromString(e, {
            maxMissingChars: t
        }) : e instanceof Uint8Array ? new E(e) : e;
    }
    static fromStrict(e) {
        return typeof e == "string" ? E.fromStringStrict(e) : e instanceof Uint8Array ? new E(e) : e;
    }
    static isValid(e) {
        try {
            return e.strict ? E.fromStrict(e.input) : E.from(e.input), {
                valid: !0
            };
        } catch (t) {
            return {
                valid: !1,
                invalidReason: _optionalChain([
                    t,
                    'optionalAccess',
                    (_6)=>_6.invalidReason
                ]),
                invalidReasonMessage: _optionalChain([
                    t,
                    'optionalAccess',
                    (_7)=>_7.message
                ])
            };
        }
    }
    equals(e) {
        return this.data.length !== e.data.length ? !1 : this.data.every((t, n)=>t === e.data[n]);
    }
};
E.LENGTH = 32, E.LONG_STRING_LENGTH = 64, E.ZERO = E.from("0x0"), E.ONE = E.from("0x1"), E.TWO = E.from("0x2"), E.THREE = E.from("0x3"), E.FOUR = E.from("0x4"), E.A = E.from("0xA");
var u = E;
var Qe = class Qe extends l {
    constructor(e){
        super();
        let { data: t } = e, n = g.fromHexInput(t);
        if (n.toUint8Array().length !== Qe.LENGTH) throw new Error(`Authentication Key length should be ${Qe.LENGTH}`);
        this.data = n;
    }
    serialize(e) {
        e.serializeFixedBytes(this.data.toUint8Array());
    }
    static deserialize(e) {
        let t = e.deserializeFixedBytes(Qe.LENGTH);
        return new Qe({
            data: t
        });
    }
    toUint8Array() {
        return this.data.toUint8Array();
    }
    static fromSchemeAndBytes(e) {
        let { scheme: t, input: n } = e, i = g.fromHexInput(n).toUint8Array(), o = new Uint8Array([
            ...i,
            t
        ]), s = _sha3.sha3_256.create();
        s.update(o);
        let a = s.digest();
        return new Qe({
            data: a
        });
    }
    static fromPublicKeyAndScheme(e) {
        let { publicKey: t } = e;
        return t.authKey();
    }
    static fromPublicKey(e) {
        let { publicKey: t } = e;
        return t.authKey();
    }
    derivedAddress() {
        return new u(this.data.toUint8Array());
    }
};
Qe.LENGTH = 32;
var B = Qe;
var _hmac = __turbopack_require__("[project]/node_modules/.pnpm/@noble+hashes@1.7.0/node_modules/@noble/hashes/hmac.js [app-route] (ecmascript)");
var _sha512 = __turbopack_require__("[project]/node_modules/.pnpm/@noble+hashes@1.7.0/node_modules/@noble/hashes/sha512.js [app-route] (ecmascript)");
var _bip39 = __turbopack_require__("[project]/node_modules/.pnpm/@scure+bip39@1.5.1/node_modules/@scure/bip39/index.js [app-route] (ecmascript)");
var Li = _interopRequireWildcard(_bip39);
var Ga = /^m\/44'\/637'\/[0-9]+'\/[0-9]+'\/[0-9]+'?$/, Ba = exports.APTOS_BIP44_REGEX = /^m\/44'\/637'\/[0-9]+'\/[0-9]+\/[0-9]+$/, Ma = exports.KeyType = ((e)=>(e.ED25519 = "ed25519 seed", e))(Ma || {}), Hi = exports.HARDENED_OFFSET = 2147483648;
function qi(r) {
    return Ba.test(r);
}
function $i(r) {
    return Ga.test(r);
}
var Bn = (r, e)=>{
    let t = _hmac.hmac.create(_sha512.sha512, r).update(e).digest();
    return {
        key: t.slice(0, 32),
        chainCode: t.slice(32)
    };
}, Wi = exports.CKDPriv = ({ key: r, chainCode: e }, t)=>{
    let n = new ArrayBuffer(4);
    new DataView(n).setUint32(0, t);
    let i = new Uint8Array(n), o = new Uint8Array([
        0
    ]), s = new Uint8Array([
        ...o,
        ...r,
        ...i
    ]);
    return Bn(e, s);
}, Va = (r)=>r.replace(/'/g, ""), Qi = exports.splitPath = (r)=>r.split("/").slice(1).map(Va), Hr = exports.mnemonicToSeed = (r)=>{
    let e = r.trim().split(/\s+/).map((t)=>t.toLowerCase()).join(" ");
    return Li.mnemonicToSeedSync(e);
};
var rr = class rr {
    static formatPrivateKey(e, t) {
        let n = rr.AIP80_PREFIXES[t], i = e;
        return typeof i == "string" && i.startsWith(n) && (i = i.split("-")[2]), `${n}${g.fromHexInput(i).toString()}`;
    }
    static parseHexInput(e, t, n) {
        let i, o = rr.AIP80_PREFIXES[t];
        if (typeof e == "string") if (!n && !e.startsWith(o)) i = g.fromHexInput(e), n !== !1 && console.warn("[Aptos SDK] It is recommended that private keys are AIP-80 compliant (https://github.com/aptos-foundation/AIPs/blob/main/aips/aip-80.md). You can fix the private key by formatting it with `PrivateKey.formatPrivateKey(privateKey: string, type: 'ed25519' | 'secp256k1'): string`.");
        else if (e.startsWith(o)) i = g.fromHexString(e.split("-")[2]);
        else throw n ? new Error("Invalid HexString input while parsing private key. Must AIP-80 compliant string.") : new Error("Invalid HexString input while parsing private key.");
        else i = g.fromHexInput(e);
        return i;
    }
};
rr.AIP80_PREFIXES = {
    ed25519: "ed25519-priv-",
    secp256k1: "secp256k1-priv-"
};
var je = rr;
var ct = class extends l {
    toUint8Array() {
        return this.bcsToBytes();
    }
    toString() {
        let e = this.toUint8Array();
        return g.fromHexInput(e).toString();
    }
}, ne = exports.AccountPublicKey = class extends ct {
};
var M = class extends l {
    toUint8Array() {
        return this.bcsToBytes();
    }
    toString() {
        let e = this.toUint8Array();
        return g.fromHexInput(e).toString();
    }
};
var xt = (r)=>typeof r == "string" ? g.isValid(r).valid ? r : new TextEncoder().encode(r) : r;
var Mn = [
    237,
    211,
    245,
    92,
    26,
    99,
    18,
    88,
    214,
    156,
    247,
    162,
    222,
    249,
    222,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    16
];
function La(r) {
    let e = r.toUint8Array().slice(32);
    for(let t = Mn.length - 1; t >= 0; t -= 1){
        if (e[t] < Mn[t]) return !0;
        if (e[t] > Mn[t]) return !1;
    }
    return !1;
}
var Je = class Je extends ne {
    constructor(e){
        super();
        let t = g.fromHexInput(e);
        if (t.toUint8Array().length !== Je.LENGTH) throw new Error(`PublicKey length should be ${Je.LENGTH}`);
        this.key = t;
    }
    verifySignature(e) {
        let { message: t, signature: n } = e;
        if (!La(n)) return !1;
        let i = xt(t), o = g.fromHexInput(i).toUint8Array(), s = n.toUint8Array(), a = this.key.toUint8Array();
        return _ed25519.ed25519.verify(s, o, a);
    }
    authKey() {
        return B.fromSchemeAndBytes({
            scheme: 0,
            input: this.toUint8Array()
        });
    }
    toUint8Array() {
        return this.key.toUint8Array();
    }
    serialize(e) {
        e.serializeBytes(this.key.toUint8Array());
    }
    static deserialize(e) {
        let t = e.deserializeBytes();
        return new Je(t);
    }
    static isPublicKey(e) {
        return e instanceof Je;
    }
    static isInstance(e) {
        return "key" in e && _optionalChain([
            e,
            'access',
            (_8)=>_8.key,
            'optionalAccess',
            (_9)=>_9.data,
            'optionalAccess',
            (_10)=>_10.length
        ]) === Je.LENGTH;
    }
};
Je.LENGTH = 32;
var P = Je, le = class le extends l {
    constructor(e, t){
        super();
        let n = je.parseHexInput(e, "ed25519", t);
        if (n.toUint8Array().length !== le.LENGTH) throw new Error(`PrivateKey length should be ${le.LENGTH}`);
        this.signingKey = n;
    }
    static generate() {
        let e = _ed25519.ed25519.utils.randomPrivateKey();
        return new le(e, !1);
    }
    static fromDerivationPath(e, t) {
        if (!$i(e)) throw new Error(`Invalid derivation path ${e}`);
        return le.fromDerivationPathInner(e, Hr(t));
    }
    static fromDerivationPathInner(e, t, n = Hi) {
        let { key: i, chainCode: o } = Bn(le.SLIP_0010_SEED, t), s = Qi(e).map((c)=>parseInt(c, 10)), { key: a } = s.reduce((c, p)=>Wi(c, p + n), {
            key: i,
            chainCode: o
        });
        return new le(a, !1);
    }
    publicKey() {
        let e = _ed25519.ed25519.getPublicKey(this.signingKey.toUint8Array());
        return new P(e);
    }
    sign(e) {
        let t = xt(e), n = g.fromHexInput(t).toUint8Array(), i = _ed25519.ed25519.sign(n, this.signingKey.toUint8Array());
        return new I(i);
    }
    toUint8Array() {
        return this.signingKey.toUint8Array();
    }
    toString() {
        return this.toHexString();
    }
    toHexString() {
        return this.signingKey.toString();
    }
    toAIP80String() {
        return je.formatPrivateKey(this.signingKey.toString(), "ed25519");
    }
    serialize(e) {
        e.serializeBytes(this.toUint8Array());
    }
    static deserialize(e) {
        let t = e.deserializeBytes();
        return new le(t, !1);
    }
    static isPrivateKey(e) {
        return e instanceof le;
    }
};
le.LENGTH = 32, le.SLIP_0010_SEED = "ed25519 seed";
var Z = le, Et = class Et extends M {
    constructor(e){
        super();
        let t = g.fromHexInput(e);
        if (t.toUint8Array().length !== Et.LENGTH) throw new Error(`Signature length should be ${Et.LENGTH}`);
        this.data = t;
    }
    toUint8Array() {
        return this.data.toUint8Array();
    }
    serialize(e) {
        e.serializeBytes(this.data.toUint8Array());
    }
    static deserialize(e) {
        let t = e.deserializeBytes();
        return new Et(t);
    }
};
Et.LENGTH = 64;
var I = Et;
var ge = class ge extends ne {
    constructor(e){
        super();
        let { publicKeys: t, threshold: n } = e;
        if (t.length > ge.MAX_KEYS || t.length < ge.MIN_KEYS) throw new Error(`Must have between ${ge.MIN_KEYS} and ${ge.MAX_KEYS} public keys, inclusive`);
        if (n < ge.MIN_THRESHOLD || n > t.length) throw new Error(`Threshold must be between ${ge.MIN_THRESHOLD} and ${t.length}, inclusive`);
        this.publicKeys = t, this.threshold = n;
    }
    verifySignature(e) {
        let { message: t, signature: n } = e;
        if (!(n instanceof ut)) return !1;
        let i = [];
        for(let o = 0; o < 4; o += 1)for(let s = 0; s < 8; s += 1)if ((n.bitmap[o] & 1 << 7 - s) !== 0) {
            let c = o * 8 + s;
            i.push(c);
        }
        if (i.length !== n.signatures.length) throw new Error("Bitmap and signatures length mismatch");
        if (i.length < this.threshold) throw new Error("Not enough signatures");
        for(let o = 0; o < i.length; o += 1)if (!this.publicKeys[i[o]].verifySignature({
            message: t,
            signature: n.signatures[o]
        })) return !1;
        return !0;
    }
    authKey() {
        return B.fromSchemeAndBytes({
            scheme: 1,
            input: this.toUint8Array()
        });
    }
    toUint8Array() {
        let e = new Uint8Array(this.publicKeys.length * P.LENGTH + 1);
        return this.publicKeys.forEach((t, n)=>{
            e.set(t.toUint8Array(), n * P.LENGTH);
        }), e[this.publicKeys.length * P.LENGTH] = this.threshold, e;
    }
    serialize(e) {
        e.serializeBytes(this.toUint8Array());
    }
    static deserialize(e) {
        let t = e.deserializeBytes(), n = t[t.length - 1], i = [];
        for(let o = 0; o < t.length - 1; o += P.LENGTH){
            let s = o;
            i.push(new P(t.subarray(s, s + P.LENGTH)));
        }
        return new ge({
            publicKeys: i,
            threshold: n
        });
    }
};
ge.MAX_KEYS = 32, ge.MIN_KEYS = 2, ge.MIN_THRESHOLD = 1;
var Pt = ge, oe = class oe extends M {
    constructor(e){
        super();
        let { signatures: t, bitmap: n } = e;
        if (t.length > oe.MAX_SIGNATURES_SUPPORTED) throw new Error(`The number of signatures cannot be greater than ${oe.MAX_SIGNATURES_SUPPORTED}`);
        if (this.signatures = t, !(n instanceof Uint8Array)) this.bitmap = oe.createBitmap({
            bits: n
        });
        else {
            if (n.length !== oe.BITMAP_LEN) throw new Error(`"bitmap" length should be ${oe.BITMAP_LEN}`);
            this.bitmap = n;
        }
    }
    toUint8Array() {
        let e = new Uint8Array(this.signatures.length * I.LENGTH + oe.BITMAP_LEN);
        return this.signatures.forEach((t, n)=>{
            e.set(t.toUint8Array(), n * I.LENGTH);
        }), e.set(this.bitmap, this.signatures.length * I.LENGTH), e;
    }
    serialize(e) {
        e.serializeBytes(this.toUint8Array());
    }
    static deserialize(e) {
        let t = e.deserializeBytes(), n = t.subarray(t.length - 4), i = [];
        for(let o = 0; o < t.length - n.length; o += I.LENGTH){
            let s = o;
            i.push(new I(t.subarray(s, s + I.LENGTH)));
        }
        return new oe({
            signatures: i,
            bitmap: n
        });
    }
    static createBitmap(e) {
        let { bits: t } = e, n = 128, i = new Uint8Array([
            0,
            0,
            0,
            0
        ]), o = new Set;
        return t.forEach((s, a)=>{
            if (s >= oe.MAX_SIGNATURES_SUPPORTED) throw new Error(`Cannot have a signature larger than ${oe.MAX_SIGNATURES_SUPPORTED - 1}.`);
            if (o.has(s)) throw new Error("Duplicate bits detected.");
            if (a > 0 && s <= t[a - 1]) throw new Error("The bits need to be sorted in ascending order.");
            o.add(s);
            let c = Math.floor(s / 8), p = i[c];
            p |= n >> s % 8, i[c] = p;
        }), i;
    }
};
oe.MAX_SIGNATURES_SUPPORTED = 32, oe.BITMAP_LEN = 4;
var ut = oe;
var _secp256k1 = __turbopack_require__("[project]/node_modules/.pnpm/@noble+curves@1.8.0/node_modules/@noble/curves/secp256k1.js [app-route] (ecmascript)");
var _bip32 = __turbopack_require__("[project]/node_modules/.pnpm/@scure+bip32@1.6.1/node_modules/@scure/bip32/lib/index.js [app-route] (ecmascript)");
var _e = class _e extends ct {
    constructor(e){
        super();
        let t = g.fromHexInput(e), { length: n } = t.toUint8Array();
        if (n === _e.LENGTH) this.key = t;
        else if (n === _e.COMPRESSED_LENGTH) {
            let i = _secp256k1.secp256k1.ProjectivePoint.fromHex(t.toUint8Array());
            this.key = g.fromHexInput(i.toRawBytes(!1));
        } else throw new Error(`PublicKey length should be ${_e.LENGTH} or ${_e.COMPRESSED_LENGTH}, received ${n}`);
    }
    verifySignature(e) {
        let { message: t, signature: n } = e, i = xt(t), o = g.fromHexInput(i).toUint8Array(), s = _sha3.sha3_256.call(void 0, o), a = n.toUint8Array();
        return _secp256k1.secp256k1.verify(a, s, this.key.toUint8Array(), {
            lowS: !0
        });
    }
    toUint8Array() {
        return this.key.toUint8Array();
    }
    serialize(e) {
        e.serializeBytes(this.key.toUint8Array());
    }
    deserialize(e) {
        let t = e.deserializeBytes();
        return new dt(t);
    }
    static deserialize(e) {
        let t = e.deserializeBytes();
        return new _e(t);
    }
    static isPublicKey(e) {
        return e instanceof _e;
    }
    static isInstance(e) {
        return "key" in e && _optionalChain([
            e,
            'access',
            (_11)=>_11.key,
            'optionalAccess',
            (_12)=>_12.data,
            'optionalAccess',
            (_13)=>_13.length
        ]) === _e.LENGTH;
    }
};
_e.LENGTH = 65, _e.COMPRESSED_LENGTH = 33;
var Ke = _e, xe = class xe extends l {
    constructor(e, t){
        super();
        let n = je.parseHexInput(e, "secp256k1", t);
        if (n.toUint8Array().length !== xe.LENGTH) throw new Error(`PrivateKey length should be ${xe.LENGTH}`);
        this.key = n;
    }
    static generate() {
        let e = _secp256k1.secp256k1.utils.randomPrivateKey();
        return new xe(e, !1);
    }
    static fromDerivationPath(e, t) {
        if (!qi(e)) throw new Error(`Invalid derivation path ${e}`);
        return xe.fromDerivationPathInner(e, Hr(t));
    }
    static fromDerivationPathInner(e, t) {
        let { privateKey: n } = _bip32.HDKey.fromMasterSeed(t).derive(e);
        if (n === null) throw new Error("Invalid key");
        return new xe(n, !1);
    }
    sign(e) {
        let t = xt(e), n = g.fromHexInput(t), i = _sha3.sha3_256.call(void 0, n.toUint8Array()), o = _secp256k1.secp256k1.sign(i, this.key.toUint8Array(), {
            lowS: !0
        });
        return new dt(o.toCompactRawBytes());
    }
    publicKey() {
        let e = _secp256k1.secp256k1.getPublicKey(this.key.toUint8Array(), !1);
        return new Ke(e);
    }
    toUint8Array() {
        return this.key.toUint8Array();
    }
    toString() {
        return this.toHexString();
    }
    toHexString() {
        return this.key.toString();
    }
    toAIP80String() {
        return je.formatPrivateKey(this.key.toString(), "secp256k1");
    }
    serialize(e) {
        e.serializeBytes(this.toUint8Array());
    }
    static deserialize(e) {
        let t = e.deserializeBytes();
        return new xe(t, !1);
    }
    static isPrivateKey(e) {
        return e instanceof xe;
    }
};
xe.LENGTH = 32;
var pt = xe, vt = class vt extends M {
    constructor(e){
        super();
        let t = g.fromHexInput(e);
        if (t.toUint8Array().length !== vt.LENGTH) throw new Error(`Signature length should be ${vt.LENGTH}, received ${t.toUint8Array().length}`);
        this.data = t;
    }
    toUint8Array() {
        return this.data.toUint8Array();
    }
    serialize(e) {
        e.serializeBytes(this.data.toUint8Array());
    }
    static deserialize(e) {
        let t = e.deserializeBytes();
        return new vt(t);
    }
};
vt.LENGTH = 64;
var dt = vt;
var _jwtdecode = __turbopack_require__("[project]/node_modules/.pnpm/jwt-decode@4.0.0/node_modules/jwt-decode/build/cjs/index.js [app-route] (ecmascript)");
var lt = class r extends ct {
    constructor(e){
        super();
        let t = e.constructor.name;
        switch(t){
            case P.name:
                this.publicKey = e, this.variant = 0;
                break;
            default:
                throw new Error(`Unsupported key for EphemeralPublicKey - ${t}`);
        }
    }
    verifySignature(e) {
        let { message: t, signature: n } = e;
        return this.publicKey.verifySignature({
            message: t,
            signature: n.signature
        });
    }
    serialize(e) {
        if (this.publicKey instanceof P) e.serializeU32AsUleb128(0), this.publicKey.serialize(e);
        else throw new Error("Unknown public key type");
    }
    static deserialize(e) {
        let t = e.deserializeUleb128AsU32();
        switch(t){
            case 0:
                return new r(P.deserialize(e));
            default:
                throw new Error(`Unknown variant index for EphemeralPublicKey: ${t}`);
        }
    }
    static isPublicKey(e) {
        return e instanceof r;
    }
}, Ee = exports.EphemeralSignature = class r extends M {
    constructor(e){
        super();
        let t = e.constructor.name;
        switch(t){
            case I.name:
                this.signature = e;
                break;
            default:
                throw new Error(`Unsupported signature for EphemeralSignature - ${t}`);
        }
    }
    static fromHex(e) {
        let t = g.fromHexInput(e), n = new N(t.toUint8Array());
        return r.deserialize(n);
    }
    serialize(e) {
        if (this.signature instanceof I) e.serializeU32AsUleb128(0), this.signature.serialize(e);
        else throw new Error("Unknown signature type");
    }
    static deserialize(e) {
        let t = e.deserializeUleb128AsU32();
        switch(t){
            case 0:
                return new r(I.deserialize(e));
            default:
                throw new Error(`Unknown variant index for EphemeralSignature: ${t}`);
        }
    }
};
var _poseidonlite = __turbopack_require__("[project]/node_modules/.pnpm/poseidon-lite@0.2.1/node_modules/poseidon-lite/index.js [app-route] (ecmascript)");
var Vn = [
    _poseidonlite.poseidon1,
    _poseidonlite.poseidon2,
    _poseidonlite.poseidon3,
    _poseidonlite.poseidon4,
    _poseidonlite.poseidon5,
    _poseidonlite.poseidon6,
    _poseidonlite.poseidon7,
    _poseidonlite.poseidon8,
    _poseidonlite.poseidon9,
    _poseidonlite.poseidon10,
    _poseidonlite.poseidon11,
    _poseidonlite.poseidon12,
    _poseidonlite.poseidon13,
    _poseidonlite.poseidon14,
    _poseidonlite.poseidon15,
    _poseidonlite.poseidon16
], Xi = 31, ac = 16, Ji = (ac - 1) * Xi;
function $r(r, e) {
    let n = new TextEncoder().encode(r);
    return cc(n, e);
}
function cc(r, e) {
    if (r.length > e) throw new Error(`Inputted bytes of length ${r} is longer than ${e}`);
    let t = Ln(r, e);
    return or(t);
}
function uc(r, e) {
    if (r.length > e) throw new Error(`Input bytes of length ${r} is longer than ${e}`);
    let t = lc(r, e);
    return pc(t);
}
function Ln(r, e) {
    if (r.length > e) throw new Error(`Input bytes of length ${r} is longer than ${e}`);
    return uc(r, e).concat([
        BigInt(r.length)
    ]);
}
function pc(r) {
    if (r.length > Ji) throw new Error(`Can't pack more than ${Ji}.  Was given ${r.length} bytes`);
    return dc(r, Xi).map((e)=>ir(e));
}
function dc(r, e) {
    let t = [];
    for(let n = 0; n < r.length; n += e)t.push(r.subarray(n, n + e));
    return t;
}
function ir(r) {
    let e = BigInt(0);
    for(let t = r.length - 1; t >= 0; t -= 1)e = e << BigInt(8) | BigInt(r[t]);
    return e;
}
function Yi(r, e) {
    let t = BigInt(r), n = new Uint8Array(e);
    for(let i = 0; i < e; i += 1)n[i] = Number(t & BigInt(255)), t >>= BigInt(8);
    return n;
}
function lc(r, e) {
    if (e < r.length) throw new Error("Padded size must be greater than or equal to the input array size.");
    let t = new Uint8Array(e);
    t.set(r);
    for(let n = r.length; n < e; n += 1)t[n] = 0;
    return t;
}
function or(r) {
    if (r.length > Vn.length) throw new Error(`Unable to hash input of length ${r.length}.  Max input length is ${Vn.length}`);
    return Vn[r.length - 1](r);
}
var Wr = class extends l {
};
var Zi = "1.33.1";
var eo = {
    mainnet: "https://api.mainnet.aptoslabs.com/v1/graphql",
    testnet: "https://api.testnet.aptoslabs.com/v1/graphql",
    devnet: "https://api.devnet.aptoslabs.com/v1/graphql",
    local: "http://127.0.0.1:8090/v1/graphql"
}, to = exports.NetworkToNodeAPI = {
    mainnet: "https://api.mainnet.aptoslabs.com/v1",
    testnet: "https://api.testnet.aptoslabs.com/v1",
    devnet: "https://api.devnet.aptoslabs.com/v1",
    local: "http://127.0.0.1:8080/v1"
}, ro = exports.NetworkToFaucetAPI = {
    mainnet: "https://faucet.mainnet.aptoslabs.com",
    testnet: "https://faucet.testnet.aptoslabs.com",
    devnet: "https://faucet.devnet.aptoslabs.com",
    local: "http://127.0.0.1:8081"
}, Hn = exports.NetworkToPepperAPI = {
    mainnet: "https://api.mainnet.aptoslabs.com/keyless/pepper/v0",
    testnet: "https://api.testnet.aptoslabs.com/keyless/pepper/v0",
    devnet: "https://api.devnet.aptoslabs.com/keyless/pepper/v0",
    local: "https://api.devnet.aptoslabs.com/keyless/pepper/v0"
}, qn = exports.NetworkToProverAPI = {
    mainnet: "https://api.mainnet.aptoslabs.com/keyless/prover/v0",
    testnet: "https://api.testnet.aptoslabs.com/keyless/prover/v0",
    devnet: "https://api.devnet.aptoslabs.com/keyless/prover/v0",
    local: "https://api.devnet.aptoslabs.com/keyless/prover/v0"
}, $n = exports.Network = ((o)=>(o.MAINNET = "mainnet", o.TESTNET = "testnet", o.DEVNET = "devnet", o.LOCAL = "local", o.CUSTOM = "custom", o))($n || {}), Wn = exports.NetworkToChainId = {
    mainnet: 1,
    testnet: 2,
    local: 4
}, yl = exports.NetworkToNetworkName = {
    mainnet: "mainnet",
    testnet: "testnet",
    devnet: "devnet",
    local: "local",
    custom: "custom"
};
var It = ((o)=>(o.FULLNODE = "Fullnode", o.INDEXER = "Indexer", o.FAUCET = "Faucet", o.PEPPER = "Pepper", o.PROVER = "Prover", o))(It || {}), no = exports.DEFAULT_MAX_GAS_AMOUNT = 2e5, io = exports.DEFAULT_TXN_EXP_SEC_FROM_NOW = 20, Qr = exports.DEFAULT_TXN_TIMEOUT_SEC = 20, gt = exports.APTOS_COIN = "0x1::aptos_coin::AptosCoin", oo = exports.APTOS_FA = "0x000000000000000000000000000000000000000000000000000000000000000a", so = exports.RAW_TRANSACTION_SALT = "APTOS::RawTransaction", Qn = exports.RAW_TRANSACTION_WITH_DATA_SALT = "APTOS::RawTransactionWithData", ke = exports.ProcessorType = ((c)=>(c.ACCOUNT_TRANSACTION_PROCESSOR = "account_transactions_processor", c.DEFAULT = "default_processor", c.EVENTS_PROCESSOR = "events_processor", c.FUNGIBLE_ASSET_PROCESSOR = "fungible_asset_processor", c.STAKE_PROCESSOR = "stake_processor", c.TOKEN_V2_PROCESSOR = "token_v2_processor", c.USER_TRANSACTION_PROCESSOR = "user_transaction_processor", c.OBJECT_PROCESSOR = "objects_processor", c))(ke || {}), ao = exports.FIREBASE_AUTH_ISS_PATTERN = /^https:\/\/securetoken\.google\.com\/[a-zA-Z0-9-_]+$/;
function co(r, e) {
    let t = e.bcsToBytes(), n = new N(t);
    return r.deserialize(n);
}
var gc = ((o)=>(o[o.API_ERROR = 0] = "API_ERROR", o[o.EXTERNAL_API_ERROR = 1] = "EXTERNAL_API_ERROR", o[o.SESSION_EXPIRED = 2] = "SESSION_EXPIRED", o[o.INVALID_STATE = 3] = "INVALID_STATE", o[o.UNKNOWN = 4] = "UNKNOWN", o))(gc || {}), yc = exports.KeylessErrorResolutionTip = ((p)=>(p.REAUTHENTICATE = "Re-authentiate to continue using your keyless account", p.REAUTHENTICATE_UNSURE = "Try re-authentiating. If the error persists join the telegram group at https://t.me/+h5CN-W35yUFiYzkx for further support", p.UPDATE_REQUEST_PARAMS = "Update the invalid request parameters and reauthenticate.", p.RATE_LIMIT_EXCEEDED = "Cache the keyless account and reuse it to avoid making too many requests.  Keyless accounts are valid until either the EphemeralKeyPair expires, when the JWK is rotated, or when the proof verifying key is changed, whichever comes soonest.", p.SERVER_ERROR = "Try again later.  See aptosApiError error for more context. For additional support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx", p.CALL_PRECHECK = "Call `await account.checkKeylessAccountValidity()` to wait for asyncronous changes and check for account validity before signing or serializing.", p.REINSTANTIATE = "Try instantiating the account again.  Avoid manipulating the account object directly", p.JOIN_SUPPORT_GROUP = "For support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx", p.UNKNOWN = "Error unknown. For support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx", p))(yc || {}), jr = exports.KeylessErrorType = ((m)=>(m[m.EPHEMERAL_KEY_PAIR_EXPIRED = 0] = "EPHEMERAL_KEY_PAIR_EXPIRED", m[m.PROOF_NOT_FOUND = 1] = "PROOF_NOT_FOUND", m[m.ASYNC_PROOF_FETCH_FAILED = 2] = "ASYNC_PROOF_FETCH_FAILED", m[m.INVALID_PROOF_VERIFICATION_FAILED = 3] = "INVALID_PROOF_VERIFICATION_FAILED", m[m.INVALID_PROOF_VERIFICATION_KEY_NOT_FOUND = 4] = "INVALID_PROOF_VERIFICATION_KEY_NOT_FOUND", m[m.INVALID_JWT_SIG = 5] = "INVALID_JWT_SIG", m[m.INVALID_JWT_JWK_NOT_FOUND = 6] = "INVALID_JWT_JWK_NOT_FOUND", m[m.INVALID_JWT_ISS_NOT_RECOGNIZED = 7] = "INVALID_JWT_ISS_NOT_RECOGNIZED", m[m.INVALID_JWT_FEDERATED_ISS_NOT_SUPPORTED = 8] = "INVALID_JWT_FEDERATED_ISS_NOT_SUPPORTED", m[m.INVALID_TW_SIG_VERIFICATION_FAILED = 9] = "INVALID_TW_SIG_VERIFICATION_FAILED", m[m.INVALID_TW_SIG_PUBLIC_KEY_NOT_FOUND = 10] = "INVALID_TW_SIG_PUBLIC_KEY_NOT_FOUND", m[m.INVALID_EXPIRY_HORIZON = 11] = "INVALID_EXPIRY_HORIZON", m[m.JWT_PARSING_ERROR = 12] = "JWT_PARSING_ERROR", m[m.JWK_FETCH_FAILED = 13] = "JWK_FETCH_FAILED", m[m.JWK_FETCH_FAILED_FEDERATED = 14] = "JWK_FETCH_FAILED_FEDERATED", m[m.RATE_LIMIT_EXCEEDED = 15] = "RATE_LIMIT_EXCEEDED", m[m.PEPPER_SERVICE_INTERNAL_ERROR = 16] = "PEPPER_SERVICE_INTERNAL_ERROR", m[m.PEPPER_SERVICE_BAD_REQUEST = 17] = "PEPPER_SERVICE_BAD_REQUEST", m[m.PEPPER_SERVICE_OTHER = 18] = "PEPPER_SERVICE_OTHER", m[m.PROVER_SERVICE_INTERNAL_ERROR = 19] = "PROVER_SERVICE_INTERNAL_ERROR", m[m.PROVER_SERVICE_BAD_REQUEST = 20] = "PROVER_SERVICE_BAD_REQUEST", m[m.PROVER_SERVICE_OTHER = 21] = "PROVER_SERVICE_OTHER", m[m.FULL_NODE_CONFIG_LOOKUP_ERROR = 22] = "FULL_NODE_CONFIG_LOOKUP_ERROR", m[m.FULL_NODE_VERIFICATION_KEY_LOOKUP_ERROR = 23] = "FULL_NODE_VERIFICATION_KEY_LOOKUP_ERROR", m[m.FULL_NODE_JWKS_LOOKUP_ERROR = 24] = "FULL_NODE_JWKS_LOOKUP_ERROR", m[m.FULL_NODE_OTHER = 25] = "FULL_NODE_OTHER", m[m.UNKNOWN = 26] = "UNKNOWN", m))(jr || {}), uo = {
    0: [
        "The ephemeral keypair has expired.",
        2,
        "Re-authentiate to continue using your keyless account"
    ],
    1: [
        "The required proof could not be found.",
        3,
        "Call `await account.checkKeylessAccountValidity()` to wait for asyncronous changes and check for account validity before signing or serializing."
    ],
    2: [
        "The required proof failed to fetch.",
        3,
        "Try re-authentiating. If the error persists join the telegram group at https://t.me/+h5CN-W35yUFiYzkx for further support"
    ],
    3: [
        "The provided proof is invalid.",
        3,
        "Try re-authentiating. If the error persists join the telegram group at https://t.me/+h5CN-W35yUFiYzkx for further support"
    ],
    4: [
        "The verification key used to authenticate was updated.",
        2,
        "Re-authentiate to continue using your keyless account"
    ],
    5: [
        "The JWK was found, but JWT failed verification",
        3,
        "Try re-authentiating. If the error persists join the telegram group at https://t.me/+h5CN-W35yUFiYzkx for further support"
    ],
    6: [
        "The JWK required to verify the JWT could not be found. The JWK may have been rotated out.",
        2,
        "Re-authentiate to continue using your keyless account"
    ],
    7: [
        "The JWT issuer is not recognized.",
        3,
        "Update the invalid request parameters and reauthenticate."
    ],
    8: [
        "The JWT issuer is not supported by the Federated Keyless ",
        0,
        "Try re-authentiating. If the error persists join the telegram group at https://t.me/+h5CN-W35yUFiYzkx for further support"
    ],
    9: [
        "The training wheels signature is invalid.",
        3,
        "Try re-authentiating. If the error persists join the telegram group at https://t.me/+h5CN-W35yUFiYzkx for further support"
    ],
    10: [
        "The public key used to verify the training wheels signature was not found.",
        2,
        "Re-authentiate to continue using your keyless account"
    ],
    11: [
        "The expiry horizon is invalid.",
        2,
        "Re-authentiate to continue using your keyless account"
    ],
    13: [
        "Failed to fetch JWKS.",
        1,
        "For support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx"
    ],
    14: [
        "Failed to fetch JWKS for Federated Keyless provider.",
        1,
        "For support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx"
    ],
    15: [
        "Rate limit exceeded. Too many requests in a short period.",
        0,
        "Cache the keyless account and reuse it to avoid making too many requests.  Keyless accounts are valid until either the EphemeralKeyPair expires, when the JWK is rotated, or when the proof verifying key is changed, whichever comes soonest."
    ],
    16: [
        "Internal error from Pepper service.",
        0,
        "Try again later.  See aptosApiError error for more context. For additional support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx"
    ],
    17: [
        "Bad request sent to Pepper service.",
        0,
        "Update the invalid request parameters and reauthenticate."
    ],
    18: [
        "Unknown error from Pepper service.",
        0,
        "Try again later.  See aptosApiError error for more context. For additional support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx"
    ],
    19: [
        "Internal error from Prover service.",
        0,
        "Try again later.  See aptosApiError error for more context. For additional support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx"
    ],
    20: [
        "Bad request sent to Prover service.",
        0,
        "Update the invalid request parameters and reauthenticate."
    ],
    21: [
        "Unknown error from Prover service.",
        0,
        "Try again later.  See aptosApiError error for more context. For additional support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx"
    ],
    12: [
        "Error when parsing JWT. This should never happen. Join https://t.me/+h5CN-W35yUFiYzkx for support",
        3,
        "Try instantiating the account again.  Avoid manipulating the account object directly"
    ],
    22: [
        "Error when looking up on-chain keyless configuration.",
        0,
        "Try again later.  See aptosApiError error for more context. For additional support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx"
    ],
    23: [
        "Error when looking up on-chain verification key.",
        0,
        "Try again later.  See aptosApiError error for more context. For additional support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx"
    ],
    24: [
        "Error when looking up on-chain JWKS.",
        0,
        "Try again later.  See aptosApiError error for more context. For additional support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx"
    ],
    25: [
        "Unknown error from full node.",
        0,
        "Try again later.  See aptosApiError error for more context. For additional support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx"
    ],
    26: [
        "An unknown error has occurred.",
        4,
        "Error unknown. For support join the telegram group at https://t.me/+h5CN-W35yUFiYzkx"
    ]
}, K = exports.KeylessError = class r extends Error {
    constructor(e){
        let { innerError: t, category: n, resolutionTip: i, type: o, message: s = uo[o][0], details: a } = e;
        super(s), this.name = "KeylessError", this.innerError = t, this.category = n, this.resolutionTip = i, this.type = o, this.details = a, this.message = r.constructMessage(s, i, t, a);
    }
    static constructMessage(e, t, n, i) {
        let o = `
Message: ${e}`;
        return i && (o += `
Details: ${i}`), n instanceof ye ? o += `
AptosApiError: ${n.message}` : n !== void 0 && (o += `
Error: ${_chunkF43XVDYJjs.c.call(void 0, n)}`), o += `
KeylessErrorResolutionTip: ${t}`, o;
    }
    static fromErrorType(e) {
        let { error: t, type: n, details: i } = e, [o, s, a] = uo[n];
        return new r({
            message: o,
            details: i,
            innerError: t,
            category: s,
            resolutionTip: a,
            type: n
        });
    }
}, ye = exports.AptosApiError = class extends Error {
    constructor({ apiType: e, aptosRequest: t, aptosResponse: n }){
        super(mc({
            apiType: e,
            aptosRequest: t,
            aptosResponse: n
        })), this.name = "AptosApiError", this.url = n.url, this.status = n.status, this.statusText = n.statusText, this.data = n.data, this.request = t;
    }
};
function mc({ apiType: r, aptosRequest: e, aptosResponse: t }) {
    let n = _optionalChain([
        t,
        'access',
        (_14)=>_14.headers,
        'optionalAccess',
        (_15)=>_15.traceparent,
        'optionalAccess',
        (_16)=>_16.split,
        'call',
        (_17)=>_17("-"),
        'access',
        (_18)=>_18[1]
    ]), i = n ? `(trace_id:${n}) ` : "", o = `Request to [${r}]: ${e.method} ${_nullishCoalesce(t.url, ()=>e.url)} ${i}failed with`;
    return r === "Indexer" && _optionalChain([
        t,
        'access',
        (_19)=>_19.data,
        'optionalAccess',
        (_20)=>_20.errors,
        'optionalAccess',
        (_21)=>_21[0],
        'optionalAccess',
        (_22)=>_22.message
    ]) != null ? `${o}: ${t.data.errors[0].message}` : _optionalChain([
        t,
        'access',
        (_23)=>_23.data,
        'optionalAccess',
        (_24)=>_24.message
    ]) != null && _optionalChain([
        t,
        'access',
        (_25)=>_25.data,
        'optionalAccess',
        (_26)=>_26.error_code
    ]) != null ? `${o}: ${JSON.stringify(t.data)}` : `${o} status: ${t.statusText}(code:${t.status}) and response body: ${fc(t.data)}`;
}
var jn = 400;
function fc(r) {
    let e = JSON.stringify(r);
    return e.length <= jn ? e : `truncated(original_size:${e.length}): ${e.slice(0, jn / 2)}...${e.slice(-jn / 2)}`;
}
async function Ac(r, e) {
    let { url: t, method: n, body: i, contentType: o, params: s, overrides: a, originMethod: c } = r, p = {
        ..._optionalChain([
            a,
            'optionalAccess',
            (_27)=>_27.HEADERS
        ]),
        "x-aptos-client": `aptos-typescript-sdk/${Zi}`,
        "content-type": _nullishCoalesce(o, ()=>"application/json"),
        "x-aptos-typescript-sdk-origin-method": c
    };
    return _optionalChain([
        a,
        'optionalAccess',
        (_28)=>_28.AUTH_TOKEN
    ]) && (p.Authorization = `Bearer ${_optionalChain([
        a,
        'optionalAccess',
        (_29)=>_29.AUTH_TOKEN
    ])}`), _optionalChain([
        a,
        'optionalAccess',
        (_30)=>_30.API_KEY
    ]) && (p.Authorization = `Bearer ${_optionalChain([
        a,
        'optionalAccess',
        (_31)=>_31.API_KEY
    ])}`), e.provider({
        url: t,
        method: n,
        body: i,
        params: s,
        headers: p,
        overrides: a
    });
}
async function Jr(r, e, t) {
    let { url: n, path: i } = r, o = i ? `${n}/${i}` : n, s = await Ac({
        ...r,
        url: o
    }, e.client), a = {
        status: s.status,
        statusText: _nullishCoalesce(s.statusText, ()=>"No status text provided"),
        data: s.data,
        headers: s.headers,
        config: s.config,
        request: s.request,
        url: o
    };
    if (a.status === 401) throw new ye({
        apiType: t,
        aptosRequest: r,
        aptosResponse: a
    });
    if (t === "Indexer") {
        let c = a.data;
        if (c.errors) throw new ye({
            apiType: t,
            aptosRequest: r,
            aptosResponse: a
        });
        a.data = c.data;
    } else if ((t === "Pepper" || t === "Prover") && a.status >= 400) throw new ye({
        apiType: t,
        aptosRequest: r,
        aptosResponse: a
    });
    if (a.status >= 200 && a.status < 300) return a;
    throw new ye({
        apiType: t,
        aptosRequest: r,
        aptosResponse: a
    });
}
async function Jn(r) {
    let { aptosConfig: e, overrides: t, params: n, contentType: i, acceptType: o, path: s, originMethod: a, type: c } = r, p = e.getRequestUrl(c);
    return Jr({
        url: p,
        method: "GET",
        originMethod: a,
        path: s,
        contentType: i,
        acceptType: o,
        params: n,
        overrides: {
            ...e.clientConfig,
            ...t
        }
    }, e, r.type);
}
async function V(r) {
    let { aptosConfig: e } = r;
    return Jn({
        ...r,
        type: "Fullnode",
        overrides: {
            ...e.clientConfig,
            ...e.fullnodeConfig,
            ...r.overrides,
            HEADERS: {
                ..._optionalChain([
                    e,
                    'access',
                    (_32)=>_32.clientConfig,
                    'optionalAccess',
                    (_33)=>_33.HEADERS
                ]),
                ..._optionalChain([
                    e,
                    'access',
                    (_34)=>_34.fullnodeConfig,
                    'optionalAccess',
                    (_35)=>_35.HEADERS
                ])
            }
        }
    });
}
async function Ml(r) {
    return Jn({
        ...r,
        type: "Pepper"
    });
}
async function Ct(r) {
    let e = [], t, n = r.params;
    do {
        let i = await Jn({
            type: "Fullnode",
            aptosConfig: r.aptosConfig,
            originMethod: r.originMethod,
            path: r.path,
            params: n,
            overrides: r.overrides
        });
        t = i.headers["x-aptos-cursor"], delete i.headers, e.push(...i.data), n.start = t;
    }while (t != null)
    return e;
}
async function sr(r) {
    let { type: e, originMethod: t, path: n, body: i, acceptType: o, contentType: s, params: a, aptosConfig: c, overrides: p } = r, d = c.getRequestUrl(e);
    return Jr({
        url: d,
        method: "POST",
        originMethod: t,
        path: n,
        body: i,
        contentType: s,
        acceptType: o,
        params: a,
        overrides: p
    }, c, r.type);
}
async function Xe(r) {
    let { aptosConfig: e } = r;
    return sr({
        ...r,
        type: "Fullnode",
        overrides: {
            ...e.clientConfig,
            ...e.fullnodeConfig,
            ...r.overrides,
            HEADERS: {
                ..._optionalChain([
                    e,
                    'access',
                    (_36)=>_36.clientConfig,
                    'optionalAccess',
                    (_37)=>_37.HEADERS
                ]),
                ..._optionalChain([
                    e,
                    'access',
                    (_38)=>_38.fullnodeConfig,
                    'optionalAccess',
                    (_39)=>_39.HEADERS
                ])
            }
        }
    });
}
async function po(r) {
    let { aptosConfig: e } = r;
    return sr({
        ...r,
        type: "Indexer",
        overrides: {
            ...e.clientConfig,
            ...e.indexerConfig,
            ...r.overrides,
            HEADERS: {
                ..._optionalChain([
                    e,
                    'access',
                    (_40)=>_40.clientConfig,
                    'optionalAccess',
                    (_41)=>_41.HEADERS
                ]),
                ..._optionalChain([
                    e,
                    'access',
                    (_42)=>_42.indexerConfig,
                    'optionalAccess',
                    (_43)=>_43.HEADERS
                ])
            }
        }
    });
}
async function lo(r) {
    let { aptosConfig: e } = r, t = {
        ...e,
        clientConfig: {
            ...e.clientConfig
        }
    };
    return _optionalChainDelete([
        t,
        'optionalAccess',
        (_44)=>_44.clientConfig,
        'optionalAccess',
        (_45)=>delete _45.API_KEY
    ]), sr({
        ...r,
        type: "Faucet",
        overrides: {
            ...t.clientConfig,
            ...t.faucetConfig,
            ...r.overrides,
            HEADERS: {
                ..._optionalChain([
                    t,
                    'access',
                    (_46)=>_46.clientConfig,
                    'optionalAccess',
                    (_47)=>_47.HEADERS
                ]),
                ..._optionalChain([
                    t,
                    'access',
                    (_48)=>_48.faucetConfig,
                    'optionalAccess',
                    (_49)=>_49.HEADERS
                ])
            }
        }
    });
}
async function go(r) {
    return sr({
        ...r,
        type: "Pepper"
    });
}
async function yo(r) {
    return sr({
        ...r,
        type: "Prover"
    });
}
var Xn = new Map;
function Pe(r, e, t) {
    return async (...n)=>{
        if (Xn.has(e)) {
            let { value: o, timestamp: s } = Xn.get(e);
            if (t === void 0 || Date.now() - s <= t) return o;
        }
        let i = await r(...n);
        return Xn.set(e, {
            value: i,
            timestamp: Date.now()
        }), i;
    };
}
var bg = 1e7, Tc = exports.MAX_AUD_VAL_BYTES = 120, bc = exports.MAX_UID_KEY_BYTES = 30, wc = exports.MAX_UID_VAL_BYTES = 330, wg = exports.MAX_ISS_VAL_BYTES = 120, _g = exports.MAX_EXTRA_FIELD_BYTES = 350, Sg = exports.MAX_JWT_HEADER_B64_BYTES = 300, xg = exports.MAX_COMMITED_EPK_BYTES = 93, ve = class ve extends ne {
    constructor(e, t){
        super();
        let n = g.fromHexInput(t).toUint8Array();
        if (n.length !== ve.ID_COMMITMENT_LENGTH) throw new Error(`Id Commitment length in bytes should be ${ve.ID_COMMITMENT_LENGTH}`);
        this.iss = e, this.idCommitment = n;
    }
    authKey() {
        let e = new q;
        return e.serializeU32AsUleb128(3), e.serializeFixedBytes(this.bcsToBytes()), B.fromSchemeAndBytes({
            scheme: 2,
            input: e.toUint8Array()
        });
    }
    verifySignature(e) {
        throw new Error("Not yet implemented");
    }
    serialize(e) {
        e.serializeStr(this.iss), e.serializeBytes(this.idCommitment);
    }
    static deserialize(e) {
        let t = e.deserializeStr(), n = e.deserializeBytes();
        return new ve(t, n);
    }
    static load(e) {
        let t = e.deserializeStr(), n = e.deserializeBytes();
        return new ve(t, n);
    }
    static isPublicKey(e) {
        return e instanceof ve;
    }
    static create(e) {
        return mo(e), new ve(e.iss, mo(e));
    }
    static fromJwtAndPepper(e) {
        let { jwt: t, pepper: n, uidKey: i = "sub" } = e, o = _jwtdecode.jwtDecode.call(void 0, t);
        if (typeof o.iss != "string") throw new Error("iss was not found");
        if (typeof o.aud != "string") throw new Error("aud was not found or an array of values");
        let s = o[i];
        return ve.create({
            iss: o.iss,
            uidKey: i,
            uidVal: s,
            aud: o.aud,
            pepper: n
        });
    }
    static isInstance(e) {
        return "iss" in e && typeof e.iss == "string" && "idCommitment" in e && e.idCommitment instanceof Uint8Array;
    }
};
ve.ID_COMMITMENT_LENGTH = 32;
var O = ve;
function mo(r) {
    let { uidKey: e, uidVal: t, aud: n, pepper: i } = r, o = [
        ir(g.fromHexInput(i).toUint8Array()),
        $r(n, Tc),
        $r(t, wc),
        $r(e, bc)
    ];
    return Yi(or(o), O.ID_COMMITMENT_LENGTH);
}
var De = class r extends M {
    constructor(e){
        super();
        let { jwtHeader: t, ephemeralCertificate: n, expiryDateSecs: i, ephemeralPublicKey: o, ephemeralSignature: s } = e;
        this.jwtHeader = t, this.ephemeralCertificate = n, this.expiryDateSecs = i, this.ephemeralPublicKey = o, this.ephemeralSignature = s;
    }
    getJwkKid() {
        return xc(this.jwtHeader).kid;
    }
    serialize(e) {
        this.ephemeralCertificate.serialize(e), e.serializeStr(this.jwtHeader), e.serializeU64(this.expiryDateSecs), this.ephemeralPublicKey.serialize(e), this.ephemeralSignature.serialize(e);
    }
    static deserialize(e) {
        let t = Rt.deserialize(e), n = e.deserializeStr(), i = e.deserializeU64(), o = lt.deserialize(e), s = Ee.deserialize(e);
        return new r({
            jwtHeader: n,
            expiryDateSecs: Number(i),
            ephemeralCertificate: t,
            ephemeralPublicKey: o,
            ephemeralSignature: s
        });
    }
    static getSimulationSignature() {
        return new r({
            jwtHeader: "{}",
            ephemeralCertificate: new Rt(new ze({
                proof: new Kt(new Ut({
                    a: new Uint8Array(32),
                    b: new Uint8Array(64),
                    c: new Uint8Array(32)
                }), 0),
                expHorizonSecs: 0
            }), 0),
            expiryDateSecs: 0,
            ephemeralPublicKey: new lt(new P(new Uint8Array(32))),
            ephemeralSignature: new Ee(new I(new Uint8Array(64)))
        });
    }
    static isSignature(e) {
        return e instanceof r;
    }
}, Rt = exports.EphemeralCertificate = class r extends M {
    constructor(e, t){
        super(), this.signature = e, this.variant = t;
    }
    toUint8Array() {
        return this.signature.toUint8Array();
    }
    serialize(e) {
        e.serializeU32AsUleb128(this.variant), this.signature.serialize(e);
    }
    static deserialize(e) {
        let t = e.deserializeUleb128AsU32();
        switch(t){
            case 0:
                return new r(ze.deserialize(e), t);
            default:
                throw new Error(`Unknown variant index for EphemeralCertificate: ${t}`);
        }
    }
}, Oe = class r extends l {
    constructor(e){
        if (super(), this.data = g.fromHexInput(e).toUint8Array(), this.data.length !== 32) throw new Error("Input needs to be 32 bytes");
    }
    serialize(e) {
        e.serializeFixedBytes(this.data);
    }
    static deserialize(e) {
        let t = e.deserializeFixedBytes(32);
        return new r(t);
    }
}, yt = class r extends l {
    constructor(e){
        if (super(), this.data = g.fromHexInput(e).toUint8Array(), this.data.length !== 64) throw new Error("Input needs to be 64 bytes");
    }
    serialize(e) {
        e.serializeFixedBytes(this.data);
    }
    static deserialize(e) {
        let t = e.deserializeFixedBytes(64);
        return new r(t);
    }
}, Ut = exports.Groth16Zkp = class r extends Wr {
    constructor(e){
        super();
        let { a: t, b: n, c: i } = e;
        this.a = new Oe(t), this.b = new yt(n), this.c = new Oe(i);
    }
    serialize(e) {
        this.a.serialize(e), this.b.serialize(e), this.c.serialize(e);
    }
    static deserialize(e) {
        let t = Oe.deserialize(e).bcsToBytes(), n = yt.deserialize(e).bcsToBytes(), i = Oe.deserialize(e).bcsToBytes();
        return new r({
            a: t,
            b: n,
            c: i
        });
    }
}, Kt = exports.ZkProof = class r extends l {
    constructor(e, t){
        super(), this.proof = e, this.variant = t;
    }
    serialize(e) {
        e.serializeU32AsUleb128(this.variant), this.proof.serialize(e);
    }
    static deserialize(e) {
        let t = e.deserializeUleb128AsU32();
        switch(t){
            case 0:
                return new r(Ut.deserialize(e), t);
            default:
                throw new Error(`Unknown variant index for ZkProof: ${t}`);
        }
    }
}, ze = exports.ZeroKnowledgeSig = class r extends M {
    constructor(e){
        super();
        let { proof: t, expHorizonSecs: n, trainingWheelsSignature: i, extraField: o, overrideAudVal: s } = e;
        this.proof = t, this.expHorizonSecs = n, this.trainingWheelsSignature = i, this.extraField = o, this.overrideAudVal = s;
    }
    static fromBytes(e) {
        return r.deserialize(new N(e));
    }
    serialize(e) {
        this.proof.serialize(e), e.serializeU64(this.expHorizonSecs), e.serializeOption(this.extraField), e.serializeOption(this.overrideAudVal), e.serializeOption(this.trainingWheelsSignature);
    }
    static deserialize(e) {
        let t = Kt.deserialize(e), n = Number(e.deserializeU64()), i = e.deserializeOption("string"), o = e.deserializeOption("string"), s = e.deserializeOption(Ee);
        return new r({
            proof: t,
            expHorizonSecs: n,
            trainingWheelsSignature: s,
            extraField: i,
            overrideAudVal: o
        });
    }
}, Yn = exports.KeylessConfiguration = class r {
    constructor(e, t){
        this.verificationKey = e, this.maxExpHorizonSecs = t;
    }
    static create(e, t) {
        return new r(new Zn({
            alphaG1: e.alpha_g1,
            betaG2: e.beta_g2,
            deltaG2: e.delta_g2,
            gammaAbcG1: e.gamma_abc_g1,
            gammaG2: e.gamma_g2
        }), t);
    }
}, Zn = exports.Groth16VerificationKey = class r {
    constructor(e){
        let { alphaG1: t, betaG2: n, deltaG2: i, gammaAbcG1: o, gammaG2: s } = e;
        this.alphaG1 = new Oe(t), this.betaG2 = new yt(n), this.deltaG2 = new yt(i), this.gammaAbcG1 = [
            new Oe(o[0]),
            new Oe(o[1])
        ], this.gammaG2 = new yt(s);
    }
    hash() {
        let e = new q;
        return this.serialize(e), _sha3.sha3_256.create().update(e.toUint8Array()).digest();
    }
    serialize(e) {
        this.alphaG1.serialize(e), this.betaG2.serialize(e), this.deltaG2.serialize(e), this.gammaAbcG1[0].serialize(e), this.gammaAbcG1[1].serialize(e), this.gammaG2.serialize(e);
    }
    static fromGroth16VerificationKeyResponse(e) {
        return new r({
            alphaG1: e.alpha_g1,
            betaG2: e.beta_g2,
            deltaG2: e.delta_g2,
            gammaAbcG1: e.gamma_abc_g1,
            gammaG2: e.gamma_g2
        });
    }
};
async function ar(r) {
    let { aptosConfig: e } = r;
    try {
        return await Pe(async ()=>{
            let t = await _c(r), n = await Sc(r);
            return Yn.create(n, Number(t.max_exp_horizon_secs));
        }, `keyless-configuration-${e.network}`, 1e3 * 60 * 5)();
    } catch (t) {
        throw t instanceof K ? t : K.fromErrorType({
            type: 25,
            error: t
        });
    }
}
function kt(r) {
    let { jwt: e, uidKey: t = "sub" } = r, n;
    try {
        n = _jwtdecode.jwtDecode.call(void 0, e);
    } catch (o) {
        throw K.fromErrorType({
            type: 12,
            details: `Failed to parse JWT - ${_chunkF43XVDYJjs.c.call(void 0, o)}`
        });
    }
    if (typeof n.iss != "string") throw K.fromErrorType({
        type: 12,
        details: "JWT is missing 'iss' in the payload. This should never happen."
    });
    if (typeof n.aud != "string") throw K.fromErrorType({
        type: 12,
        details: "JWT is missing 'aud' in the payload or 'aud' is an array of values."
    });
    let i = n[t];
    return {
        iss: n.iss,
        aud: n.aud,
        uidVal: i
    };
}
async function _c(r) {
    let { aptosConfig: e, options: t } = r, n = "0x1::keyless_account::Configuration";
    try {
        let { data: i } = await V({
            aptosConfig: e,
            originMethod: "getKeylessConfigurationResource",
            path: `accounts/${u.from("0x1").toString()}/resource/${n}`,
            params: {
                ledger_version: _optionalChain([
                    t,
                    'optionalAccess',
                    (_50)=>_50.ledgerVersion
                ])
            }
        });
        return i.data;
    } catch (i) {
        throw K.fromErrorType({
            type: 22,
            error: i
        });
    }
}
async function Sc(r) {
    let { aptosConfig: e, options: t } = r, n = "0x1::keyless_account::Groth16VerificationKey";
    try {
        let { data: i } = await V({
            aptosConfig: e,
            originMethod: "getGroth16VerificationKeyResource",
            path: `accounts/${u.from("0x1").toString()}/resource/${n}`,
            params: {
                ledger_version: _optionalChain([
                    t,
                    'optionalAccess',
                    (_51)=>_51.ledgerVersion
                ])
            }
        });
        return i.data;
    } catch (i) {
        throw K.fromErrorType({
            type: 23,
            error: i
        });
    }
}
async function Ao(r) {
    let { aptosConfig: e, jwkAddr: t, options: n } = r, i;
    if (t) {
        let s = "0x1::jwks::FederatedJWKs", { data: a } = await V({
            aptosConfig: e,
            originMethod: "getKeylessJWKs",
            path: `accounts/${u.from(t).toString()}/resource/${s}`,
            params: {
                ledger_version: _optionalChain([
                    n,
                    'optionalAccess',
                    (_52)=>_52.ledgerVersion
                ])
            }
        });
        i = a;
    } else {
        let s = "0x1::jwks::PatchedJWKs", { data: a } = await V({
            aptosConfig: e,
            originMethod: "getKeylessJWKs",
            path: `accounts/0x1/resource/${s}`,
            params: {
                ledger_version: _optionalChain([
                    n,
                    'optionalAccess',
                    (_53)=>_53.ledgerVersion
                ])
            }
        });
        i = a;
    }
    let o = new Map;
    for (let s of i.data.jwks.entries){
        let a = [];
        for (let c of s.jwks){
            let { data: p } = c.variant, d = new N(g.fromHexInput(p).toUint8Array()), A = ei.deserialize(d);
            a.push(A);
        }
        o.set(Ki(s.issuer), a);
    }
    return o;
}
var ei = class r extends l {
    constructor(e){
        super();
        let { kid: t, kty: n, alg: i, e: o, n: s } = e;
        this.kid = t, this.kty = n, this.alg = i, this.e = o, this.n = s;
    }
    serialize(e) {
        e.serializeStr(this.kid), e.serializeStr(this.kty), e.serializeStr(this.alg), e.serializeStr(this.e), e.serializeStr(this.n);
    }
    static fromMoveStruct(e) {
        let { data: t } = e.variant, n = new N(g.fromHexInput(t).toUint8Array());
        return r.deserialize(n);
    }
    static deserialize(e) {
        let t = e.deserializeStr(), n = e.deserializeStr(), i = e.deserializeStr(), o = e.deserializeStr(), s = e.deserializeStr();
        return new r({
            kid: t,
            kty: n,
            alg: i,
            n: o,
            e: s
        });
    }
};
function xc(r) {
    try {
        let e = JSON.parse(r);
        if (e.kid === void 0) throw new Error("JWT header missing kid");
        return e;
    } catch (e2) {
        throw new Error("Failed to parse JWT header.");
    }
}
var ee = class r extends ne {
    constructor(e, t){
        super(), this.jwkAddress = u.from(e), this.keylessPublicKey = t;
    }
    authKey() {
        let e = new q;
        return e.serializeU32AsUleb128(4), e.serializeFixedBytes(this.bcsToBytes()), B.fromSchemeAndBytes({
            scheme: 2,
            input: e.toUint8Array()
        });
    }
    verifySignature(e) {
        throw new Error("Not yet implemented");
    }
    serialize(e) {
        this.jwkAddress.serialize(e), this.keylessPublicKey.serialize(e);
    }
    static deserialize(e) {
        let t = u.deserialize(e), n = O.deserialize(e);
        return new r(t, n);
    }
    static isPublicKey(e) {
        return e instanceof r;
    }
    static create(e) {
        return new r(e.jwkAddress, O.create(e));
    }
    static fromJwtAndPepper(e) {
        return new r(e.jwkAddress, O.fromJwtAndPepper(e));
    }
    static isInstance(e) {
        return "jwkAddress" in e && e.jwkAddress instanceof u && "keylessPublicKey" in e && e.keylessPublicKey instanceof O;
    }
};
var F = class r extends ne {
    constructor(e){
        if (super(), this.publicKey = e, e instanceof P) this.variant = 0;
        else if (e instanceof Ke) this.variant = 1;
        else if (e instanceof O) this.variant = 3;
        else if (e instanceof ee) this.variant = 4;
        else throw new Error("Unsupported public key type");
    }
    verifySignature(e) {
        let { message: t, signature: n } = e;
        return L.isInstance(n) ? this.publicKey.verifySignature({
            message: t,
            signature: n.signature
        }) : !1;
    }
    authKey() {
        return B.fromSchemeAndBytes({
            scheme: 2,
            input: this.toUint8Array()
        });
    }
    toUint8Array() {
        return this.bcsToBytes();
    }
    serialize(e) {
        e.serializeU32AsUleb128(this.variant), this.publicKey.serialize(e);
    }
    static deserialize(e) {
        let t = e.deserializeUleb128AsU32(), n;
        switch(t){
            case 0:
                n = P.deserialize(e);
                break;
            case 1:
                n = Ke.deserialize(e);
                break;
            case 3:
                n = O.deserialize(e);
                break;
            case 4:
                n = ee.deserialize(e);
                break;
            default:
                throw new Error(`Unknown variant index for AnyPublicKey: ${t}`);
        }
        return new r(n);
    }
    static isPublicKey(e) {
        return e instanceof r;
    }
    isEd25519() {
        return this.publicKey instanceof P;
    }
    isSecp256k1PublicKey() {
        return this.publicKey instanceof Ke;
    }
    static isInstance(e) {
        return "publicKey" in e && "variant" in e;
    }
}, L = exports.AnySignature = class r extends M {
    constructor(e){
        if (super(), this.signature = e, e instanceof I) this.variant = 0;
        else if (e instanceof dt) this.variant = 1;
        else if (e instanceof De) this.variant = 3;
        else throw new Error("Unsupported signature type");
    }
    toUint8Array() {
        return console.warn("[Aptos SDK] Calls to AnySignature.toUint8Array() will soon return the underlying signature bytes. Use AnySignature.bcsToBytes() instead."), this.bcsToBytes();
    }
    serialize(e) {
        e.serializeU32AsUleb128(this.variant), this.signature.serialize(e);
    }
    static deserialize(e) {
        let t = e.deserializeUleb128AsU32(), n;
        switch(t){
            case 0:
                n = I.deserialize(e);
                break;
            case 1:
                n = dt.deserialize(e);
                break;
            case 3:
                n = De.deserialize(e);
                break;
            default:
                throw new Error(`Unknown variant index for AnySignature: ${t}`);
        }
        return new r(n);
    }
    static isInstance(e) {
        return "signature" in e && typeof e.signature == "object" && e.signature !== null && "toUint8Array" in e.signature;
    }
};
function Ec(r) {
    let e = r;
    return e -= e >> 1 & 1431655765, e = (e & 858993459) + (e >> 2 & 858993459), (e + (e >> 4) & 252645135) * 16843009 >> 24;
}
var Ye = class r extends ne {
    constructor(e){
        super();
        let { publicKeys: t, signaturesRequired: n } = e;
        if (n < 1) throw new Error("The number of required signatures needs to be greater than 0");
        if (t.length < n) throw new Error(`Provided ${t.length} public keys is smaller than the ${n} required signatures`);
        this.publicKeys = t.map((i)=>i instanceof F ? i : new F(i)), this.signaturesRequired = n;
    }
    verifySignature(e) {
        throw new Error("not implemented");
    }
    authKey() {
        return B.fromSchemeAndBytes({
            scheme: 3,
            input: this.toUint8Array()
        });
    }
    serialize(e) {
        e.serializeVector(this.publicKeys), e.serializeU8(this.signaturesRequired);
    }
    static deserialize(e) {
        let t = e.deserializeVector(F), n = e.deserializeU8();
        return new r({
            publicKeys: t,
            signaturesRequired: n
        });
    }
    createBitmap(e) {
        let { bits: t } = e, n = 128, i = new Uint8Array([
            0,
            0,
            0,
            0
        ]), o = new Set;
        return t.forEach((s, a)=>{
            if (a + 1 > this.publicKeys.length) throw new Error(`Signature index ${a + 1} is out of public keys range, ${this.publicKeys.length}.`);
            if (o.has(s)) throw new Error(`Duplicate bit ${s} detected.`);
            o.add(s);
            let c = Math.floor(s / 8), p = i[c];
            p |= n >> s % 8, i[c] = p;
        }), i;
    }
    getIndex(e) {
        let t = e instanceof F ? e : new F(e), n = this.publicKeys.findIndex((i)=>i.toString() === t.toString());
        if (n !== -1) return n;
        throw new Error("Public key not found in MultiKey");
    }
    static isInstance(e) {
        return "publicKeys" in e && "signaturesRequired" in e;
    }
}, se = class se extends M {
    constructor(e){
        super();
        let { signatures: t, bitmap: n } = e;
        if (t.length > se.MAX_SIGNATURES_SUPPORTED) throw new Error(`The number of signatures cannot be greater than ${se.MAX_SIGNATURES_SUPPORTED}`);
        if (this.signatures = t.map((o)=>o instanceof L ? o : new L(o)), !(n instanceof Uint8Array)) this.bitmap = se.createBitmap({
            bits: n
        });
        else {
            if (n.length !== se.BITMAP_LEN) throw new Error(`"bitmap" length should be ${se.BITMAP_LEN}`);
            this.bitmap = n;
        }
        let i = this.bitmap.reduce((o, s)=>o + Ec(s), 0);
        if (i !== this.signatures.length) throw new Error(`Expecting ${i} signatures from the bitmap, but got ${this.signatures.length}`);
    }
    static createBitmap(e) {
        let { bits: t } = e, n = 128, i = new Uint8Array([
            0,
            0,
            0,
            0
        ]), o = new Set;
        return t.forEach((s)=>{
            if (s >= se.MAX_SIGNATURES_SUPPORTED) throw new Error(`Cannot have a signature larger than ${se.MAX_SIGNATURES_SUPPORTED - 1}.`);
            if (o.has(s)) throw new Error("Duplicate bits detected.");
            o.add(s);
            let a = Math.floor(s / 8), c = i[a];
            c |= n >> s % 8, i[a] = c;
        }), i;
    }
    serialize(e) {
        e.serializeVector(this.signatures), e.serializeBytes(this.bitmap);
    }
    static deserialize(e) {
        let t = e.deserializeVector(L), n = e.deserializeBytes();
        return new se({
            signatures: t,
            bitmap: n
        });
    }
};
se.BITMAP_LEN = 4, se.MAX_SIGNATURES_SUPPORTED = se.BITMAP_LEN * 8;
var Ne = se;
var X = class extends l {
    static deserialize(e) {
        let t = e.deserializeUleb128AsU32();
        switch(t){
            case 0:
                return Se.load(e);
            case 1:
                return Xr.load(e);
            case 2:
                return ie.load(e);
            case 3:
                return Ie.load(e);
            case 4:
                return Ot.load(e);
            default:
                throw new Error(`Unknown variant index for AccountAuthenticator: ${t}`);
        }
    }
    isEd25519() {
        return this instanceof Se;
    }
    isMultiEd25519() {
        return this instanceof Xr;
    }
    isSingleKey() {
        return this instanceof ie;
    }
    isMultiKey() {
        return this instanceof Ie;
    }
}, Se = exports.AccountAuthenticatorEd25519 = class r extends X {
    constructor(e, t){
        super(), this.public_key = e, this.signature = t;
    }
    serialize(e) {
        e.serializeU32AsUleb128(0), this.public_key.serialize(e), this.signature.serialize(e);
    }
    static load(e) {
        let t = P.deserialize(e), n = I.deserialize(e);
        return new r(t, n);
    }
}, Xr = exports.AccountAuthenticatorMultiEd25519 = class r extends X {
    constructor(e, t){
        super(), this.public_key = e, this.signature = t;
    }
    serialize(e) {
        e.serializeU32AsUleb128(1), this.public_key.serialize(e), this.signature.serialize(e);
    }
    static load(e) {
        let t = Pt.deserialize(e), n = ut.deserialize(e);
        return new r(t, n);
    }
}, ie = exports.AccountAuthenticatorSingleKey = class r extends X {
    constructor(e, t){
        super(), this.public_key = e, this.signature = t;
    }
    serialize(e) {
        e.serializeU32AsUleb128(2), this.public_key.serialize(e), this.signature.serialize(e);
    }
    static load(e) {
        let t = F.deserialize(e), n = L.deserialize(e);
        return new r(t, n);
    }
}, Ie = exports.AccountAuthenticatorMultiKey = class r extends X {
    constructor(e, t){
        super(), this.public_keys = e, this.signatures = t;
    }
    serialize(e) {
        e.serializeU32AsUleb128(3), this.public_keys.serialize(e), this.signatures.serialize(e);
    }
    static load(e) {
        let t = Ye.deserialize(e), n = Ne.deserialize(e);
        return new r(t, n);
    }
}, Ot = exports.AccountAuthenticatorNoAccountAuthenticator = class r extends X {
    serialize(e) {
        e.serializeU32AsUleb128(4);
    }
    static load(e) {
        return new r;
    }
};
var Dt = class r extends l {
    constructor(e){
        super(), this.chainId = e;
    }
    serialize(e) {
        e.serializeU8(this.chainId);
    }
    static deserialize(e) {
        let t = e.deserializeU8();
        return new r(t);
    }
};
var R = class r extends l {
    constructor(e){
        super(), this.identifier = e;
    }
    serialize(e) {
        e.serializeStr(this.identifier);
    }
    static deserialize(e) {
        let t = e.deserializeStr();
        return new r(t);
    }
};
var Yr = (r, e)=>{
    let t = r.bcsToBytes(), n = typeof e == "string" ? Buffer.from(e, "utf8") : e, i = new Uint8Array([
        ...t,
        ...n,
        254
    ]);
    return new u(_sha3.sha3_256.call(void 0, i));
}, Dy = exports.createResourceAddress = (r, e)=>{
    let t = r.bcsToBytes(), n = typeof e == "string" ? Buffer.from(e, "utf8") : e, i = new Uint8Array([
        ...t,
        ...n,
        255
    ]);
    return new u(_sha3.sha3_256.call(void 0, i));
}, zy = exports.createTokenAddress = (r, e, t)=>{
    let n = `${e}::${t}`;
    return Yr(r, n);
};
var cr = class r extends l {
    constructor(e, t){
        super(), this.address = e, this.name = t;
    }
    static fromStr(e) {
        let t = e.split("::");
        if (t.length !== 2) throw new Error("Invalid module id.");
        return new r(u.fromString(t[0]), new R(t[1]));
    }
    serialize(e) {
        this.address.serialize(e), this.name.serialize(e);
    }
    static deserialize(e) {
        let t = u.deserialize(e), n = R.deserialize(e);
        return new r(t, n);
    }
};
var D = class r extends l {
    deserialize(e) {
        let t = u.deserialize(e), n = R.deserialize(e), i = R.deserialize(e), o = e.deserializeVector(r);
        return new Ce(t, n, i, o);
    }
    static deserialize(e) {
        let t = e.deserializeUleb128AsU32();
        switch(t){
            case 0:
                return G.load(e);
            case 1:
                return ae.load(e);
            case 2:
                return W.load(e);
            case 3:
                return Be.load(e);
            case 4:
                return Y.load(e);
            case 5:
                return mt.load(e);
            case 6:
                return C.load(e);
            case 7:
                return f.load(e);
            case 8:
                return Fe.load(e);
            case 9:
                return Ge.load(e);
            case 10:
                return Me.load(e);
            case 255:
                return z.load(e);
            default:
                throw new Error(`Unknown variant index for TypeTag: ${t}`);
        }
    }
    isBool() {
        return this instanceof G;
    }
    isAddress() {
        return this instanceof Y;
    }
    isGeneric() {
        return this instanceof z;
    }
    isSigner() {
        return this instanceof mt;
    }
    isVector() {
        return this instanceof C;
    }
    isStruct() {
        return this instanceof f;
    }
    isU8() {
        return this instanceof ae;
    }
    isU16() {
        return this instanceof Fe;
    }
    isU32() {
        return this instanceof Ge;
    }
    isU64() {
        return this instanceof W;
    }
    isU128() {
        return this instanceof Be;
    }
    isU256() {
        return this instanceof Me;
    }
    isPrimitive() {
        return this instanceof mt || this instanceof Y || this instanceof G || this instanceof ae || this instanceof Fe || this instanceof Ge || this instanceof W || this instanceof Be || this instanceof Me;
    }
}, G = exports.TypeTagBool = class r extends D {
    toString() {
        return "bool";
    }
    serialize(e) {
        e.serializeU32AsUleb128(0);
    }
    static load(e) {
        return new r;
    }
}, ae = exports.TypeTagU8 = class r extends D {
    toString() {
        return "u8";
    }
    serialize(e) {
        e.serializeU32AsUleb128(1);
    }
    static load(e) {
        return new r;
    }
}, Fe = exports.TypeTagU16 = class r extends D {
    toString() {
        return "u16";
    }
    serialize(e) {
        e.serializeU32AsUleb128(8);
    }
    static load(e) {
        return new r;
    }
}, Ge = exports.TypeTagU32 = class r extends D {
    toString() {
        return "u32";
    }
    serialize(e) {
        e.serializeU32AsUleb128(9);
    }
    static load(e) {
        return new r;
    }
}, W = exports.TypeTagU64 = class r extends D {
    toString() {
        return "u64";
    }
    serialize(e) {
        e.serializeU32AsUleb128(2);
    }
    static load(e) {
        return new r;
    }
}, Be = exports.TypeTagU128 = class r extends D {
    toString() {
        return "u128";
    }
    serialize(e) {
        e.serializeU32AsUleb128(3);
    }
    static load(e) {
        return new r;
    }
}, Me = exports.TypeTagU256 = class r extends D {
    toString() {
        return "u256";
    }
    serialize(e) {
        e.serializeU32AsUleb128(10);
    }
    static load(e) {
        return new r;
    }
}, Y = exports.TypeTagAddress = class r extends D {
    toString() {
        return "address";
    }
    serialize(e) {
        e.serializeU32AsUleb128(4);
    }
    static load(e) {
        return new r;
    }
}, mt = exports.TypeTagSigner = class r extends D {
    toString() {
        return "signer";
    }
    serialize(e) {
        e.serializeU32AsUleb128(5);
    }
    static load(e) {
        return new r;
    }
}, Zr = exports.TypeTagReference = class r extends D {
    constructor(t){
        super();
        this.value = t;
    }
    toString() {
        return `&${this.value.toString()}`;
    }
    serialize(t) {
        t.serializeU32AsUleb128(254);
    }
    static load(t) {
        let n = D.deserialize(t);
        return new r(n);
    }
}, z = exports.TypeTagGeneric = class r extends D {
    constructor(t){
        super();
        this.value = t;
        if (t < 0) throw new Error("Generic type parameter index cannot be negative");
    }
    toString() {
        return `T${this.value}`;
    }
    serialize(t) {
        t.serializeU32AsUleb128(255), t.serializeU32(this.value);
    }
    static load(t) {
        let n = t.deserializeU32();
        return new r(n);
    }
}, C = exports.TypeTagVector = class r extends D {
    constructor(t){
        super();
        this.value = t;
    }
    toString() {
        return `vector<${this.value.toString()}>`;
    }
    static u8() {
        return new r(new ae);
    }
    serialize(t) {
        t.serializeU32AsUleb128(6), this.value.serialize(t);
    }
    static load(t) {
        let n = D.deserialize(t);
        return new r(n);
    }
}, f = exports.TypeTagStruct = class r extends D {
    constructor(t){
        super();
        this.value = t;
    }
    toString() {
        let t = "";
        return this.value.typeArgs.length > 0 && (t = `<${this.value.typeArgs.map((n)=>n.toString()).join(", ")}>`), `${this.value.address.toString()}::${this.value.moduleName.identifier}::${this.value.name.identifier}${t}`;
    }
    serialize(t) {
        t.serializeU32AsUleb128(7), this.value.serialize(t);
    }
    static load(t) {
        let n = Ce.deserialize(t);
        return new r(n);
    }
    isTypeTag(t, n, i) {
        return this.value.moduleName.identifier === n && this.value.name.identifier === i && this.value.address.equals(t);
    }
    isString() {
        return this.isTypeTag(u.ONE, "string", "String");
    }
    isOption() {
        return this.isTypeTag(u.ONE, "option", "Option");
    }
    isObject() {
        return this.isTypeTag(u.ONE, "object", "Object");
    }
}, Ce = exports.StructTag = class r extends l {
    constructor(e, t, n, i){
        super(), this.address = e, this.moduleName = t, this.name = n, this.typeArgs = i;
    }
    serialize(e) {
        e.serialize(this.address), e.serialize(this.moduleName), e.serialize(this.name), e.serializeVector(this.typeArgs);
    }
    static deserialize(e) {
        let t = u.deserialize(e), n = R.deserialize(e), i = R.deserialize(e), o = e.deserializeVector(D);
        return new r(t, n, i, o);
    }
};
function om() {
    return new Ce(u.ONE, new R("aptos_coin"), new R("AptosCoin"), []);
}
function v() {
    return new Ce(u.ONE, new R("string"), new R("String"), []);
}
function sm(r) {
    return new Ce(u.ONE, new R("option"), new R("Option"), [
        r
    ]);
}
function ce(r) {
    return new Ce(u.ONE, new R("object"), new R("Object"), [
        r
    ]);
}
function Pc(r) {
    let e = r.deserializeUleb128AsU32();
    switch(e){
        case 0:
            return j.deserialize(r);
        case 1:
            return $.deserialize(r);
        case 2:
            return we.deserialize(r);
        case 3:
            return u.deserialize(r);
        case 4:
            return b.deserialize(r, j);
        case 5:
            return U.deserialize(r);
        case 6:
            return Te.deserialize(r);
        case 7:
            return be.deserialize(r);
        case 8:
            return de.deserialize(r);
        case 9:
            return tr.deserialize(r);
        default:
            throw new Error(`Unknown variant index for ScriptTransactionArgument: ${e}`);
    }
}
var ft = class extends l {
    static deserialize(e) {
        let t = e.deserializeUleb128AsU32();
        switch(t){
            case 0:
                return ur.load(e);
            case 2:
                return pr.load(e);
            case 3:
                return dr.load(e);
            default:
                throw new Error(`Unknown variant index for TransactionPayload: ${t}`);
        }
    }
}, ur = exports.TransactionPayloadScript = class r extends ft {
    constructor(e){
        super(), this.script = e;
    }
    serialize(e) {
        e.serializeU32AsUleb128(0), this.script.serialize(e);
    }
    static load(e) {
        let t = lr.deserialize(e);
        return new r(t);
    }
}, pr = exports.TransactionPayloadEntryFunction = class r extends ft {
    constructor(e){
        super(), this.entryFunction = e;
    }
    serialize(e) {
        e.serializeU32AsUleb128(2), this.entryFunction.serialize(e);
    }
    static load(e) {
        let t = At.deserialize(e);
        return new r(t);
    }
}, dr = exports.TransactionPayloadMultiSig = class r extends ft {
    constructor(e){
        super(), this.multiSig = e;
    }
    serialize(e) {
        e.serializeU32AsUleb128(3), this.multiSig.serialize(e);
    }
    static load(e) {
        let t = gr.deserialize(e);
        return new r(t);
    }
}, At = exports.EntryFunction = class r {
    constructor(e, t, n, i){
        this.module_name = e, this.function_name = t, this.type_args = n, this.args = i;
    }
    static build(e, t, n, i) {
        return new r(cr.fromStr(e), new R(t), n, i);
    }
    serialize(e) {
        this.module_name.serialize(e), this.function_name.serialize(e), e.serializeVector(this.type_args), e.serializeU32AsUleb128(this.args.length), this.args.forEach((t)=>{
            t.serializeForEntryFunction(e);
        });
    }
    static deserialize(e) {
        let t = cr.deserialize(e), n = R.deserialize(e), i = e.deserializeVector(D), o = e.deserializeUleb128AsU32(), s = new Array;
        for(let a = 0; a < o; a += 1){
            let c = e.deserializeUleb128AsU32(), p = Br.deserialize(e, c);
            s.push(p);
        }
        return new r(t, n, i, s);
    }
}, lr = exports.Script = class r {
    constructor(e, t, n){
        this.bytecode = e, this.type_args = t, this.args = n;
    }
    serialize(e) {
        e.serializeBytes(this.bytecode), e.serializeVector(this.type_args), e.serializeU32AsUleb128(this.args.length), this.args.forEach((t)=>{
            t.serializeForScriptFunction(e);
        });
    }
    static deserialize(e) {
        let t = e.deserializeBytes(), n = e.deserializeVector(D), i = e.deserializeUleb128AsU32(), o = new Array;
        for(let s = 0; s < i; s += 1){
            let a = Pc(e);
            o.push(a);
        }
        return new r(t, n, o);
    }
}, gr = exports.MultiSig = class r {
    constructor(e, t){
        this.multisig_address = e, this.transaction_payload = t;
    }
    serialize(e) {
        this.multisig_address.serialize(e), this.transaction_payload === void 0 ? e.serializeBool(!1) : (e.serializeBool(!0), this.transaction_payload.serialize(e));
    }
    static deserialize(e) {
        let t = u.deserialize(e), n = e.deserializeBool(), i;
        return n && (i = yr.deserialize(e)), new r(t, i);
    }
}, yr = exports.MultiSigTransactionPayload = class r extends l {
    constructor(e){
        super(), this.transaction_payload = e;
    }
    serialize(e) {
        e.serializeU32AsUleb128(0), this.transaction_payload.serialize(e);
    }
    static deserialize(e) {
        return e.deserializeUleb128AsU32(), new r(At.deserialize(e));
    }
};
var me = class r extends l {
    constructor(e, t, n, i, o, s, a){
        super(), this.sender = e, this.sequence_number = t, this.payload = n, this.max_gas_amount = i, this.gas_unit_price = o, this.expiration_timestamp_secs = s, this.chain_id = a;
    }
    serialize(e) {
        this.sender.serialize(e), e.serializeU64(this.sequence_number), this.payload.serialize(e), e.serializeU64(this.max_gas_amount), e.serializeU64(this.gas_unit_price), e.serializeU64(this.expiration_timestamp_secs), this.chain_id.serialize(e);
    }
    static deserialize(e) {
        let t = u.deserialize(e), n = e.deserializeU64(), i = ft.deserialize(e), o = e.deserializeU64(), s = e.deserializeU64(), a = e.deserializeU64(), c = Dt.deserialize(e);
        return new r(t, n, i, o, s, a, c);
    }
}, en = exports.RawTransactionWithData = class extends l {
    static deserialize(e) {
        let t = e.deserializeUleb128AsU32();
        switch(t){
            case 0:
                return ht.load(e);
            case 1:
                return Tt.load(e);
            default:
                throw new Error(`Unknown variant index for RawTransactionWithData: ${t}`);
        }
    }
}, ht = exports.MultiAgentRawTransaction = class r extends en {
    constructor(e, t){
        super(), this.raw_txn = e, this.secondary_signer_addresses = t;
    }
    serialize(e) {
        e.serializeU32AsUleb128(0), this.raw_txn.serialize(e), e.serializeVector(this.secondary_signer_addresses);
    }
    static load(e) {
        let t = me.deserialize(e), n = e.deserializeVector(u);
        return new r(t, n);
    }
}, Tt = exports.FeePayerRawTransaction = class r extends en {
    constructor(e, t, n){
        super(), this.raw_txn = e, this.secondary_signer_addresses = t, this.fee_payer_address = n;
    }
    serialize(e) {
        e.serializeU32AsUleb128(1), this.raw_txn.serialize(e), e.serializeVector(this.secondary_signer_addresses), this.fee_payer_address.serialize(e);
    }
    static load(e) {
        let t = me.deserialize(e), n = e.deserializeVector(u), i = u.deserialize(e);
        return new r(t, n, i);
    }
};
var tn = class extends l {
    constructor(t){
        super();
        this.accountAddress = u.ONE;
        this.moduleName = new S("account");
        this.structName = new S("RotationProofChallenge");
        this.sequenceNumber = new $(t.sequenceNumber), this.originator = t.originator, this.currentAuthKey = t.currentAuthKey, this.newPublicKey = b.U8(t.newPublicKey.toUint8Array());
    }
    serialize(t) {
        t.serialize(this.accountAddress), t.serialize(this.moduleName), t.serialize(this.structName), t.serialize(this.sequenceNumber), t.serialize(this.originator), t.serialize(this.currentAuthKey), t.serialize(this.newPublicKey);
    }
};
var Ve = class extends l {
    static deserialize(e) {
        let t = e.deserializeUleb128AsU32();
        switch(t){
            case 0:
                return bt.load(e);
            case 1:
                return rn.load(e);
            case 2:
                return wt.load(e);
            case 3:
                return _t.load(e);
            case 4:
                return Ze.load(e);
            default:
                throw new Error(`Unknown variant index for TransactionAuthenticator: ${t}`);
        }
    }
    isEd25519() {
        return this instanceof bt;
    }
    isMultiEd25519() {
        return this instanceof rn;
    }
    isMultiAgent() {
        return this instanceof wt;
    }
    isFeePayer() {
        return this instanceof _t;
    }
    isSingleSender() {
        return this instanceof Ze;
    }
}, bt = exports.TransactionAuthenticatorEd25519 = class r extends Ve {
    constructor(e, t){
        super(), this.public_key = e, this.signature = t;
    }
    serialize(e) {
        e.serializeU32AsUleb128(0), this.public_key.serialize(e), this.signature.serialize(e);
    }
    static load(e) {
        let t = P.deserialize(e), n = I.deserialize(e);
        return new r(t, n);
    }
}, rn = exports.TransactionAuthenticatorMultiEd25519 = class r extends Ve {
    constructor(e, t){
        super(), this.public_key = e, this.signature = t;
    }
    serialize(e) {
        e.serializeU32AsUleb128(1), this.public_key.serialize(e), this.signature.serialize(e);
    }
    static load(e) {
        let t = Pt.deserialize(e), n = ut.deserialize(e);
        return new r(t, n);
    }
}, wt = exports.TransactionAuthenticatorMultiAgent = class r extends Ve {
    constructor(e, t, n){
        super(), this.sender = e, this.secondary_signer_addresses = t, this.secondary_signers = n;
    }
    serialize(e) {
        e.serializeU32AsUleb128(2), this.sender.serialize(e), e.serializeVector(this.secondary_signer_addresses), e.serializeVector(this.secondary_signers);
    }
    static load(e) {
        let t = X.deserialize(e), n = e.deserializeVector(u), i = e.deserializeVector(X);
        return new r(t, n, i);
    }
}, _t = exports.TransactionAuthenticatorFeePayer = class r extends Ve {
    constructor(e, t, n, i){
        super(), this.sender = e, this.secondary_signer_addresses = t, this.secondary_signers = n, this.fee_payer = i;
    }
    serialize(e) {
        e.serializeU32AsUleb128(3), this.sender.serialize(e), e.serializeVector(this.secondary_signer_addresses), e.serializeVector(this.secondary_signers), this.fee_payer.address.serialize(e), this.fee_payer.authenticator.serialize(e);
    }
    static load(e) {
        let t = X.deserialize(e), n = e.deserializeVector(u), i = e.deserializeVector(X), o = u.deserialize(e), s = X.deserialize(e), a = {
            address: o,
            authenticator: s
        };
        return new r(t, n, i, a);
    }
}, Ze = exports.TransactionAuthenticatorSingleSender = class r extends Ve {
    constructor(e){
        super(), this.sender = e;
    }
    serialize(e) {
        e.serializeU32AsUleb128(4), this.sender.serialize(e);
    }
    static load(e) {
        let t = X.deserialize(e);
        return new r(t);
    }
};
var Le = class r extends l {
    constructor(e, t){
        super(), this.raw_txn = e, this.authenticator = t;
    }
    serialize(e) {
        this.raw_txn.serialize(e), this.authenticator.serialize(e);
    }
    static deserialize(e) {
        let t = me.deserialize(e), n = Ve.deserialize(e);
        return new r(t, n);
    }
};
var nn = class r extends l {
    constructor(e, t){
        super(), this.rawTransaction = e, this.feePayerAddress = t;
    }
    serialize(e) {
        this.rawTransaction.serialize(e), this.feePayerAddress === void 0 ? e.serializeBool(!1) : (e.serializeBool(!0), this.feePayerAddress.serialize(e));
    }
    static deserialize(e) {
        let t = me.deserialize(e), n = e.deserializeBool(), i;
        return n && (i = u.deserialize(e)), new r(t, i);
    }
};
var on = class r extends l {
    constructor(e, t, n){
        super(), this.rawTransaction = e, this.feePayerAddress = n, this.secondarySignerAddresses = t;
    }
    serialize(e) {
        this.rawTransaction.serialize(e), e.serializeVector(this.secondarySignerAddresses), this.feePayerAddress === void 0 ? e.serializeBool(!1) : (e.serializeBool(!0), this.feePayerAddress.serialize(e));
    }
    static deserialize(e) {
        let t = me.deserialize(e), n = e.deserializeVector(u), i = e.deserializeBool(), o;
        return i && (o = u.deserialize(e)), new r(t, n, o);
    }
};
function ti(r) {
    return r.feePayerAddress ? new Tt(r.rawTransaction, _nullishCoalesce(r.secondarySignerAddresses, ()=>[]), r.feePayerAddress) : r.secondarySignerAddresses ? new ht(r.rawTransaction, r.secondarySignerAddresses) : r.rawTransaction;
}
function zt(r, e) {
    let t = _sha3.sha3_256.create();
    if (!e.startsWith("APTOS::")) throw new Error(`Domain separator needs to start with 'APTOS::'.  Provided - ${e}`);
    t.update(e);
    let n = t.digest(), i = r, o = new Uint8Array(n.length + i.length);
    return o.set(n), o.set(i, n.length), o;
}
function hf(r) {
    return zt(r.bcsToBytes(), `APTOS::${r.constructor.name}`);
}
function Nt(r) {
    let e = ti(r);
    return r.feePayerAddress ? zt(e.bcsToBytes(), Qn) : r.secondarySignerAddresses ? zt(e.bcsToBytes(), Qn) : zt(e.bcsToBytes(), so);
}
var Ft = class r {
    constructor(e){
        this.signingScheme = 0;
        let { privateKey: t, address: n } = e;
        this.privateKey = t, this.publicKey = t.publicKey(), this.accountAddress = n ? u.from(n) : this.publicKey.authKey().derivedAddress();
    }
    static generate() {
        let e = Z.generate();
        return new r({
            privateKey: e
        });
    }
    static fromDerivationPath(e) {
        let { path: t, mnemonic: n } = e, i = Z.fromDerivationPath(t, n);
        return new r({
            privateKey: i
        });
    }
    verifySignature(e) {
        return this.publicKey.verifySignature(e);
    }
    signWithAuthenticator(e) {
        return new Se(this.publicKey, this.privateKey.sign(e));
    }
    signTransactionWithAuthenticator(e) {
        return new Se(this.publicKey, this.signTransaction(e));
    }
    sign(e) {
        return this.privateKey.sign(e);
    }
    signTransaction(e) {
        return this.sign(Nt(e));
    }
};
var Gt = class r {
    constructor(e){
        this.signingScheme = 2;
        let { privateKey: t, address: n } = e;
        this.privateKey = t, this.publicKey = new F(t.publicKey()), this.accountAddress = n ? u.from(n) : this.publicKey.authKey().derivedAddress();
    }
    static generate(e = {}) {
        let { scheme: t = 0 } = e, n;
        switch(t){
            case 0:
                n = Z.generate();
                break;
            case 2:
                n = pt.generate();
                break;
            default:
                throw new Error(`Unsupported signature scheme ${t}`);
        }
        return new r({
            privateKey: n
        });
    }
    static fromDerivationPath(e) {
        let { scheme: t = 0, path: n, mnemonic: i } = e, o;
        switch(t){
            case 0:
                o = Z.fromDerivationPath(n, i);
                break;
            case 2:
                o = pt.fromDerivationPath(n, i);
                break;
            default:
                throw new Error(`Unsupported signature scheme ${t}`);
        }
        return new r({
            privateKey: o
        });
    }
    verifySignature(e) {
        return this.publicKey.verifySignature(e);
    }
    signWithAuthenticator(e) {
        return new ie(this.publicKey, this.sign(e));
    }
    signTransactionWithAuthenticator(e) {
        return new ie(this.publicKey, this.signTransaction(e));
    }
    sign(e) {
        return new L(this.privateKey.sign(e));
    }
    signTransaction(e) {
        return this.sign(Nt(e));
    }
};
var et = class {
    static generate(e = {}) {
        let { scheme: t = 0, legacy: n = !0 } = e;
        return t === 0 && n ? Ft.generate() : Gt.generate({
            scheme: t
        });
    }
    static fromPrivateKey(e) {
        let { privateKey: t, address: n, legacy: i = !0 } = e;
        return t instanceof Z && i ? new Ft({
            privateKey: t,
            address: n
        }) : new Gt({
            privateKey: t,
            address: n
        });
    }
    static fromPrivateKeyAndAddress(e) {
        return this.fromPrivateKey(e);
    }
    static fromDerivationPath(e) {
        let { scheme: t = 0, mnemonic: n, path: i, legacy: o = !0 } = e;
        return t === 0 && o ? Ft.fromDerivationPath({
            mnemonic: n,
            path: i
        }) : Gt.fromDerivationPath({
            scheme: t,
            mnemonic: n,
            path: i
        });
    }
    static authKey(e) {
        let { publicKey: t } = e;
        return t.authKey();
    }
    verifySignature(e) {
        return this.publicKey.verifySignature(e);
    }
};
var Cc = 1209600, Bt = class Bt extends l {
    constructor(e){
        super();
        let { privateKey: t, expiryDateSecs: n, blinder: i } = e;
        this.privateKey = t, this.publicKey = new lt(t.publicKey()), this.expiryDateSecs = n || _chunkF43XVDYJjs.e.call(void 0, _chunkF43XVDYJjs.d.call(void 0) + Cc), this.blinder = i !== void 0 ? g.fromHexInput(i).toUint8Array() : Rc();
        let o = Ln(this.publicKey.bcsToBytes(), 93);
        o.push(BigInt(this.expiryDateSecs)), o.push(ir(this.blinder));
        let s = or(o);
        this.nonce = s.toString();
    }
    getPublicKey() {
        return this.publicKey;
    }
    isExpired() {
        return Math.floor(Date.now() / 1e3) > this.expiryDateSecs;
    }
    serialize(e) {
        e.serializeU32AsUleb128(this.publicKey.variant), e.serializeBytes(this.privateKey.toUint8Array()), e.serializeU64(this.expiryDateSecs), e.serializeFixedBytes(this.blinder);
    }
    static deserialize(e) {
        let t = e.deserializeUleb128AsU32(), n;
        switch(t){
            case 0:
                n = Z.deserialize(e);
                break;
            default:
                throw new Error(`Unknown variant index for EphemeralPublicKey: ${t}`);
        }
        let i = e.deserializeU64(), o = e.deserializeFixedBytes(31);
        return new Bt({
            privateKey: n,
            expiryDateSecs: Number(i),
            blinder: o
        });
    }
    static fromBytes(e) {
        return Bt.deserialize(new N(e));
    }
    static generate(e) {
        let t;
        switch(_optionalChain([
            e,
            'optionalAccess',
            (_54)=>_54.scheme
        ])){
            case 0:
            default:
                t = Z.generate();
        }
        return new Bt({
            privateKey: t,
            expiryDateSecs: _optionalChain([
                e,
                'optionalAccess',
                (_55)=>_55.expiryDateSecs
            ])
        });
    }
    sign(e) {
        if (this.isExpired()) throw new Error("EphemeralKeyPair has expired");
        return new Ee(this.privateKey.sign(e));
    }
};
Bt.BLINDER_LENGTH = 31;
var mr = Bt;
function Rc() {
    return _utils.randomBytes.call(void 0, mr.BLINDER_LENGTH);
}
var _eventemitter3 = __turbopack_require__("[project]/node_modules/.pnpm/eventemitter3@5.0.1/node_modules/eventemitter3/index.js [app-route] (ecmascript)");
var _eventemitter32 = _interopRequireDefault(_eventemitter3);
function sn(r) {
    return r != null && typeof r.checkKeylessAccountValidity == "function";
}
var Mt = class Mt extends l {
    constructor(e){
        super();
        let { address: t, ephemeralKeyPair: n, publicKey: i, uidKey: o, uidVal: s, aud: a, pepper: c, proof: p, proofFetchCallback: d, jwt: A, verificationKeyHash: w } = e;
        if (this.ephemeralKeyPair = n, this.publicKey = i, this.accountAddress = t ? u.from(t) : this.publicKey.authKey().derivedAddress(), this.uidKey = o, this.uidVal = s, this.aud = a, this.jwt = A, this.emitter = new _eventemitter32.default, this.proofOrPromise = p, p instanceof ze) this.proof = p;
        else {
            if (d === void 0) throw new Error("Must provide callback for async proof fetch");
            this.emitter.on("proofFetchFinish", async (x)=>{
                await d(x), this.emitter.removeAllListeners();
            }), this.init(p);
        }
        this.signingScheme = 2;
        let y = g.fromHexInput(c).toUint8Array();
        if (y.length !== Mt.PEPPER_LENGTH) throw new Error(`Pepper length in bytes should be ${Mt.PEPPER_LENGTH}`);
        if (this.pepper = y, w !== void 0) {
            if (g.hexInputToUint8Array(w).length !== 32) throw new Error("verificationKeyHash must be 32 bytes");
            this.verificationKeyHash = g.hexInputToUint8Array(w);
        }
    }
    async init(e) {
        try {
            this.proof = await e, this.emitter.emit("proofFetchFinish", {
                status: "Success"
            });
        } catch (t) {
            t instanceof Error ? this.emitter.emit("proofFetchFinish", {
                status: "Failed",
                error: t.toString()
            }) : this.emitter.emit("proofFetchFinish", {
                status: "Failed",
                error: "Unknown"
            });
        }
    }
    serialize(e) {
        if (this.accountAddress.serialize(e), e.serializeStr(this.jwt), e.serializeStr(this.uidKey), e.serializeFixedBytes(this.pepper), this.ephemeralKeyPair.serialize(e), this.proof === void 0) throw new Error("Cannot serialize - proof undefined");
        this.proof.serialize(e), e.serializeOption(this.verificationKeyHash, 32);
    }
    static partialDeserialize(e) {
        let t = u.deserialize(e), n = e.deserializeStr(), i = e.deserializeStr(), o = e.deserializeFixedBytes(31), s = mr.deserialize(e), a = ze.deserialize(e), c = e.deserializeOption("fixedBytes", 32);
        return {
            address: t,
            jwt: n,
            uidKey: i,
            pepper: o,
            ephemeralKeyPair: s,
            proof: a,
            verificationKeyHash: c
        };
    }
    isExpired() {
        return this.ephemeralKeyPair.isExpired();
    }
    signWithAuthenticator(e) {
        let t = new L(this.sign(e)), n = new F(this.publicKey);
        return new ie(n, t);
    }
    signTransactionWithAuthenticator(e) {
        let t = new L(this.signTransaction(e)), n = new F(this.publicKey);
        return new ie(n, t);
    }
    async waitForProofFetch() {
        this.proofOrPromise instanceof Promise && await this.proofOrPromise;
    }
    async checkKeylessAccountValidity(e) {
        if (this.isExpired()) throw K.fromErrorType({
            type: 0
        });
        if (await this.waitForProofFetch(), this.proof === void 0) throw K.fromErrorType({
            type: 2
        });
        let t = _jwtdecode.jwtDecode.call(void 0, this.jwt, {
            header: !0
        });
        if (t.kid === void 0) throw K.fromErrorType({
            type: 12,
            details: "checkKeylessAccountValidity failed. JWT is missing 'kid' in header. This should never happen."
        });
        if (this.verificationKeyHash !== void 0) {
            let { verificationKey: n } = await ar({
                aptosConfig: e
            });
            if (g.hexInputToString(n.hash()) !== g.hexInputToString(this.verificationKeyHash)) throw K.fromErrorType({
                type: 4
            });
        } else console.warn("[Aptos SDK] The verification key hash was not set. Proof may be invalid if the verification key has rotated.");
        await Mt.fetchJWK({
            aptosConfig: e,
            publicKey: this.publicKey,
            kid: t.kid
        });
    }
    sign(e) {
        let { expiryDateSecs: t } = this.ephemeralKeyPair;
        if (this.isExpired()) throw K.fromErrorType({
            type: 0
        });
        if (this.proof === void 0) throw K.fromErrorType({
            type: 1,
            details: "Proof not found - make sure to call `await account.checkKeylessAccountValidity()` before signing."
        });
        let n = this.ephemeralKeyPair.getPublicKey(), i = this.ephemeralKeyPair.sign(e);
        return new De({
            jwtHeader: _chunkF43XVDYJjs.f.call(void 0, this.jwt.split(".")[0]),
            ephemeralCertificate: new Rt(this.proof, 0),
            expiryDateSecs: t,
            ephemeralPublicKey: n,
            ephemeralSignature: i
        });
    }
    signTransaction(e) {
        if (this.proof === void 0) throw K.fromErrorType({
            type: 1,
            details: "Proof not found - make sure to call `await account.checkKeylessAccountValidity()` before signing."
        });
        let t = ti(e), i = new ri(t, this.proof.proof).hash();
        return this.sign(i);
    }
    verifySignature(e) {
        let { message: t, signature: n } = e;
        return !(this.isExpired() || !this.ephemeralKeyPair.getPublicKey().verifySignature({
            message: t,
            signature: n.ephemeralSignature
        }));
    }
    static async fetchJWK(e) {
        let { aptosConfig: t, publicKey: n, kid: i } = e, o = n instanceof O ? n : n.keylessPublicKey, { iss: s } = o, a, c = n instanceof ee ? n.jwkAddress : void 0;
        try {
            a = await Ao({
                aptosConfig: t,
                jwkAddr: c
            });
        } catch (A) {
            throw K.fromErrorType({
                type: 24,
                error: A,
                details: `Failed to fetch ${c ? "Federated" : "Patched"}JWKs ${c ? `for address ${c}` : "0x1"}`
            });
        }
        let p = a.get(s);
        if (p === void 0) throw K.fromErrorType({
            type: 7,
            details: `JWKs for issuer ${s} not found.`
        });
        let d = p.find((A)=>A.kid === i);
        if (d === void 0) throw K.fromErrorType({
            type: 6,
            details: `JWK with kid '${i}' for issuer '${s}' not found.`
        });
        return d;
    }
};
Mt.PEPPER_LENGTH = 31;
var ue = Mt, ri = exports.TransactionAndProof = class extends l {
    constructor(t, n){
        super();
        this.domainSeparator = "APTOS::TransactionAndProof";
        this.transaction = t, this.proof = n;
    }
    serialize(t) {
        t.serializeFixedBytes(this.transaction.bcsToBytes()), t.serializeOption(this.proof);
    }
    hash() {
        return zt(this.bcsToBytes(), this.domainSeparator);
    }
};
var Vt = class r extends ue {
    constructor(e){
        let t = O.create(e);
        super({
            publicKey: t,
            ...e
        }), this.publicKey = t;
    }
    serialize(e) {
        super.serialize(e);
    }
    static deserialize(e) {
        let { address: t, proof: n, ephemeralKeyPair: i, jwt: o, uidKey: s, pepper: a, verificationKeyHash: c } = ue.partialDeserialize(e), { iss: p, aud: d, uidVal: A } = kt({
            jwt: o,
            uidKey: s
        });
        return new r({
            address: t,
            proof: n,
            ephemeralKeyPair: i,
            iss: p,
            uidKey: s,
            uidVal: A,
            aud: d,
            pepper: a,
            jwt: o,
            verificationKeyHash: c
        });
    }
    static fromBytes(e) {
        return r.deserialize(new N(g.hexInputToUint8Array(e)));
    }
    static create(e) {
        let { address: t, proof: n, jwt: i, ephemeralKeyPair: o, pepper: s, uidKey: a = "sub", proofFetchCallback: c, verificationKey: p } = e, { iss: d, aud: A, uidVal: w } = kt({
            jwt: i,
            uidKey: a
        });
        return new r({
            address: t,
            proof: n,
            ephemeralKeyPair: o,
            iss: d,
            uidKey: a,
            uidVal: w,
            aud: A,
            pepper: s,
            jwt: i,
            proofFetchCallback: c,
            verificationKeyHash: p ? p.hash() : void 0
        });
    }
};
var an = class r extends ue {
    constructor(e){
        let t = ee.create(e);
        super({
            publicKey: t,
            ...e
        }), this.publicKey = t;
    }
    serialize(e) {
        super.serialize(e), this.publicKey.jwkAddress.serialize(e);
    }
    static deserialize(e) {
        let { address: t, proof: n, ephemeralKeyPair: i, jwt: o, uidKey: s, pepper: a, verificationKeyHash: c } = ue.partialDeserialize(e), p = u.deserialize(e), { iss: d, aud: A, uidVal: w } = kt({
            jwt: o,
            uidKey: s
        });
        return new r({
            address: t,
            proof: n,
            ephemeralKeyPair: i,
            iss: d,
            uidKey: s,
            uidVal: w,
            aud: A,
            pepper: a,
            jwt: o,
            verificationKeyHash: c,
            jwkAddress: p
        });
    }
    static fromBytes(e) {
        return r.deserialize(new N(g.hexInputToUint8Array(e)));
    }
    static create(e) {
        let { address: t, proof: n, jwt: i, ephemeralKeyPair: o, pepper: s, jwkAddress: a, uidKey: c = "sub", proofFetchCallback: p, verificationKey: d } = e, { iss: A, aud: w, uidVal: y } = kt({
            jwt: i,
            uidKey: c
        });
        return new r({
            address: t,
            proof: n,
            ephemeralKeyPair: o,
            iss: A,
            uidKey: c,
            uidVal: y,
            aud: w,
            pepper: s,
            jwkAddress: u.from(a),
            jwt: i,
            proofFetchCallback: p,
            verificationKeyHash: d ? d.hash() : void 0
        });
    }
};
var To = class r {
    constructor(e){
        let { multiKey: t, signers: n, address: i } = e;
        this.publicKey = t, this.signingScheme = 3, this.accountAddress = i ? u.from(i) : this.publicKey.authKey().derivedAddress();
        let o = [];
        for (let a of n)o.push(this.publicKey.getIndex(a.publicKey));
        let s = n.map((a, c)=>[
                a,
                o[c]
            ]);
        s.sort((a, c)=>a[1] - c[1]), this.signers = s.map((a)=>a[0]), this.signerIndicies = s.map((a)=>a[1]), this.signaturesBitmap = this.publicKey.createBitmap({
            bits: o
        });
    }
    static fromPublicKeysAndSigners(e) {
        let { publicKeys: t, signaturesRequired: n, signers: i } = e, o = new Ye({
            publicKeys: t,
            signaturesRequired: n
        });
        return new r({
            multiKey: o,
            signers: i
        });
    }
    static isMultiKeySigner(e) {
        return e instanceof r;
    }
    signWithAuthenticator(e) {
        return new Ie(this.publicKey, this.sign(e));
    }
    signTransactionWithAuthenticator(e) {
        return new Ie(this.publicKey, this.signTransaction(e));
    }
    async waitForProofFetch() {
        let t = this.signers.filter((n)=>n instanceof ue).map(async (n)=>n.waitForProofFetch());
        await Promise.all(t);
    }
    async checkKeylessAccountValidity(e) {
        let n = this.signers.filter((i)=>i instanceof ue).map((i)=>i.checkKeylessAccountValidity(e));
        await Promise.all(n);
    }
    sign(e) {
        let t = [];
        for (let n of this.signers)t.push(n.sign(e));
        return new Ne({
            signatures: t,
            bitmap: this.signaturesBitmap
        });
    }
    signTransaction(e) {
        let t = [];
        for (let n of this.signers)t.push(n.signTransaction(e));
        return new Ne({
            signatures: t,
            bitmap: this.signaturesBitmap
        });
    }
    verifySignature(e) {
        let { message: t, signature: n } = e;
        if (!this.signerIndicies.every((o, s)=>s === 0 || o >= this.signerIndicies[s - 1])) return !1;
        for(let o = 0; o < n.signatures.length; o += 1){
            let s = n.signatures[o];
            if (!this.publicKey.publicKeys[this.signerIndicies[o]].verifySignature({
                message: t,
                signature: s
            })) return !1;
        }
        return !0;
    }
};
var kc = `
    fragment TokenActivitiesFields on token_activities_v2 {
  after_value
  before_value
  entry_function_id_str
  event_account_address
  event_index
  from_address
  is_fungible_v2
  property_version_v1
  to_address
  token_amount
  token_data_id
  token_standard
  transaction_timestamp
  transaction_version
  type
}
    `, Oc = `
    fragment AnsTokenFragment on current_aptos_names {
  domain
  expiration_timestamp
  registered_address
  subdomain
  token_standard
  is_primary
  owner_address
  subdomain_expiration_policy
  domain_expiration_timestamp
}
    `, cn = `
    fragment CurrentTokenOwnershipFields on current_token_ownerships_v2 {
  token_standard
  token_properties_mutated_v1
  token_data_id
  table_type_v1
  storage_id
  property_version_v1
  owner_address
  last_transaction_version
  last_transaction_timestamp
  is_soulbound_v2
  is_fungible_v2
  amount
  current_token_data {
    collection_id
    description
    is_fungible_v2
    largest_property_version_v1
    last_transaction_timestamp
    last_transaction_version
    maximum
    supply
    token_data_id
    token_name
    token_properties
    token_standard
    token_uri
    decimals
    current_collection {
      collection_id
      collection_name
      creator_address
      current_supply
      description
      last_transaction_timestamp
      last_transaction_version
      max_supply
      mutable_description
      mutable_uri
      table_handle_v1
      token_standard
      total_minted_v2
      uri
    }
  }
}
    `, bo = `
    query getAccountCoinsCount($address: String) {
  current_fungible_asset_balances_aggregate(
    where: {owner_address: {_eq: $address}}
  ) {
    aggregate {
      count
    }
  }
}
    `, wo = `
    query getAccountCoinsData($where_condition: current_fungible_asset_balances_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_fungible_asset_balances_order_by!]) {
  current_fungible_asset_balances(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    amount
    asset_type
    is_frozen
    is_primary
    last_transaction_timestamp
    last_transaction_version
    owner_address
    storage_id
    token_standard
    metadata {
      token_standard
      symbol
      supply_aggregator_table_key_v1
      supply_aggregator_table_handle_v1
      project_uri
      name
      last_transaction_version
      last_transaction_timestamp
      icon_uri
      decimals
      creator_address
      asset_type
    }
  }
}
    `, _o = `
    query getAccountCollectionsWithOwnedTokens($where_condition: current_collection_ownership_v2_view_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_collection_ownership_v2_view_order_by!]) {
  current_collection_ownership_v2_view(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    current_collection {
      collection_id
      collection_name
      creator_address
      current_supply
      description
      last_transaction_timestamp
      last_transaction_version
      mutable_description
      max_supply
      mutable_uri
      table_handle_v1
      token_standard
      total_minted_v2
      uri
    }
    collection_id
    collection_name
    collection_uri
    creator_address
    distinct_tokens
    last_transaction_version
    owner_address
    single_token_uri
  }
}
    `, So = `
    query getAccountOwnedTokens($where_condition: current_token_ownerships_v2_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_token_ownerships_v2_order_by!]) {
  current_token_ownerships_v2(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    ...CurrentTokenOwnershipFields
  }
}
    ${cn}`, ph = `
    query getAccountOwnedTokensByTokenData($where_condition: current_token_ownerships_v2_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_token_ownerships_v2_order_by!]) {
  current_token_ownerships_v2(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    ...CurrentTokenOwnershipFields
  }
}
    ${cn}`, xo = `
    query getAccountOwnedTokensFromCollection($where_condition: current_token_ownerships_v2_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_token_ownerships_v2_order_by!]) {
  current_token_ownerships_v2(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    ...CurrentTokenOwnershipFields
  }
}
    ${cn}`, Eo = `
    query getAccountTokensCount($where_condition: current_token_ownerships_v2_bool_exp, $offset: Int, $limit: Int) {
  current_token_ownerships_v2_aggregate(
    where: $where_condition
    offset: $offset
    limit: $limit
  ) {
    aggregate {
      count
    }
  }
}
    `, Po = `
    query getAccountTransactionsCount($address: String) {
  account_transactions_aggregate(where: {account_address: {_eq: $address}}) {
    aggregate {
      count
    }
  }
}
    `, vo = `
    query getChainTopUserTransactions($limit: Int) {
  user_transactions(limit: $limit, order_by: {version: desc}) {
    version
  }
}
    `, Io = `
    query getCollectionData($where_condition: current_collections_v2_bool_exp!) {
  current_collections_v2(where: $where_condition) {
    uri
    total_minted_v2
    token_standard
    table_handle_v1
    mutable_uri
    mutable_description
    max_supply
    collection_id
    collection_name
    creator_address
    current_supply
    description
    last_transaction_timestamp
    last_transaction_version
    cdn_asset_uris {
      cdn_image_uri
      asset_uri
      animation_optimizer_retry_count
      cdn_animation_uri
      cdn_json_uri
      image_optimizer_retry_count
      json_parser_retry_count
      raw_animation_uri
      raw_image_uri
    }
  }
}
    `, Co = `
    query getCurrentFungibleAssetBalances($where_condition: current_fungible_asset_balances_bool_exp, $offset: Int, $limit: Int) {
  current_fungible_asset_balances(
    where: $where_condition
    offset: $offset
    limit: $limit
  ) {
    amount
    asset_type
    is_frozen
    is_primary
    last_transaction_timestamp
    last_transaction_version
    owner_address
    storage_id
    token_standard
  }
}
    `, Ro = `
    query getDelegatedStakingActivities($delegatorAddress: String, $poolAddress: String) {
  delegated_staking_activities(
    where: {delegator_address: {_eq: $delegatorAddress}, pool_address: {_eq: $poolAddress}}
  ) {
    amount
    delegator_address
    event_index
    event_type
    pool_address
    transaction_version
  }
}
    `, Uo = `
    query getEvents($where_condition: events_bool_exp, $offset: Int, $limit: Int, $order_by: [events_order_by!]) {
  events(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    account_address
    creation_number
    data
    event_index
    sequence_number
    transaction_block_height
    transaction_version
    type
    indexed_type
  }
}
    `, Ko = `
    query getFungibleAssetActivities($where_condition: fungible_asset_activities_bool_exp, $offset: Int, $limit: Int) {
  fungible_asset_activities(
    where: $where_condition
    offset: $offset
    limit: $limit
  ) {
    amount
    asset_type
    block_height
    entry_function_id_str
    event_index
    gas_fee_payer_address
    is_frozen
    is_gas_fee
    is_transaction_success
    owner_address
    storage_id
    storage_refund_amount
    token_standard
    transaction_timestamp
    transaction_version
    type
  }
}
    `, ko = `
    query getFungibleAssetMetadata($where_condition: fungible_asset_metadata_bool_exp, $offset: Int, $limit: Int) {
  fungible_asset_metadata(where: $where_condition, offset: $offset, limit: $limit) {
    icon_uri
    project_uri
    supply_aggregator_table_handle_v1
    supply_aggregator_table_key_v1
    creator_address
    asset_type
    decimals
    last_transaction_timestamp
    last_transaction_version
    name
    symbol
    token_standard
    supply_v2
    maximum_v2
  }
}
    `, Lt = `
    query getNames($offset: Int, $limit: Int, $where_condition: current_aptos_names_bool_exp, $order_by: [current_aptos_names_order_by!]) {
  current_aptos_names(
    limit: $limit
    where: $where_condition
    order_by: $order_by
    offset: $offset
  ) {
    ...AnsTokenFragment
  }
}
    ${Oc}`, ni = `
    query getNumberOfDelegators($where_condition: num_active_delegator_per_pool_bool_exp, $order_by: [num_active_delegator_per_pool_order_by!]) {
  num_active_delegator_per_pool(where: $where_condition, order_by: $order_by) {
    num_active_delegator
    pool_address
  }
}
    `, un = `
    query getObjectData($where_condition: current_objects_bool_exp, $offset: Int, $limit: Int, $order_by: [current_objects_order_by!]) {
  current_objects(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    allow_ungated_transfer
    state_key_hash
    owner_address
    object_address
    last_transaction_version
    last_guid_creation_num
    is_deleted
  }
}
    `, ii = `
    query getProcessorStatus($where_condition: processor_status_bool_exp) {
  processor_status(where: $where_condition) {
    last_success_version
    processor
    last_updated
  }
}
    `, Oo = `
    query getTableItemsData($where_condition: table_items_bool_exp!, $offset: Int, $limit: Int, $order_by: [table_items_order_by!]) {
  table_items(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    decoded_key
    decoded_value
    key
    table_handle
    transaction_version
    write_set_change_index
  }
}
    `, Do = `
    query getTableItemsMetadata($where_condition: table_metadatas_bool_exp!, $offset: Int, $limit: Int, $order_by: [table_metadatas_order_by!]) {
  table_metadatas(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    handle
    key_type
    value_type
  }
}
    `, zo = `
    query getTokenActivity($where_condition: token_activities_v2_bool_exp!, $offset: Int, $limit: Int, $order_by: [token_activities_v2_order_by!]) {
  token_activities_v2(
    where: $where_condition
    order_by: $order_by
    offset: $offset
    limit: $limit
  ) {
    ...TokenActivitiesFields
  }
}
    ${kc}`, oi = `
    query getCurrentTokenOwnership($where_condition: current_token_ownerships_v2_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_token_ownerships_v2_order_by!]) {
  current_token_ownerships_v2(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    ...CurrentTokenOwnershipFields
  }
}
    ${cn}`, No = `
    query getTokenData($where_condition: current_token_datas_v2_bool_exp, $offset: Int, $limit: Int, $order_by: [current_token_datas_v2_order_by!]) {
  current_token_datas_v2(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    collection_id
    description
    is_fungible_v2
    largest_property_version_v1
    last_transaction_timestamp
    last_transaction_version
    maximum
    supply
    token_data_id
    token_name
    token_properties
    token_standard
    token_uri
    decimals
    current_collection {
      collection_id
      collection_name
      creator_address
      current_supply
      description
      last_transaction_timestamp
      last_transaction_version
      max_supply
      mutable_description
      mutable_uri
      table_handle_v1
      token_standard
      total_minted_v2
      uri
    }
  }
}
    `;
async function pn(r) {
    let { aptosConfig: e } = r, { data: t } = await V({
        aptosConfig: e,
        originMethod: "getLedgerInfo",
        path: ""
    });
    return t;
}
async function Fo(r) {
    let { aptosConfig: e, limit: t } = r;
    return (await h({
        aptosConfig: e,
        query: {
            query: vo,
            variables: {
                limit: t
            }
        },
        originMethod: "getChainTopUserTransactions"
    })).user_transactions;
}
async function h(r) {
    let { aptosConfig: e, query: t, originMethod: n } = r, { data: i } = await po({
        aptosConfig: e,
        originMethod: _nullishCoalesce(n, ()=>"queryIndexer"),
        path: "",
        body: t,
        overrides: {
            WITH_CREDENTIALS: !1
        }
    });
    return i;
}
async function Dc(r) {
    let { aptosConfig: e } = r;
    return (await h({
        aptosConfig: e,
        query: {
            query: ii
        },
        originMethod: "getProcessorStatuses"
    })).processor_status;
}
async function dn(r) {
    let e = await Dc({
        aptosConfig: r.aptosConfig
    });
    return BigInt(e[0].last_success_version);
}
async function ln(r) {
    let { aptosConfig: e, processorType: t } = r;
    return (await h({
        aptosConfig: e,
        query: {
            query: ii,
            variables: {
                where_condition: {
                    processor: {
                        _eq: t
                    }
                }
            }
        },
        originMethod: "getProcessorStatus"
    })).processor_status[0];
}
async function gn(r) {
    let { aptosConfig: e, handle: t, data: n, options: i } = r;
    return (await Xe({
        aptosConfig: e,
        originMethod: "getTableItem",
        path: `tables/${t}/item`,
        params: {
            ledger_version: _optionalChain([
                i,
                'optionalAccess',
                (_56)=>_56.ledgerVersion
            ])
        },
        body: n
    })).data;
}
async function Go(r) {
    let { aptosConfig: e, options: t } = r, n = {
        query: Oo,
        variables: {
            where_condition: _optionalChain([
                t,
                'optionalAccess',
                (_57)=>_57.where
            ]),
            offset: _optionalChain([
                t,
                'optionalAccess',
                (_58)=>_58.offset
            ]),
            limit: _optionalChain([
                t,
                'optionalAccess',
                (_59)=>_59.limit
            ]),
            order_by: _optionalChain([
                t,
                'optionalAccess',
                (_60)=>_60.orderBy
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: n,
        originMethod: "getTableItemsData"
    })).table_items;
}
async function Bo(r) {
    let { aptosConfig: e, options: t } = r, n = {
        query: Do,
        variables: {
            where_condition: _optionalChain([
                t,
                'optionalAccess',
                (_61)=>_61.where
            ]),
            offset: _optionalChain([
                t,
                'optionalAccess',
                (_62)=>_62.offset
            ]),
            limit: _optionalChain([
                t,
                'optionalAccess',
                (_63)=>_63.limit
            ]),
            order_by: _optionalChain([
                t,
                'optionalAccess',
                (_64)=>_64.orderBy
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: n,
        originMethod: "getTableItemsMetadata"
    })).table_metadatas;
}
async function Re(r) {
    let { aptosConfig: e, accountAddress: t } = r, { data: n } = await V({
        aptosConfig: e,
        originMethod: "getInfo",
        path: `accounts/${u.from(t).toString()}`
    });
    return n;
}
async function Lo(r) {
    let { aptosConfig: e, accountAddress: t, options: n } = r;
    return Ct({
        aptosConfig: e,
        originMethod: "getModules",
        path: `accounts/${u.from(t).toString()}/modules`,
        params: {
            ledger_version: _optionalChain([
                n,
                'optionalAccess',
                (_65)=>_65.ledgerVersion
            ]),
            start: _optionalChain([
                n,
                'optionalAccess',
                (_66)=>_66.offset
            ]),
            limit: _nullishCoalesce(_optionalChain([
                n,
                'optionalAccess',
                (_67)=>_67.limit
            ]), ()=>1e3)
        }
    });
}
async function yn(r) {
    return _optionalChain([
        r,
        'access',
        (_68)=>_68.options,
        'optionalAccess',
        (_69)=>_69.ledgerVersion
    ]) !== void 0 ? Mo(r) : Pe(async ()=>Mo(r), `module-${r.accountAddress}-${r.moduleName}`, 1e3 * 60 * 5)();
}
async function Mo(r) {
    let { aptosConfig: e, accountAddress: t, moduleName: n, options: i } = r, { data: o } = await V({
        aptosConfig: e,
        originMethod: "getModule",
        path: `accounts/${u.from(t).toString()}/module/${n}`,
        params: {
            ledger_version: _optionalChain([
                i,
                'optionalAccess',
                (_70)=>_70.ledgerVersion
            ])
        }
    });
    return o;
}
async function Ho(r) {
    let { aptosConfig: e, accountAddress: t, options: n } = r;
    return Ct({
        aptosConfig: e,
        originMethod: "getTransactions",
        path: `accounts/${u.from(t).toString()}/transactions`,
        params: {
            start: _optionalChain([
                n,
                'optionalAccess',
                (_71)=>_71.offset
            ]),
            limit: _optionalChain([
                n,
                'optionalAccess',
                (_72)=>_72.limit
            ])
        }
    });
}
async function qo(r) {
    let { aptosConfig: e, accountAddress: t, options: n } = r;
    return Ct({
        aptosConfig: e,
        originMethod: "getResources",
        path: `accounts/${u.from(t).toString()}/resources`,
        params: {
            ledger_version: _optionalChain([
                n,
                'optionalAccess',
                (_73)=>_73.ledgerVersion
            ]),
            start: _optionalChain([
                n,
                'optionalAccess',
                (_74)=>_74.offset
            ]),
            limit: _nullishCoalesce(_optionalChain([
                n,
                'optionalAccess',
                (_75)=>_75.limit
            ]), ()=>999)
        }
    });
}
async function si(r) {
    let { aptosConfig: e, accountAddress: t, resourceType: n, options: i } = r, { data: o } = await V({
        aptosConfig: e,
        originMethod: "getResource",
        path: `accounts/${u.from(t).toString()}/resource/${n}`,
        params: {
            ledger_version: _optionalChain([
                i,
                'optionalAccess',
                (_76)=>_76.ledgerVersion
            ])
        }
    });
    return o.data;
}
async function Ht(r) {
    let { aptosConfig: e, authenticationKey: t, options: n } = r, i = await si({
        aptosConfig: e,
        accountAddress: "0x1",
        resourceType: "0x1::account::OriginatingAddress",
        options: n
    }), { address_map: { handle: o } } = i, s = u.from(t);
    try {
        let a = await gn({
            aptosConfig: e,
            handle: o,
            data: {
                key: s.toString(),
                key_type: "address",
                value_type: "address"
            },
            options: n
        });
        return u.from(a);
    } catch (a) {
        if (a instanceof ye && a.data.error_code === "table_item_not_found") return s;
        throw a;
    }
}
async function $o(r) {
    let { aptosConfig: e, accountAddress: t } = r, i = {
        owner_address: {
            _eq: u.from(t).toStringLong()
        },
        amount: {
            _gt: 0
        }
    }, s = await h({
        aptosConfig: e,
        query: {
            query: Eo,
            variables: {
                where_condition: i
            }
        },
        originMethod: "getAccountTokensCount"
    });
    return s.current_token_ownerships_v2_aggregate.aggregate ? s.current_token_ownerships_v2_aggregate.aggregate.count : 0;
}
async function Wo(r) {
    let { aptosConfig: e, accountAddress: t, options: n } = r, o = {
        owner_address: {
            _eq: u.from(t).toStringLong()
        },
        amount: {
            _gt: 0
        }
    };
    _optionalChain([
        n,
        'optionalAccess',
        (_77)=>_77.tokenStandard
    ]) && (o.token_standard = {
        _eq: _optionalChain([
            n,
            'optionalAccess',
            (_78)=>_78.tokenStandard
        ])
    });
    let s = {
        query: So,
        variables: {
            where_condition: o,
            offset: _optionalChain([
                n,
                'optionalAccess',
                (_79)=>_79.offset
            ]),
            limit: _optionalChain([
                n,
                'optionalAccess',
                (_80)=>_80.limit
            ]),
            order_by: _optionalChain([
                n,
                'optionalAccess',
                (_81)=>_81.orderBy
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: s,
        originMethod: "getAccountOwnedTokens"
    })).current_token_ownerships_v2;
}
async function Qo(r) {
    let { aptosConfig: e, accountAddress: t, collectionAddress: n, options: i } = r, o = u.from(t).toStringLong(), s = u.from(n).toStringLong(), a = {
        owner_address: {
            _eq: o
        },
        current_token_data: {
            collection_id: {
                _eq: s
            }
        },
        amount: {
            _gt: 0
        }
    };
    _optionalChain([
        i,
        'optionalAccess',
        (_82)=>_82.tokenStandard
    ]) && (a.token_standard = {
        _eq: _optionalChain([
            i,
            'optionalAccess',
            (_83)=>_83.tokenStandard
        ])
    });
    let c = {
        query: xo,
        variables: {
            where_condition: a,
            offset: _optionalChain([
                i,
                'optionalAccess',
                (_84)=>_84.offset
            ]),
            limit: _optionalChain([
                i,
                'optionalAccess',
                (_85)=>_85.limit
            ]),
            order_by: _optionalChain([
                i,
                'optionalAccess',
                (_86)=>_86.orderBy
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: c,
        originMethod: "getAccountOwnedTokensFromCollectionAddress"
    })).current_token_ownerships_v2;
}
async function jo(r) {
    let { aptosConfig: e, accountAddress: t, options: n } = r, o = {
        owner_address: {
            _eq: u.from(t).toStringLong()
        }
    };
    _optionalChain([
        n,
        'optionalAccess',
        (_87)=>_87.tokenStandard
    ]) && (o.current_collection = {
        token_standard: {
            _eq: _optionalChain([
                n,
                'optionalAccess',
                (_88)=>_88.tokenStandard
            ])
        }
    });
    let s = {
        query: _o,
        variables: {
            where_condition: o,
            offset: _optionalChain([
                n,
                'optionalAccess',
                (_89)=>_89.offset
            ]),
            limit: _optionalChain([
                n,
                'optionalAccess',
                (_90)=>_90.limit
            ]),
            order_by: _optionalChain([
                n,
                'optionalAccess',
                (_91)=>_91.orderBy
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: s,
        originMethod: "getAccountCollectionsWithOwnedTokens"
    })).current_collection_ownership_v2_view;
}
async function Jo(r) {
    let { aptosConfig: e, accountAddress: t } = r, n = u.from(t).toStringLong(), o = await h({
        aptosConfig: e,
        query: {
            query: Po,
            variables: {
                address: n
            }
        },
        originMethod: "getAccountTransactionsCount"
    });
    return o.account_transactions_aggregate.aggregate ? o.account_transactions_aggregate.aggregate.count : 0;
}
async function Xo(r) {
    let { aptosConfig: e, accountAddress: t, options: n } = r, i = u.from(t).toStringLong(), o = {
        ..._optionalChain([
            n,
            'optionalAccess',
            (_92)=>_92.where
        ]),
        owner_address: {
            _eq: i
        }
    }, s = {
        query: wo,
        variables: {
            where_condition: o,
            offset: _optionalChain([
                n,
                'optionalAccess',
                (_93)=>_93.offset
            ]),
            limit: _optionalChain([
                n,
                'optionalAccess',
                (_94)=>_94.limit
            ]),
            order_by: _optionalChain([
                n,
                'optionalAccess',
                (_95)=>_95.orderBy
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: s,
        originMethod: "getAccountCoinsData"
    })).current_fungible_asset_balances;
}
async function Yo(r) {
    let { aptosConfig: e, accountAddress: t } = r, n = u.from(t).toStringLong(), o = await h({
        aptosConfig: e,
        query: {
            query: bo,
            variables: {
                address: n
            }
        },
        originMethod: "getAccountCoinsCount"
    });
    if (!o.current_fungible_asset_balances_aggregate.aggregate) throw Error("Failed to get the count of account coins");
    return o.current_fungible_asset_balances_aggregate.aggregate.count;
}
async function Zo(r) {
    let { aptosConfig: e, accountAddress: t, options: n } = r, o = {
        owner_address: {
            _eq: u.from(t).toStringLong()
        }
    }, s = {
        query: un,
        variables: {
            where_condition: o,
            offset: _optionalChain([
                n,
                'optionalAccess',
                (_96)=>_96.offset
            ]),
            limit: _optionalChain([
                n,
                'optionalAccess',
                (_97)=>_97.limit
            ]),
            order_by: _optionalChain([
                n,
                'optionalAccess',
                (_98)=>_98.orderBy
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: s,
        originMethod: "getAccountOwnedObjects"
    })).current_objects;
}
async function es(r) {
    let { aptosConfig: e, privateKey: t } = r, n = new F(t.publicKey());
    if (t instanceof pt) {
        let o = B.fromPublicKey({
            publicKey: n
        }).derivedAddress();
        return et.fromPrivateKey({
            privateKey: t,
            address: o
        });
    }
    if (t instanceof Z) {
        let i = B.fromPublicKey({
            publicKey: n
        });
        if (await Vo({
            authKey: i,
            aptosConfig: e
        })) {
            let c = i.derivedAddress();
            return et.fromPrivateKey({
                privateKey: t,
                address: c,
                legacy: !1
            });
        }
        let s = B.fromPublicKey({
            publicKey: n.publicKey
        });
        if (await Vo({
            authKey: s,
            aptosConfig: e
        })) {
            let c = s.derivedAddress();
            return et.fromPrivateKey({
                privateKey: t,
                address: c,
                legacy: !0
            });
        }
    }
    throw new Error(`Can't derive account from private key ${t}`);
}
async function Vo(r) {
    let { aptosConfig: e, authKey: t } = r, n = await Ht({
        aptosConfig: e,
        authenticationKey: t.derivedAddress()
    });
    try {
        return await Re({
            aptosConfig: e,
            accountAddress: n
        }), !0;
    } catch (i) {
        if (i.status === 404) return !1;
        throw new Error(`Error while looking for an account info ${n.toString()}`);
    }
}
async function ci(r) {
    let { aptosConfig: e, options: t } = r;
    return Ct({
        aptosConfig: e,
        originMethod: "getTransactions",
        path: "transactions",
        params: {
            start: _optionalChain([
                t,
                'optionalAccess',
                (_99)=>_99.offset
            ]),
            limit: _optionalChain([
                t,
                'optionalAccess',
                (_100)=>_100.limit
            ])
        }
    });
}
async function fn(r) {
    let { aptosConfig: e } = r;
    return Pe(async ()=>{
        let { data: t } = await V({
            aptosConfig: e,
            originMethod: "getGasPriceEstimation",
            path: "estimate_gas_price"
        });
        return t;
    }, `gas-price-${e.network}`, 1e3 * 60 * 5)();
}
async function ts(r) {
    let { aptosConfig: e, ledgerVersion: t } = r, { data: n } = await V({
        aptosConfig: e,
        originMethod: "getTransactionByVersion",
        path: `transactions/by_version/${t}`
    });
    return n;
}
async function fr(r) {
    let { aptosConfig: e, transactionHash: t } = r, { data: n } = await V({
        aptosConfig: e,
        path: `transactions/by_hash/${t}`,
        originMethod: "getTransactionByHash"
    });
    return n;
}
async function rs(r) {
    let { aptosConfig: e, transactionHash: t } = r;
    try {
        return (await fr({
            aptosConfig: e,
            transactionHash: t
        })).type === "pending_transaction";
    } catch (n) {
        if (_optionalChain([
            n,
            'optionalAccess',
            (_101)=>_101.status
        ]) === 404) return !0;
        throw n;
    }
}
async function zc(r) {
    let { aptosConfig: e, transactionHash: t } = r, { data: n } = await V({
        aptosConfig: e,
        path: `transactions/wait_by_hash/${t}`,
        originMethod: "longWaitForTransaction"
    });
    return n;
}
async function qt(r) {
    let { aptosConfig: e, transactionHash: t, options: n } = r, i = _nullishCoalesce(_optionalChain([
        n,
        'optionalAccess',
        (_102)=>_102.timeoutSecs
    ]), ()=>20), o = _nullishCoalesce(_optionalChain([
        n,
        'optionalAccess',
        (_103)=>_103.checkSuccess
    ]), ()=>!0), s = !0, a = 0, c, p, d = 200, A = 1.5;
    function w(y) {
        if (!(y instanceof ye) || (p = y, y.status !== 404 && y.status >= 400 && y.status < 500)) throw y;
    }
    try {
        c = await fr({
            aptosConfig: e,
            transactionHash: t
        }), s = c.type === "pending_transaction";
    } catch (y) {
        w(y);
    }
    if (s) {
        let y = Date.now();
        try {
            c = await zc({
                aptosConfig: e,
                transactionHash: t
            }), s = c.type === "pending_transaction";
        } catch (x) {
            w(x);
        }
        a = (Date.now() - y) / 1e3;
    }
    for(; s && !(a >= i);){
        try {
            if (c = await fr({
                aptosConfig: e,
                transactionHash: t
            }), s = c.type === "pending_transaction", !s) break;
        } catch (y) {
            w(y);
        }
        await _chunkF43XVDYJjs.b.call(void 0, d), a += d / 1e3, d *= A;
    }
    if (c === void 0) throw p || new mn(`Fetching transaction ${t} failed and timed out after ${i} seconds`, c);
    if (c.type === "pending_transaction") throw new mn(`Transaction ${t} timed out in pending state after ${i} seconds`, c);
    if (!o) return c;
    if (!c.success) throw new ai(`Transaction ${t} failed with an error: ${c.vm_status}`, c);
    return c;
}
async function An(r) {
    let { aptosConfig: e, processorType: t } = r, n = BigInt(r.minimumLedgerVersion), i = 3e3, o = new Date().getTime(), s = BigInt(-1);
    for(; s < n;){
        if (new Date().getTime() - o > i) throw new Error("waitForLastSuccessIndexerVersionSync timeout");
        if (t === void 0 ? s = await dn({
            aptosConfig: e
        }) : s = (await ln({
            aptosConfig: e,
            processorType: t
        })).last_success_version, s >= n) break;
        await _chunkF43XVDYJjs.b.call(void 0, 200);
    }
}
var mn = class extends Error {
    constructor(e, t){
        super(e), this.lastSubmittedTransaction = t;
    }
}, ai = class extends Error {
    constructor(e, t){
        super(e), this.transaction = t;
    }
};
async function ns(r) {
    let { aptosConfig: e, ledgerVersion: t, options: n } = r, { data: i } = await V({
        aptosConfig: e,
        originMethod: "getBlockByVersion",
        path: `blocks/by_version/${t}`,
        params: {
            with_transactions: _optionalChain([
                n,
                'optionalAccess',
                (_104)=>_104.withTransactions
            ])
        }
    });
    return os({
        block: i,
        ...r
    });
}
async function is(r) {
    let { aptosConfig: e, blockHeight: t, options: n } = r, { data: i } = await V({
        aptosConfig: e,
        originMethod: "getBlockByHeight",
        path: `blocks/by_height/${t}`,
        params: {
            with_transactions: _optionalChain([
                n,
                'optionalAccess',
                (_105)=>_105.withTransactions
            ])
        }
    });
    return os({
        block: i,
        ...r
    });
}
async function os(r) {
    let { aptosConfig: e, block: t, options: n } = r;
    if (_optionalChain([
        n,
        'optionalAccess',
        (_106)=>_106.withTransactions
    ])) {
        t.transactions = _nullishCoalesce(t.transactions, ()=>[]);
        let i = t.transactions[t.transactions.length - 1], o = BigInt(t.first_version), s = BigInt(t.last_version), a = _optionalChain([
            i,
            'optionalAccess',
            (_107)=>_107.version
        ]), c;
        if (a === void 0 ? c = o - 1n : c = BigInt(a), c === s) return t;
        let p = [], d = 100n;
        for(let w = c + 1n; w < s; w += BigInt(100))p.push(ci({
            aptosConfig: e,
            options: {
                offset: w,
                limit: Math.min(Number(d), Number(s - w + 1n))
            }
        }));
        let A = await Promise.all(p);
        for (let w of A)t.transactions.push(...w);
    }
    return t;
}
async function T(r) {
    r.minimumLedgerVersion !== void 0 && await An({
        aptosConfig: r.config,
        minimumLedgerVersion: r.minimumLedgerVersion,
        processorType: r.processorType
    });
}
function ss(r) {
    return typeof r == "boolean";
}
function tt(r) {
    return typeof r == "string";
}
function Nc(r) {
    return typeof r == "number";
}
function hn(r) {
    if (Nc(r)) return r;
    if (tt(r) && r !== "") return Number.parseInt(r, 10);
}
function Tn(r) {
    return typeof r == "number" || typeof r == "bigint" || typeof r == "string";
}
function as(r) {
    return r == null;
}
function cs(r) {
    return ui(r) || di(r) || li(r) || gi(r) || yi(r) || mi(r) || fi(r) || bn(r) || pi(r) || Fc(r) || r instanceof b || r instanceof J;
}
function ui(r) {
    return r instanceof U;
}
function bn(r) {
    return r instanceof u;
}
function pi(r) {
    return r instanceof S;
}
function Fc(r) {
    return r instanceof at;
}
function di(r) {
    return r instanceof j;
}
function li(r) {
    return r instanceof Te;
}
function gi(r) {
    return r instanceof be;
}
function yi(r) {
    return r instanceof $;
}
function mi(r) {
    return r instanceof we;
}
function fi(r) {
    return r instanceof de;
}
function us(r) {
    return "bytecode" in r;
}
function k(r, e) {
    throw new Error(`Type mismatch for argument ${e}, expected '${r}'`);
}
function ps(r) {
    let e = r.params.findIndex((t)=>t !== "signer" && t !== "&signer");
    return e < 0 ? r.params.length : e;
}
function Ar(r) {
    let e = r.split("::");
    if (e.length !== 3) throw new Error(`Invalid function ${r}`);
    let t = e[0], n = e[1], i = e[2];
    return {
        moduleAddress: t,
        moduleName: n,
        functionName: i
    };
}
function ds(r) {
    return !!r.match(/^[_a-zA-Z0-9]+$/);
}
function ls(r) {
    return !!r.match(/\s/);
}
function Gc(r) {
    return !!r.match(/^T[0-9]+$/);
}
function Bc(r) {
    return !!r.match(/^&.+$/);
}
function Mc(r) {
    switch(r){
        case "signer":
        case "address":
        case "bool":
        case "u8":
        case "u16":
        case "u32":
        case "u64":
        case "u128":
        case "u256":
            return !0;
        default:
            return !1;
    }
}
function Vc(r, e) {
    let t = e;
    for(; t < r.length; t += 1){
        let n = r[t];
        if (!ls(n)) break;
    }
    return t;
}
var Lc = ((x)=>(x.InvalidTypeTag = "unknown type", x.UnexpectedGenericType = "unexpected generic type", x.UnexpectedTypeArgumentClose = "unexpected '>'", x.UnexpectedWhitespaceCharacter = "unexpected whitespace character", x.UnexpectedComma = "unexpected ','", x.TypeArgumentCountMismatch = "type argument count doesn't match expected amount", x.MissingTypeArgumentClose = "no matching '>' for '<'", x.MissingTypeArgument = "no type argument before ','", x.UnexpectedPrimitiveTypeArguments = "primitive types not expected to have type arguments", x.UnexpectedVectorTypeArgumentCount = "vector type expected to have exactly one type argument", x.UnexpectedStructFormat = "unexpected struct format, must be of the form 0xaddress::module_name::struct_name", x.InvalidModuleNameCharacter = "module name must only contain alphanumeric or '_' characters", x.InvalidStructNameCharacter = "struct name must only contain alphanumeric or '_' characters", x.InvalidAddress = "struct address must be valid", x))(Lc || {}), H = exports.TypeTagParserError = class extends Error {
    constructor(e, t){
        super(`Failed to parse typeTag '${e}', ${t}`);
    }
};
function He(r, e) {
    let t = _nullishCoalesce(_optionalChain([
        e,
        'optionalAccess',
        (_108)=>_108.allowGenerics
    ]), ()=>!1), n = [], i = [], o = [], s = 0, a = "", c = 1;
    for(; s < r.length;){
        let p = r[s];
        if (p === "<") n.push({
            savedExpectedTypes: c,
            savedStr: a,
            savedTypes: o
        }), a = "", o = [], c = 1;
        else if (p === ">") {
            if (a !== "") {
                let x = hr(a, i, t);
                o.push(x);
            }
            let d = n.pop();
            if (d === void 0) throw new H(r, "unexpected '>'");
            if (c !== o.length) throw new H(r, "type argument count doesn't match expected amount");
            let { savedStr: A, savedTypes: w, savedExpectedTypes: y } = d;
            i = o, o = w, a = A, c = y;
        } else if (p === ",") {
            if (n.length === 0) throw new H(r, "unexpected ','");
            if (a.length === 0) throw new H(r, "no type argument before ','");
            let d = hr(a, i, t);
            i = [], o.push(d), a = "", c += 1;
        } else if (ls(p)) {
            let d = !1;
            if (a.length !== 0) {
                let w = hr(a, i, t);
                i = [], o.push(w), a = "", d = !0;
            }
            s = Vc(r, s);
            let A = r[s];
            if (s < r.length && d && A !== "," && A !== ">") throw new H(r, "unexpected whitespace character");
            continue;
        } else a += p;
        s += 1;
    }
    if (n.length > 0) throw new H(r, "no matching '>' for '<'");
    switch(o.length){
        case 0:
            return hr(a, i, t);
        case 1:
            if (a === "") return o[0];
            throw new H(r, "unexpected ','");
        default:
            throw new H(r, "unexpected whitespace character");
    }
}
function hr(r, e, t) {
    let n = r.trim(), i = n.toLowerCase();
    if (Mc(i) && e.length > 0) throw new H(r, "primitive types not expected to have type arguments");
    switch(n.toLowerCase()){
        case "signer":
            return new mt;
        case "bool":
            return new G;
        case "address":
            return new Y;
        case "u8":
            return new ae;
        case "u16":
            return new Fe;
        case "u32":
            return new Ge;
        case "u64":
            return new W;
        case "u128":
            return new Be;
        case "u256":
            return new Me;
        case "vector":
            if (e.length !== 1) throw new H(r, "vector type expected to have exactly one type argument");
            return new C(e[0]);
        default:
            if (Bc(n)) {
                let a = n.substring(1);
                return new Zr(hr(a, e, t));
            }
            if (Gc(n)) {
                if (t) return new z(Number(n.split("T")[1]));
                throw new H(r, "unexpected generic type");
            }
            if (!n.match(/:/)) throw new H(r, "unknown type");
            let o = n.split("::");
            if (o.length !== 3) throw new H(r, "unexpected struct format, must be of the form 0xaddress::module_name::struct_name");
            let s;
            try {
                s = u.fromString(o[0]);
            } catch (e3) {
                throw new H(r, "struct address must be valid");
            }
            if (!ds(o[1])) throw new H(r, "module name must only contain alphanumeric or '_' characters");
            if (!ds(o[2])) throw new H(r, "struct name must only contain alphanumeric or '_' characters");
            return new f(new Ce(s, new R(o[1]), new R(o[2]), e));
    }
}
var Hc = new TextEncoder;
function wn(r) {
    return _nullishCoalesce(_optionalChain([
        r,
        'optionalAccess',
        (_109)=>_109.map,
        'call',
        (_110)=>_110((e)=>tt(e) ? He(e) : e)
    ]), ()=>[]);
}
async function gs(r, e, t, n) {
    let i = await yn({
        aptosConfig: n,
        accountAddress: r,
        moduleName: e
    });
    if (i.abi) return i.abi.exposed_functions.find((o)=>o.name === t);
}
async function ys(r, e, t, n) {
    let i = await gs(r, e, t, n);
    if (!i) throw new Error(`Could not find entry function ABI for '${r}::${e}::${t}'`);
    if (!i.is_entry) throw new Error(`'${r}::${e}::${t}' is not an entry function`);
    let o = ps(i), s = [];
    for(let a = o; a < i.params.length; a += 1)s.push(He(i.params[a], {
        allowGenerics: !0
    }));
    return {
        signers: o,
        typeParameters: i.generic_type_params,
        parameters: s
    };
}
async function ms(r, e, t, n) {
    let i = await gs(r, e, t, n);
    if (!i) throw new Error(`Could not find view function ABI for '${r}::${e}::${t}'`);
    if (!i.is_view) throw new Error(`'${r}::${e}::${t}' is not an view function`);
    let o = [];
    for(let a = 0; a < i.params.length; a += 1)o.push(He(i.params[a], {
        allowGenerics: !0
    }));
    let s = [];
    for(let a = 0; a < i.return.length; a += 1)s.push(He(i.return[a], {
        allowGenerics: !0
    }));
    return {
        typeParameters: i.generic_type_params,
        parameters: o,
        returnTypes: s
    };
}
function hi(r, e, t, n, i) {
    if (n >= e.parameters.length) throw new Error(`Too many arguments for '${r}', expected ${e.parameters.length}`);
    let o = e.parameters[n];
    return $t(t, o, n, i);
}
function $t(r, e, t, n) {
    return cs(r) ? (Ai(e, r, t), r) : qc(r, e, t, n);
}
function qc(r, e, t, n) {
    if (e.isBool()) {
        if (ss(r)) return new U(r);
        if (tt(r)) {
            if (r === "true") return new U(!0);
            if (r === "false") return new U(!1);
        }
        k("boolean", t);
    }
    if (e.isAddress()) {
        if (tt(r)) return u.fromString(r);
        k("string | AccountAddress", t);
    }
    if (e.isU8()) {
        let i = hn(r);
        if (i !== void 0) return new j(i);
        k("number | string", t);
    }
    if (e.isU16()) {
        let i = hn(r);
        if (i !== void 0) return new Te(i);
        k("number | string", t);
    }
    if (e.isU32()) {
        let i = hn(r);
        if (i !== void 0) return new be(i);
        k("number | string", t);
    }
    if (e.isU64()) {
        if (Tn(r)) return new $(BigInt(r));
        k("bigint | number | string", t);
    }
    if (e.isU128()) {
        if (Tn(r)) return new we(BigInt(r));
        k("bigint | number | string", t);
    }
    if (e.isU256()) {
        if (Tn(r)) return new de(BigInt(r));
        k("bigint | number | string", t);
    }
    if (e.isGeneric()) {
        let i = e.value;
        if (i < 0 || i >= n.length) throw new Error(`Generic argument ${e.toString()} is invalid for argument ${t}`);
        return $t(r, n[i], t, n);
    }
    if (e.isVector()) {
        if (e.value.isU8()) {
            if (tt(r)) return b.U8(Hc.encode(r));
            if (r instanceof Uint8Array) return b.U8(r);
            if (r instanceof ArrayBuffer) return b.U8(new Uint8Array(r));
        }
        if (Array.isArray(r)) return new b(r.map((i)=>$t(i, e.value, t, n)));
        throw new Error(`Type mismatch for argument ${t}, type '${e.toString()}'`);
    }
    if (e.isStruct()) {
        if (e.isString()) {
            if (tt(r)) return new S(r);
            k("string", t);
        }
        if (e.isObject()) {
            if (tt(r)) return u.fromString(r);
            k("string | AccountAddress", t);
        }
        if (e.isOption()) {
            if (as(r)) {
                let i = e.value.typeArgs[0];
                return i instanceof G ? new J(null) : i instanceof Y ? new J(null) : i instanceof ae ? new J(null) : i instanceof Fe ? new J(null) : i instanceof Ge ? new J(null) : i instanceof W ? new J(null) : i instanceof Be ? new J(null) : i instanceof Me ? new J(null) : new J(null);
            }
            return new J($t(r, e.value.typeArgs[0], t, n));
        }
        throw new Error(`Unsupported struct input type for argument ${t}, type '${e.toString()}'`);
    }
    throw new Error(`Type mismatch for argument ${t}, type '${e.toString()}'`);
}
function Ai(r, e, t) {
    if (r.isBool()) {
        if (ui(e)) return;
        k("Bool", t);
    }
    if (r.isAddress()) {
        if (bn(e)) return;
        k("AccountAddress", t);
    }
    if (r.isU8()) {
        if (di(e)) return;
        k("U8", t);
    }
    if (r.isU16()) {
        if (li(e)) return;
        k("U16", t);
    }
    if (r.isU32()) {
        if (gi(e)) return;
        k("U32", t);
    }
    if (r.isU64()) {
        if (yi(e)) return;
        k("U64", t);
    }
    if (r.isU128()) {
        if (mi(e)) return;
        k("U128", t);
    }
    if (r.isU256()) {
        if (fi(e)) return;
        k("U256", t);
    }
    if (r.isVector()) {
        if (e instanceof b) {
            e.values.length > 0 && Ai(r.value, e.values[0], t);
            return;
        }
        k("MoveVector", t);
    }
    if (r instanceof f) {
        if (r.isString()) {
            if (pi(e)) return;
            k("MoveString", t);
        }
        if (r.isObject()) {
            if (bn(e)) return;
            k("AccountAddress", t);
        }
        if (r.isOption()) {
            if (e instanceof J) {
                e.value !== void 0 && Ai(r.value.typeArgs[0], e.value, t);
                return;
            }
            k("MoveOption", t);
        }
    }
    throw new Error(`Type mismatch for argument ${t}, expected '${r.toString()}'`);
}
async function _n(r) {
    if (us(r)) return jc(r);
    let { moduleAddress: e, moduleName: t, functionName: n } = Ar(r.function), i = await Ts({
        key: "entry-function",
        moduleAddress: e,
        moduleName: t,
        functionName: n,
        aptosConfig: r.aptosConfig,
        abi: r.abi,
        fetch: ys
    });
    return Wc({
        ...r,
        abi: i
    });
}
function Wc(r) {
    let e = r.abi, { moduleAddress: t, moduleName: n, functionName: i } = Ar(r.function), o = wn(r.typeArguments);
    if (o.length !== e.typeParameters.length) throw new Error(`Type argument count mismatch, expected ${e.typeParameters.length}, received ${o.length}`);
    let s = r.functionArguments.map((c, p)=>hi(r.function, e, c, p, o));
    if (s.length !== e.parameters.length) throw new Error(`Too few arguments for '${t}::${n}::${i}', expected ${e.parameters.length} but got ${s.length}`);
    let a = At.build(`${t}::${n}`, i, o, s);
    if ("multisigAddress" in r) {
        let c = u.from(r.multisigAddress);
        return new dr(new gr(c, new yr(a)));
    }
    return new pr(a);
}
async function fs(r) {
    let { moduleAddress: e, moduleName: t, functionName: n } = Ar(r.function), i = await Ts({
        key: "view-function",
        moduleAddress: e,
        moduleName: t,
        functionName: n,
        aptosConfig: r.aptosConfig,
        abi: r.abi,
        fetch: ms
    });
    return Qc({
        abi: i,
        ...r
    });
}
function Qc(r) {
    let e = r.abi, { moduleAddress: t, moduleName: n, functionName: i } = Ar(r.function), o = wn(r.typeArguments);
    if (o.length !== e.typeParameters.length) throw new Error(`Type argument count mismatch, expected ${e.typeParameters.length}, received ${o.length}`);
    let s = _nullishCoalesce(_optionalChain([
        r,
        'optionalAccess',
        (_111)=>_111.functionArguments,
        'optionalAccess',
        (_112)=>_112.map,
        'call',
        (_113)=>_113((a, c)=>hi(r.function, e, a, c, o))
    ]), ()=>[]);
    if (s.length !== e.parameters.length) throw new Error(`Too few arguments for '${t}::${n}::${i}', expected ${e.parameters.length} but got ${s.length}`);
    return At.build(`${t}::${n}`, i, o, s);
}
function jc(r) {
    return new ur(new lr(g.fromHexInput(r.bytecode).toUint8Array(), wn(r.typeArguments), r.functionArguments));
}
async function Jc(r) {
    let { aptosConfig: e, sender: t, payload: n, options: i, feePayerAddress: o } = r, s = async ()=>Wn[e.network] ? {
            chainId: Wn[e.network]
        } : {
            chainId: (await pn({
                aptosConfig: e
            })).chain_id
        }, a = async ()=>_optionalChain([
            i,
            'optionalAccess',
            (_114)=>_114.gasUnitPrice
        ]) ? {
            gasEstimate: i.gasUnitPrice
        } : {
            gasEstimate: (await fn({
                aptosConfig: e
            })).gas_estimate
        }, c = async ()=>{
        let St = async ()=>_optionalChain([
                i,
                'optionalAccess',
                (_115)=>_115.accountSequenceNumber
            ]) !== void 0 ? i.accountSequenceNumber : (await Re({
                aptosConfig: e,
                accountAddress: t
            })).sequence_number;
        if (o && u.from(o).equals(u.ZERO)) try {
            return await St();
        } catch (e4) {
            return 0;
        }
        else return St();
    }, [{ chainId: p }, { gasEstimate: d }, A] = await Promise.all([
        s(),
        a(),
        c()
    ]), { maxGasAmount: w, gasUnitPrice: y, expireTimestamp: x } = {
        maxGasAmount: _optionalChain([
            i,
            'optionalAccess',
            (_116)=>_116.maxGasAmount
        ]) ? BigInt(i.maxGasAmount) : BigInt(2e5),
        gasUnitPrice: _nullishCoalesce(_optionalChain([
            i,
            'optionalAccess',
            (_117)=>_117.gasUnitPrice
        ]), ()=>BigInt(d)),
        expireTimestamp: _nullishCoalesce(_optionalChain([
            i,
            'optionalAccess',
            (_118)=>_118.expireTimestamp
        ]), ()=>BigInt(Math.floor(Date.now() / 1e3) + 20))
    };
    return new me(u.from(t), BigInt(A), n, BigInt(w), BigInt(y), BigInt(x), new Dt(p));
}
async function Ti(r) {
    let { aptosConfig: e, sender: t, payload: n, options: i, feePayerAddress: o } = r, s = await Jc({
        aptosConfig: e,
        sender: t,
        payload: n,
        options: i,
        feePayerAddress: o
    });
    if ("secondarySignerAddresses" in r) {
        let a = _nullishCoalesce(_optionalChain([
            r,
            'access',
            (_119)=>_119.secondarySignerAddresses,
            'optionalAccess',
            (_120)=>_120.map,
            'call',
            (_121)=>_121((c)=>u.from(c))
        ]), ()=>[]);
        return new on(s, a, r.feePayerAddress ? u.from(r.feePayerAddress) : void 0);
    }
    return new nn(s, r.feePayerAddress ? u.from(r.feePayerAddress) : void 0);
}
function As(r) {
    let { signerPublicKey: e, transaction: t, secondarySignersPublicKeys: n, feePayerPublicKey: i } = r, o = Wt(e);
    if (t.feePayerAddress) {
        let a = new Tt(t.rawTransaction, _nullishCoalesce(t.secondarySignerAddresses, ()=>[]), t.feePayerAddress), c = [];
        t.secondarySignerAddresses && (n ? c = n.map((A)=>Wt(A)) : c = Array.from({
            length: t.secondarySignerAddresses.length
        }, ()=>Wt(void 0)));
        let p = Wt(i), d = new _t(o, _nullishCoalesce(t.secondarySignerAddresses, ()=>[]), c, {
            address: t.feePayerAddress,
            authenticator: p
        });
        return new Le(a.raw_txn, d).bcsToBytes();
    }
    if (t.secondarySignerAddresses) {
        let a = new ht(t.rawTransaction, t.secondarySignerAddresses), c = [];
        n ? c = n.map((d)=>Wt(d)) : c = Array.from({
            length: t.secondarySignerAddresses.length
        }, ()=>Wt(void 0));
        let p = new wt(o, t.secondarySignerAddresses, c);
        return new Le(a.raw_txn, p).bcsToBytes();
    }
    let s;
    if (o instanceof Se) s = new bt(o.public_key, o.signature);
    else if (o instanceof ie || o instanceof Ie) s = new Ze(o);
    else if (o instanceof Ot) s = new Ze(o);
    else throw new Error("Invalid public key");
    return new Le(t.rawTransaction, s).bcsToBytes();
}
function Wt(r) {
    if (!r) return new Ot;
    let t = O.isInstance(r) || ee.isInstance(r) || Ke.isInstance(r) ? new F(r) : r, n = new I(new Uint8Array(64));
    if (P.isInstance(t)) return new Se(t, n);
    if (F.isInstance(t)) return O.isInstance(t.publicKey) ? new ie(t, new L(De.getSimulationSignature())) : new ie(t, new L(n));
    if (Ye.isInstance(t)) return new Ie(t, new Ne({
        signatures: t.publicKeys.map(()=>new L(n)),
        bitmap: t.createBitmap({
            bits: Array(t.publicKeys.length).fill(0).map((i, o)=>o)
        })
    }));
    throw new Error("Unsupported PublicKey used for simulations");
}
function bi(r) {
    let { transaction: e, feePayerAuthenticator: t, additionalSignersAuthenticators: n } = r, i = co(X, r.senderAuthenticator), o;
    if (e.feePayerAddress) {
        if (!t) throw new Error("Must provide a feePayerAuthenticator argument to generate a signed fee payer transaction");
        o = new _t(i, _nullishCoalesce(e.secondarySignerAddresses, ()=>[]), _nullishCoalesce(n, ()=>[]), {
            address: e.feePayerAddress,
            authenticator: t
        });
    } else if (e.secondarySignerAddresses) {
        if (!n) throw new Error("Must provide a additionalSignersAuthenticators argument to generate a signed multi agent transaction");
        o = new wt(i, e.secondarySignerAddresses, n);
    } else i instanceof Se ? o = new bt(i.public_key, i.signature) : o = new Ze(i);
    return new Le(e.rawTransaction, o).bcsToBytes();
}
function hs(r) {
    let e = _sha3.sha3_256.create();
    for (let t of r)e.update(t);
    return e.digest();
}
var Xc = hs([
    "APTOS::Transaction"
]);
function DT(r) {
    let e = bi(r);
    return new g(hs([
        Xc,
        new Uint8Array([
            0
        ]),
        e
    ])).toString();
}
async function Ts({ key: r, moduleAddress: e, moduleName: t, functionName: n, aptosConfig: i, abi: o, fetch: s }) {
    return o !== void 0 ? o : Pe(async ()=>s(e, t, n, i), `${r}-${i.network}-${e}-${t}-${n}`, 1e3 * 60 * 5)();
}
async function fe(r) {
    let { aptosConfig: e, payload: t, options: n } = r, i = await fs({
        ...t,
        aptosConfig: e
    }), o = new q;
    i.serialize(o);
    let s = o.toUint8Array(), { data: a } = await Xe({
        aptosConfig: e,
        path: "view",
        originMethod: "view",
        contentType: "application/x.aptos.view_function+bcs",
        params: {
            ledger_version: _optionalChain([
                n,
                'optionalAccess',
                (_122)=>_122.ledgerVersion
            ])
        },
        body: s
    });
    return a;
}
async function bs(r) {
    let { aptosConfig: e, payload: t, options: n } = r, { data: i } = await Xe({
        aptosConfig: e,
        originMethod: "viewJson",
        path: "view",
        params: {
            ledger_version: _optionalChain([
                n,
                'optionalAccess',
                (_123)=>_123.ledgerVersion
            ])
        },
        body: {
            function: t.function,
            type_arguments: _nullishCoalesce(t.typeArguments, ()=>[]),
            arguments: _nullishCoalesce(t.functionArguments, ()=>[])
        }
    });
    return i;
}
var Tr = class {
    constructor(e){
        this.config = e;
    }
    async getAccountInfo(e) {
        return Re({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountModules(e) {
        return Lo({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountModule(e) {
        return yn({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountTransactions(e) {
        return Ho({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountResources(e) {
        return qo({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountResource(e) {
        return si({
            aptosConfig: this.config,
            ...e
        });
    }
    async lookupOriginalAccountAddress(e) {
        return Ht({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountTokensCount(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "account_transactions_processor"
        }), $o({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountOwnedTokens(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "token_v2_processor"
        }), Wo({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountOwnedTokensFromCollectionAddress(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "token_v2_processor"
        }), Qo({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountCollectionsWithOwnedTokens(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "token_v2_processor"
        }), jo({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountTransactionsCount(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "account_transactions_processor"
        }), Jo({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountCoinsData(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "fungible_asset_processor"
        }), Xo({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountCoinsCount(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "fungible_asset_processor"
        }), Yo({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountAPTAmount(e) {
        return this.getAccountCoinAmount({
            coinType: gt,
            faMetadataAddress: oo,
            ...e
        });
    }
    async getAccountCoinAmount(e) {
        let { accountAddress: t, coinType: n, faMetadataAddress: i, minimumLedgerVersion: o } = e;
        o && console.warn(`minimumLedgerVersion is not used anymore, here for backward 
        compatibility see https://github.com/aptos-labs/aptos-ts-sdk/pull/519, 
        will be removed in the near future`);
        let s = n;
        n === void 0 && i !== void 0 && (s = await Pe(async ()=>{
            try {
                let p = (await fe({
                    aptosConfig: this.config,
                    payload: {
                        function: "0x1::coin::paired_coin",
                        functionArguments: [
                            i
                        ]
                    }
                })).at(0);
                if (p.vec.length > 0 && _chunkF43XVDYJjs.j.call(void 0, p.vec[0])) return _chunkF43XVDYJjs.i.call(void 0, p.vec[0]);
            } catch (e5) {}
        }, `coin-mapping-${i.toString()}`, 1e3 * 60 * 5)());
        let a;
        if (n !== void 0 && i !== void 0) a = u.from(i).toStringLong();
        else if (n !== void 0 && i === void 0) n === gt ? a = u.A.toStringLong() : a = Yr(u.A, n).toStringLong();
        else if (n === void 0 && i !== void 0) {
            let p = u.from(i);
            a = p.toStringLong(), p === u.A && (s = gt);
        } else throw new Error("Either coinType, faMetadataAddress, or both must be provided");
        if (s !== void 0) {
            let [p] = await fe({
                aptosConfig: this.config,
                payload: {
                    function: "0x1::coin::balance",
                    typeArguments: [
                        s
                    ],
                    functionArguments: [
                        t
                    ]
                }
            });
            return parseInt(p, 10);
        }
        let [c] = await fe({
            aptosConfig: this.config,
            payload: {
                function: "0x1::primary_fungible_store::balance",
                typeArguments: [
                    "0x1::object::ObjectCore"
                ],
                functionArguments: [
                    t,
                    a
                ]
            }
        });
        return parseInt(c, 10);
    }
    async getAccountOwnedObjects(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "default_processor"
        }), Zo({
            aptosConfig: this.config,
            ...e
        });
    }
    async deriveAccountFromPrivateKey(e) {
        return es({
            aptosConfig: this.config,
            ...e
        });
    }
};
var _aptosclient = __turbopack_require__("[project]/node_modules/.pnpm/@aptos-labs+aptos-client@0.1.1/node_modules/@aptos-labs/aptos-client/dist/node/index.node.js [app-route] (ecmascript)");
var _aptosclient2 = _interopRequireDefault(_aptosclient);
var Sn = class {
    constructor(e){
        this.network = _nullishCoalesce(_optionalChain([
            e,
            'optionalAccess',
            (_124)=>_124.network
        ]), ()=>"devnet"), this.fullnode = _optionalChain([
            e,
            'optionalAccess',
            (_125)=>_125.fullnode
        ]), this.faucet = _optionalChain([
            e,
            'optionalAccess',
            (_126)=>_126.faucet
        ]), this.pepper = _optionalChain([
            e,
            'optionalAccess',
            (_127)=>_127.pepper
        ]), this.prover = _optionalChain([
            e,
            'optionalAccess',
            (_128)=>_128.prover
        ]), this.indexer = _optionalChain([
            e,
            'optionalAccess',
            (_129)=>_129.indexer
        ]), this.client = _nullishCoalesce(_optionalChain([
            e,
            'optionalAccess',
            (_130)=>_130.client
        ]), ()=>({
                provider: _aptosclient2.default
            })), this.clientConfig = _nullishCoalesce(_optionalChain([
            e,
            'optionalAccess',
            (_131)=>_131.clientConfig
        ]), ()=>({})), this.fullnodeConfig = _nullishCoalesce(_optionalChain([
            e,
            'optionalAccess',
            (_132)=>_132.fullnodeConfig
        ]), ()=>({})), this.indexerConfig = _nullishCoalesce(_optionalChain([
            e,
            'optionalAccess',
            (_133)=>_133.indexerConfig
        ]), ()=>({})), this.faucetConfig = _nullishCoalesce(_optionalChain([
            e,
            'optionalAccess',
            (_134)=>_134.faucetConfig
        ]), ()=>({}));
    }
    getRequestUrl(e) {
        switch(e){
            case "Fullnode":
                if (this.fullnode !== void 0) return this.fullnode;
                if (this.network === "custom") throw new Error("Please provide a custom full node url");
                return to[this.network];
            case "Faucet":
                if (this.faucet !== void 0) return this.faucet;
                if (this.network === "custom") throw new Error("Please provide a custom faucet url");
                return ro[this.network];
            case "Indexer":
                if (this.indexer !== void 0) return this.indexer;
                if (this.network === "custom") throw new Error("Please provide a custom indexer url");
                return eo[this.network];
            case "Pepper":
                if (this.pepper !== void 0) return this.pepper;
                if (this.network === "custom") throw new Error("Please provide a custom pepper service url");
                return Hn[this.network];
            case "Prover":
                if (this.prover !== void 0) return this.prover;
                if (this.network === "custom") throw new Error("Please provide a custom prover service url");
                return qn[this.network];
            default:
                throw Error(`apiType ${e} is not supported`);
        }
    }
    isPepperServiceRequest(e) {
        return Hn[this.network] === e;
    }
    isProverServiceRequest(e) {
        return qn[this.network] === e;
    }
};
async function _(r) {
    let e = await Zc(r);
    return eu(r, e);
}
async function Zc(r) {
    let { aptosConfig: e, data: t } = r, n, i;
    return "bytecode" in t ? i = await _n(t) : "multisigAddress" in t ? (n = {
        aptosConfig: e,
        multisigAddress: t.multisigAddress,
        function: t.function,
        functionArguments: t.functionArguments,
        typeArguments: t.typeArguments,
        abi: t.abi
    }, i = await _n(n)) : (n = {
        aptosConfig: e,
        function: t.function,
        functionArguments: t.functionArguments,
        typeArguments: t.typeArguments,
        abi: t.abi
    }, i = await _n(n)), i;
}
async function eu(r, e) {
    let { aptosConfig: t, sender: n, options: i } = r, o;
    if (tu(r) && (o = u.ZERO.toString()), ru(r)) {
        let { secondarySignerAddresses: s } = r;
        return Ti({
            aptosConfig: t,
            sender: n,
            payload: e,
            options: i,
            secondarySignerAddresses: s,
            feePayerAddress: o
        });
    }
    return Ti({
        aptosConfig: t,
        sender: n,
        payload: e,
        options: i,
        feePayerAddress: o
    });
}
function tu(r) {
    return r.withFeePayer === !0;
}
function ru(r) {
    return "secondarySignerAddresses" in r;
}
function ws(r) {
    let { transaction: e } = r;
    return Nt(e);
}
function xn(r) {
    let { signer: e, transaction: t } = r;
    return e.signTransactionWithAuthenticator(t);
}
function En(r) {
    let { signer: e, transaction: t } = r;
    if (!t.feePayerAddress) throw new Error(`Transaction ${t} is not a Fee Payer transaction`);
    return t.feePayerAddress = e.accountAddress, xn({
        signer: e,
        transaction: t
    });
}
async function wi(r) {
    let { aptosConfig: e, transaction: t, signerPublicKey: n, secondarySignersPublicKeys: i, feePayerPublicKey: o, options: s } = r, a = As({
        transaction: t,
        signerPublicKey: n,
        secondarySignersPublicKeys: i,
        feePayerPublicKey: o,
        options: s
    }), { data: c } = await Xe({
        aptosConfig: e,
        body: a,
        path: "transactions/simulate",
        params: {
            estimate_gas_unit_price: _nullishCoalesce(_optionalChain([
                r,
                'access',
                (_135)=>_135.options,
                'optionalAccess',
                (_136)=>_136.estimateGasUnitPrice
            ]), ()=>!1),
            estimate_max_gas_amount: _nullishCoalesce(_optionalChain([
                r,
                'access',
                (_137)=>_137.options,
                'optionalAccess',
                (_138)=>_138.estimateMaxGasAmount
            ]), ()=>!1),
            estimate_prioritized_gas_unit_price: _nullishCoalesce(_optionalChain([
                r,
                'access',
                (_139)=>_139.options,
                'optionalAccess',
                (_140)=>_140.estimatePrioritizedGasUnitPrice
            ]), ()=>!1)
        },
        originMethod: "simulateTransaction",
        contentType: "application/x.aptos.signed_transaction+bcs"
    });
    return c;
}
async function br(r) {
    let { aptosConfig: e } = r, t = bi({
        ...r
    });
    try {
        let { data: n } = await Xe({
            aptosConfig: e,
            body: t,
            path: "transactions",
            originMethod: "submitTransaction",
            contentType: "application/x.aptos.signed_transaction+bcs"
        });
        return n;
    } catch (n) {
        let i = Le.deserialize(new N(t));
        throw i.authenticator.isSingleSender() && i.authenticator.sender.isSingleKey() && (i.authenticator.sender.public_key.publicKey instanceof O || i.authenticator.sender.public_key.publicKey instanceof ee) && await ue.fetchJWK({
            aptosConfig: e,
            publicKey: i.authenticator.sender.public_key.publicKey,
            kid: i.authenticator.sender.signature.signature.getJwkKid()
        }), n;
    }
}
async function wr(r) {
    let { aptosConfig: e, signer: t, feePayer: n, transaction: i } = r;
    sn(t) && await t.checkKeylessAccountValidity(e), sn(n) && await n.checkKeylessAccountValidity(e);
    let o = r.feePayerAuthenticator || n && En({
        signer: n,
        transaction: i
    }), s = xn({
        signer: t,
        transaction: i
    });
    return br({
        aptosConfig: e,
        transaction: i,
        senderAuthenticator: s,
        feePayerAuthenticator: o
    });
}
async function _s(r) {
    let { aptosConfig: e, senderAuthenticator: t, feePayer: n, transaction: i } = r;
    sn(n) && await n.checkKeylessAccountValidity(e);
    let o = En({
        signer: n,
        transaction: i
    });
    return br({
        aptosConfig: e,
        transaction: i,
        senderAuthenticator: t,
        feePayerAuthenticator: o
    });
}
var nu = {
    typeParameters: [],
    parameters: [
        C.u8(),
        new C(C.u8())
    ]
};
async function Ss(r) {
    let { aptosConfig: e, account: t, metadataBytes: n, moduleBytecode: i, options: o } = r, s = i.map((a)=>b.U8(a));
    return _({
        aptosConfig: e,
        sender: u.from(t),
        data: {
            function: "0x1::code::publish_package_txn",
            functionArguments: [
                b.U8(n),
                new b(s)
            ],
            abi: nu
        },
        options: o
    });
}
var iu = {
    typeParameters: [],
    parameters: [
        new ae,
        C.u8(),
        new ae,
        C.u8(),
        C.u8(),
        C.u8()
    ]
};
async function xs(r) {
    let { aptosConfig: e, fromAccount: t, toNewPrivateKey: n } = r, i = await Re({
        aptosConfig: e,
        accountAddress: t.accountAddress
    }), o = et.fromPrivateKey({
        privateKey: n,
        legacy: !0
    }), a = new tn({
        sequenceNumber: BigInt(i.sequence_number),
        originator: t.accountAddress,
        currentAuthKey: u.from(i.authentication_key),
        newPublicKey: o.publicKey
    }).bcsToBytes(), c = t.sign(a), p = o.sign(a), d = await _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x1::account::rotate_authentication_key",
            functionArguments: [
                new j(t.signingScheme),
                b.U8(t.publicKey.toUint8Array()),
                new j(o.signingScheme),
                b.U8(o.publicKey.toUint8Array()),
                b.U8(c.toUint8Array()),
                b.U8(p.toUint8Array())
            ],
            abi: iu
        }
    });
    return wr({
        aptosConfig: e,
        signer: t,
        transaction: d
    });
}
var ou = {
    typeParameters: [
        {
            constraints: []
        }
    ],
    parameters: [
        new Y,
        new W
    ]
};
async function Es(r) {
    let { aptosConfig: e, sender: t, recipient: n, amount: i, coinType: o, options: s } = r;
    return _({
        aptosConfig: e,
        sender: t,
        data: {
            function: "0x1::aptos_account::transfer_coins",
            typeArguments: [
                _nullishCoalesce(o, ()=>gt)
            ],
            functionArguments: [
                n,
                i
            ],
            abi: ou
        },
        options: s
    });
}
var _r = class {
    constructor(e){
        this.config = e;
    }
    async transferCoinTransaction(e) {
        return Es({
            aptosConfig: this.config,
            ...e
        });
    }
};
var rt = {
    BOOLEAN: "bool",
    U8: "u8",
    U16: "u16",
    U32: "u32",
    U64: "u64",
    U128: "u128",
    U256: "u256",
    ADDRESS: "address",
    STRING: "0x1::string::String",
    ARRAY: "vector<u8>"
}, Ae = "0x4::token::Token";
async function Ps(r) {
    let { aptosConfig: e, digitalAssetAddress: t } = r, n = {
        token_data_id: {
            _eq: u.from(t).toStringLong()
        }
    };
    return (await h({
        aptosConfig: e,
        query: {
            query: No,
            variables: {
                where_condition: n
            }
        },
        originMethod: "getDigitalAssetData"
    })).current_token_datas_v2[0];
}
async function vs(r) {
    let { aptosConfig: e, digitalAssetAddress: t } = r, n = {
        token_data_id: {
            _eq: u.from(t).toStringLong()
        },
        amount: {
            _gt: 0
        }
    };
    return (await h({
        aptosConfig: e,
        query: {
            query: oi,
            variables: {
                where_condition: n
            }
        },
        originMethod: "getCurrentDigitalAssetOwnership"
    })).current_token_ownerships_v2[0];
}
async function Is(r) {
    let { aptosConfig: e, ownerAddress: t, options: n } = r, i = {
        owner_address: {
            _eq: u.from(t).toStringLong()
        },
        amount: {
            _gt: 0
        }
    }, o = {
        query: oi,
        variables: {
            where_condition: i,
            offset: _optionalChain([
                n,
                'optionalAccess',
                (_141)=>_141.offset
            ]),
            limit: _optionalChain([
                n,
                'optionalAccess',
                (_142)=>_142.limit
            ]),
            order_by: _optionalChain([
                n,
                'optionalAccess',
                (_143)=>_143.orderBy
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: o,
        originMethod: "getOwnedDigitalAssets"
    })).current_token_ownerships_v2;
}
async function Cs(r) {
    let { aptosConfig: e, digitalAssetAddress: t, options: n } = r, i = {
        token_data_id: {
            _eq: u.from(t).toStringLong()
        }
    }, o = {
        query: zo,
        variables: {
            where_condition: i,
            offset: _optionalChain([
                n,
                'optionalAccess',
                (_144)=>_144.offset
            ]),
            limit: _optionalChain([
                n,
                'optionalAccess',
                (_145)=>_145.limit
            ]),
            order_by: _optionalChain([
                n,
                'optionalAccess',
                (_146)=>_146.orderBy
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: o,
        originMethod: "getDigitalAssetActivity"
    })).token_activities_v2;
}
var su = {
    typeParameters: [],
    parameters: [
        new f(v()),
        new W,
        new f(v()),
        new f(v()),
        new G,
        new G,
        new G,
        new G,
        new G,
        new G,
        new G,
        new G,
        new G,
        new W,
        new W
    ]
};
async function Rs(r) {
    let { aptosConfig: e, options: t, creator: n } = r;
    return _({
        aptosConfig: e,
        sender: n.accountAddress,
        data: {
            function: "0x4::aptos_token::create_collection",
            functionArguments: [
                new S(r.description),
                new $(_nullishCoalesce(r.maxSupply, ()=>ot)),
                new S(r.name),
                new S(r.uri),
                new U(_nullishCoalesce(r.mutableDescription, ()=>!0)),
                new U(_nullishCoalesce(r.mutableRoyalty, ()=>!0)),
                new U(_nullishCoalesce(r.mutableURI, ()=>!0)),
                new U(_nullishCoalesce(r.mutableTokenDescription, ()=>!0)),
                new U(_nullishCoalesce(r.mutableTokenName, ()=>!0)),
                new U(_nullishCoalesce(r.mutableTokenProperties, ()=>!0)),
                new U(_nullishCoalesce(r.mutableTokenURI, ()=>!0)),
                new U(_nullishCoalesce(r.tokensBurnableByCreator, ()=>!0)),
                new U(_nullishCoalesce(r.tokensFreezableByCreator, ()=>!0)),
                new $(_nullishCoalesce(r.royaltyNumerator, ()=>0)),
                new $(_nullishCoalesce(r.royaltyDenominator, ()=>1))
            ],
            abi: su
        },
        options: t
    });
}
async function Qt(r) {
    let { aptosConfig: e, options: t } = r, n = _optionalChain([
        t,
        'optionalAccess',
        (_147)=>_147.where
    ]);
    _optionalChain([
        t,
        'optionalAccess',
        (_148)=>_148.tokenStandard
    ]) && (n.token_standard = {
        _eq: _nullishCoalesce(_optionalChain([
            t,
            'optionalAccess',
            (_149)=>_149.tokenStandard
        ]), ()=>"v2")
    });
    let i = {
        query: Io,
        variables: {
            where_condition: n,
            offset: _optionalChain([
                t,
                'optionalAccess',
                (_150)=>_150.offset
            ]),
            limit: _optionalChain([
                t,
                'optionalAccess',
                (_151)=>_151.limit
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: i,
        originMethod: "getCollectionData"
    })).current_collections_v2[0];
}
async function Us(r) {
    let { aptosConfig: e, creatorAddress: t, collectionName: n, options: i } = r, o = u.from(t), s = {
        collection_name: {
            _eq: n
        },
        creator_address: {
            _eq: o.toStringLong()
        }
    };
    return _optionalChain([
        i,
        'optionalAccess',
        (_152)=>_152.tokenStandard
    ]) && (s.token_standard = {
        _eq: _nullishCoalesce(_optionalChain([
            i,
            'optionalAccess',
            (_153)=>_153.tokenStandard
        ]), ()=>"v2")
    }), Qt({
        aptosConfig: e,
        options: {
            ...i,
            where: s
        }
    });
}
async function Ks(r) {
    let { aptosConfig: e, creatorAddress: t, options: n } = r, o = {
        creator_address: {
            _eq: u.from(t).toStringLong()
        }
    };
    return _optionalChain([
        n,
        'optionalAccess',
        (_154)=>_154.tokenStandard
    ]) && (o.token_standard = {
        _eq: _nullishCoalesce(_optionalChain([
            n,
            'optionalAccess',
            (_155)=>_155.tokenStandard
        ]), ()=>"v2")
    }), Qt({
        aptosConfig: e,
        options: {
            ...n,
            where: o
        }
    });
}
async function ks(r) {
    let { aptosConfig: e, collectionId: t, options: n } = r, o = {
        collection_id: {
            _eq: u.from(t).toStringLong()
        }
    };
    return _optionalChain([
        n,
        'optionalAccess',
        (_156)=>_156.tokenStandard
    ]) && (o.token_standard = {
        _eq: _nullishCoalesce(_optionalChain([
            n,
            'optionalAccess',
            (_157)=>_157.tokenStandard
        ]), ()=>"v2")
    }), Qt({
        aptosConfig: e,
        options: {
            ...n,
            where: o
        }
    });
}
async function Os(r) {
    let { creatorAddress: e, collectionName: t, options: n, aptosConfig: i } = r, o = u.from(e), s = {
        collection_name: {
            _eq: t
        },
        creator_address: {
            _eq: o.toStringLong()
        }
    };
    return _optionalChain([
        n,
        'optionalAccess',
        (_158)=>_158.tokenStandard
    ]) && (s.token_standard = {
        _eq: _nullishCoalesce(_optionalChain([
            n,
            'optionalAccess',
            (_159)=>_159.tokenStandard
        ]), ()=>"v2")
    }), (await Qt({
        aptosConfig: i,
        options: {
            where: s
        }
    })).collection_id;
}
var au = {
    typeParameters: [],
    parameters: [
        new f(v()),
        new f(v()),
        new f(v()),
        new f(v()),
        new C(new f(v())),
        new C(new f(v())),
        new C(C.u8())
    ]
};
async function Ds(r) {
    let { aptosConfig: e, options: t, creator: n, collection: i, description: o, name: s, uri: a, propertyKeys: c, propertyTypes: p, propertyValues: d } = r, A = _optionalChain([
        p,
        'optionalAccess',
        (_160)=>_160.map,
        'call',
        (_161)=>_161((w)=>rt[w])
    ]);
    return _({
        aptosConfig: e,
        sender: n.accountAddress,
        data: {
            function: "0x4::aptos_token::mint",
            functionArguments: [
                new S(i),
                new S(o),
                new S(s),
                new S(a),
                b.MoveString(_nullishCoalesce(c, ()=>[])),
                b.MoveString(_nullishCoalesce(A, ()=>[])),
                js(_nullishCoalesce(d, ()=>[]), _nullishCoalesce(A, ()=>[]))
            ],
            abi: au
        },
        options: t
    });
}
var cu = {
    typeParameters: [
        {
            constraints: [
                "key"
            ]
        }
    ],
    parameters: [
        new f(ce(new z(0))),
        new Y
    ]
};
async function zs(r) {
    let { aptosConfig: e, sender: t, digitalAssetAddress: n, recipient: i, digitalAssetType: o, options: s } = r;
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x1::object::transfer",
            typeArguments: [
                _nullishCoalesce(o, ()=>Ae)
            ],
            functionArguments: [
                u.from(n),
                u.from(i)
            ],
            abi: cu
        },
        options: s
    });
}
var uu = {
    typeParameters: [],
    parameters: [
        new f(v()),
        new f(v()),
        new f(v()),
        new f(v()),
        new C(new f(v())),
        new C(new f(v())),
        new C(C.u8()),
        new Y
    ]
};
async function Ns(r) {
    let { aptosConfig: e, account: t, collection: n, description: i, name: o, uri: s, recipient: a, propertyKeys: c, propertyTypes: p, propertyValues: d, options: A } = r;
    if (_optionalChain([
        c,
        'optionalAccess',
        (_162)=>_162.length
    ]) !== _optionalChain([
        d,
        'optionalAccess',
        (_163)=>_163.length
    ])) throw new Error("Property keys and property values counts do not match");
    if (_optionalChain([
        p,
        'optionalAccess',
        (_164)=>_164.length
    ]) !== _optionalChain([
        d,
        'optionalAccess',
        (_165)=>_165.length
    ])) throw new Error("Property types and property values counts do not match");
    let w = _optionalChain([
        p,
        'optionalAccess',
        (_166)=>_166.map,
        'call',
        (_167)=>_167((y)=>rt[y])
    ]);
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x4::aptos_token::mint_soul_bound",
            functionArguments: [
                n,
                i,
                o,
                s,
                b.MoveString(_nullishCoalesce(c, ()=>[])),
                b.MoveString(_nullishCoalesce(w, ()=>[])),
                js(_nullishCoalesce(d, ()=>[]), _nullishCoalesce(w, ()=>[])),
                a
            ],
            abi: uu
        },
        options: A
    });
}
var pu = {
    typeParameters: [
        {
            constraints: [
                "key"
            ]
        }
    ],
    parameters: [
        new f(ce(new z(0)))
    ]
};
async function Fs(r) {
    let { aptosConfig: e, creator: t, digitalAssetAddress: n, digitalAssetType: i, options: o } = r;
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x4::aptos_token::burn",
            typeArguments: [
                _nullishCoalesce(i, ()=>Ae)
            ],
            functionArguments: [
                u.from(n)
            ],
            abi: pu
        },
        options: o
    });
}
var du = {
    typeParameters: [
        {
            constraints: [
                "key"
            ]
        }
    ],
    parameters: [
        new f(ce(new z(0)))
    ]
};
async function Gs(r) {
    let { aptosConfig: e, creator: t, digitalAssetAddress: n, digitalAssetType: i, options: o } = r;
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x4::aptos_token::freeze_transfer",
            typeArguments: [
                _nullishCoalesce(i, ()=>Ae)
            ],
            functionArguments: [
                n
            ],
            abi: du
        },
        options: o
    });
}
var lu = {
    typeParameters: [
        {
            constraints: [
                "key"
            ]
        }
    ],
    parameters: [
        new f(ce(new z(0)))
    ]
};
async function Bs(r) {
    let { aptosConfig: e, creator: t, digitalAssetAddress: n, digitalAssetType: i, options: o } = r;
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x4::aptos_token::unfreeze_transfer",
            typeArguments: [
                _nullishCoalesce(i, ()=>Ae)
            ],
            functionArguments: [
                n
            ],
            abi: lu
        },
        options: o
    });
}
var gu = {
    typeParameters: [
        {
            constraints: [
                "key"
            ]
        }
    ],
    parameters: [
        new f(ce(new z(0))),
        new f(v())
    ]
};
async function Ms(r) {
    let { aptosConfig: e, creator: t, description: n, digitalAssetAddress: i, digitalAssetType: o, options: s } = r;
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x4::aptos_token::set_description",
            typeArguments: [
                _nullishCoalesce(o, ()=>Ae)
            ],
            functionArguments: [
                u.from(i),
                new S(n)
            ],
            abi: gu
        },
        options: s
    });
}
var yu = {
    typeParameters: [
        {
            constraints: [
                "key"
            ]
        }
    ],
    parameters: [
        new f(ce(new z(0))),
        new f(v())
    ]
};
async function Vs(r) {
    let { aptosConfig: e, creator: t, name: n, digitalAssetAddress: i, digitalAssetType: o, options: s } = r;
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x4::aptos_token::set_name",
            typeArguments: [
                _nullishCoalesce(o, ()=>Ae)
            ],
            functionArguments: [
                u.from(i),
                new S(n)
            ],
            abi: yu
        },
        options: s
    });
}
var mu = {
    typeParameters: [
        {
            constraints: [
                "key"
            ]
        }
    ],
    parameters: [
        new f(ce(new z(0))),
        new f(v())
    ]
};
async function Ls(r) {
    let { aptosConfig: e, creator: t, uri: n, digitalAssetAddress: i, digitalAssetType: o, options: s } = r;
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x4::aptos_token::set_uri",
            typeArguments: [
                _nullishCoalesce(o, ()=>Ae)
            ],
            functionArguments: [
                u.from(i),
                new S(n)
            ],
            abi: mu
        },
        options: s
    });
}
var fu = {
    typeParameters: [
        {
            constraints: [
                "key"
            ]
        }
    ],
    parameters: [
        new f(ce(new z(0))),
        new f(v()),
        new f(v()),
        C.u8()
    ]
};
async function Hs(r) {
    let { aptosConfig: e, creator: t, propertyKey: n, propertyType: i, propertyValue: o, digitalAssetAddress: s, digitalAssetType: a, options: c } = r;
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x4::aptos_token::add_property",
            typeArguments: [
                _nullishCoalesce(a, ()=>Ae)
            ],
            functionArguments: [
                u.from(s),
                new S(n),
                new S(rt[i]),
                b.U8(_i(o, rt[i]))
            ],
            abi: fu
        },
        options: c
    });
}
var Au = {
    typeParameters: [
        {
            constraints: [
                "key"
            ]
        }
    ],
    parameters: [
        new f(ce(new z(0))),
        new f(v())
    ]
};
async function qs(r) {
    let { aptosConfig: e, creator: t, propertyKey: n, digitalAssetAddress: i, digitalAssetType: o, options: s } = r;
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x4::aptos_token::remove_property",
            typeArguments: [
                _nullishCoalesce(o, ()=>Ae)
            ],
            functionArguments: [
                u.from(i),
                new S(n)
            ],
            abi: Au
        },
        options: s
    });
}
var hu = {
    typeParameters: [
        {
            constraints: [
                "key"
            ]
        }
    ],
    parameters: [
        new f(ce(new z(0))),
        new f(v()),
        new f(v()),
        C.u8()
    ]
};
async function $s(r) {
    let { aptosConfig: e, creator: t, propertyKey: n, propertyType: i, propertyValue: o, digitalAssetAddress: s, digitalAssetType: a, options: c } = r;
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x4::aptos_token::update_property",
            typeArguments: [
                _nullishCoalesce(a, ()=>Ae)
            ],
            functionArguments: [
                u.from(s),
                new S(n),
                new S(rt[i]),
                _i(o, rt[i])
            ],
            abi: hu
        },
        options: c
    });
}
var Tu = {
    typeParameters: [
        {
            constraints: [
                "key"
            ]
        },
        {
            constraints: []
        }
    ],
    parameters: [
        new f(ce(new z(0))),
        new f(v()),
        new z(1)
    ]
};
async function Ws(r) {
    let { aptosConfig: e, creator: t, propertyKey: n, propertyType: i, propertyValue: o, digitalAssetAddress: s, digitalAssetType: a, options: c } = r;
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x4::aptos_token::add_typed_property",
            typeArguments: [
                _nullishCoalesce(a, ()=>Ae),
                rt[i]
            ],
            functionArguments: [
                u.from(s),
                new S(n),
                o
            ],
            abi: Tu
        },
        options: c
    });
}
var bu = {
    typeParameters: [
        {
            constraints: [
                "key"
            ]
        },
        {
            constraints: []
        }
    ],
    parameters: [
        new f(ce(new z(0))),
        new f(v()),
        new z(1)
    ]
};
async function Qs(r) {
    let { aptosConfig: e, creator: t, propertyKey: n, propertyType: i, propertyValue: o, digitalAssetAddress: s, digitalAssetType: a, options: c } = r;
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x4::aptos_token::update_typed_property",
            typeArguments: [
                _nullishCoalesce(a, ()=>Ae),
                rt[i]
            ],
            functionArguments: [
                u.from(s),
                new S(n),
                o
            ],
            abi: bu
        },
        options: c
    });
}
function js(r, e) {
    let t = new Array;
    return e.forEach((n, i)=>{
        t.push(_i(r[i], n));
    }), t;
}
function _i(r, e) {
    let t = He(e);
    return $t(r, t, 0, []).bcsToBytes();
}
var Sr = class {
    constructor(e){
        this.config = e;
    }
    async getCollectionData(e) {
        await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "token_v2_processor"
        });
        let { creatorAddress: t, collectionName: n, options: i } = e, o = u.from(t), s = {
            collection_name: {
                _eq: n
            },
            creator_address: {
                _eq: o.toStringLong()
            }
        };
        return _optionalChain([
            i,
            'optionalAccess',
            (_168)=>_168.tokenStandard
        ]) && (s.token_standard = {
            _eq: _nullishCoalesce(_optionalChain([
                i,
                'optionalAccess',
                (_169)=>_169.tokenStandard
            ]), ()=>"v2")
        }), Qt({
            aptosConfig: this.config,
            options: {
                where: s
            }
        });
    }
    async getCollectionDataByCreatorAddressAndCollectionName(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "token_v2_processor"
        }), Us({
            aptosConfig: this.config,
            ...e
        });
    }
    async getCollectionDataByCreatorAddress(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "token_v2_processor"
        }), Ks({
            aptosConfig: this.config,
            ...e
        });
    }
    async getCollectionDataByCollectionId(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "token_v2_processor"
        }), ks({
            aptosConfig: this.config,
            ...e
        });
    }
    async getCollectionId(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "token_v2_processor"
        }), Os({
            aptosConfig: this.config,
            ...e
        });
    }
    async getDigitalAssetData(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "token_v2_processor"
        }), Ps({
            aptosConfig: this.config,
            ...e
        });
    }
    async getCurrentDigitalAssetOwnership(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "token_v2_processor"
        }), vs({
            aptosConfig: this.config,
            ...e
        });
    }
    async getOwnedDigitalAssets(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "token_v2_processor"
        }), Is({
            aptosConfig: this.config,
            ...e
        });
    }
    async getDigitalAssetActivity(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "token_v2_processor"
        }), Cs({
            aptosConfig: this.config,
            ...e
        });
    }
    async createCollectionTransaction(e) {
        return Rs({
            aptosConfig: this.config,
            ...e
        });
    }
    async mintDigitalAssetTransaction(e) {
        return Ds({
            aptosConfig: this.config,
            ...e
        });
    }
    async transferDigitalAssetTransaction(e) {
        return zs({
            aptosConfig: this.config,
            ...e
        });
    }
    async mintSoulBoundTransaction(e) {
        return Ns({
            aptosConfig: this.config,
            ...e
        });
    }
    async burnDigitalAssetTransaction(e) {
        return Fs({
            aptosConfig: this.config,
            ...e
        });
    }
    async freezeDigitalAssetTransaferTransaction(e) {
        return Gs({
            aptosConfig: this.config,
            ...e
        });
    }
    async unfreezeDigitalAssetTransaferTransaction(e) {
        return Bs({
            aptosConfig: this.config,
            ...e
        });
    }
    async setDigitalAssetDescriptionTransaction(e) {
        return Ms({
            aptosConfig: this.config,
            ...e
        });
    }
    async setDigitalAssetNameTransaction(e) {
        return Vs({
            aptosConfig: this.config,
            ...e
        });
    }
    async setDigitalAssetURITransaction(e) {
        return Ls({
            aptosConfig: this.config,
            ...e
        });
    }
    async addDigitalAssetPropertyTransaction(e) {
        return Hs({
            aptosConfig: this.config,
            ...e
        });
    }
    async removeDigitalAssetPropertyTransaction(e) {
        return qs({
            aptosConfig: this.config,
            ...e
        });
    }
    async updateDigitalAssetPropertyTransaction(e) {
        return $s({
            aptosConfig: this.config,
            ...e
        });
    }
    async addDigitalAssetTypedPropertyTransaction(e) {
        return Ws({
            aptosConfig: this.config,
            ...e
        });
    }
    async updateDigitalAssetTypedPropertyTransaction(e) {
        return Qs({
            aptosConfig: this.config,
            ...e
        });
    }
};
var Js = 300, wu = (r)=>{
    if (r && r.length > Js) throw new Error(`Event type length exceeds the maximum length of ${Js}`);
};
async function Xs(r) {
    let { aptosConfig: e, eventType: t, options: n } = r, i = {
        _or: [
            {
                account_address: {
                    _eq: t.split("::")[0]
                }
            },
            {
                account_address: {
                    _eq: "0x0000000000000000000000000000000000000000000000000000000000000000"
                },
                sequence_number: {
                    _eq: 0
                },
                creation_number: {
                    _eq: 0
                }
            }
        ],
        indexed_type: {
            _eq: t
        }
    };
    return xr({
        aptosConfig: e,
        options: {
            ...n,
            where: i
        }
    });
}
async function Ys(r) {
    let { accountAddress: e, aptosConfig: t, creationNumber: n, options: i } = r, s = {
        account_address: {
            _eq: u.from(e).toStringLong()
        },
        creation_number: {
            _eq: n
        }
    };
    return xr({
        aptosConfig: t,
        options: {
            ...i,
            where: s
        }
    });
}
async function Zs(r) {
    let { accountAddress: e, aptosConfig: t, eventType: n, options: i } = r, s = {
        account_address: {
            _eq: u.from(e).toStringLong()
        },
        indexed_type: {
            _eq: n
        }
    };
    return xr({
        aptosConfig: t,
        options: {
            ...i,
            where: s
        }
    });
}
async function xr(r) {
    let { aptosConfig: e, options: t } = r;
    wu(_optionalChain([
        t,
        'optionalAccess',
        (_170)=>_170.where,
        'optionalAccess',
        (_171)=>_171.indexed_type,
        'optionalAccess',
        (_172)=>_172._eq
    ]));
    let n = {
        query: Uo,
        variables: {
            where_condition: _optionalChain([
                t,
                'optionalAccess',
                (_173)=>_173.where
            ]),
            offset: _optionalChain([
                t,
                'optionalAccess',
                (_174)=>_174.offset
            ]),
            limit: _optionalChain([
                t,
                'optionalAccess',
                (_175)=>_175.limit
            ]),
            order_by: _optionalChain([
                t,
                'optionalAccess',
                (_176)=>_176.orderBy
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: n,
        originMethod: "getEvents"
    })).events;
}
var Er = class {
    constructor(e){
        this.config = e;
    }
    async getModuleEventsByEventType(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "events_processor"
        }), Xs({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountEventsByCreationNumber(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "events_processor"
        }), Ys({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountEventsByEventType(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "events_processor"
        }), Zs({
            aptosConfig: this.config,
            ...e
        });
    }
    async getEvents(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: _optionalChain([
                e,
                'optionalAccess',
                (_177)=>_177.minimumLedgerVersion
            ]),
            processorType: "events_processor"
        }), xr({
            aptosConfig: this.config,
            ...e
        });
    }
};
async function ea(r) {
    let { aptosConfig: e, accountAddress: t, amount: n, options: i } = r, o = _optionalChain([
        i,
        'optionalAccess',
        (_178)=>_178.timeoutSecs
    ]) || 20, { data: s } = await lo({
        aptosConfig: e,
        path: "fund",
        body: {
            address: u.from(t).toString(),
            amount: n
        },
        originMethod: "fundAccount"
    }), a = s.txn_hashes[0], c = await qt({
        aptosConfig: e,
        transactionHash: a,
        options: {
            timeoutSecs: o,
            checkSuccess: _optionalChain([
                i,
                'optionalAccess',
                (_179)=>_179.checkSuccess
            ])
        }
    });
    if (c.type === "user_transaction") return c;
    throw new Error(`Unexpected transaction received for fund account: ${c.type}`);
}
var Pr = class {
    constructor(e){
        this.config = e;
    }
    async fundAccount(e) {
        let t = await ea({
            aptosConfig: this.config,
            ...e
        });
        return (_optionalChain([
            e,
            'access',
            (_180)=>_180.options,
            'optionalAccess',
            (_181)=>_181.waitForIndexer
        ]) === void 0 || _optionalChain([
            e,
            'access',
            (_182)=>_182.options,
            'optionalAccess',
            (_183)=>_183.waitForIndexer
        ])) && await An({
            aptosConfig: this.config,
            minimumLedgerVersion: BigInt(t.version),
            processorType: "fungible_asset_processor"
        }), t;
    }
};
async function Pn(r) {
    let { aptosConfig: e, options: t } = r, n = {
        query: ko,
        variables: {
            where_condition: _optionalChain([
                t,
                'optionalAccess',
                (_184)=>_184.where
            ]),
            limit: _optionalChain([
                t,
                'optionalAccess',
                (_185)=>_185.limit
            ]),
            offset: _optionalChain([
                t,
                'optionalAccess',
                (_186)=>_186.offset
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: n,
        originMethod: "getFungibleAssetMetadata"
    })).fungible_asset_metadata;
}
async function ta(r) {
    let { aptosConfig: e, options: t } = r, n = {
        query: Ko,
        variables: {
            where_condition: _optionalChain([
                t,
                'optionalAccess',
                (_187)=>_187.where
            ]),
            limit: _optionalChain([
                t,
                'optionalAccess',
                (_188)=>_188.limit
            ]),
            offset: _optionalChain([
                t,
                'optionalAccess',
                (_189)=>_189.offset
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: n,
        originMethod: "getFungibleAssetActivities"
    })).fungible_asset_activities;
}
async function ra(r) {
    let { aptosConfig: e, options: t } = r, n = {
        query: Co,
        variables: {
            where_condition: _optionalChain([
                t,
                'optionalAccess',
                (_190)=>_190.where
            ]),
            limit: _optionalChain([
                t,
                'optionalAccess',
                (_191)=>_191.limit
            ]),
            offset: _optionalChain([
                t,
                'optionalAccess',
                (_192)=>_192.offset
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: n,
        originMethod: "getCurrentFungibleAssetBalances"
    })).current_fungible_asset_balances;
}
var _u = {
    typeParameters: [
        {
            constraints: []
        }
    ],
    parameters: [
        He("0x1::object::Object"),
        new Y,
        new W
    ]
};
async function na(r) {
    let { aptosConfig: e, sender: t, fungibleAssetMetadataAddress: n, recipient: i, amount: o, options: s } = r;
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x1::primary_fungible_store::transfer",
            typeArguments: [
                "0x1::fungible_asset::Metadata"
            ],
            functionArguments: [
                n,
                i,
                o
            ],
            abi: _u
        },
        options: s
    });
}
var vr = class {
    constructor(e){
        this.config = e;
    }
    async getFungibleAssetMetadata(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: _optionalChain([
                e,
                'optionalAccess',
                (_193)=>_193.minimumLedgerVersion
            ]),
            processorType: "fungible_asset_processor"
        }), Pn({
            aptosConfig: this.config,
            ...e
        });
    }
    async getFungibleAssetMetadataByAssetType(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: _optionalChain([
                e,
                'optionalAccess',
                (_194)=>_194.minimumLedgerVersion
            ]),
            processorType: "fungible_asset_processor"
        }), (await Pn({
            aptosConfig: this.config,
            options: {
                where: {
                    asset_type: {
                        _eq: e.assetType
                    }
                }
            }
        }))[0];
    }
    async getFungibleAssetMetadataByCreatorAddress(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: _optionalChain([
                e,
                'optionalAccess',
                (_195)=>_195.minimumLedgerVersion
            ]),
            processorType: "fungible_asset_processor"
        }), await Pn({
            aptosConfig: this.config,
            options: {
                where: {
                    creator_address: {
                        _eq: u.from(e.creatorAddress).toStringLong()
                    }
                }
            }
        });
    }
    async getFungibleAssetActivities(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: _optionalChain([
                e,
                'optionalAccess',
                (_196)=>_196.minimumLedgerVersion
            ]),
            processorType: "fungible_asset_processor"
        }), ta({
            aptosConfig: this.config,
            ...e
        });
    }
    async getCurrentFungibleAssetBalances(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: _optionalChain([
                e,
                'optionalAccess',
                (_197)=>_197.minimumLedgerVersion
            ]),
            processorType: "fungible_asset_processor"
        }), ra({
            aptosConfig: this.config,
            ...e
        });
    }
    async transferFungibleAsset(e) {
        return na({
            aptosConfig: this.config,
            ...e
        });
    }
};
var Ir = class {
    constructor(e){
        this.config = e;
    }
    async getLedgerInfo() {
        return pn({
            aptosConfig: this.config
        });
    }
    async getChainId() {
        return (await this.getLedgerInfo()).chain_id;
    }
    async getBlockByVersion(e) {
        return ns({
            aptosConfig: this.config,
            ...e
        });
    }
    async getBlockByHeight(e) {
        return is({
            aptosConfig: this.config,
            ...e
        });
    }
    async view(e) {
        return fe({
            aptosConfig: this.config,
            ...e
        });
    }
    async viewJson(e) {
        return bs({
            aptosConfig: this.config,
            ...e
        });
    }
    async getChainTopUserTransactions(e) {
        return Fo({
            aptosConfig: this.config,
            ...e
        });
    }
    async queryIndexer(e) {
        return h({
            aptosConfig: this.config,
            ...e
        });
    }
    async getIndexerLastSuccessVersion() {
        return dn({
            aptosConfig: this.config
        });
    }
    async getProcessorStatus(e) {
        return ln({
            aptosConfig: this.config,
            processorType: e
        });
    }
};
var ia = [
    "A name must be between 3 and 63 characters long,",
    "and can only contain lowercase a-z, 0-9, and hyphens.",
    "A name may not start or end with a hyphen."
].join(" ");
function oa(r) {
    return !(!r || r.length < 3 || r.length > 63 || !/^[a-z\d][a-z\d-]{1,61}[a-z\d]$/.test(r));
}
function nt(r) {
    let [e, t, ...n] = r.replace(/\.apt$/, "").split(".");
    if (n.length > 0) throw new Error(`${r} is invalid. A name can only have two parts, a domain and a subdomain separated by a "."`);
    if (!oa(e)) throw new Error(`${e} is not valid. ${ia}`);
    if (t && !oa(t)) throw new Error(`${t} is not valid. ${ia}`);
    return {
        domainName: t || e,
        subdomainName: t ? e : void 0
    };
}
function sa(r) {
    if (!r) return !1;
    let e = new Date(r.domain_expiration_timestamp).getTime() < Date.now(), t = new Date(r.expiration_timestamp).getTime() < Date.now();
    return r.subdomain && e ? !1 : r.subdomain && r.subdomain_expiration_policy === 1 ? !0 : !t;
}
var Su = "0x585fc9f0f0c54183b039ffc770ca282ebd87307916c215a3e692f2f8e4305e82", xu = {
    testnet: "0x5f8fd2347449685cf41d4db97926ec3a096eaf381332be4f1318ad4d16a8497c",
    mainnet: "0x867ed1f6bf916171b1de3ee92849b8978b7d1b9e0a8cc982a3d19d535dfd9c0c",
    local: Su,
    custom: null,
    devnet: null
};
function qe(r) {
    let e = xu[r.network];
    if (!e) throw new Error(`The ANS contract is not deployed to ${r.network}`);
    return e;
}
var vn = (r)=>{
    if (r && typeof r == "object" && "vec" in r && Array.isArray(r.vec)) return r.vec[0];
};
async function aa(r) {
    let { aptosConfig: e, name: t } = r, n = qe(e), { domainName: i, subdomainName: o } = nt(t), s = await fe({
        aptosConfig: e,
        payload: {
            function: `${n}::router::get_owner_addr`,
            functionArguments: [
                i,
                o
            ]
        }
    }), a = vn(s[0]);
    return a ? u.from(a) : void 0;
}
async function ca(r) {
    let { aptosConfig: e, expiration: t, name: n, sender: i, targetAddress: o, toAddress: s, options: a, transferable: c } = r, p = qe(e), { domainName: d, subdomainName: A } = nt(n), w = t.policy === "subdomain:independent" || t.policy === "subdomain:follow-domain";
    if (A && !w) throw new Error("Subdomains must have an expiration policy of either 'subdomain:independent' or 'subdomain:follow-domain'");
    if (w && !A) throw new Error(`Policy is set to ${t.policy} but no subdomain was provided`);
    if (t.policy === "domain") {
        let kn = _nullishCoalesce(t.years, ()=>1);
        if (kn !== 1) throw new Error("For now, names can only be registered for 1 year at a time");
        let va = kn * 31536e3;
        return await _({
            aptosConfig: e,
            sender: i.accountAddress.toString(),
            data: {
                function: `${p}::router::register_domain`,
                functionArguments: [
                    d,
                    va,
                    o,
                    s
                ]
            },
            options: a
        });
    }
    if (!A) throw new Error(`${t.policy} requires a subdomain to be provided.`);
    let y = await Si({
        aptosConfig: e,
        name: d
    });
    if (!y) throw new Error("The domain does not exist");
    let x = t.policy === "subdomain:independent" ? t.expirationDate : y;
    if (x > y) throw new Error("The subdomain expiration time cannot be greater than the domain expiration time");
    return await _({
        aptosConfig: e,
        sender: i.accountAddress.toString(),
        data: {
            function: `${p}::router::register_subdomain`,
            functionArguments: [
                d,
                A,
                Math.round(x / 1e3),
                t.policy === "subdomain:follow-domain" ? 1 : 0,
                !!c,
                o,
                s
            ]
        },
        options: a
    });
}
async function Si(r) {
    let { aptosConfig: e, name: t } = r, n = qe(e), { domainName: i, subdomainName: o } = nt(t);
    try {
        let s = await fe({
            aptosConfig: e,
            payload: {
                function: `${n}::router::get_expiration`,
                functionArguments: [
                    i,
                    o
                ]
            }
        });
        return Number(s[0]) * 1e3;
    } catch (e6) {
        return;
    }
}
async function ua(r) {
    let { aptosConfig: e, address: t } = r, n = qe(e), i = await fe({
        aptosConfig: e,
        payload: {
            function: `${n}::router::get_primary_name`,
            functionArguments: [
                u.from(t).toString()
            ]
        }
    }), o = vn(i[1]), s = vn(i[0]);
    if (o) return [
        s,
        o
    ].filter(Boolean).join(".");
}
async function pa(r) {
    let { aptosConfig: e, sender: t, name: n, options: i } = r, o = qe(e);
    if (!n) return await _({
        aptosConfig: e,
        sender: t.accountAddress.toString(),
        data: {
            function: `${o}::router::clear_primary_name`,
            functionArguments: []
        },
        options: i
    });
    let { domainName: s, subdomainName: a } = nt(n);
    return await _({
        aptosConfig: e,
        sender: t.accountAddress.toString(),
        data: {
            function: `${o}::router::set_primary_name`,
            functionArguments: [
                s,
                a
            ]
        },
        options: i
    });
}
async function da(r) {
    let { aptosConfig: e, name: t } = r, n = qe(e), { domainName: i, subdomainName: o } = nt(t), s = await fe({
        aptosConfig: e,
        payload: {
            function: `${n}::router::get_target_addr`,
            functionArguments: [
                i,
                o
            ]
        }
    }), a = vn(s[0]);
    return a ? u.from(a) : void 0;
}
async function la(r) {
    let { aptosConfig: e, sender: t, name: n, address: i, options: o } = r, s = qe(e), { domainName: a, subdomainName: c } = nt(n);
    return await _({
        aptosConfig: e,
        sender: t.accountAddress.toString(),
        data: {
            function: `${s}::router::set_target_addr`,
            functionArguments: [
                a,
                c,
                i
            ]
        },
        options: o
    });
}
async function ga(r) {
    let { aptosConfig: e, name: t } = r, { domainName: n, subdomainName: i = "" } = nt(t), a = (await h({
        aptosConfig: e,
        query: {
            query: Lt,
            variables: {
                where_condition: {
                    domain: {
                        _eq: n
                    },
                    subdomain: {
                        _eq: i
                    }
                },
                limit: 1
            }
        },
        originMethod: "getName"
    })).current_aptos_names[0];
    return a && (a = Cr(a)), sa(a) ? a : void 0;
}
async function ya(r) {
    let { aptosConfig: e, options: t, accountAddress: n } = r, i = await xi({
        aptosConfig: e
    });
    return (await h({
        aptosConfig: e,
        originMethod: "getAccountNames",
        query: {
            query: Lt,
            variables: {
                limit: _optionalChain([
                    t,
                    'optionalAccess',
                    (_198)=>_198.limit
                ]),
                offset: _optionalChain([
                    t,
                    'optionalAccess',
                    (_199)=>_199.offset
                ]),
                order_by: _optionalChain([
                    t,
                    'optionalAccess',
                    (_200)=>_200.orderBy
                ]),
                where_condition: {
                    ..._nullishCoalesce(_optionalChain([
                        r,
                        'access',
                        (_201)=>_201.options,
                        'optionalAccess',
                        (_202)=>_202.where
                    ]), ()=>({})),
                    owner_address: {
                        _eq: n.toString()
                    },
                    expiration_timestamp: {
                        _gte: i
                    }
                }
            }
        }
    })).current_aptos_names.map(Cr);
}
async function ma(r) {
    let { aptosConfig: e, options: t, accountAddress: n } = r, i = await xi({
        aptosConfig: e
    });
    return (await h({
        aptosConfig: e,
        originMethod: "getAccountDomains",
        query: {
            query: Lt,
            variables: {
                limit: _optionalChain([
                    t,
                    'optionalAccess',
                    (_203)=>_203.limit
                ]),
                offset: _optionalChain([
                    t,
                    'optionalAccess',
                    (_204)=>_204.offset
                ]),
                order_by: _optionalChain([
                    t,
                    'optionalAccess',
                    (_205)=>_205.orderBy
                ]),
                where_condition: {
                    ..._nullishCoalesce(_optionalChain([
                        r,
                        'access',
                        (_206)=>_206.options,
                        'optionalAccess',
                        (_207)=>_207.where
                    ]), ()=>({})),
                    owner_address: {
                        _eq: n.toString()
                    },
                    expiration_timestamp: {
                        _gte: i
                    },
                    subdomain: {
                        _eq: ""
                    }
                }
            }
        }
    })).current_aptos_names.map(Cr);
}
async function fa(r) {
    let { aptosConfig: e, options: t, accountAddress: n } = r, i = await xi({
        aptosConfig: e
    });
    return (await h({
        aptosConfig: e,
        originMethod: "getAccountSubdomains",
        query: {
            query: Lt,
            variables: {
                limit: _optionalChain([
                    t,
                    'optionalAccess',
                    (_208)=>_208.limit
                ]),
                offset: _optionalChain([
                    t,
                    'optionalAccess',
                    (_209)=>_209.offset
                ]),
                order_by: _optionalChain([
                    t,
                    'optionalAccess',
                    (_210)=>_210.orderBy
                ]),
                where_condition: {
                    ..._nullishCoalesce(_optionalChain([
                        r,
                        'access',
                        (_211)=>_211.options,
                        'optionalAccess',
                        (_212)=>_212.where
                    ]), ()=>({})),
                    owner_address: {
                        _eq: n.toString()
                    },
                    expiration_timestamp: {
                        _gte: i
                    },
                    subdomain: {
                        _neq: ""
                    }
                }
            }
        }
    })).current_aptos_names.map(Cr);
}
async function Aa(r) {
    let { aptosConfig: e, options: t, domain: n } = r;
    return (await h({
        aptosConfig: e,
        originMethod: "getDomainSubdomains",
        query: {
            query: Lt,
            variables: {
                limit: _optionalChain([
                    t,
                    'optionalAccess',
                    (_213)=>_213.limit
                ]),
                offset: _optionalChain([
                    t,
                    'optionalAccess',
                    (_214)=>_214.offset
                ]),
                order_by: _optionalChain([
                    t,
                    'optionalAccess',
                    (_215)=>_215.orderBy
                ]),
                where_condition: {
                    ..._nullishCoalesce(_optionalChain([
                        r,
                        'access',
                        (_216)=>_216.options,
                        'optionalAccess',
                        (_217)=>_217.where
                    ]), ()=>({})),
                    domain: {
                        _eq: n
                    },
                    subdomain: {
                        _neq: ""
                    }
                }
            }
        }
    })).current_aptos_names.map(Cr).filter(sa);
}
async function xi(r) {
    let { aptosConfig: e } = r, t = qe(e), [n] = await fe({
        aptosConfig: e,
        payload: {
            function: `${t}::config::reregistration_grace_sec`,
            functionArguments: []
        }
    }), i = n / 60 / 60 / 24, o = ()=>new Date;
    return new Date(o().setDate(o().getDate() - i)).toISOString();
}
async function ha(r) {
    let { aptosConfig: e, sender: t, name: n, years: i = 1, options: o } = r, s = qe(e), a = i * 31536e3, { domainName: c, subdomainName: p } = nt(n);
    if (p) throw new Error("Subdomains cannot be renewed");
    if (i !== 1) throw new Error("Currently, only 1 year renewals are supported");
    return await _({
        aptosConfig: e,
        sender: t.accountAddress.toString(),
        data: {
            function: `${s}::router::renew_domain`,
            functionArguments: [
                c,
                a
            ]
        },
        options: o
    });
}
function Cr(r) {
    return {
        ...r,
        expiration_timestamp: new Date(r.expiration_timestamp).getTime()
    };
}
var Rr = class {
    constructor(e){
        this.config = e;
    }
    async getOwnerAddress(e) {
        return aa({
            aptosConfig: this.config,
            ...e
        });
    }
    async getExpiration(e) {
        return Si({
            aptosConfig: this.config,
            ...e
        });
    }
    async getTargetAddress(e) {
        return da({
            aptosConfig: this.config,
            ...e
        });
    }
    async setTargetAddress(e) {
        return la({
            aptosConfig: this.config,
            ...e
        });
    }
    async getPrimaryName(e) {
        return ua({
            aptosConfig: this.config,
            ...e
        });
    }
    async setPrimaryName(e) {
        return pa({
            aptosConfig: this.config,
            ...e
        });
    }
    async registerName(e) {
        return ca({
            aptosConfig: this.config,
            ...e
        });
    }
    async renewDomain(e) {
        return ha({
            aptosConfig: this.config,
            ...e
        });
    }
    async getName(e) {
        return ga({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountNames(e) {
        return ya({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountDomains(e) {
        return ma({
            aptosConfig: this.config,
            ...e
        });
    }
    async getAccountSubdomains(e) {
        return fa({
            aptosConfig: this.config,
            ...e
        });
    }
    async getDomainSubdomains(e) {
        return Aa({
            aptosConfig: this.config,
            ...e
        });
    }
};
async function Ta(r) {
    let { aptosConfig: e, poolAddress: t } = r, n = u.from(t).toStringLong(), o = await h({
        aptosConfig: e,
        query: {
            query: ni,
            variables: {
                where_condition: {
                    pool_address: {
                        _eq: n
                    }
                }
            }
        }
    });
    return o.num_active_delegator_per_pool[0] ? o.num_active_delegator_per_pool[0].num_active_delegator : 0;
}
async function ba(r) {
    let { aptosConfig: e, options: t } = r, n = {
        query: ni,
        variables: {
            order_by: _optionalChain([
                t,
                'optionalAccess',
                (_218)=>_218.orderBy
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: n
    })).num_active_delegator_per_pool;
}
async function wa(r) {
    let { aptosConfig: e, delegatorAddress: t, poolAddress: n } = r, i = {
        query: Ro,
        variables: {
            delegatorAddress: u.from(t).toStringLong(),
            poolAddress: u.from(n).toStringLong()
        }
    };
    return (await h({
        aptosConfig: e,
        query: i
    })).delegated_staking_activities;
}
var Ur = class {
    constructor(e){
        this.config = e;
    }
    async getNumberOfDelegators(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: _optionalChain([
                e,
                'optionalAccess',
                (_219)=>_219.minimumLedgerVersion
            ]),
            processorType: "stake_processor"
        }), Ta({
            aptosConfig: this.config,
            ...e
        });
    }
    async getNumberOfDelegatorsForAllPools(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: _optionalChain([
                e,
                'optionalAccess',
                (_220)=>_220.minimumLedgerVersion
            ]),
            processorType: "stake_processor"
        }), ba({
            aptosConfig: this.config,
            ...e
        });
    }
    async getDelegatedStakingActivities(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: _optionalChain([
                e,
                'optionalAccess',
                (_221)=>_221.minimumLedgerVersion
            ]),
            processorType: "stake_processor"
        }), wa({
            aptosConfig: this.config,
            ...e
        });
    }
};
var In = class {
    constructor(e){
        this.config = e;
    }
    async simple(e) {
        return _({
            aptosConfig: this.config,
            ...e
        });
    }
    async multiAgent(e) {
        return _({
            aptosConfig: this.config,
            ...e
        });
    }
};
function Ei(r, e, t) {
    let n = t.value;
    return t.value = async function(...i) {
        let [o] = i;
        if (o.transaction.feePayerAddress && !o.feePayerAuthenticator) throw new Error("You are submitting a Fee Payer transaction but missing the feePayerAuthenticator");
        return n.apply(this, i);
    }, t;
}
function Pi(r, e, t) {
    let n = t.value;
    return t.value = async function(...i) {
        return n.apply(this, i);
    }, t;
}
var jt = class {
    constructor(e){
        this.config = e;
    }
    async simple(e) {
        return wi({
            aptosConfig: this.config,
            ...e
        });
    }
    async multiAgent(e) {
        return wi({
            aptosConfig: this.config,
            ...e
        });
    }
};
_chunkF43XVDYJjs.a.call(void 0, [
    Pi
], jt.prototype, "simple", 1), _chunkF43XVDYJjs.a.call(void 0, [
    Pi
], jt.prototype, "multiAgent", 1);
var Jt = class {
    constructor(e){
        this.config = e;
    }
    async simple(e) {
        return br({
            aptosConfig: this.config,
            ...e
        });
    }
    async multiAgent(e) {
        return br({
            aptosConfig: this.config,
            ...e
        });
    }
};
_chunkF43XVDYJjs.a.call(void 0, [
    Ei
], Jt.prototype, "simple", 1), _chunkF43XVDYJjs.a.call(void 0, [
    Ei
], Jt.prototype, "multiAgent", 1);
var Cn = class {
    constructor(e, t, n, i, o){
        this.lastUncommintedNumber = null;
        this.currentNumber = null;
        this.lock = !1;
        this.aptosConfig = e, this.account = t, this.maxWaitTime = n, this.maximumInFlight = i, this.sleepTime = o;
    }
    async nextSequenceNumber() {
        for(; this.lock;)await _chunkF43XVDYJjs.b.call(void 0, this.sleepTime);
        this.lock = !0;
        let e = BigInt(0);
        try {
            if ((this.lastUncommintedNumber === null || this.currentNumber === null) && await this.initialize(), this.currentNumber - this.lastUncommintedNumber >= this.maximumInFlight) {
                await this.update();
                let t = _chunkF43XVDYJjs.d.call(void 0);
                for(; this.currentNumber - this.lastUncommintedNumber >= this.maximumInFlight;)await _chunkF43XVDYJjs.b.call(void 0, this.sleepTime), _chunkF43XVDYJjs.d.call(void 0) - t > this.maxWaitTime ? (console.warn(`Waited over 30 seconds for a transaction to commit, re-syncing ${this.account.accountAddress.toString()}`), await this.initialize()) : await this.update();
            }
            e = this.currentNumber, this.currentNumber += BigInt(1);
        } catch (t) {
            console.error("error in getting next sequence number for this account", t);
        } finally{
            this.lock = !1;
        }
        return e;
    }
    async initialize() {
        let { sequence_number: e } = await Re({
            aptosConfig: this.aptosConfig,
            accountAddress: this.account.accountAddress
        });
        this.currentNumber = BigInt(e), this.lastUncommintedNumber = BigInt(e);
    }
    async update() {
        let { sequence_number: e } = await Re({
            aptosConfig: this.aptosConfig,
            accountAddress: this.account.accountAddress
        });
        return this.lastUncommintedNumber = BigInt(e), this.lastUncommintedNumber;
    }
    async synchronize() {
        if (this.lastUncommintedNumber !== this.currentNumber) {
            for(; this.lock;)await _chunkF43XVDYJjs.b.call(void 0, this.sleepTime);
            this.lock = !0;
            try {
                await this.update();
                let e = _chunkF43XVDYJjs.d.call(void 0);
                for(; this.lastUncommintedNumber !== this.currentNumber;)_chunkF43XVDYJjs.d.call(void 0) - e > this.maxWaitTime ? (console.warn(`Waited over 30 seconds for a transaction to commit, re-syncing ${this.account.accountAddress.toString()}`), await this.initialize()) : (await _chunkF43XVDYJjs.b.call(void 0, this.sleepTime), await this.update());
            } catch (e) {
                console.error("error in synchronizing this account sequence number with the one on chain", e);
            } finally{
                this.lock = !1;
            }
        }
    }
};
var Xt = class {
    constructor(){
        this.queue = [];
        this.pendingDequeue = [];
        this.cancelled = !1;
    }
    enqueue(e) {
        if (this.cancelled = !1, this.pendingDequeue.length > 0) {
            _optionalChain([
                this,
                'access',
                (_222)=>_222.pendingDequeue,
                'access',
                (_223)=>_223.shift,
                'call',
                (_224)=>_224(),
                'optionalAccess',
                (_225)=>_225.resolve,
                'call',
                (_226)=>_226(e)
            ]);
            return;
        }
        this.queue.push(e);
    }
    async dequeue() {
        return this.queue.length > 0 ? Promise.resolve(this.queue.shift()) : new Promise((e, t)=>{
            this.pendingDequeue.push({
                resolve: e,
                reject: t
            });
        });
    }
    isEmpty() {
        return this.queue.length === 0;
    }
    cancel() {
        this.cancelled = !0, this.pendingDequeue.forEach(async ({ reject: e })=>{
            e(new Yt("Task cancelled"));
        }), this.pendingDequeue = [], this.queue.length = 0;
    }
    isCancelled() {
        return this.cancelled;
    }
    pendingDequeueLength() {
        return this.pendingDequeue.length;
    }
}, Yt = class extends Error {
};
var _a = "fulfilled", Sa = exports.TransactionWorkerEventsEnum = ((o)=>(o.TransactionSent = "transactionSent", o.TransactionSendFailed = "transactionSendFailed", o.TransactionExecuted = "transactionExecuted", o.TransactionExecutionFailed = "transactionExecutionFailed", o.ExecutionFinish = "executionFinish", o))(Sa || {}), Rn = exports.TransactionWorker = class extends _eventemitter32.default {
    constructor(t, n, i = 30, o = 100, s = 10){
        super();
        this.taskQueue = new Xt;
        this.transactionsQueue = new Xt;
        this.outstandingTransactions = new Xt;
        this.sentTransactions = [];
        this.executedTransactions = [];
        this.aptosConfig = t, this.account = n, this.started = !1, this.accountSequnceNumber = new Cn(t, n, i, o, s);
    }
    async submitNextTransaction() {
        try {
            for(;;){
                let t = await this.accountSequnceNumber.nextSequenceNumber();
                if (t === null) return;
                let n = await this.generateNextTransaction(this.account, t);
                if (!n) return;
                let i = wr({
                    aptosConfig: this.aptosConfig,
                    transaction: n,
                    signer: this.account
                });
                await this.outstandingTransactions.enqueue([
                    i,
                    t
                ]);
            }
        } catch (t) {
            if (t instanceof Yt) return;
            throw new Error(`Submit transaction failed for ${this.account.accountAddress.toString()} with error ${t}`);
        }
    }
    async processTransactions() {
        try {
            for(;;){
                let t = [], n = [], [i, o] = await this.outstandingTransactions.dequeue();
                for(t.push(i), n.push(o); !this.outstandingTransactions.isEmpty();)[i, o] = await this.outstandingTransactions.dequeue(), t.push(i), n.push(o);
                let s = await Promise.allSettled(t);
                for(let a = 0; a < s.length && a < n.length; a += 1){
                    let c = s[a];
                    o = n[a], c.status === _a ? (this.sentTransactions.push([
                        c.value.hash,
                        o,
                        null
                    ]), this.emit("transactionSent", {
                        message: `transaction hash ${c.value.hash} has been committed to chain`,
                        transactionHash: c.value.hash
                    }), await this.checkTransaction(c, o)) : (this.sentTransactions.push([
                        c.status,
                        o,
                        c.reason
                    ]), this.emit("transactionSendFailed", {
                        message: `failed to commit transaction ${this.sentTransactions.length} with error ${c.reason}`,
                        error: c.reason
                    }));
                }
                this.emit("executionFinish", {
                    message: `execute ${s.length} transactions finished`
                });
            }
        } catch (t) {
            if (t instanceof Yt) return;
            throw new Error(`Process execution failed for ${this.account.accountAddress.toString()} with error ${t}`);
        }
    }
    async checkTransaction(t, n) {
        try {
            let i = [];
            i.push(qt({
                aptosConfig: this.aptosConfig,
                transactionHash: t.value.hash
            }));
            let o = await Promise.allSettled(i);
            for(let s = 0; s < o.length; s += 1){
                let a = o[s];
                a.status === _a ? (this.executedTransactions.push([
                    a.value.hash,
                    n,
                    null
                ]), this.emit("transactionExecuted", {
                    message: `transaction hash ${a.value.hash} has been executed on chain`,
                    transactionHash: t.value.hash
                })) : (this.executedTransactions.push([
                    a.status,
                    n,
                    a.reason
                ]), this.emit("transactionExecutionFailed", {
                    message: `failed to execute transaction ${this.executedTransactions.length} with error ${a.reason}`,
                    error: a.reason
                }));
            }
        } catch (i) {
            throw new Error(`Check transaction failed for ${this.account.accountAddress.toString()} with error ${i}`);
        }
    }
    async push(t, n) {
        this.transactionsQueue.enqueue([
            t,
            n
        ]);
    }
    async generateNextTransaction(t, n) {
        if (this.transactionsQueue.isEmpty()) return;
        let [i, o] = await this.transactionsQueue.dequeue();
        return _({
            aptosConfig: this.aptosConfig,
            sender: t.accountAddress,
            data: i,
            options: {
                ...o,
                accountSequenceNumber: n
            }
        });
    }
    async run() {
        try {
            for(; !this.taskQueue.isCancelled();)await (await this.taskQueue.dequeue())();
        } catch (t) {
            throw new Error(`Unable to start transaction batching: ${t}`);
        }
    }
    start() {
        if (this.started) throw new Error("worker has already started");
        this.started = !0, this.taskQueue.enqueue(()=>this.submitNextTransaction()), this.taskQueue.enqueue(()=>this.processTransactions()), this.run();
    }
    stop() {
        if (this.taskQueue.isCancelled()) throw new Error("worker has already stopped");
        this.started = !1, this.taskQueue.cancel();
    }
};
var Un = class extends _eventemitter32.default {
    constructor(e){
        super(), this.config = e;
    }
    start(e) {
        let { sender: t } = e;
        this.account = t, this.transactionWorker = new Rn(this.config, t), this.transactionWorker.start(), this.registerToEvents();
    }
    push(e) {
        let { data: t, options: n } = e;
        for (let i of t)this.transactionWorker.push(i, n);
    }
    registerToEvents() {
        this.transactionWorker.on("transactionSent", async (e)=>{
            this.emit("transactionSent", e);
        }), this.transactionWorker.on("transactionSendFailed", async (e)=>{
            this.emit("transactionSendFailed", e);
        }), this.transactionWorker.on("transactionExecuted", async (e)=>{
            this.emit("transactionExecuted", e);
        }), this.transactionWorker.on("transactionExecutionFailed", async (e)=>{
            this.emit("transactionExecutionFailed", e);
        }), this.transactionWorker.on("executionFinish", async (e)=>{
            this.emit("executionFinish", e);
        });
    }
    forSingleAccount(e) {
        try {
            let { sender: t, data: n, options: i } = e;
            this.start({
                sender: t
            }), this.push({
                data: n,
                options: i
            });
        } catch (t) {
            throw new Error(`failed to submit transactions with error: ${t}`);
        }
    }
};
var Kr = class {
    constructor(e){
        this.config = e, this.build = new In(this.config), this.simulate = new jt(this.config), this.submit = new Jt(this.config), this.batch = new Un(this.config);
    }
    async getTransactions(e) {
        return ci({
            aptosConfig: this.config,
            ...e
        });
    }
    async getTransactionByVersion(e) {
        return ts({
            aptosConfig: this.config,
            ...e
        });
    }
    async getTransactionByHash(e) {
        return fr({
            aptosConfig: this.config,
            ...e
        });
    }
    async isPendingTransaction(e) {
        return rs({
            aptosConfig: this.config,
            ...e
        });
    }
    async waitForTransaction(e) {
        return qt({
            aptosConfig: this.config,
            ...e
        });
    }
    async getGasPriceEstimation() {
        return fn({
            aptosConfig: this.config
        });
    }
    getSigningMessage(e) {
        return ws(e);
    }
    async publishPackageTransaction(e) {
        return Ss({
            aptosConfig: this.config,
            ...e
        });
    }
    async rotateAuthKey(e) {
        return xs({
            aptosConfig: this.config,
            ...e
        });
    }
    sign(e) {
        return xn({
            ...e
        });
    }
    signAsFeePayer(e) {
        return En({
            ...e
        });
    }
    async batchTransactionsForSingleAccount(e) {
        try {
            let { sender: t, data: n, options: i } = e;
            this.batch.forSingleAccount({
                sender: t,
                data: n,
                options: i
            });
        } catch (t) {
            throw new Error(`failed to submit transactions with error: ${t}`);
        }
    }
    async signAndSubmitTransaction(e) {
        return wr({
            aptosConfig: this.config,
            ...e
        });
    }
    async signAndSubmitAsFeePayer(e) {
        return _s({
            aptosConfig: this.config,
            ...e
        });
    }
};
var kr = class {
    constructor(e){
        this.config = e;
    }
    async getTableItem(e) {
        return gn({
            aptosConfig: this.config,
            ...e
        });
    }
    async getTableItemsData(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "default_processor"
        }), Go({
            aptosConfig: this.config,
            ...e
        });
    }
    async getTableItemsMetadata(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "default_processor"
        }), Bo({
            aptosConfig: this.config,
            ...e
        });
    }
};
async function Kn(r) {
    let { aptosConfig: e, jwt: t, ephemeralKeyPair: n, uidKey: i = "sub", derivationPath: o } = r, s = {
        jwt_b64: t,
        epk: n.getPublicKey().bcsToHex().toStringWithoutPrefix(),
        exp_date_secs: n.expiryDateSecs,
        epk_blinder: g.fromHexInput(n.blinder).toStringWithoutPrefix(),
        uid_key: i,
        derivation_path: o
    }, { data: a } = await go({
        aptosConfig: e,
        path: "fetch",
        body: s,
        originMethod: "getPepper",
        overrides: {
            WITH_CREDENTIALS: !1
        }
    });
    return g.fromHexInput(a.pepper).toUint8Array();
}
async function vi(r) {
    let { aptosConfig: e, jwt: t, ephemeralKeyPair: n, pepper: i = await Kn(r), uidKey: o = "sub", maxExpHorizonSecs: s = (await ar({
        aptosConfig: e
    })).maxExpHorizonSecs } = r;
    if (g.fromHexInput(i).toUint8Array().length !== Vt.PEPPER_LENGTH) throw new Error(`Pepper needs to be ${Vt.PEPPER_LENGTH} bytes`);
    let a = _jwtdecode.jwtDecode.call(void 0, t);
    if (typeof a.iat != "number") throw new Error("iat was not found");
    if (s < n.expiryDateSecs - a.iat) throw Error(`The EphemeralKeyPair is too long lived.  It's lifespan must be less than ${s}`);
    let c = {
        jwt_b64: t,
        epk: n.getPublicKey().bcsToHex().toStringWithoutPrefix(),
        epk_blinder: g.fromHexInput(n.blinder).toStringWithoutPrefix(),
        exp_date_secs: n.expiryDateSecs,
        exp_horizon_secs: s,
        pepper: g.fromHexInput(i).toStringWithoutPrefix(),
        uid_key: o
    }, { data: p } = await yo({
        aptosConfig: e,
        path: "prove",
        body: c,
        originMethod: "getProof",
        overrides: {
            WITH_CREDENTIALS: !1
        }
    }), d = p.proof, A = new Ut({
        a: d.a,
        b: d.b,
        c: d.c
    });
    return new ze({
        proof: new Kt(A, 0),
        trainingWheelsSignature: Ee.fromHex(p.training_wheels_signature),
        expHorizonSecs: s
    });
}
async function xa(r) {
    let { aptosConfig: e, jwt: t, jwkAddress: n, uidKey: i, proofFetchCallback: o, pepper: s = await Kn(r) } = r, { verificationKey: a, maxExpHorizonSecs: c } = await ar({
        aptosConfig: e
    }), p = vi({
        ...r,
        pepper: s,
        maxExpHorizonSecs: c
    }), d = o ? p : await p;
    if (n !== void 0) {
        let y = ee.fromJwtAndPepper({
            jwt: t,
            pepper: s,
            jwkAddress: n,
            uidKey: i
        }), x = await Ht({
            aptosConfig: e,
            authenticationKey: y.authKey().derivedAddress()
        });
        return an.create({
            ...r,
            address: x,
            proof: d,
            pepper: s,
            proofFetchCallback: o,
            jwkAddress: n,
            verificationKey: a
        });
    }
    let A = O.fromJwtAndPepper({
        jwt: t,
        pepper: s,
        uidKey: i
    }), w = await Ht({
        aptosConfig: e,
        authenticationKey: A.authKey().derivedAddress()
    });
    return Vt.create({
        ...r,
        address: w,
        proof: d,
        pepper: s,
        proofFetchCallback: o,
        verificationKey: a
    });
}
async function Ea(r) {
    let { aptosConfig: e, sender: t, iss: n, options: i } = r, { jwksUrl: o } = r;
    o === void 0 && (ao.test(n) ? o = "https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com" : o = n.endsWith("/") ? `${n}.well-known/jwks.json` : `${n}/.well-known/jwks.json`);
    let s;
    try {
        if (s = await fetch(o), !s.ok) throw new Error(`${s.status} ${s.statusText}`);
    } catch (c) {
        let p;
        throw c instanceof Error ? p = `${c.message}` : p = `error unknown - ${c}`, K.fromErrorType({
            type: 14,
            details: `Failed to fetch JWKS at ${o}: ${p}`
        });
    }
    let a = await s.json();
    return _({
        aptosConfig: e,
        sender: t.accountAddress,
        data: {
            function: "0x1::jwks::update_federated_jwk_set",
            functionArguments: [
                n,
                b.MoveString(a.keys.map((c)=>c.kid)),
                b.MoveString(a.keys.map((c)=>c.alg)),
                b.MoveString(a.keys.map((c)=>c.e)),
                b.MoveString(a.keys.map((c)=>c.n))
            ]
        },
        options: i
    });
}
var Or = class {
    constructor(e){
        this.config = e;
    }
    async getPepper(e) {
        return Kn({
            aptosConfig: this.config,
            ...e
        });
    }
    async getProof(e) {
        return vi({
            aptosConfig: this.config,
            ...e
        });
    }
    async deriveKeylessAccount(e) {
        return xa({
            aptosConfig: this.config,
            ...e
        });
    }
    async updateFederatedKeylessJwkSetTransaction(e) {
        return Ea({
            aptosConfig: this.config,
            ...e
        });
    }
};
async function Iu(r) {
    let { aptosConfig: e, options: t } = r, n = {
        query: un,
        variables: {
            where_condition: _optionalChain([
                t,
                'optionalAccess',
                (_227)=>_227.where
            ]),
            offset: _optionalChain([
                t,
                'optionalAccess',
                (_228)=>_228.offset
            ]),
            limit: _optionalChain([
                t,
                'optionalAccess',
                (_229)=>_229.limit
            ]),
            order_by: _optionalChain([
                t,
                'optionalAccess',
                (_230)=>_230.orderBy
            ])
        }
    };
    return (await h({
        aptosConfig: e,
        query: n,
        originMethod: "getObjectData"
    })).current_objects;
}
async function Pa(r) {
    let { aptosConfig: e, objectAddress: t, options: n } = r, o = {
        object_address: {
            _eq: u.from(t).toStringLong()
        }
    };
    return (await Iu({
        aptosConfig: e,
        options: {
            ...n,
            where: o
        }
    }))[0];
}
var Dr = class {
    constructor(e){
        this.config = e;
    }
    async getObjectDataByObjectAddress(e) {
        return await T({
            config: this.config,
            minimumLedgerVersion: e.minimumLedgerVersion,
            processorType: "objects_processor"
        }), Pa({
            aptosConfig: this.config,
            ...e
        });
    }
};
var te = class {
    constructor(e){
        this.config = new Sn(e), this.account = new Tr(this.config), this.ans = new Rr(this.config), this.coin = new _r(this.config), this.digitalAsset = new Sr(this.config), this.event = new Er(this.config), this.faucet = new Pr(this.config), this.fungibleAsset = new vr(this.config), this.general = new Ir(this.config), this.staking = new Ur(this.config), this.transaction = new Kr(this.config), this.table = new kr(this.config), this.keyless = new Or(this.config), this.object = new Dr(this.config);
    }
};
function pe(r, e, t) {
    Object.getOwnPropertyNames(e.prototype).forEach((n)=>{
        let i = Object.getOwnPropertyDescriptor(e.prototype, n);
        i && (i.value = function(...o) {
            return this[t][n](...o);
        }, Object.defineProperty(r.prototype, n, i));
    });
}
pe(te, Tr, "account");
pe(te, Rr, "ans");
pe(te, _r, "coin");
pe(te, Sr, "digitalAsset");
pe(te, Er, "event");
pe(te, Pr, "faucet");
pe(te, vr, "fungibleAsset");
pe(te, Ir, "general");
pe(te, Ur, "staking");
pe(te, Kr, "transaction");
pe(te, kr, "table");
pe(te, Or, "keyless");
pe(te, Dr, "object");
exports.APTOS_BIP44_REGEX = Ba;
exports.APTOS_COIN = gt;
exports.APTOS_FA = oo;
exports.APTOS_HARDENED_REGEX = Ga;
exports.AbstractKeylessAccount = ue;
exports.Account = et;
exports.AccountAddress = u;
exports.AccountAuthenticator = X;
exports.AccountAuthenticatorEd25519 = Se;
exports.AccountAuthenticatorMultiEd25519 = Xr;
exports.AccountAuthenticatorMultiKey = Ie;
exports.AccountAuthenticatorNoAccountAuthenticator = Ot;
exports.AccountAuthenticatorSingleKey = ie;
exports.AccountAuthenticatorVariant = Ni;
exports.AccountPublicKey = ne;
exports.AccountSequenceNumber = Cn;
exports.AddressInvalidReason = Da;
exports.AnyPublicKey = F;
exports.AnyPublicKeyVariant = Lr;
exports.AnySignature = L;
exports.AnySignatureVariant = Fi;
exports.Aptos = te;
exports.AptosApiError = ye;
exports.AptosApiType = It;
exports.AptosConfig = Sn;
exports.AuthenticationKey = B;
exports.Bool = U;
exports.CKDPriv = Wi;
exports.ChainId = Dt;
exports.DEFAULT_MAX_GAS_AMOUNT = no;
exports.DEFAULT_TXN_EXP_SEC_FROM_NOW = io;
exports.DEFAULT_TXN_TIMEOUT_SEC = Qr;
exports.DeriveScheme = Mi;
exports.Deserializer = N;
exports.EPK_HORIZON_SECS = bg;
exports.Ed25519Account = Ft;
exports.Ed25519PrivateKey = Z;
exports.Ed25519PublicKey = P;
exports.Ed25519Signature = I;
exports.EntryFunction = At;
exports.EntryFunctionBytes = Br;
exports.EphemeralCertificate = Rt;
exports.EphemeralCertificateVariant = zn;
exports.EphemeralKeyPair = mr;
exports.EphemeralPublicKey = lt;
exports.EphemeralPublicKeyVariant = Dn;
exports.EphemeralSignature = Ee;
exports.EphemeralSignatureVariant = Gi;
exports.FIREBASE_AUTH_ISS_PATTERN = ao;
exports.FederatedKeylessAccount = an;
exports.FederatedKeylessPublicKey = ee;
exports.FeePayerRawTransaction = Tt;
exports.FixedBytes = at;
exports.Groth16VerificationKey = Zn;
exports.Groth16Zkp = Ut;
exports.HARDENED_OFFSET = Hi;
exports.Hex = g;
exports.HexInvalidReason = Ra;
exports.Identifier = R;
exports.KeyType = Ma;
exports.KeylessAccount = Vt;
exports.KeylessConfiguration = Yn;
exports.KeylessError = K;
exports.KeylessErrorCategory = gc;
exports.KeylessErrorResolutionTip = yc;
exports.KeylessErrorType = jr;
exports.KeylessPublicKey = O;
exports.KeylessSignature = De;
exports.MAX_AUD_VAL_BYTES = Tc;
exports.MAX_COMMITED_EPK_BYTES = xg;
exports.MAX_EXTRA_FIELD_BYTES = _g;
exports.MAX_ISS_VAL_BYTES = wg;
exports.MAX_JWT_HEADER_B64_BYTES = Sg;
exports.MAX_UID_KEY_BYTES = bc;
exports.MAX_UID_VAL_BYTES = wc;
exports.MimeType = Mr;
exports.ModuleId = cr;
exports.MoveAbility = Bi;
exports.MoveFunctionVisibility = Ka;
exports.MoveJWK = ei;
exports.MoveOption = J;
exports.MoveString = S;
exports.MoveVector = b;
exports.MultiAgentRawTransaction = ht;
exports.MultiAgentTransaction = on;
exports.MultiEd25519PublicKey = Pt;
exports.MultiEd25519Signature = ut;
exports.MultiKey = Ye;
exports.MultiKeyAccount = To;
exports.MultiKeySignature = Ne;
exports.MultiSig = gr;
exports.MultiSigTransactionPayload = yr;
exports.Network = $n;
exports.NetworkToChainId = Wn;
exports.NetworkToFaucetAPI = ro;
exports.NetworkToIndexerAPI = eo;
exports.NetworkToNetworkName = yl;
exports.NetworkToNodeAPI = to;
exports.NetworkToPepperAPI = Hn;
exports.NetworkToProverAPI = qn;
exports.ParsingError = Q;
exports.PrivateKey = je;
exports.PrivateKeyVariants = Vr;
exports.ProcessorType = ke;
exports.PublicKey = ct;
exports.RAW_TRANSACTION_SALT = so;
exports.RAW_TRANSACTION_WITH_DATA_SALT = Qn;
exports.RawTransaction = me;
exports.RawTransactionWithData = en;
exports.RoleType = ka;
exports.RotationProofChallenge = tn;
exports.Script = lr;
exports.ScriptTransactionArgumentVariants = er;
exports.Secp256k1PrivateKey = pt;
exports.Secp256k1PublicKey = Ke;
exports.Secp256k1Signature = dt;
exports.Serializable = l;
exports.Serialized = tr;
exports.Serializer = q;
exports.Signature = M;
exports.SignedTransaction = Le;
exports.SigningScheme = he;
exports.SigningSchemeInput = Gn;
exports.SimpleTransaction = nn;
exports.SingleKeyAccount = Gt;
exports.StructTag = Ce;
exports.TransactionAndProof = ri;
exports.TransactionAuthenticator = Ve;
exports.TransactionAuthenticatorEd25519 = bt;
exports.TransactionAuthenticatorFeePayer = _t;
exports.TransactionAuthenticatorMultiAgent = wt;
exports.TransactionAuthenticatorMultiEd25519 = rn;
exports.TransactionAuthenticatorSingleSender = Ze;
exports.TransactionAuthenticatorVariant = zi;
exports.TransactionPayload = ft;
exports.TransactionPayloadEntryFunction = pr;
exports.TransactionPayloadMultiSig = dr;
exports.TransactionPayloadScript = ur;
exports.TransactionPayloadVariants = Oi;
exports.TransactionResponseType = Fn;
exports.TransactionVariants = Di;
exports.TransactionWorker = Rn;
exports.TransactionWorkerEventsEnum = Sa;
exports.TypeTag = D;
exports.TypeTagAddress = Y;
exports.TypeTagBool = G;
exports.TypeTagGeneric = z;
exports.TypeTagParserError = H;
exports.TypeTagParserErrorType = Lc;
exports.TypeTagReference = Zr;
exports.TypeTagSigner = mt;
exports.TypeTagStruct = f;
exports.TypeTagU128 = Be;
exports.TypeTagU16 = Fe;
exports.TypeTagU256 = Me;
exports.TypeTagU32 = Ge;
exports.TypeTagU64 = W;
exports.TypeTagU8 = ae;
exports.TypeTagVariants = ki;
exports.TypeTagVector = C;
exports.U128 = we;
exports.U16 = Te;
exports.U256 = de;
exports.U32 = be;
exports.U64 = $;
exports.U8 = j;
exports.ZeroKnowledgeSig = ze;
exports.ZkProof = Kt;
exports.ZkpVariant = Nn;
exports.aptosCoinStructTag = om;
exports.aptosRequest = Jr;
exports.base64UrlDecode = _chunkF43XVDYJjs.f;
exports.bigIntToBytesLE = Yi;
exports.buildTransaction = Ti;
exports.bytesToBigIntLE = ir;
exports.checkOrConvertArgument = $t;
exports.convertAmountFromHumanReadableToOnChain = _chunkF43XVDYJjs.g;
exports.convertAmountFromOnChainToHumanReadable = _chunkF43XVDYJjs.h;
exports.convertArgument = hi;
exports.convertNumber = hn;
exports.createObjectAddress = Yr;
exports.createResourceAddress = Dy;
exports.createTokenAddress = zy;
exports.deriveKey = Bn;
exports.deriveTransactionType = ti;
exports.deserializeFromScriptArgument = Pc;
exports.ensureBoolean = On;
exports.fetchEntryFunctionAbi = ys;
exports.fetchFunctionAbi = gs;
exports.fetchViewFunctionAbi = ms;
exports.findFirstNonSignerArg = ps;
exports.floorToWholeHour = _chunkF43XVDYJjs.e;
exports.generateRawTransaction = Jc;
exports.generateSignedTransaction = bi;
exports.generateSignedTransactionForSimulation = As;
exports.generateSigningMessage = zt;
exports.generateSigningMessageForSerializable = hf;
exports.generateSigningMessageForTransaction = Nt;
exports.generateTransactionPayload = _n;
exports.generateTransactionPayloadWithABI = Wc;
exports.generateUserTransactionHash = DT;
exports.generateViewFunctionPayload = fs;
exports.generateViewFunctionPayloadWithABI = Qc;
exports.get = Jn;
exports.getAptosFullNode = V;
exports.getAptosPepperService = Ml;
exports.getAuthenticatorForSimulation = Wt;
exports.getErrorMessage = _chunkF43XVDYJjs.c;
exports.getFunctionParts = Ar;
exports.getIssAudAndUidVal = kt;
exports.getKeylessConfig = ar;
exports.getKeylessJWKs = Ao;
exports.hashStrToField = $r;
exports.hashValues = hs;
exports.hexToAsciiString = Ki;
exports.isBcsAddress = bn;
exports.isBcsBool = ui;
exports.isBcsFixedBytes = Fc;
exports.isBcsString = pi;
exports.isBcsU128 = mi;
exports.isBcsU16 = li;
exports.isBcsU256 = fi;
exports.isBcsU32 = gi;
exports.isBcsU64 = yi;
exports.isBcsU8 = di;
exports.isBlockEpilogueTransactionResponse = op;
exports.isBlockMetadataTransactionResponse = rp;
exports.isBool = ss;
exports.isCanonicalEd25519Signature = La;
exports.isEd25519Signature = sp;
exports.isEmptyOption = as;
exports.isEncodedEntryFunctionArgument = cs;
exports.isEncodedStruct = _chunkF43XVDYJjs.j;
exports.isFeePayerSignature = up;
exports.isGenesisTransactionResponse = tp;
exports.isKeylessSigner = sn;
exports.isLargeNumber = Tn;
exports.isMultiAgentSignature = cp;
exports.isMultiEd25519Signature = pp;
exports.isNumber = Nc;
exports.isPendingTransactionResponse = Zu;
exports.isScriptDataInput = us;
exports.isSecp256k1Signature = ap;
exports.isStateCheckpointTransactionResponse = np;
exports.isString = tt;
exports.isUserTransactionResponse = ep;
exports.isValidBIP44Path = qi;
exports.isValidHardenedPath = $i;
exports.isValidatorTransactionResponse = ip;
exports.mnemonicToSeed = Hr;
exports.normalizeBundle = co;
exports.nowInSeconds = _chunkF43XVDYJjs.d;
exports.objectStructTag = ce;
exports.optionStructTag = sm;
exports.outOfRangeErrorMessage = Ua;
exports.padAndPackBytesWithLen = Ln;
exports.paginateWithCursor = Ct;
exports.parseEncodedStruct = _chunkF43XVDYJjs.i;
exports.parseJwtHeader = xc;
exports.parseTypeTag = He;
exports.poseidonHash = or;
exports.post = sr;
exports.postAptosFaucet = lo;
exports.postAptosFullNode = Xe;
exports.postAptosIndexer = po;
exports.postAptosPepperService = go;
exports.postAptosProvingService = yo;
exports.promiseFulfilledStatus = _a;
exports.request = Ac;
exports.sleep = _chunkF43XVDYJjs.b;
exports.splitPath = Qi;
exports.standardizeTypeTags = wn;
exports.stringStructTag = v;
exports.throwTypeMismatch = k;
exports.validateNumberInRange = We; //# sourceMappingURL=index.js.map
}}),

};

//# sourceMappingURL=e51e1_%40aptos-labs_ts-sdk_dist_common_e67414._.js.map
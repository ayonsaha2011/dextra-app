module.exports = {

"[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/sdk.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "APPROX_DEPOSIT_RECEIPT_RENT": (()=>APPROX_DEPOSIT_RECEIPT_RENT),
    "APPROX_NFT_AUTHORITY_RENT": (()=>APPROX_NFT_AUTHORITY_RENT),
    "APPROX_POOL_RENT": (()=>APPROX_POOL_RENT),
    "APPROX_SINGLE_LISTING_RENT": (()=>APPROX_SINGLE_LISTING_RENT),
    "APPROX_SOL_ESCROW_RENT": (()=>APPROX_SOL_ESCROW_RENT),
    "APPROX_SOL_MARGIN_RENT": (()=>APPROX_SOL_MARGIN_RENT),
    "APPROX_TSWAP_RENT": (()=>APPROX_TSWAP_RENT),
    "DEPOSIT_RECEIPT_SIZE": (()=>DEPOSIT_RECEIPT_SIZE),
    "MARGIN_SIZE": (()=>MARGIN_SIZE),
    "NFT_AUTHORITY_SIZE": (()=>NFT_AUTHORITY_SIZE),
    "POOL_SIZE": (()=>POOL_SIZE),
    "SINGLE_LISTING_SIZE": (()=>SINGLE_LISTING_SIZE),
    "SNIPE_FEE_BPS": (()=>SNIPE_FEE_BPS),
    "SNIPE_MIN_FEE": (()=>SNIPE_MIN_FEE),
    "SNIPE_PROFIT_SHARE_BPS": (()=>SNIPE_PROFIT_SHARE_BPS),
    "TAKER_BROKER_PCT": (()=>TAKER_BROKER_PCT),
    "TSWAP_SIZE": (()=>TSWAP_SIZE),
    "TSwapIDL_latest": (()=>TSwapIDL_latest),
    "TSwapIDL_latest_EffSlot_Devnet": (()=>TSwapIDL_latest_EffSlot_Devnet),
    "TSwapIDL_latest_EffSlot_Mainnet": (()=>TSwapIDL_latest_EffSlot_Mainnet),
    "TSwapIDL_v0_1_32": (()=>TSwapIDL_v0_1_32),
    "TSwapIDL_v0_1_32_EffSlot_Mainnet": (()=>TSwapIDL_v0_1_32_EffSlot_Mainnet),
    "TSwapIDL_v0_2_0": (()=>TSwapIDL_v0_2_0),
    "TSwapIDL_v0_2_0_EffSlot_Mainnet": (()=>TSwapIDL_v0_2_0_EffSlot_Mainnet),
    "TSwapIDL_v0_3_0": (()=>TSwapIDL_v0_3_0),
    "TSwapIDL_v0_3_0_EffSlot_Mainnet": (()=>TSwapIDL_v0_3_0_EffSlot_Mainnet),
    "TSwapIDL_v0_3_5": (()=>TSwapIDL_v0_3_5),
    "TSwapIDL_v0_3_5_EffSlot_Mainnet": (()=>TSwapIDL_v0_3_5_EffSlot_Mainnet),
    "TSwapIDL_v1_0_0": (()=>TSwapIDL_v1_0_0),
    "TSwapIDL_v1_0_0_EffSlot_Mainnet": (()=>TSwapIDL_v1_0_0_EffSlot_Mainnet),
    "TSwapIDL_v1_1_0": (()=>TSwapIDL_v1_1_0),
    "TSwapIDL_v1_1_0_EffSlot_Mainnet": (()=>TSwapIDL_v1_1_0_EffSlot_Mainnet),
    "TSwapIDL_v1_3_0": (()=>TSwapIDL_v1_3_0),
    "TSwapIDL_v1_3_0_EffSlot_Mainnet": (()=>TSwapIDL_v1_3_0_EffSlot_Mainnet),
    "TSwapIDL_v1_4_0": (()=>TSwapIDL_v1_4_0),
    "TSwapIDL_v1_4_0_EffSlot_Mainnet": (()=>TSwapIDL_v1_4_0_EffSlot_Mainnet),
    "TSwapIDL_v1_5_0": (()=>TSwapIDL_v1_5_0),
    "TSwapIDL_v1_5_0_EffSlot_Mainnet": (()=>TSwapIDL_v1_5_0_EffSlot_Mainnet),
    "TSwapIDL_v1_6_0": (()=>TSwapIDL_v1_6_0),
    "TSwapIDL_v1_6_0_EffSlot_Mainnet": (()=>TSwapIDL_v1_6_0_EffSlot_Mainnet),
    "TSwapIDL_v1_7_0": (()=>TSwapIDL_v1_7_0),
    "TSwapIDL_v1_7_0_EffSlot_Devnet": (()=>TSwapIDL_v1_7_0_EffSlot_Devnet),
    "TSwapIDL_v1_7_0_EffSlot_Mainnet": (()=>TSwapIDL_v1_7_0_EffSlot_Mainnet),
    "TensorSwapSDK": (()=>TensorSwapSDK),
    "triageIDL": (()=>triageIDL)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$coral$2d$xyz$2b$anchor$40$0$2e$26$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$coral$2d$xyz$2f$anchor$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.26.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bn$2e$js$40$5$2e$2$2e$1$2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v0_1_32$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/idl/tensorswap_v0_1_32.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v0_2_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/idl/tensorswap_v0_2_0.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v0_3_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/idl/tensorswap_v0_3_0.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v0_3_5$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/idl/tensorswap_v0_3_5.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_0_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/idl/tensorswap_v1_0_0.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_1_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/idl/tensorswap_v1_1_0.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_3_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/idl/tensorswap_v1_3_0.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_4_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/idl/tensorswap_v1_4_0.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_5_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/idl/tensorswap_v1_5_0.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_6_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/idl/tensorswap_v1_6_0.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_7_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/idl/tensorswap_v1_7_0.js [app-route] (ecmascript)");
/*
Guide for protocol rollout: https://www.notion.so/tensor-hq/Protocol-Deployment-playbook-d345244ec21e48fb8a1f37277b38e38e
 */ // ---------------------------------------- Versioned IDLs for backwards compat when parsing.
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/idl/tensorswap.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$connection$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-hq+tensor-common@8.3.2_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54/node_modules/@tensor-hq/tensor-common/dist/esm/solana_contrib/connection.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/common.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-hq+tensor-common@8.3.2_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54/node_modules/@tensor-hq/tensor-common/dist/esm/solana_contrib/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/constants.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$coral$2d$xyz$2b$anchor$40$0$2e$26$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$coral$2d$xyz$2f$anchor$2f$dist$2f$esm$2f$program$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.26.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/program/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$anchor$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-hq+tensor-common@8.3.2_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54/node_modules/@tensor-hq/tensor-common/dist/esm/solana_contrib/anchor.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$coral$2d$xyz$2b$anchor$40$0$2e$26$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$coral$2d$xyz$2f$anchor$2f$dist$2f$esm$2f$coder$2f$borsh$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.26.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/coder/borsh/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$coral$2d$xyz$2b$anchor$40$0$2e$26$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$coral$2d$xyz$2f$anchor$2f$dist$2f$esm$2f$program$2f$event$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@coral-xyz+anchor@0.26.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@coral-xyz/anchor/dist/esm/program/event.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/pda.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensorswap/types.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$8$2e$3$2e$2$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/uuid@8.3.2/node_modules/uuid/dist/esm-node/v4.js [app-route] (ecmascript) <export default as v4>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-hq+tensor-common@8.3.2_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54/node_modules/@tensor-hq/tensor-common/dist/esm/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensor_whitelist$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/tensor_whitelist/pda.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-hq+tensor-common@8.3.2_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54/node_modules/@tensor-hq/tensor-common/dist/esm/metaplex/token_rules.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/esm/constants.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-hq+tensor-common@8.3.2_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54/node_modules/@tensor-hq/tensor-common/dist/esm/metaplex/pdas/token_rules.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-hq+tensor-common@8.3.2_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54/node_modules/@tensor-hq/tensor-common/dist/esm/metaplex/pdas/token_metadata.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-hq+tensor-common@8.3.2_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54/node_modules/@tensor-hq/tensor-common/dist/esm/solana_contrib/transaction.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$mint$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/esm/state/mint.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@tensor-oss+tensorswap-sdk@4.5.0_bufferutil@4.0.9_encoding@0.1.13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4/node_modules/@tensor-oss/tensorswap-sdk/dist/esm/token2022.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$extensions$2f$transferHook$2f$state$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/esm/extensions/transferHook/state.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$account$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/esm/state/account.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$instructions$2f$revoke$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/esm/instructions/revoke.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$extensions$2f$extensionType$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@solana+spl-token@0.4.9_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validat_ilmfpv4naddwsas5ev266bb7ey/node_modules/@solana/spl-token/lib/esm/extensions/extensionType.js [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const TSwapIDL_v0_1_32 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v0_1_32$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"];
const TSwapIDL_v0_1_32_EffSlot_Mainnet = 150855169;
const TSwapIDL_v0_2_0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v0_2_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"];
const TSwapIDL_v0_2_0_EffSlot_Mainnet = 153016663;
const TSwapIDL_v0_3_0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v0_3_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"];
const TSwapIDL_v0_3_0_EffSlot_Mainnet = 154762923;
const TSwapIDL_v0_3_5 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v0_3_5$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"];
const TSwapIDL_v0_3_5_EffSlot_Mainnet = 154963721;
const TSwapIDL_v1_0_0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_0_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"];
const TSwapIDL_v1_0_0_EffSlot_Mainnet = 172173995;
const TSwapIDL_v1_1_0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_1_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"];
const TSwapIDL_v1_1_0_EffSlot_Mainnet = 173144552;
const TSwapIDL_v1_3_0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_3_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"];
const TSwapIDL_v1_3_0_EffSlot_Mainnet = 176096448;
const TSwapIDL_v1_4_0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_4_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"];
const TSwapIDL_v1_4_0_EffSlot_Mainnet = 177428733;
const TSwapIDL_v1_5_0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_5_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"];
const TSwapIDL_v1_5_0_EffSlot_Mainnet = 182023294;
const TSwapIDL_v1_6_0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_6_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"];
const TSwapIDL_v1_6_0_EffSlot_Mainnet = 182972833;
const TSwapIDL_v1_7_0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap_v1_7_0$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"];
const TSwapIDL_v1_7_0_EffSlot_Mainnet = 183869296; // https://solscan.io/tx/5jhCkfL622mQm6LXCmzsKbYCMHcyFjHcSLqJPV2G6HApS7iFK9UMyg7gaoeW8aUW6kPFsfAdraibpvNRe3fnSc3h
const TSwapIDL_v1_7_0_EffSlot_Devnet = 213361116; // https://solscan.io/tx/GFL7tCbYtDFyG1kVqMDoZ1RTgmE7rGrpp99Ec8ZrUEpp2xH8oMsads6bUqxDhEXQH9caJzMGSCj6ZNZ69kykJYD?cluster=devnet
const TSwapIDL_latest = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"];
const TSwapIDL_latest_EffSlot_Mainnet = 186744215; // https://solscan.io/tx/JtcwNt69DQnJt7622LJwYFBeJbaBLwuabnWLes9YdncxxPR3nsSXpH1GqLcZQKVmWQhCqrUKSueirogrBVrTK811
const TSwapIDL_latest_EffSlot_Devnet = 265356431; // https://solscan.io/tx/2Ad89TuMGGiu2QEBxcbMiso47rmiyJWJTTRUrGekaipecuWwrCm3G3KYsVGi8PWUSecuTzS8MCFKNsZMJBS1PSR3?cluster=devnet
const triageIDL = (slot, cluster)=>{
    switch(cluster){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$connection$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Cluster"].Mainnet:
            //cba to parse really old txs, this was before public launch
            if (slot < TSwapIDL_v0_1_32_EffSlot_Mainnet) return null;
            if (slot < TSwapIDL_v0_2_0_EffSlot_Mainnet) return TSwapIDL_v0_1_32;
            if (slot < TSwapIDL_v0_3_0_EffSlot_Mainnet) return TSwapIDL_v0_2_0;
            if (slot < TSwapIDL_v0_3_5_EffSlot_Mainnet) return TSwapIDL_v0_3_0;
            if (slot < TSwapIDL_v1_0_0_EffSlot_Mainnet) return TSwapIDL_v0_3_5;
            if (slot < TSwapIDL_v1_1_0_EffSlot_Mainnet) return TSwapIDL_v1_0_0;
            if (slot < TSwapIDL_v1_3_0_EffSlot_Mainnet) return TSwapIDL_v1_1_0;
            if (slot < TSwapIDL_v1_4_0_EffSlot_Mainnet) return TSwapIDL_v1_3_0;
            if (slot < TSwapIDL_v1_5_0_EffSlot_Mainnet) return TSwapIDL_v1_4_0;
            if (slot < TSwapIDL_v1_6_0_EffSlot_Mainnet) return TSwapIDL_v1_5_0;
            if (slot < TSwapIDL_v1_7_0_EffSlot_Mainnet) return TSwapIDL_v1_6_0;
            if (slot < TSwapIDL_latest_EffSlot_Mainnet) return TSwapIDL_v1_7_0;
            return TSwapIDL_latest;
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$connection$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Cluster"].Devnet:
            if (slot < TSwapIDL_v1_7_0_EffSlot_Devnet) return null;
            if (slot < TSwapIDL_latest_EffSlot_Devnet) return TSwapIDL_v1_7_0;
            return TSwapIDL_latest;
    }
};
const SNIPE_FEE_BPS = +__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"].constants.find((c)=>c.name === "SNIPE_FEE_BPS").value;
const SNIPE_PROFIT_SHARE_BPS = +__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"].constants.find((c)=>c.name === "SNIPE_PROFIT_SHARE_BPS").value;
const TAKER_BROKER_PCT = +__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"].constants.find((c)=>c.name === "TAKER_BROKER_PCT").value;
const SNIPE_MIN_FEE = 0.01 * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LAMPORTS_PER_SOL"];
const TSWAP_SIZE = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["evalMathExpr"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"].constants.find((c)=>c.name === "TSWAP_SIZE").value);
const POOL_SIZE = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["evalMathExpr"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"].constants.find((c)=>c.name === "POOL_SIZE").value);
const MARGIN_SIZE = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["evalMathExpr"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"].constants.find((c)=>c.name === "MARGIN_SIZE").value);
const SINGLE_LISTING_SIZE = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["evalMathExpr"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"].constants.find((c)=>c.name === "SINGLE_LISTING_SIZE").value);
const DEPOSIT_RECEIPT_SIZE = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["evalMathExpr"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"].constants.find((c)=>c.name === "DEPOSIT_RECEIPT_SIZE").value);
const NFT_AUTHORITY_SIZE = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["evalMathExpr"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"].constants.find((c)=>c.name === "NFT_AUTHORITY_SIZE").value);
const APPROX_TSWAP_RENT = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRentSync"])(TSWAP_SIZE);
const APPROX_POOL_RENT = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRentSync"])(POOL_SIZE);
const APPROX_SOL_MARGIN_RENT = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRentSync"])(MARGIN_SIZE);
const APPROX_SINGLE_LISTING_RENT = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRentSync"])(SINGLE_LISTING_SIZE);
const APPROX_DEPOSIT_RECEIPT_RENT = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRentSync"])(DEPOSIT_RECEIPT_SIZE);
const APPROX_NFT_AUTHORITY_RENT = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRentSync"])(NFT_AUTHORITY_SIZE);
const APPROX_SOL_ESCROW_RENT = 946560; //token account owned by the program, keep hardcoded
class TensorSwapSDK {
    program;
    discMap;
    coder;
    eventParser;
    constructor({ idl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$idl$2f$tensorswap$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["IDL"], addr = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TENSORSWAP_ADDR"], provider, coder }){
        this.program = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$coral$2d$xyz$2b$anchor$40$0$2e$26$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$coral$2d$xyz$2f$anchor$2f$dist$2f$esm$2f$program$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Program"](idl, addr, provider, coder);
        this.discMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$anchor$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["genAcctDiscHexMap"])(idl);
        this.coder = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$coral$2d$xyz$2b$anchor$40$0$2e$26$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$coral$2d$xyz$2f$anchor$2f$dist$2f$esm$2f$coder$2f$borsh$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BorshCoder"](idl);
        this.eventParser = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$coral$2d$xyz$2b$anchor$40$0$2e$26$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$coral$2d$xyz$2f$anchor$2f$dist$2f$esm$2f$program$2f$event$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["EventParser"](addr, this.coder);
    }
    // --------------------------------------- fetchers
    async fetchTSwap(tswap, commitment) {
        return await this.program.account.tSwap.fetch(tswap, commitment);
    }
    async fetchPool(pool, commitment) {
        return await this.program.account.pool.fetch(pool, commitment);
    }
    async fetchReceipt(receipt, commitment) {
        return await this.program.account.nftDepositReceipt.fetch(receipt, commitment);
    }
    async fetchSolEscrow(escrow, commitment) {
        return await this.program.account.solEscrow.fetch(escrow, commitment);
    }
    async fetchNftAuthority(authority, commitment) {
        return await this.program.account.nftAuthority.fetch(authority, commitment);
    }
    async fetchMarginAccount(marginAccount, commitment) {
        return await this.program.account.marginAccount.fetch(marginAccount, commitment);
    }
    async fetchSingleListing(singleListing, commitment) {
        return await this.program.account.singleListing.fetch(singleListing, commitment);
    }
    // --------------------------------------- account methods
    decode(acct) {
        if (!acct.owner.equals(this.program.programId)) return null;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$anchor$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["decodeAnchorAcct"])(acct, this.discMap);
    }
    // --------------------------------------- tswap methods
    //main signature: owner
    async initUpdateTSwap({ owner = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TSWAP_OWNER"], newOwner, config, feeVault, cosigner = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TSWAP_COSIGNER"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const builder = this.program.methods.initUpdateTswap(config).accounts({
            tswap: tswapPda,
            owner,
            cosigner,
            newOwner,
            //tswap itself is the default fee vault
            feeVault: feeVault ?? tswapPda,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ]
            },
            tswapPda,
            tswapBump
        };
    }
    //main signature: owner
    async withdrawTswapFee({ lamports, destination, owner = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TSWAP_OWNER"], cosigner = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TSWAP_COSIGNER"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const builder = this.program.methods.withdrawTswapFees(lamports).accounts({
            tswap: tswapPda,
            owner,
            cosigner,
            destination,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ]
            },
            tswapPda,
            tswapBump
        };
    }
    // --------------------------------------- pool methods
    //main signature: owner
    async initPool({ owner, whitelist, config, customAuthSeed, isCosigned = false, orderType = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["OrderType"].Standard, maxTakerSellCount }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const authSeed = customAuthSeed ?? TensorSwapSDK.uuidToBuffer((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$8$2e$3$2e$2$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$node$2f$v4$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])().toString());
        if (authSeed.length != 32) {
            throw new Error("bad auth seed, expect it to be length 32");
        }
        const [nftAuthPda, nftAuthBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftAuthorityPDA"])({
            authSeed
        });
        const builder = this.program.methods.initPool(config, authSeed, isCosigned, orderType, maxTakerSellCount ?? null).accounts({
            tswap: tswapPda,
            pool: poolPda,
            solEscrow: solEscrowPda,
            nftAuthority: nftAuthPda,
            whitelist,
            owner,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            authSeed,
            nftAuthPda,
            nftAuthBump,
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            solEscrowPda,
            solEscrowBump
        };
    }
    //main signature: owner
    async closePool({ owner, whitelist, config }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const poolAcc = await this.fetchPool(poolPda);
        const builder = this.program.methods.closePool(config).accounts({
            tswap: tswapPda,
            pool: poolPda,
            solEscrow: solEscrowPda,
            nftAuthority: poolAcc.nftAuthority,
            whitelist,
            owner,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            nftAuthPda: poolAcc.nftAuthority,
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            solEscrowPda,
            solEscrowBump
        };
    }
    //main signature: owner
    async editPool({ owner, whitelist, oldConfig, //(!) new config is OPTIONAL. If not passed, pool is edited IN PLACE.
    newConfig, isCosigned = null, maxTakerSellCount, mmCompoundFees = null }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [oldPoolPda, oldPoolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: oldConfig.delta,
            startingPrice: oldConfig.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(oldConfig.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(oldConfig.curveType)
        });
        const poolAcc = await this.fetchPool(oldPoolPda);
        const [oldSolEscrowPda, oldSolEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: oldPoolPda
        });
        let newPoolPda = oldPoolPda;
        let newPoolBump = oldPoolBump;
        let newSolEscrowPda = oldSolEscrowPda;
        let newSolEscrowBump = oldSolEscrowBump;
        let builder;
        //in case someone passes this in separately thinking it will affect the pool in full edit ix
        if (newConfig && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(mmCompoundFees)) {
            newConfig.mmCompoundFees = mmCompoundFees;
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(newConfig)) {
            //full edit with pool migration
            [newPoolPda, newPoolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
                tswap: tswapPda,
                owner,
                whitelist,
                delta: newConfig.delta,
                startingPrice: newConfig.startingPrice,
                poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(newConfig.poolType),
                curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(newConfig.curveType)
            });
            [newSolEscrowPda, newSolEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
                pool: newPoolPda
            });
            builder = this.program.methods.editPool(oldConfig, newConfig, isCosigned, maxTakerSellCount ?? null).accounts({
                tswap: tswapPda,
                oldPool: oldPoolPda,
                newPool: newPoolPda,
                oldSolEscrow: oldSolEscrowPda,
                newSolEscrow: newSolEscrowPda,
                nftAuthority: poolAcc.nftAuthority,
                whitelist,
                owner,
                systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
            });
        } else {
            //in place edit w/o pool migration
            builder = this.program.methods.editPoolInPlace(oldConfig, isCosigned, maxTakerSellCount ?? null, mmCompoundFees).accounts({
                tswap: tswapPda,
                pool: oldPoolPda,
                whitelist,
                owner,
                systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
            });
        }
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            nftAuthPda: poolAcc.nftAuthority,
            tswapPda,
            tswapBump,
            oldPoolPda,
            oldPoolBump,
            oldSolEscrowPda,
            oldSolEscrowBump,
            newPoolPda,
            newPoolBump,
            newSolEscrowPda,
            newSolEscrowBump
        };
    }
    // --------------------------------------- deposit/withdraw methods
    // main signature: owner
    async depositNft({ whitelist, nftMint, nftSource, owner, config, tokenProgram, /** pnft args */ meta, authData = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], ruleSetAddnCompute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RULESET_ADDN_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const [receiptPda, receiptBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftDepositReceiptPDA"])({
            nftMint
        });
        const [mintProofPda] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensor_whitelist$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMintProofPDA"])({
            mint: nftMint,
            whitelist
        });
        //pnft
        const { meta: newMeta, ownerTokenRecordBump, ownerTokenRecordPda, destTokenRecordBump, destTokenRecordPda, ruleSet, nftEditionPda, authDataSerialized } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prepPnftAccounts"])({
            connection: this.program.provider.connection,
            meta,
            nftMint,
            destAta: escrowPda,
            authData,
            sourceAta: nftSource
        });
        meta = newMeta;
        const builder = this.program.methods.depositNft(config, authDataSerialized, !!ruleSet).accounts({
            tswap: tswapPda,
            pool: poolPda,
            whitelist,
            nftMint,
            nftSource,
            nftEscrow: escrowPda,
            nftReceipt: receiptPda,
            nftMetadata: meta.address,
            owner,
            tokenProgram,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            rent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_RENT_PUBKEY"],
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            mintProof: mintProofPda,
            nftEdition: nftEditionPda,
            destTokenRecord: destTokenRecordPda,
            ownerTokenRecord: ownerTokenRecordPda,
            pnftShared: {
                authorizationRulesProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AUTH_PROGRAM_ID"],
                tokenMetadataProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TMETA_PROGRAM_ID"],
                instructions: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_INSTRUCTIONS_PUBKEY"]
            },
            authRules: ruleSet ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        const ruleSetCompute = ruleSet ? ruleSetAddnCompute : null;
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(ruleSetCompute) ? null : (compute ?? 0) + (ruleSetCompute ?? 0), priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            escrowPda,
            escrowBump,
            receiptPda,
            receiptBump,
            mintProofPda,
            ownerTokenRecordPda,
            ownerTokenRecordBump,
            destTokenRecordPda,
            destTokenRecordBump,
            nftEditionPda,
            meta
        };
    }
    // main signature: owner
    async depositSol({ whitelist, owner, config, lamports }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const builder = this.program.methods.depositSol(config, lamports).accounts({
            tswap: tswapPda,
            pool: poolPda,
            whitelist,
            solEscrow: solEscrowPda,
            owner,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            solEscrowPda,
            solEscrowBump
        };
    }
    // main signature: owner
    async withdrawNft({ whitelist, nftMint, nftDest, owner, config, tokenProgram, /** pnft args */ meta, authData = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], ruleSetAddnCompute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RULESET_ADDN_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const [receiptPda, receiptBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftDepositReceiptPDA"])({
            nftMint
        });
        //pnft
        const { meta: newMeta, ownerTokenRecordBump, ownerTokenRecordPda, destTokenRecordBump, destTokenRecordPda, ruleSet, nftEditionPda, authDataSerialized } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prepPnftAccounts"])({
            connection: this.program.provider.connection,
            meta,
            nftMint,
            destAta: nftDest,
            authData,
            sourceAta: escrowPda
        });
        meta = newMeta;
        const builder = this.program.methods.withdrawNft(config, authDataSerialized, !!ruleSet).accounts({
            tswap: tswapPda,
            pool: poolPda,
            whitelist,
            nftMint,
            nftDest,
            nftEscrow: escrowPda,
            nftReceipt: receiptPda,
            owner,
            tokenProgram,
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            rent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_RENT_PUBKEY"],
            nftMetadata: meta.address,
            nftEdition: nftEditionPda,
            destTokenRecord: destTokenRecordPda,
            ownerTokenRecord: ownerTokenRecordPda,
            pnftShared: {
                authorizationRulesProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AUTH_PROGRAM_ID"],
                tokenMetadataProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TMETA_PROGRAM_ID"],
                instructions: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_INSTRUCTIONS_PUBKEY"]
            },
            authRules: ruleSet ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        const ruleSetCompute = ruleSet ? ruleSetAddnCompute : null;
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            ...await this.clearDelegate(nftDest, owner),
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(ruleSetCompute) ? null : (compute ?? 0) + (ruleSetCompute ?? 0), priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            escrowPda,
            escrowBump,
            receiptPda,
            receiptBump,
            ownerTokenRecordBump,
            ownerTokenRecordPda,
            destTokenRecordBump,
            destTokenRecordPda,
            meta
        };
    }
    // main signature: owner
    async withdrawSol({ whitelist, owner, config, lamports }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const builder = this.program.methods.withdrawSol(config, lamports).accounts({
            tswap: tswapPda,
            pool: poolPda,
            whitelist,
            solEscrow: solEscrowPda,
            owner,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            solEscrowPda,
            solEscrowBump
        };
    }
    // main signature: owner
    async withdrawMmFee({ whitelist, owner, config, lamports }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const builder = this.program.methods.withdrawMmFee(config, lamports).accounts({
            tswap: tswapPda,
            pool: poolPda,
            whitelist,
            solEscrow: solEscrowPda,
            owner,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            solEscrowPda,
            solEscrowBump
        };
    }
    // --------------------------------------- trade (buy/sell) methods
    //main signature: buyer
    async buyNft({ whitelist, nftMint, nftBuyerAcc, owner, buyer, config, maxPrice, tokenProgram, marginNr = null, optionalRoyaltyPct = null, takerBroker = null, /** pnft args */ meta, authData = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], ruleSetAddnCompute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RULESET_ADDN_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const [receiptPda, receiptBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftDepositReceiptPDA"])({
            nftMint
        });
        const tSwapAcc = await this.fetchTSwap(tswapPda);
        //pnft
        const { meta: newMeta, creators, ownerTokenRecordBump, ownerTokenRecordPda, destTokenRecordBump, destTokenRecordPda, ruleSet, nftEditionPda, authDataSerialized } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prepPnftAccounts"])({
            connection: this.program.provider.connection,
            meta,
            nftMint,
            destAta: nftBuyerAcc,
            authData,
            sourceAta: escrowPda
        });
        meta = newMeta;
        let marginPda;
        let marginBump;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(marginNr)) {
            [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
                tswap: tswapPda,
                owner,
                marginNr
            });
        }
        const builder = this.program.methods// TODO: Proofs disabled for buys for now until tx size limit increases.
        .buyNft(config, maxPrice, !!ruleSet, authDataSerialized, optionalRoyaltyPct).accounts({
            tswap: tswapPda,
            feeVault: tSwapAcc.feeVault,
            pool: poolPda,
            whitelist,
            nftMint,
            nftMetadata: meta.address,
            nftBuyerAcc,
            nftEscrow: escrowPda,
            nftReceipt: receiptPda,
            solEscrow: solEscrowPda,
            owner,
            buyer,
            tokenProgram,
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            rent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_RENT_PUBKEY"],
            nftEdition: nftEditionPda,
            destTokenRecord: destTokenRecordPda,
            ownerTokenRecord: ownerTokenRecordPda,
            pnftShared: {
                authorizationRulesProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AUTH_PROGRAM_ID"],
                tokenMetadataProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TMETA_PROGRAM_ID"],
                instructions: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_INSTRUCTIONS_PUBKEY"]
            },
            authRules: ruleSet ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            marginAccount: marginPda ?? buyer,
            takerBroker: takerBroker ?? tSwapAcc.feeVault
        }).remainingAccounts((creators ?? []).map((c)=>{
            return {
                pubkey: c.address,
                isWritable: c.share > 0,
                isSigner: false
            };
        }));
        const ruleSetCompute = ruleSet ? ruleSetAddnCompute : null;
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            // TODO: not including as it would incur an extra RPC call on every buy tx (slower). Let's see if needed.
            // ...(await this.clearDelegate(nftBuyerAcc, buyer)),
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(ruleSetCompute) ? null : (compute ?? 0) + (ruleSetCompute ?? 0), priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            escrowPda,
            escrowBump,
            solEscrowPda,
            solEscrowBump,
            receiptPda,
            receiptBump,
            ownerTokenRecordBump,
            ownerTokenRecordPda,
            destTokenRecordBump,
            destTokenRecordPda,
            meta,
            ruleSet,
            marginBump,
            marginPda
        };
    }
    //main signature: seller
    async sellNft({ type, whitelist, nftMint, nftSellerAcc, owner, seller, config, minPrice, tokenProgram, marginNr = null, isCosigned = false, cosigner = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TSWAP_COSIGNER"], optionalRoyaltyPct = null, takerBroker = null, /** pnft args */ meta, authData = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], ruleSetAddnCompute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RULESET_ADDN_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const ownerAtaAcc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$mint$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getAssociatedTokenAddressSync"])(nftMint, owner, true, tokenProgram);
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const [receiptPda, receiptBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftDepositReceiptPDA"])({
            nftMint
        });
        const [mintProofPda] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensor_whitelist$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMintProofPDA"])({
            mint: nftMint,
            whitelist
        });
        const tSwapAcc = await this.fetchTSwap(tswapPda);
        //prepare 2 pnft account sets
        const { meta: newMeta, creators, ownerTokenRecordBump, ownerTokenRecordPda, destTokenRecordBump: escrowDestTokenRecordBump, destTokenRecordPda: escrowDestTokenRecordPda, ruleSet, nftEditionPda, authDataSerialized } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prepPnftAccounts"])({
            connection: this.program.provider.connection,
            meta,
            nftMint,
            destAta: escrowPda,
            authData,
            sourceAta: nftSellerAcc
        });
        meta = newMeta;
        // Re-use fetched meta = faster.
        const { destTokenRecordBump: tokenDestTokenRecordBump, destTokenRecordPda: tokenDestTokenRecordPda } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prepPnftAccounts"])({
            connection: this.program.provider.connection,
            meta,
            nftMint,
            destAta: ownerAtaAcc,
            authData,
            sourceAta: nftSellerAcc
        });
        let marginPda;
        let marginBump;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(marginNr)) {
            [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
                tswap: tswapPda,
                owner,
                marginNr
            });
        }
        //1.optional cosigner
        const remAcc = [];
        if (isCosigned && type === "token") {
            remAcc.push({
                pubkey: cosigner,
                isSigner: true,
                isWritable: false
            });
        }
        //2.optional creators (last)
        creators.map((c)=>{
            remAcc.push({
                pubkey: c.address,
                isWritable: c.share > 0,
                isSigner: false
            });
        });
        const shared = {
            tswap: tswapPda,
            feeVault: tSwapAcc.feeVault,
            pool: poolPda,
            whitelist,
            nftMint,
            nftMetadata: meta.address,
            nftSellerAcc,
            solEscrow: solEscrowPda,
            mintProof: mintProofPda,
            owner,
            seller
        };
        const { method, accounts } = type === "trade" ? {
            method: this.program.methods.sellNftTradePool,
            accounts: {
                nftEscrow: escrowPda,
                nftReceipt: receiptPda,
                destTokenRecord: escrowDestTokenRecordPda
            }
        } : {
            method: this.program.methods.sellNftTokenPool,
            accounts: {
                nftEscrow: escrowPda,
                ownerAtaAcc,
                destTokenRecord: tokenDestTokenRecordPda,
                tempEscrowTokenRecord: escrowDestTokenRecordPda
            }
        };
        // TODO: Proofs passed through PDA instead of ix b/c of tx limit size.
        // const builder = method(config as any, proof, minPrice)
        const builder = method(config, minPrice, !!ruleSet, authDataSerialized, optionalRoyaltyPct).accounts({
            shared,
            tokenProgram,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            rent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_RENT_PUBKEY"],
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            nftEdition: nftEditionPda,
            ownerTokenRecord: ownerTokenRecordPda,
            pnftShared: {
                authorizationRulesProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AUTH_PROGRAM_ID"],
                tokenMetadataProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TMETA_PROGRAM_ID"],
                instructions: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_INSTRUCTIONS_PUBKEY"]
            },
            authRules: ruleSet ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            marginAccount: marginPda ?? seller,
            takerBroker: takerBroker ?? tSwapAcc.feeVault,
            ...accounts
        }).remainingAccounts(remAcc);
        const ruleSetCompute = ruleSet ? ruleSetAddnCompute : null;
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(ruleSetCompute) ? null : (compute ?? 0) + (ruleSetCompute ?? 0), priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            solEscrowPda,
            solEscrowBump,
            ownerAtaAcc,
            escrowPda,
            escrowBump,
            receiptPda,
            receiptBump,
            marginPda,
            marginBump,
            ownerTokenRecordBump,
            ownerTokenRecordPda,
            destTokenRecordBump: type === "trade" ? escrowDestTokenRecordBump : tokenDestTokenRecordBump,
            destTokenRecordPda: type === "trade" ? escrowDestTokenRecordPda : tokenDestTokenRecordPda,
            meta
        };
    }
    async reallocPool({ owner, cosigner = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TSWAP_COSIGNER"], whitelist, config }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const builder = this.program.methods.reallocPool(config).accounts({
            tswap: tswapPda,
            pool: poolPda,
            whitelist,
            owner,
            cosigner,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump
        };
    }
    // --------------------------------------- margin
    //main signer: owner
    async initMarginAcc({ owner, name, desiredNr }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        let marginNr;
        let marginPda;
        let marginBump;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(desiredNr)) {
            ({ marginNr, marginPda, marginBump } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNextFreeMarginNr"])({
                connection: this.program.provider.connection,
                owner,
                tswap: tswapPda
            }));
        } else {
            marginNr = desiredNr;
            [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
                tswap: tswapPda,
                owner,
                marginNr: desiredNr
            });
        }
        const builder = this.program.methods.initMarginAccount(marginNr, name).accounts({
            tswap: tswapPda,
            marginAccount: marginPda,
            owner,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            marginPda,
            marginBump,
            marginNr
        };
    }
    //main signer: owner
    async closeMarginAcc({ marginNr, owner }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
            tswap: tswapPda,
            marginNr,
            owner
        });
        const builder = this.program.methods.closeMarginAccount().accounts({
            tswap: tswapPda,
            marginAccount: marginPda,
            owner,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            marginPda,
            marginBump
        };
    }
    //main signer: owner
    async depositMarginAcc({ marginNr, owner, amount }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
            tswap: tswapPda,
            marginNr,
            owner
        });
        const builder = this.program.methods.depositMarginAccount(amount).accounts({
            tswap: tswapPda,
            marginAccount: marginPda,
            owner,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            marginPda,
            marginBump
        };
    }
    //main signer: owner
    async withdrawMarginAcc({ marginNr, owner, amount }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
            tswap: tswapPda,
            marginNr,
            owner
        });
        const builder = this.program.methods.withdrawMarginAccount(amount).accounts({
            tswap: tswapPda,
            marginAccount: marginPda,
            owner,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            marginPda,
            marginBump
        };
    }
    //main signer: owner
    async attachPoolMargin({ config, marginNr, owner, whitelist }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
            tswap: tswapPda,
            marginNr,
            owner
        });
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const builder = this.program.methods.attachPoolToMargin(config).accounts({
            tswap: tswapPda,
            marginAccount: marginPda,
            pool: poolPda,
            whitelist,
            owner,
            solEscrow: solEscrowPda,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            marginPda,
            marginBump,
            poolPda,
            poolBump,
            solEscrowPda,
            solEscrowBump
        };
    }
    //main signer: owner
    async detachPoolMargin({ config, marginNr, owner, amount = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bn$2e$js$40$5$2e$2$2e$1$2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"](0), whitelist }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
            tswap: tswapPda,
            marginNr,
            owner
        });
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const builder = this.program.methods.detachPoolFromMargin(config, amount).accounts({
            tswap: tswapPda,
            marginAccount: marginPda,
            pool: poolPda,
            whitelist,
            owner,
            solEscrow: solEscrowPda,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            marginPda,
            marginBump,
            poolPda,
            poolBump,
            solEscrowPda,
            solEscrowBump
        };
    }
    // --------------------------------------- advanced ordering system
    //main signature cosigner
    async setPoolFreeze({ whitelist, owner, config, marginNr, freeze, cosigner = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TSWAP_COSIGNER"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
            tswap: tswapPda,
            owner,
            marginNr
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const builder = this.program.methods.setPoolFreeze(config, freeze).accounts({
            tswap: tswapPda,
            pool: poolPda,
            whitelist,
            solEscrow: solEscrowPda,
            owner,
            cosigner,
            marginAccount: marginPda,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            solEscrowPda,
            solEscrowBump,
            marginPda,
            marginBump
        };
    }
    //main signature: cosigner
    async takeSnipe({ whitelist, nftMint, nftSellerAcc, owner, seller, config, actualPrice, marginNr, tokenProgram, cosigner = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TSWAP_COSIGNER"], /** pnft args */ meta, authData = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], ruleSetAddnCompute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RULESET_ADDN_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const ownerAtaAcc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$mint$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getAssociatedTokenAddressSync"])(nftMint, owner, true, tokenProgram);
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const [receiptPda, receiptBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftDepositReceiptPDA"])({
            nftMint
        });
        const [mintProofPda] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensor_whitelist$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMintProofPDA"])({
            mint: nftMint,
            whitelist
        });
        const tSwapAcc = await this.fetchTSwap(tswapPda);
        const [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
            tswap: tswapPda,
            owner,
            marginNr
        });
        //pnft
        const { meta: newMeta, ownerTokenRecordBump, ownerTokenRecordPda, destTokenRecordBump, destTokenRecordPda, ruleSet, nftEditionPda, authDataSerialized } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prepPnftAccounts"])({
            connection: this.program.provider.connection,
            meta,
            nftMint,
            destAta: ownerAtaAcc,
            authData,
            sourceAta: nftSellerAcc
        });
        meta = newMeta;
        const remAcc = [];
        //1.optional ruleset
        if (!!ruleSet) {
            remAcc.push({
                pubkey: ruleSet,
                isSigner: false,
                isWritable: false
            });
        }
        const builder = this.program.methods.takeSnipe(config, actualPrice, authDataSerialized).accounts({
            shared: {
                tswap: tswapPda,
                feeVault: tSwapAcc.feeVault,
                pool: poolPda,
                whitelist,
                nftSellerAcc,
                nftMint,
                mintProof: mintProofPda,
                nftMetadata: meta.address,
                solEscrow: solEscrowPda,
                owner,
                seller
            },
            ownerAtaAcc,
            marginAccount: marginPda,
            cosigner,
            tokenProgram,
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            rent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_RENT_PUBKEY"],
            nftEdition: nftEditionPda,
            destTokenRecord: destTokenRecordPda,
            ownerTokenRecord: ownerTokenRecordPda,
            pnftShared: {
                authorizationRulesProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AUTH_PROGRAM_ID"],
                tokenMetadataProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TMETA_PROGRAM_ID"],
                instructions: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_INSTRUCTIONS_PUBKEY"]
            }
        }).remainingAccounts(remAcc);
        const ruleSetCompute = ruleSet ? ruleSetAddnCompute : null;
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(ruleSetCompute) ? null : (compute ?? 0) + (ruleSetCompute ?? 0), priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            solEscrowPda,
            solEscrowBump,
            ownerAtaAcc,
            escrowPda,
            escrowBump,
            receiptPda,
            receiptBump,
            marginPda,
            marginBump,
            ownerTokenRecordBump,
            ownerTokenRecordPda,
            destTokenRecordBump,
            destTokenRecordPda,
            meta,
            ruleSet
        };
    }
    // --------------------------------------- single listings
    //main signature owner + payer
    async list({ nftMint, nftSource, owner, price, tokenProgram, payer = null, /** pnft args */ meta, authData = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], ruleSetAddnCompute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RULESET_ADDN_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [singleListing, singleListingBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSingleListingPDA"])({
            nftMint
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        //pnft
        const { meta: newMeta, ownerTokenRecordBump, ownerTokenRecordPda, destTokenRecordBump, destTokenRecordPda, ruleSet, nftEditionPda, authDataSerialized } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prepPnftAccounts"])({
            connection: this.program.provider.connection,
            meta,
            nftMint,
            destAta: escrowPda,
            authData,
            sourceAta: nftSource
        });
        meta = newMeta;
        const builder = this.program.methods.list(price, authDataSerialized, !!ruleSet).accounts({
            tswap: tswapPda,
            nftMint,
            nftSource,
            nftEscrow: escrowPda,
            nftMetadata: meta.address,
            owner,
            singleListing,
            tokenProgram,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            rent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_RENT_PUBKEY"],
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            nftEdition: nftEditionPda,
            destTokenRecord: destTokenRecordPda,
            ownerTokenRecord: ownerTokenRecordPda,
            pnftShared: {
                authorizationRulesProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AUTH_PROGRAM_ID"],
                tokenMetadataProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TMETA_PROGRAM_ID"],
                instructions: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_INSTRUCTIONS_PUBKEY"]
            },
            authRules: ruleSet ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            payer: payer ?? owner
        });
        const ruleSetCompute = ruleSet ? ruleSetAddnCompute : null;
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(ruleSetCompute) ? null : (compute ?? 0) + (ruleSetCompute ?? 0), priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            escrowPda,
            escrowBump,
            ownerTokenRecordPda,
            ownerTokenRecordBump,
            destTokenRecordPda,
            destTokenRecordBump,
            nftEditionPda,
            meta,
            singleListing,
            singleListingBump
        };
    }
    // main signature: owner
    async delist({ nftMint, nftDest, owner, tokenProgram, payer = null, /** pnft args */ meta, authData = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], ruleSetAddnCompute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RULESET_ADDN_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [singleListing, singleListingBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSingleListingPDA"])({
            nftMint
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        //pnft
        const { meta: newMeta, ownerTokenRecordBump, ownerTokenRecordPda, destTokenRecordBump, destTokenRecordPda, ruleSet, nftEditionPda, authDataSerialized } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prepPnftAccounts"])({
            connection: this.program.provider.connection,
            meta,
            nftMint,
            destAta: nftDest,
            authData,
            sourceAta: escrowPda
        });
        meta = newMeta;
        const builder = this.program.methods.delist(authDataSerialized, !!ruleSet).accounts({
            tswap: tswapPda,
            singleListing,
            nftMint,
            nftDest,
            nftEscrow: escrowPda,
            owner,
            tokenProgram,
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            rent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_RENT_PUBKEY"],
            nftMetadata: meta.address,
            nftEdition: nftEditionPda,
            destTokenRecord: destTokenRecordPda,
            ownerTokenRecord: ownerTokenRecordPda,
            pnftShared: {
                authorizationRulesProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AUTH_PROGRAM_ID"],
                tokenMetadataProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TMETA_PROGRAM_ID"],
                instructions: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_INSTRUCTIONS_PUBKEY"]
            },
            authRules: ruleSet ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            payer: payer ?? owner
        });
        const ruleSetCompute = ruleSet ? ruleSetAddnCompute : null;
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            ...await this.clearDelegate(nftDest, owner),
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(ruleSetCompute) ? null : (compute ?? 0) + (ruleSetCompute ?? 0), priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            escrowPda,
            escrowBump,
            ownerTokenRecordBump,
            ownerTokenRecordPda,
            destTokenRecordBump,
            destTokenRecordPda,
            meta,
            singleListing,
            singleListingBump
        };
    }
    //main signature: buyer
    async buySingleListing({ nftMint, nftBuyerAcc, owner, buyer, maxPrice, tokenProgram, optionalRoyaltyPct = null, takerBroker = null, /** pnft args */ meta, authData = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], ruleSetAddnCompute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RULESET_ADDN_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [singleListing, singleListingBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSingleListingPDA"])({
            nftMint
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const tSwapAcc = await this.fetchTSwap(tswapPda);
        //pnft
        const { meta: newMeta, creators, ownerTokenRecordBump, ownerTokenRecordPda, destTokenRecordBump, destTokenRecordPda, ruleSet, nftEditionPda, authDataSerialized } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prepPnftAccounts"])({
            connection: this.program.provider.connection,
            meta,
            nftMint,
            destAta: nftBuyerAcc,
            authData,
            sourceAta: escrowPda
        });
        meta = newMeta;
        const builder = this.program.methods.buySingleListing(maxPrice, !!ruleSet, authDataSerialized, optionalRoyaltyPct).accounts({
            tswap: tswapPda,
            singleListing,
            feeVault: tSwapAcc.feeVault,
            nftMint,
            nftMetadata: meta.address,
            nftBuyerAcc,
            nftEscrow: escrowPda,
            owner,
            buyer,
            tokenProgram,
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            rent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_RENT_PUBKEY"],
            nftEdition: nftEditionPda,
            destTokenRecord: destTokenRecordPda,
            ownerTokenRecord: ownerTokenRecordPda,
            pnftShared: {
                authorizationRulesProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_rules$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AUTH_PROGRAM_ID"],
                tokenMetadataProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$metaplex$2f$pdas$2f$token_metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TMETA_PROGRAM_ID"],
                instructions: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_INSTRUCTIONS_PUBKEY"]
            },
            authRules: ruleSet ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            takerBroker: takerBroker ?? tSwapAcc.feeVault
        }).remainingAccounts(creators.map((c)=>{
            return {
                pubkey: c.address,
                isWritable: c.share > 0,
                isSigner: false
            };
        }));
        const ruleSetCompute = ruleSet ? ruleSetAddnCompute : null;
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            // TODO: not including as it would incur an extra RPC call on every buy tx (slower). Let's see if needed.
            // ...(await this.clearDelegate(nftBuyerAcc, buyer)),
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(ruleSetCompute) ? null : (compute ?? 0) + (ruleSetCompute ?? 0), priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            escrowPda,
            escrowBump,
            ownerTokenRecordBump,
            ownerTokenRecordPda,
            destTokenRecordBump,
            destTokenRecordPda,
            meta,
            ruleSet,
            singleListing,
            singleListingBump
        };
    }
    // main signature: owner
    async editSingleListing({ nftMint, owner, price }) {
        const [singleListing, singleListingBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSingleListingPDA"])({
            nftMint
        });
        const builder = this.program.methods.editSingleListing(price).accounts({
            singleListing,
            nftMint,
            owner,
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        return {
            builder,
            tx: {
                ixs: [
                    await builder.instruction()
                ],
                extraSigners: []
            },
            singleListing,
            singleListingBump
        };
    }
    // --------------------------------------- T22
    //main signature owner + payer
    async listT22({ nftMint, nftSource, owner, price, payer = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"], transferHook = null }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [singleListing, singleListingBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSingleListingPDA"])({
            nftMint
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const builder = this.program.methods.listT22(price).accounts({
            tswap: tswapPda,
            nftMint,
            nftSource,
            nftEscrow: escrowPda,
            owner,
            singleListing,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            payer: payer ?? owner
        });
        if (transferHook) {
            const hookAccounts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTransferHookExtraAccounts"])(this.program.provider.connection, nftMint, await builder.instruction(), transferHook.program);
            builder.remainingAccounts([
                ...hookAccounts,
                ...transferHook.remainingAccounts ?? []
            ]);
        }
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            escrowPda,
            escrowBump,
            singleListing,
            singleListingBump
        };
    }
    // main signature: owner
    async delistT22({ nftMint, nftDest, owner, payer = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"], transferHook = null }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [singleListing, singleListingBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSingleListingPDA"])({
            nftMint
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const builder = this.program.methods.delistT22().accounts({
            tswap: tswapPda,
            singleListing,
            nftMint,
            nftDest,
            nftEscrow: escrowPda,
            owner,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            rent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_RENT_PUBKEY"],
            payer: payer ?? owner
        });
        if (transferHook) {
            const hookAccounts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTransferHookExtraAccounts"])(this.program.provider.connection, nftMint, await builder.instruction(), transferHook.program);
            builder.remainingAccounts([
                ...hookAccounts,
                ...transferHook.remainingAccounts ?? []
            ]);
        }
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            ...await this.clearDelegate(nftDest, owner),
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            escrowPda,
            escrowBump,
            singleListing,
            singleListingBump
        };
    }
    //main signature: buyer
    async buySingleListingT22({ nftMint, nftBuyerAcc, owner, buyer, maxPrice, takerBroker = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"], transferHook = null }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [singleListing, singleListingBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSingleListingPDA"])({
            nftMint
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const tSwapAcc = await this.fetchTSwap(tswapPda);
        const builder = this.program.methods.buySingleListingT22(maxPrice).accounts({
            tswap: tswapPda,
            singleListing,
            feeVault: tSwapAcc.feeVault,
            nftMint,
            nftBuyerAcc,
            nftEscrow: escrowPda,
            owner,
            buyer,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            takerBroker: takerBroker ?? tSwapAcc.feeVault
        });
        if (transferHook) {
            const hookAccounts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTransferHookExtraAccounts"])(this.program.provider.connection, nftMint, await builder.instruction(), transferHook.program);
            builder.remainingAccounts([
                ...hookAccounts,
                ...transferHook.remainingAccounts ?? []
            ]);
        }
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            escrowPda,
            escrowBump,
            singleListing,
            singleListingBump
        };
    }
    //main signature: buyer
    async buyNftT22({ whitelist, nftMint, nftBuyerAcc, owner, buyer, config, maxPrice, marginNr = null, takerBroker = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"], transferHook = null }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const [receiptPda, receiptBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftDepositReceiptPDA"])({
            nftMint
        });
        const tSwapAcc = await this.fetchTSwap(tswapPda);
        let marginPda = null;
        let marginBump = null;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(marginNr)) {
            [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
                tswap: tswapPda,
                owner,
                marginNr
            });
        }
        const builder = this.program.methods// TODO: Proofs disabled for buys for now until tx size limit increases.
        .buyNftT22(config, maxPrice).accounts({
            tswap: tswapPda,
            feeVault: tSwapAcc.feeVault,
            pool: poolPda,
            whitelist,
            nftMint,
            nftBuyerAcc,
            nftEscrow: escrowPda,
            nftReceipt: receiptPda,
            solEscrow: solEscrowPda,
            owner,
            buyer,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            marginAccount: marginPda ?? buyer,
            takerBroker: takerBroker ?? tSwapAcc.feeVault
        });
        if (transferHook) {
            const hookAccounts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTransferHookExtraAccounts"])(this.program.provider.connection, nftMint, await builder.instruction(), transferHook.program);
            builder.remainingAccounts([
                ...hookAccounts,
                ...transferHook.remainingAccounts ?? []
            ]);
        }
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            escrowPda,
            escrowBump,
            solEscrowPda,
            solEscrowBump,
            receiptPda,
            receiptBump,
            marginBump,
            marginPda
        };
    }
    // main signature: owner
    async depositNftT22({ whitelist, nftMint, nftSource, owner, config, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"], transferHook = null }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const [receiptPda, receiptBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftDepositReceiptPDA"])({
            nftMint
        });
        const [mintProofPda] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensor_whitelist$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMintProofPDA"])({
            mint: nftMint,
            whitelist
        });
        const builder = this.program.methods.depositNftT22(config).accounts({
            tswap: tswapPda,
            pool: poolPda,
            whitelist,
            nftMint,
            nftSource,
            nftEscrow: escrowPda,
            nftReceipt: receiptPda,
            owner,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            mintProof: mintProofPda
        });
        if (transferHook) {
            const hookAccounts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTransferHookExtraAccounts"])(this.program.provider.connection, nftMint, await builder.instruction(), transferHook.program);
            builder.remainingAccounts([
                ...hookAccounts,
                ...transferHook.remainingAccounts ?? []
            ]);
        }
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            escrowPda,
            escrowBump,
            receiptPda,
            receiptBump,
            mintProofPda
        };
    }
    //main signature: seller
    async sellNftT22({ type, whitelist, nftMint, nftSellerAcc, owner, seller, config, minPrice, marginNr = null, isCosigned = false, cosigner = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TSWAP_COSIGNER"], takerBroker = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"], transferHook = null }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const ownerAtaAcc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$mint$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getAssociatedTokenAddressSync"])(nftMint, owner, true, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"]);
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const [receiptPda, receiptBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftDepositReceiptPDA"])({
            nftMint
        });
        const [mintProofPda] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensor_whitelist$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMintProofPDA"])({
            mint: nftMint,
            whitelist
        });
        const tSwapAcc = await this.fetchTSwap(tswapPda);
        let marginPda = null;
        let marginBump = null;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(marginNr)) {
            [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
                tswap: tswapPda,
                owner,
                marginNr
            });
        }
        //1.optional cosigner
        const remAcc = [];
        if (isCosigned && type === "token") {
            remAcc.push({
                pubkey: cosigner,
                isSigner: true,
                isWritable: false
            });
        }
        const shared = {
            tswap: tswapPda,
            feeVault: tSwapAcc.feeVault,
            pool: poolPda,
            whitelist,
            nftMint,
            nftSellerAcc,
            solEscrow: solEscrowPda,
            mintProof: mintProofPda,
            owner,
            seller
        };
        const { method, accounts } = type === "trade" ? {
            method: this.program.methods.sellNftTradePoolT22,
            accounts: {
                nftEscrow: escrowPda,
                nftReceipt: receiptPda
            }
        } : {
            method: this.program.methods.sellNftTokenPoolT22,
            accounts: {
                ownerAtaAcc,
                associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"]
            }
        };
        // TODO: Proofs passed through PDA instead of ix b/c of tx limit size.
        // const builder = method(config as any, proof, minPrice)
        const builder = method(config, minPrice).accounts({
            shared,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            marginAccount: marginPda ?? seller,
            takerBroker: takerBroker ?? tSwapAcc.feeVault,
            ...accounts
        }).remainingAccounts(remAcc);
        if (transferHook) {
            const hookAccounts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTransferHookExtraAccounts"])(this.program.provider.connection, nftMint, await builder.instruction(), transferHook.program);
            remAcc.push(...hookAccounts, ...transferHook.remainingAccounts ?? []);
        }
        builder.remainingAccounts(remAcc);
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            solEscrowPda,
            solEscrowBump,
            ownerAtaAcc,
            escrowPda,
            escrowBump,
            receiptPda,
            receiptBump,
            marginPda,
            marginBump
        };
    }
    // main signature: owner
    async withdrawNftT22({ whitelist, nftMint, nftDest, owner, config, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"], transferHook = null }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const [receiptPda, receiptBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftDepositReceiptPDA"])({
            nftMint
        });
        const builder = this.program.methods.withdrawNftT22(config).accounts({
            tswap: tswapPda,
            pool: poolPda,
            whitelist,
            nftMint,
            nftDest,
            nftEscrow: escrowPda,
            nftReceipt: receiptPda,
            owner,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId
        });
        if (transferHook) {
            const hookAccounts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getTransferHookExtraAccounts"])(this.program.provider.connection, nftMint, await builder.instruction(), transferHook.program);
            builder.remainingAccounts([
                ...hookAccounts,
                ...transferHook.remainingAccounts ?? []
            ]);
        }
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            ...await this.clearDelegate(nftDest, owner),
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            escrowPda,
            escrowBump,
            receiptPda,
            receiptBump
        };
    }
    // --------------------------------------- WNS
    //main signature owner + payer
    async wnsList({ nftMint, nftSource, owner, price, collectionMint, payer = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [singleListing, singleListingBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSingleListingPDA"])({
            nftMint
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const approveAccount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getApprovalAccount"])(nftMint);
        const distribution = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDistributionAccount"])(collectionMint);
        const extraMetas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$extensions$2f$transferHook$2f$state$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getExtraAccountMetaAddress"])(nftMint, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"]);
        const builder = this.program.methods.wnsList(price).accounts({
            tswap: tswapPda,
            nftMint,
            nftSource,
            nftEscrow: escrowPda,
            owner,
            singleListing,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            payer: payer ?? owner,
            approveAccount,
            distribution,
            distributionProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_DISTRIBUTION_PROGRAM_ID"],
            wnsProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"],
            extraMetas
        });
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            escrowPda,
            escrowBump,
            singleListing,
            singleListingBump
        };
    }
    // main signature: owner
    async wnsDelist({ nftMint, nftDest, owner, collectionMint, payer = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [singleListing, singleListingBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSingleListingPDA"])({
            nftMint
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const approveAccount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getApprovalAccount"])(nftMint);
        const distribution = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDistributionAccount"])(collectionMint);
        const extraMetas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$extensions$2f$transferHook$2f$state$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getExtraAccountMetaAddress"])(nftMint, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"]);
        const builder = this.program.methods.wnsDelist().accounts({
            tswap: tswapPda,
            singleListing,
            nftMint,
            nftDest,
            nftEscrow: escrowPda,
            owner,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            rent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SYSVAR_RENT_PUBKEY"],
            payer: payer ?? owner,
            approveAccount,
            distribution,
            distributionProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_DISTRIBUTION_PROGRAM_ID"],
            wnsProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"],
            extraMetas
        });
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            ...await this.clearDelegate(nftDest, owner),
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            escrowPda,
            escrowBump,
            singleListing,
            singleListingBump
        };
    }
    //main signature: buyer
    async wnsBuySingleListing({ nftMint, nftBuyerAcc, owner, buyer, maxPrice, collectionMint, takerBroker = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [singleListing, singleListingBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSingleListingPDA"])({
            nftMint
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const tSwapAcc = await this.fetchTSwap(tswapPda);
        const approveAccount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getApprovalAccount"])(nftMint);
        const distribution = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDistributionAccount"])(collectionMint);
        const extraMetas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$extensions$2f$transferHook$2f$state$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getExtraAccountMetaAddress"])(nftMint, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"]);
        const builder = this.program.methods.wnsBuySingleListing(maxPrice).accounts({
            tswap: tswapPda,
            singleListing,
            feeVault: tSwapAcc.feeVault,
            nftMint,
            nftBuyerAcc,
            nftEscrow: escrowPda,
            owner,
            buyer,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            takerBroker: takerBroker ?? tSwapAcc.feeVault,
            approveAccount,
            distribution,
            distributionProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_DISTRIBUTION_PROGRAM_ID"],
            wnsProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"],
            extraMetas
        });
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            escrowPda,
            escrowBump,
            singleListing,
            singleListingBump
        };
    }
    //main signature: buyer
    async wnsBuyNft({ whitelist, nftMint, nftBuyerAcc, owner, buyer, config, maxPrice, collectionMint, marginNr = null, takerBroker = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const [receiptPda, receiptBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftDepositReceiptPDA"])({
            nftMint
        });
        const tSwapAcc = await this.fetchTSwap(tswapPda);
        const approveAccount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getApprovalAccount"])(nftMint);
        const distribution = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDistributionAccount"])(collectionMint);
        const extraMetas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$extensions$2f$transferHook$2f$state$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getExtraAccountMetaAddress"])(nftMint, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"]);
        let marginPda = null;
        let marginBump = null;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(marginNr)) {
            [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
                tswap: tswapPda,
                owner,
                marginNr
            });
        }
        const builder = this.program.methods// TODO: Proofs disabled for buys for now until tx size limit increases.
        .wnsBuyNft(config, maxPrice).accounts({
            tswap: tswapPda,
            feeVault: tSwapAcc.feeVault,
            pool: poolPda,
            whitelist,
            nftMint,
            nftBuyerAcc,
            nftEscrow: escrowPda,
            nftReceipt: receiptPda,
            solEscrow: solEscrowPda,
            owner,
            buyer,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            marginAccount: marginPda ?? buyer,
            takerBroker: takerBroker ?? tSwapAcc.feeVault,
            approveAccount,
            distribution,
            distributionProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_DISTRIBUTION_PROGRAM_ID"],
            wnsProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"],
            extraMetas
        });
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            escrowPda,
            escrowBump,
            solEscrowPda,
            solEscrowBump,
            receiptPda,
            receiptBump,
            marginBump,
            marginPda
        };
    }
    // main signature: owner
    async wnsDepositNft({ whitelist, nftMint, nftSource, owner, config, collectionMint, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const [receiptPda, receiptBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftDepositReceiptPDA"])({
            nftMint
        });
        const [mintProofPda] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensor_whitelist$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMintProofPDA"])({
            mint: nftMint,
            whitelist
        });
        const approveAccount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getApprovalAccount"])(nftMint);
        const distribution = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDistributionAccount"])(collectionMint);
        const extraMetas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$extensions$2f$transferHook$2f$state$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getExtraAccountMetaAddress"])(nftMint, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"]);
        const builder = this.program.methods.wnsDepositNft(config).accounts({
            tswap: tswapPda,
            pool: poolPda,
            whitelist,
            nftMint,
            nftSource,
            nftEscrow: escrowPda,
            nftReceipt: receiptPda,
            owner,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            mintProof: mintProofPda,
            approveAccount,
            distribution,
            distributionProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_DISTRIBUTION_PROGRAM_ID"],
            wnsProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"],
            extraMetas
        });
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            escrowPda,
            escrowBump,
            receiptPda,
            receiptBump,
            mintProofPda
        };
    }
    //main signature: seller
    async wnsSellNft({ type, whitelist, nftMint, nftSellerAcc, owner, seller, config, minPrice, collectionMint, marginNr = null, isCosigned = false, cosigner = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TSWAP_COSIGNER"], takerBroker = null, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [solEscrowPda, solEscrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findSolEscrowPDA"])({
            pool: poolPda
        });
        const ownerAtaAcc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$mint$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getAssociatedTokenAddressSync"])(nftMint, owner, true, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"]);
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const [receiptPda, receiptBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftDepositReceiptPDA"])({
            nftMint
        });
        const [mintProofPda] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensor_whitelist$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMintProofPDA"])({
            mint: nftMint,
            whitelist
        });
        const tSwapAcc = await this.fetchTSwap(tswapPda);
        const approveAccount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getApprovalAccount"])(nftMint);
        const distribution = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDistributionAccount"])(collectionMint);
        const extraMetas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$extensions$2f$transferHook$2f$state$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getExtraAccountMetaAddress"])(nftMint, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"]);
        let marginPda = null;
        let marginBump = null;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(marginNr)) {
            [marginPda, marginBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findMarginPDA"])({
                tswap: tswapPda,
                owner,
                marginNr
            });
        }
        //1.optional cosigner
        const cosigned = [];
        if (isCosigned && type === "token") {
            cosigned.push({
                pubkey: cosigner,
                isSigner: true,
                isWritable: false
            });
        }
        const shared = {
            tswap: tswapPda,
            feeVault: tSwapAcc.feeVault,
            pool: poolPda,
            whitelist,
            nftMint,
            nftSellerAcc,
            solEscrow: solEscrowPda,
            mintProof: mintProofPda,
            owner,
            seller
        };
        const { method, accounts } = type === "trade" ? {
            method: this.program.methods.wnsSellNftTradePool,
            accounts: {
                nftEscrow: escrowPda,
                nftReceipt: receiptPda
            }
        } : {
            method: this.program.methods.wnsSellNftTokenPool,
            accounts: {
                ownerAtaAcc,
                associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"]
            }
        };
        // TODO: Proofs passed through PDA instead of ix b/c of tx limit size.
        // const builder = method(config as any, proof, minPrice)
        const builder = method(config, minPrice).accounts({
            shared,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            marginAccount: marginPda ?? seller,
            takerBroker: takerBroker ?? tSwapAcc.feeVault,
            approveAccount,
            distribution,
            distributionProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_DISTRIBUTION_PROGRAM_ID"],
            wnsProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"],
            extraMetas,
            ...accounts
        }).remainingAccounts(cosigned);
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            solEscrowPda,
            solEscrowBump,
            ownerAtaAcc,
            escrowPda,
            escrowBump,
            receiptPda,
            receiptBump,
            marginPda,
            marginBump
        };
    }
    // main signature: owner
    async wnsWithdrawNft({ whitelist, nftMint, nftDest, owner, config, collectionMint, compute = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_XFER_COMPUTE_UNITS"], priorityMicroLamports = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$common$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_MICRO_LAMPORTS"] }) {
        const [tswapPda, tswapBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findTSwapPDA"])({});
        const [poolPda, poolBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findPoolPDA"])({
            tswap: tswapPda,
            owner,
            whitelist,
            delta: config.delta,
            startingPrice: config.startingPrice,
            poolType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["poolTypeU8"])(config.poolType),
            curveType: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["curveTypeU8"])(config.curveType)
        });
        const [escrowPda, escrowBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftEscrowPDA"])({
            nftMint
        });
        const [receiptPda, receiptBump] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$pda$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["findNftDepositReceiptPDA"])({
            nftMint
        });
        const approveAccount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getApprovalAccount"])(nftMint);
        const distribution = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDistributionAccount"])(collectionMint);
        const extraMetas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$extensions$2f$transferHook$2f$state$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getExtraAccountMetaAddress"])(nftMint, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"]);
        const builder = this.program.methods.wnsWithdrawNft(config).accounts({
            tswap: tswapPda,
            pool: poolPda,
            whitelist,
            nftMint,
            nftDest,
            nftEscrow: escrowPda,
            nftReceipt: receiptPda,
            owner,
            tokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TOKEN_2022_PROGRAM_ID"],
            associatedTokenProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ASSOCIATED_TOKEN_PROGRAM_ID"],
            systemProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId,
            approveAccount,
            distribution,
            distributionProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_DISTRIBUTION_PROGRAM_ID"],
            wnsProgram: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WNS_PROGRAM_ID"],
            extraMetas
        });
        const ixs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$transaction$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prependComputeIxs"])([
            ...await this.clearDelegate(nftDest, owner),
            await builder.instruction()
        ], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isNullLike"])(compute) ? null : compute ?? 0, priorityMicroLamports);
        return {
            builder,
            tx: {
                ixs,
                extraSigners: []
            },
            tswapPda,
            tswapBump,
            poolPda,
            poolBump,
            escrowPda,
            escrowBump,
            receiptPda,
            receiptBump
        };
    }
    // --------------------------------------- helper methods
    // remove delegate if set, else a pNFT transfer will fail
    async clearDelegate(nftDest, owner) {
        let destAtaInfo = null;
        // putting inside a try statement because a token account might not exist onchain and this would lead to errors
        try {
            destAtaInfo = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$account$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getAccount"])(this.program.provider.connection, nftDest);
        } catch  {}
        if (!!destAtaInfo?.delegate) {
            return [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$instructions$2f$revoke$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createRevokeInstruction"])(nftDest, owner)
            ];
        }
        return [];
    }
    async getTswapRent() {
        return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRent"])(this.program.provider.connection, this.program.account.tSwap);
    }
    async getPoolRent() {
        return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRent"])(this.program.provider.connection, this.program.account.pool);
    }
    async getMarginAccountRent() {
        return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRent"])(this.program.provider.connection, this.program.account.marginAccount);
    }
    async getSingleListingRent() {
        return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRent"])(this.program.provider.connection, this.program.account.singleListing);
    }
    async getNftDepositReceiptRent() {
        return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRent"])(this.program.provider.connection, this.program.account.nftDepositReceipt);
    }
    async getNftAuthorityRent() {
        return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRent"])(this.program.provider.connection, this.program.account.nftAuthority);
    }
    async getTokenAcctRent() {
        return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$state$2f$account$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getMinimumBalanceForRentExemptAccount"])(this.program.provider.connection);
    }
    async getImmutableTokenAcctRent() {
        const accountLen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$extensions$2f$extensionType$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getAccountLen"])([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$extensions$2f$extensionType$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ExtensionType"].ImmutableOwner
        ]);
        return await this.program.provider.connection.getMinimumBalanceForRentExemption(accountLen);
    }
    async getTokenAcctRentForMint(mint, programId) {
        /* TODO: currently using fixed extensions since WNS uses extensions that are not
                 yet supported by the spl library.
    
        const mintAccount = await getMint(
          this.program.provider.connection,
          mint,
          undefined,
          programId
        );
        const accountLen = getAccountLenForMint(mintAccount);
        */ const accountLen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$extensions$2f$extensionType$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getAccountLen"])([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$spl$2d$token$40$0$2e$4$2e$9_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validat_ilmfpv4naddwsas5ev266bb7ey$2f$node_modules$2f40$solana$2f$spl$2d$token$2f$lib$2f$esm$2f$extensions$2f$extensionType$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ExtensionType"].TransferHookAccount
        ]);
        return await this.program.provider.connection.getMinimumBalanceForRentExemption(accountLen);
    }
    async getSolEscrowRent() {
        return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRent"])(this.program.provider.connection, this.program.account.solEscrow);
    }
    async getApproveRent() {
        return await this.program.provider.connection.getMinimumBalanceForRentExemption((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$token2022$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getApproveAccountLen"])());
    }
    getError(name) {
        //@ts-ignore (throwing weird ts errors for me)
        return this.program.idl.errors.find((e)=>e.name === name);
    }
    getErrorCodeHex(name) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["hexCode"])(this.getError(name).code);
    }
    // --------------------------------------- parsing raw transactions
    /** This only works for the latest IDL. This is intentional: otherwise we'll need to switch/case all historical deprecated ixs downstream. */ parseIxs(tx) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$hq$2b$tensor$2d$common$40$8$2e$3$2e$2_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderdec_ia22tnpllxpcaisfaqe6wmfy54$2f$node_modules$2f40$tensor$2d$hq$2f$tensor$2d$common$2f$dist$2f$esm$2f$solana_contrib$2f$anchor$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseAnchorIxs"])({
            tx,
            coder: this.coder,
            eventParser: this.eventParser,
            programId: this.program.programId
        });
    }
    getPoolConfig(ix) {
        // No "default": this ensures we explicitly think about how to handle new ixs.
        switch(ix.ix.name){
            case "initUpdateTswap":
            case "withdrawTswapFees":
            case "initMarginAccount":
            case "closeMarginAccount":
            case "depositMarginAccount":
            case "withdrawMarginAccount":
            case "withdrawMarginAccountCpi":
            case "withdrawMarginAccountCpiTcomp":
            case "withdrawMarginAccountCpiTlock":
            case "attachPoolToMargin":
            case "detachPoolFromMargin":
            case "takeSnipe":
            case "list":
            case "delist":
            case "buySingleListing":
            case "editSingleListing":
            case "listT22":
            case "delistT22":
            case "buySingleListingT22":
            case "wnsList":
            case "wnsDelist":
            case "wnsBuySingleListing":
                return null;
            case "editPool":
                {
                    const config = ix.ix.data.newConfig;
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["castPoolConfigAnchor"])(config);
                }
            case "initPool":
            case "closePool":
            case "depositNft":
            case "withdrawNft":
            case "depositSol":
            case "withdrawSol":
            case "withdrawMmFee":
            case "buyNft":
            case "sellNftTokenPool":
            case "sellNftTradePool":
            case "depositNftT22":
            case "withdrawNftT22":
            case "buyNftT22":
            case "sellNftTokenPoolT22":
            case "sellNftTradePoolT22":
            case "wnsDepositNft":
            case "wnsWithdrawNft":
            case "wnsBuyNft":
            case "wnsSellNftTokenPool":
            case "wnsSellNftTradePool":
            case "setPoolFreeze":
            case "editPoolInPlace":
            case "reallocPool":
                {
                    const config = ix.ix.data.config;
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tensor$2d$oss$2b$tensorswap$2d$sdk$40$4$2e$5$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_fastestsmallesttextencoderd_evajakz5lgdgo7jdqbujnk67d4$2f$node_modules$2f40$tensor$2d$oss$2f$tensorswap$2d$sdk$2f$dist$2f$esm$2f$tensorswap$2f$types$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["castPoolConfigAnchor"])(config);
                }
        }
    }
    getSolAmount(ix) {
        switch(ix.ix.name){
            case "buyNft":
            case "sellNftTradePool":
            case "sellNftTokenPool":
            case "takeSnipe":
            case "buySingleListing":
            case "buyNftT22":
            case "sellNftTokenPoolT22":
            case "sellNftTradePoolT22":
            case "buySingleListingT22":
            case "wnsBuyNft":
            case "wnsBuySingleListing":
            case "wnsSellNftTokenPool":
            case "wnsSellNftTradePool":
                {
                    // NB: the actual sell price includes the "MM fee" (really a spread).
                    const event = ix.events.find((e)=>e.name === "BuySellEvent");
                    if (!event) return null;
                    return event.data.currentPrice.sub(event.data.mmFee);
                }
            case "delist":
            case "delistT22":
            case "wnsDelist":
                {
                    const event = ix.events.find((e)=>e.name === "DelistEvent");
                    if (!event) return null;
                    return event.data.currentPrice;
                }
            case "depositSol":
            case "withdrawSol":
            case "withdrawMmFee":
            case "depositMarginAccount":
            case "withdrawMarginAccount":
            case "withdrawMarginAccountCpi":
            case "withdrawMarginAccountCpiTcomp":
            case "withdrawMarginAccountCpiTlock":
            case "withdrawTswapFees":
            case "detachPoolFromMargin":
                return ix.ix.data.lamports;
            case "list":
            case "listT22":
            case "wnsList":
            case "editSingleListing":
                return ix.ix.data.price;
            case "initUpdateTswap":
            case "initPool":
            case "closePool":
            case "depositNft":
            case "withdrawNft":
            case "editPool":
            case "editPoolInPlace":
            case "reallocPool":
            case "initMarginAccount":
            case "closeMarginAccount":
            case "setPoolFreeze":
            case "attachPoolToMargin":
            case "depositNftT22":
            case "withdrawNftT22":
            case "wnsDepositNft":
            case "wnsWithdrawNft":
                return null;
        }
    }
    getFeeAmount(ix) {
        switch(ix.ix.name){
            // No "default": this ensures we explicitly think about how to handle new ixs.
            case "buyNft":
            case "sellNftTradePool":
            case "sellNftTokenPool":
            case "takeSnipe":
            case "buySingleListing":
            case "buyNftT22":
            case "sellNftTradePoolT22":
            case "sellNftTokenPoolT22":
            case "buySingleListingT22":
            case "wnsBuyNft":
            case "wnsSellNftTradePool":
            case "wnsSellNftTokenPool":
            case "wnsBuySingleListing":
                // TODO: Think of a better way to handle multiple events.
                const event = ix.events.find((e)=>e.name === "BuySellEvent");
                if (!event) return null;
                return event.data.tswapFee.add(event.data.creatorsFee);
            case "list":
            case "delist":
            case "initUpdateTswap":
            case "withdrawTswapFees":
            case "initPool":
            case "closePool":
            case "depositNft":
            case "withdrawNft":
            case "depositSol":
            case "withdrawSol":
            case "withdrawMmFee":
            case "editPool":
            case "editPoolInPlace":
            case "reallocPool":
            case "initMarginAccount":
            case "closeMarginAccount":
            case "depositMarginAccount":
            case "withdrawMarginAccount":
            case "withdrawMarginAccountCpi":
            case "withdrawMarginAccountCpiTcomp":
            case "withdrawMarginAccountCpiTlock":
            case "attachPoolToMargin":
            case "detachPoolFromMargin":
            case "setPoolFreeze":
            case "editSingleListing":
            case "listT22":
            case "delistT22":
            case "depositNftT22":
            case "withdrawNftT22":
            case "wnsList":
            case "wnsDelist":
            case "wnsDepositNft":
            case "wnsWithdrawNft":
                return null;
        }
    }
    // FYI: accounts under InstructioNDisplay is the space-separated capitalized
    // version of the fields for the corresponding #[Accounts].
    // eg sol_escrow -> "Sol Escrow', or tswap -> "Tswap"
    // shared.sol_escrow -> "Shared > Sol Escrow"
    getAccountByName(ix, name) {
        // We use endsWith since composite nested accounts (eg shared.sol_escrow)
        // will prefix it as "Shared > Sol Escrow"
        return ix.formatted?.accounts.find((acc)=>acc.name?.endsWith(name));
    }
    static uuidToBuffer = (uuid)=>{
        return Buffer.from(uuid.replaceAll("-", "")).toJSON().data;
    };
} //# sourceMappingURL=sdk.js.map
}}),

};

//# sourceMappingURL=06f9a_%40tensor-oss_tensorswap-sdk_dist_esm_tensorswap_sdk_c0c763.js.map
module.exports = {

"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/bs58/node_modules/base-x/src/index.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var r = function(r) {
    if (r.length >= 255) throw new TypeError("Alphabet too long");
    for(var e = new Uint8Array(256), t = 0; t < e.length; t++)e[t] = 255;
    for(var n = 0; n < r.length; n++){
        var o = r.charAt(n), a = o.charCodeAt(0);
        if (255 !== e[a]) throw new TypeError(o + " is ambiguous");
        e[a] = n;
    }
    var f = r.length, i = r.charAt(0), h = Math.log(f) / Math.log(256), c = Math.log(256) / Math.log(f);
    function y(r) {
        if ("string" != typeof r) throw new TypeError("Expected String");
        if (0 === r.length) return new Uint8Array;
        for(var t = 0, n = 0, o = 0; r[t] === i;)n++, t++;
        for(var a = (r.length - t) * h + 1 >>> 0, c = new Uint8Array(a); r[t];){
            var y = e[r.charCodeAt(t)];
            if (255 === y) return;
            for(var w = 0, A = a - 1; (0 !== y || w < o) && -1 !== A; A--, w++)y += f * c[A] >>> 0, c[A] = y % 256 >>> 0, y = y / 256 >>> 0;
            if (0 !== y) throw new Error("Non-zero carry");
            o = w, t++;
        }
        for(var g = a - o; g !== a && 0 === c[g];)g++;
        for(var v = new Uint8Array(n + (a - g)), u = n; g !== a;)v[u++] = c[g++];
        return v;
    }
    return {
        encode: function(e) {
            if (e instanceof Uint8Array || (ArrayBuffer.isView(e) ? e = new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : Array.isArray(e) && (e = Uint8Array.from(e))), !(e instanceof Uint8Array)) throw new TypeError("Expected Uint8Array");
            if (0 === e.length) return "";
            for(var t = 0, n = 0, o = 0, a = e.length; o !== a && 0 === e[o];)o++, t++;
            for(var h = (a - o) * c + 1 >>> 0, y = new Uint8Array(h); o !== a;){
                for(var w = e[o], A = 0, g = h - 1; (0 !== w || A < n) && -1 !== g; g--, A++)w += 256 * y[g] >>> 0, y[g] = w % f >>> 0, w = w / f >>> 0;
                if (0 !== w) throw new Error("Non-zero carry");
                n = A, o++;
            }
            for(var v = h - n; v !== h && 0 === y[v];)v++;
            for(var u = i.repeat(t); v < h; ++v)u += r.charAt(y[v]);
            return u;
        },
        decodeUnsafe: y,
        decode: function(r) {
            var e = y(r);
            if (e) return e;
            throw new Error("Non-base" + f + " character");
        }
    };
};
exports.src = r; //# sourceMappingURL=index.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/bs58/node_modules/base-x/src/index.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "s": (()=>r)
});
var r = function(r) {
    if (r.length >= 255) throw new TypeError("Alphabet too long");
    for(var e = new Uint8Array(256), t = 0; t < e.length; t++)e[t] = 255;
    for(var n = 0; n < r.length; n++){
        var o = r.charAt(n), a = o.charCodeAt(0);
        if (255 !== e[a]) throw new TypeError(o + " is ambiguous");
        e[a] = n;
    }
    var f = r.length, i = r.charAt(0), h = Math.log(f) / Math.log(256), y = Math.log(256) / Math.log(f);
    function w(r) {
        if ("string" != typeof r) throw new TypeError("Expected String");
        if (0 === r.length) return new Uint8Array;
        for(var t = 0, n = 0, o = 0; r[t] === i;)n++, t++;
        for(var a = (r.length - t) * h + 1 >>> 0, y = new Uint8Array(a); r[t];){
            var w = e[r.charCodeAt(t)];
            if (255 === w) return;
            for(var c = 0, A = a - 1; (0 !== w || c < o) && -1 !== A; A--, c++)w += f * y[A] >>> 0, y[A] = w % 256 >>> 0, w = w / 256 >>> 0;
            if (0 !== w) throw new Error("Non-zero carry");
            o = c, t++;
        }
        for(var g = a - o; g !== a && 0 === y[g];)g++;
        for(var v = new Uint8Array(n + (a - g)), u = n; g !== a;)v[u++] = y[g++];
        return v;
    }
    return {
        encode: function(e) {
            if (e instanceof Uint8Array || (ArrayBuffer.isView(e) ? e = new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : Array.isArray(e) && (e = Uint8Array.from(e))), !(e instanceof Uint8Array)) throw new TypeError("Expected Uint8Array");
            if (0 === e.length) return "";
            for(var t = 0, n = 0, o = 0, a = e.length; o !== a && 0 === e[o];)o++, t++;
            for(var h = (a - o) * y + 1 >>> 0, w = new Uint8Array(h); o !== a;){
                for(var c = e[o], A = 0, g = h - 1; (0 !== c || A < n) && -1 !== g; g--, A++)c += 256 * w[g] >>> 0, w[g] = c % f >>> 0, c = c / f >>> 0;
                if (0 !== c) throw new Error("Non-zero carry");
                n = A, o++;
            }
            for(var v = h - n; v !== h && 0 === w[v];)v++;
            for(var u = i.repeat(t); v < h; ++v)u += r.charAt(w[v]);
            return u;
        },
        decodeUnsafe: w,
        decode: function(r) {
            var e = w(r);
            if (e) return e;
            throw new Error("Non-base" + f + " character");
        }
    };
};
;
 //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/bs58/index.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var s = (0, __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/bs58/node_modules/base-x/src/index.cjs [app-route] (ecmascript)").src)("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz");
exports.bs58 = s; //# sourceMappingURL=index.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/bs58/index.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "b": (()=>e)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$bs58$2f$node_modules$2f$base$2d$x$2f$src$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/bs58/node_modules/base-x/src/index.mjs [app-route] (ecmascript)");
;
var e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$bs58$2f$node_modules$2f$base$2d$x$2f$src$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["s"])("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz");
;
 //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/types.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
exports.integers = [
    "u8",
    "u16",
    "u32",
    "u64",
    "u128",
    "i8",
    "i16",
    "i32",
    "i64",
    "i128",
    "f32",
    "f64"
]; //# sourceMappingURL=types.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/buffer.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var e = function() {
    function e() {
        this.offset = 0, this.buffer_size = 256, this.buffer = new ArrayBuffer(this.buffer_size), this.view = new DataView(this.buffer);
    }
    return e.prototype.resize_if_necessary = function(e) {
        if (this.buffer_size - this.offset < e) {
            this.buffer_size = Math.max(2 * this.buffer_size, this.buffer_size + e);
            var t = new ArrayBuffer(this.buffer_size);
            new Uint8Array(t).set(new Uint8Array(this.buffer)), this.buffer = t, this.view = new DataView(t);
        }
    }, e.prototype.get_used_buffer = function() {
        return new Uint8Array(this.buffer).slice(0, this.offset);
    }, e.prototype.store_value = function(e, t) {
        var s = t.substring(1), f = parseInt(s) / 8;
        this.resize_if_necessary(f);
        var r = "f" === t[0] ? "setFloat".concat(s) : "i" === t[0] ? "setInt".concat(s) : "setUint".concat(s);
        this.view[r](this.offset, e, !0), this.offset += f;
    }, e.prototype.store_bytes = function(e) {
        this.resize_if_necessary(e.length), new Uint8Array(this.buffer).set(new Uint8Array(e), this.offset), this.offset += e.length;
    }, e;
}(), t = function() {
    function e(e) {
        this.offset = 0, this.buffer_size = e.length, this.buffer = new ArrayBuffer(e.length), new Uint8Array(this.buffer).set(e), this.view = new DataView(this.buffer);
    }
    return e.prototype.assert_enough_buffer = function(e) {
        if (this.offset + e > this.buffer.byteLength) throw new Error("Error in schema, the buffer is smaller than expected");
    }, e.prototype.consume_value = function(e) {
        var t = e.substring(1), s = parseInt(t) / 8;
        this.assert_enough_buffer(s);
        var f = "f" === e[0] ? "getFloat".concat(t) : "i" === e[0] ? "getInt".concat(t) : "getUint".concat(t), r = this.view[f](this.offset, !0);
        return this.offset += s, r;
    }, e.prototype.consume_bytes = function(e) {
        this.assert_enough_buffer(e);
        var t = this.buffer.slice(this.offset, this.offset + e);
        return this.offset += e, t;
    }, e;
}();
exports.DecodeBuffer = t, exports.EncodeBuffer = e; //# sourceMappingURL=buffer.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/utils.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var t, e = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/types.cjs [app-route] (ecmascript)"), n = (t = function(e, n) {
    return t = Object.setPrototypeOf || ({
        __proto__: []
    }) instanceof Array && function(t, e) {
        t.__proto__ = e;
    } || function(t, e) {
        for(var n in e)Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    }, t(e, n);
}, function(e, n) {
    if ("function" != typeof n && null !== n) throw new TypeError("Class extends value " + String(n) + " is not a constructor or null");
    function r() {
        this.constructor = e;
    }
    t(e, n), e.prototype = null === n ? Object.create(n) : (r.prototype = n.prototype, new r);
});
var r = e.integers.concat([
    "bool",
    "string"
]), o = [
    "option",
    "enum",
    "array",
    "set",
    "map",
    "struct"
], c = function(t) {
    function e(e, n) {
        var r = "Invalid schema: ".concat(JSON.stringify(e), " expected ").concat(n);
        return t.call(this, r) || this;
    }
    return n(e, t), e;
}(Error);
function i(t) {
    if ("string" != typeof t || !r.includes(t)) {
        if (t && "object" == typeof t) {
            var e = Object.keys(t);
            if (1 === e.length && o.includes(e[0])) {
                var n = e[0];
                if ("option" === n) return i(t[n]);
                if ("enum" === n) return function(t) {
                    if (!Array.isArray(t)) throw new c(t, "Array");
                    for(var e = 0, n = t; e < n.length; e++){
                        var r = n[e];
                        if ("object" != typeof r || !("struct" in r)) throw new Error('Missing "struct" key in enum schema');
                        if ("object" != typeof r.struct || 1 !== Object.keys(r.struct).length) throw new Error('The "struct" in each enum must have a single key');
                        i({
                            struct: r.struct
                        });
                    }
                }(t[n]);
                if ("array" === n) return function(t) {
                    if ("object" != typeof t) throw new c(t, "{ type, len? }");
                    if (t.len && "number" != typeof t.len) throw new Error("Invalid schema: ".concat(t));
                    if ("type" in t) return i(t.type);
                    throw new c(t, "{ type, len? }");
                }(t[n]);
                if ("set" === n) return i(t[n]);
                if ("map" === n) return function(t) {
                    if ("object" != typeof t || !("key" in t) || !("value" in t)) throw new c(t, "{ key, value }");
                    i(t.key), i(t.value);
                }(t[n]);
                if ("struct" === n) return function(t) {
                    if ("object" != typeof t) throw new c(t, "object");
                    for(var e in t)i(t[e]);
                }(t[n]);
            }
        }
        throw new c(t, o.join(", ") + " or " + r.join(", "));
    }
}
exports.ErrorSchema = c, exports.expect_bigint = function(t, e) {
    if (![
        "number",
        "string",
        "bigint",
        "boolean"
    ].includes(typeof t) && !("object" == typeof t && null !== t && "toString" in t)) throw new Error("Expected bigint, number, boolean or string not ".concat(typeof t, "(").concat(t, ") at ").concat(e.join(".")));
}, exports.expect_enum = function(t, e) {
    if ("object" != typeof t || null === t) throw new Error("Expected object not ".concat(typeof t, "(").concat(t, ") at ").concat(e.join(".")));
}, exports.expect_same_size = function(t, e, n) {
    if (t !== e) throw new Error("Array length ".concat(t, " does not match schema length ").concat(e, " at ").concat(n.join(".")));
}, exports.expect_type = function(t, e, n) {
    if (typeof t !== e) throw new Error("Expected ".concat(e, " not ").concat(typeof t, "(").concat(t, ") at ").concat(n.join(".")));
}, exports.isArrayLike = function(t) {
    return Array.isArray(t) || !!t && "object" == typeof t && "length" in t && "number" == typeof t.length && (0 === t.length || t.length > 0 && t.length - 1 in t);
}, exports.validate_schema = i; //# sourceMappingURL=utils.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/serialize.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var e = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/types.cjs [app-route] (ecmascript)"), t = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/buffer.cjs [app-route] (ecmascript)"), n = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/utils.cjs [app-route] (ecmascript)"), r = function() {
    function r(e) {
        this.encoded = new t.EncodeBuffer, this.fieldPath = [
            "value"
        ], this.checkTypes = e;
    }
    return r.prototype.encode = function(e, t) {
        return this.encode_value(e, t), this.encoded.get_used_buffer();
    }, r.prototype.encode_value = function(t, n) {
        if ("string" == typeof n) {
            if (e.integers.includes(n)) return this.encode_integer(t, n);
            if ("string" === n) return this.encode_string(t);
            if ("bool" === n) return this.encode_boolean(t);
        }
        if ("object" == typeof n) {
            if ("option" in n) return this.encode_option(t, n);
            if ("enum" in n) return this.encode_enum(t, n);
            if ("array" in n) return this.encode_array(t, n);
            if ("set" in n) return this.encode_set(t, n);
            if ("map" in n) return this.encode_map(t, n);
            if ("struct" in n) return this.encode_struct(t, n);
        }
    }, r.prototype.encode_integer = function(e, t) {
        var r = parseInt(t.substring(1));
        r <= 32 || "f64" == t ? (this.checkTypes && n.expect_type(e, "number", this.fieldPath), this.encoded.store_value(e, t)) : (this.checkTypes && n.expect_bigint(e, this.fieldPath), this.encode_bigint(BigInt(e), r));
    }, r.prototype.encode_bigint = function(e, t) {
        for(var n = t / 8, r = new Uint8Array(n), o = 0; o < n; o++)r[o] = Number(e & BigInt(255)), e >>= BigInt(8);
        this.encoded.store_bytes(new Uint8Array(r));
    }, r.prototype.encode_string = function(e) {
        this.checkTypes && n.expect_type(e, "string", this.fieldPath);
        for(var t = e, r = [], o = 0; o < t.length; o++){
            var i = t.charCodeAt(o);
            i < 128 ? r.push(i) : i < 2048 ? r.push(192 | i >> 6, 128 | 63 & i) : i < 55296 || i >= 57344 ? r.push(224 | i >> 12, 128 | i >> 6 & 63, 128 | 63 & i) : (o++, i = 65536 + ((1023 & i) << 10 | 1023 & t.charCodeAt(o)), r.push(240 | i >> 18, 128 | i >> 12 & 63, 128 | i >> 6 & 63, 128 | 63 & i));
        }
        this.encoded.store_value(r.length, "u32"), this.encoded.store_bytes(new Uint8Array(r));
    }, r.prototype.encode_boolean = function(e) {
        this.checkTypes && n.expect_type(e, "boolean", this.fieldPath), this.encoded.store_value(e ? 1 : 0, "u8");
    }, r.prototype.encode_option = function(e, t) {
        null == e ? this.encoded.store_value(0, "u8") : (this.encoded.store_value(1, "u8"), this.encode_value(e, t.option));
    }, r.prototype.encode_enum = function(e, t) {
        this.checkTypes && n.expect_enum(e, this.fieldPath);
        for(var r = Object.keys(e)[0], o = 0; o < t.enum.length; o++){
            var i = t.enum[o];
            if (r === Object.keys(i.struct)[0]) return this.encoded.store_value(o, "u8"), this.encode_struct(e, i);
        }
        throw new Error("Enum key (".concat(r, ") not found in enum schema: ").concat(JSON.stringify(t), " at ").concat(this.fieldPath.join(".")));
    }, r.prototype.encode_array = function(e, t) {
        if (n.isArrayLike(e)) return this.encode_arraylike(e, t);
        if (e instanceof ArrayBuffer) return this.encode_buffer(e, t);
        throw new Error("Expected Array-like not ".concat(typeof e, "(").concat(e, ") at ").concat(this.fieldPath.join(".")));
    }, r.prototype.encode_arraylike = function(e, t) {
        t.array.len ? n.expect_same_size(e.length, t.array.len, this.fieldPath) : this.encoded.store_value(e.length, "u32");
        for(var r = 0; r < e.length; r++)this.encode_value(e[r], t.array.type);
    }, r.prototype.encode_buffer = function(e, t) {
        t.array.len ? n.expect_same_size(e.byteLength, t.array.len, this.fieldPath) : this.encoded.store_value(e.byteLength, "u32"), this.encoded.store_bytes(new Uint8Array(e));
    }, r.prototype.encode_set = function(e, t) {
        this.checkTypes && n.expect_type(e, "object", this.fieldPath);
        var r = e instanceof Set ? Array.from(e.values()) : Object.values(e);
        this.encoded.store_value(r.length, "u32");
        for(var o = 0, i = r; o < i.length; o++){
            var s = i[o];
            this.encode_value(s, t.set);
        }
    }, r.prototype.encode_map = function(e, t) {
        this.checkTypes && n.expect_type(e, "object", this.fieldPath);
        var r = e instanceof Map, o = r ? Array.from(e.keys()) : Object.keys(e);
        this.encoded.store_value(o.length, "u32");
        for(var i = 0, s = o; i < s.length; i++){
            var c = s[i];
            this.encode_value(c, t.map.key), this.encode_value(r ? e.get(c) : e[c], t.map.value);
        }
    }, r.prototype.encode_struct = function(e, t) {
        this.checkTypes && n.expect_type(e, "object", this.fieldPath);
        for(var r = 0, o = Object.keys(t.struct); r < o.length; r++){
            var i = o[r];
            this.fieldPath.push(i), this.encode_value(e[i], t.struct[i]), this.fieldPath.pop();
        }
    }, r;
}();
exports.BorshSerializer = r; //# sourceMappingURL=serialize.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/deserialize.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var e = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/types.cjs [app-route] (ecmascript)"), t = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/buffer.cjs [app-route] (ecmascript)"), r = function() {
    function r(e) {
        this.buffer = new t.DecodeBuffer(e);
    }
    return r.prototype.decode = function(e) {
        return this.decode_value(e);
    }, r.prototype.decode_value = function(t) {
        if ("string" == typeof t) {
            if (e.integers.includes(t)) return this.decode_integer(t);
            if ("string" === t) return this.decode_string();
            if ("bool" === t) return this.decode_boolean();
        }
        if ("object" == typeof t) {
            if ("option" in t) return this.decode_option(t);
            if ("enum" in t) return this.decode_enum(t);
            if ("array" in t) return this.decode_array(t);
            if ("set" in t) return this.decode_set(t);
            if ("map" in t) return this.decode_map(t);
            if ("struct" in t) return this.decode_struct(t);
        }
        throw new Error("Unsupported type: ".concat(t));
    }, r.prototype.decode_integer = function(e) {
        var t = parseInt(e.substring(1));
        return t <= 32 || "f64" == e ? this.buffer.consume_value(e) : this.decode_bigint(t, e.startsWith("i"));
    }, r.prototype.decode_bigint = function(e, t) {
        void 0 === t && (t = !1);
        var r = e / 8, n = new Uint8Array(this.buffer.consume_bytes(r)), o = n.reduceRight(function(e, t) {
            return e + t.toString(16).padStart(2, "0");
        }, "");
        return t && n[r - 1] ? BigInt.asIntN(e, BigInt("0x".concat(o))) : BigInt("0x".concat(o));
    }, r.prototype.decode_string = function() {
        for(var e = this.decode_integer("u32"), t = new Uint8Array(this.buffer.consume_bytes(e)), r = [], n = 0; n < e; ++n){
            var o = t[n];
            if (o < 128) r.push(o);
            else if (o < 224) r.push((31 & o) << 6 | 63 & t[++n]);
            else if (o < 240) r.push((15 & o) << 12 | (63 & t[++n]) << 6 | 63 & t[++n]);
            else {
                var i = (7 & o) << 18 | (63 & t[++n]) << 12 | (63 & t[++n]) << 6 | 63 & t[++n];
                r.push(i);
            }
        }
        return String.fromCodePoint.apply(String, r);
    }, r.prototype.decode_boolean = function() {
        return this.buffer.consume_value("u8") > 0;
    }, r.prototype.decode_option = function(e) {
        var t = this.buffer.consume_value("u8");
        if (1 === t) return this.decode_value(e.option);
        if (0 !== t) throw new Error("Invalid option ".concat(t));
        return null;
    }, r.prototype.decode_enum = function(e) {
        var t, r = this.buffer.consume_value("u8");
        if (r > e.enum.length) throw new Error("Enum option ".concat(r, " is not available"));
        var n = e.enum[r].struct, o = Object.keys(n)[0];
        return (t = {})[o] = this.decode_value(n[o]), t;
    }, r.prototype.decode_array = function(e) {
        for(var t = [], r = e.array.len ? e.array.len : this.decode_integer("u32"), n = 0; n < r; ++n)t.push(this.decode_value(e.array.type));
        return t;
    }, r.prototype.decode_set = function(e) {
        for(var t = this.decode_integer("u32"), r = new Set, n = 0; n < t; ++n)r.add(this.decode_value(e.set));
        return r;
    }, r.prototype.decode_map = function(e) {
        for(var t = this.decode_integer("u32"), r = new Map, n = 0; n < t; ++n){
            var o = this.decode_value(e.map.key), i = this.decode_value(e.map.value);
            r.set(o, i);
        }
        return r;
    }, r.prototype.decode_struct = function(e) {
        var t = {};
        for(var r in e.struct)t[r] = this.decode_value(e.struct[r]);
        return t;
    }, r;
}();
exports.BorshDeserializer = r; //# sourceMappingURL=deserialize.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/index.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var e = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/serialize.cjs [app-route] (ecmascript)"), r = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/deserialize.cjs [app-route] (ecmascript)"), i = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/borsh/lib/esm/utils.cjs [app-route] (ecmascript)");
exports.deserialize = function(e, s, a) {
    return void 0 === a && (a = !0), a && i.validate_schema(e), new r.BorshDeserializer(s).decode(e);
}, exports.serialize = function(r, s, a) {
    return void 0 === a && (a = !0), a && i.validate_schema(r), new e.BorshSerializer(a).encode(s, r);
}; //# sourceMappingURL=index.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/types.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "integers": (()=>i)
});
var i = [
    "u8",
    "u16",
    "u32",
    "u64",
    "u128",
    "i8",
    "i16",
    "i32",
    "i64",
    "i128",
    "f32",
    "f64"
];
;
 //# sourceMappingURL=types.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/buffer.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "DecodeBuffer": (()=>e),
    "EncodeBuffer": (()=>t)
});
var t = function() {
    function t() {
        this.offset = 0, this.buffer_size = 256, this.buffer = new ArrayBuffer(this.buffer_size), this.view = new DataView(this.buffer);
    }
    return t.prototype.resize_if_necessary = function(t) {
        if (this.buffer_size - this.offset < t) {
            this.buffer_size = Math.max(2 * this.buffer_size, this.buffer_size + t);
            var e = new ArrayBuffer(this.buffer_size);
            new Uint8Array(e).set(new Uint8Array(this.buffer)), this.buffer = e, this.view = new DataView(e);
        }
    }, t.prototype.get_used_buffer = function() {
        return new Uint8Array(this.buffer).slice(0, this.offset);
    }, t.prototype.store_value = function(t, e) {
        var s = e.substring(1), f = parseInt(s) / 8;
        this.resize_if_necessary(f);
        var i = "f" === e[0] ? "setFloat".concat(s) : "i" === e[0] ? "setInt".concat(s) : "setUint".concat(s);
        this.view[i](this.offset, t, !0), this.offset += f;
    }, t.prototype.store_bytes = function(t) {
        this.resize_if_necessary(t.length), new Uint8Array(this.buffer).set(new Uint8Array(t), this.offset), this.offset += t.length;
    }, t;
}(), e = function() {
    function t(t) {
        this.offset = 0, this.buffer_size = t.length, this.buffer = new ArrayBuffer(t.length), new Uint8Array(this.buffer).set(t), this.view = new DataView(this.buffer);
    }
    return t.prototype.assert_enough_buffer = function(t) {
        if (this.offset + t > this.buffer.byteLength) throw new Error("Error in schema, the buffer is smaller than expected");
    }, t.prototype.consume_value = function(t) {
        var e = t.substring(1), s = parseInt(e) / 8;
        this.assert_enough_buffer(s);
        var f = "f" === t[0] ? "getFloat".concat(e) : "i" === t[0] ? "getInt".concat(e) : "getUint".concat(e), i = this.view[f](this.offset, !0);
        return this.offset += s, i;
    }, t.prototype.consume_bytes = function(t) {
        this.assert_enough_buffer(t);
        var e = this.buffer.slice(this.offset, this.offset + t);
        return this.offset += t, e;
    }, t;
}();
;
 //# sourceMappingURL=buffer.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/utils.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ErrorSchema": (()=>y),
    "expect_bigint": (()=>c),
    "expect_enum": (()=>a),
    "expect_same_size": (()=>i),
    "expect_type": (()=>r),
    "isArrayLike": (()=>e),
    "validate_schema": (()=>p)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$types$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/types.mjs [app-route] (ecmascript)");
;
var n, o = (n = function(t, o) {
    return n = Object.setPrototypeOf || ({
        __proto__: []
    }) instanceof Array && function(t, n) {
        t.__proto__ = n;
    } || function(t, n) {
        for(var o in n)Object.prototype.hasOwnProperty.call(n, o) && (t[o] = n[o]);
    }, n(t, o);
}, function(t, o) {
    if ("function" != typeof o && null !== o) throw new TypeError("Class extends value " + String(o) + " is not a constructor or null");
    function e() {
        this.constructor = t;
    }
    n(t, o), t.prototype = null === o ? Object.create(o) : (e.prototype = o.prototype, new e);
});
function e(t) {
    return Array.isArray(t) || !!t && "object" == typeof t && "length" in t && "number" == typeof t.length && (0 === t.length || t.length > 0 && t.length - 1 in t);
}
function r(t, n, o) {
    if (typeof t !== n) throw new Error("Expected ".concat(n, " not ").concat(typeof t, "(").concat(t, ") at ").concat(o.join(".")));
}
function c(t, n) {
    if (![
        "number",
        "string",
        "bigint",
        "boolean"
    ].includes(typeof t) && !("object" == typeof t && null !== t && "toString" in t)) throw new Error("Expected bigint, number, boolean or string not ".concat(typeof t, "(").concat(t, ") at ").concat(n.join(".")));
}
function i(t, n, o) {
    if (t !== n) throw new Error("Array length ".concat(t, " does not match schema length ").concat(n, " at ").concat(o.join(".")));
}
function a(t, n) {
    if ("object" != typeof t || null === t) throw new Error("Expected object not ".concat(typeof t, "(").concat(t, ") at ").concat(n.join(".")));
}
var f = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$types$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["integers"].concat([
    "bool",
    "string"
]), u = [
    "option",
    "enum",
    "array",
    "set",
    "map",
    "struct"
], y = function(t) {
    function n(n, o) {
        var e = "Invalid schema: ".concat(JSON.stringify(n), " expected ").concat(o);
        return t.call(this, e) || this;
    }
    return o(n, t), n;
}(Error);
function p(t) {
    if ("string" != typeof t || !f.includes(t)) {
        if (t && "object" == typeof t) {
            var n = Object.keys(t);
            if (1 === n.length && u.includes(n[0])) {
                var o = n[0];
                if ("option" === o) return p(t[o]);
                if ("enum" === o) return function(t) {
                    if (!Array.isArray(t)) throw new y(t, "Array");
                    for(var n = 0, o = t; n < o.length; n++){
                        var e = o[n];
                        if ("object" != typeof e || !("struct" in e)) throw new Error('Missing "struct" key in enum schema');
                        if ("object" != typeof e.struct || 1 !== Object.keys(e.struct).length) throw new Error('The "struct" in each enum must have a single key');
                        p({
                            struct: e.struct
                        });
                    }
                }(t[o]);
                if ("array" === o) return function(t) {
                    if ("object" != typeof t) throw new y(t, "{ type, len? }");
                    if (t.len && "number" != typeof t.len) throw new Error("Invalid schema: ".concat(t));
                    if ("type" in t) return p(t.type);
                    throw new y(t, "{ type, len? }");
                }(t[o]);
                if ("set" === o) return p(t[o]);
                if ("map" === o) return function(t) {
                    if ("object" != typeof t || !("key" in t) || !("value" in t)) throw new y(t, "{ key, value }");
                    p(t.key), p(t.value);
                }(t[o]);
                if ("struct" === o) return function(t) {
                    if ("object" != typeof t) throw new y(t, "object");
                    for(var n in t)p(t[n]);
                }(t[o]);
            }
        }
        throw new y(t, u.join(", ") + " or " + f.join(", "));
    }
}
;
 //# sourceMappingURL=utils.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/serialize.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "BorshSerializer": (()=>c)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$types$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/types.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$buffer$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/buffer.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/utils.mjs [app-route] (ecmascript)");
;
;
;
var c = function() {
    function c(e) {
        this.encoded = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$buffer$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["EncodeBuffer"], this.fieldPath = [
            "value"
        ], this.checkTypes = e;
    }
    return c.prototype.encode = function(e, t) {
        return this.encode_value(e, t), this.encoded.get_used_buffer();
    }, c.prototype.encode_value = function(t, n) {
        if ("string" == typeof n) {
            if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$types$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["integers"].includes(n)) return this.encode_integer(t, n);
            if ("string" === n) return this.encode_string(t);
            if ("bool" === n) return this.encode_boolean(t);
        }
        if ("object" == typeof n) {
            if ("option" in n) return this.encode_option(t, n);
            if ("enum" in n) return this.encode_enum(t, n);
            if ("array" in n) return this.encode_array(t, n);
            if ("set" in n) return this.encode_set(t, n);
            if ("map" in n) return this.encode_map(t, n);
            if ("struct" in n) return this.encode_struct(t, n);
        }
    }, c.prototype.encode_integer = function(e, t) {
        var r = parseInt(t.substring(1));
        r <= 32 || "f64" == t ? (this.checkTypes && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["expect_type"])(e, "number", this.fieldPath), this.encoded.store_value(e, t)) : (this.checkTypes && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["expect_bigint"])(e, this.fieldPath), this.encode_bigint(BigInt(e), r));
    }, c.prototype.encode_bigint = function(e, t) {
        for(var n = t / 8, o = new Uint8Array(n), r = 0; r < n; r++)o[r] = Number(e & BigInt(255)), e >>= BigInt(8);
        this.encoded.store_bytes(new Uint8Array(o));
    }, c.prototype.encode_string = function(e) {
        this.checkTypes && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["expect_type"])(e, "string", this.fieldPath);
        for(var t = e, o = [], r = 0; r < t.length; r++){
            var i = t.charCodeAt(r);
            i < 128 ? o.push(i) : i < 2048 ? o.push(192 | i >> 6, 128 | 63 & i) : i < 55296 || i >= 57344 ? o.push(224 | i >> 12, 128 | i >> 6 & 63, 128 | 63 & i) : (r++, i = 65536 + ((1023 & i) << 10 | 1023 & t.charCodeAt(r)), o.push(240 | i >> 18, 128 | i >> 12 & 63, 128 | i >> 6 & 63, 128 | 63 & i));
        }
        this.encoded.store_value(o.length, "u32"), this.encoded.store_bytes(new Uint8Array(o));
    }, c.prototype.encode_boolean = function(e) {
        this.checkTypes && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["expect_type"])(e, "boolean", this.fieldPath), this.encoded.store_value(e ? 1 : 0, "u8");
    }, c.prototype.encode_option = function(e, t) {
        null == e ? this.encoded.store_value(0, "u8") : (this.encoded.store_value(1, "u8"), this.encode_value(e, t.option));
    }, c.prototype.encode_enum = function(e, t) {
        this.checkTypes && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["expect_enum"])(e, this.fieldPath);
        for(var n = Object.keys(e)[0], o = 0; o < t.enum.length; o++){
            var i = t.enum[o];
            if (n === Object.keys(i.struct)[0]) return this.encoded.store_value(o, "u8"), this.encode_struct(e, i);
        }
        throw new Error("Enum key (".concat(n, ") not found in enum schema: ").concat(JSON.stringify(t), " at ").concat(this.fieldPath.join(".")));
    }, c.prototype.encode_array = function(e, t) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isArrayLike"])(e)) return this.encode_arraylike(e, t);
        if (e instanceof ArrayBuffer) return this.encode_buffer(e, t);
        throw new Error("Expected Array-like not ".concat(typeof e, "(").concat(e, ") at ").concat(this.fieldPath.join(".")));
    }, c.prototype.encode_arraylike = function(e, t) {
        t.array.len ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["expect_same_size"])(e.length, t.array.len, this.fieldPath) : this.encoded.store_value(e.length, "u32");
        for(var n = 0; n < e.length; n++)this.encode_value(e[n], t.array.type);
    }, c.prototype.encode_buffer = function(e, t) {
        t.array.len ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["expect_same_size"])(e.byteLength, t.array.len, this.fieldPath) : this.encoded.store_value(e.byteLength, "u32"), this.encoded.store_bytes(new Uint8Array(e));
    }, c.prototype.encode_set = function(e, t) {
        this.checkTypes && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["expect_type"])(e, "object", this.fieldPath);
        var o = e instanceof Set ? Array.from(e.values()) : Object.values(e);
        this.encoded.store_value(o.length, "u32");
        for(var r = 0, i = o; r < i.length; r++){
            var s = i[r];
            this.encode_value(s, t.set);
        }
    }, c.prototype.encode_map = function(e, t) {
        this.checkTypes && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["expect_type"])(e, "object", this.fieldPath);
        var o = e instanceof Map, r = o ? Array.from(e.keys()) : Object.keys(e);
        this.encoded.store_value(r.length, "u32");
        for(var i = 0, s = r; i < s.length; i++){
            var c = s[i];
            this.encode_value(c, t.map.key), this.encode_value(o ? e.get(c) : e[c], t.map.value);
        }
    }, c.prototype.encode_struct = function(e, t) {
        this.checkTypes && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["expect_type"])(e, "object", this.fieldPath);
        for(var o = 0, r = Object.keys(t.struct); o < r.length; o++){
            var i = r[o];
            this.fieldPath.push(i), this.encode_value(e[i], t.struct[i]), this.fieldPath.pop();
        }
    }, c;
}();
;
 //# sourceMappingURL=serialize.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/deserialize.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "BorshDeserializer": (()=>r)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$types$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/types.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$buffer$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/buffer.mjs [app-route] (ecmascript)");
;
;
var r = function() {
    function r(e) {
        this.buffer = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$buffer$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DecodeBuffer"](e);
    }
    return r.prototype.decode = function(e) {
        return this.decode_value(e);
    }, r.prototype.decode_value = function(t) {
        if ("string" == typeof t) {
            if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$types$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["integers"].includes(t)) return this.decode_integer(t);
            if ("string" === t) return this.decode_string();
            if ("bool" === t) return this.decode_boolean();
        }
        if ("object" == typeof t) {
            if ("option" in t) return this.decode_option(t);
            if ("enum" in t) return this.decode_enum(t);
            if ("array" in t) return this.decode_array(t);
            if ("set" in t) return this.decode_set(t);
            if ("map" in t) return this.decode_map(t);
            if ("struct" in t) return this.decode_struct(t);
        }
        throw new Error("Unsupported type: ".concat(t));
    }, r.prototype.decode_integer = function(e) {
        var t = parseInt(e.substring(1));
        return t <= 32 || "f64" == e ? this.buffer.consume_value(e) : this.decode_bigint(t, e.startsWith("i"));
    }, r.prototype.decode_bigint = function(e, t) {
        void 0 === t && (t = !1);
        var r = e / 8, o = new Uint8Array(this.buffer.consume_bytes(r)), n = o.reduceRight(function(e, t) {
            return e + t.toString(16).padStart(2, "0");
        }, "");
        return t && o[r - 1] ? BigInt.asIntN(e, BigInt("0x".concat(n))) : BigInt("0x".concat(n));
    }, r.prototype.decode_string = function() {
        for(var e = this.decode_integer("u32"), t = new Uint8Array(this.buffer.consume_bytes(e)), r = [], o = 0; o < e; ++o){
            var n = t[o];
            if (n < 128) r.push(n);
            else if (n < 224) r.push((31 & n) << 6 | 63 & t[++o]);
            else if (n < 240) r.push((15 & n) << 12 | (63 & t[++o]) << 6 | 63 & t[++o]);
            else {
                var i = (7 & n) << 18 | (63 & t[++o]) << 12 | (63 & t[++o]) << 6 | 63 & t[++o];
                r.push(i);
            }
        }
        return String.fromCodePoint.apply(String, r);
    }, r.prototype.decode_boolean = function() {
        return this.buffer.consume_value("u8") > 0;
    }, r.prototype.decode_option = function(e) {
        var t = this.buffer.consume_value("u8");
        if (1 === t) return this.decode_value(e.option);
        if (0 !== t) throw new Error("Invalid option ".concat(t));
        return null;
    }, r.prototype.decode_enum = function(e) {
        var t, r = this.buffer.consume_value("u8");
        if (r > e.enum.length) throw new Error("Enum option ".concat(r, " is not available"));
        var o = e.enum[r].struct, n = Object.keys(o)[0];
        return (t = {})[n] = this.decode_value(o[n]), t;
    }, r.prototype.decode_array = function(e) {
        for(var t = [], r = e.array.len ? e.array.len : this.decode_integer("u32"), o = 0; o < r; ++o)t.push(this.decode_value(e.array.type));
        return t;
    }, r.prototype.decode_set = function(e) {
        for(var t = this.decode_integer("u32"), r = new Set, o = 0; o < t; ++o)r.add(this.decode_value(e.set));
        return r;
    }, r.prototype.decode_map = function(e) {
        for(var t = this.decode_integer("u32"), r = new Map, o = 0; o < t; ++o){
            var n = this.decode_value(e.map.key), i = this.decode_value(e.map.value);
            r.set(n, i);
        }
        return r;
    }, r.prototype.decode_struct = function(e) {
        var t = {};
        for(var r in e.struct)t[r] = this.decode_value(e.struct[r]);
        return t;
    }, r;
}();
;
 //# sourceMappingURL=deserialize.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/index.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "deserialize": (()=>m),
    "serialize": (()=>i)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$serialize$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/serialize.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$deserialize$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/deserialize.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/borsh/lib/esm/utils.mjs [app-route] (ecmascript)");
;
;
;
function i(o, i, m) {
    return void 0 === m && (m = !0), m && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["validate_schema"])(o), new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$serialize$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BorshSerializer"](m).encode(i, o);
}
function m(e, i, m) {
    return void 0 === m && (m = !0), m && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$utils$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["validate_schema"])(e), new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$borsh$2f$lib$2f$esm$2f$deserialize$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BorshDeserializer"](i).decode(e);
}
;
 //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/base64-js/index.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: !0
});
var r = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/_virtual/index2.cjs [app-route] (ecmascript)");
r.__exports.byteLength = function(r) {
    var e = u(r), t = e[0], o = e[1];
    return 3 * (t + o) / 4 - o;
}, r.__exports.toByteArray = function(r) {
    var e, n, a = u(r), c = a[0], h = a[1], i = new o(function(r, e, t) {
        return 3 * (e + t) / 4 - t;
    }(0, c, h)), d = 0, f = h > 0 ? c - 4 : c;
    for(n = 0; n < f; n += 4)e = t[r.charCodeAt(n)] << 18 | t[r.charCodeAt(n + 1)] << 12 | t[r.charCodeAt(n + 2)] << 6 | t[r.charCodeAt(n + 3)], i[d++] = e >> 16 & 255, i[d++] = e >> 8 & 255, i[d++] = 255 & e;
    2 === h && (e = t[r.charCodeAt(n)] << 2 | t[r.charCodeAt(n + 1)] >> 4, i[d++] = 255 & e);
    1 === h && (e = t[r.charCodeAt(n)] << 10 | t[r.charCodeAt(n + 1)] << 4 | t[r.charCodeAt(n + 2)] >> 2, i[d++] = e >> 8 & 255, i[d++] = 255 & e);
    return i;
}, r.__exports.fromByteArray = function(r) {
    for(var t, o = r.length, n = o % 3, a = [], u = 16383, h = 0, i = o - n; h < i; h += u)a.push(c(r, h, h + u > i ? i : h + u));
    1 === n ? (t = r[o - 1], a.push(e[t >> 2] + e[t << 4 & 63] + "==")) : 2 === n && (t = (r[o - 2] << 8) + r[o - 1], a.push(e[t >> 10] + e[t >> 4 & 63] + e[t << 2 & 63] + "="));
    return a.join("");
};
for(var e = [], t = [], o = "undefined" != typeof Uint8Array ? Uint8Array : Array, n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", a = 0; a < 64; ++a)e[a] = n[a], t[n.charCodeAt(a)] = a;
function u(r) {
    var e = r.length;
    if (e % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
    var t = r.indexOf("=");
    return -1 === t && (t = e), [
        t,
        t === e ? 0 : 4 - t % 4
    ];
}
function c(r, t, o) {
    for(var n, a, u = [], c = t; c < o; c += 3)n = (r[c] << 16 & 16711680) + (r[c + 1] << 8 & 65280) + (255 & r[c + 2]), u.push(e[(a = n) >> 18 & 63] + e[a >> 12 & 63] + e[a >> 6 & 63] + e[63 & a]);
    return u.join("");
}
t["-".charCodeAt(0)] = 62, t["_".charCodeAt(0)] = 63, exports.default = r.__exports; //# sourceMappingURL=index.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/base64-js/index.mjs [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index2$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/index2.mjs [app-route] (ecmascript)");
;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index2$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].byteLength = function(r) {
    var t = h(r), e = t[0], n = t[1];
    return 3 * (e + n) / 4 - n;
}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index2$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].toByteArray = function(r) {
    var t, o, a = h(r), u = a[0], i = a[1], c = new n(function(r, t, e) {
        return 3 * (t + e) / 4 - e;
    }(0, u, i)), d = 0, f = i > 0 ? u - 4 : u;
    for(o = 0; o < f; o += 4)t = e[r.charCodeAt(o)] << 18 | e[r.charCodeAt(o + 1)] << 12 | e[r.charCodeAt(o + 2)] << 6 | e[r.charCodeAt(o + 3)], c[d++] = t >> 16 & 255, c[d++] = t >> 8 & 255, c[d++] = 255 & t;
    2 === i && (t = e[r.charCodeAt(o)] << 2 | e[r.charCodeAt(o + 1)] >> 4, c[d++] = 255 & t);
    1 === i && (t = e[r.charCodeAt(o)] << 10 | e[r.charCodeAt(o + 1)] << 4 | e[r.charCodeAt(o + 2)] >> 2, c[d++] = t >> 8 & 255, c[d++] = 255 & t);
    return c;
}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index2$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].fromByteArray = function(r) {
    for(var e, n = r.length, o = n % 3, a = [], h = 16383, i = 0, c = n - o; i < c; i += h)a.push(u(r, i, i + h > c ? c : i + h));
    1 === o ? (e = r[n - 1], a.push(t[e >> 2] + t[e << 4 & 63] + "==")) : 2 === o && (e = (r[n - 2] << 8) + r[n - 1], a.push(t[e >> 10] + t[e >> 4 & 63] + t[e << 2 & 63] + "="));
    return a.join("");
};
for(var t = [], e = [], n = "undefined" != typeof Uint8Array ? Uint8Array : Array, o = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", a = 0; a < 64; ++a)t[a] = o[a], e[o.charCodeAt(a)] = a;
function h(r) {
    var t = r.length;
    if (t % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
    var e = r.indexOf("=");
    return -1 === e && (e = t), [
        e,
        e === t ? 0 : 4 - e % 4
    ];
}
function u(r, e, n) {
    for(var o, a, h = [], u = e; u < n; u += 3)o = (r[u] << 16 & 16711680) + (r[u + 1] << 8 & 65280) + (255 & r[u + 2]), h.push(t[(a = o) >> 18 & 63] + t[a >> 12 & 63] + t[a >> 6 & 63] + t[63 & a]);
    return h.join("");
}
e["-".charCodeAt(0)] = 62, e["_".charCodeAt(0)] = 63;
;
 //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/base64-js/index.mjs [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index2$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/index2.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$base64$2d$js$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/base64-js/index.mjs [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/ieee754/index.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: !0
});
var t = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/_virtual/index3.cjs [app-route] (ecmascript)");
/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */ t.__exports.read = function(t, o, r, a, e) {
    var p, M, h = 8 * e - a - 1, s = (1 << h) - 1, i = s >> 1, f = -7, u = r ? e - 1 : 0, w = r ? -1 : 1, _ = t[o + u];
    for(u += w, p = _ & (1 << -f) - 1, _ >>= -f, f += h; f > 0; p = 256 * p + t[o + u], u += w, f -= 8);
    for(M = p & (1 << -f) - 1, p >>= -f, f += a; f > 0; M = 256 * M + t[o + u], u += w, f -= 8);
    if (0 === p) p = 1 - i;
    else {
        if (p === s) return M ? NaN : 1 / 0 * (_ ? -1 : 1);
        M += Math.pow(2, a), p -= i;
    }
    return (_ ? -1 : 1) * M * Math.pow(2, p - a);
}, t.__exports.write = function(t, o, r, a, e, p) {
    var M, h, s, i = 8 * p - e - 1, f = (1 << i) - 1, u = f >> 1, w = 23 === e ? Math.pow(2, -24) - Math.pow(2, -77) : 0, _ = a ? 0 : p - 1, n = a ? 1 : -1, l = o < 0 || 0 === o && 1 / o < 0 ? 1 : 0;
    for(o = Math.abs(o), isNaN(o) || o === 1 / 0 ? (h = isNaN(o) ? 1 : 0, M = f) : (M = Math.floor(Math.log(o) / Math.LN2), o * (s = Math.pow(2, -M)) < 1 && (M--, s *= 2), (o += M + u >= 1 ? w / s : w * Math.pow(2, 1 - u)) * s >= 2 && (M++, s /= 2), M + u >= f ? (h = 0, M = f) : M + u >= 1 ? (h = (o * s - 1) * Math.pow(2, e), M += u) : (h = o * Math.pow(2, u - 1) * Math.pow(2, e), M = 0)); e >= 8; t[r + _] = 255 & h, _ += n, h /= 256, e -= 8);
    for(M = M << e | h, i += e; i > 0; t[r + _] = 255 & M, _ += n, M /= 256, i -= 8);
    t[r + _ - n] |= 128 * l;
}, exports.default = t.__exports; //# sourceMappingURL=index.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/ieee754/index.mjs [app-route] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index3$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/index3.mjs [app-route] (ecmascript)");
;
/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index3$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].read = function(a, t, o, r, h) {
    var M, p, f = 8 * h - r - 1, e = (1 << f) - 1, i = e >> 1, w = -7, s = o ? h - 1 : 0, n = o ? -1 : 1, N = a[t + s];
    for(s += n, M = N & (1 << -w) - 1, N >>= -w, w += f; w > 0; M = 256 * M + a[t + s], s += n, w -= 8);
    for(p = M & (1 << -w) - 1, M >>= -w, w += r; w > 0; p = 256 * p + a[t + s], s += n, w -= 8);
    if (0 === M) M = 1 - i;
    else {
        if (M === e) return p ? NaN : 1 / 0 * (N ? -1 : 1);
        p += Math.pow(2, r), M -= i;
    }
    return (N ? -1 : 1) * p * Math.pow(2, M - r);
}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index3$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].write = function(a, t, o, r, h, M) {
    var p, f, e, i = 8 * M - h - 1, w = (1 << i) - 1, s = w >> 1, n = 23 === h ? Math.pow(2, -24) - Math.pow(2, -77) : 0, N = r ? 0 : M - 1, u = r ? 1 : -1, l = t < 0 || 0 === t && 1 / t < 0 ? 1 : 0;
    for(t = Math.abs(t), isNaN(t) || t === 1 / 0 ? (f = isNaN(t) ? 1 : 0, p = w) : (p = Math.floor(Math.log(t) / Math.LN2), t * (e = Math.pow(2, -p)) < 1 && (p--, e *= 2), (t += p + s >= 1 ? n / e : n * Math.pow(2, 1 - s)) * e >= 2 && (p++, e /= 2), p + s >= w ? (f = 0, p = w) : p + s >= 1 ? (f = (t * e - 1) * Math.pow(2, h), p += s) : (f = t * Math.pow(2, s - 1) * Math.pow(2, h), p = 0)); h >= 8; a[o + N] = 255 & f, N += u, f /= 256, h -= 8);
    for(p = p << h | f, i += h; i > 0; a[o + N] = 255 & p, N += u, p /= 256, i -= 8);
    a[o + N - u] |= 128 * l;
};
;
 //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/ieee754/index.mjs [app-route] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index3$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/index3.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$ieee754$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/ieee754/index.mjs [app-route] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/buffer/index.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var t = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/_virtual/index.cjs [app-route] (ecmascript)"), e = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/_virtual/index2.cjs [app-route] (ecmascript)");
__turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/base64-js/index.cjs [app-route] (ecmascript)");
var r = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/_virtual/index3.cjs [app-route] (ecmascript)");
__turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/ieee754/index.cjs [app-route] (ecmascript)"), /*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */ function(t) {
    const n = e.__exports, i = r.__exports, o = "function" == typeof Symbol && "function" == typeof Symbol.for ? Symbol.for("nodejs.util.inspect.custom") : null;
    t.Buffer = u, t.SlowBuffer = function(t) {
        +t != t && (t = 0);
        return u.alloc(+t);
    }, t.INSPECT_MAX_BYTES = 50;
    const f = 2147483647;
    function s(t) {
        if (t > f) throw new RangeError('The value "' + t + '" is invalid for option "size"');
        const e = new Uint8Array(t);
        return Object.setPrototypeOf(e, u.prototype), e;
    }
    function u(t, e, r) {
        if ("number" == typeof t) {
            if ("string" == typeof e) throw new TypeError('The "string" argument must be of type string. Received type number');
            return a(t);
        }
        return h(t, e, r);
    }
    function h(t, e, r) {
        if ("string" == typeof t) return function(t, e) {
            "string" == typeof e && "" !== e || (e = "utf8");
            if (!u.isEncoding(e)) throw new TypeError("Unknown encoding: " + e);
            const r = 0 | y(t, e);
            let n = s(r);
            const i = n.write(t, e);
            i !== r && (n = n.slice(0, i));
            return n;
        }(t, e);
        if (ArrayBuffer.isView(t)) return function(t) {
            if (J(t, Uint8Array)) {
                const e = new Uint8Array(t);
                return p(e.buffer, e.byteOffset, e.byteLength);
            }
            return l(t);
        }(t);
        if (null == t) throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof t);
        if (J(t, ArrayBuffer) || t && J(t.buffer, ArrayBuffer)) return p(t, e, r);
        if ("undefined" != typeof SharedArrayBuffer && (J(t, SharedArrayBuffer) || t && J(t.buffer, SharedArrayBuffer))) return p(t, e, r);
        if ("number" == typeof t) throw new TypeError('The "value" argument must not be of type number. Received type number');
        const n = t.valueOf && t.valueOf();
        if (null != n && n !== t) return u.from(n, e, r);
        const i = function(t) {
            if (u.isBuffer(t)) {
                const e = 0 | g(t.length), r = s(e);
                return 0 === r.length || t.copy(r, 0, 0, e), r;
            }
            if (void 0 !== t.length) return "number" != typeof t.length || Z(t.length) ? s(0) : l(t);
            if ("Buffer" === t.type && Array.isArray(t.data)) return l(t.data);
        }(t);
        if (i) return i;
        if ("undefined" != typeof Symbol && null != Symbol.toPrimitive && "function" == typeof t[Symbol.toPrimitive]) return u.from(t[Symbol.toPrimitive]("string"), e, r);
        throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof t);
    }
    function c(t) {
        if ("number" != typeof t) throw new TypeError('"size" argument must be of type number');
        if (t < 0) throw new RangeError('The value "' + t + '" is invalid for option "size"');
    }
    function a(t) {
        return c(t), s(t < 0 ? 0 : 0 | g(t));
    }
    function l(t) {
        const e = t.length < 0 ? 0 : 0 | g(t.length), r = s(e);
        for(let n = 0; n < e; n += 1)r[n] = 255 & t[n];
        return r;
    }
    function p(t, e, r) {
        if (e < 0 || t.byteLength < e) throw new RangeError('"offset" is outside of buffer bounds');
        if (t.byteLength < e + (r || 0)) throw new RangeError('"length" is outside of buffer bounds');
        let n;
        return n = void 0 === e && void 0 === r ? new Uint8Array(t) : void 0 === r ? new Uint8Array(t, e) : new Uint8Array(t, e, r), Object.setPrototypeOf(n, u.prototype), n;
    }
    function g(t) {
        if (t >= f) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + f.toString(16) + " bytes");
        return 0 | t;
    }
    function y(t, e) {
        if (u.isBuffer(t)) return t.length;
        if (ArrayBuffer.isView(t) || J(t, ArrayBuffer)) return t.byteLength;
        if ("string" != typeof t) throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof t);
        const r = t.length, n = arguments.length > 2 && !0 === arguments[2];
        if (!n && 0 === r) return 0;
        let i = !1;
        for(;;)switch(e){
            case "ascii":
            case "latin1":
            case "binary":
                return r;
            case "utf8":
            case "utf-8":
                return V(t).length;
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
                return 2 * r;
            case "hex":
                return r >>> 1;
            case "base64":
                return W(t).length;
            default:
                if (i) return n ? -1 : V(t).length;
                e = ("" + e).toLowerCase(), i = !0;
        }
    }
    function w(t, e, r) {
        let n = !1;
        if ((void 0 === e || e < 0) && (e = 0), e > this.length) return "";
        if ((void 0 === r || r > this.length) && (r = this.length), r <= 0) return "";
        if ((r >>>= 0) <= (e >>>= 0)) return "";
        for(t || (t = "utf8");;)switch(t){
            case "hex":
                return L(this, e, r);
            case "utf8":
            case "utf-8":
                return R(this, e, r);
            case "ascii":
                return O(this, e, r);
            case "latin1":
            case "binary":
                return _(this, e, r);
            case "base64":
                return v(this, e, r);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
                return S(this, e, r);
            default:
                if (n) throw new TypeError("Unknown encoding: " + t);
                t = (t + "").toLowerCase(), n = !0;
        }
    }
    function d(t, e, r) {
        const n = t[e];
        t[e] = t[r], t[r] = n;
    }
    function b(t, e, r, n, i) {
        if (0 === t.length) return -1;
        if ("string" == typeof r ? (n = r, r = 0) : r > 2147483647 ? r = 2147483647 : r < -2147483648 && (r = -2147483648), Z(r = +r) && (r = i ? 0 : t.length - 1), r < 0 && (r = t.length + r), r >= t.length) {
            if (i) return -1;
            r = t.length - 1;
        } else if (r < 0) {
            if (!i) return -1;
            r = 0;
        }
        if ("string" == typeof e && (e = u.from(e, n)), u.isBuffer(e)) return 0 === e.length ? -1 : B(t, e, r, n, i);
        if ("number" == typeof e) return e &= 255, "function" == typeof Uint8Array.prototype.indexOf ? i ? Uint8Array.prototype.indexOf.call(t, e, r) : Uint8Array.prototype.lastIndexOf.call(t, e, r) : B(t, [
            e
        ], r, n, i);
        throw new TypeError("val must be string, number or Buffer");
    }
    function B(t, e, r, n, i) {
        let o, f = 1, s = t.length, u = e.length;
        if (void 0 !== n && ("ucs2" === (n = String(n).toLowerCase()) || "ucs-2" === n || "utf16le" === n || "utf-16le" === n)) {
            if (t.length < 2 || e.length < 2) return -1;
            f = 2, s /= 2, u /= 2, r /= 2;
        }
        function h(t, e) {
            return 1 === f ? t[e] : t.readUInt16BE(e * f);
        }
        if (i) {
            let n = -1;
            for(o = r; o < s; o++)if (h(t, o) === h(e, -1 === n ? 0 : o - n)) {
                if (-1 === n && (n = o), o - n + 1 === u) return n * f;
            } else -1 !== n && (o -= o - n), n = -1;
        } else for(r + u > s && (r = s - u), o = r; o >= 0; o--){
            let r = !0;
            for(let n = 0; n < u; n++)if (h(t, o + n) !== h(e, n)) {
                r = !1;
                break;
            }
            if (r) return o;
        }
        return -1;
    }
    function E(t, e, r, n) {
        r = Number(r) || 0;
        const i = t.length - r;
        n ? (n = Number(n)) > i && (n = i) : n = i;
        const o = e.length;
        let f;
        for(n > o / 2 && (n = o / 2), f = 0; f < n; ++f){
            const n = parseInt(e.substr(2 * f, 2), 16);
            if (Z(n)) return f;
            t[r + f] = n;
        }
        return f;
    }
    function m(t, e, r, n) {
        return X(V(e, t.length - r), t, r, n);
    }
    function I(t, e, r, n) {
        return X(function(t) {
            const e = [];
            for(let r = 0; r < t.length; ++r)e.push(255 & t.charCodeAt(r));
            return e;
        }(e), t, r, n);
    }
    function U(t, e, r, n) {
        return X(W(e), t, r, n);
    }
    function A(t, e, r, n) {
        return X(function(t, e) {
            let r, n, i;
            const o = [];
            for(let f = 0; f < t.length && !((e -= 2) < 0); ++f)r = t.charCodeAt(f), n = r >> 8, i = r % 256, o.push(i), o.push(n);
            return o;
        }(e, t.length - r), t, r, n);
    }
    function v(t, e, r) {
        return 0 === e && r === t.length ? n.fromByteArray(t) : n.fromByteArray(t.slice(e, r));
    }
    function R(t, e, r) {
        r = Math.min(t.length, r);
        const n = [];
        let i = e;
        for(; i < r;){
            const e = t[i];
            let o = null, f = e > 239 ? 4 : e > 223 ? 3 : e > 191 ? 2 : 1;
            if (i + f <= r) {
                let r, n, s, u;
                switch(f){
                    case 1:
                        e < 128 && (o = e);
                        break;
                    case 2:
                        r = t[i + 1], 128 == (192 & r) && (u = (31 & e) << 6 | 63 & r, u > 127 && (o = u));
                        break;
                    case 3:
                        r = t[i + 1], n = t[i + 2], 128 == (192 & r) && 128 == (192 & n) && (u = (15 & e) << 12 | (63 & r) << 6 | 63 & n, u > 2047 && (u < 55296 || u > 57343) && (o = u));
                        break;
                    case 4:
                        r = t[i + 1], n = t[i + 2], s = t[i + 3], 128 == (192 & r) && 128 == (192 & n) && 128 == (192 & s) && (u = (15 & e) << 18 | (63 & r) << 12 | (63 & n) << 6 | 63 & s, u > 65535 && u < 1114112 && (o = u));
                }
            }
            null === o ? (o = 65533, f = 1) : o > 65535 && (o -= 65536, n.push(o >>> 10 & 1023 | 55296), o = 56320 | 1023 & o), n.push(o), i += f;
        }
        return function(t) {
            const e = t.length;
            if (e <= T) return String.fromCharCode.apply(String, t);
            let r = "", n = 0;
            for(; n < e;)r += String.fromCharCode.apply(String, t.slice(n, n += T));
            return r;
        }(n);
    }
    t.kMaxLength = f, u.TYPED_ARRAY_SUPPORT = function() {
        try {
            const t = new Uint8Array(1), e = {
                foo: function() {
                    return 42;
                }
            };
            return Object.setPrototypeOf(e, Uint8Array.prototype), Object.setPrototypeOf(t, e), 42 === t.foo();
        } catch (t) {
            return !1;
        }
    }(), u.TYPED_ARRAY_SUPPORT || "undefined" == typeof console || "function" != typeof console.error || console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."), Object.defineProperty(u.prototype, "parent", {
        enumerable: !0,
        get: function() {
            if (u.isBuffer(this)) return this.buffer;
        }
    }), Object.defineProperty(u.prototype, "offset", {
        enumerable: !0,
        get: function() {
            if (u.isBuffer(this)) return this.byteOffset;
        }
    }), u.poolSize = 8192, u.from = function(t, e, r) {
        return h(t, e, r);
    }, Object.setPrototypeOf(u.prototype, Uint8Array.prototype), Object.setPrototypeOf(u, Uint8Array), u.alloc = function(t, e, r) {
        return function(t, e, r) {
            return c(t), t <= 0 ? s(t) : void 0 !== e ? "string" == typeof r ? s(t).fill(e, r) : s(t).fill(e) : s(t);
        }(t, e, r);
    }, u.allocUnsafe = function(t) {
        return a(t);
    }, u.allocUnsafeSlow = function(t) {
        return a(t);
    }, u.isBuffer = function(t) {
        return null != t && !0 === t._isBuffer && t !== u.prototype;
    }, u.compare = function(t, e) {
        if (J(t, Uint8Array) && (t = u.from(t, t.offset, t.byteLength)), J(e, Uint8Array) && (e = u.from(e, e.offset, e.byteLength)), !u.isBuffer(t) || !u.isBuffer(e)) throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
        if (t === e) return 0;
        let r = t.length, n = e.length;
        for(let i = 0, o = Math.min(r, n); i < o; ++i)if (t[i] !== e[i]) {
            r = t[i], n = e[i];
            break;
        }
        return r < n ? -1 : n < r ? 1 : 0;
    }, u.isEncoding = function(t) {
        switch(String(t).toLowerCase()){
            case "hex":
            case "utf8":
            case "utf-8":
            case "ascii":
            case "latin1":
            case "binary":
            case "base64":
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
                return !0;
            default:
                return !1;
        }
    }, u.concat = function(t, e) {
        if (!Array.isArray(t)) throw new TypeError('"list" argument must be an Array of Buffers');
        if (0 === t.length) return u.alloc(0);
        let r;
        if (void 0 === e) for(e = 0, r = 0; r < t.length; ++r)e += t[r].length;
        const n = u.allocUnsafe(e);
        let i = 0;
        for(r = 0; r < t.length; ++r){
            let e = t[r];
            if (J(e, Uint8Array)) i + e.length > n.length ? (u.isBuffer(e) || (e = u.from(e)), e.copy(n, i)) : Uint8Array.prototype.set.call(n, e, i);
            else {
                if (!u.isBuffer(e)) throw new TypeError('"list" argument must be an Array of Buffers');
                e.copy(n, i);
            }
            i += e.length;
        }
        return n;
    }, u.byteLength = y, u.prototype._isBuffer = !0, u.prototype.swap16 = function() {
        const t = this.length;
        if (t % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
        for(let e = 0; e < t; e += 2)d(this, e, e + 1);
        return this;
    }, u.prototype.swap32 = function() {
        const t = this.length;
        if (t % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
        for(let e = 0; e < t; e += 4)d(this, e, e + 3), d(this, e + 1, e + 2);
        return this;
    }, u.prototype.swap64 = function() {
        const t = this.length;
        if (t % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
        for(let e = 0; e < t; e += 8)d(this, e, e + 7), d(this, e + 1, e + 6), d(this, e + 2, e + 5), d(this, e + 3, e + 4);
        return this;
    }, u.prototype.toString = function() {
        const t = this.length;
        return 0 === t ? "" : 0 === arguments.length ? R(this, 0, t) : w.apply(this, arguments);
    }, u.prototype.toLocaleString = u.prototype.toString, u.prototype.equals = function(t) {
        if (!u.isBuffer(t)) throw new TypeError("Argument must be a Buffer");
        return this === t || 0 === u.compare(this, t);
    }, u.prototype.inspect = function() {
        let e = "";
        const r = t.INSPECT_MAX_BYTES;
        return e = this.toString("hex", 0, r).replace(/(.{2})/g, "$1 ").trim(), this.length > r && (e += " ... "), "<Buffer " + e + ">";
    }, o && (u.prototype[o] = u.prototype.inspect), u.prototype.compare = function(t, e, r, n, i) {
        if (J(t, Uint8Array) && (t = u.from(t, t.offset, t.byteLength)), !u.isBuffer(t)) throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof t);
        if (void 0 === e && (e = 0), void 0 === r && (r = t ? t.length : 0), void 0 === n && (n = 0), void 0 === i && (i = this.length), e < 0 || r > t.length || n < 0 || i > this.length) throw new RangeError("out of range index");
        if (n >= i && e >= r) return 0;
        if (n >= i) return -1;
        if (e >= r) return 1;
        if (this === t) return 0;
        let o = (i >>>= 0) - (n >>>= 0), f = (r >>>= 0) - (e >>>= 0);
        const s = Math.min(o, f), h = this.slice(n, i), c = t.slice(e, r);
        for(let t = 0; t < s; ++t)if (h[t] !== c[t]) {
            o = h[t], f = c[t];
            break;
        }
        return o < f ? -1 : f < o ? 1 : 0;
    }, u.prototype.includes = function(t, e, r) {
        return -1 !== this.indexOf(t, e, r);
    }, u.prototype.indexOf = function(t, e, r) {
        return b(this, t, e, r, !0);
    }, u.prototype.lastIndexOf = function(t, e, r) {
        return b(this, t, e, r, !1);
    }, u.prototype.write = function(t, e, r, n) {
        if (void 0 === e) n = "utf8", r = this.length, e = 0;
        else if (void 0 === r && "string" == typeof e) n = e, r = this.length, e = 0;
        else {
            if (!isFinite(e)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
            e >>>= 0, isFinite(r) ? (r >>>= 0, void 0 === n && (n = "utf8")) : (n = r, r = void 0);
        }
        const i = this.length - e;
        if ((void 0 === r || r > i) && (r = i), t.length > 0 && (r < 0 || e < 0) || e > this.length) throw new RangeError("Attempt to write outside buffer bounds");
        n || (n = "utf8");
        let o = !1;
        for(;;)switch(n){
            case "hex":
                return E(this, t, e, r);
            case "utf8":
            case "utf-8":
                return m(this, t, e, r);
            case "ascii":
            case "latin1":
            case "binary":
                return I(this, t, e, r);
            case "base64":
                return U(this, t, e, r);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
                return A(this, t, e, r);
            default:
                if (o) throw new TypeError("Unknown encoding: " + n);
                n = ("" + n).toLowerCase(), o = !0;
        }
    }, u.prototype.toJSON = function() {
        return {
            type: "Buffer",
            data: Array.prototype.slice.call(this._arr || this, 0)
        };
    };
    const T = 4096;
    function O(t, e, r) {
        let n = "";
        r = Math.min(t.length, r);
        for(let i = e; i < r; ++i)n += String.fromCharCode(127 & t[i]);
        return n;
    }
    function _(t, e, r) {
        let n = "";
        r = Math.min(t.length, r);
        for(let i = e; i < r; ++i)n += String.fromCharCode(t[i]);
        return n;
    }
    function L(t, e, r) {
        const n = t.length;
        (!e || e < 0) && (e = 0), (!r || r < 0 || r > n) && (r = n);
        let i = "";
        for(let n = e; n < r; ++n)i += H[t[n]];
        return i;
    }
    function S(t, e, r) {
        const n = t.slice(e, r);
        let i = "";
        for(let t = 0; t < n.length - 1; t += 2)i += String.fromCharCode(n[t] + 256 * n[t + 1]);
        return i;
    }
    function x(t, e, r) {
        if (t % 1 != 0 || t < 0) throw new RangeError("offset is not uint");
        if (t + e > r) throw new RangeError("Trying to access beyond buffer length");
    }
    function $(t, e, r, n, i, o) {
        if (!u.isBuffer(t)) throw new TypeError('"buffer" argument must be a Buffer instance');
        if (e > i || e < o) throw new RangeError('"value" argument is out of bounds');
        if (r + n > t.length) throw new RangeError("Index out of range");
    }
    function P(t, e, r, n, i) {
        z(e, n, i, t, r, 7);
        let o = Number(e & BigInt(4294967295));
        t[r++] = o, o >>= 8, t[r++] = o, o >>= 8, t[r++] = o, o >>= 8, t[r++] = o;
        let f = Number(e >> BigInt(32) & BigInt(4294967295));
        return t[r++] = f, f >>= 8, t[r++] = f, f >>= 8, t[r++] = f, f >>= 8, t[r++] = f, r;
    }
    function C(t, e, r, n, i) {
        z(e, n, i, t, r, 7);
        let o = Number(e & BigInt(4294967295));
        t[r + 7] = o, o >>= 8, t[r + 6] = o, o >>= 8, t[r + 5] = o, o >>= 8, t[r + 4] = o;
        let f = Number(e >> BigInt(32) & BigInt(4294967295));
        return t[r + 3] = f, f >>= 8, t[r + 2] = f, f >>= 8, t[r + 1] = f, f >>= 8, t[r] = f, r + 8;
    }
    function j(t, e, r, n, i, o) {
        if (r + n > t.length) throw new RangeError("Index out of range");
        if (r < 0) throw new RangeError("Index out of range");
    }
    function N(t, e, r, n, o) {
        return e = +e, r >>>= 0, o || j(t, 0, r, 4), i.write(t, e, r, n, 23, 4), r + 4;
    }
    function k(t, e, r, n, o) {
        return e = +e, r >>>= 0, o || j(t, 0, r, 8), i.write(t, e, r, n, 52, 8), r + 8;
    }
    u.prototype.slice = function(t, e) {
        const r = this.length;
        (t = ~~t) < 0 ? (t += r) < 0 && (t = 0) : t > r && (t = r), (e = void 0 === e ? r : ~~e) < 0 ? (e += r) < 0 && (e = 0) : e > r && (e = r), e < t && (e = t);
        const n = this.subarray(t, e);
        return Object.setPrototypeOf(n, u.prototype), n;
    }, u.prototype.readUintLE = u.prototype.readUIntLE = function(t, e, r) {
        t >>>= 0, e >>>= 0, r || x(t, e, this.length);
        let n = this[t], i = 1, o = 0;
        for(; ++o < e && (i *= 256);)n += this[t + o] * i;
        return n;
    }, u.prototype.readUintBE = u.prototype.readUIntBE = function(t, e, r) {
        t >>>= 0, e >>>= 0, r || x(t, e, this.length);
        let n = this[t + --e], i = 1;
        for(; e > 0 && (i *= 256);)n += this[t + --e] * i;
        return n;
    }, u.prototype.readUint8 = u.prototype.readUInt8 = function(t, e) {
        return t >>>= 0, e || x(t, 1, this.length), this[t];
    }, u.prototype.readUint16LE = u.prototype.readUInt16LE = function(t, e) {
        return t >>>= 0, e || x(t, 2, this.length), this[t] | this[t + 1] << 8;
    }, u.prototype.readUint16BE = u.prototype.readUInt16BE = function(t, e) {
        return t >>>= 0, e || x(t, 2, this.length), this[t] << 8 | this[t + 1];
    }, u.prototype.readUint32LE = u.prototype.readUInt32LE = function(t, e) {
        return t >>>= 0, e || x(t, 4, this.length), (this[t] | this[t + 1] << 8 | this[t + 2] << 16) + 16777216 * this[t + 3];
    }, u.prototype.readUint32BE = u.prototype.readUInt32BE = function(t, e) {
        return t >>>= 0, e || x(t, 4, this.length), 16777216 * this[t] + (this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3]);
    }, u.prototype.readBigUInt64LE = K(function(t) {
        q(t >>>= 0, "offset");
        const e = this[t], r = this[t + 7];
        void 0 !== e && void 0 !== r || Y(t, this.length - 8);
        const n = e + 256 * this[++t] + 65536 * this[++t] + this[++t] * 2 ** 24, i = this[++t] + 256 * this[++t] + 65536 * this[++t] + r * 2 ** 24;
        return BigInt(n) + (BigInt(i) << BigInt(32));
    }), u.prototype.readBigUInt64BE = K(function(t) {
        q(t >>>= 0, "offset");
        const e = this[t], r = this[t + 7];
        void 0 !== e && void 0 !== r || Y(t, this.length - 8);
        const n = e * 2 ** 24 + 65536 * this[++t] + 256 * this[++t] + this[++t], i = this[++t] * 2 ** 24 + 65536 * this[++t] + 256 * this[++t] + r;
        return (BigInt(n) << BigInt(32)) + BigInt(i);
    }), u.prototype.readIntLE = function(t, e, r) {
        t >>>= 0, e >>>= 0, r || x(t, e, this.length);
        let n = this[t], i = 1, o = 0;
        for(; ++o < e && (i *= 256);)n += this[t + o] * i;
        return i *= 128, n >= i && (n -= Math.pow(2, 8 * e)), n;
    }, u.prototype.readIntBE = function(t, e, r) {
        t >>>= 0, e >>>= 0, r || x(t, e, this.length);
        let n = e, i = 1, o = this[t + --n];
        for(; n > 0 && (i *= 256);)o += this[t + --n] * i;
        return i *= 128, o >= i && (o -= Math.pow(2, 8 * e)), o;
    }, u.prototype.readInt8 = function(t, e) {
        return t >>>= 0, e || x(t, 1, this.length), 128 & this[t] ? -1 * (255 - this[t] + 1) : this[t];
    }, u.prototype.readInt16LE = function(t, e) {
        t >>>= 0, e || x(t, 2, this.length);
        const r = this[t] | this[t + 1] << 8;
        return 32768 & r ? 4294901760 | r : r;
    }, u.prototype.readInt16BE = function(t, e) {
        t >>>= 0, e || x(t, 2, this.length);
        const r = this[t + 1] | this[t] << 8;
        return 32768 & r ? 4294901760 | r : r;
    }, u.prototype.readInt32LE = function(t, e) {
        return t >>>= 0, e || x(t, 4, this.length), this[t] | this[t + 1] << 8 | this[t + 2] << 16 | this[t + 3] << 24;
    }, u.prototype.readInt32BE = function(t, e) {
        return t >>>= 0, e || x(t, 4, this.length), this[t] << 24 | this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3];
    }, u.prototype.readBigInt64LE = K(function(t) {
        q(t >>>= 0, "offset");
        const e = this[t], r = this[t + 7];
        void 0 !== e && void 0 !== r || Y(t, this.length - 8);
        const n = this[t + 4] + 256 * this[t + 5] + 65536 * this[t + 6] + (r << 24);
        return (BigInt(n) << BigInt(32)) + BigInt(e + 256 * this[++t] + 65536 * this[++t] + this[++t] * 2 ** 24);
    }), u.prototype.readBigInt64BE = K(function(t) {
        q(t >>>= 0, "offset");
        const e = this[t], r = this[t + 7];
        void 0 !== e && void 0 !== r || Y(t, this.length - 8);
        const n = (e << 24) + 65536 * this[++t] + 256 * this[++t] + this[++t];
        return (BigInt(n) << BigInt(32)) + BigInt(this[++t] * 2 ** 24 + 65536 * this[++t] + 256 * this[++t] + r);
    }), u.prototype.readFloatLE = function(t, e) {
        return t >>>= 0, e || x(t, 4, this.length), i.read(this, t, !0, 23, 4);
    }, u.prototype.readFloatBE = function(t, e) {
        return t >>>= 0, e || x(t, 4, this.length), i.read(this, t, !1, 23, 4);
    }, u.prototype.readDoubleLE = function(t, e) {
        return t >>>= 0, e || x(t, 8, this.length), i.read(this, t, !0, 52, 8);
    }, u.prototype.readDoubleBE = function(t, e) {
        return t >>>= 0, e || x(t, 8, this.length), i.read(this, t, !1, 52, 8);
    }, u.prototype.writeUintLE = u.prototype.writeUIntLE = function(t, e, r, n) {
        if (t = +t, e >>>= 0, r >>>= 0, !n) {
            $(this, t, e, r, Math.pow(2, 8 * r) - 1, 0);
        }
        let i = 1, o = 0;
        for(this[e] = 255 & t; ++o < r && (i *= 256);)this[e + o] = t / i & 255;
        return e + r;
    }, u.prototype.writeUintBE = u.prototype.writeUIntBE = function(t, e, r, n) {
        if (t = +t, e >>>= 0, r >>>= 0, !n) {
            $(this, t, e, r, Math.pow(2, 8 * r) - 1, 0);
        }
        let i = r - 1, o = 1;
        for(this[e + i] = 255 & t; --i >= 0 && (o *= 256);)this[e + i] = t / o & 255;
        return e + r;
    }, u.prototype.writeUint8 = u.prototype.writeUInt8 = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 1, 255, 0), this[e] = 255 & t, e + 1;
    }, u.prototype.writeUint16LE = u.prototype.writeUInt16LE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 2, 65535, 0), this[e] = 255 & t, this[e + 1] = t >>> 8, e + 2;
    }, u.prototype.writeUint16BE = u.prototype.writeUInt16BE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 2, 65535, 0), this[e] = t >>> 8, this[e + 1] = 255 & t, e + 2;
    }, u.prototype.writeUint32LE = u.prototype.writeUInt32LE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 4, 4294967295, 0), this[e + 3] = t >>> 24, this[e + 2] = t >>> 16, this[e + 1] = t >>> 8, this[e] = 255 & t, e + 4;
    }, u.prototype.writeUint32BE = u.prototype.writeUInt32BE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 4, 4294967295, 0), this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t, e + 4;
    }, u.prototype.writeBigUInt64LE = K(function(t, e = 0) {
        return P(this, t, e, BigInt(0), BigInt("0xffffffffffffffff"));
    }), u.prototype.writeBigUInt64BE = K(function(t, e = 0) {
        return C(this, t, e, BigInt(0), BigInt("0xffffffffffffffff"));
    }), u.prototype.writeIntLE = function(t, e, r, n) {
        if (t = +t, e >>>= 0, !n) {
            const n = Math.pow(2, 8 * r - 1);
            $(this, t, e, r, n - 1, -n);
        }
        let i = 0, o = 1, f = 0;
        for(this[e] = 255 & t; ++i < r && (o *= 256);)t < 0 && 0 === f && 0 !== this[e + i - 1] && (f = 1), this[e + i] = (t / o >> 0) - f & 255;
        return e + r;
    }, u.prototype.writeIntBE = function(t, e, r, n) {
        if (t = +t, e >>>= 0, !n) {
            const n = Math.pow(2, 8 * r - 1);
            $(this, t, e, r, n - 1, -n);
        }
        let i = r - 1, o = 1, f = 0;
        for(this[e + i] = 255 & t; --i >= 0 && (o *= 256);)t < 0 && 0 === f && 0 !== this[e + i + 1] && (f = 1), this[e + i] = (t / o >> 0) - f & 255;
        return e + r;
    }, u.prototype.writeInt8 = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 1, 127, -128), t < 0 && (t = 255 + t + 1), this[e] = 255 & t, e + 1;
    }, u.prototype.writeInt16LE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 2, 32767, -32768), this[e] = 255 & t, this[e + 1] = t >>> 8, e + 2;
    }, u.prototype.writeInt16BE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 2, 32767, -32768), this[e] = t >>> 8, this[e + 1] = 255 & t, e + 2;
    }, u.prototype.writeInt32LE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 4, 2147483647, -2147483648), this[e] = 255 & t, this[e + 1] = t >>> 8, this[e + 2] = t >>> 16, this[e + 3] = t >>> 24, e + 4;
    }, u.prototype.writeInt32BE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 4, 2147483647, -2147483648), t < 0 && (t = 4294967295 + t + 1), this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t, e + 4;
    }, u.prototype.writeBigInt64LE = K(function(t, e = 0) {
        return P(this, t, e, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
    }), u.prototype.writeBigInt64BE = K(function(t, e = 0) {
        return C(this, t, e, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
    }), u.prototype.writeFloatLE = function(t, e, r) {
        return N(this, t, e, !0, r);
    }, u.prototype.writeFloatBE = function(t, e, r) {
        return N(this, t, e, !1, r);
    }, u.prototype.writeDoubleLE = function(t, e, r) {
        return k(this, t, e, !0, r);
    }, u.prototype.writeDoubleBE = function(t, e, r) {
        return k(this, t, e, !1, r);
    }, u.prototype.copy = function(t, e, r, n) {
        if (!u.isBuffer(t)) throw new TypeError("argument should be a Buffer");
        if (r || (r = 0), n || 0 === n || (n = this.length), e >= t.length && (e = t.length), e || (e = 0), n > 0 && n < r && (n = r), n === r) return 0;
        if (0 === t.length || 0 === this.length) return 0;
        if (e < 0) throw new RangeError("targetStart out of bounds");
        if (r < 0 || r >= this.length) throw new RangeError("Index out of range");
        if (n < 0) throw new RangeError("sourceEnd out of bounds");
        n > this.length && (n = this.length), t.length - e < n - r && (n = t.length - e + r);
        const i = n - r;
        return this === t && "function" == typeof Uint8Array.prototype.copyWithin ? this.copyWithin(e, r, n) : Uint8Array.prototype.set.call(t, this.subarray(r, n), e), i;
    }, u.prototype.fill = function(t, e, r, n) {
        if ("string" == typeof t) {
            if ("string" == typeof e ? (n = e, e = 0, r = this.length) : "string" == typeof r && (n = r, r = this.length), void 0 !== n && "string" != typeof n) throw new TypeError("encoding must be a string");
            if ("string" == typeof n && !u.isEncoding(n)) throw new TypeError("Unknown encoding: " + n);
            if (1 === t.length) {
                const e = t.charCodeAt(0);
                ("utf8" === n && e < 128 || "latin1" === n) && (t = e);
            }
        } else "number" == typeof t ? t &= 255 : "boolean" == typeof t && (t = Number(t));
        if (e < 0 || this.length < e || this.length < r) throw new RangeError("Out of range index");
        if (r <= e) return this;
        let i;
        if (e >>>= 0, r = void 0 === r ? this.length : r >>> 0, t || (t = 0), "number" == typeof t) for(i = e; i < r; ++i)this[i] = t;
        else {
            const o = u.isBuffer(t) ? t : u.from(t, n), f = o.length;
            if (0 === f) throw new TypeError('The value "' + t + '" is invalid for argument "value"');
            for(i = 0; i < r - e; ++i)this[i + e] = o[i % f];
        }
        return this;
    };
    const F = {};
    function M(t, e, r) {
        F[t] = class extends r {
            constructor(){
                super(), Object.defineProperty(this, "message", {
                    value: e.apply(this, arguments),
                    writable: !0,
                    configurable: !0
                }), this.name = `${this.name} [${t}]`, delete this.name;
            }
            get code() {
                return t;
            }
            set code(t) {
                Object.defineProperty(this, "code", {
                    configurable: !0,
                    enumerable: !0,
                    value: t,
                    writable: !0
                });
            }
            toString() {
                return `${this.name} [${t}]: ${this.message}`;
            }
        };
    }
    function D(t) {
        let e = "", r = t.length;
        const n = "-" === t[0] ? 1 : 0;
        for(; r >= n + 4; r -= 3)e = `_${t.slice(r - 3, r)}${e}`;
        return `${t.slice(0, r)}${e}`;
    }
    function z(t, e, r, n, i, o) {
        if (t > r || t < e) {
            const n = "bigint" == typeof e ? "n" : "";
            let i;
            throw i = o > 3 ? 0 === e || e === BigInt(0) ? `>= 0${n} and < 2${n} ** ${8 * (o + 1)}${n}` : `>= -(2${n} ** ${8 * (o + 1) - 1}${n}) and < 2 ** ${8 * (o + 1) - 1}${n}` : `>= ${e}${n} and <= ${r}${n}`, new F.ERR_OUT_OF_RANGE("value", i, t);
        }
        !function(t, e, r) {
            q(e, "offset"), void 0 !== t[e] && void 0 !== t[e + r] || Y(e, t.length - (r + 1));
        }(n, i, o);
    }
    function q(t, e) {
        if ("number" != typeof t) throw new F.ERR_INVALID_ARG_TYPE(e, "number", t);
    }
    function Y(t, e, r) {
        if (Math.floor(t) !== t) throw q(t, r), new F.ERR_OUT_OF_RANGE(r || "offset", "an integer", t);
        if (e < 0) throw new F.ERR_BUFFER_OUT_OF_BOUNDS;
        throw new F.ERR_OUT_OF_RANGE(r || "offset", `>= ${r ? 1 : 0} and <= ${e}`, t);
    }
    M("ERR_BUFFER_OUT_OF_BOUNDS", function(t) {
        return t ? `${t} is outside of buffer bounds` : "Attempt to access memory outside buffer bounds";
    }, RangeError), M("ERR_INVALID_ARG_TYPE", function(t, e) {
        return `The "${t}" argument must be of type number. Received type ${typeof e}`;
    }, TypeError), M("ERR_OUT_OF_RANGE", function(t, e, r) {
        let n = `The value of "${t}" is out of range.`, i = r;
        return Number.isInteger(r) && Math.abs(r) > 2 ** 32 ? i = D(String(r)) : "bigint" == typeof r && (i = String(r), (r > BigInt(2) ** BigInt(32) || r < -(BigInt(2) ** BigInt(32))) && (i = D(i)), i += "n"), n += ` It must be ${e}. Received ${i}`, n;
    }, RangeError);
    const G = /[^+/0-9A-Za-z-_]/g;
    function V(t, e) {
        let r;
        e = e || 1 / 0;
        const n = t.length;
        let i = null;
        const o = [];
        for(let f = 0; f < n; ++f){
            if (r = t.charCodeAt(f), r > 55295 && r < 57344) {
                if (!i) {
                    if (r > 56319) {
                        (e -= 3) > -1 && o.push(239, 191, 189);
                        continue;
                    }
                    if (f + 1 === n) {
                        (e -= 3) > -1 && o.push(239, 191, 189);
                        continue;
                    }
                    i = r;
                    continue;
                }
                if (r < 56320) {
                    (e -= 3) > -1 && o.push(239, 191, 189), i = r;
                    continue;
                }
                r = 65536 + (i - 55296 << 10 | r - 56320);
            } else i && (e -= 3) > -1 && o.push(239, 191, 189);
            if (i = null, r < 128) {
                if ((e -= 1) < 0) break;
                o.push(r);
            } else if (r < 2048) {
                if ((e -= 2) < 0) break;
                o.push(r >> 6 | 192, 63 & r | 128);
            } else if (r < 65536) {
                if ((e -= 3) < 0) break;
                o.push(r >> 12 | 224, r >> 6 & 63 | 128, 63 & r | 128);
            } else {
                if (!(r < 1114112)) throw new Error("Invalid code point");
                if ((e -= 4) < 0) break;
                o.push(r >> 18 | 240, r >> 12 & 63 | 128, r >> 6 & 63 | 128, 63 & r | 128);
            }
        }
        return o;
    }
    function W(t) {
        return n.toByteArray(function(t) {
            if ((t = (t = t.split("=")[0]).trim().replace(G, "")).length < 2) return "";
            for(; t.length % 4 != 0;)t += "=";
            return t;
        }(t));
    }
    function X(t, e, r, n) {
        let i;
        for(i = 0; i < n && !(i + r >= e.length || i >= t.length); ++i)e[i + r] = t[i];
        return i;
    }
    function J(t, e) {
        return t instanceof e || null != t && null != t.constructor && null != t.constructor.name && t.constructor.name === e.name;
    }
    function Z(t) {
        return t != t;
    }
    const H = function() {
        const t = "0123456789abcdef", e = new Array(256);
        for(let r = 0; r < 16; ++r){
            const n = 16 * r;
            for(let i = 0; i < 16; ++i)e[n + i] = t[r] + t[i];
        }
        return e;
    }();
    function K(t) {
        return "undefined" == typeof BigInt ? Q : t;
    }
    function Q() {
        throw new Error("BigInt not supported");
    }
}(t.__exports); //# sourceMappingURL=index.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/buffer/index.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index2$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/index2.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$base64$2d$js$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/base64-js/index.mjs [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index3$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/index3.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$ieee754$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/ieee754/index.mjs [app-route] (ecmascript) <module evaluation>");
;
;
;
;
;
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */ !function(t) {
    const n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index2$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"], i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index3$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"], o = "function" == typeof Symbol && "function" == typeof Symbol.for ? Symbol.for("nodejs.util.inspect.custom") : null;
    t.Buffer = u, t.SlowBuffer = function(t) {
        +t != t && (t = 0);
        return u.alloc(+t);
    }, t.INSPECT_MAX_BYTES = 50;
    const f = 2147483647;
    function s(t) {
        if (t > f) throw new RangeError('The value "' + t + '" is invalid for option "size"');
        const e = new Uint8Array(t);
        return Object.setPrototypeOf(e, u.prototype), e;
    }
    function u(t, e, r) {
        if ("number" == typeof t) {
            if ("string" == typeof e) throw new TypeError('The "string" argument must be of type string. Received type number');
            return a(t);
        }
        return h(t, e, r);
    }
    function h(t, e, r) {
        if ("string" == typeof t) return function(t, e) {
            "string" == typeof e && "" !== e || (e = "utf8");
            if (!u.isEncoding(e)) throw new TypeError("Unknown encoding: " + e);
            const r = 0 | y(t, e);
            let n = s(r);
            const i = n.write(t, e);
            i !== r && (n = n.slice(0, i));
            return n;
        }(t, e);
        if (ArrayBuffer.isView(t)) return function(t) {
            if (J(t, Uint8Array)) {
                const e = new Uint8Array(t);
                return l(e.buffer, e.byteOffset, e.byteLength);
            }
            return p(t);
        }(t);
        if (null == t) throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof t);
        if (J(t, ArrayBuffer) || t && J(t.buffer, ArrayBuffer)) return l(t, e, r);
        if ("undefined" != typeof SharedArrayBuffer && (J(t, SharedArrayBuffer) || t && J(t.buffer, SharedArrayBuffer))) return l(t, e, r);
        if ("number" == typeof t) throw new TypeError('The "value" argument must not be of type number. Received type number');
        const n = t.valueOf && t.valueOf();
        if (null != n && n !== t) return u.from(n, e, r);
        const i = function(t) {
            if (u.isBuffer(t)) {
                const e = 0 | g(t.length), r = s(e);
                return 0 === r.length || t.copy(r, 0, 0, e), r;
            }
            if (void 0 !== t.length) return "number" != typeof t.length || Z(t.length) ? s(0) : p(t);
            if ("Buffer" === t.type && Array.isArray(t.data)) return p(t.data);
        }(t);
        if (i) return i;
        if ("undefined" != typeof Symbol && null != Symbol.toPrimitive && "function" == typeof t[Symbol.toPrimitive]) return u.from(t[Symbol.toPrimitive]("string"), e, r);
        throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof t);
    }
    function c(t) {
        if ("number" != typeof t) throw new TypeError('"size" argument must be of type number');
        if (t < 0) throw new RangeError('The value "' + t + '" is invalid for option "size"');
    }
    function a(t) {
        return c(t), s(t < 0 ? 0 : 0 | g(t));
    }
    function p(t) {
        const e = t.length < 0 ? 0 : 0 | g(t.length), r = s(e);
        for(let n = 0; n < e; n += 1)r[n] = 255 & t[n];
        return r;
    }
    function l(t, e, r) {
        if (e < 0 || t.byteLength < e) throw new RangeError('"offset" is outside of buffer bounds');
        if (t.byteLength < e + (r || 0)) throw new RangeError('"length" is outside of buffer bounds');
        let n;
        return n = void 0 === e && void 0 === r ? new Uint8Array(t) : void 0 === r ? new Uint8Array(t, e) : new Uint8Array(t, e, r), Object.setPrototypeOf(n, u.prototype), n;
    }
    function g(t) {
        if (t >= f) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + f.toString(16) + " bytes");
        return 0 | t;
    }
    function y(t, e) {
        if (u.isBuffer(t)) return t.length;
        if (ArrayBuffer.isView(t) || J(t, ArrayBuffer)) return t.byteLength;
        if ("string" != typeof t) throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof t);
        const r = t.length, n = arguments.length > 2 && !0 === arguments[2];
        if (!n && 0 === r) return 0;
        let i = !1;
        for(;;)switch(e){
            case "ascii":
            case "latin1":
            case "binary":
                return r;
            case "utf8":
            case "utf-8":
                return q(t).length;
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
                return 2 * r;
            case "hex":
                return r >>> 1;
            case "base64":
                return W(t).length;
            default:
                if (i) return n ? -1 : q(t).length;
                e = ("" + e).toLowerCase(), i = !0;
        }
    }
    function w(t, e, r) {
        let n = !1;
        if ((void 0 === e || e < 0) && (e = 0), e > this.length) return "";
        if ((void 0 === r || r > this.length) && (r = this.length), r <= 0) return "";
        if ((r >>>= 0) <= (e >>>= 0)) return "";
        for(t || (t = "utf8");;)switch(t){
            case "hex":
                return L(this, e, r);
            case "utf8":
            case "utf-8":
                return R(this, e, r);
            case "ascii":
                return O(this, e, r);
            case "latin1":
            case "binary":
                return _(this, e, r);
            case "base64":
                return v(this, e, r);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
                return S(this, e, r);
            default:
                if (n) throw new TypeError("Unknown encoding: " + t);
                t = (t + "").toLowerCase(), n = !0;
        }
    }
    function d(t, e, r) {
        const n = t[e];
        t[e] = t[r], t[r] = n;
    }
    function b(t, e, r, n, i) {
        if (0 === t.length) return -1;
        if ("string" == typeof r ? (n = r, r = 0) : r > 2147483647 ? r = 2147483647 : r < -2147483648 && (r = -2147483648), Z(r = +r) && (r = i ? 0 : t.length - 1), r < 0 && (r = t.length + r), r >= t.length) {
            if (i) return -1;
            r = t.length - 1;
        } else if (r < 0) {
            if (!i) return -1;
            r = 0;
        }
        if ("string" == typeof e && (e = u.from(e, n)), u.isBuffer(e)) return 0 === e.length ? -1 : m(t, e, r, n, i);
        if ("number" == typeof e) return e &= 255, "function" == typeof Uint8Array.prototype.indexOf ? i ? Uint8Array.prototype.indexOf.call(t, e, r) : Uint8Array.prototype.lastIndexOf.call(t, e, r) : m(t, [
            e
        ], r, n, i);
        throw new TypeError("val must be string, number or Buffer");
    }
    function m(t, e, r, n, i) {
        let o, f = 1, s = t.length, u = e.length;
        if (void 0 !== n && ("ucs2" === (n = String(n).toLowerCase()) || "ucs-2" === n || "utf16le" === n || "utf-16le" === n)) {
            if (t.length < 2 || e.length < 2) return -1;
            f = 2, s /= 2, u /= 2, r /= 2;
        }
        function h(t, e) {
            return 1 === f ? t[e] : t.readUInt16BE(e * f);
        }
        if (i) {
            let n = -1;
            for(o = r; o < s; o++)if (h(t, o) === h(e, -1 === n ? 0 : o - n)) {
                if (-1 === n && (n = o), o - n + 1 === u) return n * f;
            } else -1 !== n && (o -= o - n), n = -1;
        } else for(r + u > s && (r = s - u), o = r; o >= 0; o--){
            let r = !0;
            for(let n = 0; n < u; n++)if (h(t, o + n) !== h(e, n)) {
                r = !1;
                break;
            }
            if (r) return o;
        }
        return -1;
    }
    function B(t, e, r, n) {
        r = Number(r) || 0;
        const i = t.length - r;
        n ? (n = Number(n)) > i && (n = i) : n = i;
        const o = e.length;
        let f;
        for(n > o / 2 && (n = o / 2), f = 0; f < n; ++f){
            const n = parseInt(e.substr(2 * f, 2), 16);
            if (Z(n)) return f;
            t[r + f] = n;
        }
        return f;
    }
    function E(t, e, r, n) {
        return X(q(e, t.length - r), t, r, n);
    }
    function I(t, e, r, n) {
        return X(function(t) {
            const e = [];
            for(let r = 0; r < t.length; ++r)e.push(255 & t.charCodeAt(r));
            return e;
        }(e), t, r, n);
    }
    function U(t, e, r, n) {
        return X(W(e), t, r, n);
    }
    function A(t, e, r, n) {
        return X(function(t, e) {
            let r, n, i;
            const o = [];
            for(let f = 0; f < t.length && !((e -= 2) < 0); ++f)r = t.charCodeAt(f), n = r >> 8, i = r % 256, o.push(i), o.push(n);
            return o;
        }(e, t.length - r), t, r, n);
    }
    function v(t, e, r) {
        return 0 === e && r === t.length ? n.fromByteArray(t) : n.fromByteArray(t.slice(e, r));
    }
    function R(t, e, r) {
        r = Math.min(t.length, r);
        const n = [];
        let i = e;
        for(; i < r;){
            const e = t[i];
            let o = null, f = e > 239 ? 4 : e > 223 ? 3 : e > 191 ? 2 : 1;
            if (i + f <= r) {
                let r, n, s, u;
                switch(f){
                    case 1:
                        e < 128 && (o = e);
                        break;
                    case 2:
                        r = t[i + 1], 128 == (192 & r) && (u = (31 & e) << 6 | 63 & r, u > 127 && (o = u));
                        break;
                    case 3:
                        r = t[i + 1], n = t[i + 2], 128 == (192 & r) && 128 == (192 & n) && (u = (15 & e) << 12 | (63 & r) << 6 | 63 & n, u > 2047 && (u < 55296 || u > 57343) && (o = u));
                        break;
                    case 4:
                        r = t[i + 1], n = t[i + 2], s = t[i + 3], 128 == (192 & r) && 128 == (192 & n) && 128 == (192 & s) && (u = (15 & e) << 18 | (63 & r) << 12 | (63 & n) << 6 | 63 & s, u > 65535 && u < 1114112 && (o = u));
                }
            }
            null === o ? (o = 65533, f = 1) : o > 65535 && (o -= 65536, n.push(o >>> 10 & 1023 | 55296), o = 56320 | 1023 & o), n.push(o), i += f;
        }
        return function(t) {
            const e = t.length;
            if (e <= T) return String.fromCharCode.apply(String, t);
            let r = "", n = 0;
            for(; n < e;)r += String.fromCharCode.apply(String, t.slice(n, n += T));
            return r;
        }(n);
    }
    t.kMaxLength = f, u.TYPED_ARRAY_SUPPORT = function() {
        try {
            const t = new Uint8Array(1), e = {
                foo: function() {
                    return 42;
                }
            };
            return Object.setPrototypeOf(e, Uint8Array.prototype), Object.setPrototypeOf(t, e), 42 === t.foo();
        } catch (t) {
            return !1;
        }
    }(), u.TYPED_ARRAY_SUPPORT || "undefined" == typeof console || "function" != typeof console.error || console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."), Object.defineProperty(u.prototype, "parent", {
        enumerable: !0,
        get: function() {
            if (u.isBuffer(this)) return this.buffer;
        }
    }), Object.defineProperty(u.prototype, "offset", {
        enumerable: !0,
        get: function() {
            if (u.isBuffer(this)) return this.byteOffset;
        }
    }), u.poolSize = 8192, u.from = function(t, e, r) {
        return h(t, e, r);
    }, Object.setPrototypeOf(u.prototype, Uint8Array.prototype), Object.setPrototypeOf(u, Uint8Array), u.alloc = function(t, e, r) {
        return function(t, e, r) {
            return c(t), t <= 0 ? s(t) : void 0 !== e ? "string" == typeof r ? s(t).fill(e, r) : s(t).fill(e) : s(t);
        }(t, e, r);
    }, u.allocUnsafe = function(t) {
        return a(t);
    }, u.allocUnsafeSlow = function(t) {
        return a(t);
    }, u.isBuffer = function(t) {
        return null != t && !0 === t._isBuffer && t !== u.prototype;
    }, u.compare = function(t, e) {
        if (J(t, Uint8Array) && (t = u.from(t, t.offset, t.byteLength)), J(e, Uint8Array) && (e = u.from(e, e.offset, e.byteLength)), !u.isBuffer(t) || !u.isBuffer(e)) throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
        if (t === e) return 0;
        let r = t.length, n = e.length;
        for(let i = 0, o = Math.min(r, n); i < o; ++i)if (t[i] !== e[i]) {
            r = t[i], n = e[i];
            break;
        }
        return r < n ? -1 : n < r ? 1 : 0;
    }, u.isEncoding = function(t) {
        switch(String(t).toLowerCase()){
            case "hex":
            case "utf8":
            case "utf-8":
            case "ascii":
            case "latin1":
            case "binary":
            case "base64":
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
                return !0;
            default:
                return !1;
        }
    }, u.concat = function(t, e) {
        if (!Array.isArray(t)) throw new TypeError('"list" argument must be an Array of Buffers');
        if (0 === t.length) return u.alloc(0);
        let r;
        if (void 0 === e) for(e = 0, r = 0; r < t.length; ++r)e += t[r].length;
        const n = u.allocUnsafe(e);
        let i = 0;
        for(r = 0; r < t.length; ++r){
            let e = t[r];
            if (J(e, Uint8Array)) i + e.length > n.length ? (u.isBuffer(e) || (e = u.from(e)), e.copy(n, i)) : Uint8Array.prototype.set.call(n, e, i);
            else {
                if (!u.isBuffer(e)) throw new TypeError('"list" argument must be an Array of Buffers');
                e.copy(n, i);
            }
            i += e.length;
        }
        return n;
    }, u.byteLength = y, u.prototype._isBuffer = !0, u.prototype.swap16 = function() {
        const t = this.length;
        if (t % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
        for(let e = 0; e < t; e += 2)d(this, e, e + 1);
        return this;
    }, u.prototype.swap32 = function() {
        const t = this.length;
        if (t % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
        for(let e = 0; e < t; e += 4)d(this, e, e + 3), d(this, e + 1, e + 2);
        return this;
    }, u.prototype.swap64 = function() {
        const t = this.length;
        if (t % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
        for(let e = 0; e < t; e += 8)d(this, e, e + 7), d(this, e + 1, e + 6), d(this, e + 2, e + 5), d(this, e + 3, e + 4);
        return this;
    }, u.prototype.toString = function() {
        const t = this.length;
        return 0 === t ? "" : 0 === arguments.length ? R(this, 0, t) : w.apply(this, arguments);
    }, u.prototype.toLocaleString = u.prototype.toString, u.prototype.equals = function(t) {
        if (!u.isBuffer(t)) throw new TypeError("Argument must be a Buffer");
        return this === t || 0 === u.compare(this, t);
    }, u.prototype.inspect = function() {
        let e = "";
        const r = t.INSPECT_MAX_BYTES;
        return e = this.toString("hex", 0, r).replace(/(.{2})/g, "$1 ").trim(), this.length > r && (e += " ... "), "<Buffer " + e + ">";
    }, o && (u.prototype[o] = u.prototype.inspect), u.prototype.compare = function(t, e, r, n, i) {
        if (J(t, Uint8Array) && (t = u.from(t, t.offset, t.byteLength)), !u.isBuffer(t)) throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof t);
        if (void 0 === e && (e = 0), void 0 === r && (r = t ? t.length : 0), void 0 === n && (n = 0), void 0 === i && (i = this.length), e < 0 || r > t.length || n < 0 || i > this.length) throw new RangeError("out of range index");
        if (n >= i && e >= r) return 0;
        if (n >= i) return -1;
        if (e >= r) return 1;
        if (this === t) return 0;
        let o = (i >>>= 0) - (n >>>= 0), f = (r >>>= 0) - (e >>>= 0);
        const s = Math.min(o, f), h = this.slice(n, i), c = t.slice(e, r);
        for(let t = 0; t < s; ++t)if (h[t] !== c[t]) {
            o = h[t], f = c[t];
            break;
        }
        return o < f ? -1 : f < o ? 1 : 0;
    }, u.prototype.includes = function(t, e, r) {
        return -1 !== this.indexOf(t, e, r);
    }, u.prototype.indexOf = function(t, e, r) {
        return b(this, t, e, r, !0);
    }, u.prototype.lastIndexOf = function(t, e, r) {
        return b(this, t, e, r, !1);
    }, u.prototype.write = function(t, e, r, n) {
        if (void 0 === e) n = "utf8", r = this.length, e = 0;
        else if (void 0 === r && "string" == typeof e) n = e, r = this.length, e = 0;
        else {
            if (!isFinite(e)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
            e >>>= 0, isFinite(r) ? (r >>>= 0, void 0 === n && (n = "utf8")) : (n = r, r = void 0);
        }
        const i = this.length - e;
        if ((void 0 === r || r > i) && (r = i), t.length > 0 && (r < 0 || e < 0) || e > this.length) throw new RangeError("Attempt to write outside buffer bounds");
        n || (n = "utf8");
        let o = !1;
        for(;;)switch(n){
            case "hex":
                return B(this, t, e, r);
            case "utf8":
            case "utf-8":
                return E(this, t, e, r);
            case "ascii":
            case "latin1":
            case "binary":
                return I(this, t, e, r);
            case "base64":
                return U(this, t, e, r);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
                return A(this, t, e, r);
            default:
                if (o) throw new TypeError("Unknown encoding: " + n);
                n = ("" + n).toLowerCase(), o = !0;
        }
    }, u.prototype.toJSON = function() {
        return {
            type: "Buffer",
            data: Array.prototype.slice.call(this._arr || this, 0)
        };
    };
    const T = 4096;
    function O(t, e, r) {
        let n = "";
        r = Math.min(t.length, r);
        for(let i = e; i < r; ++i)n += String.fromCharCode(127 & t[i]);
        return n;
    }
    function _(t, e, r) {
        let n = "";
        r = Math.min(t.length, r);
        for(let i = e; i < r; ++i)n += String.fromCharCode(t[i]);
        return n;
    }
    function L(t, e, r) {
        const n = t.length;
        (!e || e < 0) && (e = 0), (!r || r < 0 || r > n) && (r = n);
        let i = "";
        for(let n = e; n < r; ++n)i += H[t[n]];
        return i;
    }
    function S(t, e, r) {
        const n = t.slice(e, r);
        let i = "";
        for(let t = 0; t < n.length - 1; t += 2)i += String.fromCharCode(n[t] + 256 * n[t + 1]);
        return i;
    }
    function x(t, e, r) {
        if (t % 1 != 0 || t < 0) throw new RangeError("offset is not uint");
        if (t + e > r) throw new RangeError("Trying to access beyond buffer length");
    }
    function $(t, e, r, n, i, o) {
        if (!u.isBuffer(t)) throw new TypeError('"buffer" argument must be a Buffer instance');
        if (e > i || e < o) throw new RangeError('"value" argument is out of bounds');
        if (r + n > t.length) throw new RangeError("Index out of range");
    }
    function P(t, e, r, n, i) {
        z(e, n, i, t, r, 7);
        let o = Number(e & BigInt(4294967295));
        t[r++] = o, o >>= 8, t[r++] = o, o >>= 8, t[r++] = o, o >>= 8, t[r++] = o;
        let f = Number(e >> BigInt(32) & BigInt(4294967295));
        return t[r++] = f, f >>= 8, t[r++] = f, f >>= 8, t[r++] = f, f >>= 8, t[r++] = f, r;
    }
    function C(t, e, r, n, i) {
        z(e, n, i, t, r, 7);
        let o = Number(e & BigInt(4294967295));
        t[r + 7] = o, o >>= 8, t[r + 6] = o, o >>= 8, t[r + 5] = o, o >>= 8, t[r + 4] = o;
        let f = Number(e >> BigInt(32) & BigInt(4294967295));
        return t[r + 3] = f, f >>= 8, t[r + 2] = f, f >>= 8, t[r + 1] = f, f >>= 8, t[r] = f, r + 8;
    }
    function j(t, e, r, n, i, o) {
        if (r + n > t.length) throw new RangeError("Index out of range");
        if (r < 0) throw new RangeError("Index out of range");
    }
    function N(t, e, r, n, o) {
        return e = +e, r >>>= 0, o || j(t, 0, r, 4), i.write(t, e, r, n, 23, 4), r + 4;
    }
    function k(t, e, r, n, o) {
        return e = +e, r >>>= 0, o || j(t, 0, r, 8), i.write(t, e, r, n, 52, 8), r + 8;
    }
    u.prototype.slice = function(t, e) {
        const r = this.length;
        (t = ~~t) < 0 ? (t += r) < 0 && (t = 0) : t > r && (t = r), (e = void 0 === e ? r : ~~e) < 0 ? (e += r) < 0 && (e = 0) : e > r && (e = r), e < t && (e = t);
        const n = this.subarray(t, e);
        return Object.setPrototypeOf(n, u.prototype), n;
    }, u.prototype.readUintLE = u.prototype.readUIntLE = function(t, e, r) {
        t >>>= 0, e >>>= 0, r || x(t, e, this.length);
        let n = this[t], i = 1, o = 0;
        for(; ++o < e && (i *= 256);)n += this[t + o] * i;
        return n;
    }, u.prototype.readUintBE = u.prototype.readUIntBE = function(t, e, r) {
        t >>>= 0, e >>>= 0, r || x(t, e, this.length);
        let n = this[t + --e], i = 1;
        for(; e > 0 && (i *= 256);)n += this[t + --e] * i;
        return n;
    }, u.prototype.readUint8 = u.prototype.readUInt8 = function(t, e) {
        return t >>>= 0, e || x(t, 1, this.length), this[t];
    }, u.prototype.readUint16LE = u.prototype.readUInt16LE = function(t, e) {
        return t >>>= 0, e || x(t, 2, this.length), this[t] | this[t + 1] << 8;
    }, u.prototype.readUint16BE = u.prototype.readUInt16BE = function(t, e) {
        return t >>>= 0, e || x(t, 2, this.length), this[t] << 8 | this[t + 1];
    }, u.prototype.readUint32LE = u.prototype.readUInt32LE = function(t, e) {
        return t >>>= 0, e || x(t, 4, this.length), (this[t] | this[t + 1] << 8 | this[t + 2] << 16) + 16777216 * this[t + 3];
    }, u.prototype.readUint32BE = u.prototype.readUInt32BE = function(t, e) {
        return t >>>= 0, e || x(t, 4, this.length), 16777216 * this[t] + (this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3]);
    }, u.prototype.readBigUInt64LE = K(function(t) {
        Y(t >>>= 0, "offset");
        const e = this[t], r = this[t + 7];
        void 0 !== e && void 0 !== r || G(t, this.length - 8);
        const n = e + 256 * this[++t] + 65536 * this[++t] + this[++t] * 2 ** 24, i = this[++t] + 256 * this[++t] + 65536 * this[++t] + r * 2 ** 24;
        return BigInt(n) + (BigInt(i) << BigInt(32));
    }), u.prototype.readBigUInt64BE = K(function(t) {
        Y(t >>>= 0, "offset");
        const e = this[t], r = this[t + 7];
        void 0 !== e && void 0 !== r || G(t, this.length - 8);
        const n = e * 2 ** 24 + 65536 * this[++t] + 256 * this[++t] + this[++t], i = this[++t] * 2 ** 24 + 65536 * this[++t] + 256 * this[++t] + r;
        return (BigInt(n) << BigInt(32)) + BigInt(i);
    }), u.prototype.readIntLE = function(t, e, r) {
        t >>>= 0, e >>>= 0, r || x(t, e, this.length);
        let n = this[t], i = 1, o = 0;
        for(; ++o < e && (i *= 256);)n += this[t + o] * i;
        return i *= 128, n >= i && (n -= Math.pow(2, 8 * e)), n;
    }, u.prototype.readIntBE = function(t, e, r) {
        t >>>= 0, e >>>= 0, r || x(t, e, this.length);
        let n = e, i = 1, o = this[t + --n];
        for(; n > 0 && (i *= 256);)o += this[t + --n] * i;
        return i *= 128, o >= i && (o -= Math.pow(2, 8 * e)), o;
    }, u.prototype.readInt8 = function(t, e) {
        return t >>>= 0, e || x(t, 1, this.length), 128 & this[t] ? -1 * (255 - this[t] + 1) : this[t];
    }, u.prototype.readInt16LE = function(t, e) {
        t >>>= 0, e || x(t, 2, this.length);
        const r = this[t] | this[t + 1] << 8;
        return 32768 & r ? 4294901760 | r : r;
    }, u.prototype.readInt16BE = function(t, e) {
        t >>>= 0, e || x(t, 2, this.length);
        const r = this[t + 1] | this[t] << 8;
        return 32768 & r ? 4294901760 | r : r;
    }, u.prototype.readInt32LE = function(t, e) {
        return t >>>= 0, e || x(t, 4, this.length), this[t] | this[t + 1] << 8 | this[t + 2] << 16 | this[t + 3] << 24;
    }, u.prototype.readInt32BE = function(t, e) {
        return t >>>= 0, e || x(t, 4, this.length), this[t] << 24 | this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3];
    }, u.prototype.readBigInt64LE = K(function(t) {
        Y(t >>>= 0, "offset");
        const e = this[t], r = this[t + 7];
        void 0 !== e && void 0 !== r || G(t, this.length - 8);
        const n = this[t + 4] + 256 * this[t + 5] + 65536 * this[t + 6] + (r << 24);
        return (BigInt(n) << BigInt(32)) + BigInt(e + 256 * this[++t] + 65536 * this[++t] + this[++t] * 2 ** 24);
    }), u.prototype.readBigInt64BE = K(function(t) {
        Y(t >>>= 0, "offset");
        const e = this[t], r = this[t + 7];
        void 0 !== e && void 0 !== r || G(t, this.length - 8);
        const n = (e << 24) + 65536 * this[++t] + 256 * this[++t] + this[++t];
        return (BigInt(n) << BigInt(32)) + BigInt(this[++t] * 2 ** 24 + 65536 * this[++t] + 256 * this[++t] + r);
    }), u.prototype.readFloatLE = function(t, e) {
        return t >>>= 0, e || x(t, 4, this.length), i.read(this, t, !0, 23, 4);
    }, u.prototype.readFloatBE = function(t, e) {
        return t >>>= 0, e || x(t, 4, this.length), i.read(this, t, !1, 23, 4);
    }, u.prototype.readDoubleLE = function(t, e) {
        return t >>>= 0, e || x(t, 8, this.length), i.read(this, t, !0, 52, 8);
    }, u.prototype.readDoubleBE = function(t, e) {
        return t >>>= 0, e || x(t, 8, this.length), i.read(this, t, !1, 52, 8);
    }, u.prototype.writeUintLE = u.prototype.writeUIntLE = function(t, e, r, n) {
        if (t = +t, e >>>= 0, r >>>= 0, !n) {
            $(this, t, e, r, Math.pow(2, 8 * r) - 1, 0);
        }
        let i = 1, o = 0;
        for(this[e] = 255 & t; ++o < r && (i *= 256);)this[e + o] = t / i & 255;
        return e + r;
    }, u.prototype.writeUintBE = u.prototype.writeUIntBE = function(t, e, r, n) {
        if (t = +t, e >>>= 0, r >>>= 0, !n) {
            $(this, t, e, r, Math.pow(2, 8 * r) - 1, 0);
        }
        let i = r - 1, o = 1;
        for(this[e + i] = 255 & t; --i >= 0 && (o *= 256);)this[e + i] = t / o & 255;
        return e + r;
    }, u.prototype.writeUint8 = u.prototype.writeUInt8 = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 1, 255, 0), this[e] = 255 & t, e + 1;
    }, u.prototype.writeUint16LE = u.prototype.writeUInt16LE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 2, 65535, 0), this[e] = 255 & t, this[e + 1] = t >>> 8, e + 2;
    }, u.prototype.writeUint16BE = u.prototype.writeUInt16BE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 2, 65535, 0), this[e] = t >>> 8, this[e + 1] = 255 & t, e + 2;
    }, u.prototype.writeUint32LE = u.prototype.writeUInt32LE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 4, 4294967295, 0), this[e + 3] = t >>> 24, this[e + 2] = t >>> 16, this[e + 1] = t >>> 8, this[e] = 255 & t, e + 4;
    }, u.prototype.writeUint32BE = u.prototype.writeUInt32BE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 4, 4294967295, 0), this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t, e + 4;
    }, u.prototype.writeBigUInt64LE = K(function(t, e = 0) {
        return P(this, t, e, BigInt(0), BigInt("0xffffffffffffffff"));
    }), u.prototype.writeBigUInt64BE = K(function(t, e = 0) {
        return C(this, t, e, BigInt(0), BigInt("0xffffffffffffffff"));
    }), u.prototype.writeIntLE = function(t, e, r, n) {
        if (t = +t, e >>>= 0, !n) {
            const n = Math.pow(2, 8 * r - 1);
            $(this, t, e, r, n - 1, -n);
        }
        let i = 0, o = 1, f = 0;
        for(this[e] = 255 & t; ++i < r && (o *= 256);)t < 0 && 0 === f && 0 !== this[e + i - 1] && (f = 1), this[e + i] = (t / o >> 0) - f & 255;
        return e + r;
    }, u.prototype.writeIntBE = function(t, e, r, n) {
        if (t = +t, e >>>= 0, !n) {
            const n = Math.pow(2, 8 * r - 1);
            $(this, t, e, r, n - 1, -n);
        }
        let i = r - 1, o = 1, f = 0;
        for(this[e + i] = 255 & t; --i >= 0 && (o *= 256);)t < 0 && 0 === f && 0 !== this[e + i + 1] && (f = 1), this[e + i] = (t / o >> 0) - f & 255;
        return e + r;
    }, u.prototype.writeInt8 = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 1, 127, -128), t < 0 && (t = 255 + t + 1), this[e] = 255 & t, e + 1;
    }, u.prototype.writeInt16LE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 2, 32767, -32768), this[e] = 255 & t, this[e + 1] = t >>> 8, e + 2;
    }, u.prototype.writeInt16BE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 2, 32767, -32768), this[e] = t >>> 8, this[e + 1] = 255 & t, e + 2;
    }, u.prototype.writeInt32LE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 4, 2147483647, -2147483648), this[e] = 255 & t, this[e + 1] = t >>> 8, this[e + 2] = t >>> 16, this[e + 3] = t >>> 24, e + 4;
    }, u.prototype.writeInt32BE = function(t, e, r) {
        return t = +t, e >>>= 0, r || $(this, t, e, 4, 2147483647, -2147483648), t < 0 && (t = 4294967295 + t + 1), this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t, e + 4;
    }, u.prototype.writeBigInt64LE = K(function(t, e = 0) {
        return P(this, t, e, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
    }), u.prototype.writeBigInt64BE = K(function(t, e = 0) {
        return C(this, t, e, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
    }), u.prototype.writeFloatLE = function(t, e, r) {
        return N(this, t, e, !0, r);
    }, u.prototype.writeFloatBE = function(t, e, r) {
        return N(this, t, e, !1, r);
    }, u.prototype.writeDoubleLE = function(t, e, r) {
        return k(this, t, e, !0, r);
    }, u.prototype.writeDoubleBE = function(t, e, r) {
        return k(this, t, e, !1, r);
    }, u.prototype.copy = function(t, e, r, n) {
        if (!u.isBuffer(t)) throw new TypeError("argument should be a Buffer");
        if (r || (r = 0), n || 0 === n || (n = this.length), e >= t.length && (e = t.length), e || (e = 0), n > 0 && n < r && (n = r), n === r) return 0;
        if (0 === t.length || 0 === this.length) return 0;
        if (e < 0) throw new RangeError("targetStart out of bounds");
        if (r < 0 || r >= this.length) throw new RangeError("Index out of range");
        if (n < 0) throw new RangeError("sourceEnd out of bounds");
        n > this.length && (n = this.length), t.length - e < n - r && (n = t.length - e + r);
        const i = n - r;
        return this === t && "function" == typeof Uint8Array.prototype.copyWithin ? this.copyWithin(e, r, n) : Uint8Array.prototype.set.call(t, this.subarray(r, n), e), i;
    }, u.prototype.fill = function(t, e, r, n) {
        if ("string" == typeof t) {
            if ("string" == typeof e ? (n = e, e = 0, r = this.length) : "string" == typeof r && (n = r, r = this.length), void 0 !== n && "string" != typeof n) throw new TypeError("encoding must be a string");
            if ("string" == typeof n && !u.isEncoding(n)) throw new TypeError("Unknown encoding: " + n);
            if (1 === t.length) {
                const e = t.charCodeAt(0);
                ("utf8" === n && e < 128 || "latin1" === n) && (t = e);
            }
        } else "number" == typeof t ? t &= 255 : "boolean" == typeof t && (t = Number(t));
        if (e < 0 || this.length < e || this.length < r) throw new RangeError("Out of range index");
        if (r <= e) return this;
        let i;
        if (e >>>= 0, r = void 0 === r ? this.length : r >>> 0, t || (t = 0), "number" == typeof t) for(i = e; i < r; ++i)this[i] = t;
        else {
            const o = u.isBuffer(t) ? t : u.from(t, n), f = o.length;
            if (0 === f) throw new TypeError('The value "' + t + '" is invalid for argument "value"');
            for(i = 0; i < r - e; ++i)this[i + e] = o[i % f];
        }
        return this;
    };
    const F = {};
    function M(t, e, r) {
        F[t] = class extends r {
            constructor(){
                super(), Object.defineProperty(this, "message", {
                    value: e.apply(this, arguments),
                    writable: !0,
                    configurable: !0
                }), this.name = `${this.name} [${t}]`, delete this.name;
            }
            get code() {
                return t;
            }
            set code(t) {
                Object.defineProperty(this, "code", {
                    configurable: !0,
                    enumerable: !0,
                    value: t,
                    writable: !0
                });
            }
            toString() {
                return `${this.name} [${t}]: ${this.message}`;
            }
        };
    }
    function D(t) {
        let e = "", r = t.length;
        const n = "-" === t[0] ? 1 : 0;
        for(; r >= n + 4; r -= 3)e = `_${t.slice(r - 3, r)}${e}`;
        return `${t.slice(0, r)}${e}`;
    }
    function z(t, e, r, n, i, o) {
        if (t > r || t < e) {
            const n = "bigint" == typeof e ? "n" : "";
            let i;
            throw i = o > 3 ? 0 === e || e === BigInt(0) ? `>= 0${n} and < 2${n} ** ${8 * (o + 1)}${n}` : `>= -(2${n} ** ${8 * (o + 1) - 1}${n}) and < 2 ** ${8 * (o + 1) - 1}${n}` : `>= ${e}${n} and <= ${r}${n}`, new F.ERR_OUT_OF_RANGE("value", i, t);
        }
        !function(t, e, r) {
            Y(e, "offset"), void 0 !== t[e] && void 0 !== t[e + r] || G(e, t.length - (r + 1));
        }(n, i, o);
    }
    function Y(t, e) {
        if ("number" != typeof t) throw new F.ERR_INVALID_ARG_TYPE(e, "number", t);
    }
    function G(t, e, r) {
        if (Math.floor(t) !== t) throw Y(t, r), new F.ERR_OUT_OF_RANGE(r || "offset", "an integer", t);
        if (e < 0) throw new F.ERR_BUFFER_OUT_OF_BOUNDS;
        throw new F.ERR_OUT_OF_RANGE(r || "offset", `>= ${r ? 1 : 0} and <= ${e}`, t);
    }
    M("ERR_BUFFER_OUT_OF_BOUNDS", function(t) {
        return t ? `${t} is outside of buffer bounds` : "Attempt to access memory outside buffer bounds";
    }, RangeError), M("ERR_INVALID_ARG_TYPE", function(t, e) {
        return `The "${t}" argument must be of type number. Received type ${typeof e}`;
    }, TypeError), M("ERR_OUT_OF_RANGE", function(t, e, r) {
        let n = `The value of "${t}" is out of range.`, i = r;
        return Number.isInteger(r) && Math.abs(r) > 2 ** 32 ? i = D(String(r)) : "bigint" == typeof r && (i = String(r), (r > BigInt(2) ** BigInt(32) || r < -(BigInt(2) ** BigInt(32))) && (i = D(i)), i += "n"), n += ` It must be ${e}. Received ${i}`, n;
    }, RangeError);
    const V = /[^+/0-9A-Za-z-_]/g;
    function q(t, e) {
        let r;
        e = e || 1 / 0;
        const n = t.length;
        let i = null;
        const o = [];
        for(let f = 0; f < n; ++f){
            if (r = t.charCodeAt(f), r > 55295 && r < 57344) {
                if (!i) {
                    if (r > 56319) {
                        (e -= 3) > -1 && o.push(239, 191, 189);
                        continue;
                    }
                    if (f + 1 === n) {
                        (e -= 3) > -1 && o.push(239, 191, 189);
                        continue;
                    }
                    i = r;
                    continue;
                }
                if (r < 56320) {
                    (e -= 3) > -1 && o.push(239, 191, 189), i = r;
                    continue;
                }
                r = 65536 + (i - 55296 << 10 | r - 56320);
            } else i && (e -= 3) > -1 && o.push(239, 191, 189);
            if (i = null, r < 128) {
                if ((e -= 1) < 0) break;
                o.push(r);
            } else if (r < 2048) {
                if ((e -= 2) < 0) break;
                o.push(r >> 6 | 192, 63 & r | 128);
            } else if (r < 65536) {
                if ((e -= 3) < 0) break;
                o.push(r >> 12 | 224, r >> 6 & 63 | 128, 63 & r | 128);
            } else {
                if (!(r < 1114112)) throw new Error("Invalid code point");
                if ((e -= 4) < 0) break;
                o.push(r >> 18 | 240, r >> 12 & 63 | 128, r >> 6 & 63 | 128, 63 & r | 128);
            }
        }
        return o;
    }
    function W(t) {
        return n.toByteArray(function(t) {
            if ((t = (t = t.split("=")[0]).trim().replace(V, "")).length < 2) return "";
            for(; t.length % 4 != 0;)t += "=";
            return t;
        }(t));
    }
    function X(t, e, r, n) {
        let i;
        for(i = 0; i < n && !(i + r >= e.length || i >= t.length); ++i)e[i + r] = t[i];
        return i;
    }
    function J(t, e) {
        return t instanceof e || null != t && null != t.constructor && null != t.constructor.name && t.constructor.name === e.name;
    }
    function Z(t) {
        return t != t;
    }
    const H = function() {
        const t = "0123456789abcdef", e = new Array(256);
        for(let r = 0; r < 16; ++r){
            const n = 16 * r;
            for(let i = 0; i < 16; ++i)e[n + i] = t[r] + t[i];
        }
        return e;
    }();
    function K(t) {
        return "undefined" == typeof BigInt ? Q : t;
    }
    function Q() {
        throw new Error("BigInt not supported");
    }
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"]); //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/@bonfida/sns-records/dist/index.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
__turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/buffer/index.cjs [app-route] (ecmascript)");
var e, t = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)"), r = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/_virtual/index.cjs [app-route] (ecmascript)"), i = [
    "u8",
    "u16",
    "u32",
    "u64",
    "u128",
    "i8",
    "i16",
    "i32",
    "i64",
    "i128",
    "f32",
    "f64"
], n = function() {
    function e() {
        this.offset = 0, this.buffer_size = 256, this.buffer = new ArrayBuffer(this.buffer_size), this.view = new DataView(this.buffer);
    }
    return e.prototype.resize_if_necessary = function(e) {
        if (this.buffer_size - this.offset < e) {
            this.buffer_size = Math.max(2 * this.buffer_size, this.buffer_size + e);
            var t = new ArrayBuffer(this.buffer_size);
            new Uint8Array(t).set(new Uint8Array(this.buffer)), this.buffer = t, this.view = new DataView(t);
        }
    }, e.prototype.get_used_buffer = function() {
        return new Uint8Array(this.buffer).slice(0, this.offset);
    }, e.prototype.store_value = function(e, t) {
        var r = t.substring(1), i = parseInt(r) / 8;
        this.resize_if_necessary(i);
        var n = "f" === t[0] ? "setFloat".concat(r) : "i" === t[0] ? "setInt".concat(r) : "setUint".concat(r);
        this.view[n](this.offset, e, !0), this.offset += i;
    }, e.prototype.store_bytes = function(e) {
        this.resize_if_necessary(e.length), new Uint8Array(this.buffer).set(new Uint8Array(e), this.offset), this.offset += e.length;
    }, e;
}(), s = function() {
    function e(e) {
        this.offset = 0, this.buffer_size = e.length, this.buffer = new ArrayBuffer(e.length), new Uint8Array(this.buffer).set(e), this.view = new DataView(this.buffer);
    }
    return e.prototype.assert_enough_buffer = function(e) {
        if (this.offset + e > this.buffer.byteLength) throw new Error("Error in schema, the buffer is smaller than expected");
    }, e.prototype.consume_value = function(e) {
        var t = e.substring(1), r = parseInt(t) / 8;
        this.assert_enough_buffer(r);
        var i = "f" === e[0] ? "getFloat".concat(t) : "i" === e[0] ? "getInt".concat(t) : "getUint".concat(t), n = this.view[i](this.offset, !0);
        return this.offset += r, n;
    }, e.prototype.consume_bytes = function(e) {
        this.assert_enough_buffer(e);
        var t = this.buffer.slice(this.offset, this.offset + e);
        return this.offset += e, t;
    }, e;
}(), o = (e = function(t, r) {
    return e = Object.setPrototypeOf || ({
        __proto__: []
    }) instanceof Array && function(e, t) {
        e.__proto__ = t;
    } || function(e, t) {
        for(var r in t)Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
    }, e(t, r);
}, function(t, r) {
    if ("function" != typeof r && null !== r) throw new TypeError("Class extends value " + String(r) + " is not a constructor or null");
    function i() {
        this.constructor = t;
    }
    e(t, r), t.prototype = null === r ? Object.create(r) : (i.prototype = r.prototype, new i);
});
function a(e, t, r) {
    if (typeof e !== t) throw new Error("Expected ".concat(t, " not ").concat(typeof e, "(").concat(e, ") at ").concat(r.join(".")));
}
function u(e, t, r) {
    if (e !== t) throw new Error("Array length ".concat(e, " does not match schema length ").concat(t, " at ").concat(r.join(".")));
}
var c = i.concat([
    "bool",
    "string"
]), h = [
    "option",
    "enum",
    "array",
    "set",
    "map",
    "struct"
], f = function(e) {
    function t(t, r) {
        var i = "Invalid schema: ".concat(JSON.stringify(t), " expected ").concat(r);
        return e.call(this, i) || this;
    }
    return o(t, e), t;
}(Error);
function p(e) {
    if ("string" != typeof e || !c.includes(e)) {
        if (e && "object" == typeof e) {
            var t = Object.keys(e);
            if (1 === t.length && h.includes(t[0])) {
                var r = t[0];
                if ("option" === r) return p(e[r]);
                if ("enum" === r) return function(e) {
                    if (!Array.isArray(e)) throw new f(e, "Array");
                    for(var t = 0, r = e; t < r.length; t++){
                        var i = r[t];
                        if ("object" != typeof i || !("struct" in i)) throw new Error('Missing "struct" key in enum schema');
                        if ("object" != typeof i.struct || 1 !== Object.keys(i.struct).length) throw new Error('The "struct" in each enum must have a single key');
                        p({
                            struct: i.struct
                        });
                    }
                }(e[r]);
                if ("array" === r) return function(e) {
                    if ("object" != typeof e) throw new f(e, "{ type, len? }");
                    if (e.len && "number" != typeof e.len) throw new Error("Invalid schema: ".concat(e));
                    if ("type" in e) return p(e.type);
                    throw new f(e, "{ type, len? }");
                }(e[r]);
                if ("set" === r) return p(e[r]);
                if ("map" === r) return function(e) {
                    if ("object" != typeof e || !("key" in e) || !("value" in e)) throw new f(e, "{ key, value }");
                    p(e.key), p(e.value);
                }(e[r]);
                if ("struct" === r) return function(e) {
                    if ("object" != typeof e) throw new f(e, "object");
                    for(var t in e)p(e[t]);
                }(e[r]);
            }
        }
        throw new f(e, h.join(", ") + " or " + c.join(", "));
    }
}
var d = function() {
    function e(e) {
        this.encoded = new n, this.fieldPath = [
            "value"
        ], this.checkTypes = e;
    }
    return e.prototype.encode = function(e, t) {
        return this.encode_value(e, t), this.encoded.get_used_buffer();
    }, e.prototype.encode_value = function(e, t) {
        if ("string" == typeof t) {
            if (i.includes(t)) return this.encode_integer(e, t);
            if ("string" === t) return this.encode_string(e);
            if ("bool" === t) return this.encode_boolean(e);
        }
        if ("object" == typeof t) {
            if ("option" in t) return this.encode_option(e, t);
            if ("enum" in t) return this.encode_enum(e, t);
            if ("array" in t) return this.encode_array(e, t);
            if ("set" in t) return this.encode_set(e, t);
            if ("map" in t) return this.encode_map(e, t);
            if ("struct" in t) return this.encode_struct(e, t);
        }
    }, e.prototype.encode_integer = function(e, t) {
        var r = parseInt(t.substring(1));
        r <= 32 || "f64" == t ? (this.checkTypes && a(e, "number", this.fieldPath), this.encoded.store_value(e, t)) : (this.checkTypes && function(e, t) {
            if (!([
                "number",
                "string",
                "bigint",
                "boolean"
            ].includes(typeof e) || "object" == typeof e && null !== e && "toString" in e)) throw new Error("Expected bigint, number, boolean or string not ".concat(typeof e, "(").concat(e, ") at ").concat(t.join(".")));
        }(e, this.fieldPath), this.encode_bigint(BigInt(e), r));
    }, e.prototype.encode_bigint = function(e, t) {
        for(var r = t / 8, i = new Uint8Array(r), n = 0; n < r; n++)i[n] = Number(e & BigInt(255)), e >>= BigInt(8);
        this.encoded.store_bytes(new Uint8Array(i));
    }, e.prototype.encode_string = function(e) {
        this.checkTypes && a(e, "string", this.fieldPath);
        var t = e;
        this.encoded.store_value(t.length, "u32");
        for(var r = 0; r < t.length; r++)this.encoded.store_value(t.charCodeAt(r), "u8");
    }, e.prototype.encode_boolean = function(e) {
        this.checkTypes && a(e, "boolean", this.fieldPath), this.encoded.store_value(e ? 1 : 0, "u8");
    }, e.prototype.encode_option = function(e, t) {
        null == e ? this.encoded.store_value(0, "u8") : (this.encoded.store_value(1, "u8"), this.encode_value(e, t.option));
    }, e.prototype.encode_enum = function(e, t) {
        this.checkTypes && function(e, t) {
            if ("object" != typeof e || null === e) throw new Error("Expected object not ".concat(typeof e, "(").concat(e, ") at ").concat(t.join(".")));
        }(e, this.fieldPath);
        for(var r = Object.keys(e)[0], i = 0; i < t.enum.length; i++){
            var n = t.enum[i];
            if (r === Object.keys(n.struct)[0]) return this.encoded.store_value(i, "u8"), this.encode_struct(e, n);
        }
        throw new Error("Enum key (".concat(r, ") not found in enum schema: ").concat(JSON.stringify(t), " at ").concat(this.fieldPath.join(".")));
    }, e.prototype.encode_array = function(e, t) {
        if (function(e) {
            return Array.isArray(e) || !!e && "object" == typeof e && "length" in e && "number" == typeof e.length && (0 === e.length || e.length > 0 && e.length - 1 in e);
        }(e)) return this.encode_arraylike(e, t);
        if (e instanceof ArrayBuffer) return this.encode_buffer(e, t);
        throw new Error("Expected Array-like not ".concat(typeof e, "(").concat(e, ") at ").concat(this.fieldPath.join(".")));
    }, e.prototype.encode_arraylike = function(e, t) {
        t.array.len ? u(e.length, t.array.len, this.fieldPath) : this.encoded.store_value(e.length, "u32");
        for(var r = 0; r < e.length; r++)this.encode_value(e[r], t.array.type);
    }, e.prototype.encode_buffer = function(e, t) {
        t.array.len ? u(e.byteLength, t.array.len, this.fieldPath) : this.encoded.store_value(e.byteLength, "u32"), this.encoded.store_bytes(new Uint8Array(e));
    }, e.prototype.encode_set = function(e, t) {
        this.checkTypes && a(e, "object", this.fieldPath);
        var r = e instanceof Set ? Array.from(e.values()) : Object.values(e);
        this.encoded.store_value(r.length, "u32");
        for(var i = 0, n = r; i < n.length; i++){
            var s = n[i];
            this.encode_value(s, t.set);
        }
    }, e.prototype.encode_map = function(e, t) {
        this.checkTypes && a(e, "object", this.fieldPath);
        var r = e instanceof Map, i = r ? Array.from(e.keys()) : Object.keys(e);
        this.encoded.store_value(i.length, "u32");
        for(var n = 0, s = i; n < s.length; n++){
            var o = s[n];
            this.encode_value(o, t.map.key), this.encode_value(r ? e.get(o) : e[o], t.map.value);
        }
    }, e.prototype.encode_struct = function(e, t) {
        this.checkTypes && a(e, "object", this.fieldPath);
        for(var r = 0, i = Object.keys(t.struct); r < i.length; r++){
            var n = i[r];
            this.fieldPath.push(n), this.encode_value(e[n], t.struct[n]), this.fieldPath.pop();
        }
    }, e;
}(), l = function() {
    function e(e) {
        this.buffer = new s(e);
    }
    return e.prototype.decode = function(e) {
        return this.decode_value(e);
    }, e.prototype.decode_value = function(e) {
        if ("string" == typeof e) {
            if (i.includes(e)) return this.decode_integer(e);
            if ("string" === e) return this.decode_string();
            if ("bool" === e) return this.decode_boolean();
        }
        if ("object" == typeof e) {
            if ("option" in e) return this.decode_option(e);
            if ("enum" in e) return this.decode_enum(e);
            if ("array" in e) return this.decode_array(e);
            if ("set" in e) return this.decode_set(e);
            if ("map" in e) return this.decode_map(e);
            if ("struct" in e) return this.decode_struct(e);
        }
        throw new Error("Unsupported type: ".concat(e));
    }, e.prototype.decode_integer = function(e) {
        var t = parseInt(e.substring(1));
        return t <= 32 || "f64" == e ? this.buffer.consume_value(e) : this.decode_bigint(t, e.startsWith("i"));
    }, e.prototype.decode_bigint = function(e, t) {
        void 0 === t && (t = !1);
        var r = e / 8, i = new Uint8Array(this.buffer.consume_bytes(r)), n = i.reduceRight(function(e, t) {
            return e + t.toString(16).padStart(2, "0");
        }, "");
        return t && i[r - 1] ? BigInt.asIntN(e, BigInt("0x".concat(n))) : BigInt("0x".concat(n));
    }, e.prototype.decode_string = function() {
        var e = this.decode_integer("u32"), t = new Uint8Array(this.buffer.consume_bytes(e));
        return String.fromCharCode.apply(null, t);
    }, e.prototype.decode_boolean = function() {
        return this.buffer.consume_value("u8") > 0;
    }, e.prototype.decode_option = function(e) {
        var t = this.buffer.consume_value("u8");
        if (1 === t) return this.decode_value(e.option);
        if (0 !== t) throw new Error("Invalid option ".concat(t));
        return null;
    }, e.prototype.decode_enum = function(e) {
        var t, r = this.buffer.consume_value("u8");
        if (r > e.enum.length) throw new Error("Enum option ".concat(r, " is not available"));
        var i = e.enum[r].struct, n = Object.keys(i)[0];
        return (t = {})[n] = this.decode_value(i[n]), t;
    }, e.prototype.decode_array = function(e) {
        for(var t = [], r = e.array.len ? e.array.len : this.decode_integer("u32"), i = 0; i < r; ++i)t.push(this.decode_value(e.array.type));
        return t;
    }, e.prototype.decode_set = function(e) {
        for(var t = this.decode_integer("u32"), r = new Set, i = 0; i < t; ++i)r.add(this.decode_value(e.set));
        return r;
    }, e.prototype.decode_map = function(e) {
        for(var t = this.decode_integer("u32"), r = new Map, i = 0; i < t; ++i){
            var n = this.decode_value(e.map.key), s = this.decode_value(e.map.value);
            r.set(n, s);
        }
        return r;
    }, e.prototype.decode_struct = function(e) {
        var t = {};
        for(var r in e.struct)t[r] = this.decode_value(e.struct[r]);
        return t;
    }, e;
}();
function y(e, t, r) {
    return void 0 === r && (r = !0), r && p(e), new d(r).encode(t, e);
}
class g {
    constructor(e){
        this.tag = 1, this.record = e.record, this.content = e.content;
    }
    serialize() {
        return y(g.schema, this);
    }
    getInstruction(e, i, n, s, o, a, u, c) {
        const h = r.__exports.Buffer.from(this.serialize());
        let f = [];
        return f.push({
            pubkey: i,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: n,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: s,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: o,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: a,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: u,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: c,
            isSigner: !1,
            isWritable: !1
        }), new t.TransactionInstruction({
            keys: f,
            programId: e,
            data: h
        });
    }
}
g.schema = {
    struct: {
        tag: "u8",
        record: "string",
        content: {
            array: {
                type: "u8"
            }
        }
    }
};
class b {
    constructor(e){
        this.tag = 4, this.validation = e.validation, this.signature = e.signature, this.expectedPubkey = e.expectedPubkey;
    }
    serialize() {
        return y(b.schema, this);
    }
    getInstruction(e, i, n, s, o, a, u, c) {
        const h = r.__exports.Buffer.from(this.serialize());
        let f = [];
        return f.push({
            pubkey: i,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: n,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: s,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: o,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: a,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: u,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: c,
            isSigner: !1,
            isWritable: !1
        }), new t.TransactionInstruction({
            keys: f,
            programId: e,
            data: h
        });
    }
}
b.schema = {
    struct: {
        tag: "u8",
        validation: "u8",
        signature: {
            array: {
                type: "u8"
            }
        },
        expectedPubkey: {
            array: {
                type: "u8"
            }
        }
    }
};
class _ {
    constructor(e){
        this.tag = 3, this.staleness = e.staleness;
    }
    serialize() {
        return y(_.schema, this);
    }
    getInstruction(e, i, n, s, o, a, u, c, h) {
        const f = r.__exports.Buffer.from(this.serialize());
        let p = [];
        return p.push({
            pubkey: i,
            isSigner: !1,
            isWritable: !1
        }), p.push({
            pubkey: n,
            isSigner: !1,
            isWritable: !1
        }), p.push({
            pubkey: s,
            isSigner: !0,
            isWritable: !0
        }), p.push({
            pubkey: o,
            isSigner: !1,
            isWritable: !0
        }), p.push({
            pubkey: a,
            isSigner: !1,
            isWritable: !0
        }), p.push({
            pubkey: u,
            isSigner: !1,
            isWritable: !0
        }), p.push({
            pubkey: c,
            isSigner: !1,
            isWritable: !1
        }), p.push({
            pubkey: h,
            isSigner: !0,
            isWritable: !0
        }), new t.TransactionInstruction({
            keys: p,
            programId: e,
            data: f
        });
    }
}
_.schema = {
    struct: {
        tag: "u8",
        staleness: "bool"
    }
};
class v {
    constructor(e){
        this.tag = 2, this.record = e.record, this.content = e.content;
    }
    serialize() {
        return y(v.schema, this);
    }
    getInstruction(e, i, n, s, o, a, u, c) {
        const h = r.__exports.Buffer.from(this.serialize());
        let f = [];
        return f.push({
            pubkey: i,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: n,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: s,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: o,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: a,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: u,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: c,
            isSigner: !1,
            isWritable: !1
        }), new t.TransactionInstruction({
            keys: f,
            programId: e,
            data: h
        });
    }
}
v.schema = {
    struct: {
        tag: "u8",
        record: "string",
        content: {
            array: {
                type: "u8"
            }
        }
    }
};
class m {
    constructor(){
        this.tag = 5;
    }
    serialize() {
        return y(m.schema, this);
    }
    getInstruction(e, i, n, s, o, a, u, c) {
        const h = r.__exports.Buffer.from(this.serialize());
        let f = [];
        return f.push({
            pubkey: i,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: n,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: s,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: o,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: a,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: u,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: c,
            isSigner: !1,
            isWritable: !1
        }), new t.TransactionInstruction({
            keys: f,
            programId: e,
            data: h
        });
    }
}
m.schema = {
    struct: {
        tag: "u8"
    }
};
class w {
    constructor(e){
        this.tag = 6, this.roaId = e.roaId;
    }
    serialize() {
        return y(w.schema, this);
    }
    getInstruction(e, i, n, s, o, a, u, c) {
        const h = r.__exports.Buffer.from(this.serialize());
        let f = [];
        return f.push({
            pubkey: i,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: n,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: s,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: o,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: a,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: u,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: c,
            isSigner: !1,
            isWritable: !1
        }), new t.TransactionInstruction({
            keys: f,
            programId: e,
            data: h
        });
    }
}
w.schema = {
    struct: {
        tag: "u8",
        roaId: {
            array: {
                type: "u8"
            }
        }
    }
};
const k = new t.PublicKey("HP3D4D1ZCmohQGFVms2SS4LCANgJyksBf5s1F77FuFjZ"), [S] = t.PublicKey.findProgramAddressSync([
    k.toBuffer()
], k);
var I;
exports.Validation = void 0, (I = exports.Validation || (exports.Validation = {}))[I.None = 0] = "None", I[I.Solana = 1] = "Solana", I[I.Ethereum = 2] = "Ethereum", I[I.UnverifiedSolana = 3] = "UnverifiedSolana";
const x = (e)=>{
    switch(e){
        case exports.Validation.None:
            return 0;
        case exports.Validation.Ethereum:
            return 20;
        case exports.Validation.Solana:
        case exports.Validation.UnverifiedSolana:
            return 32;
        default:
            throw new Error("Invalid validation enum");
    }
};
class A {
    constructor(e){
        this.stalenessValidation = e.stalenessValidation, this.rightOfAssociationValidation = e.rightOfAssociationValidation, this.contentLength = e.contentLength;
    }
    static deserialize(e) {
        return new A((t = this.schema, r = e, void 0 === (i = !0) && (i = !0), i && p(t), new l(r).decode(t)));
        "TURBOPACK unreachable";
        var t, r, i;
    }
    static async retrieve(e, t) {
        const r = await e.getAccountInfo(t);
        if (!r || !r.data) throw new Error("Record header account not found");
        return this.deserialize(r.data.slice(96, 96 + this.LEN));
    }
}
A.LEN = 8, A.schema = {
    struct: {
        stalenessValidation: "u16",
        rightOfAssociationValidation: "u16",
        contentLength: "u32"
    }
};
class W {
    constructor(e, t){
        this.data = t, this.header = e;
    }
    static deserialize(e) {
        const t = A.deserialize(e.slice(96, 96 + A.LEN)), r = e.slice(96 + A.LEN);
        return new W(t, r);
    }
    static async retrieve(e, t) {
        const r = await e.getAccountInfo(t);
        if (!r || !r.data) throw new Error("Record header account not found");
        return this.deserialize(r.data);
    }
    static async retrieveBatch(e, t) {
        return (await e.getMultipleAccountsInfo(t)).map((e)=>{
            if (null == e ? void 0 : e.data) return this.deserialize(e.data);
        });
    }
    getContent() {
        let e = x(this.header.stalenessValidation) + x(this.header.rightOfAssociationValidation);
        return this.data.slice(e);
    }
    getStalenessId() {
        let e = x(this.header.stalenessValidation);
        return this.data.slice(0, e);
    }
    getRoAId() {
        let e = x(this.header.stalenessValidation), t = e + x(this.header.rightOfAssociationValidation);
        return this.data.slice(e, t);
    }
}
exports.CENTRAL_STATE_SNS_RECORDS = S, exports.Record = W, exports.RecordHeader = A, exports.SNS_RECORDS_ID = k, exports.allocateAndPostRecord = (e, r, i, n, s, o, a, u)=>new g({
        record: o,
        content: Array.from(a)
    }).getInstruction(u, t.SystemProgram.programId, s, e, r, i, n, S), exports.allocateAndPostRecordInstruction = g, exports.deleteRecord = (e, r, i, n, s, o)=>(new m).getInstruction(o, t.SystemProgram.programId, s, e, n, r, i, S), exports.deleteRecordInstruction = m, exports.editRecord = (e, r, i, n, s, o, a, u)=>new v({
        record: o,
        content: Array.from(a)
    }).getInstruction(u, t.SystemProgram.programId, s, e, r, i, n, S), exports.editRecordInstruction = v, exports.getValidationLength = x, exports.validateEthSignature = (e, r, i, n, s, o, a, u, c)=>new b({
        validation: o,
        signature: Array.from(a),
        expectedPubkey: Array.from(u)
    }).getInstruction(c, t.SystemProgram.programId, s, e, r, i, n, S), exports.validateEthereumSignatureInstruction = b, exports.validateSolanaSignature = (e, r, i, n, s, o, a, u)=>new _({
        staleness: a
    }).getInstruction(u, t.SystemProgram.programId, o, e, r, i, n, S, s), exports.validateSolanaSignatureInstruction = _, exports.writeRoa = (e, r, i, n, s, o, a)=>new w({
        roaId: Array.from(o.toBuffer())
    }).getInstruction(a, t.SystemProgram.programId, r, e, i, n, s, S), exports.writeRoaInstruction = w; //# sourceMappingURL=index.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/@bonfida/sns-records/dist/index.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "CENTRAL_STATE_SNS_RECORDS": (()=>A),
    "Record": (()=>V),
    "RecordHeader": (()=>U),
    "SNS_RECORDS_ID": (()=>I),
    "Validation": (()=>B),
    "allocateAndPostRecord": (()=>W),
    "allocateAndPostRecordInstruction": (()=>_),
    "deleteRecord": (()=>j),
    "deleteRecordInstruction": (()=>k),
    "editRecord": (()=>E),
    "editRecordInstruction": (()=>w),
    "getValidationLength": (()=>x),
    "validateEthSignature": (()=>z),
    "validateEthereumSignatureInstruction": (()=>v),
    "validateSolanaSignature": (()=>P),
    "validateSolanaSignatureInstruction": (()=>m),
    "writeRoa": (()=>O),
    "writeRoaInstruction": (()=>S)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$buffer$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/buffer/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/index.mjs [app-route] (ecmascript)");
;
;
;
var n, s = [
    "u8",
    "u16",
    "u32",
    "u64",
    "u128",
    "i8",
    "i16",
    "i32",
    "i64",
    "i128",
    "f32",
    "f64"
], o = function() {
    function e() {
        this.offset = 0, this.buffer_size = 256, this.buffer = new ArrayBuffer(this.buffer_size), this.view = new DataView(this.buffer);
    }
    return e.prototype.resize_if_necessary = function(e) {
        if (this.buffer_size - this.offset < e) {
            this.buffer_size = Math.max(2 * this.buffer_size, this.buffer_size + e);
            var t = new ArrayBuffer(this.buffer_size);
            new Uint8Array(t).set(new Uint8Array(this.buffer)), this.buffer = t, this.view = new DataView(t);
        }
    }, e.prototype.get_used_buffer = function() {
        return new Uint8Array(this.buffer).slice(0, this.offset);
    }, e.prototype.store_value = function(e, t) {
        var r = t.substring(1), i = parseInt(r) / 8;
        this.resize_if_necessary(i);
        var n = "f" === t[0] ? "setFloat".concat(r) : "i" === t[0] ? "setInt".concat(r) : "setUint".concat(r);
        this.view[n](this.offset, e, !0), this.offset += i;
    }, e.prototype.store_bytes = function(e) {
        this.resize_if_necessary(e.length), new Uint8Array(this.buffer).set(new Uint8Array(e), this.offset), this.offset += e.length;
    }, e;
}(), a = function() {
    function e(e) {
        this.offset = 0, this.buffer_size = e.length, this.buffer = new ArrayBuffer(e.length), new Uint8Array(this.buffer).set(e), this.view = new DataView(this.buffer);
    }
    return e.prototype.assert_enough_buffer = function(e) {
        if (this.offset + e > this.buffer.byteLength) throw new Error("Error in schema, the buffer is smaller than expected");
    }, e.prototype.consume_value = function(e) {
        var t = e.substring(1), r = parseInt(t) / 8;
        this.assert_enough_buffer(r);
        var i = "f" === e[0] ? "getFloat".concat(t) : "i" === e[0] ? "getInt".concat(t) : "getUint".concat(t), n = this.view[i](this.offset, !0);
        return this.offset += r, n;
    }, e.prototype.consume_bytes = function(e) {
        this.assert_enough_buffer(e);
        var t = this.buffer.slice(this.offset, this.offset + e);
        return this.offset += e, t;
    }, e;
}(), u = (n = function(e, t) {
    return n = Object.setPrototypeOf || ({
        __proto__: []
    }) instanceof Array && function(e, t) {
        e.__proto__ = t;
    } || function(e, t) {
        for(var r in t)Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
    }, n(e, t);
}, function(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
    function r() {
        this.constructor = e;
    }
    n(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r);
});
function c(e, t, r) {
    if (typeof e !== t) throw new Error("Expected ".concat(t, " not ").concat(typeof e, "(").concat(e, ") at ").concat(r.join(".")));
}
function h(e, t, r) {
    if (e !== t) throw new Error("Array length ".concat(e, " does not match schema length ").concat(t, " at ").concat(r.join(".")));
}
var f = s.concat([
    "bool",
    "string"
]), d = [
    "option",
    "enum",
    "array",
    "set",
    "map",
    "struct"
], l = function(e) {
    function t(t, r) {
        var i = "Invalid schema: ".concat(JSON.stringify(t), " expected ").concat(r);
        return e.call(this, i) || this;
    }
    return u(t, e), t;
}(Error);
function p(e) {
    if ("string" != typeof e || !f.includes(e)) {
        if (e && "object" == typeof e) {
            var t = Object.keys(e);
            if (1 === t.length && d.includes(t[0])) {
                var r = t[0];
                if ("option" === r) return p(e[r]);
                if ("enum" === r) return function(e) {
                    if (!Array.isArray(e)) throw new l(e, "Array");
                    for(var t = 0, r = e; t < r.length; t++){
                        var i = r[t];
                        if ("object" != typeof i || !("struct" in i)) throw new Error('Missing "struct" key in enum schema');
                        if ("object" != typeof i.struct || 1 !== Object.keys(i.struct).length) throw new Error('The "struct" in each enum must have a single key');
                        p({
                            struct: i.struct
                        });
                    }
                }(e[r]);
                if ("array" === r) return function(e) {
                    if ("object" != typeof e) throw new l(e, "{ type, len? }");
                    if (e.len && "number" != typeof e.len) throw new Error("Invalid schema: ".concat(e));
                    if ("type" in e) return p(e.type);
                    throw new l(e, "{ type, len? }");
                }(e[r]);
                if ("set" === r) return p(e[r]);
                if ("map" === r) return function(e) {
                    if ("object" != typeof e || !("key" in e) || !("value" in e)) throw new l(e, "{ key, value }");
                    p(e.key), p(e.value);
                }(e[r]);
                if ("struct" === r) return function(e) {
                    if ("object" != typeof e) throw new l(e, "object");
                    for(var t in e)p(e[t]);
                }(e[r]);
            }
        }
        throw new l(e, d.join(", ") + " or " + f.join(", "));
    }
}
var y = function() {
    function e(e) {
        this.encoded = new o, this.fieldPath = [
            "value"
        ], this.checkTypes = e;
    }
    return e.prototype.encode = function(e, t) {
        return this.encode_value(e, t), this.encoded.get_used_buffer();
    }, e.prototype.encode_value = function(e, t) {
        if ("string" == typeof t) {
            if (s.includes(t)) return this.encode_integer(e, t);
            if ("string" === t) return this.encode_string(e);
            if ("bool" === t) return this.encode_boolean(e);
        }
        if ("object" == typeof t) {
            if ("option" in t) return this.encode_option(e, t);
            if ("enum" in t) return this.encode_enum(e, t);
            if ("array" in t) return this.encode_array(e, t);
            if ("set" in t) return this.encode_set(e, t);
            if ("map" in t) return this.encode_map(e, t);
            if ("struct" in t) return this.encode_struct(e, t);
        }
    }, e.prototype.encode_integer = function(e, t) {
        var r = parseInt(t.substring(1));
        r <= 32 || "f64" == t ? (this.checkTypes && c(e, "number", this.fieldPath), this.encoded.store_value(e, t)) : (this.checkTypes && function(e, t) {
            if (!([
                "number",
                "string",
                "bigint",
                "boolean"
            ].includes(typeof e) || "object" == typeof e && null !== e && "toString" in e)) throw new Error("Expected bigint, number, boolean or string not ".concat(typeof e, "(").concat(e, ") at ").concat(t.join(".")));
        }(e, this.fieldPath), this.encode_bigint(BigInt(e), r));
    }, e.prototype.encode_bigint = function(e, t) {
        for(var r = t / 8, i = new Uint8Array(r), n = 0; n < r; n++)i[n] = Number(e & BigInt(255)), e >>= BigInt(8);
        this.encoded.store_bytes(new Uint8Array(i));
    }, e.prototype.encode_string = function(e) {
        this.checkTypes && c(e, "string", this.fieldPath);
        var t = e;
        this.encoded.store_value(t.length, "u32");
        for(var r = 0; r < t.length; r++)this.encoded.store_value(t.charCodeAt(r), "u8");
    }, e.prototype.encode_boolean = function(e) {
        this.checkTypes && c(e, "boolean", this.fieldPath), this.encoded.store_value(e ? 1 : 0, "u8");
    }, e.prototype.encode_option = function(e, t) {
        null == e ? this.encoded.store_value(0, "u8") : (this.encoded.store_value(1, "u8"), this.encode_value(e, t.option));
    }, e.prototype.encode_enum = function(e, t) {
        this.checkTypes && function(e, t) {
            if ("object" != typeof e || null === e) throw new Error("Expected object not ".concat(typeof e, "(").concat(e, ") at ").concat(t.join(".")));
        }(e, this.fieldPath);
        for(var r = Object.keys(e)[0], i = 0; i < t.enum.length; i++){
            var n = t.enum[i];
            if (r === Object.keys(n.struct)[0]) return this.encoded.store_value(i, "u8"), this.encode_struct(e, n);
        }
        throw new Error("Enum key (".concat(r, ") not found in enum schema: ").concat(JSON.stringify(t), " at ").concat(this.fieldPath.join(".")));
    }, e.prototype.encode_array = function(e, t) {
        if (function(e) {
            return Array.isArray(e) || !!e && "object" == typeof e && "length" in e && "number" == typeof e.length && (0 === e.length || e.length > 0 && e.length - 1 in e);
        }(e)) return this.encode_arraylike(e, t);
        if (e instanceof ArrayBuffer) return this.encode_buffer(e, t);
        throw new Error("Expected Array-like not ".concat(typeof e, "(").concat(e, ") at ").concat(this.fieldPath.join(".")));
    }, e.prototype.encode_arraylike = function(e, t) {
        t.array.len ? h(e.length, t.array.len, this.fieldPath) : this.encoded.store_value(e.length, "u32");
        for(var r = 0; r < e.length; r++)this.encode_value(e[r], t.array.type);
    }, e.prototype.encode_buffer = function(e, t) {
        t.array.len ? h(e.byteLength, t.array.len, this.fieldPath) : this.encoded.store_value(e.byteLength, "u32"), this.encoded.store_bytes(new Uint8Array(e));
    }, e.prototype.encode_set = function(e, t) {
        this.checkTypes && c(e, "object", this.fieldPath);
        var r = e instanceof Set ? Array.from(e.values()) : Object.values(e);
        this.encoded.store_value(r.length, "u32");
        for(var i = 0, n = r; i < n.length; i++){
            var s = n[i];
            this.encode_value(s, t.set);
        }
    }, e.prototype.encode_map = function(e, t) {
        this.checkTypes && c(e, "object", this.fieldPath);
        var r = e instanceof Map, i = r ? Array.from(e.keys()) : Object.keys(e);
        this.encoded.store_value(i.length, "u32");
        for(var n = 0, s = i; n < s.length; n++){
            var o = s[n];
            this.encode_value(o, t.map.key), this.encode_value(r ? e.get(o) : e[o], t.map.value);
        }
    }, e.prototype.encode_struct = function(e, t) {
        this.checkTypes && c(e, "object", this.fieldPath);
        for(var r = 0, i = Object.keys(t.struct); r < i.length; r++){
            var n = i[r];
            this.fieldPath.push(n), this.encode_value(e[n], t.struct[n]), this.fieldPath.pop();
        }
    }, e;
}(), g = function() {
    function e(e) {
        this.buffer = new a(e);
    }
    return e.prototype.decode = function(e) {
        return this.decode_value(e);
    }, e.prototype.decode_value = function(e) {
        if ("string" == typeof e) {
            if (s.includes(e)) return this.decode_integer(e);
            if ("string" === e) return this.decode_string();
            if ("bool" === e) return this.decode_boolean();
        }
        if ("object" == typeof e) {
            if ("option" in e) return this.decode_option(e);
            if ("enum" in e) return this.decode_enum(e);
            if ("array" in e) return this.decode_array(e);
            if ("set" in e) return this.decode_set(e);
            if ("map" in e) return this.decode_map(e);
            if ("struct" in e) return this.decode_struct(e);
        }
        throw new Error("Unsupported type: ".concat(e));
    }, e.prototype.decode_integer = function(e) {
        var t = parseInt(e.substring(1));
        return t <= 32 || "f64" == e ? this.buffer.consume_value(e) : this.decode_bigint(t, e.startsWith("i"));
    }, e.prototype.decode_bigint = function(e, t) {
        void 0 === t && (t = !1);
        var r = e / 8, i = new Uint8Array(this.buffer.consume_bytes(r)), n = i.reduceRight(function(e, t) {
            return e + t.toString(16).padStart(2, "0");
        }, "");
        return t && i[r - 1] ? BigInt.asIntN(e, BigInt("0x".concat(n))) : BigInt("0x".concat(n));
    }, e.prototype.decode_string = function() {
        var e = this.decode_integer("u32"), t = new Uint8Array(this.buffer.consume_bytes(e));
        return String.fromCharCode.apply(null, t);
    }, e.prototype.decode_boolean = function() {
        return this.buffer.consume_value("u8") > 0;
    }, e.prototype.decode_option = function(e) {
        var t = this.buffer.consume_value("u8");
        if (1 === t) return this.decode_value(e.option);
        if (0 !== t) throw new Error("Invalid option ".concat(t));
        return null;
    }, e.prototype.decode_enum = function(e) {
        var t, r = this.buffer.consume_value("u8");
        if (r > e.enum.length) throw new Error("Enum option ".concat(r, " is not available"));
        var i = e.enum[r].struct, n = Object.keys(i)[0];
        return (t = {})[n] = this.decode_value(i[n]), t;
    }, e.prototype.decode_array = function(e) {
        for(var t = [], r = e.array.len ? e.array.len : this.decode_integer("u32"), i = 0; i < r; ++i)t.push(this.decode_value(e.array.type));
        return t;
    }, e.prototype.decode_set = function(e) {
        for(var t = this.decode_integer("u32"), r = new Set, i = 0; i < t; ++i)r.add(this.decode_value(e.set));
        return r;
    }, e.prototype.decode_map = function(e) {
        for(var t = this.decode_integer("u32"), r = new Map, i = 0; i < t; ++i){
            var n = this.decode_value(e.map.key), s = this.decode_value(e.map.value);
            r.set(n, s);
        }
        return r;
    }, e.prototype.decode_struct = function(e) {
        var t = {};
        for(var r in e.struct)t[r] = this.decode_value(e.struct[r]);
        return t;
    }, e;
}();
function b(e, t, r) {
    return void 0 === r && (r = !0), r && p(e), new y(r).encode(t, e);
}
class _ {
    constructor(e){
        this.tag = 1, this.record = e.record, this.content = e.content;
    }
    serialize() {
        return b(_.schema, this);
    }
    getInstruction(e, t, n, s, o, a, u, c) {
        const h = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].Buffer.from(this.serialize());
        let f = [];
        return f.push({
            pubkey: t,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: n,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: s,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: o,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: a,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: u,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: c,
            isSigner: !1,
            isWritable: !1
        }), new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
            keys: f,
            programId: e,
            data: h
        });
    }
}
_.schema = {
    struct: {
        tag: "u8",
        record: "string",
        content: {
            array: {
                type: "u8"
            }
        }
    }
};
class v {
    constructor(e){
        this.tag = 4, this.validation = e.validation, this.signature = e.signature, this.expectedPubkey = e.expectedPubkey;
    }
    serialize() {
        return b(v.schema, this);
    }
    getInstruction(e, t, n, s, o, a, u, c) {
        const h = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].Buffer.from(this.serialize());
        let f = [];
        return f.push({
            pubkey: t,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: n,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: s,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: o,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: a,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: u,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: c,
            isSigner: !1,
            isWritable: !1
        }), new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
            keys: f,
            programId: e,
            data: h
        });
    }
}
v.schema = {
    struct: {
        tag: "u8",
        validation: "u8",
        signature: {
            array: {
                type: "u8"
            }
        },
        expectedPubkey: {
            array: {
                type: "u8"
            }
        }
    }
};
class m {
    constructor(e){
        this.tag = 3, this.staleness = e.staleness;
    }
    serialize() {
        return b(m.schema, this);
    }
    getInstruction(e, t, n, s, o, a, u, c, h) {
        const f = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].Buffer.from(this.serialize());
        let d = [];
        return d.push({
            pubkey: t,
            isSigner: !1,
            isWritable: !1
        }), d.push({
            pubkey: n,
            isSigner: !1,
            isWritable: !1
        }), d.push({
            pubkey: s,
            isSigner: !0,
            isWritable: !0
        }), d.push({
            pubkey: o,
            isSigner: !1,
            isWritable: !0
        }), d.push({
            pubkey: a,
            isSigner: !1,
            isWritable: !0
        }), d.push({
            pubkey: u,
            isSigner: !1,
            isWritable: !0
        }), d.push({
            pubkey: c,
            isSigner: !1,
            isWritable: !1
        }), d.push({
            pubkey: h,
            isSigner: !0,
            isWritable: !0
        }), new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
            keys: d,
            programId: e,
            data: f
        });
    }
}
m.schema = {
    struct: {
        tag: "u8",
        staleness: "bool"
    }
};
class w {
    constructor(e){
        this.tag = 2, this.record = e.record, this.content = e.content;
    }
    serialize() {
        return b(w.schema, this);
    }
    getInstruction(e, t, n, s, o, a, u, c) {
        const h = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].Buffer.from(this.serialize());
        let f = [];
        return f.push({
            pubkey: t,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: n,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: s,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: o,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: a,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: u,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: c,
            isSigner: !1,
            isWritable: !1
        }), new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
            keys: f,
            programId: e,
            data: h
        });
    }
}
w.schema = {
    struct: {
        tag: "u8",
        record: "string",
        content: {
            array: {
                type: "u8"
            }
        }
    }
};
class k {
    constructor(){
        this.tag = 5;
    }
    serialize() {
        return b(k.schema, this);
    }
    getInstruction(e, t, n, s, o, a, u, c) {
        const h = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].Buffer.from(this.serialize());
        let f = [];
        return f.push({
            pubkey: t,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: n,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: s,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: o,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: a,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: u,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: c,
            isSigner: !1,
            isWritable: !1
        }), new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
            keys: f,
            programId: e,
            data: h
        });
    }
}
k.schema = {
    struct: {
        tag: "u8"
    }
};
class S {
    constructor(e){
        this.tag = 6, this.roaId = e.roaId;
    }
    serialize() {
        return b(S.schema, this);
    }
    getInstruction(e, t, n, s, o, a, u, c) {
        const h = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].Buffer.from(this.serialize());
        let f = [];
        return f.push({
            pubkey: t,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: n,
            isSigner: !1,
            isWritable: !1
        }), f.push({
            pubkey: s,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: o,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: a,
            isSigner: !1,
            isWritable: !0
        }), f.push({
            pubkey: u,
            isSigner: !0,
            isWritable: !0
        }), f.push({
            pubkey: c,
            isSigner: !1,
            isWritable: !1
        }), new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TransactionInstruction"]({
            keys: f,
            programId: e,
            data: h
        });
    }
}
S.schema = {
    struct: {
        tag: "u8",
        roaId: {
            array: {
                type: "u8"
            }
        }
    }
};
const I = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PublicKey"]("HP3D4D1ZCmohQGFVms2SS4LCANgJyksBf5s1F77FuFjZ"), [A] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PublicKey"].findProgramAddressSync([
    I.toBuffer()
], I), W = (e, r, i, n, s, o, a, u)=>new _({
        record: o,
        content: Array.from(a)
    }).getInstruction(u, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId, s, e, r, i, n, A), j = (e, r, i, n, s, o)=>(new k).getInstruction(o, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId, s, e, n, r, i, A), E = (e, r, i, n, s, o, a, u)=>new w({
        record: o,
        content: Array.from(a)
    }).getInstruction(u, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId, s, e, r, i, n, A), z = (e, r, i, n, s, o, a, u, c)=>new v({
        validation: o,
        signature: Array.from(a),
        expectedPubkey: Array.from(u)
    }).getInstruction(c, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId, s, e, r, i, n, A), P = (e, r, i, n, s, o, a, u)=>new m({
        staleness: a
    }).getInstruction(u, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId, o, e, r, i, n, A, s), O = (e, r, i, n, s, o, a)=>new S({
        roaId: Array.from(o.toBuffer())
    }).getInstruction(a, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8$2d$validate$40$5$2e$0$2e$10$2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SystemProgram"].programId, r, e, i, n, s, A);
var B, R;
(R = B || (B = {}))[R.None = 0] = "None", R[R.Solana = 1] = "Solana", R[R.Ethereum = 2] = "Ethereum", R[R.UnverifiedSolana = 3] = "UnverifiedSolana";
const x = (e)=>{
    switch(e){
        case B.None:
            return 0;
        case B.Ethereum:
            return 20;
        case B.Solana:
        case B.UnverifiedSolana:
            return 32;
        default:
            throw new Error("Invalid validation enum");
    }
};
class U {
    constructor(e){
        this.stalenessValidation = e.stalenessValidation, this.rightOfAssociationValidation = e.rightOfAssociationValidation, this.contentLength = e.contentLength;
    }
    static deserialize(e) {
        return new U((t = this.schema, r = e, void 0 === (i = !0) && (i = !0), i && p(t), new g(r).decode(t)));
        "TURBOPACK unreachable";
        var t, r, i;
    }
    static async retrieve(e, t) {
        const r = await e.getAccountInfo(t);
        if (!r || !r.data) throw new Error("Record header account not found");
        return this.deserialize(r.data.slice(96, 96 + this.LEN));
    }
}
U.LEN = 8, U.schema = {
    struct: {
        stalenessValidation: "u16",
        rightOfAssociationValidation: "u16",
        contentLength: "u32"
    }
};
class V {
    constructor(e, t){
        this.data = t, this.header = e;
    }
    static deserialize(e) {
        const t = U.deserialize(e.slice(96, 96 + U.LEN)), r = e.slice(96 + U.LEN);
        return new V(t, r);
    }
    static async retrieve(e, t) {
        const r = await e.getAccountInfo(t);
        if (!r || !r.data) throw new Error("Record header account not found");
        return this.deserialize(r.data);
    }
    static async retrieveBatch(e, t) {
        return (await e.getMultipleAccountsInfo(t)).map((e)=>{
            if (null == e ? void 0 : e.data) return this.deserialize(e.data);
        });
    }
    getContent() {
        let e = x(this.header.stalenessValidation) + x(this.header.rightOfAssociationValidation);
        return this.data.slice(e);
    }
    getStalenessId() {
        let e = x(this.header.stalenessValidation);
        return this.data.slice(0, e);
    }
    getRoAId() {
        let e = x(this.header.stalenessValidation), t = e + x(this.header.rightOfAssociationValidation);
        return this.data.slice(e, t);
    }
}
;
 //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/@scure/base/lib/esm/index.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
/*! scure-base - MIT License (c) 2022 Paul Miller (paulmillr.com) */ function r(...r1) {
    const e = (r)=>r, o = (r, e)=>(o)=>r(e(o));
    return {
        encode: r1.map((r)=>r.encode).reduceRight(o, e),
        decode: r1.map((r)=>r.decode).reduce(o, e)
    };
}
const e = (r, o)=>o ? e(o, r % o) : r, o = (r, o)=>r + (o - e(r, o));
function n(r, e, n, t) {
    if (!Array.isArray(r)) throw new Error("convertRadix2: data should be array");
    if (e <= 0 || e > 32) throw new Error(`convertRadix2: wrong from=${e}`);
    if (n <= 0 || n > 32) throw new Error(`convertRadix2: wrong to=${n}`);
    if (o(e, n) > 32) throw new Error(`convertRadix2: carry overflow from=${e} to=${n} carryBits=${o(e, n)}`);
    let i = 0, f = 0;
    const s = 2 ** n - 1, c = [];
    for (const o of r){
        if (o >= 2 ** e) throw new Error(`convertRadix2: invalid data word=${o} from=${e}`);
        if (i = i << e | o, f + e > 32) throw new Error(`convertRadix2: carry overflow pos=${f} from=${e}`);
        for(f += e; f >= n; f -= n)c.push((i >> f - n & s) >>> 0);
        i &= 2 ** f - 1;
    }
    if (i = i << n - f & s, !t && f >= e) throw new Error("Excess padding");
    if (!t && i) throw new Error(`Non-zero padding: ${i}`);
    return t && f > 0 && c.push(i >>> 0), c;
}
function t(r, e = !1) {
    if (r <= 0 || r > 32) throw new Error("radix2: bits should be in (0..32]");
    if (o(8, r) > 32 || o(r, 8) > 32) throw new Error("radix2: carry overflow");
    return {
        encode: (o)=>{
            if (!((t = o) instanceof Uint8Array || null != t && "object" == typeof t && "Uint8Array" === t.constructor.name)) throw new Error("radix2.encode input should be Uint8Array");
            var t;
            return n(Array.from(o), 8, r, !e);
        },
        decode: (o)=>{
            if (!Array.isArray(o) || o.length && "number" != typeof o[0]) throw new Error("radix2.decode input should be array of numbers");
            return Uint8Array.from(n(o, r, 8, e));
        }
    };
}
function i(r) {
    if ("function" != typeof r) throw new Error("unsafeWrapper fn should be function");
    return function(...e) {
        try {
            return r.apply(null, e);
        } catch (r) {}
    };
}
const f = r(function(r) {
    return {
        encode: (e)=>{
            if (!Array.isArray(e) || e.length && "number" != typeof e[0]) throw new Error("alphabet.encode input should be an array of numbers");
            return e.map((e)=>{
                if (e < 0 || e >= r.length) throw new Error(`Digit index outside alphabet: ${e} (alphabet: ${r.length})`);
                return r[e];
            });
        },
        decode: (e)=>{
            if (!Array.isArray(e) || e.length && "string" != typeof e[0]) throw new Error("alphabet.decode input should be array of strings");
            return e.map((e)=>{
                if ("string" != typeof e) throw new Error(`alphabet.decode: not string element=${e}`);
                const o = r.indexOf(e);
                if (-1 === o) throw new Error(`Unknown letter: "${e}". Allowed: ${r}`);
                return o;
            });
        }
    };
}("qpzry9x8gf2tvdw0s3jn54khce6mua7l"), function(r = "") {
    if ("string" != typeof r) throw new Error("join separator should be string");
    return {
        encode: (e)=>{
            if (!Array.isArray(e) || e.length && "string" != typeof e[0]) throw new Error("join.encode input should be array of strings");
            for (let r of e)if ("string" != typeof r) throw new Error(`join.encode: non-string input=${r}`);
            return e.join(r);
        },
        decode: (e)=>{
            if ("string" != typeof e) throw new Error("join.decode input should be string");
            return e.split(r);
        }
    };
}("")), s = [
    996825010,
    642813549,
    513874426,
    1027748829,
    705979059
];
function c(r) {
    const e = r >> 25;
    let o = (33554431 & r) << 5;
    for(let r = 0; r < s.length; r++)1 == (e >> r & 1) && (o ^= s[r]);
    return o;
}
function d(r, e, o = 1) {
    const t = r.length;
    let i = 1;
    for(let e = 0; e < t; e++){
        const o = r.charCodeAt(e);
        if (o < 33 || o > 126) throw new Error(`Invalid prefix (${r})`);
        i = c(i) ^ o >> 5;
    }
    i = c(i);
    for(let e = 0; e < t; e++)i = c(i) ^ 31 & r.charCodeAt(e);
    for (let r of e)i = c(i) ^ r;
    for(let r = 0; r < 6; r++)i = c(i);
    return i ^= o, f.encode(n([
        i % 2 ** 30
    ], 30, 5, !1));
}
function a(r) {
    const e = "bech32" === r ? 1 : 734539939, o = t(5), n = o.decode, s = o.encode, c = i(n);
    function a(r, o = 90) {
        if ("string" != typeof r) throw new Error("bech32.decode input should be string, not " + typeof r);
        if (r.length < 8 || !1 !== o && r.length > o) throw new TypeError(`Wrong string length: ${r.length} (${r}). Expected (8..${o})`);
        const n = r.toLowerCase();
        if (r !== n && r !== r.toUpperCase()) throw new Error("String must be lowercase or uppercase");
        const t = n.lastIndexOf("1");
        if (0 === t || -1 === t) throw new Error('Letter "1" must be present between prefix and data only');
        const i = n.slice(0, t), s = n.slice(t + 1);
        if (s.length < 6) throw new Error("Data must be at least 6 characters long");
        const c = f.decode(s).slice(0, -6), a1 = d(i, c, e);
        if (!s.endsWith(a1)) throw new Error(`Invalid checksum in ${r}: expected "${a1}"`);
        return {
            prefix: i,
            words: c
        };
    }
    return {
        encode: function(r, o, n = 90) {
            if ("string" != typeof r) throw new Error("bech32.encode prefix should be string, not " + typeof r);
            if (!Array.isArray(o) || o.length && "number" != typeof o[0]) throw new Error("bech32.encode words should be array of numbers, not " + typeof o);
            if (0 === r.length) throw new TypeError(`Invalid prefix length ${r.length}`);
            const t = r.length + 7 + o.length;
            if (!1 !== n && t > n) throw new TypeError(`Length ${t} exceeds limit ${n}`);
            const i = r.toLowerCase(), s = d(i, o, e);
            return `${i}1${f.encode(o)}${s}`;
        },
        decode: a,
        decodeToBytes: function(r) {
            const { prefix: e, words: o } = a(r, !1);
            return {
                prefix: e,
                words: o,
                bytes: n(o)
            };
        },
        decodeUnsafe: i(a),
        fromWords: n,
        fromWordsUnsafe: c,
        toWords: s
    };
}
const h = a("bech32");
exports.bech32 = h; //# sourceMappingURL=index.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/@scure/base/lib/esm/index.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/*! scure-base - MIT License (c) 2022 Paul Miller (paulmillr.com) */ __turbopack_esm__({
    "bech32": (()=>h)
});
function r(...r1) {
    const e = (r)=>r, o = (r, e)=>(o)=>r(e(o));
    return {
        encode: r1.map((r)=>r.encode).reduceRight(o, e),
        decode: r1.map((r)=>r.decode).reduce(o, e)
    };
}
const e = (r, o)=>o ? e(o, r % o) : r, o = (r, o)=>r + (o - e(r, o));
function n(r, e, n, t) {
    if (!Array.isArray(r)) throw new Error("convertRadix2: data should be array");
    if (e <= 0 || e > 32) throw new Error(`convertRadix2: wrong from=${e}`);
    if (n <= 0 || n > 32) throw new Error(`convertRadix2: wrong to=${n}`);
    if (o(e, n) > 32) throw new Error(`convertRadix2: carry overflow from=${e} to=${n} carryBits=${o(e, n)}`);
    let i = 0, f = 0;
    const c = 2 ** n - 1, d = [];
    for (const o of r){
        if (o >= 2 ** e) throw new Error(`convertRadix2: invalid data word=${o} from=${e}`);
        if (i = i << e | o, f + e > 32) throw new Error(`convertRadix2: carry overflow pos=${f} from=${e}`);
        for(f += e; f >= n; f -= n)d.push((i >> f - n & c) >>> 0);
        i &= 2 ** f - 1;
    }
    if (i = i << n - f & c, !t && f >= e) throw new Error("Excess padding");
    if (!t && i) throw new Error(`Non-zero padding: ${i}`);
    return t && f > 0 && d.push(i >>> 0), d;
}
function t(r, e = !1) {
    if (r <= 0 || r > 32) throw new Error("radix2: bits should be in (0..32]");
    if (o(8, r) > 32 || o(r, 8) > 32) throw new Error("radix2: carry overflow");
    return {
        encode: (o)=>{
            if (!((t = o) instanceof Uint8Array || null != t && "object" == typeof t && "Uint8Array" === t.constructor.name)) throw new Error("radix2.encode input should be Uint8Array");
            var t;
            return n(Array.from(o), 8, r, !e);
        },
        decode: (o)=>{
            if (!Array.isArray(o) || o.length && "number" != typeof o[0]) throw new Error("radix2.decode input should be array of numbers");
            return Uint8Array.from(n(o, r, 8, e));
        }
    };
}
function i(r) {
    if ("function" != typeof r) throw new Error("unsafeWrapper fn should be function");
    return function(...e) {
        try {
            return r.apply(null, e);
        } catch (r) {}
    };
}
const f = r(function(r) {
    return {
        encode: (e)=>{
            if (!Array.isArray(e) || e.length && "number" != typeof e[0]) throw new Error("alphabet.encode input should be an array of numbers");
            return e.map((e)=>{
                if (e < 0 || e >= r.length) throw new Error(`Digit index outside alphabet: ${e} (alphabet: ${r.length})`);
                return r[e];
            });
        },
        decode: (e)=>{
            if (!Array.isArray(e) || e.length && "string" != typeof e[0]) throw new Error("alphabet.decode input should be array of strings");
            return e.map((e)=>{
                if ("string" != typeof e) throw new Error(`alphabet.decode: not string element=${e}`);
                const o = r.indexOf(e);
                if (-1 === o) throw new Error(`Unknown letter: "${e}". Allowed: ${r}`);
                return o;
            });
        }
    };
}("qpzry9x8gf2tvdw0s3jn54khce6mua7l"), function(r = "") {
    if ("string" != typeof r) throw new Error("join separator should be string");
    return {
        encode: (e)=>{
            if (!Array.isArray(e) || e.length && "string" != typeof e[0]) throw new Error("join.encode input should be array of strings");
            for (let r of e)if ("string" != typeof r) throw new Error(`join.encode: non-string input=${r}`);
            return e.join(r);
        },
        decode: (e)=>{
            if ("string" != typeof e) throw new Error("join.decode input should be string");
            return e.split(r);
        }
    };
}("")), c = [
    996825010,
    642813549,
    513874426,
    1027748829,
    705979059
];
function d(r) {
    const e = r >> 25;
    let o = (33554431 & r) << 5;
    for(let r = 0; r < c.length; r++)1 == (e >> r & 1) && (o ^= c[r]);
    return o;
}
function s(r, e, o = 1) {
    const t = r.length;
    let i = 1;
    for(let e = 0; e < t; e++){
        const o = r.charCodeAt(e);
        if (o < 33 || o > 126) throw new Error(`Invalid prefix (${r})`);
        i = d(i) ^ o >> 5;
    }
    i = d(i);
    for(let e = 0; e < t; e++)i = d(i) ^ 31 & r.charCodeAt(e);
    for (let r of e)i = d(i) ^ r;
    for(let r = 0; r < 6; r++)i = d(i);
    return i ^= o, f.encode(n([
        i % 2 ** 30
    ], 30, 5, !1));
}
function a(r) {
    const e = "bech32" === r ? 1 : 734539939, o = t(5), n = o.decode, c = o.encode, d = i(n);
    function a(r, o = 90) {
        if ("string" != typeof r) throw new Error("bech32.decode input should be string, not " + typeof r);
        if (r.length < 8 || !1 !== o && r.length > o) throw new TypeError(`Wrong string length: ${r.length} (${r}). Expected (8..${o})`);
        const n = r.toLowerCase();
        if (r !== n && r !== r.toUpperCase()) throw new Error("String must be lowercase or uppercase");
        const t = n.lastIndexOf("1");
        if (0 === t || -1 === t) throw new Error('Letter "1" must be present between prefix and data only');
        const i = n.slice(0, t), c = n.slice(t + 1);
        if (c.length < 6) throw new Error("Data must be at least 6 characters long");
        const d = f.decode(c).slice(0, -6), a1 = s(i, d, e);
        if (!c.endsWith(a1)) throw new Error(`Invalid checksum in ${r}: expected "${a1}"`);
        return {
            prefix: i,
            words: d
        };
    }
    return {
        encode: function(r, o, n = 90) {
            if ("string" != typeof r) throw new Error("bech32.encode prefix should be string, not " + typeof r);
            if (!Array.isArray(o) || o.length && "number" != typeof o[0]) throw new Error("bech32.encode words should be array of numbers, not " + typeof o);
            if (0 === r.length) throw new TypeError(`Invalid prefix length ${r.length}`);
            const t = r.length + 7 + o.length;
            if (!1 !== n && t > n) throw new TypeError(`Length ${t} exceeds limit ${n}`);
            const i = r.toLowerCase(), c = s(i, o, e);
            return `${i}1${f.encode(o)}${c}`;
        },
        decode: a,
        decodeToBytes: function(r) {
            const { prefix: e, words: o } = a(r, !1);
            return {
                prefix: e,
                words: o,
                bytes: n(o)
            };
        },
        decodeUnsafe: i(a),
        fromWords: n,
        fromWordsUnsafe: d,
        toWords: c
    };
}
const h = a("bech32");
;
 //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/punycode/punycode.es6.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
const o = 2147483647, t = 36, n = {
    overflow: "Overflow: input needs wider integers to process",
    "not-basic": "Illegal input >= 0x80 (not a basic code point)",
    "invalid-input": "Invalid input"
}, e = Math.floor, r = String.fromCharCode;
function s(o) {
    throw new RangeError(n[o]);
}
function c(o) {
    const t = [];
    let n = 0;
    const e = o.length;
    for(; n < e;){
        const r = o.charCodeAt(n++);
        if (r >= 55296 && r <= 56319 && n < e) {
            const e = o.charCodeAt(n++);
            56320 == (64512 & e) ? t.push(((1023 & r) << 10) + (1023 & e) + 65536) : (t.push(r), n--);
        } else t.push(r);
    }
    return t;
}
const i = function(o, t) {
    return o + 22 + 75 * (o < 26) - ((0 != t) << 5);
}, f = function(o, n, r) {
    let s = 0;
    for(o = r ? e(o / 700) : o >> 1, o += e(o / n); o > 455; s += t)o = e(o / 35);
    return e(s + 36 * o / (o + 38));
};
exports.decode = function(n) {
    const r = [], c = n.length;
    let i = 0, l = 128, u = 72, a = n.lastIndexOf("-");
    a < 0 && (a = 0);
    for(let o = 0; o < a; ++o)n.charCodeAt(o) >= 128 && s("not-basic"), r.push(n.charCodeAt(o));
    for(let d = a > 0 ? a + 1 : 0; d < c;){
        const a = i;
        for(let r = 1, f = t;; f += t){
            d >= c && s("invalid-input");
            const l = (h = n.charCodeAt(d++)) >= 48 && h < 58 ? h - 48 + 26 : h >= 65 && h < 91 ? h - 65 : h >= 97 && h < 123 ? h - 97 : t;
            l >= t && s("invalid-input"), l > e((o - i) / r) && s("overflow"), i += l * r;
            const a = f <= u ? 1 : f >= u + 26 ? 26 : f - u;
            if (l < a) break;
            const p = t - a;
            r > e(o / p) && s("overflow"), r *= p;
        }
        const p = r.length + 1;
        u = f(i - a, p, 0 == a), e(i / p) > o - l && s("overflow"), l += e(i / p), i %= p, r.splice(i++, 0, l);
    }
    var h;
    return String.fromCodePoint(...r);
}, exports.encode = function(n) {
    const l = [], u = (n = c(n)).length;
    let a = 128, h = 0, d = 72;
    for (const o of n)o < 128 && l.push(r(o));
    const p = l.length;
    let v = p;
    for(p && l.push("-"); v < u;){
        let c = o;
        for (const o of n)o >= a && o < c && (c = o);
        const u = v + 1;
        c - a > e((o - h) / u) && s("overflow"), h += (c - a) * u, a = c;
        for (const c of n)if (c < a && ++h > o && s("overflow"), c === a) {
            let o = h;
            for(let n = t;; n += t){
                const s = n <= d ? 1 : n >= d + 26 ? 26 : n - d;
                if (o < s) break;
                const c = o - s, f = t - s;
                l.push(r(i(s + c % f, 0))), o = e(c / f);
            }
            l.push(r(i(o, 0))), d = f(h, u, v === p), h = 0, ++v;
        }
        ++h, ++a;
    }
    return l.join("");
}, exports.ucs2decode = c; //# sourceMappingURL=punycode.es6.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/punycode/punycode.es6.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "decode": (()=>l),
    "encode": (()=>u),
    "ucs2decode": (()=>c)
});
const o = 2147483647, t = 36, n = {
    overflow: "Overflow: input needs wider integers to process",
    "not-basic": "Illegal input >= 0x80 (not a basic code point)",
    "invalid-input": "Invalid input"
}, e = Math.floor, r = String.fromCharCode;
function s(o) {
    throw new RangeError(n[o]);
}
function c(o) {
    const t = [];
    let n = 0;
    const e = o.length;
    for(; n < e;){
        const r = o.charCodeAt(n++);
        if (r >= 55296 && r <= 56319 && n < e) {
            const e = o.charCodeAt(n++);
            56320 == (64512 & e) ? t.push(((1023 & r) << 10) + (1023 & e) + 65536) : (t.push(r), n--);
        } else t.push(r);
    }
    return t;
}
const f = function(o, t) {
    return o + 22 + 75 * (o < 26) - ((0 != t) << 5);
}, i = function(o, n, r) {
    let s = 0;
    for(o = r ? e(o / 700) : o >> 1, o += e(o / n); o > 455; s += t)o = e(o / 35);
    return e(s + 36 * o / (o + 38));
}, l = function(n) {
    const r = [], c = n.length;
    let f = 0, l = 128, u = 72, a = n.lastIndexOf("-");
    a < 0 && (a = 0);
    for(let o = 0; o < a; ++o)n.charCodeAt(o) >= 128 && s("not-basic"), r.push(n.charCodeAt(o));
    for(let p = a > 0 ? a + 1 : 0; p < c;){
        const a = f;
        for(let r = 1, i = t;; i += t){
            p >= c && s("invalid-input");
            const l = (h = n.charCodeAt(p++)) >= 48 && h < 58 ? h - 48 + 26 : h >= 65 && h < 91 ? h - 65 : h >= 97 && h < 123 ? h - 97 : t;
            l >= t && s("invalid-input"), l > e((o - f) / r) && s("overflow"), f += l * r;
            const a = i <= u ? 1 : i >= u + 26 ? 26 : i - u;
            if (l < a) break;
            const d = t - a;
            r > e(o / d) && s("overflow"), r *= d;
        }
        const d = r.length + 1;
        u = i(f - a, d, 0 == a), e(f / d) > o - l && s("overflow"), l += e(f / d), f %= d, r.splice(f++, 0, l);
    }
    var h;
    return String.fromCodePoint(...r);
}, u = function(n) {
    const l = [], u = (n = c(n)).length;
    let a = 128, h = 0, p = 72;
    for (const o of n)o < 128 && l.push(r(o));
    const d = l.length;
    let v = d;
    for(d && l.push("-"); v < u;){
        let c = o;
        for (const o of n)o >= a && o < c && (c = o);
        const u = v + 1;
        c - a > e((o - h) / u) && s("overflow"), h += (c - a) * u, a = c;
        for (const c of n)if (c < a && ++h > o && s("overflow"), c === a) {
            let o = h;
            for(let n = t;; n += t){
                const s = n <= p ? 1 : n >= p + 26 ? 26 : n - p;
                if (o < s) break;
                const c = o - s, i = t - s;
                l.push(r(f(s + c % i, 0))), o = e(c / i);
            }
            l.push(r(f(o, 0))), p = i(h, u, v === d), h = 0, ++v;
        }
        ++h, ++a;
    }
    return l.join("");
};
;
 //# sourceMappingURL=punycode.es6.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/ipaddr.js/lib/ipaddr.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var t, r = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/_virtual/_commonjsHelpers.cjs [app-route] (ecmascript)"), e = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/_virtual/ipaddr.cjs [app-route] (ecmascript)");
t = e.__module, function(r) {
    const e = "(0?\\d+|0x[a-f0-9]+)", n = {
        fourOctet: new RegExp(`^${e}\\.${e}\\.${e}\\.${e}$`, "i"),
        threeOctet: new RegExp(`^${e}\\.${e}\\.${e}$`, "i"),
        twoOctet: new RegExp(`^${e}\\.${e}$`, "i"),
        longValue: new RegExp(`^${e}$`, "i")
    }, i = new RegExp("^0[0-7]+$", "i"), o = new RegExp("^0x[a-f0-9]+$", "i"), s = "%[0-9a-z]{1,}", a = "(?:[0-9a-f]+::?)+", p = {
        zoneIndex: new RegExp(s, "i"),
        native: new RegExp(`^(::)?(${a})?([0-9a-f]+)?(::)?(${s})?$`, "i"),
        deprecatedTransitional: new RegExp(`^(?:::)(${e}\\.${e}\\.${e}\\.${e}(${s})?)$`, "i"),
        transitional: new RegExp(`^((?:${a})|(?:::)(?:${a})?)${e}\\.${e}\\.${e}\\.${e}(${s})?$`, "i")
    };
    function u(t, r) {
        if (t.indexOf("::") !== t.lastIndexOf("::")) return null;
        let e, n, i = 0, o = -1, s = (t.match(p.zoneIndex) || [])[0];
        for(s && (s = s.substring(1), t = t.replace(/%.+$/, "")); (o = t.indexOf(":", o + 1)) >= 0;)i++;
        if ("::" === t.substr(0, 2) && i--, "::" === t.substr(-2, 2) && i--, i > r) return null;
        for(n = r - i, e = ":"; n--;)e += "0:";
        return ":" === (t = t.replace("::", e))[0] && (t = t.slice(1)), ":" === t[t.length - 1] && (t = t.slice(0, -1)), {
            parts: r = function() {
                const r = t.split(":"), e = [];
                for(let t = 0; t < r.length; t++)e.push(parseInt(r[t], 16));
                return e;
            }(),
            zoneId: s
        };
    }
    function d(t, r, e, n) {
        if (t.length !== r.length) throw new Error("ipaddr: cannot match CIDR for objects with different lengths");
        let i, o = 0;
        for(; n > 0;){
            if (i = e - n, i < 0 && (i = 0), t[o] >> i != r[o] >> i) return !1;
            n -= e, o += 1;
        }
        return !0;
    }
    function c(t) {
        if (o.test(t)) return parseInt(t, 16);
        if ("0" === t[0] && !isNaN(parseInt(t[1], 10))) {
            if (i.test(t)) return parseInt(t, 8);
            throw new Error(`ipaddr: cannot parse ${t} as octal`);
        }
        return parseInt(t, 10);
    }
    function h(t, r) {
        for(; t.length < r;)t = `0${t}`;
        return t;
    }
    const f = {};
    f.IPv4 = function() {
        function t(t) {
            if (4 !== t.length) throw new Error("ipaddr: ipv4 octet count should be 4");
            let r, e;
            for(r = 0; r < t.length; r++)if (e = t[r], !(0 <= e && e <= 255)) throw new Error("ipaddr: ipv4 octet should fit in 8 bits");
            this.octets = t;
        }
        return t.prototype.SpecialRanges = {
            unspecified: [
                [
                    new t([
                        0,
                        0,
                        0,
                        0
                    ]),
                    8
                ]
            ],
            broadcast: [
                [
                    new t([
                        255,
                        255,
                        255,
                        255
                    ]),
                    32
                ]
            ],
            multicast: [
                [
                    new t([
                        224,
                        0,
                        0,
                        0
                    ]),
                    4
                ]
            ],
            linkLocal: [
                [
                    new t([
                        169,
                        254,
                        0,
                        0
                    ]),
                    16
                ]
            ],
            loopback: [
                [
                    new t([
                        127,
                        0,
                        0,
                        0
                    ]),
                    8
                ]
            ],
            carrierGradeNat: [
                [
                    new t([
                        100,
                        64,
                        0,
                        0
                    ]),
                    10
                ]
            ],
            private: [
                [
                    new t([
                        10,
                        0,
                        0,
                        0
                    ]),
                    8
                ],
                [
                    new t([
                        172,
                        16,
                        0,
                        0
                    ]),
                    12
                ],
                [
                    new t([
                        192,
                        168,
                        0,
                        0
                    ]),
                    16
                ]
            ],
            reserved: [
                [
                    new t([
                        192,
                        0,
                        0,
                        0
                    ]),
                    24
                ],
                [
                    new t([
                        192,
                        0,
                        2,
                        0
                    ]),
                    24
                ],
                [
                    new t([
                        192,
                        88,
                        99,
                        0
                    ]),
                    24
                ],
                [
                    new t([
                        198,
                        18,
                        0,
                        0
                    ]),
                    15
                ],
                [
                    new t([
                        198,
                        51,
                        100,
                        0
                    ]),
                    24
                ],
                [
                    new t([
                        203,
                        0,
                        113,
                        0
                    ]),
                    24
                ],
                [
                    new t([
                        240,
                        0,
                        0,
                        0
                    ]),
                    4
                ]
            ],
            as112: [
                [
                    new t([
                        192,
                        175,
                        48,
                        0
                    ]),
                    24
                ],
                [
                    new t([
                        192,
                        31,
                        196,
                        0
                    ]),
                    24
                ]
            ],
            amt: [
                [
                    new t([
                        192,
                        52,
                        193,
                        0
                    ]),
                    24
                ]
            ]
        }, t.prototype.kind = function() {
            return "ipv4";
        }, t.prototype.match = function(t, r) {
            let e;
            if (void 0 === r && (e = t, t = e[0], r = e[1]), "ipv4" !== t.kind()) throw new Error("ipaddr: cannot match ipv4 address with non-ipv4 one");
            return d(this.octets, t.octets, 8, r);
        }, t.prototype.prefixLengthFromSubnetMask = function() {
            let t = 0, r = !1;
            const e = {
                0: 8,
                128: 7,
                192: 6,
                224: 5,
                240: 4,
                248: 3,
                252: 2,
                254: 1,
                255: 0
            };
            let n, i, o;
            for(n = 3; n >= 0; n -= 1){
                if (i = this.octets[n], !(i in e)) return null;
                if (o = e[i], r && 0 !== o) return null;
                8 !== o && (r = !0), t += o;
            }
            return 32 - t;
        }, t.prototype.range = function() {
            return f.subnetMatch(this, this.SpecialRanges);
        }, t.prototype.toByteArray = function() {
            return this.octets.slice(0);
        }, t.prototype.toIPv4MappedAddress = function() {
            return f.IPv6.parse(`::ffff:${this.toString()}`);
        }, t.prototype.toNormalizedString = function() {
            return this.toString();
        }, t.prototype.toString = function() {
            return this.octets.join(".");
        }, t;
    }(), f.IPv4.broadcastAddressFromCIDR = function(t) {
        try {
            const r = this.parseCIDR(t), e = r[0].toByteArray(), n = this.subnetMaskFromPrefixLength(r[1]).toByteArray(), i = [];
            let o = 0;
            for(; o < 4;)i.push(parseInt(e[o], 10) | 255 ^ parseInt(n[o], 10)), o++;
            return new this(i);
        } catch (t) {
            throw new Error("ipaddr: the address does not have IPv4 CIDR format");
        }
    }, f.IPv4.isIPv4 = function(t) {
        return null !== this.parser(t);
    }, f.IPv4.isValid = function(t) {
        try {
            return new this(this.parser(t)), !0;
        } catch (t) {
            return !1;
        }
    }, f.IPv4.isValidCIDR = function(t) {
        try {
            return this.parseCIDR(t), !0;
        } catch (t) {
            return !1;
        }
    }, f.IPv4.isValidFourPartDecimal = function(t) {
        return !(!f.IPv4.isValid(t) || !t.match(/^(0|[1-9]\d*)(\.(0|[1-9]\d*)){3}$/));
    }, f.IPv4.networkAddressFromCIDR = function(t) {
        let r, e, n, i, o;
        try {
            for(r = this.parseCIDR(t), n = r[0].toByteArray(), o = this.subnetMaskFromPrefixLength(r[1]).toByteArray(), i = [], e = 0; e < 4;)i.push(parseInt(n[e], 10) & parseInt(o[e], 10)), e++;
            return new this(i);
        } catch (t) {
            throw new Error("ipaddr: the address does not have IPv4 CIDR format");
        }
    }, f.IPv4.parse = function(t) {
        const r = this.parser(t);
        if (null === r) throw new Error("ipaddr: string is not formatted like an IPv4 Address");
        return new this(r);
    }, f.IPv4.parseCIDR = function(t) {
        let r;
        if (r = t.match(/^(.+)\/(\d+)$/)) {
            const t = parseInt(r[2]);
            if (t >= 0 && t <= 32) {
                const e = [
                    this.parse(r[1]),
                    t
                ];
                return Object.defineProperty(e, "toString", {
                    value: function() {
                        return this.join("/");
                    }
                }), e;
            }
        }
        throw new Error("ipaddr: string is not formatted like an IPv4 CIDR range");
    }, f.IPv4.parser = function(t) {
        let r, e, i;
        if (r = t.match(n.fourOctet)) return function() {
            const t = r.slice(1, 6), n = [];
            for(let r = 0; r < t.length; r++)e = t[r], n.push(c(e));
            return n;
        }();
        if (r = t.match(n.longValue)) {
            if (i = c(r[1]), i > 4294967295 || i < 0) throw new Error("ipaddr: address outside defined range");
            return (function() {
                const t = [];
                let r;
                for(r = 0; r <= 24; r += 8)t.push(i >> r & 255);
                return t;
            })().reverse();
        }
        return (r = t.match(n.twoOctet)) ? function() {
            const t = r.slice(1, 4), e = [];
            if (i = c(t[1]), i > 16777215 || i < 0) throw new Error("ipaddr: address outside defined range");
            return e.push(c(t[0])), e.push(i >> 16 & 255), e.push(i >> 8 & 255), e.push(255 & i), e;
        }() : (r = t.match(n.threeOctet)) ? function() {
            const t = r.slice(1, 5), e = [];
            if (i = c(t[2]), i > 65535 || i < 0) throw new Error("ipaddr: address outside defined range");
            return e.push(c(t[0])), e.push(c(t[1])), e.push(i >> 8 & 255), e.push(255 & i), e;
        }() : null;
    }, f.IPv4.subnetMaskFromPrefixLength = function(t) {
        if ((t = parseInt(t)) < 0 || t > 32) throw new Error("ipaddr: invalid IPv4 prefix length");
        const r = [
            0,
            0,
            0,
            0
        ];
        let e = 0;
        const n = Math.floor(t / 8);
        for(; e < n;)r[e] = 255, e++;
        return n < 4 && (r[n] = Math.pow(2, t % 8) - 1 << 8 - t % 8), new this(r);
    }, f.IPv6 = function() {
        function t(t, r) {
            let e, n;
            if (16 === t.length) for(this.parts = [], e = 0; e <= 14; e += 2)this.parts.push(t[e] << 8 | t[e + 1]);
            else {
                if (8 !== t.length) throw new Error("ipaddr: ipv6 part count should be 8 or 16");
                this.parts = t;
            }
            for(e = 0; e < this.parts.length; e++)if (n = this.parts[e], !(0 <= n && n <= 65535)) throw new Error("ipaddr: ipv6 part should fit in 16 bits");
            r && (this.zoneId = r);
        }
        return t.prototype.SpecialRanges = {
            unspecified: [
                new t([
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                128
            ],
            linkLocal: [
                new t([
                    65152,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                10
            ],
            multicast: [
                new t([
                    65280,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                8
            ],
            loopback: [
                new t([
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    1
                ]),
                128
            ],
            uniqueLocal: [
                new t([
                    64512,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                7
            ],
            ipv4Mapped: [
                new t([
                    0,
                    0,
                    0,
                    0,
                    0,
                    65535,
                    0,
                    0
                ]),
                96
            ],
            discard: [
                new t([
                    256,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                64
            ],
            rfc6145: [
                new t([
                    0,
                    0,
                    0,
                    0,
                    65535,
                    0,
                    0,
                    0
                ]),
                96
            ],
            rfc6052: [
                new t([
                    100,
                    65435,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                96
            ],
            "6to4": [
                new t([
                    8194,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                16
            ],
            teredo: [
                new t([
                    8193,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                32
            ],
            benchmarking: [
                new t([
                    8193,
                    2,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                48
            ],
            amt: [
                new t([
                    8193,
                    3,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                32
            ],
            as112v6: [
                [
                    new t([
                        8193,
                        4,
                        274,
                        0,
                        0,
                        0,
                        0,
                        0
                    ]),
                    48
                ],
                [
                    new t([
                        9760,
                        79,
                        32768,
                        0,
                        0,
                        0,
                        0,
                        0
                    ]),
                    48
                ]
            ],
            deprecated: [
                new t([
                    8193,
                    16,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                28
            ],
            orchid2: [
                new t([
                    8193,
                    32,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                28
            ],
            droneRemoteIdProtocolEntityTags: [
                new t([
                    8193,
                    48,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                28
            ],
            reserved: [
                [
                    new t([
                        8193,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ]),
                    23
                ],
                [
                    new t([
                        8193,
                        3512,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ]),
                    32
                ]
            ]
        }, t.prototype.isIPv4MappedAddress = function() {
            return "ipv4Mapped" === this.range();
        }, t.prototype.kind = function() {
            return "ipv6";
        }, t.prototype.match = function(t, r) {
            let e;
            if (void 0 === r && (e = t, t = e[0], r = e[1]), "ipv6" !== t.kind()) throw new Error("ipaddr: cannot match ipv6 address with non-ipv6 one");
            return d(this.parts, t.parts, 16, r);
        }, t.prototype.prefixLengthFromSubnetMask = function() {
            let t = 0, r = !1;
            const e = {
                0: 16,
                32768: 15,
                49152: 14,
                57344: 13,
                61440: 12,
                63488: 11,
                64512: 10,
                65024: 9,
                65280: 8,
                65408: 7,
                65472: 6,
                65504: 5,
                65520: 4,
                65528: 3,
                65532: 2,
                65534: 1,
                65535: 0
            };
            let n, i;
            for(let o = 7; o >= 0; o -= 1){
                if (n = this.parts[o], !(n in e)) return null;
                if (i = e[n], r && 0 !== i) return null;
                16 !== i && (r = !0), t += i;
            }
            return 128 - t;
        }, t.prototype.range = function() {
            return f.subnetMatch(this, this.SpecialRanges);
        }, t.prototype.toByteArray = function() {
            let t;
            const r = [], e = this.parts;
            for(let n = 0; n < e.length; n++)t = e[n], r.push(t >> 8), r.push(255 & t);
            return r;
        }, t.prototype.toFixedLengthString = function() {
            const t = (function() {
                const t = [];
                for(let r = 0; r < this.parts.length; r++)t.push(h(this.parts[r].toString(16), 4));
                return t;
            }).call(this).join(":");
            let r = "";
            return this.zoneId && (r = `%${this.zoneId}`), t + r;
        }, t.prototype.toIPv4Address = function() {
            if (!this.isIPv4MappedAddress()) throw new Error("ipaddr: trying to convert a generic ipv6 address to ipv4");
            const t = this.parts.slice(-2), r = t[0], e = t[1];
            return new f.IPv4([
                r >> 8,
                255 & r,
                e >> 8,
                255 & e
            ]);
        }, t.prototype.toNormalizedString = function() {
            const t = (function() {
                const t = [];
                for(let r = 0; r < this.parts.length; r++)t.push(this.parts[r].toString(16));
                return t;
            }).call(this).join(":");
            let r = "";
            return this.zoneId && (r = `%${this.zoneId}`), t + r;
        }, t.prototype.toRFC5952String = function() {
            const t = /((^|:)(0(:|$)){2,})/g, r = this.toNormalizedString();
            let e, n = 0, i = -1;
            for(; e = t.exec(r);)e[0].length > i && (n = e.index, i = e[0].length);
            return i < 0 ? r : `${r.substring(0, n)}::${r.substring(n + i)}`;
        }, t.prototype.toString = function() {
            return this.toRFC5952String();
        }, t;
    }(), f.IPv6.broadcastAddressFromCIDR = function(t) {
        try {
            const r = this.parseCIDR(t), e = r[0].toByteArray(), n = this.subnetMaskFromPrefixLength(r[1]).toByteArray(), i = [];
            let o = 0;
            for(; o < 16;)i.push(parseInt(e[o], 10) | 255 ^ parseInt(n[o], 10)), o++;
            return new this(i);
        } catch (t) {
            throw new Error(`ipaddr: the address does not have IPv6 CIDR format (${t})`);
        }
    }, f.IPv6.isIPv6 = function(t) {
        return null !== this.parser(t);
    }, f.IPv6.isValid = function(t) {
        if ("string" == typeof t && -1 === t.indexOf(":")) return !1;
        try {
            const r = this.parser(t);
            return new this(r.parts, r.zoneId), !0;
        } catch (t) {
            return !1;
        }
    }, f.IPv6.isValidCIDR = function(t) {
        if ("string" == typeof t && -1 === t.indexOf(":")) return !1;
        try {
            return this.parseCIDR(t), !0;
        } catch (t) {
            return !1;
        }
    }, f.IPv6.networkAddressFromCIDR = function(t) {
        let r, e, n, i, o;
        try {
            for(r = this.parseCIDR(t), n = r[0].toByteArray(), o = this.subnetMaskFromPrefixLength(r[1]).toByteArray(), i = [], e = 0; e < 16;)i.push(parseInt(n[e], 10) & parseInt(o[e], 10)), e++;
            return new this(i);
        } catch (t) {
            throw new Error(`ipaddr: the address does not have IPv6 CIDR format (${t})`);
        }
    }, f.IPv6.parse = function(t) {
        const r = this.parser(t);
        if (null === r.parts) throw new Error("ipaddr: string is not formatted like an IPv6 Address");
        return new this(r.parts, r.zoneId);
    }, f.IPv6.parseCIDR = function(t) {
        let r, e, n;
        if ((e = t.match(/^(.+)\/(\d+)$/)) && (r = parseInt(e[2]), r >= 0 && r <= 128)) return n = [
            this.parse(e[1]),
            r
        ], Object.defineProperty(n, "toString", {
            value: function() {
                return this.join("/");
            }
        }), n;
        throw new Error("ipaddr: string is not formatted like an IPv6 CIDR range");
    }, f.IPv6.parser = function(t) {
        let r, e, n, i, o, s;
        if (n = t.match(p.deprecatedTransitional)) return this.parser(`::ffff:${n[1]}`);
        if (p.native.test(t)) return u(t, 8);
        if ((n = t.match(p.transitional)) && (s = n[6] || "", r = n[1], n[1].endsWith("::") || (r = r.slice(0, -1)), r = u(r + s, 6), r.parts)) {
            for(o = [
                parseInt(n[2]),
                parseInt(n[3]),
                parseInt(n[4]),
                parseInt(n[5])
            ], e = 0; e < o.length; e++)if (i = o[e], !(0 <= i && i <= 255)) return null;
            return r.parts.push(o[0] << 8 | o[1]), r.parts.push(o[2] << 8 | o[3]), {
                parts: r.parts,
                zoneId: r.zoneId
            };
        }
        return null;
    }, f.IPv6.subnetMaskFromPrefixLength = function(t) {
        if ((t = parseInt(t)) < 0 || t > 128) throw new Error("ipaddr: invalid IPv6 prefix length");
        const r = [
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        ];
        let e = 0;
        const n = Math.floor(t / 8);
        for(; e < n;)r[e] = 255, e++;
        return n < 16 && (r[n] = Math.pow(2, t % 8) - 1 << 8 - t % 8), new this(r);
    }, f.fromByteArray = function(t) {
        const r = t.length;
        if (4 === r) return new f.IPv4(t);
        if (16 === r) return new f.IPv6(t);
        throw new Error("ipaddr: the binary input is neither an IPv6 nor IPv4 address");
    }, f.isValid = function(t) {
        return f.IPv6.isValid(t) || f.IPv4.isValid(t);
    }, f.isValidCIDR = function(t) {
        return f.IPv6.isValidCIDR(t) || f.IPv4.isValidCIDR(t);
    }, f.parse = function(t) {
        if (f.IPv6.isValid(t)) return f.IPv6.parse(t);
        if (f.IPv4.isValid(t)) return f.IPv4.parse(t);
        throw new Error("ipaddr: the address has neither IPv6 nor IPv4 format");
    }, f.parseCIDR = function(t) {
        try {
            return f.IPv6.parseCIDR(t);
        } catch (r) {
            try {
                return f.IPv4.parseCIDR(t);
            } catch (t) {
                throw new Error("ipaddr: the address has neither IPv6 nor IPv4 CIDR format");
            }
        }
    }, f.process = function(t) {
        const r = this.parse(t);
        return "ipv6" === r.kind() && r.isIPv4MappedAddress() ? r.toIPv4Address() : r;
    }, f.subnetMatch = function(t, r, e) {
        let n, i, o, s;
        for(i in null == e && (e = "unicast"), r)if (Object.prototype.hasOwnProperty.call(r, i)) {
            for(o = r[i], !o[0] || o[0] instanceof Array || (o = [
                o
            ]), n = 0; n < o.length; n++)if (s = o[n], t.kind() === s[0].kind() && t.match.apply(t, s)) return i;
        }
        return e;
    }, t.exports ? t.exports = f : r.ipaddr = f;
}(r.commonjsGlobal);
var n = e.__module.exports;
exports.ipaddrExports = n; //# sourceMappingURL=ipaddr.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/ipaddr.js/lib/ipaddr.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "i": (()=>n)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$_commonjsHelpers$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/_commonjsHelpers.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$ipaddr$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/ipaddr.mjs [app-route] (ecmascript)");
;
;
var e;
e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$ipaddr$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__module"], function(t) {
    const r = "(0?\\d+|0x[a-f0-9]+)", n = {
        fourOctet: new RegExp(`^${r}\\.${r}\\.${r}\\.${r}$`, "i"),
        threeOctet: new RegExp(`^${r}\\.${r}\\.${r}$`, "i"),
        twoOctet: new RegExp(`^${r}\\.${r}$`, "i"),
        longValue: new RegExp(`^${r}$`, "i")
    }, i = new RegExp("^0[0-7]+$", "i"), o = new RegExp("^0x[a-f0-9]+$", "i"), s = "%[0-9a-z]{1,}", a = "(?:[0-9a-f]+::?)+", p = {
        zoneIndex: new RegExp(s, "i"),
        native: new RegExp(`^(::)?(${a})?([0-9a-f]+)?(::)?(${s})?$`, "i"),
        deprecatedTransitional: new RegExp(`^(?:::)(${r}\\.${r}\\.${r}\\.${r}(${s})?)$`, "i"),
        transitional: new RegExp(`^((?:${a})|(?:::)(?:${a})?)${r}\\.${r}\\.${r}\\.${r}(${s})?$`, "i")
    };
    function u(t, r) {
        if (t.indexOf("::") !== t.lastIndexOf("::")) return null;
        let e, n, i = 0, o = -1, s = (t.match(p.zoneIndex) || [])[0];
        for(s && (s = s.substring(1), t = t.replace(/%.+$/, "")); (o = t.indexOf(":", o + 1)) >= 0;)i++;
        if ("::" === t.substr(0, 2) && i--, "::" === t.substr(-2, 2) && i--, i > r) return null;
        for(n = r - i, e = ":"; n--;)e += "0:";
        return ":" === (t = t.replace("::", e))[0] && (t = t.slice(1)), ":" === t[t.length - 1] && (t = t.slice(0, -1)), {
            parts: r = function() {
                const r = t.split(":"), e = [];
                for(let t = 0; t < r.length; t++)e.push(parseInt(r[t], 16));
                return e;
            }(),
            zoneId: s
        };
    }
    function d(t, r, e, n) {
        if (t.length !== r.length) throw new Error("ipaddr: cannot match CIDR for objects with different lengths");
        let i, o = 0;
        for(; n > 0;){
            if (i = e - n, i < 0 && (i = 0), t[o] >> i != r[o] >> i) return !1;
            n -= e, o += 1;
        }
        return !0;
    }
    function h(t) {
        if (o.test(t)) return parseInt(t, 16);
        if ("0" === t[0] && !isNaN(parseInt(t[1], 10))) {
            if (i.test(t)) return parseInt(t, 8);
            throw new Error(`ipaddr: cannot parse ${t} as octal`);
        }
        return parseInt(t, 10);
    }
    function c(t, r) {
        for(; t.length < r;)t = `0${t}`;
        return t;
    }
    const f = {};
    f.IPv4 = function() {
        function t(t) {
            if (4 !== t.length) throw new Error("ipaddr: ipv4 octet count should be 4");
            let r, e;
            for(r = 0; r < t.length; r++)if (e = t[r], !(0 <= e && e <= 255)) throw new Error("ipaddr: ipv4 octet should fit in 8 bits");
            this.octets = t;
        }
        return t.prototype.SpecialRanges = {
            unspecified: [
                [
                    new t([
                        0,
                        0,
                        0,
                        0
                    ]),
                    8
                ]
            ],
            broadcast: [
                [
                    new t([
                        255,
                        255,
                        255,
                        255
                    ]),
                    32
                ]
            ],
            multicast: [
                [
                    new t([
                        224,
                        0,
                        0,
                        0
                    ]),
                    4
                ]
            ],
            linkLocal: [
                [
                    new t([
                        169,
                        254,
                        0,
                        0
                    ]),
                    16
                ]
            ],
            loopback: [
                [
                    new t([
                        127,
                        0,
                        0,
                        0
                    ]),
                    8
                ]
            ],
            carrierGradeNat: [
                [
                    new t([
                        100,
                        64,
                        0,
                        0
                    ]),
                    10
                ]
            ],
            private: [
                [
                    new t([
                        10,
                        0,
                        0,
                        0
                    ]),
                    8
                ],
                [
                    new t([
                        172,
                        16,
                        0,
                        0
                    ]),
                    12
                ],
                [
                    new t([
                        192,
                        168,
                        0,
                        0
                    ]),
                    16
                ]
            ],
            reserved: [
                [
                    new t([
                        192,
                        0,
                        0,
                        0
                    ]),
                    24
                ],
                [
                    new t([
                        192,
                        0,
                        2,
                        0
                    ]),
                    24
                ],
                [
                    new t([
                        192,
                        88,
                        99,
                        0
                    ]),
                    24
                ],
                [
                    new t([
                        198,
                        18,
                        0,
                        0
                    ]),
                    15
                ],
                [
                    new t([
                        198,
                        51,
                        100,
                        0
                    ]),
                    24
                ],
                [
                    new t([
                        203,
                        0,
                        113,
                        0
                    ]),
                    24
                ],
                [
                    new t([
                        240,
                        0,
                        0,
                        0
                    ]),
                    4
                ]
            ],
            as112: [
                [
                    new t([
                        192,
                        175,
                        48,
                        0
                    ]),
                    24
                ],
                [
                    new t([
                        192,
                        31,
                        196,
                        0
                    ]),
                    24
                ]
            ],
            amt: [
                [
                    new t([
                        192,
                        52,
                        193,
                        0
                    ]),
                    24
                ]
            ]
        }, t.prototype.kind = function() {
            return "ipv4";
        }, t.prototype.match = function(t, r) {
            let e;
            if (void 0 === r && (e = t, t = e[0], r = e[1]), "ipv4" !== t.kind()) throw new Error("ipaddr: cannot match ipv4 address with non-ipv4 one");
            return d(this.octets, t.octets, 8, r);
        }, t.prototype.prefixLengthFromSubnetMask = function() {
            let t = 0, r = !1;
            const e = {
                0: 8,
                128: 7,
                192: 6,
                224: 5,
                240: 4,
                248: 3,
                252: 2,
                254: 1,
                255: 0
            };
            let n, i, o;
            for(n = 3; n >= 0; n -= 1){
                if (i = this.octets[n], !(i in e)) return null;
                if (o = e[i], r && 0 !== o) return null;
                8 !== o && (r = !0), t += o;
            }
            return 32 - t;
        }, t.prototype.range = function() {
            return f.subnetMatch(this, this.SpecialRanges);
        }, t.prototype.toByteArray = function() {
            return this.octets.slice(0);
        }, t.prototype.toIPv4MappedAddress = function() {
            return f.IPv6.parse(`::ffff:${this.toString()}`);
        }, t.prototype.toNormalizedString = function() {
            return this.toString();
        }, t.prototype.toString = function() {
            return this.octets.join(".");
        }, t;
    }(), f.IPv4.broadcastAddressFromCIDR = function(t) {
        try {
            const r = this.parseCIDR(t), e = r[0].toByteArray(), n = this.subnetMaskFromPrefixLength(r[1]).toByteArray(), i = [];
            let o = 0;
            for(; o < 4;)i.push(parseInt(e[o], 10) | 255 ^ parseInt(n[o], 10)), o++;
            return new this(i);
        } catch (t) {
            throw new Error("ipaddr: the address does not have IPv4 CIDR format");
        }
    }, f.IPv4.isIPv4 = function(t) {
        return null !== this.parser(t);
    }, f.IPv4.isValid = function(t) {
        try {
            return new this(this.parser(t)), !0;
        } catch (t) {
            return !1;
        }
    }, f.IPv4.isValidCIDR = function(t) {
        try {
            return this.parseCIDR(t), !0;
        } catch (t) {
            return !1;
        }
    }, f.IPv4.isValidFourPartDecimal = function(t) {
        return !(!f.IPv4.isValid(t) || !t.match(/^(0|[1-9]\d*)(\.(0|[1-9]\d*)){3}$/));
    }, f.IPv4.networkAddressFromCIDR = function(t) {
        let r, e, n, i, o;
        try {
            for(r = this.parseCIDR(t), n = r[0].toByteArray(), o = this.subnetMaskFromPrefixLength(r[1]).toByteArray(), i = [], e = 0; e < 4;)i.push(parseInt(n[e], 10) & parseInt(o[e], 10)), e++;
            return new this(i);
        } catch (t) {
            throw new Error("ipaddr: the address does not have IPv4 CIDR format");
        }
    }, f.IPv4.parse = function(t) {
        const r = this.parser(t);
        if (null === r) throw new Error("ipaddr: string is not formatted like an IPv4 Address");
        return new this(r);
    }, f.IPv4.parseCIDR = function(t) {
        let r;
        if (r = t.match(/^(.+)\/(\d+)$/)) {
            const t = parseInt(r[2]);
            if (t >= 0 && t <= 32) {
                const e = [
                    this.parse(r[1]),
                    t
                ];
                return Object.defineProperty(e, "toString", {
                    value: function() {
                        return this.join("/");
                    }
                }), e;
            }
        }
        throw new Error("ipaddr: string is not formatted like an IPv4 CIDR range");
    }, f.IPv4.parser = function(t) {
        let r, e, i;
        if (r = t.match(n.fourOctet)) return function() {
            const t = r.slice(1, 6), n = [];
            for(let r = 0; r < t.length; r++)e = t[r], n.push(h(e));
            return n;
        }();
        if (r = t.match(n.longValue)) {
            if (i = h(r[1]), i > 4294967295 || i < 0) throw new Error("ipaddr: address outside defined range");
            return (function() {
                const t = [];
                let r;
                for(r = 0; r <= 24; r += 8)t.push(i >> r & 255);
                return t;
            })().reverse();
        }
        return (r = t.match(n.twoOctet)) ? function() {
            const t = r.slice(1, 4), e = [];
            if (i = h(t[1]), i > 16777215 || i < 0) throw new Error("ipaddr: address outside defined range");
            return e.push(h(t[0])), e.push(i >> 16 & 255), e.push(i >> 8 & 255), e.push(255 & i), e;
        }() : (r = t.match(n.threeOctet)) ? function() {
            const t = r.slice(1, 5), e = [];
            if (i = h(t[2]), i > 65535 || i < 0) throw new Error("ipaddr: address outside defined range");
            return e.push(h(t[0])), e.push(h(t[1])), e.push(i >> 8 & 255), e.push(255 & i), e;
        }() : null;
    }, f.IPv4.subnetMaskFromPrefixLength = function(t) {
        if ((t = parseInt(t)) < 0 || t > 32) throw new Error("ipaddr: invalid IPv4 prefix length");
        const r = [
            0,
            0,
            0,
            0
        ];
        let e = 0;
        const n = Math.floor(t / 8);
        for(; e < n;)r[e] = 255, e++;
        return n < 4 && (r[n] = Math.pow(2, t % 8) - 1 << 8 - t % 8), new this(r);
    }, f.IPv6 = function() {
        function t(t, r) {
            let e, n;
            if (16 === t.length) for(this.parts = [], e = 0; e <= 14; e += 2)this.parts.push(t[e] << 8 | t[e + 1]);
            else {
                if (8 !== t.length) throw new Error("ipaddr: ipv6 part count should be 8 or 16");
                this.parts = t;
            }
            for(e = 0; e < this.parts.length; e++)if (n = this.parts[e], !(0 <= n && n <= 65535)) throw new Error("ipaddr: ipv6 part should fit in 16 bits");
            r && (this.zoneId = r);
        }
        return t.prototype.SpecialRanges = {
            unspecified: [
                new t([
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                128
            ],
            linkLocal: [
                new t([
                    65152,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                10
            ],
            multicast: [
                new t([
                    65280,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                8
            ],
            loopback: [
                new t([
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    1
                ]),
                128
            ],
            uniqueLocal: [
                new t([
                    64512,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                7
            ],
            ipv4Mapped: [
                new t([
                    0,
                    0,
                    0,
                    0,
                    0,
                    65535,
                    0,
                    0
                ]),
                96
            ],
            discard: [
                new t([
                    256,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                64
            ],
            rfc6145: [
                new t([
                    0,
                    0,
                    0,
                    0,
                    65535,
                    0,
                    0,
                    0
                ]),
                96
            ],
            rfc6052: [
                new t([
                    100,
                    65435,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                96
            ],
            "6to4": [
                new t([
                    8194,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                16
            ],
            teredo: [
                new t([
                    8193,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                32
            ],
            benchmarking: [
                new t([
                    8193,
                    2,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                48
            ],
            amt: [
                new t([
                    8193,
                    3,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                32
            ],
            as112v6: [
                [
                    new t([
                        8193,
                        4,
                        274,
                        0,
                        0,
                        0,
                        0,
                        0
                    ]),
                    48
                ],
                [
                    new t([
                        9760,
                        79,
                        32768,
                        0,
                        0,
                        0,
                        0,
                        0
                    ]),
                    48
                ]
            ],
            deprecated: [
                new t([
                    8193,
                    16,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                28
            ],
            orchid2: [
                new t([
                    8193,
                    32,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                28
            ],
            droneRemoteIdProtocolEntityTags: [
                new t([
                    8193,
                    48,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                ]),
                28
            ],
            reserved: [
                [
                    new t([
                        8193,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ]),
                    23
                ],
                [
                    new t([
                        8193,
                        3512,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ]),
                    32
                ]
            ]
        }, t.prototype.isIPv4MappedAddress = function() {
            return "ipv4Mapped" === this.range();
        }, t.prototype.kind = function() {
            return "ipv6";
        }, t.prototype.match = function(t, r) {
            let e;
            if (void 0 === r && (e = t, t = e[0], r = e[1]), "ipv6" !== t.kind()) throw new Error("ipaddr: cannot match ipv6 address with non-ipv6 one");
            return d(this.parts, t.parts, 16, r);
        }, t.prototype.prefixLengthFromSubnetMask = function() {
            let t = 0, r = !1;
            const e = {
                0: 16,
                32768: 15,
                49152: 14,
                57344: 13,
                61440: 12,
                63488: 11,
                64512: 10,
                65024: 9,
                65280: 8,
                65408: 7,
                65472: 6,
                65504: 5,
                65520: 4,
                65528: 3,
                65532: 2,
                65534: 1,
                65535: 0
            };
            let n, i;
            for(let o = 7; o >= 0; o -= 1){
                if (n = this.parts[o], !(n in e)) return null;
                if (i = e[n], r && 0 !== i) return null;
                16 !== i && (r = !0), t += i;
            }
            return 128 - t;
        }, t.prototype.range = function() {
            return f.subnetMatch(this, this.SpecialRanges);
        }, t.prototype.toByteArray = function() {
            let t;
            const r = [], e = this.parts;
            for(let n = 0; n < e.length; n++)t = e[n], r.push(t >> 8), r.push(255 & t);
            return r;
        }, t.prototype.toFixedLengthString = function() {
            const t = (function() {
                const t = [];
                for(let r = 0; r < this.parts.length; r++)t.push(c(this.parts[r].toString(16), 4));
                return t;
            }).call(this).join(":");
            let r = "";
            return this.zoneId && (r = `%${this.zoneId}`), t + r;
        }, t.prototype.toIPv4Address = function() {
            if (!this.isIPv4MappedAddress()) throw new Error("ipaddr: trying to convert a generic ipv6 address to ipv4");
            const t = this.parts.slice(-2), r = t[0], e = t[1];
            return new f.IPv4([
                r >> 8,
                255 & r,
                e >> 8,
                255 & e
            ]);
        }, t.prototype.toNormalizedString = function() {
            const t = (function() {
                const t = [];
                for(let r = 0; r < this.parts.length; r++)t.push(this.parts[r].toString(16));
                return t;
            }).call(this).join(":");
            let r = "";
            return this.zoneId && (r = `%${this.zoneId}`), t + r;
        }, t.prototype.toRFC5952String = function() {
            const t = /((^|:)(0(:|$)){2,})/g, r = this.toNormalizedString();
            let e, n = 0, i = -1;
            for(; e = t.exec(r);)e[0].length > i && (n = e.index, i = e[0].length);
            return i < 0 ? r : `${r.substring(0, n)}::${r.substring(n + i)}`;
        }, t.prototype.toString = function() {
            return this.toRFC5952String();
        }, t;
    }(), f.IPv6.broadcastAddressFromCIDR = function(t) {
        try {
            const r = this.parseCIDR(t), e = r[0].toByteArray(), n = this.subnetMaskFromPrefixLength(r[1]).toByteArray(), i = [];
            let o = 0;
            for(; o < 16;)i.push(parseInt(e[o], 10) | 255 ^ parseInt(n[o], 10)), o++;
            return new this(i);
        } catch (t) {
            throw new Error(`ipaddr: the address does not have IPv6 CIDR format (${t})`);
        }
    }, f.IPv6.isIPv6 = function(t) {
        return null !== this.parser(t);
    }, f.IPv6.isValid = function(t) {
        if ("string" == typeof t && -1 === t.indexOf(":")) return !1;
        try {
            const r = this.parser(t);
            return new this(r.parts, r.zoneId), !0;
        } catch (t) {
            return !1;
        }
    }, f.IPv6.isValidCIDR = function(t) {
        if ("string" == typeof t && -1 === t.indexOf(":")) return !1;
        try {
            return this.parseCIDR(t), !0;
        } catch (t) {
            return !1;
        }
    }, f.IPv6.networkAddressFromCIDR = function(t) {
        let r, e, n, i, o;
        try {
            for(r = this.parseCIDR(t), n = r[0].toByteArray(), o = this.subnetMaskFromPrefixLength(r[1]).toByteArray(), i = [], e = 0; e < 16;)i.push(parseInt(n[e], 10) & parseInt(o[e], 10)), e++;
            return new this(i);
        } catch (t) {
            throw new Error(`ipaddr: the address does not have IPv6 CIDR format (${t})`);
        }
    }, f.IPv6.parse = function(t) {
        const r = this.parser(t);
        if (null === r.parts) throw new Error("ipaddr: string is not formatted like an IPv6 Address");
        return new this(r.parts, r.zoneId);
    }, f.IPv6.parseCIDR = function(t) {
        let r, e, n;
        if ((e = t.match(/^(.+)\/(\d+)$/)) && (r = parseInt(e[2]), r >= 0 && r <= 128)) return n = [
            this.parse(e[1]),
            r
        ], Object.defineProperty(n, "toString", {
            value: function() {
                return this.join("/");
            }
        }), n;
        throw new Error("ipaddr: string is not formatted like an IPv6 CIDR range");
    }, f.IPv6.parser = function(t) {
        let r, e, n, i, o, s;
        if (n = t.match(p.deprecatedTransitional)) return this.parser(`::ffff:${n[1]}`);
        if (p.native.test(t)) return u(t, 8);
        if ((n = t.match(p.transitional)) && (s = n[6] || "", r = n[1], n[1].endsWith("::") || (r = r.slice(0, -1)), r = u(r + s, 6), r.parts)) {
            for(o = [
                parseInt(n[2]),
                parseInt(n[3]),
                parseInt(n[4]),
                parseInt(n[5])
            ], e = 0; e < o.length; e++)if (i = o[e], !(0 <= i && i <= 255)) return null;
            return r.parts.push(o[0] << 8 | o[1]), r.parts.push(o[2] << 8 | o[3]), {
                parts: r.parts,
                zoneId: r.zoneId
            };
        }
        return null;
    }, f.IPv6.subnetMaskFromPrefixLength = function(t) {
        if ((t = parseInt(t)) < 0 || t > 128) throw new Error("ipaddr: invalid IPv6 prefix length");
        const r = [
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
        ];
        let e = 0;
        const n = Math.floor(t / 8);
        for(; e < n;)r[e] = 255, e++;
        return n < 16 && (r[n] = Math.pow(2, t % 8) - 1 << 8 - t % 8), new this(r);
    }, f.fromByteArray = function(t) {
        const r = t.length;
        if (4 === r) return new f.IPv4(t);
        if (16 === r) return new f.IPv6(t);
        throw new Error("ipaddr: the binary input is neither an IPv6 nor IPv4 address");
    }, f.isValid = function(t) {
        return f.IPv6.isValid(t) || f.IPv4.isValid(t);
    }, f.isValidCIDR = function(t) {
        return f.IPv6.isValidCIDR(t) || f.IPv4.isValidCIDR(t);
    }, f.parse = function(t) {
        if (f.IPv6.isValid(t)) return f.IPv6.parse(t);
        if (f.IPv4.isValid(t)) return f.IPv4.parse(t);
        throw new Error("ipaddr: the address has neither IPv6 nor IPv4 format");
    }, f.parseCIDR = function(t) {
        try {
            return f.IPv6.parseCIDR(t);
        } catch (r) {
            try {
                return f.IPv4.parseCIDR(t);
            } catch (t) {
                throw new Error("ipaddr: the address has neither IPv6 nor IPv4 CIDR format");
            }
        }
    }, f.process = function(t) {
        const r = this.parse(t);
        return "ipv6" === r.kind() && r.isIPv4MappedAddress() ? r.toIPv4Address() : r;
    }, f.subnetMatch = function(t, r, e) {
        let n, i, o, s;
        for(i in null == e && (e = "unicast"), r)if (Object.prototype.hasOwnProperty.call(r, i)) {
            for(o = r[i], !o[0] || o[0] instanceof Array || (o = [
                o
            ]), n = 0; n < o.length; n++)if (s = o[n], t.kind() === s[0].kind() && t.match.apply(t, s)) return i;
        }
        return e;
    }, e.exports ? e.exports = f : t.ipaddr = f;
}(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$_commonjsHelpers$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["commonjsGlobal"]);
var n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$ipaddr$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__module"].exports;
;
 //# sourceMappingURL=ipaddr.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/graphemesplit/typeTrie.json.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: !0
});
var v = "ABAOAAAAAACwiAAAAYkHdvjtnH+IFkUYxx/v3vPe7uw8UkjsD43ChKICDQsT3iIJy4gSiZAjkn5JUFlaiFmjccT9ESkpGBGVIlQgWSkY/QDBoMgrQv0jRJDAfkCXhUmgRX23d4ebnndmd3Z3ZnfVeeDDzM7MPs8zv57Zd2+5hd1Ed4ClYAisBuuUsqLpMHgJjIBNFu1fBW8l1O8AO8Ee8Cn4HIyCg+CI0u4Y+AmMgVPgDOhuEHWBPjAZXAy2gjfA9kb73hlx+i7SK8AHYDf4BOwHB8AoOAyOguPgB/ArOKlcnwHdPe32/Uin9LTvvwTph0gv62nbubKnXT+nZ1z/DcjfFF8vQno7uEaxH923BGVXN9v5Zcgvj/VFPIT8Y/H1k0jXxPn1SEfARjBdab8V+TfB22CXUh5xd3OcZTH3g6di1LZJbLNs55q96M9n4J9Gm6hsfzQvcT8fbfy//TyUf8vG4Lses/5jcd2PSE/IcQan4/o/UXYadE0kaoJBMG1ivNbidNbETr1XoWyuplwyHFN0fFai/8/EY7BIKY/68EpCvwP+mc/m/2vNGnBhp1eZ51bCmgsEAoFAIBAIBAKBQKAO3Irfrg3lfc4qi/cXd+Kee5TfvAd6ieY0ie5D2cNx+eNInwZLmu33gWuRn4/8C3H9CNJNYEt8/TrS35HuSPktvRP1z0LPOvAceB4IsB5saIa6UBfqQl2oc123AjwBVjWrP7MCgcC5y/ue/56yqXv87+qcIU2Z+ny8tuHHpyxsvrDNITDXgqkDRJcPdJY/wMo24/oQmDqZaPHkdplAuhv8ApqDRDeCVj/OAvD9BUSX9qF8Qpt7lTxnZ7+5TmVtrGMM7XchP3sS0SNgGzg4yU5HIBAIBM5NfsO5QDgfjuM54STOw7/Az/F3QtfhfF4Qn9F/gxMouxm/WU7F9afBQuUM7+rtPF+jb0b6ese/I7sI+emadhEzUT5bqbsW+esNbSMWoG6hWo/8gOLPUqUu+v5rKEHX8oS6iEXQexd7XlmBe1aCNWAp6kSsYyjHc82Liv2Xkd/C/HkN1w/Geren+KryToa2PtlQg2c9zijGZnGJ9kaibzZh84jmmfx4TeYpK9H3usMKqxnDCWxsdLY/3ygy9h+l/LYbYHtuXw2/rfsSPo0a/Jrn6PvPrzL2+7CmfV88lkc9j+F7cRzYU4N48DF8uA3n/T7Fly9q4Jdvoth0uLf9LORC11hvO/0D6RnQfRa99+2Hr1NS/M26VvfEe2jaWTAOvG8zzgKf8zCrYL++qUEfbumeQAjTVnQp+QmW99gQpDoJ4+9uHZe5/l3OW/M8x6WUZaduUvUc5p13NTXlz3VpGbCVrGNe5zOnjvGlrDWY1IdWShuuQ9fWh6h+VSV1Wit1lvNhHFz1zeUYtCg5ntvOSStDW5cITRnF5RJ+rcasJHExztwu910tl6LzLYsvuvvzilB0mvSaxt/V+SY0EMurfkjbrTjfInf+FJGkNdzSlOukZaDo3snqs7RZpqj2Gx7sS52D5O79k+93W2W/T3NhQxe3VeF16pwn4eI8qev7Sl1s0PnPy5PalSV57Pp6XuDxrypR9wBR8nOCzm/eXuYp5d4s/lV1XvL+lG2b+2AaQ1nPr23Hrc7z0WT5qvZL0v7QtdX5zdu6HMei+gV1ri8et4XSVpCfdeB7fRWNRy79UP0RCT4Jyre/88bbKsQUawUrV69dxjd+nlXxbCKos79pz1BpOqucz0gEdZ5hMk+aa7Wdy/7xZ5Yqhc+nyHivrkyQ/reM7tziuFojfM7zxtq0505XYutvHrtVnzNl2ONrTGdPkLv9ZjNHOoShnCh5nLLYKOKfK4qK7bjx/gqyj9lFJc2Wz/HIqyMSYaGnqM8+xp6vB1/6feg22UmLFUno1rurvelz7yT1UVfORW3L7+d6fMcAXdzxIVK3TNNioZpSyj2242izpky6y5S0fpr6q5ZXJT7O1qrmQRVB+rkQ1Dk3vvYttyGoc+51/mUVkYLtXvTx7MCvbUnzW2czyR8pql4XUlbcN9l1pSfPfOl0JV2bylyKoM4959sHQfr9Vpbk2V8u4ry0ndcvH5I1xggP9qVem/PHZL+qeGLrc945tLnHtG/LEtdjr4urxMpM92X1RZDd+pLtsorUydeCaiuvbtdSpQ9l2M4SU01nvI1e35L3uS5Jlw8pe1ykCKo2JtrGK9O9ujOlimcD6Y9LEWQ+7019d2VDLVPrTCLrsvjsQ1TfJVJM12pZmm5b4Xptx6HM9SpFkP2c6drJa5/iSr+pD7r+CNLvATVfpST1RYog/fwKTdsyxLVNQfnWrkyziGltJK2hLLptzjHXIsh+/HytmyQfpPA5VNtzXWWLzbiVsc9sbWSJ7UWE69KNh6v9kya2c6TzMa0fwpD37TtvQ6wuiw9CA9cny33Mj2pLte9Kp6996HO/83HPQ5r+ov5mvU9Qte/fIrGJP7axPO/9eXX6kjLPKZNd17iyZdOHLP31JSbfXY6hC59c+ZZ136TZ9SFlj6cvmVkSrkSQn3NG5KBqEVSeH6Ji/vvnhFWjSlfFNDwzyMgqLvvKxXffbeASBWo+Zj4p2x6TfwE=", e = {
    data: v
};
exports.data = v, exports.default = e; //# sourceMappingURL=typeTrie.json.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/graphemesplit/extPict.json.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: !0
});
var d = "AAACAAAAAACAOAAAAbYBSf7t2S1IBEEYBuDVDZ7FYrQMNsFiu3hgEYOI0SCXRIUrB8JhEZtgs5gEg1GMFk02m82oGI02m+9xezCOczv/uwv3fvAwc/PzfXOzcdqzWdaBDdiGPdiHdjE+DS3RNDuCfsn8idQ/g3OH3BdwKf0e96/gumTfYcncLdzBPTzAo+RZ+f0Cr/AG7/AJX4738x1wtz9FO5PX/50n6UXMNdfg/0lERERERERERERERETpdedHBvDRql4nq0cXtW9af98qdRby0Vvp8K4W0V+C5Xw0t4J2bfjeBp3cnEu1brnnCTYNa7eKdz91XP7WO9Lb4GqRb7cY6xbtAdqeVOsY/QGcevw/tb6OT85YhvfKYEx9CMuxKsKnrs+eJtVInVvHJ0eVYVvTZk2siFVLOCjb61PTZX3MdVWEyP7fjzpmMxdzTyq2Ebue6x61nXRGnzndWpf1an7dXmGYE4Y1ptqqKsK1nu26Ju0ty+maV2Rpvk+qnDZjKUIobUiesdAQE/jmCTmHmsskpFZsVYbtmXRcaoSGUPomunW2derQhDPFjtT1Q/eb8vnm990fq35oHVt11bU9m89c7DNI8Qs=", e = {
    data: d
};
exports.data = d, exports.default = e; //# sourceMappingURL=extPict.json.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/graphemesplit/types.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
exports.types = {
    Other: 0,
    CR: 1,
    LF: 2,
    Control: 4,
    Extend: 8,
    ZWJ: 16,
    Regional_Indicator: 32,
    Prepend: 64,
    SpacingMark: 128,
    L: 256,
    V: 512,
    T: 1024,
    LV: 2048,
    LVT: 4096,
    Extended_Pictographic: 8192
}; //# sourceMappingURL=types.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/graphemesplit/index.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: !0
});
var e = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/_virtual/_commonjsHelpers.cjs [app-route] (ecmascript)"), t = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/graphemesplit/typeTrie.json.cjs [app-route] (ecmascript)"), r = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/graphemesplit/extPict.json.cjs [app-route] (ecmascript)"), n = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/unicode-trie/index.cjs [app-route] (ecmascript)"), o = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/js-base64/base64.cjs [app-route] (ecmascript)");
const i = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/graphemesplit/types.cjs [app-route] (ecmascript)").types, s = t.default.data, c = r.default.data, a = n.unicodeTrie, u = o.base64Exports.Base64, d = new a(u.toUint8Array(s)), l = new a(u.toUint8Array(c));
function f(e, t) {
    return 0 != (e & t);
}
const p = 0, g = 1, j = 2;
function x(e, t) {
    const r = e.length;
    let n = 0, o = p;
    for(let s = t; s + 1 < r; s++){
        const r = e[s + 0], c = e[s + 1];
        switch(f(r, i.Regional_Indicator) || (n = 0), o){
            case j:
            case p:
                o = f(r, i.Extended_Pictographic) ? g : p;
                break;
            case g:
                o = f(r, i.Extend) ? g : f(r, i.ZWJ) && f(c, i.Extended_Pictographic) ? j : p;
        }
        if (!f(r, i.CR) || !f(c, i.LF)) {
            if (f(r, i.Control | i.CR | i.LF)) return s + 1 - t;
            if (f(c, i.Control | i.CR | i.LF)) return s + 1 - t;
            if (!(f(r, i.L) && f(c, i.L | i.V | i.LV | i.LVT) || f(r, i.LV | i.V) && f(c, i.V | i.T) || f(r, i.LVT | i.T) && f(c, i.T) || f(c, i.Extend | i.ZWJ) || f(c, i.SpacingMark) || f(r, i.Prepend) || o === j)) {
                if (!f(r, i.Regional_Indicator) || !f(c, i.Regional_Indicator) || n % 2 != 0) return s + 1 - t;
                n++;
            }
        }
    }
    return r - t;
}
var h = function(e) {
    const t = [], r = [
        0
    ], n = [];
    for(let t = 0; t < e.length;){
        const o = e.codePointAt(t);
        n.push(d.get(o) | l.get(o)), t += o > 65535 ? 2 : 1, r.push(t);
    }
    for(let o = 0; o < n.length;){
        const i = x(n, o), s = r[o], c = r[o + i];
        t.push(e.slice(s, c)), o += i;
    }
    return t;
}, L = e.getDefaultExportFromCjs(h);
exports.default = L; //# sourceMappingURL=index.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/graphemesplit/typeTrie.json.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "data": (()=>v),
    "default": (()=>f)
});
var v = "ABAOAAAAAACwiAAAAYkHdvjtnH+IFkUYxx/v3vPe7uw8UkjsD43ChKICDQsT3iIJy4gSiZAjkn5JUFlaiFmjccT9ESkpGBGVIlQgWSkY/QDBoMgrQv0jRJDAfkCXhUmgRX23d4ebnndmd3Z3ZnfVeeDDzM7MPs8zv57Zd2+5hd1Ed4ClYAisBuuUsqLpMHgJjIBNFu1fBW8l1O8AO8Ee8Cn4HIyCg+CI0u4Y+AmMgVPgDOhuEHWBPjAZXAy2gjfA9kb73hlx+i7SK8AHYDf4BOwHB8AoOAyOguPgB/ArOKlcnwHdPe32/Uin9LTvvwTph0gv62nbubKnXT+nZ1z/DcjfFF8vQno7uEaxH923BGVXN9v5Zcgvj/VFPIT8Y/H1k0jXxPn1SEfARjBdab8V+TfB22CXUh5xd3OcZTH3g6di1LZJbLNs55q96M9n4J9Gm6hsfzQvcT8fbfy//TyUf8vG4Lses/5jcd2PSE/IcQan4/o/UXYadE0kaoJBMG1ivNbidNbETr1XoWyuplwyHFN0fFai/8/EY7BIKY/68EpCvwP+mc/m/2vNGnBhp1eZ51bCmgsEAoFAIBAIBAKBQKAO3Irfrg3lfc4qi/cXd+Kee5TfvAd6ieY0ie5D2cNx+eNInwZLmu33gWuRn4/8C3H9CNJNYEt8/TrS35HuSPktvRP1z0LPOvAceB4IsB5saIa6UBfqQl2oc123AjwBVjWrP7MCgcC5y/ue/56yqXv87+qcIU2Z+ny8tuHHpyxsvrDNITDXgqkDRJcPdJY/wMo24/oQmDqZaPHkdplAuhv8ApqDRDeCVj/OAvD9BUSX9qF8Qpt7lTxnZ7+5TmVtrGMM7XchP3sS0SNgGzg4yU5HIBAIBM5NfsO5QDgfjuM54STOw7/Az/F3QtfhfF4Qn9F/gxMouxm/WU7F9afBQuUM7+rtPF+jb0b6ese/I7sI+emadhEzUT5bqbsW+esNbSMWoG6hWo/8gOLPUqUu+v5rKEHX8oS6iEXQexd7XlmBe1aCNWAp6kSsYyjHc82Liv2Xkd/C/HkN1w/Geren+KryToa2PtlQg2c9zijGZnGJ9kaibzZh84jmmfx4TeYpK9H3usMKqxnDCWxsdLY/3ygy9h+l/LYbYHtuXw2/rfsSPo0a/Jrn6PvPrzL2+7CmfV88lkc9j+F7cRzYU4N48DF8uA3n/T7Fly9q4Jdvoth0uLf9LORC11hvO/0D6RnQfRa99+2Hr1NS/M26VvfEe2jaWTAOvG8zzgKf8zCrYL++qUEfbumeQAjTVnQp+QmW99gQpDoJ4+9uHZe5/l3OW/M8x6WUZaduUvUc5p13NTXlz3VpGbCVrGNe5zOnjvGlrDWY1IdWShuuQ9fWh6h+VSV1Wit1lvNhHFz1zeUYtCg5ntvOSStDW5cITRnF5RJ+rcasJHExztwu910tl6LzLYsvuvvzilB0mvSaxt/V+SY0EMurfkjbrTjfInf+FJGkNdzSlOukZaDo3snqs7RZpqj2Gx7sS52D5O79k+93W2W/T3NhQxe3VeF16pwn4eI8qev7Sl1s0PnPy5PalSV57Pp6XuDxrypR9wBR8nOCzm/eXuYp5d4s/lV1XvL+lG2b+2AaQ1nPr23Hrc7z0WT5qvZL0v7QtdX5zdu6HMei+gV1ri8et4XSVpCfdeB7fRWNRy79UP0RCT4Jyre/88bbKsQUawUrV69dxjd+nlXxbCKos79pz1BpOqucz0gEdZ5hMk+aa7Wdy/7xZ5Yqhc+nyHivrkyQ/reM7tziuFojfM7zxtq0505XYutvHrtVnzNl2ONrTGdPkLv9ZjNHOoShnCh5nLLYKOKfK4qK7bjx/gqyj9lFJc2Wz/HIqyMSYaGnqM8+xp6vB1/6feg22UmLFUno1rurvelz7yT1UVfORW3L7+d6fMcAXdzxIVK3TNNioZpSyj2242izpky6y5S0fpr6q5ZXJT7O1qrmQRVB+rkQ1Dk3vvYttyGoc+51/mUVkYLtXvTx7MCvbUnzW2czyR8pql4XUlbcN9l1pSfPfOl0JV2bylyKoM4959sHQfr9Vpbk2V8u4ry0ndcvH5I1xggP9qVem/PHZL+qeGLrc945tLnHtG/LEtdjr4urxMpM92X1RZDd+pLtsorUydeCaiuvbtdSpQ9l2M4SU01nvI1e35L3uS5Jlw8pe1ykCKo2JtrGK9O9ujOlimcD6Y9LEWQ+7019d2VDLVPrTCLrsvjsQ1TfJVJM12pZmm5b4Xptx6HM9SpFkP2c6drJa5/iSr+pD7r+CNLvATVfpST1RYog/fwKTdsyxLVNQfnWrkyziGltJK2hLLptzjHXIsh+/HytmyQfpPA5VNtzXWWLzbiVsc9sbWSJ7UWE69KNh6v9kya2c6TzMa0fwpD37TtvQ6wuiw9CA9cny33Mj2pLte9Kp6996HO/83HPQ5r+ov5mvU9Qte/fIrGJP7axPO/9eXX6kjLPKZNd17iyZdOHLP31JSbfXY6hC59c+ZZ136TZ9SFlj6cvmVkSrkSQn3NG5KBqEVSeH6Ji/vvnhFWjSlfFNDwzyMgqLvvKxXffbeASBWo+Zj4p2x6TfwE=", f = {
    data: v
};
;
 //# sourceMappingURL=typeTrie.json.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/graphemesplit/extPict.json.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "data": (()=>d),
    "default": (()=>A)
});
var d = "AAACAAAAAACAOAAAAbYBSf7t2S1IBEEYBuDVDZ7FYrQMNsFiu3hgEYOI0SCXRIUrB8JhEZtgs5gEg1GMFk02m82oGI02m+9xezCOczv/uwv3fvAwc/PzfXOzcdqzWdaBDdiGPdiHdjE+DS3RNDuCfsn8idQ/g3OH3BdwKf0e96/gumTfYcncLdzBPTzAo+RZ+f0Cr/AG7/AJX4738x1wtz9FO5PX/50n6UXMNdfg/0lERERERERERERERETpdedHBvDRql4nq0cXtW9af98qdRby0Vvp8K4W0V+C5Xw0t4J2bfjeBp3cnEu1brnnCTYNa7eKdz91XP7WO9Lb4GqRb7cY6xbtAdqeVOsY/QGcevw/tb6OT85YhvfKYEx9CMuxKsKnrs+eJtVInVvHJ0eVYVvTZk2siFVLOCjb61PTZX3MdVWEyP7fjzpmMxdzTyq2Ebue6x61nXRGnzndWpf1an7dXmGYE4Y1ptqqKsK1nu26Ju0ty+maV2Rpvk+qnDZjKUIobUiesdAQE/jmCTmHmsskpFZsVYbtmXRcaoSGUPomunW2derQhDPFjtT1Q/eb8vnm990fq35oHVt11bU9m89c7DNI8Qs=", A = {
    data: d
};
;
 //# sourceMappingURL=extPict.json.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/graphemesplit/types.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "t": (()=>e)
});
var e = {
    Other: 0,
    CR: 1,
    LF: 2,
    Control: 4,
    Extend: 8,
    ZWJ: 16,
    Regional_Indicator: 32,
    Prepend: 64,
    SpacingMark: 128,
    L: 256,
    V: 512,
    T: 1024,
    LV: 2048,
    LVT: 4096,
    Extended_Pictographic: 8192
};
;
 //# sourceMappingURL=types.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/graphemesplit/index.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>L)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$_commonjsHelpers$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/_commonjsHelpers.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$graphemesplit$2f$typeTrie$2e$json$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/graphemesplit/typeTrie.json.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$graphemesplit$2f$extPict$2e$json$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/graphemesplit/extPict.json.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$unicode$2d$trie$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/unicode-trie/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$js$2d$base64$2f$base64$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/js-base64/base64.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$graphemesplit$2f$types$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/graphemesplit/types.mjs [app-route] (ecmascript)");
;
;
;
;
;
;
const s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$graphemesplit$2f$types$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["t"], a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$graphemesplit$2f$typeTrie$2e$json$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].data, c = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$graphemesplit$2f$extPict$2e$json$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].data, m = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$unicode$2d$trie$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["u"], f = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$js$2d$base64$2f$base64$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["b"].Base64, p = new m(f.toUint8Array(a)), d = new m(f.toUint8Array(c));
function l(t, e) {
    return 0 != (t & e);
}
const u = 0, g = 1, j = 2;
function h(t, e) {
    const o = t.length;
    let r = 0, n = u;
    for(let i = e; i + 1 < o; i++){
        const o = t[i + 0], a = t[i + 1];
        switch(l(o, s.Regional_Indicator) || (r = 0), n){
            case j:
            case u:
                n = l(o, s.Extended_Pictographic) ? g : u;
                break;
            case g:
                n = l(o, s.Extend) ? g : l(o, s.ZWJ) && l(a, s.Extended_Pictographic) ? j : u;
        }
        if (!l(o, s.CR) || !l(a, s.LF)) {
            if (l(o, s.Control | s.CR | s.LF)) return i + 1 - e;
            if (l(a, s.Control | s.CR | s.LF)) return i + 1 - e;
            if (!(l(o, s.L) && l(a, s.L | s.V | s.LV | s.LVT) || l(o, s.LV | s.V) && l(a, s.V | s.T) || l(o, s.LVT | s.T) && l(a, s.T) || l(a, s.Extend | s.ZWJ) || l(a, s.SpacingMark) || l(o, s.Prepend) || n === j)) {
                if (!l(o, s.Regional_Indicator) || !l(a, s.Regional_Indicator) || r % 2 != 0) return i + 1 - e;
                r++;
            }
        }
    }
    return o - e;
}
var L = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$_commonjsHelpers$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDefaultExportFromCjs"])(function(t) {
    const e = [], o = [
        0
    ], r = [];
    for(let e = 0; e < t.length;){
        const n = t.codePointAt(e);
        r.push(p.get(n) | d.get(n)), e += n > 65535 ? 2 : 1, o.push(e);
    }
    for(let n = 0; n < r.length;){
        const i = h(r, n), s = o[n], a = o[n + i];
        e.push(t.slice(s, a)), n += i;
    }
    return e;
});
;
 //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/tiny-inflate/index.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var t = 0, e = -3;
function r() {
    this.table = new Uint16Array(16), this.trans = new Uint16Array(288);
}
function n(t, e) {
    this.source = t, this.sourceIndex = 0, this.tag = 0, this.bitcount = 0, this.dest = e, this.destLen = 0, this.ltree = new r, this.dtree = new r;
}
var o = new r, a = new r, s = new Uint8Array(30), i = new Uint16Array(30), u = new Uint8Array(30), c = new Uint16Array(30), f = new Uint8Array([
    16,
    17,
    18,
    0,
    8,
    7,
    9,
    6,
    10,
    5,
    11,
    4,
    12,
    3,
    13,
    2,
    14,
    1,
    15
]), d = new r, b = new Uint8Array(320);
function l(t, e, r, n) {
    var o, a;
    for(o = 0; o < r; ++o)t[o] = 0;
    for(o = 0; o < 30 - r; ++o)t[o + r] = o / r | 0;
    for(a = n, o = 0; o < 30; ++o)e[o] = a, a += 1 << t[o];
}
var w = new Uint16Array(16);
function v(t, e, r, n) {
    var o, a;
    for(o = 0; o < 16; ++o)t.table[o] = 0;
    for(o = 0; o < n; ++o)t.table[e[r + o]]++;
    for(t.table[0] = 0, a = 0, o = 0; o < 16; ++o)w[o] = a, a += t.table[o];
    for(o = 0; o < n; ++o)e[r + o] && (t.trans[w[e[r + o]]++] = o);
}
function h(t) {
    t.bitcount-- || (t.tag = t.source[t.sourceIndex++], t.bitcount = 7);
    var e = 1 & t.tag;
    return t.tag >>>= 1, e;
}
function x(t, e, r) {
    if (!e) return r;
    for(; t.bitcount < 24;)t.tag |= t.source[t.sourceIndex++] << t.bitcount, t.bitcount += 8;
    var n = t.tag & 65535 >>> 16 - e;
    return t.tag >>>= e, t.bitcount -= e, n + r;
}
function y(t, e) {
    for(; t.bitcount < 24;)t.tag |= t.source[t.sourceIndex++] << t.bitcount, t.bitcount += 8;
    var r = 0, n = 0, o = 0, a = t.tag;
    do {
        n = 2 * n + (1 & a), a >>>= 1, ++o, r += e.table[o], n -= e.table[o];
    }while (n >= 0)
    return t.tag = a, t.bitcount -= o, e.trans[r + n];
}
function I(t, e, r) {
    var n, o, a, s, i, u;
    for(n = x(t, 5, 257), o = x(t, 5, 1), a = x(t, 4, 4), s = 0; s < 19; ++s)b[s] = 0;
    for(s = 0; s < a; ++s){
        var c = x(t, 3, 0);
        b[f[s]] = c;
    }
    for(v(d, b, 0, 19), i = 0; i < n + o;){
        var l = y(t, d);
        switch(l){
            case 16:
                var w = b[i - 1];
                for(u = x(t, 2, 3); u; --u)b[i++] = w;
                break;
            case 17:
                for(u = x(t, 3, 3); u; --u)b[i++] = 0;
                break;
            case 18:
                for(u = x(t, 7, 11); u; --u)b[i++] = 0;
                break;
            default:
                b[i++] = l;
        }
    }
    v(e, b, 0, n), v(r, b, n, o);
}
function g(e, r, n) {
    for(;;){
        var o, a, f, d, b = y(e, r);
        if (256 === b) return t;
        if (b < 256) e.dest[e.destLen++] = b;
        else for(o = x(e, s[b -= 257], i[b]), a = y(e, n), d = f = e.destLen - x(e, u[a], c[a]); d < f + o; ++d)e.dest[e.destLen++] = e.dest[d];
    }
}
function A(r) {
    for(var n, o; r.bitcount > 8;)r.sourceIndex--, r.bitcount -= 8;
    if ((n = 256 * (n = r.source[r.sourceIndex + 1]) + r.source[r.sourceIndex]) !== (65535 & ~(256 * r.source[r.sourceIndex + 3] + r.source[r.sourceIndex + 2]))) return e;
    for(r.sourceIndex += 4, o = n; o; --o)r.dest[r.destLen++] = r.source[r.sourceIndex++];
    return r.bitcount = 0, t;
}
!function(t, e) {
    var r;
    for(r = 0; r < 7; ++r)t.table[r] = 0;
    for(t.table[7] = 24, t.table[8] = 152, t.table[9] = 112, r = 0; r < 24; ++r)t.trans[r] = 256 + r;
    for(r = 0; r < 144; ++r)t.trans[24 + r] = r;
    for(r = 0; r < 8; ++r)t.trans[168 + r] = 280 + r;
    for(r = 0; r < 112; ++r)t.trans[176 + r] = 144 + r;
    for(r = 0; r < 5; ++r)e.table[r] = 0;
    for(e.table[5] = 32, r = 0; r < 32; ++r)e.trans[r] = r;
}(o, a), l(s, i, 4, 3), l(u, c, 2, 1), s[28] = 0, i[28] = 258;
var U = function(r, s) {
    var i, u, c = new n(r, s);
    do {
        switch(i = h(c), x(c, 2, 0)){
            case 0:
                u = A(c);
                break;
            case 1:
                u = g(c, o, a);
                break;
            case 2:
                I(c, c.ltree, c.dtree), u = g(c, c.ltree, c.dtree);
                break;
            default:
                u = e;
        }
        if (u !== t) throw new Error("Data error");
    }while (!i)
    return c.destLen < c.dest.length ? "function" == typeof c.dest.slice ? c.dest.slice(0, c.destLen) : c.dest.subarray(0, c.destLen) : c.dest;
};
exports.tinyInflate = U; //# sourceMappingURL=index.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/tiny-inflate/index.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "t": (()=>U)
});
var t = 0, e = -3;
function r() {
    this.table = new Uint16Array(16), this.trans = new Uint16Array(288);
}
function n(t, e) {
    this.source = t, this.sourceIndex = 0, this.tag = 0, this.bitcount = 0, this.dest = e, this.destLen = 0, this.ltree = new r, this.dtree = new r;
}
var o = new r, a = new r, s = new Uint8Array(30), u = new Uint16Array(30), c = new Uint8Array(30), i = new Uint16Array(30), f = new Uint8Array([
    16,
    17,
    18,
    0,
    8,
    7,
    9,
    6,
    10,
    5,
    11,
    4,
    12,
    3,
    13,
    2,
    14,
    1,
    15
]), d = new r, b = new Uint8Array(320);
function l(t, e, r, n) {
    var o, a;
    for(o = 0; o < r; ++o)t[o] = 0;
    for(o = 0; o < 30 - r; ++o)t[o + r] = o / r | 0;
    for(a = n, o = 0; o < 30; ++o)e[o] = a, a += 1 << t[o];
}
var w = new Uint16Array(16);
function v(t, e, r, n) {
    var o, a;
    for(o = 0; o < 16; ++o)t.table[o] = 0;
    for(o = 0; o < n; ++o)t.table[e[r + o]]++;
    for(t.table[0] = 0, a = 0, o = 0; o < 16; ++o)w[o] = a, a += t.table[o];
    for(o = 0; o < n; ++o)e[r + o] && (t.trans[w[e[r + o]]++] = o);
}
function h(t) {
    t.bitcount-- || (t.tag = t.source[t.sourceIndex++], t.bitcount = 7);
    var e = 1 & t.tag;
    return t.tag >>>= 1, e;
}
function x(t, e, r) {
    if (!e) return r;
    for(; t.bitcount < 24;)t.tag |= t.source[t.sourceIndex++] << t.bitcount, t.bitcount += 8;
    var n = t.tag & 65535 >>> 16 - e;
    return t.tag >>>= e, t.bitcount -= e, n + r;
}
function g(t, e) {
    for(; t.bitcount < 24;)t.tag |= t.source[t.sourceIndex++] << t.bitcount, t.bitcount += 8;
    var r = 0, n = 0, o = 0, a = t.tag;
    do {
        n = 2 * n + (1 & a), a >>>= 1, ++o, r += e.table[o], n -= e.table[o];
    }while (n >= 0)
    return t.tag = a, t.bitcount -= o, e.trans[r + n];
}
function y(t, e, r) {
    var n, o, a, s, u, c;
    for(n = x(t, 5, 257), o = x(t, 5, 1), a = x(t, 4, 4), s = 0; s < 19; ++s)b[s] = 0;
    for(s = 0; s < a; ++s){
        var i = x(t, 3, 0);
        b[f[s]] = i;
    }
    for(v(d, b, 0, 19), u = 0; u < n + o;){
        var l = g(t, d);
        switch(l){
            case 16:
                var w = b[u - 1];
                for(c = x(t, 2, 3); c; --c)b[u++] = w;
                break;
            case 17:
                for(c = x(t, 3, 3); c; --c)b[u++] = 0;
                break;
            case 18:
                for(c = x(t, 7, 11); c; --c)b[u++] = 0;
                break;
            default:
                b[u++] = l;
        }
    }
    v(e, b, 0, n), v(r, b, n, o);
}
function I(e, r, n) {
    for(;;){
        var o, a, f, d, b = g(e, r);
        if (256 === b) return t;
        if (b < 256) e.dest[e.destLen++] = b;
        else for(o = x(e, s[b -= 257], u[b]), a = g(e, n), d = f = e.destLen - x(e, c[a], i[a]); d < f + o; ++d)e.dest[e.destLen++] = e.dest[d];
    }
}
function A(r) {
    for(var n, o; r.bitcount > 8;)r.sourceIndex--, r.bitcount -= 8;
    if ((n = 256 * (n = r.source[r.sourceIndex + 1]) + r.source[r.sourceIndex]) !== (65535 & ~(256 * r.source[r.sourceIndex + 3] + r.source[r.sourceIndex + 2]))) return e;
    for(r.sourceIndex += 4, o = n; o; --o)r.dest[r.destLen++] = r.source[r.sourceIndex++];
    return r.bitcount = 0, t;
}
!function(t, e) {
    var r;
    for(r = 0; r < 7; ++r)t.table[r] = 0;
    for(t.table[7] = 24, t.table[8] = 152, t.table[9] = 112, r = 0; r < 24; ++r)t.trans[r] = 256 + r;
    for(r = 0; r < 144; ++r)t.trans[24 + r] = r;
    for(r = 0; r < 8; ++r)t.trans[168 + r] = 280 + r;
    for(r = 0; r < 112; ++r)t.trans[176 + r] = 144 + r;
    for(r = 0; r < 5; ++r)e.table[r] = 0;
    for(e.table[5] = 32, r = 0; r < 32; ++r)e.trans[r] = r;
}(o, a), l(s, u, 4, 3), l(c, i, 2, 1), s[28] = 0, u[28] = 258;
var U = function(r, s) {
    var u, c, i = new n(r, s);
    do {
        switch(u = h(i), x(i, 2, 0)){
            case 0:
                c = A(i);
                break;
            case 1:
                c = I(i, o, a);
                break;
            case 2:
                y(i, i.ltree, i.dtree), c = I(i, i.ltree, i.dtree);
                break;
            default:
                c = e;
        }
        if (c !== t) throw new Error("Data error");
    }while (!u)
    return i.destLen < i.dest.length ? "function" == typeof i.dest.slice ? i.dest.slice(0, i.destLen) : i.dest.subarray(0, i.destLen) : i.dest;
};
;
 //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/unicode-trie/swap.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
const t = 18 === new Uint8Array(new Uint32Array([
    305419896
]).buffer)[0], r = (t, r, e)=>{
    let n = t[r];
    t[r] = t[e], t[e] = n;
};
var e = {
    swap32LE: (e)=>{
        t && ((t)=>{
            const e = t.length;
            for(let n = 0; n < e; n += 4)r(t, n, n + 3), r(t, n + 1, n + 2);
        })(e);
    }
};
exports.swap_1 = e; //# sourceMappingURL=swap.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/unicode-trie/index.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var t = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/tiny-inflate/index.cjs [app-route] (ecmascript)"), a = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/unicode-trie/swap.cjs [app-route] (ecmascript)");
const e = t.tinyInflate, { swap32LE: r } = a.swap_1;
var i = class {
    constructor(t){
        const a = "function" == typeof t.readUInt32BE && "function" == typeof t.slice;
        if (a || t instanceof Uint8Array) {
            let i;
            if (a) this.highStart = t.readUInt32LE(0), this.errorValue = t.readUInt32LE(4), i = t.readUInt32LE(8), t = t.slice(12);
            else {
                const a = new DataView(t.buffer);
                this.highStart = a.getUint32(0, !0), this.errorValue = a.getUint32(4, !0), i = a.getUint32(8, !0), t = t.subarray(12);
            }
            t = e(t, new Uint8Array(i)), t = e(t, new Uint8Array(i)), r(t), this.data = new Uint32Array(t.buffer);
        } else ({ data: this.data, highStart: this.highStart, errorValue: this.errorValue } = t);
    }
    get(t) {
        let a;
        return t < 0 || t > 1114111 ? this.errorValue : t < 55296 || t > 56319 && t <= 65535 ? (a = (this.data[t >> 5] << 2) + (31 & t), this.data[a]) : t <= 65535 ? (a = (this.data[2048 + (t - 55296 >> 5)] << 2) + (31 & t), this.data[a]) : t < this.highStart ? (a = this.data[2080 + (t >> 11)], a = this.data[a + (t >> 5 & 63)], a = (a << 2) + (31 & t), this.data[a]) : this.data[this.data.length - 4];
    }
};
exports.unicodeTrie = i; //# sourceMappingURL=index.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/unicode-trie/swap.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "s": (()=>e)
});
const r = 18 === new Uint8Array(new Uint32Array([
    305419896
]).buffer)[0], t = (r, t, e)=>{
    let n = r[t];
    r[t] = r[e], r[e] = n;
};
var e = {
    swap32LE: (e)=>{
        r && ((r)=>{
            const e = r.length;
            for(let n = 0; n < e; n += 4)t(r, n, n + 3), t(r, n + 1, n + 2);
        })(e);
    }
};
;
 //# sourceMappingURL=swap.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/unicode-trie/index.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "u": (()=>e)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$tiny$2d$inflate$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/tiny-inflate/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$unicode$2d$trie$2f$swap$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/unicode-trie/swap.mjs [app-route] (ecmascript)");
;
;
const r = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$tiny$2d$inflate$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["t"], { swap32LE: i } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$unicode$2d$trie$2f$swap$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["s"];
var e = class {
    constructor(t){
        const a = "function" == typeof t.readUInt32BE && "function" == typeof t.slice;
        if (a || t instanceof Uint8Array) {
            let e;
            if (a) this.highStart = t.readUInt32LE(0), this.errorValue = t.readUInt32LE(4), e = t.readUInt32LE(8), t = t.slice(12);
            else {
                const a = new DataView(t.buffer);
                this.highStart = a.getUint32(0, !0), this.errorValue = a.getUint32(4, !0), e = a.getUint32(8, !0), t = t.subarray(12);
            }
            t = r(t, new Uint8Array(e)), t = r(t, new Uint8Array(e)), i(t), this.data = new Uint32Array(t.buffer);
        } else ({ data: this.data, highStart: this.highStart, errorValue: this.errorValue } = t);
    }
    get(t) {
        let a;
        return t < 0 || t > 1114111 ? this.errorValue : t < 55296 || t > 56319 && t <= 65535 ? (a = (this.data[t >> 5] << 2) + (31 & t), this.data[a]) : t <= 65535 ? (a = (this.data[2048 + (t - 55296 >> 5)] << 2) + (31 & t), this.data[a]) : t < this.highStart ? (a = this.data[2080 + (t >> 11)], a = this.data[a + (t >> 5 & 63)], a = (a << 2) + (31 & t), this.data[a]) : this.data[this.data.length - 4];
    }
};
;
 //# sourceMappingURL=index.mjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/js-base64/base64.cjs [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
__turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/node_modules/buffer/index.cjs [app-route] (ecmascript)");
var r, t, e, n, o, u, i, c, f, a, s, d, l, p, h, A, y, b, x, g, m, _, B, v, C, U, F, w, j, E, S, D, R, z, T, Z, q, I, O, P, L, G, V = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/_virtual/_commonjsHelpers.cjs [app-route] (ecmascript)"), k = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/_virtual/base64.cjs [app-route] (ecmascript)"), H = __turbopack_require__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/cjs/_virtual/index.cjs [app-route] (ecmascript)");
r = k.__module, "undefined" != typeof self ? self : ("TURBOPACK compile-time falsy", 0) ? ("TURBOPACK unreachable", undefined) : (V.commonjsGlobal, V.commonjsGlobal), r.exports = (e = t = "3.7.5", n = "function" == typeof atob, o = "function" == typeof btoa, u = "function" == typeof H.__exports.Buffer, i = "function" == typeof TextDecoder ? new TextDecoder : void 0, c = "function" == typeof TextEncoder ? new TextEncoder : void 0, f = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", a = Array.prototype.slice.call(f), G = {}, a.forEach(function(r, t) {
    return G[r] = t;
}), s = G, d = /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/, l = String.fromCharCode.bind(String), p = "function" == typeof Uint8Array.from ? Uint8Array.from.bind(Uint8Array) : function(r) {
    return new Uint8Array(Array.prototype.slice.call(r, 0));
}, h = function(r) {
    return r.replace(/=/g, "").replace(/[+\/]/g, function(r) {
        return "+" == r ? "-" : "_";
    });
}, A = function(r) {
    return r.replace(/[^A-Za-z0-9\+\/]/g, "");
}, y = function(r) {
    for(var t, e, n, o, u = "", i = r.length % 3, c = 0; c < r.length;){
        if ((e = r.charCodeAt(c++)) > 255 || (n = r.charCodeAt(c++)) > 255 || (o = r.charCodeAt(c++)) > 255) throw new TypeError("invalid character found");
        u += a[(t = e << 16 | n << 8 | o) >> 18 & 63] + a[t >> 12 & 63] + a[t >> 6 & 63] + a[63 & t];
    }
    return i ? u.slice(0, i - 3) + "===".substring(i) : u;
}, x = u ? function(r) {
    return H.__exports.Buffer.from(r).toString("base64");
} : function(r) {
    for(var t = 4096, e = [], n = 0, o = r.length; n < o; n += t)e.push(l.apply(null, r.subarray(n, n + t)));
    return b(e.join(""));
}, m = function(r) {
    if (r.length < 2) return (t = r.charCodeAt(0)) < 128 ? r : t < 2048 ? l(192 | t >>> 6) + l(128 | 63 & t) : l(224 | t >>> 12 & 15) + l(128 | t >>> 6 & 63) + l(128 | 63 & t);
    var t = 65536 + 1024 * (r.charCodeAt(0) - 55296) + (r.charCodeAt(1) - 56320);
    return l(240 | t >>> 18 & 7) + l(128 | t >>> 12 & 63) + l(128 | t >>> 6 & 63) + l(128 | 63 & t);
}, _ = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g, v = u ? function(r) {
    return H.__exports.Buffer.from(r, "utf8").toString("base64");
} : c ? function(r) {
    return x(c.encode(r));
} : function(r) {
    return b(B(r));
}, U = function(r) {
    return C(r, !0);
}, F = /[\xC0-\xDF][\x80-\xBF]|[\xE0-\xEF][\x80-\xBF]{2}|[\xF0-\xF7][\x80-\xBF]{3}/g, w = function(r) {
    switch(r.length){
        case 4:
            var t = ((7 & r.charCodeAt(0)) << 18 | (63 & r.charCodeAt(1)) << 12 | (63 & r.charCodeAt(2)) << 6 | 63 & r.charCodeAt(3)) - 65536;
            return l(55296 + (t >>> 10)) + l(56320 + (1023 & t));
        case 3:
            return l((15 & r.charCodeAt(0)) << 12 | (63 & r.charCodeAt(1)) << 6 | 63 & r.charCodeAt(2));
        default:
            return l((31 & r.charCodeAt(0)) << 6 | 63 & r.charCodeAt(1));
    }
}, E = function(r) {
    if (r = r.replace(/\s+/g, ""), !d.test(r)) throw new TypeError("malformed base64.");
    r += "==".slice(2 - (3 & r.length));
    for(var t, e, n, o = "", u = 0; u < r.length;)t = s[r.charAt(u++)] << 18 | s[r.charAt(u++)] << 12 | (e = s[r.charAt(u++)]) << 6 | (n = s[r.charAt(u++)]), o += 64 === e ? l(t >> 16 & 255) : 64 === n ? l(t >> 16 & 255, t >> 8 & 255) : l(t >> 16 & 255, t >> 8 & 255, 255 & t);
    return o;
}, D = u ? function(r) {
    return p(H.__exports.Buffer.from(r, "base64"));
} : function(r) {
    return p(S(r).split("").map(function(r) {
        return r.charCodeAt(0);
    }));
}, R = function(r) {
    return D(T(r));
}, z = u ? function(r) {
    return H.__exports.Buffer.from(r, "base64").toString("utf8");
} : i ? function(r) {
    return i.decode(D(r));
} : function(r) {
    return j(S(r));
}, T = function(r) {
    return A(r.replace(/[-_]/g, function(r) {
        return "-" == r ? "+" : "/";
    }));
}, q = function(r) {
    return {
        value: r,
        enumerable: !1,
        writable: !0,
        configurable: !0
    };
}, I = function() {
    var r = function(r, t) {
        return Object.defineProperty(String.prototype, r, q(t));
    };
    r("fromBase64", function() {
        return Z(this);
    }), r("toBase64", function(r) {
        return C(this, r);
    }), r("toBase64URI", function() {
        return C(this, !0);
    }), r("toBase64URL", function() {
        return C(this, !0);
    }), r("toUint8Array", function() {
        return R(this);
    });
}, O = function() {
    var r = function(r, t) {
        return Object.defineProperty(Uint8Array.prototype, r, q(t));
    };
    r("toBase64", function(r) {
        return g(this, r);
    }), r("toBase64URI", function() {
        return g(this, !0);
    }), r("toBase64URL", function() {
        return g(this, !0);
    });
}, P = function() {
    I(), O();
}, L = {
    version: t,
    VERSION: e,
    atob: S = n ? function(r) {
        return atob(A(r));
    } : u ? function(r) {
        return H.__exports.Buffer.from(r, "base64").toString("binary");
    } : E,
    atobPolyfill: E,
    btoa: b = o ? function(r) {
        return btoa(r);
    } : u ? function(r) {
        return H.__exports.Buffer.from(r, "binary").toString("base64");
    } : y,
    btoaPolyfill: y,
    fromBase64: Z = function(r) {
        return z(T(r));
    },
    toBase64: C = function(r, t) {
        return void 0 === t && (t = !1), t ? h(v(r)) : v(r);
    },
    encode: C,
    encodeURI: U,
    encodeURL: U,
    utob: B = function(r) {
        return r.replace(_, m);
    },
    btou: j = function(r) {
        return r.replace(F, w);
    },
    decode: Z,
    isValid: function(r) {
        if ("string" != typeof r) return !1;
        var t = r.replace(/\s+/g, "").replace(/={0,2}$/, "");
        return !/[^\s0-9a-zA-Z\+/]/.test(t) || !/[^\s0-9a-zA-Z\-_]/.test(t);
    },
    fromUint8Array: g = function(r, t) {
        return void 0 === t && (t = !1), t ? h(x(r)) : x(r);
    },
    toUint8Array: R,
    extendString: I,
    extendUint8Array: O,
    extendBuiltins: P,
    Base64: {}
}, Object.keys(L).forEach(function(r) {
    return L.Base64[r] = L[r];
}), L);
var N = k.__module.exports;
exports.base64Exports = N; //# sourceMappingURL=base64.cjs.map
}}),
"[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/js-base64/base64.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "b": (()=>$)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$node_modules$2f$buffer$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/node_modules/buffer/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$_commonjsHelpers$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/_commonjsHelpers.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$base64$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/base64.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@bonfida+spl-name-service@3.0.7_@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8_rrwgb5odwn6mnxryo3fxrd7pwq/node_modules/@bonfida/spl-name-service/dist/esm/_virtual/index.mjs [app-route] (ecmascript)");
;
;
;
;
var e, o, u, i, f, a, c, s, d, l, p, h, A, y, b, m, g, x, B, v, C, U, F, w, S, _, j, E, D, R, z, T, Z, I, O, P, L, V, k, H, N;
"undefined" != typeof self ? self : "undefined" != "undefined" && window, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$base64$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__module"].exports = (o = e = "3.7.5", u = "function" == typeof atob, i = "function" == typeof btoa, f = "function" == typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].Buffer, a = "function" == typeof TextDecoder ? new TextDecoder : void 0, c = "function" == typeof TextEncoder ? new TextEncoder : void 0, s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", d = Array.prototype.slice.call(s), N = {}, d.forEach(function(r, t) {
    return N[r] = t;
}), l = N, p = /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/, h = String.fromCharCode.bind(String), A = "function" == typeof Uint8Array.from ? Uint8Array.from.bind(Uint8Array) : function(r) {
    return new Uint8Array(Array.prototype.slice.call(r, 0));
}, y = function(r) {
    return r.replace(/=/g, "").replace(/[+\/]/g, function(r) {
        return "+" == r ? "-" : "_";
    });
}, b = function(r) {
    return r.replace(/[^A-Za-z0-9\+\/]/g, "");
}, m = function(r) {
    for(var t, n, e, o, u = "", i = r.length % 3, f = 0; f < r.length;){
        if ((n = r.charCodeAt(f++)) > 255 || (e = r.charCodeAt(f++)) > 255 || (o = r.charCodeAt(f++)) > 255) throw new TypeError("invalid character found");
        u += d[(t = n << 16 | e << 8 | o) >> 18 & 63] + d[t >> 12 & 63] + d[t >> 6 & 63] + d[63 & t];
    }
    return i ? u.slice(0, i - 3) + "===".substring(i) : u;
}, x = f ? function(r) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].Buffer.from(r).toString("base64");
} : function(r) {
    for(var t = 4096, n = [], e = 0, o = r.length; e < o; e += t)n.push(h.apply(null, r.subarray(e, e + t)));
    return g(n.join(""));
}, v = function(r) {
    if (r.length < 2) return (t = r.charCodeAt(0)) < 128 ? r : t < 2048 ? h(192 | t >>> 6) + h(128 | 63 & t) : h(224 | t >>> 12 & 15) + h(128 | t >>> 6 & 63) + h(128 | 63 & t);
    var t = 65536 + 1024 * (r.charCodeAt(0) - 55296) + (r.charCodeAt(1) - 56320);
    return h(240 | t >>> 18 & 7) + h(128 | t >>> 12 & 63) + h(128 | t >>> 6 & 63) + h(128 | 63 & t);
}, C = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g, F = f ? function(r) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].Buffer.from(r, "utf8").toString("base64");
} : c ? function(r) {
    return x(c.encode(r));
} : function(r) {
    return g(U(r));
}, S = function(r) {
    return w(r, !0);
}, _ = /[\xC0-\xDF][\x80-\xBF]|[\xE0-\xEF][\x80-\xBF]{2}|[\xF0-\xF7][\x80-\xBF]{3}/g, j = function(r) {
    switch(r.length){
        case 4:
            var t = ((7 & r.charCodeAt(0)) << 18 | (63 & r.charCodeAt(1)) << 12 | (63 & r.charCodeAt(2)) << 6 | 63 & r.charCodeAt(3)) - 65536;
            return h(55296 + (t >>> 10)) + h(56320 + (1023 & t));
        case 3:
            return h((15 & r.charCodeAt(0)) << 12 | (63 & r.charCodeAt(1)) << 6 | 63 & r.charCodeAt(2));
        default:
            return h((31 & r.charCodeAt(0)) << 6 | 63 & r.charCodeAt(1));
    }
}, D = function(r) {
    if (r = r.replace(/\s+/g, ""), !p.test(r)) throw new TypeError("malformed base64.");
    r += "==".slice(2 - (3 & r.length));
    for(var t, n, e, o = "", u = 0; u < r.length;)t = l[r.charAt(u++)] << 18 | l[r.charAt(u++)] << 12 | (n = l[r.charAt(u++)]) << 6 | (e = l[r.charAt(u++)]), o += 64 === n ? h(t >> 16 & 255) : 64 === e ? h(t >> 16 & 255, t >> 8 & 255) : h(t >> 16 & 255, t >> 8 & 255, 255 & t);
    return o;
}, z = f ? function(r) {
    return A(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].Buffer.from(r, "base64"));
} : function(r) {
    return A(R(r).split("").map(function(r) {
        return r.charCodeAt(0);
    }));
}, T = function(r) {
    return z(I(r));
}, Z = f ? function(r) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].Buffer.from(r, "base64").toString("utf8");
} : a ? function(r) {
    return a.decode(z(r));
} : function(r) {
    return E(R(r));
}, I = function(r) {
    return b(r.replace(/[-_]/g, function(r) {
        return "-" == r ? "+" : "/";
    }));
}, P = function(r) {
    return {
        value: r,
        enumerable: !1,
        writable: !0,
        configurable: !0
    };
}, L = function() {
    var r = function(r, t) {
        return Object.defineProperty(String.prototype, r, P(t));
    };
    r("fromBase64", function() {
        return O(this);
    }), r("toBase64", function(r) {
        return w(this, r);
    }), r("toBase64URI", function() {
        return w(this, !0);
    }), r("toBase64URL", function() {
        return w(this, !0);
    }), r("toUint8Array", function() {
        return T(this);
    });
}, V = function() {
    var r = function(r, t) {
        return Object.defineProperty(Uint8Array.prototype, r, P(t));
    };
    r("toBase64", function(r) {
        return B(this, r);
    }), r("toBase64URI", function() {
        return B(this, !0);
    }), r("toBase64URL", function() {
        return B(this, !0);
    });
}, k = function() {
    L(), V();
}, H = {
    version: e,
    VERSION: o,
    atob: R = u ? function(r) {
        return atob(b(r));
    } : f ? function(r) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].Buffer.from(r, "base64").toString("binary");
    } : D,
    atobPolyfill: D,
    btoa: g = i ? function(r) {
        return btoa(r);
    } : f ? function(r) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__exports"].Buffer.from(r, "binary").toString("base64");
    } : m,
    btoaPolyfill: m,
    fromBase64: O = function(r) {
        return Z(I(r));
    },
    toBase64: w = function(r, t) {
        return void 0 === t && (t = !1), t ? y(F(r)) : F(r);
    },
    encode: w,
    encodeURI: S,
    encodeURL: S,
    utob: U = function(r) {
        return r.replace(C, v);
    },
    btou: E = function(r) {
        return r.replace(_, j);
    },
    decode: O,
    isValid: function(r) {
        if ("string" != typeof r) return !1;
        var t = r.replace(/\s+/g, "").replace(/={0,2}$/, "");
        return !/[^\s0-9a-zA-Z\+/]/.test(t) || !/[^\s0-9a-zA-Z\-_]/.test(t);
    },
    fromUint8Array: B = function(r, t) {
        return void 0 === t && (t = !1), t ? y(x(r)) : x(r);
    },
    toUint8Array: T,
    extendString: L,
    extendUint8Array: V,
    extendBuiltins: k,
    Base64: {}
}, Object.keys(H).forEach(function(r) {
    return H.Base64[r] = H[r];
}), H);
var $ = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$bonfida$2b$spl$2d$name$2d$service$40$3$2e$0$2e$7_$40$solana$2b$web3$2e$js$40$1$2e$98$2e$0_bufferutil$40$4$2e$0$2e$9_encoding$40$0$2e$1$2e$13_utf$2d$8_rrwgb5odwn6mnxryo3fxrd7pwq$2f$node_modules$2f40$bonfida$2f$spl$2d$name$2d$service$2f$dist$2f$esm$2f$_virtual$2f$base64$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["__module"].exports;
;
 //# sourceMappingURL=base64.mjs.map
}}),

};

//# sourceMappingURL=a2553_%40bonfida_spl-name-service_dist_0a7ffa._.js.map
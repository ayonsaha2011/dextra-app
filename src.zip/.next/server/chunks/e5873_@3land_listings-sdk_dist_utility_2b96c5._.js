module.exports = {

"[project]/node_modules/.pnpm/@3land+listings-sdk@0.0.4_@types+node@20.17.14_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.1_hcq54orvwwwhxfa45fjs36zq7a/node_modules/@3land/listings-sdk/dist/utility/Connection.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getConnection = getConnection;
exports.createKeypairFromSecretKey = createKeypairFromSecretKey;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
function getConnection(endpoint) {
    return new web3_js_1.Connection(endpoint);
}
function createKeypairFromSecretKey(secretKey) {
    return web3_js_1.Keypair.fromSecretKey(secretKey);
} //# sourceMappingURL=Connection.js.map
}}),
"[project]/node_modules/.pnpm/@3land+listings-sdk@0.0.4_@types+node@20.17.14_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.1_hcq54orvwwwhxfa45fjs36zq7a/node_modules/@3land/listings-sdk/dist/utility/PdaManager.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getATAPDA = exports.treeAuthority = exports.buyPaymentPDA = exports.collectorGlobalRegistryPDA = exports.collectorArtistRegistryPDA = exports.userActivityPDA = exports.creatorRegistryPDA = exports.collectionAuthorityRecord = exports.getEditionPDA = exports.getMetadataPDA = exports.toPublicKey = exports.METADATA_PREFIX = void 0;
exports.holderPDA = holderPDA;
exports.holderAccountPDA = holderAccountPDA;
exports.storePDA = storePDA;
exports.creatorAuthorityPDA = creatorAuthorityPDA;
exports.itemAccountPDA = itemAccountPDA;
exports.itemReserveListPDA = itemReserveListPDA;
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
const programId_1 = __turbopack_require__("[project]/node_modules/.pnpm/@3land+listings-sdk@0.0.4_@types+node@20.17.14_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.1_hcq54orvwwwhxfa45fjs36zq7a/node_modules/@3land/listings-sdk/dist/types/programId.js [app-route] (ecmascript)");
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
exports.METADATA_PREFIX = "metadata";
function holderPDA({ creator, slot }) {
    if (!slot) slot = 0;
    creator = (0, exports.toPublicKey)(creator);
    return web3_js_1.PublicKey.findProgramAddress([
        Buffer.from("holder"),
        creator.toBytes(),
        new bn_js_1.default(slot).toArrayLike(Buffer, "le", 8)
    ], (0, exports.toPublicKey)(programId_1.PROGRAM_ID));
}
function holderAccountPDA({ creator, slot }) {
    if (!slot) slot = 0;
    creator = (0, exports.toPublicKey)(creator);
    return web3_js_1.PublicKey.findProgramAddress([
        Buffer.from("holder_account"),
        creator.toBytes(),
        new bn_js_1.default(slot).toArrayLike(Buffer, "le", 8)
    ], (0, exports.toPublicKey)(programId_1.PROGRAM_ID));
}
function storePDA({ storeId, creator, holder }) {
    holder = (0, exports.toPublicKey)(holder);
    creator = (0, exports.toPublicKey)(creator);
    if (!storeId?.toNumber) storeId = new bn_js_1.default(storeId);
    return web3_js_1.PublicKey.findProgramAddress([
        Buffer.from("store"),
        holder.toBytes(),
        creator.toBytes(),
        storeId.toArrayLike(Buffer, "le", 2)
    ], (0, exports.toPublicKey)(programId_1.PROGRAM_ID));
}
function creatorAuthorityPDA({ creator, store }) {
    store = (0, exports.toPublicKey)(store);
    creator = (0, exports.toPublicKey)(creator);
    return web3_js_1.PublicKey.findProgramAddress([
        Buffer.from("creator_authority"),
        store.toBytes(),
        creator.toBytes()
    ], (0, exports.toPublicKey)(programId_1.PROGRAM_ID));
}
function itemAccountPDA({ creator, store, identifier }) {
    store = (0, exports.toPublicKey)(store);
    creator = (0, exports.toPublicKey)(creator);
    return web3_js_1.PublicKey.findProgramAddress([
        Buffer.from("item_account"),
        store.toBytes(),
        creator.toBytes(),
        identifier.toArrayLike(Buffer, "le", 8)
    ], (0, exports.toPublicKey)(programId_1.PROGRAM_ID));
}
function itemReserveListPDA({ item }) {
    item = (0, exports.toPublicKey)(item);
    return web3_js_1.PublicKey.findProgramAddress([
        Buffer.from("item_reserve_list"),
        item.toBytes()
    ], (0, exports.toPublicKey)(programId_1.PROGRAM_ID));
}
const toPublicKey = (key)=>{
    if (typeof key !== "string") return key;
    const PubKeysInternedMap = new Map();
    let result = PubKeysInternedMap.get(key);
    if (!result) {
        result = new web3_js_1.PublicKey(key);
        PubKeysInternedMap.set(key, result);
    }
    return result;
};
exports.toPublicKey = toPublicKey;
const getMetadataPDA = async (mint)=>{
    const [publicKey] = await web3_js_1.PublicKey.findProgramAddress([
        Buffer.from("metadata"),
        programId_1.TOKEN_METADATA_PROGRAM_ID.toBuffer(),
        mint.toBuffer()
    ], programId_1.TOKEN_METADATA_PROGRAM_ID //PROGRAM_ID
    );
    return publicKey;
};
exports.getMetadataPDA = getMetadataPDA;
const getEditionPDA = async (mint, full)=>{
    return await web3_js_1.PublicKey.findProgramAddress([
        Buffer.from(exports.METADATA_PREFIX),
        (0, exports.toPublicKey)(programId_1.TOKEN_METADATA_PROGRAM_ID).toBuffer(),
        mint.toBuffer(),
        Buffer.from("edition")
    ], (0, exports.toPublicKey)(programId_1.TOKEN_METADATA_PROGRAM_ID));
};
exports.getEditionPDA = getEditionPDA;
const collectionAuthorityRecord = async ({ mint, new_authority })=>{
    mint = (0, exports.toPublicKey)(mint);
    new_authority = (0, exports.toPublicKey)(new_authority);
    return web3_js_1.PublicKey.findProgramAddress([
        Buffer.from("metadata"),
        programId_1.TOKEN_METADATA_PROGRAM_ID.toBuffer(),
        mint.toBuffer(),
        Buffer.from("collection_authority"),
        new_authority.toBuffer()
    ], programId_1.TOKEN_METADATA_PROGRAM_ID);
};
exports.collectionAuthorityRecord = collectionAuthorityRecord;
const creatorRegistryPDA = ({ user, currency, store })=>{
    user = (0, exports.toPublicKey)(user);
    currency = (0, exports.toPublicKey)(currency);
    store = (0, exports.toPublicKey)(store);
    return web3_js_1.PublicKey.findProgramAddress([
        Buffer.from("creator_registry"),
        currency.toBytes(),
        user.toBytes(),
        store.toBytes()
    ], (0, exports.toPublicKey)(programId_1.PROGRAM_ID));
};
exports.creatorRegistryPDA = creatorRegistryPDA;
const userActivityPDA = async ({ user, store })=>{
    user = (0, exports.toPublicKey)(user);
    store = (0, exports.toPublicKey)(store);
    return web3_js_1.PublicKey.findProgramAddress([
        Buffer.from("user_activity_tracking"),
        user.toBytes(),
        store.toBytes()
    ], (0, exports.toPublicKey)(programId_1.PROGRAM_ID));
};
exports.userActivityPDA = userActivityPDA;
const collectorArtistRegistryPDA = async ({ user, artist, currency, store })=>{
    user = (0, exports.toPublicKey)(user);
    currency = (0, exports.toPublicKey)(currency);
    artist = (0, exports.toPublicKey)(artist);
    store = (0, exports.toPublicKey)(store);
    return web3_js_1.PublicKey.findProgramAddress([
        Buffer.from("collectors_artist_registry"),
        user.toBytes(),
        currency.toBytes(),
        artist.toBytes(),
        store.toBytes()
    ], (0, exports.toPublicKey)(programId_1.PROGRAM_ID));
};
exports.collectorArtistRegistryPDA = collectorArtistRegistryPDA;
const collectorGlobalRegistryPDA = ({ user, currency, store })=>{
    user = (0, exports.toPublicKey)(user);
    currency = (0, exports.toPublicKey)(currency);
    store = (0, exports.toPublicKey)(store);
    return web3_js_1.PublicKey.findProgramAddress([
        Buffer.from("collectors_global_registry"),
        user.toBytes(),
        currency.toBytes(),
        store.toBytes()
    ], (0, exports.toPublicKey)(programId_1.PROGRAM_ID));
};
exports.collectorGlobalRegistryPDA = collectorGlobalRegistryPDA;
const buyPaymentPDA = ({ owner, itemAccount })=>{
    owner = (0, exports.toPublicKey)(owner);
    itemAccount = (0, exports.toPublicKey)(itemAccount);
    return web3_js_1.PublicKey.findProgramAddress([
        Buffer.from("buy_payment"),
        owner.toBytes(),
        itemAccount.toBytes()
    ], (0, exports.toPublicKey)(programId_1.PROGRAM_ID));
};
exports.buyPaymentPDA = buyPaymentPDA;
const treeAuthority = ({ tree })=>{
    tree = (0, exports.toPublicKey)(tree);
    return web3_js_1.PublicKey.findProgramAddressSync([
        tree.toBuffer()
    ], (0, exports.toPublicKey)(programId_1.BUBBLEGUM_PROGRAM_ID));
};
exports.treeAuthority = treeAuthority;
const getATAPDA = async ({ owner, mint })=>{
    const [publicKey] = await web3_js_1.PublicKey.findProgramAddress([
        (0, exports.toPublicKey)(owner).toBuffer(),
        programId_1.TOKEN_PROGRAM_ID.toBuffer(),
        (0, exports.toPublicKey)(mint).toBuffer()
    ], programId_1.SPL_ASSOCIATED_TOKEN_ACCOUNT_PROGRAM_ID);
    return publicKey;
};
exports.getATAPDA = getATAPDA; //# sourceMappingURL=PdaManager.js.map
}}),
"[project]/node_modules/.pnpm/@3land+listings-sdk@0.0.4_@types+node@20.17.14_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.1_hcq54orvwwwhxfa45fjs36zq7a/node_modules/@3land/listings-sdk/dist/utility/utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.checkCategory = exports.checkFileType = exports.validateSolAddress = exports.nowS = exports.sleep = exports.cyrb53 = void 0;
exports.bytesToU32 = bytesToU32;
exports.normalizeFileData = normalizeFileData;
exports.getUrlFileType = getUrlFileType;
exports.getFileType = getFileType;
exports.validateFileType = validateFileType;
exports.getFileCategory = getFileCategory;
exports.isAnimatable = isAnimatable;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const node_fetch_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/node-fetch@3.3.2/node_modules/node-fetch/src/index.js [app-route] (ecmascript)"));
function bytesToU32(slice) {
    let result = 0;
    for(let i = slice.length - 1; i >= 0; i--){
        result = result << 8 | slice[i];
    }
    return result >>> 0;
}
const cyrb53 = (str, seed = 0)=>{
    let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
    let arr = null;
    if (typeof str != "string") {
        if (Array.isArray(str)) {
            arr = str;
        } else {
            str = str + "";
        }
    }
    if (arr) {
        for (const ch of arr){
            h1 = Math.imul(h1 ^ ch, 2654435761);
            h2 = Math.imul(h2 ^ ch, 1597334677);
        }
    } else {
        for(let i = 0, ch; i < str.length; i++){
            ch = str.charCodeAt(i);
            h1 = Math.imul(h1 ^ ch, 2654435761);
            h2 = Math.imul(h2 ^ ch, 1597334677);
        }
    }
    h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507) ^ Math.imul(h2 ^ h2 >>> 13, 3266489909);
    h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507) ^ Math.imul(h1 ^ h1 >>> 13, 3266489909);
    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
};
exports.cyrb53 = cyrb53;
const sleep = (t)=>{
    return new Promise((res)=>{
        setTimeout(res, t);
    });
};
exports.sleep = sleep;
const nowS = ()=>Date.now() / 1000;
exports.nowS = nowS;
const validateSolAddress = (address)=>{
    try {
        let pubkey = new web3_js_1.PublicKey(address);
        return web3_js_1.PublicKey.isOnCurve(pubkey.toBuffer());
    } catch (error) {
        return false;
    }
};
exports.validateSolAddress = validateSolAddress;
const checkFileType = (file)=>{
    return file?.type?.includes("video/webp") ? "video/webp" : file?.type?.includes("image/webp") ? "image/webp" : file?.type?.includes("jpeg") || file?.type?.includes("jpg") ? "image/jpeg" : file?.type?.includes("gif") ? "image/gif" : file?.type?.includes("png") ? "image/png" : file?.type?.includes("audio") ? "audio" : file?.type?.includes("mp4") ? "video/mp4" : file?.name?.includes("glb") || file?.type?.includes("model") ? "model/gltf-binary" : null;
};
exports.checkFileType = checkFileType;
const checkCategory = (file)=>{
    return file?.type?.includes("image") ? "image" : file?.type?.includes("audio") ? "audio" : file?.type?.includes("video") ? "video" : file?.name?.includes("glb") || file?.type?.includes("model") ? "vr" : null;
};
exports.checkCategory = checkCategory;
async function normalizeFileData(fileData) {
    try {
        const buffer = await (fileData.arrayBuffer instanceof Function ? fileData.arrayBuffer() : Promise.resolve(fileData.arrayBuffer));
        const type = fileData.type || getMimeTypeFromBuffer(buffer);
        return {
            arrayBuffer: ()=>buffer,
            type,
            size: buffer.byteLength,
            name: fileData.name
        };
    } catch (error) {
        throw new Error(`Failed to normalize file data: ${error}`);
    }
}
function getMimeTypeFromBuffer(buffer) {
    const arr = new Uint8Array(buffer).subarray(0, 12);
    const header = Array.from(arr).map((byte)=>byte.toString(16)).join("");
    if (header.startsWith("89504e47")) return "image/png";
    if (header.startsWith("474946")) return "image/gif";
    if (header.startsWith("ffd8ff")) return "image/jpeg";
    if (header.startsWith("52494646") && header.includes("57454250")) return "image/webp";
    if (header.startsWith("494433") || header.startsWith("fffb")) return "audio/mp3";
    if (header.startsWith("000000") && (header.includes("66747970") || header.includes("6d6f6f76"))) return "video/mp4";
    if (header.startsWith("676c5446")) return "model/gltf-binary";
    return "application/octet-stream";
}
async function getUrlFileType(fileUrl) {
    try {
        // Fetch only the first 12 bytes of the file first to check if the file exists
        const headResponse = await (0, node_fetch_1.default)(fileUrl, {
            method: "HEAD"
        });
        if (!headResponse.ok) {
            throw new Error(`Failed to fetch file: ${headResponse.statusText}`);
        }
        // Then fetch the beginning of the file using a range request
        const response = await (0, node_fetch_1.default)(fileUrl, {
            headers: {
                Range: "bytes=0-11"
            }
        });
        if (!response.ok) {
            // If range request is not supported, fetch a small part of the file
            const fullResponse = await (0, node_fetch_1.default)(fileUrl);
            if (!fullResponse.ok) {
                throw new Error(`Failed to fetch file: ${fullResponse.statusText}`);
            }
            const buffer = await fullResponse.arrayBuffer();
            // Only take the first 12 bytes
            const slicedBuffer = buffer.slice(0, 12);
            return getMimeTypeFromBuffer(slicedBuffer);
        }
        const buffer = await response.arrayBuffer();
        const fileType = getMimeTypeFromBuffer(buffer);
        console.log("file type in getUrl: ", fileType);
        return fileType;
    } catch (error) {
        console.error("Error getting file type from URL:", error);
        return "application/octet-stream"; // Default type if we can't determine the actual type
    }
}
function getFileType(file) {
    if (!file) return null;
    const type = file.type?.toLowerCase() || "";
    const name = (file.name || "").toLowerCase();
    if (type.includes("video/webp")) return "video/webp";
    if (type.includes("image/webp")) return "image/webp";
    if (type.includes("jpeg") || type.includes("jpg")) return "image/jpeg";
    if (type.includes("gif")) return "image/gif";
    if (type.includes("png")) return "image/png";
    if (type.includes("mp3") || type.includes("audio/mp3")) return "audio/mp3";
    if (type.includes("mp4")) return "video/mp4";
    if (type.includes("glb") || name.endsWith(".glb")) return "model/gltf-binary";
    return type || null;
}
function validateFileType(type) {
    const allowedTypes = [
        "image/png",
        "image/jpeg",
        "image/gif",
        "image/webp",
        "video/mp4",
        "audio/mp3",
        "model/gltf-binary",
        "application/octet-stream"
    ];
    if (!allowedTypes.includes(type)) {
        throw new Error(`Unsupported file type: ${type}`);
    }
}
function getFileCategory(file) {
    if (!file) return null;
    const type = (file.type || "").toLowerCase();
    const name = (file.name || "").toLowerCase();
    if (type.includes("image")) return "image";
    if (type.includes("audio")) return "audio";
    if (type.includes("video")) return "video";
    if (type.includes("model") || name.endsWith(".glb")) return "vr";
    return null;
}
function isAnimatable(type) {
    return type?.includes("video/") || type?.includes("audio/") || type === "model/gltf-binary";
} //# sourceMappingURL=utils.js.map
}}),
"[project]/node_modules/.pnpm/@3land+listings-sdk@0.0.4_@types+node@20.17.14_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.1_hcq54orvwwwhxfa45fjs36zq7a/node_modules/@3land/listings-sdk/dist/utility/Holders.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.mainnetHolder = exports.devnetHolder = void 0;
exports.devnetHolder = {
    creator: "7fmpv3iEP1EYVgbnbvfrv8r99hdqpvGAPmtkpqGXztAv",
    slot: 26
};
exports.mainnetHolder = {
    creator: "6xzPPWsWjV2bvAufWHJHdfNrNqgbeS46yVPPofEQuJPL",
    slot: 69
}; //# sourceMappingURL=Holders.js.map
}}),
"[project]/node_modules/.pnpm/@3land+listings-sdk@0.0.4_@types+node@20.17.14_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.1_hcq54orvwwwhxfa45fjs36zq7a/node_modules/@3land/listings-sdk/dist/utility/validation.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ValidationError = void 0;
exports.validateStoreConfig = validateStoreConfig;
exports.validateMetadata = validateMetadata;
exports.validateSaleConfig = validateSaleConfig;
exports.validateSupply = validateSupply;
exports.validateIdentifier = validateIdentifier;
exports.validateCollectionArgs = validateCollectionArgs;
exports.validateBuySingleArgs = validateBuySingleArgs;
const web3_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/@solana+web3.js@1.98.0_bufferutil@4.0.9_encoding@0.1.13_utf-8-validate@5.0.10/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
const bn_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)");
class ValidationError extends Error {
    constructor(message){
        super(message);
        this.name = "ValidationError";
    }
}
exports.ValidationError = ValidationError;
function validateStoreConfig(config) {
    if (!config.fee || !(config.fee instanceof bn_js_1.BN)) {
        throw new ValidationError("Store fee must be a valid BN instance");
    }
    if (typeof config.feePercentage !== "number" || config.feePercentage < 0 || config.feePercentage > 100) {
        throw new ValidationError("Fee percentage must be a number between 0 and 100");
    }
    if (!config.trust || !(config.trust instanceof web3_js_1.PublicKey)) {
        throw new ValidationError("Trust must be a valid PublicKey");
    }
}
function validateMetadata(metadata) {
    if (!metadata.name || metadata.name.length > 32) {
        throw new ValidationError("Metadata name is required and must be <= 32 characters");
    }
    if (metadata.uriType !== 0 && metadata.uriType !== 1) {
        throw new ValidationError("Invalid URI type");
    }
    if (!metadata.creators || !metadata.creators.length) {
        throw new ValidationError("At least one creator is required");
    }
    const totalShares = metadata.creators.reduce((sum, creator)=>sum + creator.share, 0);
    if (totalShares !== 100) {
        throw new ValidationError("Creator shares must sum to 100");
    }
}
function validateSaleConfig(config) {
    // if (!config.prices || !config.prices.length) {
    //   throw new ValidationError("At least one price configuration is required");
    // }
    // config.prices.forEach((price) => {
    //   if (!price.amount || !(price.amount instanceof BN)) {
    //     throw new ValidationError(
    //       "Each price amount must be a valid BN instance"
    //     );
    //   }
    // });
    if (config.sendToVault < 0) {
        throw new ValidationError("sendToVault must be non-negative");
    }
}
function validateSupply(supply) {
    if (typeof supply !== "number" || supply < 0) {
        throw new ValidationError("Supply must be a non-negative number");
    }
}
function validateIdentifier(identifier) {
    if (typeof identifier !== "number" || identifier < 0) {
        throw new ValidationError("Identifier must be a non-negative number");
    }
}
function validateCollectionArgs(collectionDetails, supply, metadata, irysData) {
    if (!collectionDetails || typeof collectionDetails.__kind !== "string") {
        throw new ValidationError("Invalid collection details format");
    }
    if (typeof supply !== "number" || supply < 0) {
        throw new ValidationError("Supply must be a non-negative number");
    }
    if (!metadata) {
        throw new ValidationError("Metadata is required");
    }
    // Validate metadata fields
    if (!metadata.symbol || metadata.symbol.length > 10) {
        throw new ValidationError("Symbol is required and must be <= 10 characters");
    }
    if (!metadata.name || metadata.name.length > 32) {
        throw new ValidationError("Name is required and must be <= 32 characters");
    }
    if (!metadata.creators || !Array.isArray(metadata.creators)) {
        throw new ValidationError("Creators array is required");
    }
    const totalShares = metadata.creators.reduce((sum, creator)=>sum + creator.share, 0);
    if (totalShares !== 100) {
        throw new ValidationError("Creator shares must sum to 100");
    }
    // Validate Irys data
    if (!irysData || !irysData.options || !irysData.options.metadata) {
        throw new ValidationError("Invalid Irys data format");
    }
    if (!irysData.options.metadata.files || !irysData.options.metadata.files.file) {
        throw new ValidationError("Collection image file is required");
    }
}
function validateBuySingleArgs(payer, packAccount, burnProgress, owner, distributionBumps, globalStoreAccount, extraAccounts, collectionAddress, storeAccount, creator) {
    if (!payer || !payer.publicKey) {
        throw new ValidationError("Invalid payer");
    }
    if (!web3_js_1.PublicKey.isOnCurve(packAccount)) {
        throw new ValidationError("Invalid pack account public key");
    }
    if (!web3_js_1.PublicKey.isOnCurve(burnProgress)) {
        throw new ValidationError("Invalid burn progress public key");
    }
    if (!web3_js_1.PublicKey.isOnCurve(owner)) {
        throw new ValidationError("Invalid owner public key");
    }
    if (!Array.isArray(distributionBumps) || distributionBumps.length !== 6) {
        throw new ValidationError("Distribution bumps must be an array of length 6");
    }
    distributionBumps.forEach((bump, index)=>{
        if (typeof bump !== "number" || bump < 0 || bump > 255) {
            throw new ValidationError(`Invalid distribution bump at index ${index}`);
        }
    });
    if (!storeAccount) {
        throw new ValidationError("Store account missing");
    }
    if (web3_js_1.PublicKey.isOnCurve(storeAccount)) {
        throw new ValidationError("Invalid store account public key");
    }
    if (web3_js_1.PublicKey.isOnCurve(globalStoreAccount)) {
        throw new ValidationError("Invalid global store account public key");
    }
    if (!collectionAddress) {
        throw new ValidationError("Collection address missing");
    }
    if (!web3_js_1.PublicKey.isOnCurve(collectionAddress)) {
        throw new ValidationError("Invalid collection address public key");
    }
    if (!creator) {
        throw new ValidationError("Creator public key missing");
    }
    if (!web3_js_1.PublicKey.isOnCurve(creator)) {
        throw new ValidationError("Invalid creator public key");
    }
    if (!Array.isArray(extraAccounts)) {
        throw new ValidationError("Extra accounts must be an array");
    }
    extraAccounts.forEach((account, index)=>{
        if (!account.pubkey || web3_js_1.PublicKey.isOnCurve(account.pubkey)) {
            throw new ValidationError(`Invalid public key in extra accounts at index ${index}`);
        }
        if (typeof account.isSigner !== "boolean") {
            throw new ValidationError(`Invalid isSigner flag in extra accounts at index ${index}`);
        }
        if (typeof account.isWritable !== "boolean") {
            throw new ValidationError(`Invalid isWritable flag in extra accounts at index ${index}`);
        }
    });
} //# sourceMappingURL=validation.js.map
}}),
"[project]/node_modules/.pnpm/@3land+listings-sdk@0.0.4_@types+node@20.17.14_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.1_hcq54orvwwwhxfa45fjs36zq7a/node_modules/@3land/listings-sdk/dist/utility/config.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.NETWORK_CONFIGS = exports.NetworkType = void 0;
const programId_1 = __turbopack_require__("[project]/node_modules/.pnpm/@3land+listings-sdk@0.0.4_@types+node@20.17.14_arweave@1.15.5_bufferutil@4.0.9_encoding@0.1.1_hcq54orvwwwhxfa45fjs36zq7a/node_modules/@3land/listings-sdk/dist/types/programId.js [app-route] (ecmascript)");
var NetworkType;
(function(NetworkType) {
    NetworkType["DEVNET"] = "devnet";
    NetworkType["MAINNET"] = "mainnet-beta";
})(NetworkType || (exports.NetworkType = NetworkType = {}));
exports.NETWORK_CONFIGS = {
    [NetworkType.DEVNET]: {
        endpoint: "https://api.devnet.solana.com",
        programId: programId_1.PROGRAM_CNFT,
        tokenProgramId: programId_1.TOKEN_PROGRAM_ID,
        metadataProgramId: programId_1.TOKEN_METADATA_PROGRAM_ID
    },
    [NetworkType.MAINNET]: {
        endpoint: "https://api.mainnet-beta.solana.com",
        programId: programId_1.PROGRAM_CNFT,
        tokenProgramId: programId_1.TOKEN_PROGRAM_ID,
        metadataProgramId: programId_1.TOKEN_METADATA_PROGRAM_ID
    }
}; //# sourceMappingURL=config.js.map
}}),

};

//# sourceMappingURL=e5873_%403land_listings-sdk_dist_utility_2b96c5._.js.map
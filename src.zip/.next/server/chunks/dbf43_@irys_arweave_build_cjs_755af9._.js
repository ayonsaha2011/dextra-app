module.exports = {

"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/crypto/pem.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.jwkTopem = exports.pemTojwk = exports.RSA_OID = void 0;
// @ts-expect-error no typing :c
const api_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/asn1.js@5.4.1/node_modules/asn1.js/lib/asn1/api.js [app-route] (ecmascript)"));
const define = api_1.default.define;
const bn_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bn.js@5.2.1/node_modules/bn.js/lib/bn.js [app-route] (ecmascript)"));
function urlize(base64) {
    return base64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
function hex2b64url(str) {
    return urlize(Buffer.from(str, "hex").toString("base64"));
}
const RSAPublicKey = define("RSAPublicKey", function() {
    this.seq().obj(this.key("n").int(), this.key("e").int());
});
const AlgorithmIdentifier = define("AlgorithmIdentifier", function() {
    this.seq().obj(this.key("algorithm").objid(), this.key("parameters").optional().any());
});
const PublicKeyInfo = define("PublicKeyInfo", function() {
    this.seq().obj(this.key("algorithm").use(AlgorithmIdentifier), this.key("publicKey").bitstr());
});
const Version = define("Version", function() {
    this.int({
        0: "two-prime",
        1: "multi"
    });
});
const OtherPrimeInfos = define("OtherPrimeInfos", function() {
    this.seq().obj(this.key("ri").int(), this.key("di").int(), this.key("ti").int());
});
const RSAPrivateKey = define("RSAPrivateKey", function() {
    this.seq().obj(this.key("version").use(Version), this.key("n").int(), this.key("e").int(), this.key("d").int(), this.key("p").int(), this.key("q").int(), this.key("dp").int(), this.key("dq").int(), this.key("qi").int(), this.key("other").optional().use(OtherPrimeInfos));
});
const PrivateKeyInfo = define("PrivateKeyInfo", function() {
    this.seq().obj(this.key("version").use(Version), this.key("algorithm").use(AlgorithmIdentifier), this.key("privateKey").bitstr());
});
exports.RSA_OID = "1.2.840.113549.1.1.1";
function addExtras(obj, extras) {
    extras = extras || {};
    Object.keys(extras).forEach(function(key) {
        obj[key] = extras[key];
    });
    return obj;
}
function pad(hex) {
    return hex.length % 2 === 1 ? "0" + hex : hex;
}
function decodeRsaPublic(buffer, extras) {
    const key = RSAPublicKey.decode(buffer, "der");
    const e = pad(key.e.toString(16));
    const jwk = {
        kty: "RSA",
        n: bn2base64url(key.n),
        e: hex2b64url(e)
    };
    return addExtras(jwk, extras);
}
function decodeRsaPrivate(buffer, extras) {
    const key = RSAPrivateKey.decode(buffer, "der");
    const e = pad(key.e.toString(16));
    const jwk = {
        kty: "RSA",
        n: bn2base64url(key.n),
        e: hex2b64url(e),
        d: bn2base64url(key.d),
        p: bn2base64url(key.p),
        q: bn2base64url(key.q),
        dp: bn2base64url(key.dp),
        dq: bn2base64url(key.dq),
        qi: bn2base64url(key.qi)
    };
    return addExtras(jwk, extras);
}
function decodePublic(buffer, extras) {
    const info = PublicKeyInfo.decode(buffer, "der");
    return decodeRsaPublic(info.publicKey.data, extras);
}
function decodePrivate(buffer, extras) {
    const info = PrivateKeyInfo.decode(buffer, "der");
    return decodeRsaPrivate(info.privateKey.data, extras);
}
function getDecoder(header) {
    const match = /^-----BEGIN (RSA )?(PUBLIC|PRIVATE) KEY-----$/.exec(header);
    if (!match) {
        return null;
    }
    const isRSA = !!match[1];
    const isPrivate = match[2] === "PRIVATE";
    if (isPrivate) {
        return isRSA ? decodeRsaPrivate : decodePrivate;
    } else {
        return isRSA ? decodeRsaPublic : decodePublic;
    }
}
function parse(jwk) {
    return {
        n: string2bn(jwk.n),
        e: string2bn(jwk.e),
        d: jwk.d && string2bn(jwk.d),
        p: jwk.p && string2bn(jwk.p),
        q: jwk.q && string2bn(jwk.q),
        dp: jwk.dp && string2bn(jwk.dp),
        dq: jwk.dq && string2bn(jwk.dq),
        qi: jwk.qi && string2bn(jwk.qi)
    };
}
function bn2base64url(bn) {
    return hex2b64url(pad(bn.toString(16)));
}
function base64url2bn(str) {
    return new bn_js_1.default(Buffer.from(str, "base64"));
}
function string2bn(str) {
    if (/^[0-9]+$/.test(str)) {
        return new bn_js_1.default(str, 10);
    }
    return base64url2bn(str);
}
function pemTojwk(pem, extras) {
    let text = pem.toString().split(/(\r\n|\r|\n)+/g);
    text = text.filter(function(line) {
        return line.trim().length !== 0;
    });
    const decoder = getDecoder(text[0]);
    text = text.slice(1, -1).join("");
    return decoder(Buffer.from(text.replace(/[^\w\d\+\/=]+/g, ""), "base64"), extras);
}
exports.pemTojwk = pemTojwk;
function jwkTopem(json) {
    const jwk = parse(json);
    const isPrivate = !!jwk.d;
    const t = isPrivate ? "PRIVATE" : "PUBLIC";
    const header = "-----BEGIN RSA " + t + " KEY-----\n";
    const footer = "\n-----END RSA " + t + " KEY-----\n";
    let data = Buffer.alloc(0);
    if (isPrivate) {
        jwk.version = "two-prime";
        data = RSAPrivateKey.encode(jwk, "der");
    } else {
        data = RSAPublicKey.encode(jwk, "der");
    }
    const body = data.toString("base64").match(/.{1,64}/g).join("\n");
    return header + body + footer;
}
exports.jwkTopem = jwkTopem; //# sourceMappingURL=pem.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/node-driver.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.NodeCryptoDriver = void 0;
const pem_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/crypto/pem.js [app-route] (ecmascript)");
const crypto = __importStar(__turbopack_require__("[externals]/crypto [external] (crypto, cjs)"));
class NodeCryptoDriver {
    constructor(){
        this.keyLength = 4096;
        this.publicExponent = 0x10001;
        this.hashAlgorithm = "sha256";
        this.encryptionAlgorithm = "aes-256-cbc";
    }
    generateJWK() {
        if (typeof crypto.generateKeyPair !== "function") {
            throw new Error("Keypair generation not supported in this version of Node, only supported in versions 10+");
        }
        return new Promise((resolve, reject)=>{
            crypto.generateKeyPair("rsa", {
                modulusLength: this.keyLength,
                publicExponent: this.publicExponent,
                privateKeyEncoding: {
                    type: "pkcs1",
                    format: "pem"
                },
                publicKeyEncoding: {
                    type: "pkcs1",
                    format: "pem"
                }
            }, (err, _publicKey, privateKey)=>{
                if (err) {
                    reject(err);
                }
                resolve(this.pemToJWK(privateKey));
            });
        });
    }
    sign(jwk, data, { saltLength } = {}) {
        return new Promise((resolve)=>{
            resolve(crypto.createSign(this.hashAlgorithm).update(data).sign({
                key: this.jwkToPem(jwk),
                padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
                saltLength
            }));
        });
    }
    verify(publicModulus, data, signature) {
        return new Promise((resolve)=>{
            const publicKey = {
                kty: "RSA",
                e: "AQAB",
                n: publicModulus
            };
            const pem = this.jwkToPem(publicKey);
            resolve(crypto.createVerify(this.hashAlgorithm).update(data).verify({
                key: pem,
                padding: crypto.constants.RSA_PKCS1_PSS_PADDING
            }, signature));
        });
    }
    hash(data, algorithm = "SHA-256") {
        return new Promise((resolve)=>{
            resolve(crypto.createHash(this.parseHashAlgorithm(algorithm)).update(data).digest());
        });
    }
    /**
     * If a key is passed as a buffer it *must* be exactly 32 bytes.
     * If a key is passed as a string then any length may be used.
     *
     * @param {Buffer} data
     * @param {(string | Buffer)} key
     * @returns {Promise<Uint8Array>}
     */ encrypt(data, key, salt) {
        return __awaiter(this, void 0, void 0, function*() {
            // create a random string for deriving the key
            // const salt = crypto.randomBytes(16);
            // console.log(salt);
            // As we're using CBC with a randomised IV per cypher we don't really need
            // an additional random salt per passphrase.
            const derivedKey = crypto.pbkdf2Sync(key, salt = salt ? salt : "salt", 100000, 32, this.hashAlgorithm);
            const iv = crypto.randomBytes(16);
            const cipher = crypto.createCipheriv(this.encryptionAlgorithm, derivedKey, iv);
            const encrypted = Buffer.concat([
                iv,
                cipher.update(data),
                cipher.final()
            ]);
            return encrypted;
        });
    }
    /**
     * If a key is passed as a buffer it *must* be exactly 32 bytes.
     * If a key is passed as a string then any length may be used.
     *
     * @param {Buffer} encrypted
     * @param {(string | Buffer)} key
     * @returns {Promise<Uint8Array>}
     */ decrypt(encrypted, key, salt) {
        return __awaiter(this, void 0, void 0, function*() {
            try {
                // create a random string for deriving the key
                // const salt = crypto.randomBytes(16).toString('hex');
                // As we're using CBC with a randomised IV per cypher we don't really need
                // an additional random salt per passphrase.
                const derivedKey = crypto.pbkdf2Sync(key, salt = salt ? salt : "salt", 100000, 32, this.hashAlgorithm);
                const iv = encrypted.slice(0, 16);
                const data = encrypted.slice(16);
                const decipher = crypto.createDecipheriv(this.encryptionAlgorithm, derivedKey, iv);
                const decrypted = Buffer.concat([
                    decipher.update(data),
                    decipher.final()
                ]);
                return decrypted;
            } catch (error) {
                throw new Error("Failed to decrypt");
            }
        });
    }
    jwkToPem(jwk) {
        return (0, pem_1.jwkTopem)(jwk);
    }
    pemToJWK(pem) {
        const jwk = (0, pem_1.pemTojwk)(pem);
        return jwk;
    }
    parseHashAlgorithm(algorithm) {
        switch(algorithm){
            case "SHA-256":
                return "sha256";
            case "SHA-384":
                return "sha384";
            default:
                throw new Error(`Algorithm not supported: ${algorithm}`);
        }
    }
}
exports.NodeCryptoDriver = NodeCryptoDriver;
exports.default = NodeCryptoDriver; //# sourceMappingURL=node-driver.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/utils.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.arToWinston = exports.winstonToAr = exports.b64UrlDecode = exports.b64UrlEncode = exports.bufferTob64Url = exports.bufferTob64 = exports.b64UrlToBuffer = exports.stringToB64Url = exports.stringToBuffer = exports.bufferToString = exports.b64UrlToString = exports.concatBuffers = void 0;
const base64_js_1 = __turbopack_require__("[project]/node_modules/.pnpm/base64-js@1.5.1/node_modules/base64-js/index.js [app-route] (ecmascript)");
const bignumber_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
function concatBuffers(buffers) {
    let totalLength = 0;
    for (const b of buffers)totalLength += b.byteLength;
    const temp = new Uint8Array(totalLength);
    let offset = 0;
    temp.set(new Uint8Array(buffers[0]), offset);
    offset += buffers[0].byteLength;
    for(let i = 1; i < buffers.length; i++){
        temp.set(new Uint8Array(buffers[i]), offset);
        offset += buffers[i].byteLength;
    }
    return temp;
}
exports.concatBuffers = concatBuffers;
function b64UrlToString(b64UrlString) {
    const buffer = b64UrlToBuffer(b64UrlString);
    return bufferToString(buffer);
}
exports.b64UrlToString = b64UrlToString;
function bufferToString(buffer) {
    return new TextDecoder("utf-8", {
        fatal: true
    }).decode(buffer);
}
exports.bufferToString = bufferToString;
function stringToBuffer(string) {
    return new TextEncoder().encode(string);
}
exports.stringToBuffer = stringToBuffer;
function stringToB64Url(string) {
    return bufferTob64Url(stringToBuffer(string));
}
exports.stringToB64Url = stringToB64Url;
function b64UrlToBuffer(b64UrlString) {
    return new Uint8Array((0, base64_js_1.toByteArray)(b64UrlDecode(b64UrlString)));
}
exports.b64UrlToBuffer = b64UrlToBuffer;
function bufferTob64(buffer) {
    return (0, base64_js_1.fromByteArray)(new Uint8Array(buffer));
}
exports.bufferTob64 = bufferTob64;
function bufferTob64Url(buffer) {
    return b64UrlEncode(bufferTob64(buffer));
}
exports.bufferTob64Url = bufferTob64Url;
function b64UrlEncode(b64UrlString) {
    return b64UrlString.replace(/\+/g, "-").replace(/\//g, "_").replace(/\=/g, "");
}
exports.b64UrlEncode = b64UrlEncode;
function b64UrlDecode(b64UrlString) {
    b64UrlString = b64UrlString.replace(/\-/g, "+").replace(/\_/g, "/");
    let padding;
    b64UrlString.length % 4 == 0 ? padding = 0 : padding = 4 - b64UrlString.length % 4;
    return b64UrlString.concat("=".repeat(padding));
}
exports.b64UrlDecode = b64UrlDecode;
function winstonToAr(winston) {
    return new bignumber_js_1.default(winston).shiftedBy(-12);
}
exports.winstonToAr = winstonToAr;
function arToWinston(ar) {
    return new bignumber_js_1.default(ar).shiftedBy(12);
}
exports.arToWinston = arToWinston; //# sourceMappingURL=utils.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/transaction.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ArweaveTag = void 0;
/* eslint-disable no-case-declarations */ const ArweaveUtils = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/utils.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/utils.js [app-route] (ecmascript)");
class BaseObject {
    get(field, options) {
        if (!Object.getOwnPropertyNames(this).includes(field)) {
            throw new Error(`Field "${field}" is not a property of the Arweave Transaction class.`);
        }
        // Handle fields that are Uint8Arrays.
        // To maintain compat we encode them to b64url
        // if decode option is not specificed.
        if (this[field] instanceof Uint8Array) {
            if (options && options.decode && options.string) {
                return ArweaveUtils.bufferToString(this[field]);
            }
            if (options && options.decode && !options.string) {
                return this[field];
            }
            return ArweaveUtils.bufferTob64Url(this[field]);
        }
        if (this[field] instanceof Array) {
            if ((options === null || options === void 0 ? void 0 : options.decode) !== undefined || (options === null || options === void 0 ? void 0 : options.string) !== undefined) {
                if (field === "tags") {
                    console.warn(`Did you mean to use 'transaction["tags"]' ?`);
                }
                throw new Error(`Cannot decode or stringify an array.`);
            }
            return this[field];
        }
        if (options && options.decode == true) {
            if (options && options.string) {
                return ArweaveUtils.b64UrlToString(this[field]);
            }
            return ArweaveUtils.b64UrlToBuffer(this[field]);
        }
        return this[field];
    }
}
class ArweaveTag extends BaseObject {
    constructor(name, value /* _decode = false */ ){
        super();
        this.name = name;
        this.value = value;
    }
}
exports.ArweaveTag = ArweaveTag;
class Transaction extends BaseObject {
    constructor({ attributes, deps }){
        super();
        this.format = 2;
        this.id = "";
        this.last_tx = "";
        this.owner = "";
        this.tags = [];
        this.target = "";
        this.quantity = "0";
        this.data_size = "0";
        this.data = new Uint8Array();
        this.data_root = "";
        this.reward = "0";
        this.signature = "";
        this.merkle = deps.merkle;
        this.deepHash = deps.deepHash;
        Object.assign(this, attributes);
        // If something passes in a Tx that has been toJSON'ed and back,
        // or where the data was filled in from /tx/data endpoint.
        // data will be b64url encoded, so decode it.
        if (typeof this.data === "string") {
            this.data = ArweaveUtils.b64UrlToBuffer(this.data);
        }
        if (attributes.tags) {
            this.tags = attributes.tags /* .map((tag: { name: string; value: string }) => {
              return new Tag(tag.name, tag.value);
            }) */ ;
        }
    }
    addTag(name, value) {
        this.tags.push({
            name: ArweaveUtils.stringToB64Url(name),
            value: ArweaveUtils.stringToB64Url(value)
        });
    }
    toJSON() {
        return {
            format: this.format,
            id: this.id,
            last_tx: this.last_tx,
            owner: this.owner,
            tags: this.tags,
            target: this.target,
            quantity: this.quantity,
            data: ArweaveUtils.bufferTob64Url(this.data),
            data_size: this.data_size,
            data_root: this.data_root,
            data_tree: this.data_tree,
            reward: this.reward,
            signature: this.signature
        };
    }
    setOwner(owner) {
        this.owner = owner;
    }
    setSignature({ id, owner, reward, tags, signature }) {
        this.id = id;
        this.owner = owner;
        if (reward) this.reward = reward;
        if (tags) this.tags = tags;
        this.signature = signature;
    }
    prepareChunks(data) {
        return __awaiter(this, void 0, void 0, function*() {
            // Note: we *do not* use `this.data`, the caller may be
            // operating on a transaction with an zero length data field.
            // This function computes the chunks for the data passed in and
            // assigns the result to this transaction. It should not read the
            // data *from* this transaction.
            if (!this.chunks && data.byteLength > 0) {
                this.chunks = yield this.merkle.generateTransactionChunks(data);
                this.data_root = (0, utils_1.bufferTob64Url)(this.chunks.data_root);
            }
            if (!this.chunks && data.byteLength === 0) {
                this.chunks = {
                    chunks: [],
                    data_root: new Uint8Array(),
                    proofs: []
                };
                this.data_root = "";
            }
        });
    }
    // Returns a chunk in a format suitable for posting to /chunk.
    // Similar to `prepareChunks()` this does not operate `this.data`,
    // instead using the data passed in.
    getChunk(idx, data) {
        if (!this.chunks) {
            throw new Error(`Chunks have not been prepared`);
        }
        const proof = this.chunks.proofs[idx];
        const chunk = this.chunks.chunks[idx];
        return {
            data_root: this.data_root,
            data_size: this.data_size,
            data_path: ArweaveUtils.bufferTob64Url(proof.proof),
            offset: proof.offset.toString(),
            chunk: ArweaveUtils.bufferTob64Url(data.slice(chunk.minByteRange, chunk.maxByteRange))
        };
    }
    getSignatureData() {
        return __awaiter(this, void 0, void 0, function*() {
            switch(this.format){
                case 1:
                    const tags = this.tags.reduce((accumulator, tag)=>{
                        return ArweaveUtils.concatBuffers([
                            accumulator,
                            (0, utils_1.b64UrlToBuffer)(tag.name),
                            (0, utils_1.b64UrlToBuffer)(tag.value)
                        ]);
                    }, new Uint8Array());
                    return ArweaveUtils.concatBuffers([
                        this.get("owner", {
                            decode: true,
                            string: false
                        }),
                        this.get("target", {
                            decode: true,
                            string: false
                        }),
                        this.get("data", {
                            decode: true,
                            string: false
                        }),
                        ArweaveUtils.stringToBuffer(this.quantity),
                        ArweaveUtils.stringToBuffer(this.reward),
                        this.get("last_tx", {
                            decode: true,
                            string: false
                        }),
                        tags
                    ]);
                case 2:
                    if (!this.data_root) {
                        yield this.prepareChunks(this.data);
                    }
                    const tagList = this.tags.map((tag)=>[
                            (0, utils_1.b64UrlToBuffer)(tag.name),
                            (0, utils_1.b64UrlToBuffer)(tag.value)
                        ]);
                    return yield this.deepHash.deepHash([
                        ArweaveUtils.stringToBuffer(this.format.toString()),
                        this.get("owner", {
                            decode: true,
                            string: false
                        }),
                        this.get("target", {
                            decode: true,
                            string: false
                        }),
                        ArweaveUtils.stringToBuffer(this.quantity),
                        ArweaveUtils.stringToBuffer(this.reward),
                        this.get("last_tx", {
                            decode: true,
                            string: false
                        }),
                        tagList,
                        ArweaveUtils.stringToBuffer(this.data_size),
                        this.get("data_root", {
                            decode: true,
                            string: false
                        })
                    ]);
                default:
                    throw new Error(`Unexpected transaction format: ${this.format}`);
            }
        });
    }
}
exports.default = Transaction; //# sourceMappingURL=transaction.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/error.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getError = void 0;
class ArweaveError extends Error {
    constructor(type, optional = {}){
        if (optional.message) {
            super(optional.message);
        } else {
            super();
        }
        this.type = type;
        this.response = optional.response;
    }
    getType() {
        return this.type;
    }
}
exports.default = ArweaveError;
// Safely get error string
// from a response, falling back to
// resp.data, statusText or 'unknown'.
// Note: a wrongly set content-type can
// cause what is a json response to be interepted
// as a string or Buffer, so we handle that too.
function getError(resp) {
    let data = resp.data;
    if (typeof resp.data === "string") {
        try {
            data = JSON.parse(resp.data);
        } catch (e) {}
    }
    if (resp.data instanceof ArrayBuffer || resp.data instanceof Uint8Array) {
        try {
            data = JSON.parse(data.toString());
        } catch (e) {}
    }
    return data ? data.error || data : resp.statusText || "unknown";
}
exports.getError = getError; //# sourceMappingURL=error.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/blocks.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
/* eslint-disable @typescript-eslint/naming-convention */ const error_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/error.js [app-route] (ecmascript)"));
class Blocks {
    constructor(api, network){
        this.api = api;
        this.network = network;
    }
    /**
     * Gets a block by its "indep_hash"
     */ getByHash(indepHash) {
        return __awaiter(this, void 0, void 0, function*() {
            const response = yield this.api.get(`block/hash/${indepHash}`);
            if (response.status === 200) {
                return response.data;
            } else {
                if (response.status === 404) {
                    throw new error_1.default("BLOCK_NOT_FOUND" /* ArweaveErrorType.BLOCK_NOT_FOUND */ );
                } else {
                    throw new Error(`Error while loading block data: ${response}`);
                }
            }
        });
    }
    /**
     * Gets a block by its "indep_hash"
     */ getByHeight(height) {
        return __awaiter(this, void 0, void 0, function*() {
            const response = yield this.api.get(`block/height/${height}`);
            if (response.status === 200) {
                return response.data;
            } else {
                if (response.status === 404) {
                    throw new error_1.default("BLOCK_NOT_FOUND" /* ArweaveErrorType.BLOCK_NOT_FOUND */ );
                } else {
                    throw new Error(`Error while loading block data: ${response}`);
                }
            }
        });
    }
    /**
     * Gets current block data (ie. block with indep_hash = Network.getInfo().current)
     */ getCurrent() {
        return __awaiter(this, void 0, void 0, function*() {
            const { current } = yield this.network.getInfo();
            return yield this.getByHash(current);
        });
    }
}
exports.default = Blocks; //# sourceMappingURL=blocks.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/merkle.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.arrayCompare = exports.bufferToInt = exports.intToBuffer = exports.arrayFlatten = exports.Merkle = exports.MIN_CHUNK_SIZE = exports.MAX_CHUNK_SIZE = void 0;
/**
 * @see {@link https://github.com/ArweaveTeam/arweave/blob/fbc381e0e36efffa45d13f2faa6199d3766edaa2/apps/arweave/src/ar_merkle.erl}
 */ const arweave_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/arweave.js [app-route] (ecmascript)"));
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/utils.js [app-route] (ecmascript)");
exports.MAX_CHUNK_SIZE = 256 * 1024;
exports.MIN_CHUNK_SIZE = 32 * 1024;
const NOTE_SIZE = 32;
const HASH_SIZE = 32;
class Merkle {
    constructor(opts){
        this.crypto = opts.deps.crypto;
    }
    /**
     * Takes the input data and chunks it into (mostly) equal sized chunks.
     * The last chunk will be a bit smaller as it contains the remainder
     * from the chunking process.
     */ chunkData(data) {
        return __awaiter(this, void 0, void 0, function*() {
            const chunks = [];
            let rest = data;
            let cursor = 0;
            while(rest.byteLength >= exports.MAX_CHUNK_SIZE){
                let chunkSize = exports.MAX_CHUNK_SIZE;
                // If the total bytes left will produce a chunk < MIN_CHUNK_SIZE,
                // then adjust the amount we put in this 2nd last chunk.
                const nextChunkSize = rest.byteLength - exports.MAX_CHUNK_SIZE;
                if (nextChunkSize > 0 && nextChunkSize < exports.MIN_CHUNK_SIZE) {
                    chunkSize = Math.ceil(rest.byteLength / 2);
                // console.log(`Last chunk will be: ${nextChunkSize} which is below ${MIN_CHUNK_SIZE}, adjusting current to ${chunkSize} with ${rest.byteLength} left.`)
                }
                const chunk = rest.slice(0, chunkSize);
                const dataHash = yield this.crypto.hash(chunk);
                cursor += chunk.byteLength;
                chunks.push({
                    dataHash,
                    minByteRange: cursor - chunk.byteLength,
                    maxByteRange: cursor
                });
                rest = rest.slice(chunkSize);
            }
            chunks.push({
                dataHash: yield this.crypto.hash(rest),
                minByteRange: cursor,
                maxByteRange: cursor + rest.byteLength
            });
            return chunks;
        });
    }
    generateLeaves(chunks) {
        return __awaiter(this, void 0, void 0, function*() {
            return Promise.all(chunks.map(({ dataHash, minByteRange, maxByteRange })=>__awaiter(this, void 0, void 0, function*() {
                    return {
                        type: "leaf",
                        id: yield this.hash((yield Promise.all([
                            this.hash(dataHash),
                            this.hash(intToBuffer(maxByteRange))
                        ]))),
                        dataHash: dataHash,
                        minByteRange,
                        maxByteRange
                    };
                })));
        });
    }
    /**
     * Builds an arweave merkle tree and gets the root hash for the given input.
     */ computeRootHash(data) {
        return __awaiter(this, void 0, void 0, function*() {
            const rootNode = yield this.generateTree(data);
            return rootNode.id;
        });
    }
    generateTree(data) {
        return __awaiter(this, void 0, void 0, function*() {
            const rootNode = yield this.buildLayers((yield this.generateLeaves((yield this.chunkData(data)))));
            return rootNode;
        });
    }
    /**
     * Generates the data_root, chunks & proofs
     * needed for a transaction.
     *
     * This also checks if the last chunk is a zero-length
     * chunk and discards that chunk and proof if so.
     * (we do not need to upload this zero length chunk)
     *
     * @param data
     */ generateTransactionChunks(data) {
        return __awaiter(this, void 0, void 0, function*() {
            const chunks = yield this.chunkData(data);
            const leaves = yield this.generateLeaves(chunks);
            const root = yield this.buildLayers(leaves);
            const proofs = yield this.generateProofs(root);
            // Discard the last chunk & proof if it's zero length.
            const lastChunk = chunks.slice(-1)[0];
            if (lastChunk.maxByteRange - lastChunk.minByteRange === 0) {
                chunks.splice(chunks.length - 1, 1);
                proofs.splice(proofs.length - 1, 1);
            }
            return {
                data_root: root.id,
                chunks,
                proofs
            };
        });
    }
    /**
     * Starting with the bottom layer of leaf nodes, hash every second pair
     * into a new branch node, push those branch nodes onto a new layer,
     * and then recurse, building up the tree to it's root, where the
     * layer only consists of two items.
     */ buildLayers(nodes, level = 0) {
        return __awaiter(this, void 0, void 0, function*() {
            // If there is only 1 node left, this is going to be the root node
            if (nodes.length < 2) {
                const root = nodes[0];
                // console.log("Root layer", root);
                return root;
            }
            const nextLayer = [];
            for(let i = 0; i < nodes.length; i += 2){
                nextLayer.push((yield this.hashBranch(nodes[i], nodes[i + 1])));
            }
            // console.log("Layer", nextLayer);
            return this.buildLayers(nextLayer, level + 1);
        });
    }
    /**
     * Recursively search through all branches of the tree,
     * and generate a proof for each leaf node.
     */ generateProofs(root) {
        const proofs = this.resolveBranchProofs(root);
        if (!Array.isArray(proofs)) {
            return [
                proofs
            ];
        }
        return arrayFlatten(proofs);
    }
    resolveBranchProofs(node, proof = new Uint8Array(), depth = 0) {
        if (node.type == "leaf") {
            return {
                offset: node.maxByteRange - 1,
                proof: (0, utils_1.concatBuffers)([
                    proof,
                    node.dataHash,
                    intToBuffer(node.maxByteRange)
                ])
            };
        }
        if (node.type == "branch") {
            const partialProof = (0, utils_1.concatBuffers)([
                proof,
                node.leftChild.id,
                node.rightChild.id,
                intToBuffer(node.byteRange)
            ]);
            return [
                this.resolveBranchProofs(node.leftChild, partialProof, depth + 1),
                this.resolveBranchProofs(node.rightChild, partialProof, depth + 1)
            ];
        }
        throw new Error(`Unexpected node type`);
    }
    validatePath(id, dest, leftBound, rightBound, path) {
        return __awaiter(this, void 0, void 0, function*() {
            if (rightBound <= 0) {
                return false;
            }
            if (dest >= rightBound) {
                return this.validatePath(id, 0, rightBound - 1, rightBound, path);
            }
            if (dest < 0) {
                return this.validatePath(id, 0, 0, rightBound, path);
            }
            if (path.length == HASH_SIZE + NOTE_SIZE) {
                const pathData = path.slice(0, HASH_SIZE);
                const endOffsetBuffer = path.slice(pathData.length, pathData.length + NOTE_SIZE);
                const pathDataHash = yield this.hash([
                    (yield this.hash(pathData)),
                    (yield this.hash(endOffsetBuffer))
                ]);
                const result = (0, exports.arrayCompare)(id, pathDataHash);
                if (result) {
                    return {
                        offset: rightBound - 1,
                        leftBound: leftBound,
                        rightBound: rightBound,
                        chunkSize: rightBound - leftBound
                    };
                }
                return false;
            }
            const left = path.slice(0, HASH_SIZE);
            const right = path.slice(left.length, left.length + HASH_SIZE);
            const offsetBuffer = path.slice(left.length + right.length, left.length + right.length + NOTE_SIZE);
            const offset = bufferToInt(offsetBuffer);
            const remainder = path.slice(left.length + right.length + offsetBuffer.length);
            const pathHash = yield this.hash([
                (yield this.hash(left)),
                (yield this.hash(right)),
                (yield this.hash(offsetBuffer))
            ]);
            if ((0, exports.arrayCompare)(id, pathHash)) {
                if (dest < offset) {
                    return yield this.validatePath(left, dest, leftBound, Math.min(rightBound, offset), remainder);
                }
                return yield this.validatePath(right, dest, Math.max(leftBound, offset), rightBound, remainder);
            }
            return false;
        });
    }
    hashBranch(left, right) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!right) {
                return left;
            }
            const branch = {
                type: "branch",
                id: yield this.hash([
                    (yield this.hash(left.id)),
                    (yield this.hash(right.id)),
                    (yield this.hash(intToBuffer(left.maxByteRange)))
                ]),
                byteRange: left.maxByteRange,
                maxByteRange: right.maxByteRange,
                leftChild: left,
                rightChild: right
            };
            return branch;
        });
    }
    hash(data) {
        return __awaiter(this, void 0, void 0, function*() {
            if (Array.isArray(data)) {
                data = arweave_1.default.utils.concatBuffers(data);
            }
            return new Uint8Array((yield this.crypto.hash(data)));
        });
    }
    /**
     * Inspect an arweave chunk proof.
     * Takes proof, parses, reads and displays the values for console logging.
     * One proof section per line
     * Format: left,right,offset => hash
     */ debug(proof, output = "") {
        return __awaiter(this, void 0, void 0, function*() {
            if (proof.byteLength < 1) {
                return output;
            }
            const left = proof.slice(0, HASH_SIZE);
            const right = proof.slice(left.length, left.length + HASH_SIZE);
            const offsetBuffer = proof.slice(left.length + right.length, left.length + right.length + NOTE_SIZE);
            const offset = bufferToInt(offsetBuffer);
            const remainder = proof.slice(left.length + right.length + offsetBuffer.length);
            const pathHash = yield this.hash([
                (yield this.hash(left)),
                (yield this.hash(right)),
                (yield this.hash(offsetBuffer))
            ]);
            const updatedOutput = `${output}\n${JSON.stringify(Buffer.from(left))},${JSON.stringify(Buffer.from(right))},${offset} => ${JSON.stringify(pathHash)}`;
            return this.debug(remainder, updatedOutput);
        });
    }
}
exports.Merkle = Merkle;
function arrayFlatten(input) {
    const flat = [];
    input.forEach((item)=>{
        if (Array.isArray(item)) {
            flat.push(...arrayFlatten(item));
        } else {
            flat.push(item);
        }
    });
    return flat;
}
exports.arrayFlatten = arrayFlatten;
function intToBuffer(note) {
    const buffer = new Uint8Array(NOTE_SIZE);
    for(let i = buffer.length - 1; i >= 0; i--){
        const byte = note % 256;
        buffer[i] = byte;
        note = (note - byte) / 256;
    }
    return buffer;
}
exports.intToBuffer = intToBuffer;
function bufferToInt(buffer) {
    let value = 0;
    for(let i = 0; i < buffer.length; i++){
        value *= 256;
        value += buffer[i];
    }
    return value;
}
exports.bufferToInt = bufferToInt;
const arrayCompare = (a, b)=>a.every((value, index)=>b[index] === value);
exports.arrayCompare = arrayCompare;
exports.default = Merkle; //# sourceMappingURL=merkle.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/chunks.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = this && this.__asyncValues || function(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i);
    "TURBOPACK unreachable";
    function verb(n) {
        i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
                v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
        };
    }
    function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function(v) {
            resolve({
                value: v,
                done: d
            });
        }, reject);
    }
};
var __await = this && this.__await || function(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
};
var __asyncGenerator = this && this.__asyncGenerator || function(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i;
    "TURBOPACK unreachable";
    function verb(n) {
        if (g[n]) i[n] = function(v) {
            return new Promise(function(a, b) {
                q.push([
                    n,
                    v,
                    a,
                    b
                ]) > 1 || resume(n, v);
            });
        };
    }
    function resume(n, v) {
        try {
            step(g[n](v));
        } catch (e) {
            settle(q[0][3], e);
        }
    }
    function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
        resume("next", value);
    }
    function reject(value) {
        resume("throw", value);
    }
    function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const bignumber_js_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/bignumber.js@9.1.2/node_modules/bignumber.js/bignumber.js [app-route] (ecmascript)"));
const error_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/error.js [app-route] (ecmascript)");
const ArweaveUtils = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/utils.js [app-route] (ecmascript)"));
const merkle_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/merkle.js [app-route] (ecmascript)");
class Chunks {
    constructor(api){
        this.api = api;
    }
    getTransactionMetadata(id) {
        return __awaiter(this, void 0, void 0, function*() {
            const resp = yield this.api.get(`tx/${id}/offset`);
            if (resp.status === 200) {
                return resp.data;
            }
            throw new Error(`Unable to get transaction offset: ${(0, error_1.getError)(resp)}`);
        });
    }
    getChunk(offset) {
        return __awaiter(this, void 0, void 0, function*() {
            const resp = yield this.api.get(`chunk/${offset}`);
            if (resp.status === 200) {
                return resp.data;
            }
            throw new Error(`Unable to get chunk: ${(0, error_1.getError)(resp)}`);
        });
    }
    getChunkData(offset) {
        return __awaiter(this, void 0, void 0, function*() {
            const chunk = yield this.getChunk(offset);
            const buf = ArweaveUtils.b64UrlToBuffer(chunk.chunk);
            return buf;
        });
    }
    firstChunkOffset(offsetResponse) {
        return parseInt(offsetResponse.offset) - parseInt(offsetResponse.size) + 1;
    }
    /**
     * Downloads chunks from the configured API peers, with a default concurrency of 10
     * @param id - ID of the transaction to download
     * @param options - Options object for configuring the downloader
     * @param options.concurrency - The number of chunks to download simultaneously. reduce on slower connections.
     * @returns
     */ downloadChunkedData(id, options) {
        var _a, e_1, _b, _c;
        return __awaiter(this, void 0, void 0, function*() {
            const offsetResponse = yield this.getTransactionMetadata(id);
            const size = parseInt(offsetResponse.size);
            const data = new Uint8Array(size);
            let byte = 0;
            try {
                for(var _d = true, _e = __asyncValues(this.concurrentChunkDownloader(id, options)), _f; _f = yield _e.next(), _a = _f.done, !_a; _d = true){
                    _c = _f.value;
                    _d = false;
                    const chunkData = _c;
                    data.set(chunkData, byte);
                    byte += chunkData.length;
                }
            } catch (e_1_1) {
                e_1 = {
                    error: e_1_1
                };
            } finally{
                try {
                    if (!_d && !_a && (_b = _e.return)) yield _b.call(_e);
                } finally{
                    if (e_1) throw e_1.error;
                }
            }
            return data;
        });
    }
    concurrentChunkDownloader(id, options) {
        return __asyncGenerator(this, arguments, function* concurrentChunkDownloader_1() {
            const opts = Object.assign({
                concurrency: 10
            }, options);
            const metadata = yield __await(this.getTransactionMetadata(id));
            // use big numbers for safety
            const endOffset = new bignumber_js_1.default(metadata.offset);
            const size = new bignumber_js_1.default(metadata.size);
            const startOffset = endOffset.minus(size).plus(1);
            let processedBytes = 0;
            const chunks = Math.ceil(size.dividedBy(merkle_1.MAX_CHUNK_SIZE).toNumber());
            const downloadData = (offset)=>this.getChunkData(offset.toString()).then((r)=>{
                    processedBytes += r.length;
                    return r;
                });
            const processing = [];
            // only parallelise everything except last two chunks.
            // last two due to merkle rebalancing due to minimum chunk size, see https://github.com/ArweaveTeam/arweave-js/blob/ce441f8d4e66a2524cfe86bbbcaed34b887ba193/src/common/lib/merkle.ts#LL53C19-L53C19
            const parallelChunks = chunks - 2;
            const concurrency = Math.min(parallelChunks, opts.concurrency);
            let currChunk = 0;
            // logger.debug(`[downloadTx] Tx ${txId} start ${startOffset} size ${size} chunks ${chunks} concurrency ${concurrency}`);
            for(let i = 0; i < concurrency; i++)processing.push(downloadData(startOffset.plus(merkle_1.MAX_CHUNK_SIZE * currChunk++)));
            while(currChunk < parallelChunks){
                processing.push(downloadData(startOffset.plus(merkle_1.MAX_CHUNK_SIZE * currChunk++)));
                // yield await so that processedBytes works properly
                yield yield __await(processing.shift());
            }
            while(processing.length > 0)yield yield __await(processing.shift());
            yield yield __await(downloadData(startOffset.plus(merkle_1.MAX_CHUNK_SIZE * currChunk++)));
            if (size.isGreaterThan(processedBytes)) yield yield __await(downloadData(startOffset.plus(merkle_1.MAX_CHUNK_SIZE * currChunk++)));
            if (!size.isEqualTo(processedBytes)) throw new Error(`got ${processedBytes}B, expected ${size.toString()}B`);
            return yield __await(void 0);
        });
    }
}
exports.default = Chunks; //# sourceMappingURL=chunks.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/crypto/crypto-augment.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.augmentCrypto = void 0;
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/utils.js [app-route] (ecmascript)");
function augmentCrypto(crypto, augments) {
    const crypt = crypto;
    crypt.deepHash = new augments.deepHash({
        deps: {
            utils: {
                stringToBuffer: utils_1.stringToBuffer,
                concatBuffers: utils_1.concatBuffers
            },
            crypto
        }
    });
    return crypt;
//   crypto: Class<CryptoInterface>,
//   augments: { deepHash: Class<DeepHash, ConstructorParameters<typeof DeepHash>> },
// ): AugmentedCrypto {
//   const cryptoAugment = class Crypto extends crypto implements CryptoInterface {
//     public deepHash: DeepHash;
//     constructor() {
//       super();
//       this.deepHash = new augments.deepHash({ deps: { crypto: this, utils: ArweaveUtils } });
//     }
//   };
//   return new cryptoAugment();
}
exports.augmentCrypto = augmentCrypto; //# sourceMappingURL=crypto-augment.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/deepHash.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DeepHash = void 0;
class DeepHash {
    constructor({ deps }){
        this.crypto = deps.crypto;
        this.utils = deps.utils;
    }
    deepHash(data) {
        return __awaiter(this, void 0, void 0, function*() {
            if (Array.isArray(data)) {
                const tag = this.utils.concatBuffers([
                    this.utils.stringToBuffer("list"),
                    this.utils.stringToBuffer(data.length.toString())
                ]);
                return yield this.deepHashChunks(data, (yield this.crypto.hash(tag, "SHA-384")));
            }
            const tag = this.utils.concatBuffers([
                this.utils.stringToBuffer("blob"),
                this.utils.stringToBuffer(data.byteLength.toString())
            ]);
            const taggedHash = this.utils.concatBuffers([
                (yield this.crypto.hash(tag, "SHA-384")),
                (yield this.crypto.hash(data, "SHA-384"))
            ]);
            return yield this.crypto.hash(taggedHash, "SHA-384");
        });
    }
    deepHashChunks(chunks, acc) {
        return __awaiter(this, void 0, void 0, function*() {
            if (chunks.length < 1) return acc;
            const hashPair = this.utils.concatBuffers([
                acc,
                (yield this.deepHash(chunks[0]))
            ]);
            const newAcc = yield this.crypto.hash(hashPair, "SHA-384");
            return yield this.deepHashChunks(chunks.slice(1), newAcc);
        });
    }
}
exports.DeepHash = DeepHash; //# sourceMappingURL=deepHash.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/api.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const axios_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/axios@1.7.9/node_modules/axios/dist/node/axios.cjs [app-route] (ecmascript)"));
const async_retry_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/async-retry@1.3.3/node_modules/async-retry/lib/index.js [app-route] (ecmascript)"));
const arweave_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/arweave.js [app-route] (ecmascript)"));
class Api {
    constructor(config){
        this.cookieMap = new Map();
        if (config) this.applyConfig(config);
    }
    applyConfig(config) {
        this.config = this.mergeDefaults(config);
        this._instance = undefined;
    }
    getConfig() {
        return this.config;
    }
    requestInterceptor(request) {
        var _a;
        return __awaiter(this, void 0, void 0, function*() {
            const cookies = this.cookieMap.get(new URL((_a = request.baseURL) !== null && _a !== void 0 ? _a : "").host);
            if (cookies) request.headers.cookie = cookies;
            return request;
        });
    }
    responseInterceptor(response) {
        var _a;
        return __awaiter(this, void 0, void 0, function*() {
            const setCookie = (_a = response.headers) === null || _a === void 0 ? void 0 : _a["set-cookie"];
            if (setCookie) this.cookieMap.set(response.request.host, setCookie);
            return response;
        });
    }
    mergeDefaults(config) {
        var _a, _b, _c, _d, _e;
        (_a = config.headers) !== null && _a !== void 0 ? _a : config.headers = {};
        if (config.network && !Object.keys(config.headers).includes("x-network")) config.headers["x-network"] = config.network;
        return {
            url: config.url,
            timeout: (_b = config.timeout) !== null && _b !== void 0 ? _b : 20000,
            logging: (_c = config.logging) !== null && _c !== void 0 ? _c : false,
            logger: (_d = config.logger) !== null && _d !== void 0 ? _d : console.log,
            headers: Object.assign(Object.assign({}, config.headers), {
                "x-irys-arweave-version": arweave_1.default.VERSION
            }),
            withCredentials: (_e = config.withCredentials) !== null && _e !== void 0 ? _e : false,
            retry: {
                retries: 3,
                maxTimeout: 5000
            }
        };
    }
    get(path, config) {
        var _a;
        return __awaiter(this, void 0, void 0, function*() {
            try {
                return yield this.request(path, Object.assign(Object.assign({}, config), {
                    method: "GET"
                }));
            } catch (error) {
                if ((_a = error.response) === null || _a === void 0 ? void 0 : _a.status) return error.response;
                throw error;
            }
        });
    }
    post(path, body, config) {
        var _a;
        return __awaiter(this, void 0, void 0, function*() {
            try {
                return yield this.request(path, Object.assign(Object.assign({
                    data: body
                }, config), {
                    method: "POST"
                }));
            } catch (error) {
                if ((_a = error.response) === null || _a === void 0 ? void 0 : _a.status) return error.response;
                throw error;
            }
        });
    }
    get instance() {
        if (this._instance) return this._instance;
        const instance = axios_1.default.create({
            baseURL: this.config.url.toString(),
            timeout: this.config.timeout,
            maxContentLength: 1024 * 1024 * 512,
            headers: this.config.headers,
            withCredentials: this.config.withCredentials
        });
        if (this.config.withCredentials) {
            instance.interceptors.request.use(this.requestInterceptor.bind(this));
            instance.interceptors.response.use(this.responseInterceptor.bind(this));
        }
        if (this.config.logging) {
            instance.interceptors.request.use((request)=>{
                this.config.logger(`Requesting: ${request.baseURL}/${request.url}`);
                return request;
            });
            instance.interceptors.response.use((response)=>{
                this.config.logger(`Response: ${response.config.url} - ${response.status}`);
                return response;
            });
        }
        return this._instance = instance;
    }
    request(path, config) {
        var _a;
        return __awaiter(this, void 0, void 0, function*() {
            const instance = this.instance;
            const url = (_a = config === null || config === void 0 ? void 0 : config.url) !== null && _a !== void 0 ? _a : new URL(path, this.config.url).toString();
            return (0, async_retry_1.default)((_)=>instance(Object.assign(Object.assign({}, config), {
                    url
                })), Object.assign(Object.assign({}, this.config.retry), config === null || config === void 0 ? void 0 : config.retry));
        });
    }
}
exports.default = Api; //# sourceMappingURL=api.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/fallbackApi.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.FallbackApi = void 0;
const api_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/api.js [app-route] (ecmascript)"));
const isApiConfig = (o)=>typeof o !== "string" && "url" in o;
const defaultFallbackConfig = {
    maxAttempts: 15,
    randomlySelect: true
};
class FallbackApi {
    constructor({ gateways, miners, opts }){
        var _a;
        this.minerInstances = [];
        this.gatewayInstances = [];
        this.globalConfig = (_a = opts === null || opts === void 0 ? void 0 : opts.globalConfig) !== null && _a !== void 0 ? _a : {};
        if (miners) this.addMiners(miners);
        if (gateways) this.addGateways(gateways);
    // this.gatewayInstance = this.minerInstances[0];
    }
    addPeersFrom(url, options) {
        return __awaiter(this, void 0, void 0, function*() {
            const peers = (yield this.get("", {
                url: new URL("/peers", url).toString()
            })).data;
            this.addMiners(peers.slice(0, options === null || options === void 0 ? void 0 : options.limit).map((p)=>`http://${p}`));
        });
    }
    addMiners(hosts) {
        hosts.forEach((h)=>this.minerInstances.push(new api_1.default(isApiConfig(h) ? h : Object.assign({
                url: new URL(h)
            }, this.globalConfig))));
    }
    addGateways(hosts) {
        hosts.forEach((h)=>this.gatewayInstances.push(new api_1.default(isApiConfig(h) ? h : Object.assign({
                url: new URL(h)
            }, this.globalConfig))));
    }
    get(path, config) {
        return __awaiter(this, void 0, void 0, function*() {
            return this.request(path, Object.assign(Object.assign({}, config), {
                method: "GET"
            }));
        });
    }
    post(path, body, config) {
        return __awaiter(this, void 0, void 0, function*() {
            return this.request(path, Object.assign(Object.assign({
                data: body
            }, config), {
                method: "POST"
            }));
        });
    }
    request(path, config) {
        return __awaiter(this, void 0, void 0, function*() {
            const fallbackConfig = Object.assign(Object.assign({}, defaultFallbackConfig), config === null || config === void 0 ? void 0 : config.fallback);
            let attempts = 0;
            const errors = [];
            const instances = (config === null || config === void 0 ? void 0 : config.gatewayOnly) ? this.gatewayInstances : this.gatewayInstances.concat(this.minerInstances);
            const maxAttempts = Math.min(Math.max(fallbackConfig === null || fallbackConfig === void 0 ? void 0 : fallbackConfig.maxAttempts, 1), instances.length);
            const onFallback = fallbackConfig === null || fallbackConfig === void 0 ? void 0 : fallbackConfig.onFallback;
            if (instances.length === 0) throw new Error(`Unable to run request due to 0 configured gateways/miners.`);
            while(attempts++ < maxAttempts){
                const apiInstance = instances.at((fallbackConfig === null || fallbackConfig === void 0 ? void 0 : fallbackConfig.randomlySelect) ? Math.floor(Math.random() * instances.length) : attempts - 1);
                if (!apiInstance) continue;
                try {
                    return yield apiInstance.request(path, Object.assign({}, config));
                } catch (e) {
                    onFallback === null || onFallback === void 0 ? void 0 : onFallback(e, apiInstance);
                    errors.push(e);
                    if (attempts >= maxAttempts) throw e;
                }
            }
            throw new Error("unreachable");
        });
    }
}
exports.FallbackApi = FallbackApi;
exports.default = FallbackApi; //# sourceMappingURL=fallbackApi.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/network.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
class Network {
    constructor(api){
        this.api = api;
    }
    getInfo() {
        return this.api.get(`info`).then((response)=>{
            return response.data;
        });
    }
    getPeers() {
        return this.api.get(`peers`).then((response)=>{
            return response.data;
        });
    }
}
exports.default = Network; //# sourceMappingURL=network.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/transaction-uploader.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TransactionUploader = exports.FATAL_CHUNK_UPLOAD_ERRORS = void 0;
const transaction_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/transaction.js [app-route] (ecmascript)"));
const error_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/error.js [app-route] (ecmascript)");
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/utils.js [app-route] (ecmascript)");
// import { validatePath } from "./merkle";
// Maximum amount of chunks we will upload in the body.
const MAX_CHUNKS_IN_BODY = 1;
// We assume these errors are intermitment and we can try again after a delay:
// - not_joined
// - timeout
// - data_root_not_found (we may have hit a node that just hasn't seen it yet)
// - exceeds_disk_pool_size_limit
// We also try again after any kind of unexpected network errors
// Errors from /chunk we should never try and continue on.
exports.FATAL_CHUNK_UPLOAD_ERRORS = [
    "invalid_json",
    "chunk_too_big",
    "data_path_too_big",
    "offset_too_big",
    "data_size_too_big",
    "chunk_proof_ratio_not_attractive",
    "invalid_proof"
];
// Amount we will delay on receiving an error response but do want to continue.
const ERROR_DELAY = 1000 * 40;
class TransactionUploader {
    get isComplete() {
        return this.txPosted && this.chunkIndex === this.transaction.chunks.chunks.length;
    }
    get totalChunks() {
        return this.transaction.chunks.chunks.length;
    }
    get uploadedChunks() {
        return this.chunkIndex;
    }
    get pctComplete() {
        return Math.trunc(this.uploadedChunks / this.totalChunks * 100);
    }
    constructor({ deps, transaction }){
        this.chunkIndex = 0;
        this.txPosted = false;
        this.lastRequestTimeEnd = 0;
        this.totalErrors = 0; // Not serialized.
        this.lastResponseStatus = 0;
        this.lastResponseError = "";
        if (!transaction.id) {
            throw new Error(`Transaction is not signed`);
        }
        if (!transaction.chunks) {
            throw new Error(`Transaction chunks not prepared`);
        }
        this.api = deps.api;
        this.crypto = deps.crypto;
        this.merkle = deps.merkle;
        this.deepHash = deps.deepHash;
        // Make a copy of transaction, zeroing the data so we can serialize.
        this.data = transaction.data;
        this.transaction = new transaction_1.default({
            attributes: Object.assign({}, transaction, {
                data: new Uint8Array(0)
            }),
            deps: {
                merkle: deps.merkle,
                deepHash: deps.deepHash
            }
        });
    }
    /**
     * Uploads the next part of the transaction.
     * On the first call this posts the transaction
     * itself and on any subsequent calls uploads the
     * next chunk until it completes.
     */ uploadChunk(chunkIndex_) {
        return __awaiter(this, void 0, void 0, function*() {
            if (this.isComplete) {
                throw new Error(`Upload is already complete`);
            }
            if (this.lastResponseError !== "") {
                this.totalErrors++;
            } else {
                this.totalErrors = 0;
            }
            // We have been trying for about an hour receiving an
            // error every time, so eventually bail.
            if (this.totalErrors === 100) {
                throw new Error(`Unable to complete upload: ${this.lastResponseStatus}: ${this.lastResponseError}`);
            }
            let delay = this.lastResponseError === "" ? 0 : Math.max(this.lastRequestTimeEnd + ERROR_DELAY - Date.now(), ERROR_DELAY);
            if (delay > 0) {
                // Jitter delay bcoz networks, subtract up to 30% from 40 seconds
                delay = delay - delay * Math.random() * 0.3;
                yield new Promise((res)=>setTimeout(res, delay));
            }
            this.lastResponseError = "";
            if (!this.txPosted) {
                yield this.postTransaction();
                return;
            }
            if (chunkIndex_) {
                this.chunkIndex = chunkIndex_;
            }
            const chunk = this.transaction.getChunk(chunkIndex_ || this.chunkIndex, this.data);
            const chunkOk = yield this.merkle.validatePath(this.transaction.chunks.data_root, parseInt(chunk.offset), 0, parseInt(chunk.data_size), (0, utils_1.b64UrlToBuffer)(chunk.data_path));
            if (!chunkOk) {
                throw new Error(`Unable to validate chunk ${this.chunkIndex}`);
            }
            // Catch network errors and turn them into objects with status -1 and an error message.
            const resp = yield this.api.post(`chunk`, this.transaction.getChunk(this.chunkIndex, this.data)).catch((e)=>{
                console.error(e.message);
                return {
                    status: -1,
                    data: {
                        error: e.message
                    }
                };
            });
            this.lastRequestTimeEnd = Date.now();
            this.lastResponseStatus = resp.status;
            if (this.lastResponseStatus == 200) {
                this.chunkIndex++;
            } else {
                this.lastResponseError = (0, error_1.getError)(resp);
                if (exports.FATAL_CHUNK_UPLOAD_ERRORS.includes(this.lastResponseError)) {
                    throw new Error(`Fatal error uploading chunk ${this.chunkIndex}: ${this.lastResponseError}`);
                }
            }
        });
    }
    /**
     * Reconstructs an upload from its serialized state and data.
     * Checks if data matches the expected data_root.
     *
     * @param serialized
     * @param data
     */ static fromSerialized({ serialized, data, deps }) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!serialized || typeof serialized.chunkIndex !== "number" || typeof serialized.transaction !== "object") {
                throw new Error(`Serialized object does not match expected format.`);
            }
            // Everything looks ok, reconstruct the TransactionUpload,
            // prepare the chunks again and verify the data_root matches
            const transaction = new transaction_1.default(serialized.transaction);
            if (!transaction.chunks) {
                yield transaction.prepareChunks(data);
            }
            const upload = new TransactionUploader({
                deps,
                transaction
            });
            // Copy the serialized upload information, and data passed in.
            upload.chunkIndex = serialized.chunkIndex;
            upload.lastRequestTimeEnd = serialized.lastRequestTimeEnd;
            upload.lastResponseError = serialized.lastResponseError;
            upload.lastResponseStatus = serialized.lastResponseStatus;
            upload.txPosted = serialized.txPosted;
            upload.data = data;
            if (upload.transaction.data_root !== serialized.transaction.data_root) {
                throw new Error(`Data mismatch: Uploader doesn't match provided data.`);
            }
            return upload;
        });
    }
    /**
     * Reconstruct an upload from the tx metadata, ie /tx/<id>.
     *
     * @param api
     * @param id
     * @param data
     */ static fromTransactionId(api, id) {
        return __awaiter(this, void 0, void 0, function*() {
            const resp = yield api.get(`tx/${id}`);
            if (resp.status !== 200) {
                throw new Error(`Tx ${id} not found: ${resp.status}`);
            }
            const transaction = resp.data;
            transaction.data = new Uint8Array(0);
            const serialized = {
                txPosted: true,
                chunkIndex: 0,
                lastResponseError: "",
                lastRequestTimeEnd: 0,
                lastResponseStatus: 0,
                transaction
            };
            return serialized;
        });
    }
    toJSON() {
        return {
            chunkIndex: this.chunkIndex,
            transaction: this.transaction,
            lastRequestTimeEnd: this.lastRequestTimeEnd,
            lastResponseStatus: this.lastResponseStatus,
            lastResponseError: this.lastResponseError,
            txPosted: this.txPosted
        };
    }
    // POST to /tx
    postTransaction() {
        return __awaiter(this, void 0, void 0, function*() {
            const uploadInBody = this.totalChunks <= MAX_CHUNKS_IN_BODY;
            if (uploadInBody) {
                // Post the transaction with data.
                this.transaction.data = this.data;
                const resp = yield this.api.post(`tx`, this.transaction).catch((e)=>{
                    console.error(e);
                    return {
                        status: -1,
                        data: {
                            error: e.message
                        }
                    };
                });
                this.lastRequestTimeEnd = Date.now();
                this.lastResponseStatus = resp.status;
                this.transaction.data = new Uint8Array(0);
                if (resp.status >= 200 && resp.status < 300) {
                    // We are complete.
                    this.txPosted = true;
                    this.chunkIndex = MAX_CHUNKS_IN_BODY;
                    return;
                }
                this.lastResponseError = (0, error_1.getError)(resp);
                throw new Error(`Unable to upload transaction: ${resp.status}, ${this.lastResponseError}`);
            }
            // Post the transaction with no data.
            const resp = yield this.api.post(`tx`, this.transaction);
            this.lastRequestTimeEnd = Date.now();
            this.lastResponseStatus = resp.status;
            if (!(resp.status >= 200 && resp.status < 300)) {
                this.lastResponseError = (0, error_1.getError)(resp);
                throw new Error(`Unable to upload transaction: ${resp.status}, ${this.lastResponseError}`);
            }
            this.txPosted = true;
        });
    }
}
exports.TransactionUploader = TransactionUploader; //# sourceMappingURL=transaction-uploader.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/transactions.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __await = this && this.__await || function(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
};
var __asyncGenerator = this && this.__asyncGenerator || function(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i;
    "TURBOPACK unreachable";
    function verb(n) {
        if (g[n]) i[n] = function(v) {
            return new Promise(function(a, b) {
                q.push([
                    n,
                    v,
                    a,
                    b
                ]) > 1 || resume(n, v);
            });
        };
    }
    function resume(n, v) {
        try {
            step(g[n](v));
        } catch (e) {
            settle(q[0][3], e);
        }
    }
    function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
        resume("next", value);
    }
    function reject(value) {
        resume("throw", value);
    }
    function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const error_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/error.js [app-route] (ecmascript)"));
const transaction_1 = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/transaction.js [app-route] (ecmascript)"));
const ArweaveUtils = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/utils.js [app-route] (ecmascript)"));
const transaction_uploader_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/transaction-uploader.js [app-route] (ecmascript)");
class Transactions {
    constructor({ deps }){
        this.api = deps.api;
        this.crypto = deps.crypto;
        this.chunks = deps.chunks;
        this.merkle = deps.merkle;
        this.deepHash = deps.deepHash;
    }
    getTransactionAnchor() {
        /**
         * Maintain compatibility with erdjs which sets a global axios.defaults.transformResponse
         * in order to overcome some other issue in:  https://github.com/axios/axios/issues/983
         *
         * However, this introduces a problem with ardrive-js, so we will enforce
         * config =  {transformResponse: []} where we do not require a transform
         */ return this.api.get(`tx_anchor`, {
            transformResponse: []
        }).then((response)=>{
            return response.data;
        });
    }
    getPrice(byteSize, targetAddress) {
        const endpoint = targetAddress ? `price/${byteSize}/${targetAddress}` : `price/${byteSize}`;
        return this.api.get(endpoint, {
            transformResponse: [
                /**
                 * We need to specify a response transformer to override
                 * the default JSON.parse behavior, as this causes
                 * winston to be converted to a number and we want to
                 * return it as a winston string.
                 * @param data
                 */ function(data) {
                    return data;
                }
            ]
        }).then((response)=>{
            return response.data;
        });
    }
    get(id) {
        return __awaiter(this, void 0, void 0, function*() {
            const response = yield this.api.get(`tx/${id}`);
            if (response.status == 200) {
                const data_size = parseInt(response.data.data_size);
                if (response.data.format >= 2 && data_size > 0 && data_size <= 1024 * 1024 * 12) {
                    const data = yield this.getData(id);
                    return new transaction_1.default({
                        attributes: Object.assign(Object.assign({}, response.data), {
                            data
                        }),
                        deps: {
                            merkle: this.merkle,
                            deepHash: this.deepHash
                        }
                    });
                }
                return new transaction_1.default({
                    attributes: Object.assign(Object.assign({}, response.data), {
                        format: response.data.format || 1
                    }),
                    deps: {
                        merkle: this.merkle,
                        deepHash: this.deepHash
                    }
                });
            }
            if (response.status === 404) {
                throw new error_1.default("TX_NOT_FOUND" /* ArweaveErrorType.TX_NOT_FOUND */ );
            }
            if (response.status === 410) {
                throw new error_1.default("TX_FAILED" /* ArweaveErrorType.TX_FAILED */ );
            }
            throw new error_1.default("TX_INVALID" /* ArweaveErrorType.TX_INVALID */ );
        });
    }
    fromRaw(attributes) {
        return new transaction_1.default({
            attributes,
            deps: {
                merkle: this.merkle,
                deepHash: this.deepHash
            }
        });
    }
    getStatus(id) {
        return this.api.get(`tx/${id}/status`).then((response)=>{
            if (response.status === 200) {
                return {
                    status: 200,
                    confirmed: response.data
                };
            }
            return {
                status: response.status,
                confirmed: null
            };
        });
    }
    getData(id) {
        return __awaiter(this, void 0, void 0, function*() {
            let data = undefined;
            try {
                data = (yield this.api.get(`/${id}`, {
                    responseType: "arraybuffer"
                })).data;
            } catch (error) {
                console.error(`Error while trying to download contiguous data from gateway cache for ${id}`);
                console.error(error);
            }
            if (!data) {
                console.warn(`Falling back to chunks for ${id}`);
                try {
                    data = yield this.chunks.downloadChunkedData(id);
                } catch (error) {
                    console.error(`Error while trying to download chunked data for ${id}`);
                    console.error(error);
                }
            }
            if (!data) {
                throw new Error(`${id} data was not found!`);
            }
            return data;
        });
    }
    getDataStream(id) {
        return __awaiter(this, void 0, void 0, function*() {
            let data = undefined;
            try {
                const resData = (yield this.api.get(`/${id}`, {
                    responseType: "arraybuffer"
                })).data;
                const gen = function g() {
                    return __asyncGenerator(this, arguments, function* g_1() {
                        yield yield __await(resData);
                    });
                };
                data = gen();
            } catch (error) {
                console.error(`Error while trying to download contiguous data from gateway cache for ${id}`);
                console.error(error);
            }
            if (!data) {
                console.warn(`Falling back to chunks for ${id}`);
                try {
                    const gen = this.chunks.concurrentChunkDownloader(id);
                    data = gen;
                } catch (error) {
                    console.error(`Error while trying to download chunked data for ${id}`);
                    console.error(error);
                }
            }
            if (!data) {
                throw new Error(`${id} data was not found!`);
            }
            return data;
        });
    }
    sign(transaction, jwk, options) {
        return __awaiter(this, void 0, void 0, function*() {
            /** Non-exhaustive (only checks key names), but previously no jwk checking was done */ const isJwk = (obj)=>{
                let valid = true;
                [
                    "n",
                    "e",
                    "d",
                    "p",
                    "q",
                    "dp",
                    "dq",
                    "qi"
                ].map((key)=>!(key in obj) && (valid = false));
                return valid;
            };
            const validJwk = typeof jwk === "object" && isJwk(jwk);
            const externalWallet = typeof arweaveWallet === "object";
            if (!validJwk && !externalWallet) {
                throw new Error(`No valid JWK or external wallet found to sign transaction.`);
            } else if (externalWallet) {
                try {
                    const existingPermissions = yield arweaveWallet.getPermissions();
                    if (!existingPermissions.includes("SIGN_TRANSACTION")) yield arweaveWallet.connect([
                        "SIGN_TRANSACTION"
                    ]);
                } catch (_a) {
                // Permission is already granted
                }
                // for external compatibility
                transaction.tags = transaction.tags.map((v)=>new transaction_1.ArweaveTag(v.name, v.value));
                const signedTransaction = yield arweaveWallet.sign(transaction, options);
                transaction.setSignature({
                    id: signedTransaction.id,
                    owner: signedTransaction.owner,
                    reward: signedTransaction.reward,
                    tags: signedTransaction.tags,
                    signature: signedTransaction.signature
                });
            } else if (validJwk) {
                transaction.setOwner(jwk.n);
                const dataToSign = yield transaction.getSignatureData();
                const rawSignature = yield this.crypto.sign(jwk, dataToSign, options);
                const id = yield this.crypto.hash(rawSignature);
                transaction.setSignature({
                    id: ArweaveUtils.bufferTob64Url(id),
                    owner: jwk.n,
                    signature: ArweaveUtils.bufferTob64Url(rawSignature)
                });
            } else {
                // can't get here, but for sanity we'll throw an error.
                throw new Error(`An error occurred while signing. Check wallet is valid`);
            }
        });
    }
    verify(transaction) {
        return __awaiter(this, void 0, void 0, function*() {
            const signaturePayload = yield transaction.getSignatureData();
            /**
             * The transaction ID should be a SHA-256 hash of the raw signature bytes, so this needs
             * to be recalculated from the signature and checked against the transaction ID.
             */ const rawSignature = transaction.get("signature", {
                decode: true,
                string: false
            });
            const expectedId = ArweaveUtils.bufferTob64Url((yield this.crypto.hash(rawSignature)));
            if (transaction.id !== expectedId) {
                throw new Error(`Invalid transaction signature or ID! The transaction ID doesn't match the expected SHA-256 hash of the signature.`);
            }
            /**
             * Now verify the signature is valid and signed by the owner wallet (owner field = originating wallet public key).
             */ return this.crypto.verify(transaction.owner, signaturePayload, rawSignature);
        });
    }
    post(transaction) {
        return __awaiter(this, void 0, void 0, function*() {
            if (typeof transaction === "string") {
                transaction = new transaction_1.default({
                    attributes: JSON.parse(transaction),
                    deps: {
                        merkle: this.merkle,
                        deepHash: this.deepHash
                    }
                });
            } else if (typeof transaction.readInt32BE === "function") {
                transaction = new transaction_1.default({
                    attributes: JSON.parse(transaction.toString()),
                    deps: {
                        merkle: this.merkle,
                        deepHash: this.deepHash
                    }
                });
            } else if (typeof transaction === "object" && !(transaction instanceof transaction_1.default)) {
                transaction = new transaction_1.default({
                    attributes: transaction,
                    deps: {
                        merkle: this.merkle,
                        deepHash: this.deepHash
                    }
                });
            }
            if (!(transaction instanceof transaction_1.default)) {
                throw new Error(`Must be Transaction object`);
            }
            if (!transaction.chunks) {
                yield transaction.prepareChunks(transaction.data);
            }
            const uploader = yield this.getUploader(transaction, transaction.data);
            // Emulate existing error & return value behavior.
            try {
                while(!uploader.isComplete){
                    yield uploader.uploadChunk();
                }
            } catch (e) {
                if (uploader.lastResponseStatus > 0) {
                    return {
                        status: uploader.lastResponseStatus,
                        statusText: uploader.lastResponseError,
                        data: {
                            error: uploader.lastResponseError
                        }
                    };
                }
                throw e;
            }
            return {
                status: 200,
                statusText: "OK",
                data: {}
            };
        });
    }
    /**
     * Gets an uploader than can be used to upload a transaction chunk by chunk, giving progress
     * and the ability to resume.
     *
     * Usage example:
     *
     * ```
     * const uploader = arweave.transactions.getUploader(transaction);
     * while (!uploader.isComplete) {
     *   await uploader.uploadChunk();
     *   console.log(`${uploader.pctComplete}%`);
     * }
     * ```
     *
     * @param upload a Transaction object, a previously save progress object, or a transaction id.
     * @param data the data of the transaction. Required when resuming an upload.
     */ getUploader(upload, data) {
        return __awaiter(this, void 0, void 0, function*() {
            let uploader;
            if (data instanceof ArrayBuffer) {
                data = new Uint8Array(data);
            }
            if (upload instanceof transaction_1.default) {
                if (!data) {
                    data = upload.data;
                }
                if (!(data instanceof Uint8Array)) {
                    throw new Error("Data format is invalid");
                }
                if (!upload.chunks) {
                    yield upload.prepareChunks(data);
                }
                uploader = new transaction_uploader_1.TransactionUploader({
                    transaction: upload,
                    deps: {
                        api: this.api,
                        crypto: this.crypto,
                        merkle: this.merkle,
                        deepHash: this.deepHash
                    }
                });
                if (!uploader.data || uploader.data.length === 0) {
                    uploader.data = data;
                }
            } else {
                if (typeof upload === "string") {
                    upload = yield transaction_uploader_1.TransactionUploader.fromTransactionId(this.api, upload);
                }
                if (!data || !(data instanceof Uint8Array)) {
                    throw new Error(`Must provide data when resuming upload`);
                }
                // upload should be a serialized upload.
                uploader = yield transaction_uploader_1.TransactionUploader.fromSerialized({
                    deps: {
                        api: this.api,
                        merkle: this.merkle,
                        crypto: this.crypto,
                        deepHash: this.deepHash
                    },
                    serialized: upload,
                    data
                });
            }
            return uploader;
        });
    }
    /**
     * Async generator version of uploader
     *
     * Usage example:
     *
     * ```
     * for await (const uploader of arweave.transactions.upload(tx)) {
     *  console.log(`${uploader.pctComplete}%`);
     * }
     * ```
     *
     * @param upload a Transaction object, a previously save uploader, or a transaction id.
     * @param data the data of the transaction. Required when resuming an upload.
     */ upload(upload, data) {
        return __asyncGenerator(this, arguments, function* upload_1() {
            const uploader = yield __await(this.getUploader(upload, data));
            while(!uploader.isComplete){
                yield __await(uploader.uploadChunk());
                yield yield __await(uploader);
            }
            return yield __await(uploader);
        });
    }
}
exports.default = Transactions; //# sourceMappingURL=transactions.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/wallets.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const ArweaveUtils = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/utils.js [app-route] (ecmascript)"));
class Wallets {
    constructor(api, crypto){
        this.api = api;
        this.crypto = crypto;
    }
    /**
     * Get the wallet balance for the given address.
     *
     * @param {string} address - The arweave address to get the balance for.
     *
     * @returns {Promise<string>} - Promise which resolves with a winston string balance.
     */ getBalance(address) {
        return this.api.get(`wallet/${address}/balance`, {
            transformResponse: [
                /**
                 * We need to specify a response transformer to override
                 * the default JSON.parse behaviour, as this causes
                 * balances to be converted to a number and we want to
                 * return it as a winston string.
                 * @param data
                 */ function(data) {
                    return data;
                }
            ]
        }).then((response)=>{
            return response.data;
        });
    }
    /**
     * Get the last transaction ID for the given wallet address.
     *
     * @param {string} address - The arweave address to get the transaction for.
     *
     * @returns {Promise<string>} - Promise which resolves with a transaction ID.
     */ getLastTransactionID(address) {
        return this.api.get(`wallet/${address}/last_tx`).then((response)=>{
            return response.data;
        });
    }
    generate() {
        return this.crypto.generateJWK();
    }
    jwkToAddress(jwk) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!jwk || jwk === "use_wallet") {
                return this.getAddress();
            } else {
                return this.getAddress(jwk);
            }
        });
    }
    getAddress(jwk) {
        return __awaiter(this, void 0, void 0, function*() {
            if (!jwk || jwk === "use_wallet") {
                try {
                    yield arweaveWallet.connect([
                        "ACCESS_ADDRESS"
                    ]);
                } catch (_a) {
                // Permission is already granted
                }
                return arweaveWallet.getActiveAddress();
            } else {
                return this.ownerToAddress(jwk.n);
            }
        });
    }
    ownerToAddress(owner) {
        return __awaiter(this, void 0, void 0, function*() {
            return ArweaveUtils.bufferTob64Url((yield this.crypto.hash(ArweaveUtils.b64UrlToBuffer(owner))));
        });
    }
}
exports.default = Wallets; //# sourceMappingURL=wallets.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/arweave.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Arweave = void 0;
// import Ar from "./ar";
const blocks_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/blocks.js [app-route] (ecmascript)"));
const chunks_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/chunks.js [app-route] (ecmascript)"));
const crypto_augment_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/crypto/crypto-augment.js [app-route] (ecmascript)");
const deepHash_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/deepHash.js [app-route] (ecmascript)");
const fallbackApi_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/fallbackApi.js [app-route] (ecmascript)"));
const merkle_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/merkle.js [app-route] (ecmascript)"));
const transaction_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/transaction.js [app-route] (ecmascript)"));
const ArweaveUtils = __importStar(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/utils.js [app-route] (ecmascript)"));
const network_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/network.js [app-route] (ecmascript)"));
const transactions_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/transactions.js [app-route] (ecmascript)"));
const wallets_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/wallets.js [app-route] (ecmascript)"));
class Arweave {
    constructor(config){
        this.config = config;
        if (!config.crypto) throw new Error(`config.crypto is required`); // `crypto` is automatically added by the wrapper constructors, users should never encounter this
        this.crypto = (0, crypto_augment_1.augmentCrypto)(config.crypto, {
            deepHash: deepHash_1.DeepHash
        });
        this.deepHash = this.crypto.deepHash;
        const apiConfig = config.gateways ? Array.isArray(config.gateways) ? config.gateways : [
            config.gateways
        ] : undefined;
        this.api = new fallbackApi_1.default({
            gateways: apiConfig,
            miners: config.miners
        });
        this.wallets = new wallets_1.default(this.api, this.crypto);
        this.chunks = new chunks_1.default(this.api);
        this.network = new network_1.default(this.api);
        this.blocks = new blocks_1.default(this.api, this.network);
        this.merkle = new merkle_1.default({
            deps: {
                crypto: this.crypto
            }
        });
        this.transactions = new transactions_1.default({
            deps: {
                api: this.api,
                crypto: config.crypto,
                chunks: this.chunks,
                merkle: this.merkle,
                deepHash: this.deepHash
            }
        });
    }
    get utils() {
        return Arweave.utils;
    }
    getConfig() {
        return this.config;
    }
    createTransaction(attributes, jwk) {
        return __awaiter(this, void 0, void 0, function*() {
            const transaction = {};
            Object.assign(transaction, attributes);
            if (!attributes.data && !(attributes.target && attributes.quantity)) {
                throw new Error(`A new Arweave transaction must have a 'data' value, or 'target' and 'quantity' values.`);
            }
            if (attributes.owner == undefined) {
                if (jwk && jwk !== "use_wallet") {
                    transaction.owner = jwk.n;
                }
            }
            if (attributes.last_tx == undefined) {
                transaction.last_tx = yield this.transactions.getTransactionAnchor();
            }
            if (typeof attributes.data === "string") {
                attributes.data = ArweaveUtils.stringToBuffer(attributes.data);
            }
            if (attributes.data instanceof ArrayBuffer) {
                attributes.data = new Uint8Array(attributes.data);
            }
            if (attributes.data && !(attributes.data instanceof Uint8Array)) {
                throw new Error("Expected data to be a string, Uint8Array or ArrayBuffer");
            }
            if (attributes.reward == undefined) {
                const length = attributes.data ? attributes.data.byteLength : 0;
                transaction.reward = yield this.transactions.getPrice(length, transaction.target);
            }
            // here we should call prepare chunk
            transaction.data_root = "";
            transaction.data_size = attributes.data ? attributes.data.byteLength.toString() : "0";
            transaction.data = attributes.data || new Uint8Array(0);
            const createdTransaction = new transaction_1.default({
                attributes: transaction,
                deps: {
                    merkle: this.merkle,
                    deepHash: this.deepHash
                }
            });
            yield createdTransaction.getSignatureData();
            return createdTransaction;
        });
    }
}
exports.Arweave = Arweave;
Arweave.utils = ArweaveUtils;
Arweave.VERSION = "0.0.1";
exports.default = Arweave; //# sourceMappingURL=arweave.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/arweave.js [app-route] (ecmascript)"), exports);
var arweave_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/arweave.js [app-route] (ecmascript)");
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return arweave_1.Arweave;
    }
}); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/stream/chunker.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __asyncValues = this && this.__asyncValues || function(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i);
    "TURBOPACK unreachable";
    function verb(n) {
        i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
                v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
        };
    }
    function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function(v) {
            resolve({
                value: v,
                done: d
            });
        }, reject);
    }
};
var __await = this && this.__await || function(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
};
var __asyncGenerator = this && this.__asyncGenerator || function(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i;
    "TURBOPACK unreachable";
    function verb(n) {
        if (g[n]) i[n] = function(v) {
            return new Promise(function(a, b) {
                q.push([
                    n,
                    v,
                    a,
                    b
                ]) > 1 || resume(n, v);
            });
        };
    }
    function resume(n, v) {
        try {
            step(g[n](v));
        } catch (e) {
            settle(q[0][3], e);
        }
    }
    function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
        resume("next", value);
    }
    function reject(value) {
        resume("throw", value);
    }
    function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.chunker = exports.ChunkBuffer = void 0;
class ChunkBuffer {
    constructor(){
        this.buffers = [];
    }
    get empty() {
        return this.buffers.length === 0;
    }
    push(...buffers) {
        this.buffers.push(...buffers);
    }
    pop(expectedChunkSize) {
        let totalBufferSize = 0;
        for (const [i, chunk] of this.buffers.entries()){
            totalBufferSize += chunk.byteLength;
            if (totalBufferSize === expectedChunkSize) {
                return Buffer.concat(this.buffers.splice(0, i + 1));
            } else if (totalBufferSize > expectedChunkSize) {
                const chunkOverflowAmount = totalBufferSize - expectedChunkSize;
                const chunkWatermark = chunk.byteLength - chunkOverflowAmount;
                const chunkBelowWatermark = chunk.slice(0, chunkWatermark);
                const chunkOverflow = chunk.slice(chunkWatermark);
                const chunkBuffers = this.buffers.splice(0, i);
                chunkBuffers.push(chunkBelowWatermark);
                this.buffers[0] = chunkOverflow;
                return Buffer.concat(chunkBuffers);
            }
        }
        return null;
    }
    flush() {
        const remaining = Buffer.concat(this.buffers);
        this.buffers.length = 0;
        return remaining;
    }
}
exports.ChunkBuffer = ChunkBuffer;
function chunker(expectedChunkSize, { flush } = {
    flush: false
}) {
    return function(stream) {
        return __asyncGenerator(this, arguments, function*() {
            var _a, e_1, _b, _c;
            const chunkBuffer = new ChunkBuffer();
            try {
                for(var _d = true, stream_1 = __asyncValues(stream), stream_1_1; stream_1_1 = yield __await(stream_1.next()), _a = stream_1_1.done, !_a; _d = true){
                    _c = stream_1_1.value;
                    _d = false;
                    const chunk = _c;
                    chunkBuffer.push(chunk);
                    while(true){
                        const sizedChunk = chunkBuffer.pop(expectedChunkSize);
                        if (!sizedChunk) {
                            break;
                        }
                        yield yield __await(sizedChunk);
                    }
                }
            } catch (e_1_1) {
                e_1 = {
                    error: e_1_1
                };
            } finally{
                try {
                    if (!_d && !_a && (_b = stream_1.return)) yield __await(_b.call(stream_1));
                } finally{
                    if (e_1) throw e_1.error;
                }
            }
            if (flush) {
                const flushedBuffer = chunkBuffer.flush();
                if (flushedBuffer.byteLength > 0) {
                    yield yield __await(flushedBuffer);
                }
            }
        });
    };
}
exports.chunker = chunker; //# sourceMappingURL=chunker.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/stream/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = this && this.__asyncValues || function(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i);
    "TURBOPACK unreachable";
    function verb(n) {
        i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
                v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
        };
    }
    function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function(v) {
            resolve({
                value: v,
                done: d
            });
        }, reject);
    }
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Stream = void 0;
const promises_1 = __turbopack_require__("[externals]/stream/promises [external] (stream/promises, cjs)");
const merkle_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/merkle.js [app-route] (ecmascript)");
const transaction_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/transaction.js [app-route] (ecmascript)"));
const transaction_uploader_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/transaction-uploader.js [app-route] (ecmascript)");
const utils_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/lib/utils.js [app-route] (ecmascript)");
const chunker_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/stream/chunker.js [app-route] (ecmascript)");
const MAX_CONCURRENT_CHUNK_UPLOAD_COUNT = 128;
class Stream {
    constructor({ deps }){
        this.crypto = deps.crypto;
        this.merkle = deps.merkle;
        this.api = deps.api;
        this.transactions = deps.transactions;
        this.deepHash = deps.deepHash;
    }
    /**
     * Creates an Arweave transaction from the piped data stream.
     */ createTransactionAsync(attributes, jwk) {
        // eslint-disable-next-line @typescript-eslint/no-this-alias
        const oThis = this;
        return (source)=>__awaiter(this, void 0, void 0, function*() {
                var _a, _b, _c;
                const chunks = yield (0, promises_1.pipeline)(source, oThis.generateTransactionChunksAsync());
                const txAttrs = Object.assign({}, attributes);
                (_a = txAttrs.owner) !== null && _a !== void 0 ? _a : txAttrs.owner = jwk === null || jwk === void 0 ? void 0 : jwk.n;
                (_b = txAttrs.last_tx) !== null && _b !== void 0 ? _b : txAttrs.last_tx = yield oThis.transactions.getTransactionAnchor();
                const lastChunk = chunks.chunks[chunks.chunks.length - 1];
                const dataByteLength = lastChunk.maxByteRange;
                (_c = txAttrs.reward) !== null && _c !== void 0 ? _c : txAttrs.reward = yield oThis.transactions.getPrice(dataByteLength, txAttrs.target);
                txAttrs.data_size = dataByteLength.toString();
                const tx = new transaction_1.default({
                    attributes: txAttrs,
                    deps: {
                        merkle: oThis.merkle,
                        deepHash: oThis.deepHash
                    }
                });
                tx.chunks = chunks;
                tx.data_root = (0, utils_1.bufferTob64Url)(chunks.data_root);
                return tx;
            });
    }
    /**
     * Generates the Arweave transaction chunk information from the piped data stream.
     */ generateTransactionChunksAsync() {
        const crypto = this.crypto;
        return (source)=>__awaiter(this, void 0, void 0, function*() {
                const chunks = [];
                /**
             * @param chunkByteIndex the index the start of the specified chunk is located at within its original data stream.
             */ const addChunk = (chunkByteIndex, chunk)=>__awaiter(this, void 0, void 0, function*() {
                        const dataHash = yield crypto.hash(chunk);
                        const chunkRep = {
                            dataHash,
                            minByteRange: chunkByteIndex,
                            maxByteRange: chunkByteIndex + chunk.byteLength
                        };
                        chunks.push(chunkRep);
                        return chunkRep;
                    });
                let chunkStreamByteIndex = 0;
                let previousDataChunk;
                let expectChunkGenerationCompleted = false;
                yield (0, promises_1.pipeline)(source, (0, chunker_1.chunker)(merkle_1.MAX_CHUNK_SIZE, {
                    flush: true
                }), (chunkedSource)=>{
                    var _a, chunkedSource_1, chunkedSource_1_1;
                    return __awaiter(this, void 0, void 0, function*() {
                        var _b, e_1, _c, _d;
                        try {
                            for(_a = true, chunkedSource_1 = __asyncValues(chunkedSource); chunkedSource_1_1 = yield chunkedSource_1.next(), _b = chunkedSource_1_1.done, !_b; _a = true){
                                _d = chunkedSource_1_1.value;
                                _a = false;
                                const chunk = _d;
                                if (expectChunkGenerationCompleted) {
                                    throw Error("Expected chunk generation to have completed.");
                                }
                                if (chunk.byteLength >= merkle_1.MIN_CHUNK_SIZE && chunk.byteLength <= merkle_1.MAX_CHUNK_SIZE) {
                                    yield addChunk(chunkStreamByteIndex, chunk);
                                } else if (chunk.byteLength < merkle_1.MIN_CHUNK_SIZE) {
                                    if (previousDataChunk) {
                                        // If this final chunk is smaller than the minimum chunk size, rebalance this final chunk and
                                        // the previous chunk to keep the final chunk size above the minimum threshold.
                                        const remainingBytes = Buffer.concat([
                                            previousDataChunk,
                                            chunk
                                        ], previousDataChunk.byteLength + chunk.byteLength);
                                        const rebalancedSizeForPreviousChunk = Math.ceil(remainingBytes.byteLength / 2);
                                        const previousChunk = chunks.pop();
                                        const rebalancedPreviousChunk = yield addChunk(previousChunk.minByteRange, remainingBytes.slice(0, rebalancedSizeForPreviousChunk));
                                        yield addChunk(rebalancedPreviousChunk.maxByteRange, remainingBytes.slice(rebalancedSizeForPreviousChunk));
                                    } else {
                                        // This entire stream should be smaller than the minimum chunk size, just add the chunk in.
                                        yield addChunk(chunkStreamByteIndex, chunk);
                                    }
                                    expectChunkGenerationCompleted = true;
                                } else if (chunk.byteLength > merkle_1.MAX_CHUNK_SIZE) {
                                    throw Error("Encountered chunk larger than max chunk size.");
                                }
                                chunkStreamByteIndex += chunk.byteLength;
                                previousDataChunk = chunk;
                            }
                        } catch (e_1_1) {
                            e_1 = {
                                error: e_1_1
                            };
                        } finally{
                            try {
                                if (!_a && !_b && (_c = chunkedSource_1.return)) yield _c.call(chunkedSource_1);
                            } finally{
                                if (e_1) throw e_1.error;
                            }
                        }
                    });
                });
                const leaves = yield this.merkle.generateLeaves(chunks);
                const root = yield this.merkle.buildLayers(leaves);
                const proofs = this.merkle.generateProofs(root);
                return {
                    data_root: root.id,
                    chunks,
                    proofs
                };
            });
    }
    /**
     * Uploads the piped data to the specified transaction.
     *
     * @param tx
     * @param arweave
     * @param createTx whether or not the passed transaction should be created on the network.
     * This can be false if we want to reseed an existing transaction,
     * @param debugOpts
     */ uploadTransactionAsync(tx, createTx = true, debugOpts) {
        var _a, _b;
        const txId = tx.id;
        const log = (message)=>{
            if (debugOpts === null || debugOpts === void 0 ? void 0 : debugOpts.log) debugOpts.log(`[uploadTransactionAsync:${txId}] ${message}`);
        };
        log(`Starting chunked upload - ${(_b = (_a = tx.chunks) === null || _a === void 0 ? void 0 : _a.chunks) === null || _b === void 0 ? void 0 : _b.length} chunks / ${tx.data_size} total bytes`);
        return (source)=>__awaiter(this, void 0, void 0, function*() {
                if (!tx.chunks) {
                    throw Error("Transaction has no computed chunks!");
                }
                if (createTx) {
                    // Ensure the transaction data field is blank.
                    // We'll upload this data in chunks instead.
                    tx.data = new Uint8Array(0);
                    const createTxRes = yield this.api.post(`tx`, tx);
                    if (!(createTxRes.status >= 200 && createTxRes.status < 300)) {
                        throw new Error(`Failed to create transaction: status ${createTxRes.status} / data ${createTxRes.data}`);
                    }
                }
                const txChunkData = tx.chunks;
                const { chunks, proofs } = txChunkData;
                function prepareChunkUploadPayload(chunkIndex, chunkData) {
                    const proof = proofs[chunkIndex];
                    return {
                        data_root: tx.data_root,
                        data_size: tx.data_size,
                        data_path: (0, utils_1.bufferTob64Url)(proof.proof),
                        offset: proof.offset.toString(),
                        chunk: (0, utils_1.bufferTob64Url)(chunkData)
                    };
                }
                log(`Starting pipe - MAX_CHUNK_SIZE=${merkle_1.MAX_CHUNK_SIZE}`);
                yield (0, promises_1.pipeline)(source, (0, chunker_1.chunker)(merkle_1.MAX_CHUNK_SIZE, {
                    flush: true
                }), (chunkedSource)=>{
                    var _a, chunkedSource_2, chunkedSource_2_1;
                    return __awaiter(this, void 0, void 0, function*() {
                        var _b, e_2, _c, _d;
                        let chunkIndex = 0;
                        let dataRebalancedIntoFinalChunk;
                        const activeChunkUploads = [];
                        try {
                            for(_a = true, chunkedSource_2 = __asyncValues(chunkedSource); chunkedSource_2_1 = yield chunkedSource_2.next(), _b = chunkedSource_2_1.done, !_b; _a = true){
                                _d = chunkedSource_2_1.value;
                                _a = false;
                                const chunkData = _d;
                                const currentChunk = chunks[chunkIndex];
                                const chunkSize = currentChunk.maxByteRange - currentChunk.minByteRange;
                                log(`Got chunk - ${chunkData.byteLength} bytes / chunkSize ${chunkSize}`);
                                const expectedToBeFinalRebalancedChunk = dataRebalancedIntoFinalChunk != null;
                                let chunkPayload;
                                if (chunkData.byteLength === chunkSize) {
                                    // If the transaction data chunks was never rebalanced this is the only code path that
                                    // will execute as the incoming chunked data as the will always be equivalent to `chunkSize`.
                                    chunkPayload = prepareChunkUploadPayload(chunkIndex, chunkData);
                                } else if (chunkData.byteLength > chunkSize) {
                                    // If the incoming chunk data is larger than the expected size of the current chunk
                                    // it means that the transaction had chunks that were rebalanced to meet the minimum chunk size.
                                    //
                                    // It also means that the chunk we're currently processing should be the second to last
                                    // chunk.
                                    chunkPayload = prepareChunkUploadPayload(chunkIndex, chunkData.slice(0, chunkSize));
                                    dataRebalancedIntoFinalChunk = chunkData.slice(chunkSize);
                                } else if (chunkData.byteLength < chunkSize && expectedToBeFinalRebalancedChunk) {
                                    // If this is the final rebalanced chunk, create the upload payload by concatenating the previous
                                    // chunk's data that was moved into this and the remaining stream data.
                                    chunkPayload = prepareChunkUploadPayload(chunkIndex, Buffer.concat([
                                        dataRebalancedIntoFinalChunk,
                                        chunkData
                                    ], dataRebalancedIntoFinalChunk.length + chunkData.length));
                                } else {
                                    throw Error("Transaction data stream terminated incorrectly.");
                                }
                                const chunkValid = yield this.merkle.validatePath(txChunkData.data_root, parseInt(chunkPayload.offset), 0, parseInt(chunkPayload.data_size), (0, utils_1.b64UrlToBuffer)(chunkPayload.data_path));
                                if (!chunkValid) {
                                    throw new Error(`Unable to validate chunk ${chunkIndex}.`);
                                }
                                // Upload multiple transaction chunks in parallel to speed up the upload.
                                // If we are already at the maximum concurrent chunk upload limit,
                                // wait till all of them to complete first before continuing.
                                if (activeChunkUploads.length >= MAX_CONCURRENT_CHUNK_UPLOAD_COUNT) {
                                    yield Promise.all(activeChunkUploads);
                                    // Clear the active chunk uploads array.
                                    activeChunkUploads.length = 0;
                                }
                                // TODO: allow for this abort code behaviour
                                activeChunkUploads.push(this.api.post("chunk", chunkPayload, {
                                    retry: {
                                        onRetry: (err)=>!transaction_uploader_1.FATAL_CHUNK_UPLOAD_ERRORS.includes(err.message)
                                    }
                                }));
                                chunkIndex++;
                                log(`Chunk process done - ${chunkIndex}`);
                            }
                        } catch (e_2_1) {
                            e_2 = {
                                error: e_2_1
                            };
                        } finally{
                            try {
                                if (!_a && !_b && (_c = chunkedSource_2.return)) yield _c.call(chunkedSource_2);
                            } finally{
                                if (e_2) throw e_2.error;
                            }
                        }
                        log(`Active chunks to upload - ${activeChunkUploads.length}`);
                        yield Promise.all(activeChunkUploads);
                        if (chunkIndex < chunks.length) {
                            throw Error(`Transaction upload incomplete: ${chunkIndex + 1}/${chunks.length} chunks uploaded.`);
                        }
                    });
                }).catch((e)=>{
                    log(e.message);
                    throw e;
                });
            });
    }
}
exports.Stream = Stream; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/arweave.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.NodeArweave = exports.Arweave = void 0;
const common_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/common/index.js [app-route] (ecmascript)"));
const node_driver_1 = __importDefault(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/node-driver.js [app-route] (ecmascript)"));
const stream_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/stream/index.js [app-route] (ecmascript)");
class Arweave extends common_1.default {
    /**
     * Constructor for a new `Arweave` instance - this one uses the node crypto driver
     * @param gateways - Specify the Arweave gateway(s) you want to use for requests
     * @param options - Other configuration options
     * @param options.miners - A list of Arweave miners (peers) to use for requests
     * @param options.gateways - A list of Arweave miners (peers) to use for requests
     */ constructor(gateways, options){
        var _a;
        super(Object.assign(Object.assign({
            crypto: (_a = options === null || options === void 0 ? void 0 : options.crypto) !== null && _a !== void 0 ? _a : new node_driver_1.default()
        }, options), {
            gateways: gateways !== null && gateways !== void 0 ? gateways : "https://arweave.net"
        }));
        this.stream = new stream_1.Stream({
            deps: {
                crypto: this.crypto,
                api: this.api,
                merkle: this.merkle,
                transactions: this.transactions,
                deepHash: this.deepHash
            }
        });
    }
    static init(apiConfig) {
        return new Arweave(apiConfig);
    }
}
exports.Arweave = Arweave;
exports.NodeArweave = Arweave;
exports.default = Arweave; //# sourceMappingURL=arweave.js.map
}}),
"[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/index.js [app-route] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
__exportStar(__turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/arweave.js [app-route] (ecmascript)"), exports);
var arweave_1 = __turbopack_require__("[project]/node_modules/.pnpm/@irys+arweave@0.0.2/node_modules/@irys/arweave/build/cjs/node/arweave.js [app-route] (ecmascript)");
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return __importDefault(arweave_1).default;
    }
}); //# sourceMappingURL=index.js.map
}}),

};

//# sourceMappingURL=dbf43_%40irys_arweave_build_cjs_755af9._.js.map